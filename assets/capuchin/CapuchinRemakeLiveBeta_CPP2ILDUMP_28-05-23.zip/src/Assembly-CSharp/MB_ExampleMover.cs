﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000085 RID: 133
[Token(Token = "0x2000085")]
public class MB_ExampleMover : MonoBehaviour
{
	// Token: 0x0600135D RID: 4957 RVA: 0x000276D0 File Offset: 0x000258D0
	[Address(RVA = "0x24350D0", Offset = "0x24350D0", VA = "0x24350D0")]
	[Token(Token = "0x600135D")]
	private void method_0()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600135E RID: 4958 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x600135E")]
	[Address(RVA = "0x2435170", Offset = "0x2435170", VA = "0x2435170")]
	private void method_1()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600135F RID: 4959 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435210", Offset = "0x2435210", VA = "0x2435210")]
	[Token(Token = "0x600135F")]
	private void method_2()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001360 RID: 4960 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001360")]
	[Address(RVA = "0x24352AC", Offset = "0x24352AC", VA = "0x24352AC")]
	private void method_3()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001361 RID: 4961 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x243534C", Offset = "0x243534C", VA = "0x243534C")]
	[Token(Token = "0x6001361")]
	private void method_4()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001362 RID: 4962 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001362")]
	[Address(RVA = "0x24353EC", Offset = "0x24353EC", VA = "0x24353EC")]
	private void method_5()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001363 RID: 4963 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001363")]
	[Address(RVA = "0x2435488", Offset = "0x2435488", VA = "0x2435488")]
	private void method_6()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001364 RID: 4964 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435524", Offset = "0x2435524", VA = "0x2435524")]
	[Token(Token = "0x6001364")]
	private void method_7()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001365 RID: 4965 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001365")]
	[Address(RVA = "0x24355C4", Offset = "0x24355C4", VA = "0x24355C4")]
	private void method_8()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001366 RID: 4966 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435660", Offset = "0x2435660", VA = "0x2435660")]
	[Token(Token = "0x6001366")]
	private void method_9()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001367 RID: 4967 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x24356FC", Offset = "0x24356FC", VA = "0x24356FC")]
	[Token(Token = "0x6001367")]
	private void method_10()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001368 RID: 4968 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x243579C", Offset = "0x243579C", VA = "0x243579C")]
	[Token(Token = "0x6001368")]
	private void method_11()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001369 RID: 4969 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001369")]
	[Address(RVA = "0x2435838", Offset = "0x2435838", VA = "0x2435838")]
	private void method_12()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600136A RID: 4970 RVA: 0x00027708 File Offset: 0x00025908
	[Token(Token = "0x600136A")]
	[Address(RVA = "0x24358D4", Offset = "0x24358D4", VA = "0x24358D4")]
	private void method_13()
	{
		float time = Time.time;
	}

	// Token: 0x0600136B RID: 4971 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435970", Offset = "0x2435970", VA = "0x2435970")]
	[Token(Token = "0x600136B")]
	private void method_14()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600136C RID: 4972 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435A10", Offset = "0x2435A10", VA = "0x2435A10")]
	[Token(Token = "0x600136C")]
	private void method_15()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600136D RID: 4973 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435AAC", Offset = "0x2435AAC", VA = "0x2435AAC")]
	[Token(Token = "0x600136D")]
	private void method_16()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600136E RID: 4974 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x600136E")]
	[Address(RVA = "0x2435B48", Offset = "0x2435B48", VA = "0x2435B48")]
	private void method_17()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600136F RID: 4975 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x600136F")]
	[Address(RVA = "0x2435BE8", Offset = "0x2435BE8", VA = "0x2435BE8")]
	private void method_18()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001370 RID: 4976 RVA: 0x00027708 File Offset: 0x00025908
	[Token(Token = "0x6001370")]
	[Address(RVA = "0x2435C84", Offset = "0x2435C84", VA = "0x2435C84")]
	private void method_19()
	{
		float time = Time.time;
	}

	// Token: 0x06001371 RID: 4977 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001371")]
	[Address(RVA = "0x2435D20", Offset = "0x2435D20", VA = "0x2435D20")]
	private void method_20()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001372 RID: 4978 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435DBC", Offset = "0x2435DBC", VA = "0x2435DBC")]
	[Token(Token = "0x6001372")]
	private void method_21()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001373 RID: 4979 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2435E5C", Offset = "0x2435E5C", VA = "0x2435E5C")]
	[Token(Token = "0x6001373")]
	public MB_ExampleMover()
	{
	}

	// Token: 0x06001374 RID: 4980 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435E64", Offset = "0x2435E64", VA = "0x2435E64")]
	[Token(Token = "0x6001374")]
	private void method_22()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001375 RID: 4981 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001375")]
	[Address(RVA = "0x2435F00", Offset = "0x2435F00", VA = "0x2435F00")]
	private void method_23()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001376 RID: 4982 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2435F9C", Offset = "0x2435F9C", VA = "0x2435F9C")]
	[Token(Token = "0x6001376")]
	private void method_24()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001377 RID: 4983 RVA: 0x000276EC File Offset: 0x000258EC
	[Token(Token = "0x6001377")]
	[Address(RVA = "0x243603C", Offset = "0x243603C", VA = "0x243603C")]
	private void method_25()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001378 RID: 4984 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x24360DC", Offset = "0x24360DC", VA = "0x24360DC")]
	[Token(Token = "0x6001378")]
	private void method_26()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001379 RID: 4985 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x243617C", Offset = "0x243617C", VA = "0x243617C")]
	[Token(Token = "0x6001379")]
	private void method_27()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600137A RID: 4986 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x243621C", Offset = "0x243621C", VA = "0x243621C")]
	[Token(Token = "0x600137A")]
	private void method_28()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600137B RID: 4987 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x24362B8", Offset = "0x24362B8", VA = "0x24362B8")]
	[Token(Token = "0x600137B")]
	private void method_29()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600137C RID: 4988 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436354", Offset = "0x2436354", VA = "0x2436354")]
	[Token(Token = "0x600137C")]
	private void method_30()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600137D RID: 4989 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x24363F0", Offset = "0x24363F0", VA = "0x24363F0")]
	[Token(Token = "0x600137D")]
	private void method_31()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600137E RID: 4990 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436490", Offset = "0x2436490", VA = "0x2436490")]
	[Token(Token = "0x600137E")]
	private void method_32()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600137F RID: 4991 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436530", Offset = "0x2436530", VA = "0x2436530")]
	[Token(Token = "0x600137F")]
	private void method_33()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001380 RID: 4992 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x24365CC", Offset = "0x24365CC", VA = "0x24365CC")]
	[Token(Token = "0x6001380")]
	private void method_34()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001381 RID: 4993 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436668", Offset = "0x2436668", VA = "0x2436668")]
	[Token(Token = "0x6001381")]
	private void method_35()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001382 RID: 4994 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436708", Offset = "0x2436708", VA = "0x2436708")]
	[Token(Token = "0x6001382")]
	private void method_36()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001383 RID: 4995 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x24367A4", Offset = "0x24367A4", VA = "0x24367A4")]
	[Token(Token = "0x6001383")]
	private void method_37()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001384 RID: 4996 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436840", Offset = "0x2436840", VA = "0x2436840")]
	[Token(Token = "0x6001384")]
	private void method_38()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001385 RID: 4997 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x24368E0", Offset = "0x24368E0", VA = "0x24368E0")]
	[Token(Token = "0x6001385")]
	private void method_39()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001386 RID: 4998 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436980", Offset = "0x2436980", VA = "0x2436980")]
	[Token(Token = "0x6001386")]
	private void method_40()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001387 RID: 4999 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436A1C", Offset = "0x2436A1C", VA = "0x2436A1C")]
	[Token(Token = "0x6001387")]
	private void Update()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001388 RID: 5000 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436AB4", Offset = "0x2436AB4", VA = "0x2436AB4")]
	[Token(Token = "0x6001388")]
	private void method_41()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x06001389 RID: 5001 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436B50", Offset = "0x2436B50", VA = "0x2436B50")]
	[Token(Token = "0x6001389")]
	private void method_42()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600138A RID: 5002 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436BEC", Offset = "0x2436BEC", VA = "0x2436BEC")]
	[Token(Token = "0x600138A")]
	private void method_43()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600138B RID: 5003 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436C8C", Offset = "0x2436C8C", VA = "0x2436C8C")]
	[Token(Token = "0x600138B")]
	private void method_44()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600138C RID: 5004 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436D2C", Offset = "0x2436D2C", VA = "0x2436D2C")]
	[Token(Token = "0x600138C")]
	private void method_45()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x0600138D RID: 5005 RVA: 0x000276EC File Offset: 0x000258EC
	[Address(RVA = "0x2436DC8", Offset = "0x2436DC8", VA = "0x2436DC8")]
	[Token(Token = "0x600138D")]
	private void method_46()
	{
		float time = Time.time;
		Transform transform = base.transform;
	}

	// Token: 0x04000298 RID: 664
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000298")]
	public int int_0;
}
