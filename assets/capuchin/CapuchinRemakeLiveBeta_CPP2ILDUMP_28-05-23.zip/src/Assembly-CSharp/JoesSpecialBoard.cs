﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x020000D2 RID: 210
[Token(Token = "0x20000D2")]
public class JoesSpecialBoard : MonoBehaviour
{
	// Token: 0x06001E77 RID: 7799 RVA: 0x00002A5D File Offset: 0x00000C5D
	[Address(RVA = "0x3120D7C", Offset = "0x3120D7C", VA = "0x3120D7C")]
	[Token(Token = "0x6001E77")]
	private void method_0()
	{
		if (this.bool_0)
		{
			this.method_90();
		}
	}

	// Token: 0x06001E78 RID: 7800 RVA: 0x00002A6D File Offset: 0x00000C6D
	[Address(RVA = "0x3120E74", Offset = "0x3120E74", VA = "0x3120E74")]
	[Token(Token = "0x6001E78")]
	private void method_1()
	{
		this.method_28();
	}

	// Token: 0x06001E79 RID: 7801 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3120F44", Offset = "0x3120F44", VA = "0x3120F44")]
	[Token(Token = "0x6001E79")]
	public void method_2()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E7A RID: 7802 RVA: 0x00002A75 File Offset: 0x00000C75
	[Address(RVA = "0x3121010", Offset = "0x3121010", VA = "0x3121010")]
	[Token(Token = "0x6001E7A")]
	private void method_3()
	{
		this.method_97();
	}

	// Token: 0x06001E7B RID: 7803 RVA: 0x00002A7D File Offset: 0x00000C7D
	[Address(RVA = "0x31210E0", Offset = "0x31210E0", VA = "0x31210E0")]
	[Token(Token = "0x6001E7B")]
	private void method_4()
	{
		if (this.bool_0)
		{
			this.method_88();
		}
	}

	// Token: 0x06001E7C RID: 7804 RVA: 0x00002A8D File Offset: 0x00000C8D
	[Address(RVA = "0x31211D8", Offset = "0x31211D8", VA = "0x31211D8")]
	[Token(Token = "0x6001E7C")]
	private void method_5()
	{
		this.method_39();
	}

	// Token: 0x06001E7D RID: 7805 RVA: 0x00002A95 File Offset: 0x00000C95
	[Address(RVA = "0x31212A8", Offset = "0x31212A8", VA = "0x31212A8")]
	[Token(Token = "0x6001E7D")]
	private void method_6()
	{
		this.method_35();
	}

	// Token: 0x06001E7E RID: 7806 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121378", Offset = "0x3121378", VA = "0x3121378")]
	[Token(Token = "0x6001E7E")]
	public void method_7()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E7F RID: 7807 RVA: 0x00002A9D File Offset: 0x00000C9D
	[Address(RVA = "0x3121444", Offset = "0x3121444", VA = "0x3121444")]
	[Token(Token = "0x6001E7F")]
	private void method_8()
	{
		if (this.bool_0)
		{
			this.method_57();
		}
	}

	// Token: 0x06001E80 RID: 7808 RVA: 0x00038D48 File Offset: 0x00036F48
	[Address(RVA = "0x312153C", Offset = "0x312153C", VA = "0x312153C")]
	[Token(Token = "0x6001E80")]
	private void method_9()
	{
		if (this.bool_0)
		{
			this.method_84();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001E81 RID: 7809 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121638", Offset = "0x3121638", VA = "0x3121638")]
	[Token(Token = "0x6001E81")]
	public void method_10()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E82 RID: 7810 RVA: 0x00002AAD File Offset: 0x00000CAD
	[Address(RVA = "0x3121704", Offset = "0x3121704", VA = "0x3121704")]
	[Token(Token = "0x6001E82")]
	private void method_11()
	{
		this.method_75();
	}

	// Token: 0x06001E83 RID: 7811 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31217D4", Offset = "0x31217D4", VA = "0x31217D4")]
	[Token(Token = "0x6001E83")]
	public void method_12()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E84 RID: 7812 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31218A0", Offset = "0x31218A0", VA = "0x31218A0")]
	[Token(Token = "0x6001E84")]
	public void method_13()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E85 RID: 7813 RVA: 0x00002AB5 File Offset: 0x00000CB5
	[Address(RVA = "0x312196C", Offset = "0x312196C", VA = "0x312196C")]
	[Token(Token = "0x6001E85")]
	private void method_14()
	{
		this.method_89();
	}

	// Token: 0x06001E86 RID: 7814 RVA: 0x00002ABD File Offset: 0x00000CBD
	[Address(RVA = "0x3121A3C", Offset = "0x3121A3C", VA = "0x3121A3C")]
	[Token(Token = "0x6001E86")]
	private void method_15()
	{
		this.method_59();
	}

	// Token: 0x06001E87 RID: 7815 RVA: 0x00002AC5 File Offset: 0x00000CC5
	[Address(RVA = "0x3121B0C", Offset = "0x3121B0C", VA = "0x3121B0C")]
	[Token(Token = "0x6001E87")]
	private void method_16()
	{
		if (this.bool_0)
		{
			this.method_81();
		}
	}

	// Token: 0x06001E88 RID: 7816 RVA: 0x00002AD5 File Offset: 0x00000CD5
	[Address(RVA = "0x3121C04", Offset = "0x3121C04", VA = "0x3121C04")]
	[Token(Token = "0x6001E88")]
	private void method_17()
	{
		if (this.bool_0)
		{
			this.method_110();
		}
	}

	// Token: 0x06001E89 RID: 7817 RVA: 0x00038D6C File Offset: 0x00036F6C
	[Address(RVA = "0x3121CFC", Offset = "0x3121CFC", VA = "0x3121CFC")]
	[Token(Token = "0x6001E89")]
	private void method_18()
	{
		if (this.bool_0)
		{
			this.method_75();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001E8A RID: 7818 RVA: 0x00002AE5 File Offset: 0x00000CE5
	[Address(RVA = "0x3121D2C", Offset = "0x3121D2C", VA = "0x3121D2C")]
	[Token(Token = "0x6001E8A")]
	private void method_19()
	{
		if (this.bool_0)
		{
			this.method_66();
		}
	}

	// Token: 0x06001E8B RID: 7819 RVA: 0x00002AF5 File Offset: 0x00000CF5
	[Address(RVA = "0x3121E24", Offset = "0x3121E24", VA = "0x3121E24")]
	[Token(Token = "0x6001E8B")]
	private void method_20()
	{
		this.method_57();
	}

	// Token: 0x06001E8C RID: 7820 RVA: 0x00002A6D File Offset: 0x00000C6D
	[Address(RVA = "0x3121E28", Offset = "0x3121E28", VA = "0x3121E28")]
	[Token(Token = "0x6001E8C")]
	private void method_21()
	{
		this.method_28();
	}

	// Token: 0x06001E8D RID: 7821 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121E2C", Offset = "0x3121E2C", VA = "0x3121E2C")]
	[Token(Token = "0x6001E8D")]
	public void method_22()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E8E RID: 7822 RVA: 0x00002AB5 File Offset: 0x00000CB5
	[Address(RVA = "0x3121EF8", Offset = "0x3121EF8", VA = "0x3121EF8")]
	[Token(Token = "0x6001E8E")]
	private void method_23()
	{
		this.method_89();
	}

	// Token: 0x06001E8F RID: 7823 RVA: 0x00002AFD File Offset: 0x00000CFD
	[Address(RVA = "0x3121EFC", Offset = "0x3121EFC", VA = "0x3121EFC")]
	[Token(Token = "0x6001E8F")]
	private void method_24()
	{
		this.method_63();
	}

	// Token: 0x06001E90 RID: 7824 RVA: 0x00002B05 File Offset: 0x00000D05
	[Address(RVA = "0x3121FCC", Offset = "0x3121FCC", VA = "0x3121FCC")]
	[Token(Token = "0x6001E90")]
	private void method_25()
	{
		this.method_66();
	}

	// Token: 0x06001E91 RID: 7825 RVA: 0x00002B0D File Offset: 0x00000D0D
	[Address(RVA = "0x3121FD0", Offset = "0x3121FD0", VA = "0x3121FD0")]
	[Token(Token = "0x6001E91")]
	private void method_26()
	{
		if (this.bool_0)
		{
			this.method_103();
		}
	}

	// Token: 0x06001E92 RID: 7826 RVA: 0x00002B1D File Offset: 0x00000D1D
	[Address(RVA = "0x31220C8", Offset = "0x31220C8", VA = "0x31220C8")]
	[Token(Token = "0x6001E92")]
	private void method_27()
	{
		this.method_94();
	}

	// Token: 0x06001E93 RID: 7827 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3120E78", Offset = "0x3120E78", VA = "0x3120E78")]
	[Token(Token = "0x6001E93")]
	public void method_28()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E94 RID: 7828 RVA: 0x00002AFD File Offset: 0x00000CFD
	[Address(RVA = "0x3122198", Offset = "0x3122198", VA = "0x3122198")]
	[Token(Token = "0x6001E94")]
	private void method_29()
	{
		this.method_63();
	}

	// Token: 0x06001E95 RID: 7829 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x312219C", Offset = "0x312219C", VA = "0x312219C")]
	[Token(Token = "0x6001E95")]
	public void method_30()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E96 RID: 7830 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3122268", Offset = "0x3122268", VA = "0x3122268")]
	[Token(Token = "0x6001E96")]
	public void method_31()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E97 RID: 7831 RVA: 0x00002B25 File Offset: 0x00000D25
	[Address(RVA = "0x3122334", Offset = "0x3122334", VA = "0x3122334")]
	[Token(Token = "0x6001E97")]
	private void method_32()
	{
		this.method_84();
	}

	// Token: 0x06001E98 RID: 7832 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3122338", Offset = "0x3122338", VA = "0x3122338")]
	[Token(Token = "0x6001E98")]
	public void method_33()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E99 RID: 7833 RVA: 0x00002B1D File Offset: 0x00000D1D
	[Address(RVA = "0x3122404", Offset = "0x3122404", VA = "0x3122404")]
	[Token(Token = "0x6001E99")]
	private void method_34()
	{
		this.method_94();
	}

	// Token: 0x06001E9A RID: 7834 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31212AC", Offset = "0x31212AC", VA = "0x31212AC")]
	[Token(Token = "0x6001E9A")]
	public void method_35()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E9B RID: 7835 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3122408", Offset = "0x3122408", VA = "0x3122408")]
	[Token(Token = "0x6001E9B")]
	public void method_36()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E9C RID: 7836 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x31224D4", Offset = "0x31224D4", VA = "0x31224D4")]
	[Token(Token = "0x6001E9C")]
	public JoesSpecialBoard()
	{
	}

	// Token: 0x06001E9D RID: 7837 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31224DC", Offset = "0x31224DC", VA = "0x31224DC")]
	[Token(Token = "0x6001E9D")]
	public void method_37()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001E9E RID: 7838 RVA: 0x00002B2D File Offset: 0x00000D2D
	[Address(RVA = "0x31225A8", Offset = "0x31225A8", VA = "0x31225A8")]
	[Token(Token = "0x6001E9E")]
	private void method_38()
	{
		if (this.bool_0)
		{
			this.method_46();
		}
	}

	// Token: 0x06001E9F RID: 7839 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31211DC", Offset = "0x31211DC", VA = "0x31211DC")]
	[Token(Token = "0x6001E9F")]
	public void method_39()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EA0 RID: 7840 RVA: 0x00038D90 File Offset: 0x00036F90
	[Address(RVA = "0x31226A0", Offset = "0x31226A0", VA = "0x31226A0")]
	[Token(Token = "0x6001EA0")]
	private void method_40()
	{
		if (this.bool_0)
		{
			this.method_12();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EA1 RID: 7841 RVA: 0x00038DB4 File Offset: 0x00036FB4
	[Address(RVA = "0x31226D0", Offset = "0x31226D0", VA = "0x31226D0")]
	[Token(Token = "0x6001EA1")]
	private void method_41()
	{
		if (this.bool_0)
		{
			this.method_39();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EA2 RID: 7842 RVA: 0x00002B3D File Offset: 0x00000D3D
	[Address(RVA = "0x3122700", Offset = "0x3122700", VA = "0x3122700")]
	[Token(Token = "0x6001EA2")]
	private void method_42()
	{
		this.method_110();
	}

	// Token: 0x06001EA3 RID: 7843 RVA: 0x00002B25 File Offset: 0x00000D25
	[Address(RVA = "0x3122704", Offset = "0x3122704", VA = "0x3122704")]
	[Token(Token = "0x6001EA3")]
	private void method_43()
	{
		this.method_84();
	}

	// Token: 0x06001EA4 RID: 7844 RVA: 0x00002B25 File Offset: 0x00000D25
	[Address(RVA = "0x3122708", Offset = "0x3122708", VA = "0x3122708")]
	[Token(Token = "0x6001EA4")]
	private void method_44()
	{
		this.method_84();
	}

	// Token: 0x06001EA5 RID: 7845 RVA: 0x00002AC5 File Offset: 0x00000CC5
	[Address(RVA = "0x312270C", Offset = "0x312270C", VA = "0x312270C")]
	[Token(Token = "0x6001EA5")]
	private void method_45()
	{
		if (this.bool_0)
		{
			this.method_81();
		}
	}

	// Token: 0x06001EA6 RID: 7846 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31225D4", Offset = "0x31225D4", VA = "0x31225D4")]
	[Token(Token = "0x6001EA6")]
	public void method_46()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EA7 RID: 7847 RVA: 0x00002B1D File Offset: 0x00000D1D
	[Address(RVA = "0x3122738", Offset = "0x3122738", VA = "0x3122738")]
	[Token(Token = "0x6001EA7")]
	private void method_47()
	{
		this.method_94();
	}

	// Token: 0x06001EA8 RID: 7848 RVA: 0x00002B45 File Offset: 0x00000D45
	[Address(RVA = "0x312273C", Offset = "0x312273C", VA = "0x312273C")]
	[Token(Token = "0x6001EA8")]
	private void method_48()
	{
		if (this.bool_0)
		{
			this.method_2();
		}
	}

	// Token: 0x06001EA9 RID: 7849 RVA: 0x00002A75 File Offset: 0x00000C75
	[Address(RVA = "0x3122768", Offset = "0x3122768", VA = "0x3122768")]
	[Token(Token = "0x6001EA9")]
	private void method_49()
	{
		this.method_97();
	}

	// Token: 0x06001EAA RID: 7850 RVA: 0x00038DD8 File Offset: 0x00036FD8
	[Address(RVA = "0x312276C", Offset = "0x312276C", VA = "0x312276C")]
	[Token(Token = "0x6001EAA")]
	private void method_50()
	{
		if (this.bool_0)
		{
			this.method_88();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EAB RID: 7851 RVA: 0x00002B55 File Offset: 0x00000D55
	[Address(RVA = "0x312279C", Offset = "0x312279C", VA = "0x312279C")]
	[Token(Token = "0x6001EAB")]
	private void method_51()
	{
		if (this.bool_0)
		{
			this.method_10();
		}
	}

	// Token: 0x06001EAC RID: 7852 RVA: 0x00002AAD File Offset: 0x00000CAD
	[Address(RVA = "0x31227C8", Offset = "0x31227C8", VA = "0x31227C8")]
	[Token(Token = "0x6001EAC")]
	private void method_52()
	{
		this.method_75();
	}

	// Token: 0x06001EAD RID: 7853 RVA: 0x00038DFC File Offset: 0x00036FFC
	[Address(RVA = "0x31227CC", Offset = "0x31227CC", VA = "0x31227CC")]
	[Token(Token = "0x6001EAD")]
	private void method_53()
	{
		if (this.bool_0)
		{
			this.method_33();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EAE RID: 7854 RVA: 0x00002B65 File Offset: 0x00000D65
	[Address(RVA = "0x31227FC", Offset = "0x31227FC", VA = "0x31227FC")]
	[Token(Token = "0x6001EAE")]
	private void method_54()
	{
		this.method_22();
	}

	// Token: 0x06001EAF RID: 7855 RVA: 0x00002B6D File Offset: 0x00000D6D
	[Address(RVA = "0x3122800", Offset = "0x3122800", VA = "0x3122800")]
	[Token(Token = "0x6001EAF")]
	private void method_55()
	{
		this.method_37();
	}

	// Token: 0x06001EB0 RID: 7856 RVA: 0x00002B65 File Offset: 0x00000D65
	[Address(RVA = "0x3122804", Offset = "0x3122804", VA = "0x3122804")]
	[Token(Token = "0x6001EB0")]
	private void method_56()
	{
		this.method_22();
	}

	// Token: 0x06001EB1 RID: 7857 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121470", Offset = "0x3121470", VA = "0x3121470")]
	[Token(Token = "0x6001EB1")]
	public void method_57()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EB2 RID: 7858 RVA: 0x00002A75 File Offset: 0x00000C75
	[Address(RVA = "0x3122808", Offset = "0x3122808", VA = "0x3122808")]
	[Token(Token = "0x6001EB2")]
	private void method_58()
	{
		this.method_97();
	}

	// Token: 0x06001EB3 RID: 7859 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121A40", Offset = "0x3121A40", VA = "0x3121A40")]
	[Token(Token = "0x6001EB3")]
	public void method_59()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EB4 RID: 7860 RVA: 0x00002B75 File Offset: 0x00000D75
	[Address(RVA = "0x312280C", Offset = "0x312280C", VA = "0x312280C")]
	[Token(Token = "0x6001EB4")]
	private void method_60()
	{
		this.method_10();
	}

	// Token: 0x06001EB5 RID: 7861 RVA: 0x00038DB4 File Offset: 0x00036FB4
	[Address(RVA = "0x3122810", Offset = "0x3122810", VA = "0x3122810")]
	[Token(Token = "0x6001EB5")]
	private void method_61()
	{
		if (this.bool_0)
		{
			this.method_39();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EB6 RID: 7862 RVA: 0x00002B7D File Offset: 0x00000D7D
	[Address(RVA = "0x3122840", Offset = "0x3122840", VA = "0x3122840")]
	[Token(Token = "0x6001EB6")]
	private void method_62()
	{
		this.method_36();
	}

	// Token: 0x06001EB7 RID: 7863 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121F00", Offset = "0x3121F00", VA = "0x3121F00")]
	[Token(Token = "0x6001EB7")]
	public void method_63()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EB8 RID: 7864 RVA: 0x00002A8D File Offset: 0x00000C8D
	[Address(RVA = "0x3122844", Offset = "0x3122844", VA = "0x3122844")]
	[Token(Token = "0x6001EB8")]
	private void method_64()
	{
		this.method_39();
	}

	// Token: 0x06001EB9 RID: 7865 RVA: 0x00002A6D File Offset: 0x00000C6D
	[Address(RVA = "0x3122848", Offset = "0x3122848", VA = "0x3122848")]
	[Token(Token = "0x6001EB9")]
	private void method_65()
	{
		this.method_28();
	}

	// Token: 0x06001EBA RID: 7866 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121D58", Offset = "0x3121D58", VA = "0x3121D58")]
	[Token(Token = "0x6001EBA")]
	public void method_66()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EBB RID: 7867 RVA: 0x00038E20 File Offset: 0x00037020
	[Address(RVA = "0x312284C", Offset = "0x312284C", VA = "0x312284C")]
	[Token(Token = "0x6001EBB")]
	private void method_67()
	{
		if (this.bool_0)
		{
			this.method_28();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EBC RID: 7868 RVA: 0x00038E44 File Offset: 0x00037044
	[Address(RVA = "0x312287C", Offset = "0x312287C", VA = "0x312287C")]
	[Token(Token = "0x6001EBC")]
	private void method_68()
	{
		if (this.bool_0)
		{
			this.method_85();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EBD RID: 7869 RVA: 0x00002B85 File Offset: 0x00000D85
	[Address(RVA = "0x3122978", Offset = "0x3122978", VA = "0x3122978")]
	[Token(Token = "0x6001EBD")]
	private void method_69()
	{
		this.method_102();
	}

	// Token: 0x06001EBE RID: 7870 RVA: 0x00002B8D File Offset: 0x00000D8D
	[Address(RVA = "0x3122A48", Offset = "0x3122A48", VA = "0x3122A48")]
	[Token(Token = "0x6001EBE")]
	private void method_70()
	{
		this.method_103();
	}

	// Token: 0x06001EBF RID: 7871 RVA: 0x00038E68 File Offset: 0x00037068
	[Address(RVA = "0x3122A4C", Offset = "0x3122A4C", VA = "0x3122A4C")]
	[Token(Token = "0x6001EBF")]
	private void method_71()
	{
		if (this.bool_0)
		{
			this.method_82();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EC0 RID: 7872 RVA: 0x00002AF5 File Offset: 0x00000CF5
	[Address(RVA = "0x3122B48", Offset = "0x3122B48", VA = "0x3122B48")]
	[Token(Token = "0x6001EC0")]
	private void method_72()
	{
		this.method_57();
	}

	// Token: 0x06001EC1 RID: 7873 RVA: 0x00002B95 File Offset: 0x00000D95
	[Address(RVA = "0x3122B4C", Offset = "0x3122B4C", VA = "0x3122B4C")]
	[Token(Token = "0x6001EC1")]
	private void method_73()
	{
		if (this.bool_0)
		{
			this.method_30();
		}
	}

	// Token: 0x06001EC2 RID: 7874 RVA: 0x00002BA5 File Offset: 0x00000DA5
	[Address(RVA = "0x3122B78", Offset = "0x3122B78", VA = "0x3122B78")]
	[Token(Token = "0x6001EC2")]
	private void method_74()
	{
		this.method_30();
	}

	// Token: 0x06001EC3 RID: 7875 RVA: 0x00002BAD File Offset: 0x00000DAD
	[Address(RVA = "0x3122B7C", Offset = "0x3122B7C", VA = "0x3122B7C")]
	[Token(Token = "0x6001EC3")]
	private void Update()
	{
		if (this.bool_0)
		{
			this.method_94();
		}
	}

	// Token: 0x06001EC4 RID: 7876 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121708", Offset = "0x3121708", VA = "0x3121708")]
	[Token(Token = "0x6001EC4")]
	public void method_75()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EC5 RID: 7877 RVA: 0x00002B1D File Offset: 0x00000D1D
	[Address(RVA = "0x3122BA8", Offset = "0x3122BA8", VA = "0x3122BA8")]
	[Token(Token = "0x6001EC5")]
	private void method_76()
	{
		this.method_94();
	}

	// Token: 0x06001EC6 RID: 7878 RVA: 0x00038E8C File Offset: 0x0003708C
	[Address(RVA = "0x3122BAC", Offset = "0x3122BAC", VA = "0x3122BAC")]
	[Token(Token = "0x6001EC6")]
	private void method_77()
	{
		if (this.bool_0)
		{
			this.method_94();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EC7 RID: 7879 RVA: 0x00002BBD File Offset: 0x00000DBD
	[Address(RVA = "0x3122BDC", Offset = "0x3122BDC", VA = "0x3122BDC")]
	[Token(Token = "0x6001EC7")]
	private void method_78()
	{
		this.method_33();
	}

	// Token: 0x06001EC8 RID: 7880 RVA: 0x00038E8C File Offset: 0x0003708C
	[Address(RVA = "0x3122BE0", Offset = "0x3122BE0", VA = "0x3122BE0")]
	[Token(Token = "0x6001EC8")]
	private void method_79()
	{
		if (this.bool_0)
		{
			this.method_94();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EC9 RID: 7881 RVA: 0x00002A8D File Offset: 0x00000C8D
	[Address(RVA = "0x3122C10", Offset = "0x3122C10", VA = "0x3122C10")]
	[Token(Token = "0x6001EC9")]
	private void method_80()
	{
		this.method_39();
	}

	// Token: 0x06001ECA RID: 7882 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121B38", Offset = "0x3121B38", VA = "0x3121B38")]
	[Token(Token = "0x6001ECA")]
	public void method_81()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ECB RID: 7883 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3122A7C", Offset = "0x3122A7C", VA = "0x3122A7C")]
	[Token(Token = "0x6001ECB")]
	public void method_82()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ECC RID: 7884 RVA: 0x00038EB0 File Offset: 0x000370B0
	[Address(RVA = "0x3122C14", Offset = "0x3122C14", VA = "0x3122C14")]
	[Token(Token = "0x6001ECC")]
	private void method_83()
	{
		if (this.bool_0)
		{
			this.method_30();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001ECD RID: 7885 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x312156C", Offset = "0x312156C", VA = "0x312156C")]
	[Token(Token = "0x6001ECD")]
	public void method_84()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ECE RID: 7886 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31228AC", Offset = "0x31228AC", VA = "0x31228AC")]
	[Token(Token = "0x6001ECE")]
	public void method_85()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ECF RID: 7887 RVA: 0x00002BC5 File Offset: 0x00000DC5
	[Address(RVA = "0x3122C44", Offset = "0x3122C44", VA = "0x3122C44")]
	[Token(Token = "0x6001ECF")]
	private void method_86()
	{
		this.method_95();
	}

	// Token: 0x06001ED0 RID: 7888 RVA: 0x00038ED4 File Offset: 0x000370D4
	[Address(RVA = "0x3122D14", Offset = "0x3122D14", VA = "0x3122D14")]
	[Token(Token = "0x6001ED0")]
	private void method_87()
	{
		if (this.bool_0)
		{
			this.method_36();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001ED1 RID: 7889 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x312110C", Offset = "0x312110C", VA = "0x312110C")]
	[Token(Token = "0x6001ED1")]
	public void method_88()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ED2 RID: 7890 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121970", Offset = "0x3121970", VA = "0x3121970")]
	[Token(Token = "0x6001ED2")]
	public void method_89()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ED3 RID: 7891 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3120DA8", Offset = "0x3120DA8", VA = "0x3120DA8")]
	[Token(Token = "0x6001ED3")]
	public void method_90()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ED4 RID: 7892 RVA: 0x00002AB5 File Offset: 0x00000CB5
	[Address(RVA = "0x3122D44", Offset = "0x3122D44", VA = "0x3122D44")]
	[Token(Token = "0x6001ED4")]
	private void method_91()
	{
		this.method_89();
	}

	// Token: 0x06001ED5 RID: 7893 RVA: 0x00038EF8 File Offset: 0x000370F8
	[Address(RVA = "0x3122D48", Offset = "0x3122D48", VA = "0x3122D48")]
	[Token(Token = "0x6001ED5")]
	private void method_92()
	{
		if (this.bool_0)
		{
			this.method_81();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001ED6 RID: 7894 RVA: 0x00038F1C File Offset: 0x0003711C
	[Address(RVA = "0x3122D78", Offset = "0x3122D78", VA = "0x3122D78")]
	[Token(Token = "0x6001ED6")]
	private void method_93()
	{
		if (this.bool_0)
		{
			this.method_7();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001ED7 RID: 7895 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x31220CC", Offset = "0x31220CC", VA = "0x31220CC")]
	[Token(Token = "0x6001ED7")]
	public void method_94()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ED8 RID: 7896 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3122C48", Offset = "0x3122C48", VA = "0x3122C48")]
	[Token(Token = "0x6001ED8")]
	public void method_95()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001ED9 RID: 7897 RVA: 0x00002BCD File Offset: 0x00000DCD
	[Address(RVA = "0x3122DA8", Offset = "0x3122DA8", VA = "0x3122DA8")]
	[Token(Token = "0x6001ED9")]
	private void method_96()
	{
		this.method_13();
	}

	// Token: 0x06001EDA RID: 7898 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121014", Offset = "0x3121014", VA = "0x3121014")]
	[Token(Token = "0x6001EDA")]
	public void method_97()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EDB RID: 7899 RVA: 0x00002B7D File Offset: 0x00000D7D
	[Address(RVA = "0x3122DAC", Offset = "0x3122DAC", VA = "0x3122DAC")]
	[Token(Token = "0x6001EDB")]
	private void method_98()
	{
		this.method_36();
	}

	// Token: 0x06001EDC RID: 7900 RVA: 0x00002B1D File Offset: 0x00000D1D
	[Address(RVA = "0x3122DB0", Offset = "0x3122DB0", VA = "0x3122DB0")]
	[Token(Token = "0x6001EDC")]
	private void Start()
	{
		this.method_94();
	}

	// Token: 0x06001EDD RID: 7901 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3122DB4", Offset = "0x3122DB4", VA = "0x3122DB4")]
	[Token(Token = "0x6001EDD")]
	public void method_99()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EDE RID: 7902 RVA: 0x00002A6D File Offset: 0x00000C6D
	[Address(RVA = "0x3122E80", Offset = "0x3122E80", VA = "0x3122E80")]
	[Token(Token = "0x6001EDE")]
	private void method_100()
	{
		this.method_28();
	}

	// Token: 0x06001EDF RID: 7903 RVA: 0x00038EF8 File Offset: 0x000370F8
	[Address(RVA = "0x3122E84", Offset = "0x3122E84", VA = "0x3122E84")]
	[Token(Token = "0x6001EDF")]
	private void method_101()
	{
		if (this.bool_0)
		{
			this.method_81();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EE0 RID: 7904 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x312297C", Offset = "0x312297C", VA = "0x312297C")]
	[Token(Token = "0x6001EE0")]
	public void method_102()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EE1 RID: 7905 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121FFC", Offset = "0x3121FFC", VA = "0x3121FFC")]
	[Token(Token = "0x6001EE1")]
	public void method_103()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EE2 RID: 7906 RVA: 0x00002B75 File Offset: 0x00000D75
	[Address(RVA = "0x3122EB4", Offset = "0x3122EB4", VA = "0x3122EB4")]
	[Token(Token = "0x6001EE2")]
	private void method_104()
	{
		this.method_10();
	}

	// Token: 0x06001EE3 RID: 7907 RVA: 0x00038F40 File Offset: 0x00037140
	[Address(RVA = "0x3122EB8", Offset = "0x3122EB8", VA = "0x3122EB8")]
	[Token(Token = "0x6001EE3")]
	private void method_105()
	{
		if (this.bool_0)
		{
			this.method_66();
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001EE4 RID: 7908 RVA: 0x00002BD5 File Offset: 0x00000DD5
	[Address(RVA = "0x3122EE8", Offset = "0x3122EE8", VA = "0x3122EE8")]
	[Token(Token = "0x6001EE4")]
	private void method_106()
	{
		this.method_46();
	}

	// Token: 0x06001EE5 RID: 7909 RVA: 0x00002ABD File Offset: 0x00000CBD
	[Address(RVA = "0x3122EEC", Offset = "0x3122EEC", VA = "0x3122EEC")]
	[Token(Token = "0x6001EE5")]
	private void method_107()
	{
		this.method_59();
	}

	// Token: 0x06001EE6 RID: 7910 RVA: 0x00002BDD File Offset: 0x00000DDD
	[Address(RVA = "0x3122EF0", Offset = "0x3122EF0", VA = "0x3122EF0")]
	[Token(Token = "0x6001EE6")]
	private void method_108()
	{
		this.method_12();
	}

	// Token: 0x06001EE7 RID: 7911 RVA: 0x00002A9D File Offset: 0x00000C9D
	[Address(RVA = "0x3122EF4", Offset = "0x3122EF4", VA = "0x3122EF4")]
	[Token(Token = "0x6001EE7")]
	private void method_109()
	{
		if (this.bool_0)
		{
			this.method_57();
		}
	}

	// Token: 0x06001EE8 RID: 7912 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3121C30", Offset = "0x3121C30", VA = "0x3121C30")]
	[Token(Token = "0x6001EE8")]
	public void method_110()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EE9 RID: 7913 RVA: 0x00002A6D File Offset: 0x00000C6D
	[Address(RVA = "0x3122F20", Offset = "0x3122F20", VA = "0x3122F20")]
	[Token(Token = "0x6001EE9")]
	private void method_111()
	{
		this.method_28();
	}

	// Token: 0x06001EEA RID: 7914 RVA: 0x00002BCD File Offset: 0x00000DCD
	[Address(RVA = "0x3122F24", Offset = "0x3122F24", VA = "0x3122F24")]
	[Token(Token = "0x6001EEA")]
	private void method_112()
	{
		this.method_13();
	}

	// Token: 0x06001EEB RID: 7915 RVA: 0x00002BE5 File Offset: 0x00000DE5
	[Address(RVA = "0x3122F28", Offset = "0x3122F28", VA = "0x3122F28")]
	[Token(Token = "0x6001EEB")]
	private void method_113()
	{
		this.method_81();
	}

	// Token: 0x06001EEC RID: 7916 RVA: 0x00002BED File Offset: 0x00000DED
	[Address(RVA = "0x3122F2C", Offset = "0x3122F2C", VA = "0x3122F2C")]
	[Token(Token = "0x6001EEC")]
	private void method_114()
	{
		this.method_82();
	}

	// Token: 0x06001EED RID: 7917 RVA: 0x00002BF5 File Offset: 0x00000DF5
	[Address(RVA = "0x3122F30", Offset = "0x3122F30", VA = "0x3122F30")]
	[Token(Token = "0x6001EED")]
	private void method_115()
	{
		if (this.bool_0)
		{
			this.method_102();
		}
	}

	// Token: 0x06001EEE RID: 7918 RVA: 0x00002AB5 File Offset: 0x00000CB5
	[Address(RVA = "0x3122F5C", Offset = "0x3122F5C", VA = "0x3122F5C")]
	[Token(Token = "0x6001EEE")]
	private void method_116()
	{
		this.method_89();
	}

	// Token: 0x06001EEF RID: 7919 RVA: 0x00002C05 File Offset: 0x00000E05
	[Address(RVA = "0x3122F60", Offset = "0x3122F60", VA = "0x3122F60")]
	[Token(Token = "0x6001EEF")]
	private void method_117()
	{
		if (this.bool_0)
		{
			this.method_119();
		}
	}

	// Token: 0x06001EF0 RID: 7920 RVA: 0x00002C05 File Offset: 0x00000E05
	[Address(RVA = "0x3123058", Offset = "0x3123058", VA = "0x3123058")]
	[Token(Token = "0x6001EF0")]
	private void method_118()
	{
		if (this.bool_0)
		{
			this.method_119();
		}
	}

	// Token: 0x06001EF1 RID: 7921 RVA: 0x00038D04 File Offset: 0x00036F04
	[Address(RVA = "0x3122F8C", Offset = "0x3122F8C", VA = "0x3122F8C")]
	[Token(Token = "0x6001EF1")]
	public void method_119()
	{
		TextMeshPro component = base.GetComponent<TextMeshPro>();
		this.textMeshPro_0 = component;
		float num = this.float_2;
		this.float_0 = num;
		float f;
		int num2 = Mathf.RoundToInt(f);
		this.int_0 = num2;
		this.string_1 = component;
	}

	// Token: 0x06001EF2 RID: 7922 RVA: 0x00002C15 File Offset: 0x00000E15
	[Address(RVA = "0x3123084", Offset = "0x3123084", VA = "0x3123084")]
	[Token(Token = "0x6001EF2")]
	private void method_120()
	{
		this.method_31();
	}

	// Token: 0x06001EF3 RID: 7923 RVA: 0x00002C1D File Offset: 0x00000E1D
	[Address(RVA = "0x3123088", Offset = "0x3123088", VA = "0x3123088")]
	[Token(Token = "0x6001EF3")]
	private void method_121()
	{
		if (this.bool_0)
		{
			this.method_59();
		}
	}

	// Token: 0x06001EF4 RID: 7924 RVA: 0x00002AB5 File Offset: 0x00000CB5
	[Address(RVA = "0x31230B4", Offset = "0x31230B4", VA = "0x31230B4")]
	[Token(Token = "0x6001EF4")]
	private void method_122()
	{
		this.method_89();
	}

	// Token: 0x06001EF5 RID: 7925 RVA: 0x00002C2D File Offset: 0x00000E2D
	[Address(RVA = "0x31230B8", Offset = "0x31230B8", VA = "0x31230B8")]
	[Token(Token = "0x6001EF5")]
	private void method_123()
	{
		if (this.bool_0)
		{
			this.method_13();
		}
	}

	// Token: 0x04000407 RID: 1031
	[Token(Token = "0x4000407")]
	[FieldOffset(Offset = "0x18")]
	public string[] string_0;

	// Token: 0x04000408 RID: 1032
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000408")]
	public float float_0;

	// Token: 0x04000409 RID: 1033
	[Token(Token = "0x4000409")]
	[FieldOffset(Offset = "0x24")]
	public int int_0;

	// Token: 0x0400040A RID: 1034
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400040A")]
	public float float_1;

	// Token: 0x0400040B RID: 1035
	[Token(Token = "0x400040B")]
	[FieldOffset(Offset = "0x2C")]
	public float float_2;

	// Token: 0x0400040C RID: 1036
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400040C")]
	public string string_1;

	// Token: 0x0400040D RID: 1037
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400040D")]
	private TextMeshPro textMeshPro_0;

	// Token: 0x0400040E RID: 1038
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400040E")]
	public bool bool_0;
}
