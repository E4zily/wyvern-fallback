﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200003C RID: 60
[Token(Token = "0x200003C")]
public class PositionToPosition : MonoBehaviour
{
	// Token: 0x0600079E RID: 1950 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D474", Offset = "0x2A7D474", VA = "0x2A7D474")]
	[Token(Token = "0x600079E")]
	public void method_0()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x600079F")]
	[Address(RVA = "0x2A7D4B4", Offset = "0x2A7D4B4", VA = "0x2A7D4B4")]
	public void method_1()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D4F4", Offset = "0x2A7D4F4", VA = "0x2A7D4F4")]
	[Token(Token = "0x60007A0")]
	public void method_2()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D534", Offset = "0x2A7D534", VA = "0x2A7D534")]
	[Token(Token = "0x60007A1")]
	public void method_3()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007A2")]
	[Address(RVA = "0x2A7D574", Offset = "0x2A7D574", VA = "0x2A7D574")]
	public void method_4()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A3 RID: 1955 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D5B4", Offset = "0x2A7D5B4", VA = "0x2A7D5B4")]
	[Token(Token = "0x60007A3")]
	public void method_5()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D5F4", Offset = "0x2A7D5F4", VA = "0x2A7D5F4")]
	[Token(Token = "0x60007A4")]
	public void method_6()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D634", Offset = "0x2A7D634", VA = "0x2A7D634")]
	[Token(Token = "0x60007A5")]
	public void method_7()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A6 RID: 1958 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D674", Offset = "0x2A7D674", VA = "0x2A7D674")]
	[Token(Token = "0x60007A6")]
	public void method_8()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D6B4", Offset = "0x2A7D6B4", VA = "0x2A7D6B4")]
	[Token(Token = "0x60007A7")]
	public void method_9()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A8 RID: 1960 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007A8")]
	[Address(RVA = "0x2A7D6F4", Offset = "0x2A7D6F4", VA = "0x2A7D6F4")]
	public void Update()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007A9 RID: 1961 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A7D734", Offset = "0x2A7D734", VA = "0x2A7D734")]
	[Token(Token = "0x60007A9")]
	public PositionToPosition()
	{
	}

	// Token: 0x060007AA RID: 1962 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007AA")]
	[Address(RVA = "0x2A7D73C", Offset = "0x2A7D73C", VA = "0x2A7D73C")]
	public void method_10()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007AB RID: 1963 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007AB")]
	[Address(RVA = "0x2A7D77C", Offset = "0x2A7D77C", VA = "0x2A7D77C")]
	public void method_11()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007AC RID: 1964 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D7BC", Offset = "0x2A7D7BC", VA = "0x2A7D7BC")]
	[Token(Token = "0x60007AC")]
	public void method_12()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007AD")]
	[Address(RVA = "0x2A7D7FC", Offset = "0x2A7D7FC", VA = "0x2A7D7FC")]
	public void method_13()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D83C", Offset = "0x2A7D83C", VA = "0x2A7D83C")]
	[Token(Token = "0x60007AE")]
	public void method_14()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D87C", Offset = "0x2A7D87C", VA = "0x2A7D87C")]
	[Token(Token = "0x60007AF")]
	public void method_15()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007B0")]
	[Address(RVA = "0x2A7D8BC", Offset = "0x2A7D8BC", VA = "0x2A7D8BC")]
	public void method_16()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D8FC", Offset = "0x2A7D8FC", VA = "0x2A7D8FC")]
	[Token(Token = "0x60007B1")]
	public void method_17()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D93C", Offset = "0x2A7D93C", VA = "0x2A7D93C")]
	[Token(Token = "0x60007B2")]
	public void method_18()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007B3")]
	[Address(RVA = "0x2A7D97C", Offset = "0x2A7D97C", VA = "0x2A7D97C")]
	public void method_19()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D9BC", Offset = "0x2A7D9BC", VA = "0x2A7D9BC")]
	[Token(Token = "0x60007B4")]
	public void method_20()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B5 RID: 1973 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7D9FC", Offset = "0x2A7D9FC", VA = "0x2A7D9FC")]
	[Token(Token = "0x60007B5")]
	public void method_21()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007B6")]
	[Address(RVA = "0x2A7DA3C", Offset = "0x2A7DA3C", VA = "0x2A7DA3C")]
	public void method_22()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DA7C", Offset = "0x2A7DA7C", VA = "0x2A7DA7C")]
	[Token(Token = "0x60007B7")]
	public void method_23()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B8 RID: 1976 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DABC", Offset = "0x2A7DABC", VA = "0x2A7DABC")]
	[Token(Token = "0x60007B8")]
	public void method_24()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007B9 RID: 1977 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DAFC", Offset = "0x2A7DAFC", VA = "0x2A7DAFC")]
	[Token(Token = "0x60007B9")]
	public void method_25()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007BA RID: 1978 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DB3C", Offset = "0x2A7DB3C", VA = "0x2A7DB3C")]
	[Token(Token = "0x60007BA")]
	public void method_26()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007BB")]
	[Address(RVA = "0x2A7DB7C", Offset = "0x2A7DB7C", VA = "0x2A7DB7C")]
	public void method_27()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007BC RID: 1980 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DBBC", Offset = "0x2A7DBBC", VA = "0x2A7DBBC")]
	[Token(Token = "0x60007BC")]
	public void method_28()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DBFC", Offset = "0x2A7DBFC", VA = "0x2A7DBFC")]
	[Token(Token = "0x60007BD")]
	public void method_29()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007BE")]
	[Address(RVA = "0x2A7DC3C", Offset = "0x2A7DC3C", VA = "0x2A7DC3C")]
	public void method_30()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DC7C", Offset = "0x2A7DC7C", VA = "0x2A7DC7C")]
	[Token(Token = "0x60007BF")]
	public void method_31()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DCBC", Offset = "0x2A7DCBC", VA = "0x2A7DCBC")]
	[Token(Token = "0x60007C0")]
	public void method_32()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007C1")]
	[Address(RVA = "0x2A7DCFC", Offset = "0x2A7DCFC", VA = "0x2A7DCFC")]
	public void method_33()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007C2")]
	[Address(RVA = "0x2A7DD3C", Offset = "0x2A7DD3C", VA = "0x2A7DD3C")]
	public void method_34()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C3 RID: 1987 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DD7C", Offset = "0x2A7DD7C", VA = "0x2A7DD7C")]
	[Token(Token = "0x60007C3")]
	public void method_35()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C4 RID: 1988 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DDBC", Offset = "0x2A7DDBC", VA = "0x2A7DDBC")]
	[Token(Token = "0x60007C4")]
	public void method_36()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C5 RID: 1989 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007C5")]
	[Address(RVA = "0x2A7DDFC", Offset = "0x2A7DDFC", VA = "0x2A7DDFC")]
	public void method_37()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C6 RID: 1990 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DE3C", Offset = "0x2A7DE3C", VA = "0x2A7DE3C")]
	[Token(Token = "0x60007C6")]
	public void method_38()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DE7C", Offset = "0x2A7DE7C", VA = "0x2A7DE7C")]
	[Token(Token = "0x60007C7")]
	public void method_39()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C8 RID: 1992 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DEBC", Offset = "0x2A7DEBC", VA = "0x2A7DEBC")]
	[Token(Token = "0x60007C8")]
	public void method_40()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007C9 RID: 1993 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007C9")]
	[Address(RVA = "0x2A7DEFC", Offset = "0x2A7DEFC", VA = "0x2A7DEFC")]
	public void method_41()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007CA")]
	[Address(RVA = "0x2A7DF3C", Offset = "0x2A7DF3C", VA = "0x2A7DF3C")]
	public void method_42()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007CB RID: 1995 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007CB")]
	[Address(RVA = "0x2A7DF7C", Offset = "0x2A7DF7C", VA = "0x2A7DF7C")]
	public void method_43()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7DFBC", Offset = "0x2A7DFBC", VA = "0x2A7DFBC")]
	[Token(Token = "0x60007CC")]
	public void method_44()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007CD RID: 1997 RVA: 0x00012014 File Offset: 0x00010214
	[Token(Token = "0x60007CD")]
	[Address(RVA = "0x2A7DFFC", Offset = "0x2A7DFFC", VA = "0x2A7DFFC")]
	public void method_45()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060007CE RID: 1998 RVA: 0x00012014 File Offset: 0x00010214
	[Address(RVA = "0x2A7E03C", Offset = "0x2A7E03C", VA = "0x2A7E03C")]
	[Token(Token = "0x60007CE")]
	public void method_46()
	{
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x0400010F RID: 271
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400010F")]
	public Transform transform_0;

	// Token: 0x04000110 RID: 272
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000110")]
	public Transform transform_1;
}
