﻿using System;
using Cpp2IlInjected;

// Token: 0x0200016C RID: 364
[Token(Token = "0x200016C")]
public enum GEnum23
{
	// Token: 0x040009BB RID: 2491
	[Token(Token = "0x40009BB")]
	const_0,
	// Token: 0x040009BC RID: 2492
	[Token(Token = "0x40009BC")]
	const_1,
	// Token: 0x040009BD RID: 2493
	[Token(Token = "0x40009BD")]
	const_2,
	// Token: 0x040009BE RID: 2494
	[Token(Token = "0x40009BE")]
	const_3,
	// Token: 0x040009BF RID: 2495
	[Token(Token = "0x40009BF")]
	const_4,
	// Token: 0x040009C0 RID: 2496
	[Token(Token = "0x40009C0")]
	const_5,
	// Token: 0x040009C1 RID: 2497
	[Token(Token = "0x40009C1")]
	const_6,
	// Token: 0x040009C2 RID: 2498
	[Token(Token = "0x40009C2")]
	const_7,
	// Token: 0x040009C3 RID: 2499
	[Token(Token = "0x40009C3")]
	const_8,
	// Token: 0x040009C4 RID: 2500
	[Token(Token = "0x40009C4")]
	const_9,
	// Token: 0x040009C5 RID: 2501
	[Token(Token = "0x40009C5")]
	const_10,
	// Token: 0x040009C6 RID: 2502
	[Token(Token = "0x40009C6")]
	const_11,
	// Token: 0x040009C7 RID: 2503
	[Token(Token = "0x40009C7")]
	const_12,
	// Token: 0x040009C8 RID: 2504
	[Token(Token = "0x40009C8")]
	const_13,
	// Token: 0x040009C9 RID: 2505
	[Token(Token = "0x40009C9")]
	const_14,
	// Token: 0x040009CA RID: 2506
	[Token(Token = "0x40009CA")]
	const_15,
	// Token: 0x040009CB RID: 2507
	[Token(Token = "0x40009CB")]
	const_16,
	// Token: 0x040009CC RID: 2508
	[Token(Token = "0x40009CC")]
	const_17
}
