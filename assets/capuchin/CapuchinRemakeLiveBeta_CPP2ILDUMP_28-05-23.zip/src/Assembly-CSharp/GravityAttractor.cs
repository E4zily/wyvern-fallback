﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000035 RID: 53
[Token(Token = "0x2000035")]
public class GravityAttractor : MonoBehaviour
{
	// Token: 0x0600064B RID: 1611 RVA: 0x000101D8 File Offset: 0x0000E3D8
	[Token(Token = "0x600064B")]
	[Address(RVA = "0x34FEE70", Offset = "0x34FEE70", VA = "0x34FEE70")]
	public void method_0(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x600064C")]
	[Address(RVA = "0x34FF038", Offset = "0x34FF038", VA = "0x34FF038")]
	public void method_1(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x34FF200", Offset = "0x34FF200", VA = "0x34FF200")]
	[Token(Token = "0x600064D")]
	public void method_2(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x34FF3C8", Offset = "0x34FF3C8", VA = "0x34FF3C8")]
	[Token(Token = "0x600064E")]
	public void method_3(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x600064F")]
	[Address(RVA = "0x34FF590", Offset = "0x34FF590", VA = "0x34FF590")]
	public void method_4(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x00010268 File Offset: 0x0000E468
	[Address(RVA = "0x34FF758", Offset = "0x34FF758", VA = "0x34FF758")]
	[Token(Token = "0x6000650")]
	public void method_5(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Transform transform;
		Vector3 up = transform.up;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000651")]
	[Address(RVA = "0x34FF920", Offset = "0x34FF920", VA = "0x34FF920")]
	public void method_6(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x0001029C File Offset: 0x0000E49C
	[Token(Token = "0x6000652")]
	[Address(RVA = "0x34FFAE8", Offset = "0x34FFAE8", VA = "0x34FFAE8")]
	public void method_7(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Transform transform;
		Vector3 normalized = transform.position.normalized;
		Transform transform2;
		Vector3 up = transform2.up;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000653")]
	[Address(RVA = "0x34FFCB0", Offset = "0x34FFCB0", VA = "0x34FFCB0")]
	public void method_8(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x00010268 File Offset: 0x0000E468
	[Token(Token = "0x6000654")]
	[Address(RVA = "0x34FFE78", Offset = "0x34FFE78", VA = "0x34FFE78")]
	public void method_9(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Transform transform;
		Vector3 up = transform.up;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000655 RID: 1621 RVA: 0x000102CC File Offset: 0x0000E4CC
	[Token(Token = "0x6000655")]
	[Address(RVA = "0x3500040", Offset = "0x3500040", VA = "0x3500040")]
	public void method_10(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Transform transform;
		Vector3 normalized = transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000656")]
	[Address(RVA = "0x3500208", Offset = "0x3500208", VA = "0x3500208")]
	public void method_11(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x35003D0", Offset = "0x35003D0", VA = "0x35003D0")]
	[Token(Token = "0x6000657")]
	public void method_12(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000658")]
	[Address(RVA = "0x3500598", Offset = "0x3500598", VA = "0x3500598")]
	public void method_13(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000659")]
	[Address(RVA = "0x3500760", Offset = "0x3500760", VA = "0x3500760")]
	public void method_14(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3500928", Offset = "0x3500928", VA = "0x3500928")]
	[Token(Token = "0x600065A")]
	public void method_15(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600065B RID: 1627 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3500AE8", Offset = "0x3500AE8", VA = "0x3500AE8")]
	[Token(Token = "0x600065B")]
	public void method_16(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600065C RID: 1628 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3500CB0", Offset = "0x3500CB0", VA = "0x3500CB0")]
	[Token(Token = "0x600065C")]
	public void method_17(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600065D RID: 1629 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3500E78", Offset = "0x3500E78", VA = "0x3500E78")]
	[Token(Token = "0x600065D")]
	public void method_18(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3501040", Offset = "0x3501040", VA = "0x3501040")]
	[Token(Token = "0x600065E")]
	public void method_19(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600065F RID: 1631 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x600065F")]
	[Address(RVA = "0x3501208", Offset = "0x3501208", VA = "0x3501208")]
	public void method_20(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000660 RID: 1632 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x35013D0", Offset = "0x35013D0", VA = "0x35013D0")]
	[Token(Token = "0x6000660")]
	public void method_21(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000661 RID: 1633 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3501598", Offset = "0x3501598", VA = "0x3501598")]
	[Token(Token = "0x6000661")]
	public void method_22(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x0001030C File Offset: 0x0000E50C
	[Address(RVA = "0x3501760", Offset = "0x3501760", VA = "0x3501760")]
	[Token(Token = "0x6000662")]
	public void method_23(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3501928", Offset = "0x3501928", VA = "0x3501928")]
	[Token(Token = "0x6000663")]
	public void method_24(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3501AF0", Offset = "0x3501AF0", VA = "0x3501AF0")]
	[Token(Token = "0x6000664")]
	public void method_25(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000665 RID: 1637 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000665")]
	[Address(RVA = "0x3501CB8", Offset = "0x3501CB8", VA = "0x3501CB8")]
	public void method_26(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000666 RID: 1638 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000666")]
	[Address(RVA = "0x3501E80", Offset = "0x3501E80", VA = "0x3501E80")]
	public void method_27(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000667 RID: 1639 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x3502048", Offset = "0x3502048", VA = "0x3502048")]
	[Token(Token = "0x6000667")]
	public void method_28(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000668 RID: 1640 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000668")]
	[Address(RVA = "0x3502210", Offset = "0x3502210", VA = "0x3502210")]
	public void method_29(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000669 RID: 1641 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x35023D8", Offset = "0x35023D8", VA = "0x35023D8")]
	[Token(Token = "0x6000669")]
	public void method_30(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600066A RID: 1642 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x35025A0", Offset = "0x35025A0", VA = "0x35025A0")]
	[Token(Token = "0x600066A")]
	public void method_31(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600066B RID: 1643 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x600066B")]
	[Address(RVA = "0x3502768", Offset = "0x3502768", VA = "0x3502768")]
	public void method_32(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600066C RID: 1644 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x600066C")]
	[Address(RVA = "0x3502930", Offset = "0x3502930", VA = "0x3502930")]
	public void method_33(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600066D RID: 1645 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x600066D")]
	[Address(RVA = "0x3502AF8", Offset = "0x3502AF8", VA = "0x3502AF8")]
	public void method_34(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600066E RID: 1646 RVA: 0x00010354 File Offset: 0x0000E554
	[Token(Token = "0x600066E")]
	[Address(RVA = "0x3502CC0", Offset = "0x3502CC0", VA = "0x3502CC0")]
	public void method_35(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x600066F")]
	[Address(RVA = "0x3502E88", Offset = "0x3502E88", VA = "0x3502E88")]
	public void method_36(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000670")]
	[Address(RVA = "0x3503050", Offset = "0x3503050", VA = "0x3503050")]
	public void method_37(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000671")]
	[Address(RVA = "0x3503218", Offset = "0x3503218", VA = "0x3503218")]
	public GravityAttractor()
	{
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x350322C", Offset = "0x350322C", VA = "0x350322C")]
	[Token(Token = "0x6000672")]
	public void method_38(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x35033F4", Offset = "0x35033F4", VA = "0x35033F4")]
	[Token(Token = "0x6000673")]
	public void method_39(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x00010220 File Offset: 0x0000E420
	[Address(RVA = "0x35035BC", Offset = "0x35035BC", VA = "0x35035BC")]
	[Token(Token = "0x6000674")]
	public void method_40(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x00010220 File Offset: 0x0000E420
	[Token(Token = "0x6000675")]
	[Address(RVA = "0x3503784", Offset = "0x3503784", VA = "0x3503784")]
	public void method_41(Rigidbody rigidbody_0)
	{
		Vector3 position = rigidbody_0.position;
		Vector3 normalized = base.transform.position.normalized;
		Vector3 up = rigidbody_0.transform.up;
		Quaternion rotation = rigidbody_0.rotation;
		Quaternion rotation2 = rigidbody_0.rotation;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x040000F3 RID: 243
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000F3")]
	public float float_0;
}
