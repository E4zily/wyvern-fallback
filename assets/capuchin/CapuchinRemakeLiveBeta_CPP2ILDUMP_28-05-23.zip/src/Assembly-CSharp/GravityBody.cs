﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000036 RID: 54
[Token(Token = "0x2000036")]
public class GravityBody : MonoBehaviour
{
	// Token: 0x06000676 RID: 1654 RVA: 0x00010394 File Offset: 0x0000E594
	[Address(RVA = "0x350394C", Offset = "0x350394C", VA = "0x350394C")]
	[Token(Token = "0x6000676")]
	private void method_0()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x000103C0 File Offset: 0x0000E5C0
	[Token(Token = "0x6000677")]
	[Address(RVA = "0x35039B0", Offset = "0x35039B0", VA = "0x35039B0")]
	private void method_1()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)40;
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x000103F8 File Offset: 0x0000E5F8
	[Token(Token = "0x6000678")]
	[Address(RVA = "0x3503A14", Offset = "0x3503A14", VA = "0x3503A14")]
	private void method_2()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_15(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x00010448 File Offset: 0x0000E648
	[Token(Token = "0x6000679")]
	[Address(RVA = "0x3503AEC", Offset = "0x3503AEC", VA = "0x3503AEC")]
	private void method_3()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_10(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x00010498 File Offset: 0x0000E698
	[Address(RVA = "0x3503BC0", Offset = "0x3503BC0", VA = "0x3503BC0")]
	[Token(Token = "0x600067A")]
	private void method_4()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x000104C4 File Offset: 0x0000E6C4
	[Address(RVA = "0x3503C24", Offset = "0x3503C24", VA = "0x3503C24")]
	[Token(Token = "0x600067B")]
	private void method_5()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_18(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x00010498 File Offset: 0x0000E698
	[Token(Token = "0x600067C")]
	[Address(RVA = "0x3503CFC", Offset = "0x3503CFC", VA = "0x3503CFC")]
	private void method_6()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x00010514 File Offset: 0x0000E714
	[Token(Token = "0x600067D")]
	[Address(RVA = "0x3503D60", Offset = "0x3503D60", VA = "0x3503D60")]
	private void method_7()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x00010550 File Offset: 0x0000E750
	[Address(RVA = "0x3503E38", Offset = "0x3503E38", VA = "0x3503E38")]
	[Token(Token = "0x600067E")]
	private void method_8()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_37(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x00010498 File Offset: 0x0000E698
	[Token(Token = "0x600067F")]
	[Address(RVA = "0x3503F08", Offset = "0x3503F08", VA = "0x3503F08")]
	private void method_9()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x000105A0 File Offset: 0x0000E7A0
	[Token(Token = "0x6000680")]
	[Address(RVA = "0x3503F6C", Offset = "0x3503F6C", VA = "0x3503F6C")]
	private void method_10()
	{
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3504040", Offset = "0x3504040", VA = "0x3504040")]
	[Token(Token = "0x6000681")]
	public GravityBody()
	{
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3504048", Offset = "0x3504048", VA = "0x3504048")]
	[Token(Token = "0x6000682")]
	private void method_11()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000683 RID: 1667 RVA: 0x000105B0 File Offset: 0x0000E7B0
	[Token(Token = "0x6000683")]
	[Address(RVA = "0x3504118", Offset = "0x3504118", VA = "0x3504118")]
	private void method_12()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_14(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x00010600 File Offset: 0x0000E800
	[Token(Token = "0x6000684")]
	[Address(RVA = "0x35041F0", Offset = "0x35041F0", VA = "0x35041F0")]
	private void method_13()
	{
		bool enabled = this.gravityBody_0.enabled;
	}

	// Token: 0x06000685 RID: 1669 RVA: 0x0001061C File Offset: 0x0000E81C
	[Address(RVA = "0x3504254", Offset = "0x3504254", VA = "0x3504254")]
	[Token(Token = "0x6000685")]
	private void method_14()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_4(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000686 RID: 1670 RVA: 0x0001066C File Offset: 0x0000E86C
	[Address(RVA = "0x350432C", Offset = "0x350432C", VA = "0x350432C")]
	[Token(Token = "0x6000686")]
	private void method_15()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_25(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x000106BC File Offset: 0x0000E8BC
	[Address(RVA = "0x3504404", Offset = "0x3504404", VA = "0x3504404")]
	[Token(Token = "0x6000687")]
	private void method_16()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_24(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x0001070C File Offset: 0x0000E90C
	[Token(Token = "0x6000688")]
	[Address(RVA = "0x35044D8", Offset = "0x35044D8", VA = "0x35044D8")]
	private void method_17()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_23(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x0001075C File Offset: 0x0000E95C
	[Token(Token = "0x6000689")]
	[Address(RVA = "0x35045B0", Offset = "0x35045B0", VA = "0x35045B0")]
	private void method_18()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)110;
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x00010794 File Offset: 0x0000E994
	[Token(Token = "0x600068A")]
	[Address(RVA = "0x3504614", Offset = "0x3504614", VA = "0x3504614")]
	private void method_19()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)27;
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x00010394 File Offset: 0x0000E594
	[Address(RVA = "0x3504678", Offset = "0x3504678", VA = "0x3504678")]
	[Token(Token = "0x600068B")]
	private void method_20()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x000103F8 File Offset: 0x0000E5F8
	[Address(RVA = "0x35046DC", Offset = "0x35046DC", VA = "0x35046DC")]
	[Token(Token = "0x600068C")]
	private void FixedUpdate()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_15(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x000107CC File Offset: 0x0000E9CC
	[Token(Token = "0x600068D")]
	[Address(RVA = "0x35047B4", Offset = "0x35047B4", VA = "0x35047B4")]
	private void method_21()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x00010808 File Offset: 0x0000EA08
	[Token(Token = "0x600068E")]
	[Address(RVA = "0x350488C", Offset = "0x350488C", VA = "0x350488C")]
	private void method_22()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)59;
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x00010840 File Offset: 0x0000EA40
	[Address(RVA = "0x35048F0", Offset = "0x35048F0", VA = "0x35048F0")]
	[Token(Token = "0x600068F")]
	private void method_23()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_9(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x00010890 File Offset: 0x0000EA90
	[Address(RVA = "0x35049C4", Offset = "0x35049C4", VA = "0x35049C4")]
	[Token(Token = "0x6000690")]
	private void method_24()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_15(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x000108E0 File Offset: 0x0000EAE0
	[Token(Token = "0x6000691")]
	[Address(RVA = "0x3504A94", Offset = "0x3504A94", VA = "0x3504A94")]
	private void method_25()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_14(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x000104C4 File Offset: 0x0000E6C4
	[Token(Token = "0x6000692")]
	[Address(RVA = "0x3504B68", Offset = "0x3504B68", VA = "0x3504B68")]
	private void method_26()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_18(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000693 RID: 1683 RVA: 0x00010930 File Offset: 0x0000EB30
	[Address(RVA = "0x3504C40", Offset = "0x3504C40", VA = "0x3504C40")]
	[Token(Token = "0x6000693")]
	private void method_27()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_12(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x00010980 File Offset: 0x0000EB80
	[Address(RVA = "0x3504D18", Offset = "0x3504D18", VA = "0x3504D18")]
	[Token(Token = "0x6000694")]
	private void method_28()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)9;
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x00010498 File Offset: 0x0000E698
	[Token(Token = "0x6000695")]
	[Address(RVA = "0x3504D7C", Offset = "0x3504D7C", VA = "0x3504D7C")]
	private void method_29()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x00010600 File Offset: 0x0000E800
	[Token(Token = "0x6000696")]
	[Address(RVA = "0x3504DE0", Offset = "0x3504DE0", VA = "0x3504DE0")]
	private void method_30()
	{
		bool enabled = this.gravityBody_0.enabled;
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x000109B8 File Offset: 0x0000EBB8
	[Address(RVA = "0x3504E44", Offset = "0x3504E44", VA = "0x3504E44")]
	[Token(Token = "0x6000697")]
	private void method_31()
	{
		bool enabled = base.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x000109DC File Offset: 0x0000EBDC
	[Token(Token = "0x6000698")]
	[Address(RVA = "0x3504EA8", Offset = "0x3504EA8", VA = "0x3504EA8")]
	private void method_32()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)98;
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x00010498 File Offset: 0x0000E698
	[Address(RVA = "0x3504F0C", Offset = "0x3504F0C", VA = "0x3504F0C")]
	[Token(Token = "0x6000699")]
	private void method_33()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x00010A14 File Offset: 0x0000EC14
	[Token(Token = "0x600069A")]
	[Address(RVA = "0x3504F70", Offset = "0x3504F70", VA = "0x3504F70")]
	private void method_34()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_41(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600069B RID: 1691 RVA: 0x00010A64 File Offset: 0x0000EC64
	[Token(Token = "0x600069B")]
	[Address(RVA = "0x3505048", Offset = "0x3505048", VA = "0x3505048")]
	private void method_35()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_9(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
	}

	// Token: 0x0600069C RID: 1692 RVA: 0x00010AA0 File Offset: 0x0000ECA0
	[Address(RVA = "0x3505120", Offset = "0x3505120", VA = "0x3505120")]
	[Token(Token = "0x600069C")]
	private void method_36()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_31(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x00010394 File Offset: 0x0000E594
	[Address(RVA = "0x35051F4", Offset = "0x35051F4", VA = "0x35051F4")]
	[Token(Token = "0x600069D")]
	private void method_37()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x00010AF0 File Offset: 0x0000ECF0
	[Token(Token = "0x600069E")]
	[Address(RVA = "0x3505258", Offset = "0x3505258", VA = "0x3505258")]
	private void method_38()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_1(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x00010B40 File Offset: 0x0000ED40
	[Address(RVA = "0x350532C", Offset = "0x350532C", VA = "0x350532C")]
	[Token(Token = "0x600069F")]
	private void method_39()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_4(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x00010B90 File Offset: 0x0000ED90
	[Token(Token = "0x60006A0")]
	[Address(RVA = "0x35053FC", Offset = "0x35053FC", VA = "0x35053FC")]
	private void method_40()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_36(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x00010BE0 File Offset: 0x0000EDE0
	[Token(Token = "0x60006A1")]
	[Address(RVA = "0x35054D4", Offset = "0x35054D4", VA = "0x35054D4")]
	private void method_41()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_41(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x00010C30 File Offset: 0x0000EE30
	[Address(RVA = "0x35055A4", Offset = "0x35055A4", VA = "0x35055A4")]
	[Token(Token = "0x60006A2")]
	private void method_42()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)43;
	}

	// Token: 0x060006A3 RID: 1699 RVA: 0x00010C68 File Offset: 0x0000EE68
	[Address(RVA = "0x3505608", Offset = "0x3505608", VA = "0x3505608")]
	[Token(Token = "0x60006A3")]
	private void method_43()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_39(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A4 RID: 1700 RVA: 0x00010394 File Offset: 0x0000E594
	[Address(RVA = "0x35056D8", Offset = "0x35056D8", VA = "0x35056D8")]
	[Token(Token = "0x60006A4")]
	private void method_44()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A5 RID: 1701 RVA: 0x00010CB8 File Offset: 0x0000EEB8
	[Address(RVA = "0x350573C", Offset = "0x350573C", VA = "0x350573C")]
	[Token(Token = "0x60006A5")]
	private void method_45()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)36;
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x00010CF0 File Offset: 0x0000EEF0
	[Address(RVA = "0x35057A0", Offset = "0x35057A0", VA = "0x35057A0")]
	[Token(Token = "0x60006A6")]
	private void method_46()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_7(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x00010498 File Offset: 0x0000E698
	[Token(Token = "0x60006A7")]
	[Address(RVA = "0x3505870", Offset = "0x3505870", VA = "0x3505870")]
	private void method_47()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x00010D40 File Offset: 0x0000EF40
	[Token(Token = "0x60006A8")]
	[Address(RVA = "0x35058D4", Offset = "0x35058D4", VA = "0x35058D4")]
	private void method_48()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_38(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x00010394 File Offset: 0x0000E594
	[Token(Token = "0x60006A9")]
	[Address(RVA = "0x35059AC", Offset = "0x35059AC", VA = "0x35059AC")]
	private void method_49()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x00010394 File Offset: 0x0000E594
	[Token(Token = "0x60006AA")]
	[Address(RVA = "0x3505A10", Offset = "0x3505A10", VA = "0x3505A10")]
	private void method_50()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006AB RID: 1707 RVA: 0x00010D90 File Offset: 0x0000EF90
	[Address(RVA = "0x3505A74", Offset = "0x3505A74", VA = "0x3505A74")]
	[Token(Token = "0x60006AB")]
	private void method_51()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_15(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x00010DE0 File Offset: 0x0000EFE0
	[Address(RVA = "0x3505B44", Offset = "0x3505B44", VA = "0x3505B44")]
	[Token(Token = "0x60006AC")]
	private void method_52()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_5(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x00010E30 File Offset: 0x0000F030
	[Token(Token = "0x60006AD")]
	[Address(RVA = "0x3505C1C", Offset = "0x3505C1C", VA = "0x3505C1C")]
	private void method_53()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_7(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006AE RID: 1710 RVA: 0x00010E80 File Offset: 0x0000F080
	[Token(Token = "0x60006AE")]
	[Address(RVA = "0x3505CF4", Offset = "0x3505CF4", VA = "0x3505CF4")]
	private void method_54()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)123;
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x00010EB8 File Offset: 0x0000F0B8
	[Token(Token = "0x60006AF")]
	[Address(RVA = "0x3505D58", Offset = "0x3505D58", VA = "0x3505D58")]
	private void method_55()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_0(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x00010F08 File Offset: 0x0000F108
	[Token(Token = "0x60006B0")]
	[Address(RVA = "0x3505E28", Offset = "0x3505E28", VA = "0x3505E28")]
	private void method_56()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_8(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x00010F58 File Offset: 0x0000F158
	[Address(RVA = "0x3505EFC", Offset = "0x3505EFC", VA = "0x3505EFC")]
	[Token(Token = "0x60006B1")]
	private void method_57()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)27;
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x00010498 File Offset: 0x0000E698
	[Token(Token = "0x60006B2")]
	[Address(RVA = "0x3505F60", Offset = "0x3505F60", VA = "0x3505F60")]
	private void method_58()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00010F90 File Offset: 0x0000F190
	[Token(Token = "0x60006B3")]
	[Address(RVA = "0x3505FC4", Offset = "0x3505FC4", VA = "0x3505FC4")]
	private void method_59()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_39(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x00010600 File Offset: 0x0000E800
	[Token(Token = "0x60006B4")]
	[Address(RVA = "0x350609C", Offset = "0x350609C", VA = "0x350609C")]
	private void method_60()
	{
		bool enabled = this.gravityBody_0.enabled;
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x00010FE0 File Offset: 0x0000F1E0
	[Token(Token = "0x60006B5")]
	[Address(RVA = "0x3506100", Offset = "0x3506100", VA = "0x3506100")]
	private void method_61()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_22(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x00010394 File Offset: 0x0000E594
	[Address(RVA = "0x35061D4", Offset = "0x35061D4", VA = "0x35061D4")]
	[Token(Token = "0x60006B6")]
	private void method_62()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x00010394 File Offset: 0x0000E594
	[Address(RVA = "0x3506238", Offset = "0x3506238", VA = "0x3506238")]
	[Token(Token = "0x60006B7")]
	private void method_63()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x00011030 File Offset: 0x0000F230
	[Address(RVA = "0x350629C", Offset = "0x350629C", VA = "0x350629C")]
	[Token(Token = "0x60006B8")]
	private void method_64()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_39(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x000104C4 File Offset: 0x0000E6C4
	[Address(RVA = "0x350636C", Offset = "0x350636C", VA = "0x350636C")]
	[Token(Token = "0x60006B9")]
	private void method_65()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_18(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x00010394 File Offset: 0x0000E594
	[Address(RVA = "0x3506444", Offset = "0x3506444", VA = "0x3506444")]
	[Token(Token = "0x60006BA")]
	private void method_66()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x00011080 File Offset: 0x0000F280
	[Address(RVA = "0x35064A8", Offset = "0x35064A8", VA = "0x35064A8")]
	[Token(Token = "0x60006BB")]
	private void method_67()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_11(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x000110D0 File Offset: 0x0000F2D0
	[Token(Token = "0x60006BC")]
	[Address(RVA = "0x3506580", Offset = "0x3506580", VA = "0x3506580")]
	private void method_68()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_19(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006BD RID: 1725 RVA: 0x00011120 File Offset: 0x0000F320
	[Address(RVA = "0x3506650", Offset = "0x3506650", VA = "0x3506650")]
	[Token(Token = "0x60006BD")]
	private void method_69()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)18;
	}

	// Token: 0x060006BE RID: 1726 RVA: 0x00011158 File Offset: 0x0000F358
	[Token(Token = "0x60006BE")]
	[Address(RVA = "0x35066B4", Offset = "0x35066B4", VA = "0x35066B4")]
	private void method_70()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_13(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x000111A8 File Offset: 0x0000F3A8
	[Token(Token = "0x60006BF")]
	[Address(RVA = "0x3506788", Offset = "0x3506788", VA = "0x3506788")]
	private void method_71()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_7(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		base.GetComponent<Rigidbody>();
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x00010394 File Offset: 0x0000E594
	[Token(Token = "0x60006C0")]
	[Address(RVA = "0x3506858", Offset = "0x3506858", VA = "0x3506858")]
	private void method_72()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x000111F4 File Offset: 0x0000F3F4
	[Token(Token = "0x60006C1")]
	[Address(RVA = "0x35068BC", Offset = "0x35068BC", VA = "0x35068BC")]
	private void method_73()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_35(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x00011244 File Offset: 0x0000F444
	[Token(Token = "0x60006C2")]
	[Address(RVA = "0x3506994", Offset = "0x3506994", VA = "0x3506994")]
	private void method_74()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)81;
	}

	// Token: 0x060006C3 RID: 1731 RVA: 0x00010394 File Offset: 0x0000E594
	[Token(Token = "0x60006C3")]
	[Address(RVA = "0x35069F8", Offset = "0x35069F8", VA = "0x35069F8")]
	private void method_75()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 1L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006C4 RID: 1732 RVA: 0x0001127C File Offset: 0x0000F47C
	[Address(RVA = "0x3506A5C", Offset = "0x3506A5C", VA = "0x3506A5C")]
	[Token(Token = "0x60006C4")]
	private void method_76()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_27(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x000112CC File Offset: 0x0000F4CC
	[Token(Token = "0x60006C5")]
	[Address(RVA = "0x3506B30", Offset = "0x3506B30", VA = "0x3506B30")]
	private void method_77()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
		this.rigidbody_0.constraints = (RigidbodyConstraints)9;
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x00010498 File Offset: 0x0000E698
	[Token(Token = "0x60006C6")]
	[Address(RVA = "0x3506B94", Offset = "0x3506B94", VA = "0x3506B94")]
	private void Start()
	{
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody rigidbody = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody.useGravity = (useGravity != 0L);
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x00011304 File Offset: 0x0000F504
	[Address(RVA = "0x3506BF8", Offset = "0x3506BF8", VA = "0x3506BF8")]
	[Token(Token = "0x60006C7")]
	private void method_78()
	{
		GravityAttractor gravityAttractor = this.gravityAttractor_0;
		Rigidbody rigidbody = this.rigidbody_0;
		gravityAttractor.method_13(rigidbody);
		bool enabled = this.gravityBody_0.enabled;
		Rigidbody component = base.GetComponent<Rigidbody>();
		this.rigidbody_0 = component;
		Rigidbody rigidbody2 = this.rigidbody_0;
		long useGravity = 0L;
		rigidbody2.useGravity = (useGravity != 0L);
	}

	// Token: 0x040000F4 RID: 244
	[Token(Token = "0x40000F4")]
	[FieldOffset(Offset = "0x18")]
	public GravityAttractor gravityAttractor_0;

	// Token: 0x040000F5 RID: 245
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000F5")]
	public Rigidbody rigidbody_0;

	// Token: 0x040000F6 RID: 246
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40000F6")]
	public GravityBody gravityBody_0;

	// Token: 0x040000F7 RID: 247
	[Token(Token = "0x40000F7")]
	[FieldOffset(Offset = "0x30")]
	public bool bool_0;
}
