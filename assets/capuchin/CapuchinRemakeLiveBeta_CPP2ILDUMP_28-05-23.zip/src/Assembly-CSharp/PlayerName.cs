﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x0200003B RID: 59
[Token(Token = "0x200003B")]
public class PlayerName : MonoBehaviour
{
	// Token: 0x06000789 RID: 1929 RVA: 0x00011DF0 File Offset: 0x0000FFF0
	[Token(Token = "0x6000789")]
	[Address(RVA = "0x2A78968", Offset = "0x2A78968", VA = "0x2A78968")]
	private void method_0()
	{
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x00011DF0 File Offset: 0x0000FFF0
	[Address(RVA = "0x2A789A4", Offset = "0x2A789A4", VA = "0x2A789A4")]
	[Token(Token = "0x600078A")]
	private void method_1()
	{
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x00011E00 File Offset: 0x00010000
	[Address(RVA = "0x2A789E0", Offset = "0x2A789E0", VA = "0x2A789E0")]
	[Token(Token = "0x600078B")]
	private void method_2()
	{
		this.method_7();
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x00011E14 File Offset: 0x00010014
	[Address(RVA = "0x2A78A84", Offset = "0x2A78A84", VA = "0x2A78A84")]
	[Token(Token = "0x600078C")]
	private void method_3()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			PlayerPrefs.HasKey("Key");
			return;
		}
		this.method_0();
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x00011E40 File Offset: 0x00010040
	[Token(Token = "0x600078D")]
	[Address(RVA = "0x2A78C44", Offset = "0x2A78C44", VA = "0x2A78C44")]
	private void Update()
	{
		this.method_1();
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x00011E54 File Offset: 0x00010054
	[Address(RVA = "0x2A78CAC", Offset = "0x2A78CAC", VA = "0x2A78CAC")]
	[Token(Token = "0x600078E")]
	private void method_4()
	{
		this.method_11();
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x00011E40 File Offset: 0x00010040
	[Address(RVA = "0x2A78D50", Offset = "0x2A78D50", VA = "0x2A78D50")]
	[Token(Token = "0x600078F")]
	private void method_5()
	{
		this.method_1();
	}

	// Token: 0x06000790 RID: 1936 RVA: 0x00011E68 File Offset: 0x00010068
	[Token(Token = "0x6000790")]
	[Address(RVA = "0x2A78DB8", Offset = "0x2A78DB8", VA = "0x2A78DB8")]
	private void method_6()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			PlayerPrefs.HasKey("A Player has left the Room.");
			return;
		}
		this.method_0();
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x00011DF0 File Offset: 0x0000FFF0
	[Address(RVA = "0x2A78A48", Offset = "0x2A78A48", VA = "0x2A78A48")]
	[Token(Token = "0x6000791")]
	private void method_7()
	{
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x00011E40 File Offset: 0x00010040
	[Address(RVA = "0x2A78F78", Offset = "0x2A78F78", VA = "0x2A78F78")]
	[Token(Token = "0x6000792")]
	private void method_8()
	{
		this.method_1();
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x00011E94 File Offset: 0x00010094
	[Token(Token = "0x6000793")]
	[Address(RVA = "0x2A78FE0", Offset = "0x2A78FE0", VA = "0x2A78FE0")]
	private void method_9()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			PlayerPrefs.HasKey("Diffuse");
			return;
		}
		this.method_0();
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x00011EC0 File Offset: 0x000100C0
	[Token(Token = "0x6000794")]
	[Address(RVA = "0x2A791A0", Offset = "0x2A791A0", VA = "0x2A791A0")]
	private void method_10()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			PlayerPrefs.HasKey("PlayWave");
			return;
		}
		this.method_7();
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x00011DF0 File Offset: 0x0000FFF0
	[Address(RVA = "0x2A78D14", Offset = "0x2A78D14", VA = "0x2A78D14")]
	[Token(Token = "0x6000795")]
	private void method_11()
	{
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x00011EEC File Offset: 0x000100EC
	[Token(Token = "0x6000796")]
	[Address(RVA = "0x2A79360", Offset = "0x2A79360", VA = "0x2A79360")]
	private void method_12()
	{
		this.method_0();
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A793C8", Offset = "0x2A793C8", VA = "0x2A793C8")]
	[Token(Token = "0x6000797")]
	public PlayerName()
	{
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x00011F00 File Offset: 0x00010100
	[Address(RVA = "0x2A793D0", Offset = "0x2A793D0", VA = "0x2A793D0")]
	[Token(Token = "0x6000798")]
	private void method_13()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			PlayerPrefs.HasKey("You have been banned for ");
			return;
		}
		this.method_11();
	}

	// Token: 0x06000799 RID: 1945 RVA: 0x00011EEC File Offset: 0x000100EC
	[Token(Token = "0x6000799")]
	[Address(RVA = "0x2A79590", Offset = "0x2A79590", VA = "0x2A79590")]
	private void method_14()
	{
		this.method_0();
	}

	// Token: 0x0600079A RID: 1946 RVA: 0x00011F2C File Offset: 0x0001012C
	[Token(Token = "0x600079A")]
	[Address(RVA = "0x2A795F8", Offset = "0x2A795F8", VA = "0x2A795F8")]
	private void method_15()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			PlayerPrefs.HasKey("\n");
			return;
		}
		this.method_11();
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x00011E40 File Offset: 0x00010040
	[Token(Token = "0x600079B")]
	[Address(RVA = "0x2A797B8", Offset = "0x2A797B8", VA = "0x2A797B8")]
	private void method_16()
	{
		this.method_1();
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x00011F58 File Offset: 0x00010158
	[Token(Token = "0x600079C")]
	[Address(RVA = "0x2A79820", Offset = "0x2A79820", VA = "0x2A79820")]
	private void method_17()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			PlayerPrefs.HasKey("Downloading image");
			return;
		}
		this.method_1();
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x00011F84 File Offset: 0x00010184
	[Address(RVA = "0x2A799E0", Offset = "0x2A799E0", VA = "0x2A799E0")]
	[Token(Token = "0x600079D")]
	private void Start()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			long maxExclusive = 0L;
			PlayerPrefs.HasKey("username");
			int num = UnityEngine.Random.Range(0, (int)maxExclusive);
			long maxExclusive2 = 0L;
			string str = num.ToString();
			string str2 = UnityEngine.Random.Range(0, (int)maxExclusive2).ToString();
			string str3 = UnityEngine.Random.Range(0, 1000).ToString();
			string value = str + " " + str2 + str3;
			PlayerPrefs.SetString("username", value);
			PhotonNetwork.NickName = PlayerPrefs.GetString("username");
		}
		this.method_1();
	}

	// Token: 0x0400010B RID: 267
	[Token(Token = "0x400010B")]
	[FieldOffset(Offset = "0x18")]
	public PhotonView photonView_0;

	// Token: 0x0400010C RID: 268
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400010C")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x0400010D RID: 269
	[Token(Token = "0x400010D")]
	[FieldOffset(Offset = "0x28")]
	public string[] string_0;

	// Token: 0x0400010E RID: 270
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400010E")]
	public string[] string_1;
}
