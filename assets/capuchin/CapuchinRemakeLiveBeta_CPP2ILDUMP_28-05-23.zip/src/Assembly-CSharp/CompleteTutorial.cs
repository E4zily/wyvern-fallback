﻿using System;
using CapuchinPlayFab;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000026 RID: 38
[Token(Token = "0x2000026")]
public class CompleteTutorial : MonoBehaviour
{
	// Token: 0x060004AB RID: 1195 RVA: 0x0000CD48 File Offset: 0x0000AF48
	[Token(Token = "0x60004AB")]
	[Address(RVA = "0x2A62B5C", Offset = "0x2A62B5C", VA = "0x2A62B5C")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (PlayerPrefs.GetString("HandR") != null)
		{
			return;
		}
		PlayerPrefs.SetString("RightHandAttachPoint", "Room1");
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x0000CD88 File Offset: 0x0000AF88
	[Token(Token = "0x60004AC")]
	[Address(RVA = "0x2A62C34", Offset = "0x2A62C34", VA = "0x2A62C34")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		if (PlayerPrefs.GetString("Found Gameobject: ") != null)
		{
			return;
		}
	}

	// Token: 0x060004AD RID: 1197 RVA: 0x0000CDB8 File Offset: 0x0000AFB8
	[Address(RVA = "0x2A62D0C", Offset = "0x2A62D0C", VA = "0x2A62D0C")]
	[Token(Token = "0x60004AD")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "HandR";
		if (PlayerPrefs.GetString("On") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Photon token acquired!", "Cannot access index {0}. Buffer size is {1}");
	}

	// Token: 0x060004AE RID: 1198 RVA: 0x0000CDF8 File Offset: 0x0000AFF8
	[Address(RVA = "0x2A62DE4", Offset = "0x2A62DE4", VA = "0x2A62DE4")]
	[Token(Token = "0x60004AE")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.tag == "Reason: ";
		if (PlayerPrefs.GetString("liftoff failed!") != null)
		{
			return;
		}
		PlayerPrefs.SetString("BloodKill", "cosmos");
	}

	// Token: 0x060004AF RID: 1199 RVA: 0x0000CE38 File Offset: 0x0000B038
	[Token(Token = "0x60004AF")]
	[Address(RVA = "0x2A62EBC", Offset = "0x2A62EBC", VA = "0x2A62EBC")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "_WobbleX";
		if (PlayerPrefs.GetString("ChangeToTagged") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Player", "forced knee");
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x0000CE78 File Offset: 0x0000B078
	[Token(Token = "0x60004B0")]
	[Address(RVA = "0x2A62F94", Offset = "0x2A62F94", VA = "0x2A62F94")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayWave";
		if (PlayerPrefs.GetString("Camera movement detected, calibrating height.") != null)
		{
			return;
		}
		PlayerPrefs.SetString("User has been reported for: ", "Cannot access index {0}. Buffer size is {1}");
	}

	// Token: 0x060004B1 RID: 1201 RVA: 0x0000CEB8 File Offset: 0x0000B0B8
	[Address(RVA = "0x2A6306C", Offset = "0x2A6306C", VA = "0x2A6306C")]
	[Token(Token = "0x60004B1")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "unstuck";
		if (PlayerPrefs.GetString("Player") != null)
		{
			return;
		}
		PlayerPrefs.SetString("containsStaff", "Add/Remove Sword");
	}

	// Token: 0x060004B2 RID: 1202 RVA: 0x0000CEF8 File Offset: 0x0000B0F8
	[Token(Token = "0x60004B2")]
	[Address(RVA = "0x2A63144", Offset = "0x2A63144", VA = "0x2A63144")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		string @string = PlayerPrefs.GetString("");
		if (@string != null)
		{
			return;
		}
		PlayerPrefs.SetString(@string, "Connected to Server.");
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x0000CF38 File Offset: 0x0000B138
	[Token(Token = "0x60004B3")]
	[Address(RVA = "0x2A6321C", Offset = "0x2A6321C", VA = "0x2A6321C")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "isLava";
		if (PlayerPrefs.GetString("Adding ") != null)
		{
			return;
		}
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x0000CF68 File Offset: 0x0000B168
	[Token(Token = "0x60004B4")]
	[Address(RVA = "0x2A632F4", Offset = "0x2A632F4", VA = "0x2A632F4")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "We don't need this electrical box";
		if (PlayerPrefs.GetString("containsStaff") != null)
		{
			return;
		}
		PlayerPrefs.SetString("TurnAmount", " and for the price of ");
	}

	// Token: 0x060004B5 RID: 1205 RVA: 0x0000CFA8 File Offset: 0x0000B1A8
	[Token(Token = "0x60004B5")]
	[Address(RVA = "0x2A633CC", Offset = "0x2A633CC", VA = "0x2A633CC")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "sound play play";
		if (PlayerPrefs.GetString("Left Hand") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Head", "BN");
	}

	// Token: 0x060004B6 RID: 1206 RVA: 0x0000CFE8 File Offset: 0x0000B1E8
	[Address(RVA = "0x2A634A4", Offset = "0x2A634A4", VA = "0x2A634A4")]
	[Token(Token = "0x60004B6")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "retract broken";
		if (PlayerPrefs.GetString("Grip") != null)
		{
			return;
		}
		PlayerPrefs.SetString("closeToObject", "BN");
	}

	// Token: 0x060004B7 RID: 1207 RVA: 0x0000D028 File Offset: 0x0000B228
	[Address(RVA = "0x2A6357C", Offset = "0x2A6357C", VA = "0x2A6357C")]
	[Token(Token = "0x60004B7")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		if (PlayerPrefs.GetString("PURCHASED!") != null)
		{
			return;
		}
		PlayerPrefs.SetString("containsStaff", "Player");
	}

	// Token: 0x060004B8 RID: 1208 RVA: 0x0000D068 File Offset: 0x0000B268
	[Token(Token = "0x60004B8")]
	[Address(RVA = "0x2A63640", Offset = "0x2A63640", VA = "0x2A63640")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		if (PlayerPrefs.GetString("tutorialCheck") != null)
		{
			return;
		}
		PlayerPrefs.SetString("tutorialCheck", "true");
	}

	// Token: 0x060004B9 RID: 1209 RVA: 0x0000D0A8 File Offset: 0x0000B2A8
	[Token(Token = "0x60004B9")]
	[Address(RVA = "0x2A63704", Offset = "0x2A63704", VA = "0x2A63704")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "QuickStatic";
		if (PlayerPrefs.GetString("{0}/{1:f0}") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Add/Remove Glasses", "HandL");
	}

	// Token: 0x060004BA RID: 1210 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60004BA")]
	[Address(RVA = "0x2A637DC", Offset = "0x2A637DC", VA = "0x2A637DC")]
	public CompleteTutorial()
	{
	}

	// Token: 0x060004BB RID: 1211 RVA: 0x0000D0E8 File Offset: 0x0000B2E8
	[Address(RVA = "0x2A637E4", Offset = "0x2A637E4", VA = "0x2A637E4")]
	[Token(Token = "0x60004BB")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == "Not connected to room";
		if (PlayerPrefs.GetString("ORGTARG") != null)
		{
			return;
		}
		PlayerPrefs.SetString("Purchase For ", "spatial");
	}

	// Token: 0x040000B9 RID: 185
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000B9")]
	public LoginManager loginManager_0;
}
