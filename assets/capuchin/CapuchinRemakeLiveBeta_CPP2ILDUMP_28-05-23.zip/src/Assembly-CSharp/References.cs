﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200000E RID: 14
[Token(Token = "0x200000E")]
public class References : MonoBehaviour
{
	// Token: 0x060001B4 RID: 436 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60001B4")]
	[Address(RVA = "0x3483828", Offset = "0x3483828", VA = "0x3483828")]
	public References()
	{
	}

	// Token: 0x0400003C RID: 60
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400003C")]
	public TagManager tagManager_0;

	// Token: 0x0400003D RID: 61
	[Token(Token = "0x400003D")]
	[FieldOffset(Offset = "0x20")]
	public PhotonView photonView_0;
}
