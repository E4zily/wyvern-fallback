﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000075 RID: 117
[Token(Token = "0x2000075")]
public class InteractableCosmeticCollider : MonoBehaviour
{
	// Token: 0x06001068 RID: 4200 RVA: 0x0001FF60 File Offset: 0x0001E160
	[Address(RVA = "0x311FAC0", Offset = "0x311FAC0", VA = "0x311FAC0")]
	[Token(Token = "0x6001068")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("PlayWave");
	}

	// Token: 0x06001069 RID: 4201 RVA: 0x0001FF88 File Offset: 0x0001E188
	[Token(Token = "0x6001069")]
	[Address(RVA = "0x311FBBC", Offset = "0x311FBBC", VA = "0x311FBBC")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("friend");
	}

	// Token: 0x0600106A RID: 4202 RVA: 0x0001FFB0 File Offset: 0x0001E1B0
	[Address(RVA = "0x311FCB8", Offset = "0x311FCB8", VA = "0x311FCB8")]
	[Token(Token = "0x600106A")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("PlayNoise");
	}

	// Token: 0x0600106B RID: 4203 RVA: 0x0001FFD8 File Offset: 0x0001E1D8
	[Token(Token = "0x600106B")]
	[Address(RVA = "0x311FDB4", Offset = "0x311FDB4", VA = "0x311FDB4")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("typesOfTalk");
	}

	// Token: 0x0600106C RID: 4204 RVA: 0x00020000 File Offset: 0x0001E200
	[Token(Token = "0x600106C")]
	[Address(RVA = "0x311FEB0", Offset = "0x311FEB0", VA = "0x311FEB0")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("Player");
	}

	// Token: 0x0600106D RID: 4205 RVA: 0x00020028 File Offset: 0x0001E228
	[Address(RVA = "0x311FFAC", Offset = "0x311FFAC", VA = "0x311FFAC")]
	[Token(Token = "0x600106D")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("Regular");
	}

	// Token: 0x0600106E RID: 4206 RVA: 0x00020050 File Offset: 0x0001E250
	[Address(RVA = "0x31200A8", Offset = "0x31200A8", VA = "0x31200A8")]
	[Token(Token = "0x600106E")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("You have been banned for ");
	}

	// Token: 0x0600106F RID: 4207 RVA: 0x00020078 File Offset: 0x0001E278
	[Address(RVA = "0x31201A4", Offset = "0x31201A4", VA = "0x31201A4")]
	[Token(Token = "0x600106F")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("_Color");
	}

	// Token: 0x06001070 RID: 4208 RVA: 0x000200A0 File Offset: 0x0001E2A0
	[Address(RVA = "0x31202A0", Offset = "0x31202A0", VA = "0x31202A0")]
	[Token(Token = "0x6001070")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("/");
	}

	// Token: 0x06001071 RID: 4209 RVA: 0x000200C8 File Offset: 0x0001E2C8
	[Token(Token = "0x6001071")]
	[Address(RVA = "0x312039C", Offset = "0x312039C", VA = "0x312039C")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log(" and the correct version is ");
	}

	// Token: 0x06001072 RID: 4210 RVA: 0x000200F0 File Offset: 0x0001E2F0
	[Token(Token = "0x6001072")]
	[Address(RVA = "0x3120498", Offset = "0x3120498", VA = "0x3120498")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("false");
	}

	// Token: 0x06001073 RID: 4211 RVA: 0x00020118 File Offset: 0x0001E318
	[Token(Token = "0x6001073")]
	[Address(RVA = "0x3120594", Offset = "0x3120594", VA = "0x3120594")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("true");
	}

	// Token: 0x06001074 RID: 4212 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3120690", Offset = "0x3120690", VA = "0x3120690")]
	[Token(Token = "0x6001074")]
	public InteractableCosmeticCollider()
	{
	}

	// Token: 0x06001075 RID: 4213 RVA: 0x00020140 File Offset: 0x0001E340
	[Address(RVA = "0x3120698", Offset = "0x3120698", VA = "0x3120698")]
	[Token(Token = "0x6001075")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("HandL");
	}

	// Token: 0x06001076 RID: 4214 RVA: 0x00020168 File Offset: 0x0001E368
	[Token(Token = "0x6001076")]
	[Address(RVA = "0x3120794", Offset = "0x3120794", VA = "0x3120794")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("Room Name: ");
	}

	// Token: 0x06001077 RID: 4215 RVA: 0x00020190 File Offset: 0x0001E390
	[Token(Token = "0x6001077")]
	[Address(RVA = "0x3120890", Offset = "0x3120890", VA = "0x3120890")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("Fire Stick Is Lighting...");
	}

	// Token: 0x06001078 RID: 4216 RVA: 0x000201B8 File Offset: 0x0001E3B8
	[Token(Token = "0x6001078")]
	[Address(RVA = "0x312098C", Offset = "0x312098C", VA = "0x312098C")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("Combine textures & build combined mesh using coroutine");
	}

	// Token: 0x06001079 RID: 4217 RVA: 0x000201E0 File Offset: 0x0001E3E0
	[Address(RVA = "0x3120A88", Offset = "0x3120A88", VA = "0x3120A88")]
	[Token(Token = "0x6001079")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("Squeeze");
	}

	// Token: 0x0600107A RID: 4218 RVA: 0x00020140 File Offset: 0x0001E340
	[Token(Token = "0x600107A")]
	[Address(RVA = "0x3120B84", Offset = "0x3120B84", VA = "0x3120B84")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("HandL");
	}

	// Token: 0x0600107B RID: 4219 RVA: 0x00020208 File Offset: 0x0001E408
	[Token(Token = "0x600107B")]
	[Address(RVA = "0x3120C80", Offset = "0x3120C80", VA = "0x3120C80")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmetic>();
		Debug.Log("");
	}
}
