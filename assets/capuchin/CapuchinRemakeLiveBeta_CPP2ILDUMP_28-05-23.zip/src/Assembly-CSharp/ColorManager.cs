﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

// Token: 0x02000050 RID: 80
[Token(Token = "0x2000050")]
public class ColorManager : MonoBehaviourPunCallbacks
{
	// Token: 0x06000B11 RID: 2833 RVA: 0x000191B4 File Offset: 0x000173B4
	[Address(RVA = "0x2A61318", Offset = "0x2A61318", VA = "0x2A61318")]
	[Token(Token = "0x6000B11")]
	private void method_0()
	{
	}

	// Token: 0x06000B12 RID: 2834 RVA: 0x000191B4 File Offset: 0x000173B4
	[Token(Token = "0x6000B12")]
	[Address(RVA = "0x2A614B8", Offset = "0x2A614B8", VA = "0x2A614B8")]
	private void method_1()
	{
	}

	// Token: 0x06000B13 RID: 2835 RVA: 0x000191C4 File Offset: 0x000173C4
	[Token(Token = "0x6000B13")]
	[Address(RVA = "0x2A61654", Offset = "0x2A61654", VA = "0x2A61654")]
	public ColorManager()
	{
		float[] array = new float[3];
		this.float_0 = array;
		base..ctor();
	}

	// Token: 0x06000B14 RID: 2836 RVA: 0x000191B4 File Offset: 0x000173B4
	[Address(RVA = "0x2A616BC", Offset = "0x2A616BC", VA = "0x2A616BC")]
	[Token(Token = "0x6000B14")]
	private void method_2()
	{
	}

	// Token: 0x06000B15 RID: 2837 RVA: 0x000191E8 File Offset: 0x000173E8
	[Address(RVA = "0x2A61860", Offset = "0x2A61860", VA = "0x2A61860")]
	[Token(Token = "0x6000B15")]
	private void method_3()
	{
	}

	// Token: 0x06000B16 RID: 2838 RVA: 0x000191F8 File Offset: 0x000173F8
	[Token(Token = "0x6000B16")]
	[Address(RVA = "0x2A61A00", Offset = "0x2A61A00", VA = "0x2A61A00")]
	private void method_4()
	{
		ColorManager.colorManager_0 = this;
	}

	// Token: 0x06000B17 RID: 2839 RVA: 0x0001920C File Offset: 0x0001740C
	[Address(RVA = "0x2A5C6C4", Offset = "0x2A5C6C4", VA = "0x2A5C6C4")]
	[Token(Token = "0x6000B17")]
	public void method_5()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("DisableCosmetic");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B18 RID: 2840 RVA: 0x0001922C File Offset: 0x0001742C
	[Address(RVA = "0x2A5C88C", Offset = "0x2A5C88C", VA = "0x2A5C88C")]
	[Token(Token = "0x6000B18")]
	public void method_6()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("_Tint");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B19 RID: 2841 RVA: 0x000191B4 File Offset: 0x000173B4
	[Address(RVA = "0x2A61AF4", Offset = "0x2A61AF4", VA = "0x2A61AF4")]
	[Token(Token = "0x6000B19")]
	private void method_7()
	{
	}

	// Token: 0x06000B1A RID: 2842 RVA: 0x000191F8 File Offset: 0x000173F8
	[Token(Token = "0x6000B1A")]
	[Address(RVA = "0x2A61C8C", Offset = "0x2A61C8C", VA = "0x2A61C8C")]
	private void method_8()
	{
		ColorManager.colorManager_0 = this;
	}

	// Token: 0x06000B1B RID: 2843 RVA: 0x0001924C File Offset: 0x0001744C
	[Token(Token = "0x6000B1B")]
	[Address(RVA = "0x2A5E4D0", Offset = "0x2A5E4D0", VA = "0x2A5E4D0")]
	public void SetColor()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("NetworkPlayer");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B1C RID: 2844 RVA: 0x0001926C File Offset: 0x0001746C
	[Token(Token = "0x6000B1C")]
	[Address(RVA = "0x2A5D4B0", Offset = "0x2A5D4B0", VA = "0x2A5D4B0")]
	public void method_9()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("User has been reported for: ");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B1D RID: 2845 RVA: 0x0001928C File Offset: 0x0001748C
	[Token(Token = "0x6000B1D")]
	[Address(RVA = "0x2A61D80", Offset = "0x2A61D80", VA = "0x2A61D80")]
	private void method_10()
	{
	}

	// Token: 0x06000B1E RID: 2846 RVA: 0x0001929C File Offset: 0x0001749C
	[Token(Token = "0x6000B1E")]
	[Address(RVA = "0x2A5DFE4", Offset = "0x2A5DFE4", VA = "0x2A5DFE4")]
	public void method_11()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("_WobbleX");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B1F RID: 2847 RVA: 0x000191B4 File Offset: 0x000173B4
	[Address(RVA = "0x2A61F1C", Offset = "0x2A61F1C", VA = "0x2A61F1C")]
	[Token(Token = "0x6000B1F")]
	private void method_12()
	{
	}

	// Token: 0x06000B20 RID: 2848 RVA: 0x000191F8 File Offset: 0x000173F8
	[Address(RVA = "0x2A620C0", Offset = "0x2A620C0", VA = "0x2A620C0")]
	[Token(Token = "0x6000B20")]
	private void method_13()
	{
		ColorManager.colorManager_0 = this;
	}

	// Token: 0x06000B21 RID: 2849 RVA: 0x00002326 File Offset: 0x00000526
	[Token(Token = "0x6000B21")]
	[Address(RVA = "0x2A621B4", Offset = "0x2A621B4", VA = "0x2A621B4", Slot = "42")]
	public override void OnPlayerEnteredRoom(Player newPlayer)
	{
		base.OnPlayerEnteredRoom(newPlayer);
	}

	// Token: 0x06000B22 RID: 2850 RVA: 0x000192BC File Offset: 0x000174BC
	[Address(RVA = "0x2A5D124", Offset = "0x2A5D124", VA = "0x2A5D124")]
	[Token(Token = "0x6000B22")]
	public void method_14()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("EnableCosmetic");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B23 RID: 2851 RVA: 0x000191F8 File Offset: 0x000173F8
	[Address(RVA = "0x2A621BC", Offset = "0x2A621BC", VA = "0x2A621BC")]
	[Token(Token = "0x6000B23")]
	private void method_15()
	{
		ColorManager.colorManager_0 = this;
	}

	// Token: 0x06000B24 RID: 2852 RVA: 0x000191F8 File Offset: 0x000173F8
	[Token(Token = "0x6000B24")]
	[Address(RVA = "0x2A622B0", Offset = "0x2A622B0", VA = "0x2A622B0")]
	private void method_16()
	{
		ColorManager.colorManager_0 = this;
	}

	// Token: 0x06000B25 RID: 2853 RVA: 0x000192DC File Offset: 0x000174DC
	[Token(Token = "0x6000B25")]
	[Address(RVA = "0x2A5CAA4", Offset = "0x2A5CAA4", VA = "0x2A5CAA4")]
	public void method_17()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("NetworkPlayer");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B26 RID: 2854 RVA: 0x000191B4 File Offset: 0x000173B4
	[Address(RVA = "0x2A623A8", Offset = "0x2A623A8", VA = "0x2A623A8")]
	[Token(Token = "0x6000B26")]
	private void method_18()
	{
	}

	// Token: 0x06000B27 RID: 2855 RVA: 0x000192FC File Offset: 0x000174FC
	[Token(Token = "0x6000B27")]
	[Address(RVA = "0x2A5E8F4", Offset = "0x2A5E8F4", VA = "0x2A5E8F4")]
	public void method_19()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("Add/Remove Hat");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B28 RID: 2856 RVA: 0x0001931C File Offset: 0x0001751C
	[Token(Token = "0x6000B28")]
	[Address(RVA = "0x2A5D8A0", Offset = "0x2A5D8A0", VA = "0x2A5D8A0")]
	public void method_20()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("CapuchinStore");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B29 RID: 2857 RVA: 0x000191F8 File Offset: 0x000173F8
	[Address(RVA = "0x2A62548", Offset = "0x2A62548", VA = "0x2A62548")]
	[Token(Token = "0x6000B29")]
	private void Start()
	{
		ColorManager.colorManager_0 = this;
	}

	// Token: 0x06000B2A RID: 2858 RVA: 0x000191B4 File Offset: 0x000173B4
	[Token(Token = "0x6000B2A")]
	[Address(RVA = "0x2A62624", Offset = "0x2A62624", VA = "0x2A62624")]
	private void method_21()
	{
	}

	// Token: 0x06000B2B RID: 2859 RVA: 0x0001933C File Offset: 0x0001753C
	[Token(Token = "0x6000B2B")]
	[Address(RVA = "0x2A627C4", Offset = "0x2A627C4", VA = "0x2A627C4")]
	private void Update()
	{
	}

	// Token: 0x06000B2C RID: 2860 RVA: 0x0000232F File Offset: 0x0000052F
	[Token(Token = "0x6000B2C")]
	[Address(RVA = "0x2A6295C", Offset = "0x2A6295C", VA = "0x2A6295C", Slot = "41")]
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
	}

	// Token: 0x06000B2D RID: 2861 RVA: 0x0001934C File Offset: 0x0001754C
	[Address(RVA = "0x2A5E2C8", Offset = "0x2A5E2C8", VA = "0x2A5E2C8")]
	[Token(Token = "0x6000B2D")]
	public void method_22()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("spooky guy true");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B2E RID: 2862 RVA: 0x0001936C File Offset: 0x0001756C
	[Token(Token = "0x6000B2E")]
	[Address(RVA = "0x2A5CD60", Offset = "0x2A5CD60", VA = "0x2A5CD60")]
	public void method_23()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("This is the 5000 Bananas button, and it was just clicked");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B2F RID: 2863 RVA: 0x000192BC File Offset: 0x000174BC
	[Address(RVA = "0x2A5DA58", Offset = "0x2A5DA58", VA = "0x2A5DA58")]
	[Token(Token = "0x6000B2F")]
	public void method_24()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("EnableCosmetic");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B30 RID: 2864 RVA: 0x0001938C File Offset: 0x0001758C
	[Token(Token = "0x6000B30")]
	[Address(RVA = "0x2A5D2F0", Offset = "0x2A5D2F0", VA = "0x2A5D2F0")]
	public void method_25()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("Skelechin");
		this.gameObject_0 = array;
	}

	// Token: 0x06000B31 RID: 2865 RVA: 0x000191B4 File Offset: 0x000173B4
	[Address(RVA = "0x2A629BC", Offset = "0x2A629BC", VA = "0x2A629BC")]
	[Token(Token = "0x6000B31")]
	private void method_26()
	{
	}

	// Token: 0x04000192 RID: 402
	[Token(Token = "0x4000192")]
	public static ColorManager colorManager_0;

	// Token: 0x04000193 RID: 403
	[Token(Token = "0x4000193")]
	[FieldOffset(Offset = "0x20")]
	private GameObject[] gameObject_0;

	// Token: 0x04000194 RID: 404
	[Token(Token = "0x4000194")]
	[FieldOffset(Offset = "0x28")]
	public Material material_0;

	// Token: 0x04000195 RID: 405
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000195")]
	public Material material_1;

	// Token: 0x04000196 RID: 406
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000196")]
	public Color color_0;

	// Token: 0x04000197 RID: 407
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000197")]
	public float[] float_0;

	// Token: 0x04000198 RID: 408
	[Token(Token = "0x4000198")]
	[FieldOffset(Offset = "0x50")]
	public TMP_Text tmp_Text_0;

	// Token: 0x04000199 RID: 409
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000199")]
	public TMP_Text tmp_Text_1;

	// Token: 0x0400019A RID: 410
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400019A")]
	public TMP_Text tmp_Text_2;

	// Token: 0x0400019B RID: 411
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400019B")]
	private string string_0;

	// Token: 0x0400019C RID: 412
	[Token(Token = "0x400019C")]
	[FieldOffset(Offset = "0x70")]
	private string string_1;

	// Token: 0x0400019D RID: 413
	[Token(Token = "0x400019D")]
	[FieldOffset(Offset = "0x78")]
	private string string_2;
}
