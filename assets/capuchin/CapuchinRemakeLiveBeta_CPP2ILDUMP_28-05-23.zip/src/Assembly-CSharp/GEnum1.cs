﻿using System;
using Cpp2IlInjected;

// Token: 0x02000025 RID: 37
[Token(Token = "0x2000025")]
public enum GEnum1 : byte
{
	// Token: 0x040000AE RID: 174
	[Token(Token = "0x40000AE")]
	const_0,
	// Token: 0x040000AF RID: 175
	[Token(Token = "0x40000AF")]
	const_1,
	// Token: 0x040000B0 RID: 176
	[Token(Token = "0x40000B0")]
	const_2,
	// Token: 0x040000B1 RID: 177
	[Token(Token = "0x40000B1")]
	const_3,
	// Token: 0x040000B2 RID: 178
	[Token(Token = "0x40000B2")]
	const_4,
	// Token: 0x040000B3 RID: 179
	[Token(Token = "0x40000B3")]
	const_5,
	// Token: 0x040000B4 RID: 180
	[Token(Token = "0x40000B4")]
	const_6,
	// Token: 0x040000B5 RID: 181
	[Token(Token = "0x40000B5")]
	const_7,
	// Token: 0x040000B6 RID: 182
	[Token(Token = "0x40000B6")]
	const_8,
	// Token: 0x040000B7 RID: 183
	[Token(Token = "0x40000B7")]
	const_9,
	// Token: 0x040000B8 RID: 184
	[Token(Token = "0x40000B8")]
	const_10
}
