﻿using System;
using Cpp2IlInjected;

// Token: 0x02000166 RID: 358
[Token(Token = "0x2000166")]
public enum GEnum22
{
	// Token: 0x04000968 RID: 2408
	[Token(Token = "0x4000968")]
	const_0,
	// Token: 0x04000969 RID: 2409
	[Token(Token = "0x4000969")]
	const_1,
	// Token: 0x0400096A RID: 2410
	[Token(Token = "0x400096A")]
	const_2,
	// Token: 0x0400096B RID: 2411
	[Token(Token = "0x400096B")]
	const_3,
	// Token: 0x0400096C RID: 2412
	[Token(Token = "0x400096C")]
	const_4,
	// Token: 0x0400096D RID: 2413
	[Token(Token = "0x400096D")]
	const_5,
	// Token: 0x0400096E RID: 2414
	[Token(Token = "0x400096E")]
	const_6
}
