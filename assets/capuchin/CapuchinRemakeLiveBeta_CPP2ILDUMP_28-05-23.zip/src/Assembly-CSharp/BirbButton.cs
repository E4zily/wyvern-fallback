﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000A9 RID: 169
[Token(Token = "0x20000A9")]
public class BirbButton : MonoBehaviour
{
	// Token: 0x06001838 RID: 6200 RVA: 0x00031764 File Offset: 0x0002F964
	[Address(RVA = "0x259EFDC", Offset = "0x259EFDC", VA = "0x259EFDC")]
	[Token(Token = "0x6001838")]
	private void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			return;
		}
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001839 RID: 6201 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x259F12C", Offset = "0x259F12C", VA = "0x259F12C")]
	[Token(Token = "0x6001839")]
	public IEnumerator method_1()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600183A RID: 6202 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x259F1A4", Offset = "0x259F1A4", VA = "0x259F1A4")]
	[Token(Token = "0x600183A")]
	public IEnumerator method_2()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600183B RID: 6203 RVA: 0x000317BC File Offset: 0x0002F9BC
	[Address(RVA = "0x259F21C", Offset = "0x259F21C", VA = "0x259F21C", Slot = "4")]
	[Token(Token = "0x600183B")]
	public virtual void vmethod_0(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_12();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600183C RID: 6204 RVA: 0x00031828 File Offset: 0x0002FA28
	[Address(RVA = "0x259F418", Offset = "0x259F418", VA = "0x259F418")]
	[Token(Token = "0x600183C")]
	private IEnumerator method_3(bool bool_1, float float_1, float float_2)
	{
		BirbButton.Class21 @class = new BirbButton.Class21((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(BirbButton.Class21).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600183D RID: 6205 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x259F4BC", Offset = "0x259F4BC", VA = "0x259F4BC")]
	[Token(Token = "0x600183D")]
	public IEnumerator method_4()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600183E RID: 6206 RVA: 0x0003185C File Offset: 0x0002FA5C
	[Address(RVA = "0x259F534", Offset = "0x259F534", VA = "0x259F534", Slot = "5")]
	[Token(Token = "0x600183E")]
	public virtual void vmethod_1(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_14();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600183F RID: 6207 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x259F730", Offset = "0x259F730", VA = "0x259F730")]
	[Token(Token = "0x600183F")]
	private void OnTriggerEnter(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001840 RID: 6208 RVA: 0x000318C8 File Offset: 0x0002FAC8
	[Address(RVA = "0x259F8F4", Offset = "0x259F8F4", VA = "0x259F8F4")]
	[Token(Token = "0x6001840")]
	public void Start()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
	}

	// Token: 0x06001841 RID: 6209 RVA: 0x000318E4 File Offset: 0x0002FAE4
	[Address(RVA = "0x259F950", Offset = "0x259F950", VA = "0x259F950", Slot = "6")]
	[Token(Token = "0x6001841")]
	public virtual void vmethod_2(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_27();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001842 RID: 6210 RVA: 0x000318C8 File Offset: 0x0002FAC8
	[Address(RVA = "0x259FB4C", Offset = "0x259FB4C", VA = "0x259FB4C")]
	[Token(Token = "0x6001842")]
	public void method_5()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
	}

	// Token: 0x06001843 RID: 6211 RVA: 0x000318C8 File Offset: 0x0002FAC8
	[Address(RVA = "0x259FBA8", Offset = "0x259FBA8", VA = "0x259FBA8")]
	[Token(Token = "0x6001843")]
	public void method_6()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
	}

	// Token: 0x06001844 RID: 6212 RVA: 0x00031950 File Offset: 0x0002FB50
	[Address(RVA = "0x259FC04", Offset = "0x259FC04", VA = "0x259FC04", Slot = "7")]
	[Token(Token = "0x6001844")]
	public virtual void vmethod_3(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_37();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001845 RID: 6213 RVA: 0x00031828 File Offset: 0x0002FA28
	[Address(RVA = "0x259FE00", Offset = "0x259FE00", VA = "0x259FE00")]
	[Token(Token = "0x6001845")]
	private IEnumerator method_7(bool bool_1, float float_1, float float_2)
	{
		BirbButton.Class21 @class = new BirbButton.Class21((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(BirbButton.Class21).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001846 RID: 6214 RVA: 0x000318C8 File Offset: 0x0002FAC8
	[Address(RVA = "0x259FEA4", Offset = "0x259FEA4", VA = "0x259FEA4")]
	[Token(Token = "0x6001846")]
	public void method_8()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_0 = component;
	}

	// Token: 0x06001847 RID: 6215 RVA: 0x00031828 File Offset: 0x0002FA28
	[Address(RVA = "0x259FF00", Offset = "0x259FF00", VA = "0x259FF00")]
	[Token(Token = "0x6001847")]
	private IEnumerator method_9(bool bool_1, float float_1, float float_2)
	{
		BirbButton.Class21 @class = new BirbButton.Class21((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(BirbButton.Class21).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001848 RID: 6216 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x259FFA4", Offset = "0x259FFA4", VA = "0x259FFA4")]
	[Token(Token = "0x6001848")]
	private void method_10(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001849 RID: 6217 RVA: 0x000319BC File Offset: 0x0002FBBC
	[Address(RVA = "0x25A00F4", Offset = "0x25A00F4", VA = "0x25A00F4", Slot = "8")]
	[Token(Token = "0x6001849")]
	public virtual void vmethod_4()
	{
		Material material = base.GetComponent<Renderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
	}

	// Token: 0x0600184A RID: 6218 RVA: 0x00031A14 File Offset: 0x0002FC14
	[Address(RVA = "0x25A0260", Offset = "0x25A0260", VA = "0x25A0260")]
	[Token(Token = "0x600184A")]
	private void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x0600184B RID: 6219 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x259F3A0", Offset = "0x259F3A0", VA = "0x259F3A0")]
	[Token(Token = "0x600184B")]
	public IEnumerator method_12()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600184C RID: 6220 RVA: 0x000319BC File Offset: 0x0002FBBC
	[Address(RVA = "0x25A0460", Offset = "0x25A0460", VA = "0x25A0460", Slot = "9")]
	[Token(Token = "0x600184C")]
	public virtual void vmethod_5()
	{
		Material material = base.GetComponent<Renderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
	}

	// Token: 0x0600184D RID: 6221 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A05CC", Offset = "0x25A05CC", VA = "0x25A05CC")]
	[Token(Token = "0x600184D")]
	private void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x0600184E RID: 6222 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x259F6B8", Offset = "0x259F6B8", VA = "0x259F6B8")]
	[Token(Token = "0x600184E")]
	public IEnumerator method_14()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600184F RID: 6223 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A07D0", Offset = "0x25A07D0", VA = "0x25A07D0")]
	[Token(Token = "0x600184F")]
	private void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x06001850 RID: 6224 RVA: 0x00031AC0 File Offset: 0x0002FCC0
	[Address(RVA = "0x25A09A4", Offset = "0x25A09A4", VA = "0x25A09A4", Slot = "10")]
	[Token(Token = "0x6001850")]
	public virtual void vmethod_6(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		GameObject gameObject;
		Vector3 localPosition2 = gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_4();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001851 RID: 6225 RVA: 0x000319BC File Offset: 0x0002FBBC
	[Address(RVA = "0x25A0B28", Offset = "0x25A0B28", VA = "0x25A0B28", Slot = "11")]
	[Token(Token = "0x6001851")]
	public virtual void vmethod_7()
	{
		Material material = base.GetComponent<Renderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
	}

	// Token: 0x06001852 RID: 6226 RVA: 0x000319BC File Offset: 0x0002FBBC
	[Address(RVA = "0x25A0C94", Offset = "0x25A0C94", VA = "0x25A0C94", Slot = "12")]
	[Token(Token = "0x6001852")]
	public virtual void vmethod_8()
	{
		Material material = base.GetComponent<Renderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
	}

	// Token: 0x06001853 RID: 6227 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x25A0DF4", Offset = "0x25A0DF4", VA = "0x25A0DF4")]
	[Token(Token = "0x6001853")]
	public IEnumerator method_16()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001854 RID: 6228 RVA: 0x00031B24 File Offset: 0x0002FD24
	[Address(RVA = "0x259F8C4", Offset = "0x259F8C4", VA = "0x259F8C4")]
	[Token(Token = "0x6001854")]
	private void method_17(bool bool_1, float float_1, float float_2)
	{
		IEnumerator routine = this.method_3(bool_1, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x06001855 RID: 6229 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A0E6C", Offset = "0x25A0E6C", VA = "0x25A0E6C")]
	[Token(Token = "0x6001855")]
	private void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x06001856 RID: 6230 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A1040", Offset = "0x25A1040", VA = "0x25A1040")]
	[Token(Token = "0x6001856")]
	private void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x06001857 RID: 6231 RVA: 0x00031828 File Offset: 0x0002FA28
	[Address(RVA = "0x25A1214", Offset = "0x25A1214", VA = "0x25A1214")]
	[Token(Token = "0x6001857")]
	private IEnumerator method_20(bool bool_1, float float_1, float float_2)
	{
		BirbButton.Class21 @class = new BirbButton.Class21((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(BirbButton.Class21).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001858 RID: 6232 RVA: 0x00031B44 File Offset: 0x0002FD44
	[Address(RVA = "0x25A12B8", Offset = "0x25A12B8", VA = "0x25A12B8", Slot = "13")]
	[Token(Token = "0x6001858")]
	public virtual void vmethod_9(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_35();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001859 RID: 6233 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x25A14B4", Offset = "0x25A14B4", VA = "0x25A14B4")]
	[Token(Token = "0x6001859")]
	public IEnumerator method_21()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600185A RID: 6234 RVA: 0x00031764 File Offset: 0x0002F964
	[Address(RVA = "0x25A152C", Offset = "0x25A152C", VA = "0x25A152C")]
	[Token(Token = "0x600185A")]
	private void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			return;
		}
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x0600185B RID: 6235 RVA: 0x00031BB0 File Offset: 0x0002FDB0
	[Address(RVA = "0x25A0430", Offset = "0x25A0430", VA = "0x25A0430")]
	[Token(Token = "0x600185B")]
	private void method_23(bool bool_1, float float_1, float float_2)
	{
		IEnumerator routine = this.method_28(bool_1, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x0600185C RID: 6236 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A1720", Offset = "0x25A1720", VA = "0x25A1720")]
	[Token(Token = "0x600185C")]
	private void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x0600185D RID: 6237 RVA: 0x00031BD0 File Offset: 0x0002FDD0
	[Address(RVA = "0x25A18F4", Offset = "0x25A18F4", VA = "0x25A18F4")]
	[Token(Token = "0x600185D")]
	private void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x0600185E RID: 6238 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A1A44", Offset = "0x25A1A44", VA = "0x25A1A44")]
	[Token(Token = "0x600185E")]
	private void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x0600185F RID: 6239 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x259FAD4", Offset = "0x259FAD4", VA = "0x259FAD4")]
	[Token(Token = "0x600185F")]
	public IEnumerator method_27()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001860 RID: 6240 RVA: 0x00031828 File Offset: 0x0002FA28
	[Address(RVA = "0x25A167C", Offset = "0x25A167C", VA = "0x25A167C")]
	[Token(Token = "0x6001860")]
	private IEnumerator method_28(bool bool_1, float float_1, float float_2)
	{
		BirbButton.Class21 @class = new BirbButton.Class21((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(BirbButton.Class21).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001861 RID: 6241 RVA: 0x00031828 File Offset: 0x0002FA28
	[Address(RVA = "0x25A1C14", Offset = "0x25A1C14", VA = "0x25A1C14")]
	[Token(Token = "0x6001861")]
	private IEnumerator method_29(bool bool_1, float float_1, float float_2)
	{
		BirbButton.Class21 @class = new BirbButton.Class21((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(BirbButton.Class21).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001862 RID: 6242 RVA: 0x00031B24 File Offset: 0x0002FD24
	[Address(RVA = "0x25A07A0", Offset = "0x25A07A0", VA = "0x25A07A0")]
	[Token(Token = "0x6001862")]
	private void method_30(bool bool_1, float float_1, float float_2)
	{
		IEnumerator routine = this.method_3(bool_1, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x06001863 RID: 6243 RVA: 0x00031BEC File Offset: 0x0002FDEC
	[Address(RVA = "0x25A1CB8", Offset = "0x25A1CB8", VA = "0x25A1CB8", Slot = "14")]
	[Token(Token = "0x6001863")]
	public virtual void vmethod_10(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_2();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001864 RID: 6244 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x25A1E3C", Offset = "0x25A1E3C", VA = "0x25A1E3C")]
	[Token(Token = "0x6001864")]
	public IEnumerator method_31()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001865 RID: 6245 RVA: 0x00031764 File Offset: 0x0002F964
	[Address(RVA = "0x25A1EB4", Offset = "0x25A1EB4", VA = "0x25A1EB4")]
	[Token(Token = "0x6001865")]
	private void OnTriggerExit(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			return;
		}
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001866 RID: 6246 RVA: 0x00031764 File Offset: 0x0002F964
	[Address(RVA = "0x25A1FF8", Offset = "0x25A1FF8", VA = "0x25A1FF8")]
	[Token(Token = "0x6001866")]
	private void method_32(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			return;
		}
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001867 RID: 6247 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x25A214C", Offset = "0x25A214C", VA = "0x25A214C")]
	[Token(Token = "0x6001867")]
	public IEnumerator method_33()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001868 RID: 6248 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A21C4", Offset = "0x25A21C4", VA = "0x25A21C4")]
	[Token(Token = "0x6001868")]
	private void method_34(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x06001869 RID: 6249 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x25A143C", Offset = "0x25A143C", VA = "0x25A143C")]
	[Token(Token = "0x6001869")]
	public IEnumerator method_35()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600186A RID: 6250 RVA: 0x00031828 File Offset: 0x0002FA28
	[Address(RVA = "0x25A2398", Offset = "0x25A2398", VA = "0x25A2398")]
	[Token(Token = "0x600186A")]
	private IEnumerator method_36(bool bool_1, float float_1, float float_2)
	{
		BirbButton.Class21 @class = new BirbButton.Class21((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(BirbButton.Class21).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600186B RID: 6251 RVA: 0x00031B44 File Offset: 0x0002FD44
	[Address(RVA = "0x25A243C", Offset = "0x25A243C", VA = "0x25A243C", Slot = "15")]
	[Token(Token = "0x600186B")]
	public virtual void vmethod_11(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_35();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600186C RID: 6252 RVA: 0x00031C58 File Offset: 0x0002FE58
	[Address(RVA = "0x25A25B0", Offset = "0x25A25B0", VA = "0x25A25B0", Slot = "16")]
	[Token(Token = "0x600186C")]
	public virtual void vmethod_12(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_16();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600186D RID: 6253 RVA: 0x00031794 File Offset: 0x0002F994
	[Address(RVA = "0x259FD88", Offset = "0x259FD88", VA = "0x259FD88")]
	[Token(Token = "0x600186D")]
	public IEnumerator method_37()
	{
		BirbButton.Class20 @class = new BirbButton.Class20((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600186E RID: 6254 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A2734", Offset = "0x25A2734", VA = "0x25A2734")]
	[Token(Token = "0x600186E")]
	private void method_38(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x0600186F RID: 6255 RVA: 0x000026DC File Offset: 0x000008DC
	[Address(RVA = "0x25A2908", Offset = "0x25A2908", VA = "0x25A2908")]
	[Token(Token = "0x600186F")]
	public BirbButton()
	{
	}

	// Token: 0x06001870 RID: 6256 RVA: 0x00031764 File Offset: 0x0002F964
	[Address(RVA = "0x25A291C", Offset = "0x25A291C", VA = "0x25A291C")]
	[Token(Token = "0x6001870")]
	private void method_39(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_0)
		{
			return;
		}
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x06001871 RID: 6257 RVA: 0x00031CC4 File Offset: 0x0002FEC4
	[Address(RVA = "0x25A2A6C", Offset = "0x25A2A6C", VA = "0x25A2A6C", Slot = "17")]
	[Token(Token = "0x6001871")]
	public virtual void vmethod_13()
	{
		Renderer renderer;
		Material material = renderer.material;
		GameObject gameObject;
		Vector3 localPosition = gameObject.transform.gameObject.transform.localPosition;
		GameObject gameObject2;
		Vector3 localPosition2 = gameObject2.transform.localPosition;
		GameObject gameObject3;
		Vector3 localPosition3 = gameObject3.transform.localPosition;
	}

	// Token: 0x06001872 RID: 6258 RVA: 0x00031A64 File Offset: 0x0002FC64
	[Address(RVA = "0x25A2BD8", Offset = "0x25A2BD8", VA = "0x25A2BD8")]
	[Token(Token = "0x6001872")]
	private void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			bool flag3 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		IEnumerator routine2;
		base.StartCoroutine(routine2);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x06001873 RID: 6259 RVA: 0x000318E4 File Offset: 0x0002FAE4
	[Address(RVA = "0x25A2DA8", Offset = "0x25A2DA8", VA = "0x25A2DA8", Slot = "18")]
	[Token(Token = "0x6001873")]
	public virtual void vmethod_14(bool bool_1)
	{
		Material material = base.GetComponent<MeshRenderer>().material;
		Transform transform = base.gameObject.transform;
		Vector3 localPosition = base.gameObject.transform.localPosition;
		Vector3 localPosition2 = base.gameObject.transform.localPosition;
		Vector3 localPosition3 = base.gameObject.transform.localPosition;
		IEnumerator routine = this.method_27();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001874 RID: 6260 RVA: 0x00031D08 File Offset: 0x0002FF08
	[Address(RVA = "0x25A2F2C", Offset = "0x25A2F2C", VA = "0x25A2F2C")]
	[Token(Token = "0x6001874")]
	private void method_41(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		bool flag = this.bool_0;
		bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
		if (flag)
		{
			throw new MissingMethodException();
		}
		IEnumerator routine;
		base.StartCoroutine(routine);
		Material material = base.GetComponent<MeshRenderer>().material;
	}

	// Token: 0x06001875 RID: 6261 RVA: 0x00031D54 File Offset: 0x0002FF54
	[Address(RVA = "0x25A30FC", Offset = "0x25A30FC", VA = "0x25A30FC")]
	[Token(Token = "0x6001875")]
	private void method_42(Collider collider_0)
	{
		HandColliders component = collider_0.GetComponent<HandColliders>();
		component;
		bool flag = collider_0.GetComponent<HandColliders>().bool_0;
		if (component != null)
		{
			bool flag2 = collider_0.GetComponent<HandColliders>().bool_0;
			return;
		}
		MeshRenderer meshRenderer;
		Material material = meshRenderer.material;
	}

	// Token: 0x04000324 RID: 804
	[Token(Token = "0x4000324")]
	[FieldOffset(Offset = "0x18")]
	private float float_0 = (float)52429;

	// Token: 0x04000325 RID: 805
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000325")]
	private BoxCollider boxCollider_0;

	// Token: 0x04000326 RID: 806
	[Token(Token = "0x4000326")]
	[FieldOffset(Offset = "0x28")]
	public bool bool_0;
}
