﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;
using VLB;

// Token: 0x02000103 RID: 259
[Token(Token = "0x2000103")]
public class WatchBatteryManager : MonoBehaviour
{
	// Token: 0x0600275C RID: 10076 RVA: 0x00050598 File Offset: 0x0004E798
	[Token(Token = "0x600275C")]
	[Address(RVA = "0x20F6B50", Offset = "0x20F6B50", VA = "0x20F6B50")]
	public void method_0()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
		this.gameObject_3 = gameObject;
		Light light;
		this.light_0 = light;
		VolumetricLightBeam volumetricLightBeam;
		this.volumetricLightBeam_0 = volumetricLightBeam;
		float deltaTime = Time.deltaTime;
		Image image = this.image_0;
		image.fillAmount = deltaTime;
		float num = this.float_0;
		float r;
		if (this.bool_0)
		{
			Light light2 = this.light_0;
			this.float_0 = num;
			light2.gameObject.name == "Vector1_d371bd24217449349bd747533d51af6b";
			bool inRoom2 = PhotonNetwork.InRoom;
			Light light3 = this.light_0;
			float intensity = light3.intensity;
			float intensity2;
			light3.intensity = intensity2;
			r = this.color_0.r;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light light4 = this.light_0;
		this.float_0 = r;
		light4.gameObject.name == "Did Hit";
		bool inRoom3 = PhotonNetwork.InRoom;
		Light light5 = this.light_0;
		light5.intensity = deltaTime3;
		float deltaTime4 = Time.deltaTime;
		this.audioSource_0.Stop();
		if (!this.bool_1)
		{
			this.audioSource_1.Play();
			Debug.Log("TurnAmount");
		}
		this.method_1();
	}

	// Token: 0x0600275D RID: 10077 RVA: 0x000506C8 File Offset: 0x0004E8C8
	[Token(Token = "0x600275D")]
	[Address(RVA = "0x20F7050", Offset = "0x20F7050", VA = "0x20F7050")]
	public void method_1()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		bool isPlaying = this.audioSource_2.isPlaying;
	}

	// Token: 0x0600275E RID: 10078 RVA: 0x00050718 File Offset: 0x0004E918
	[Token(Token = "0x600275E")]
	[Address(RVA = "0x20F7130", Offset = "0x20F7130", VA = "0x20F7130")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Debug.Log("PlayerHead");
		GameObject gameObject = this.gameObject_2;
		this.bool_1 = (num != 0L);
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x0600275F RID: 10079 RVA: 0x0005076C File Offset: 0x0004E96C
	[Token(Token = "0x600275F")]
	[Address(RVA = "0x20F726C", Offset = "0x20F726C", VA = "0x20F726C")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		this.audioSource_0.Stop();
	}

	// Token: 0x06002760 RID: 10080 RVA: 0x00050798 File Offset: 0x0004E998
	[Address(RVA = "0x20F7354", Offset = "0x20F7354", VA = "0x20F7354")]
	[Token(Token = "0x6002760")]
	public void method_4()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06002761 RID: 10081 RVA: 0x000507DC File Offset: 0x0004E9DC
	[Address(RVA = "0x20F73AC", Offset = "0x20F73AC", VA = "0x20F73AC")]
	[Token(Token = "0x6002761")]
	public void method_5()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
		this.gameObject_3 = gameObject;
		Light light;
		this.light_0 = light;
		VolumetricLightBeam volumetricLightBeam;
		this.volumetricLightBeam_0 = volumetricLightBeam;
		float deltaTime = Time.deltaTime;
		Image image = this.image_0;
		image.fillAmount = deltaTime;
		float num = this.float_0;
		float r;
		if (this.bool_0)
		{
			Light light2 = this.light_0;
			this.float_0 = num;
			light2.gameObject.name == "Bare Torso";
			bool inRoom2 = PhotonNetwork.InRoom;
			Light light3 = this.light_0;
			float intensity = light3.intensity;
			float intensity2;
			light3.intensity = intensity2;
			r = this.color_0.r;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light light4 = this.light_0;
		this.float_0 = r;
		light4.gameObject.name == "typesOfTalk";
		bool inRoom3 = PhotonNetwork.InRoom;
		Light light5 = this.light_0;
		light5.intensity = deltaTime3;
		float deltaTime4 = Time.deltaTime;
		this.audioSource_0.Stop();
		if (!this.bool_1)
		{
			this.audioSource_1.Play();
			Debug.Log("1BN");
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		this.method_19();
	}

	// Token: 0x06002762 RID: 10082 RVA: 0x00050918 File Offset: 0x0004EB18
	[Address(RVA = "0x20F7990", Offset = "0x20F7990", VA = "0x20F7990")]
	[Token(Token = "0x6002762")]
	public void method_6()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06002763 RID: 10083 RVA: 0x0005095C File Offset: 0x0004EB5C
	[Token(Token = "0x6002763")]
	[Address(RVA = "0x20F79E8", Offset = "0x20F79E8", VA = "0x20F79E8")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
	}

	// Token: 0x06002764 RID: 10084 RVA: 0x00050998 File Offset: 0x0004EB98
	[Token(Token = "0x6002764")]
	[Address(RVA = "0x20F7AD0", Offset = "0x20F7AD0", VA = "0x20F7AD0")]
	public void method_8()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		bool isPlaying = this.audioSource_2.isPlaying;
	}

	// Token: 0x06002765 RID: 10085 RVA: 0x000509E8 File Offset: 0x0004EBE8
	[Token(Token = "0x6002765")]
	[Address(RVA = "0x20F7B58", Offset = "0x20F7B58", VA = "0x20F7B58")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
	}

	// Token: 0x06002766 RID: 10086 RVA: 0x00050A24 File Offset: 0x0004EC24
	[Address(RVA = "0x20F7C40", Offset = "0x20F7C40", VA = "0x20F7C40")]
	[Token(Token = "0x6002766")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002767 RID: 10087 RVA: 0x00050A54 File Offset: 0x0004EC54
	[Address(RVA = "0x20F7D28", Offset = "0x20F7D28", VA = "0x20F7D28")]
	[Token(Token = "0x6002767")]
	public void method_10()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
		this.gameObject_3 = gameObject;
		Light light;
		this.light_0 = light;
		VolumetricLightBeam volumetricLightBeam;
		this.volumetricLightBeam_0 = volumetricLightBeam;
		float deltaTime = Time.deltaTime;
		Image image = this.image_0;
		image.fillAmount = deltaTime;
		float num = this.float_0;
		float r;
		if (this.bool_0)
		{
			Light light2 = this.light_0;
			this.float_0 = num;
			light2.gameObject.name == "Cannot access index {0}. Buffer is empty";
			bool inRoom2 = PhotonNetwork.InRoom;
			Light light3 = this.light_0;
			float intensity = light3.intensity;
			float intensity2;
			light3.intensity = intensity2;
			r = this.color_0.r;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light light4 = this.light_0;
		this.float_0 = r;
		light4.gameObject.name == " and the correct version is ";
		bool inRoom3 = PhotonNetwork.InRoom;
		Light light5 = this.light_0;
		light5.intensity = deltaTime3;
		float deltaTime4 = Time.deltaTime;
		this.audioSource_0.Stop();
		if (!this.bool_1)
		{
			this.audioSource_1.Play();
			Debug.Log("TurnAmount");
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		this.method_19();
	}

	// Token: 0x06002768 RID: 10088 RVA: 0x00050B90 File Offset: 0x0004ED90
	[Address(RVA = "0x20F822C", Offset = "0x20F822C", VA = "0x20F822C")]
	[Token(Token = "0x6002768")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long num = 1L;
		this.bool_0 = (num != 0L);
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
	}

	// Token: 0x06002769 RID: 10089 RVA: 0x00050BD4 File Offset: 0x0004EDD4
	[Address(RVA = "0x20F8318", Offset = "0x20F8318", VA = "0x20F8318")]
	[Token(Token = "0x6002769")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Debug.Log("META");
		GameObject gameObject = this.gameObject_2;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x0600276A RID: 10090 RVA: 0x00050C20 File Offset: 0x0004EE20
	[Address(RVA = "0x20F8454", Offset = "0x20F8454", VA = "0x20F8454")]
	[Token(Token = "0x600276A")]
	public void method_13(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.GetComponent<Charger>();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Debug.Log("Universal Render Pipeline/Lit");
		GameObject gameObject2 = this.gameObject_2;
		this.bool_1 = (num != 0L);
		long active = 0L;
		gameObject2.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x0600276B RID: 10091 RVA: 0x00050C70 File Offset: 0x0004EE70
	[Token(Token = "0x600276B")]
	[Address(RVA = "0x20F8590", Offset = "0x20F8590", VA = "0x20F8590")]
	public void method_14()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		bool isPlaying = this.audioSource_2.isPlaying;
	}

	// Token: 0x0600276C RID: 10092 RVA: 0x00050CC0 File Offset: 0x0004EEC0
	[Token(Token = "0x600276C")]
	[Address(RVA = "0x20F8618", Offset = "0x20F8618", VA = "0x20F8618")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		long active = 0L;
		Debug.Log("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		this.gameObject_2.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x0600276D RID: 10093 RVA: 0x00050918 File Offset: 0x0004EB18
	[Token(Token = "0x600276D")]
	[Address(RVA = "0x20F8750", Offset = "0x20F8750", VA = "0x20F8750")]
	public void method_16()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x0600276E RID: 10094 RVA: 0x00050C70 File Offset: 0x0004EE70
	[Address(RVA = "0x20F87A8", Offset = "0x20F87A8", VA = "0x20F87A8")]
	[Token(Token = "0x600276E")]
	public void method_17()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		bool isPlaying = this.audioSource_2.isPlaying;
	}

	// Token: 0x0600276F RID: 10095 RVA: 0x00050B90 File Offset: 0x0004ED90
	[Token(Token = "0x600276F")]
	[Address(RVA = "0x20F8830", Offset = "0x20F8830", VA = "0x20F8830")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long num = 1L;
		this.bool_0 = (num != 0L);
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
	}

	// Token: 0x06002770 RID: 10096 RVA: 0x000506C8 File Offset: 0x0004E8C8
	[Token(Token = "0x6002770")]
	[Address(RVA = "0x20F78B0", Offset = "0x20F78B0", VA = "0x20F78B0")]
	public void method_19()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		bool isPlaying = this.audioSource_2.isPlaying;
	}

	// Token: 0x06002771 RID: 10097 RVA: 0x00050D04 File Offset: 0x0004EF04
	[Address(RVA = "0x20F891C", Offset = "0x20F891C", VA = "0x20F891C")]
	[Token(Token = "0x6002771")]
	public void method_20()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
		this.gameObject_3 = gameObject;
		Light light;
		this.light_0 = light;
		VolumetricLightBeam volumetricLightBeam;
		this.volumetricLightBeam_0 = volumetricLightBeam;
		float deltaTime = Time.deltaTime;
		Image image = this.image_0;
		image.fillAmount = deltaTime;
		float num = this.float_0;
		float r;
		if (this.bool_0)
		{
			Light light2 = this.light_0;
			this.float_0 = num;
			light2.gameObject.name == "Collided";
			bool inRoom2 = PhotonNetwork.InRoom;
			Light light3 = this.light_0;
			float intensity = light3.intensity;
			float intensity2;
			light3.intensity = intensity2;
			r = this.color_0.r;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light light4 = this.light_0;
		this.float_0 = r;
		light4.gameObject.name == "Version";
		bool inRoom3 = PhotonNetwork.InRoom;
		Light light5 = this.light_0;
		light5.intensity = deltaTime3;
		float deltaTime4 = Time.deltaTime;
		AudioSource audioSource = this.audioSource_0;
		audioSource.Stop();
		if (!this.bool_1)
		{
			audioSource.Play();
			Debug.Log("CapuchinStore");
		}
		this.method_36();
	}

	// Token: 0x06002772 RID: 10098 RVA: 0x00050E34 File Offset: 0x0004F034
	[Address(RVA = "0x20F8EA4", Offset = "0x20F8EA4", VA = "0x20F8EA4")]
	[Token(Token = "0x6002772")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Debug.Log("hh:mmtt");
		GameObject gameObject = this.gameObject_2;
		this.bool_1 = (num != 0L);
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x06002773 RID: 10099 RVA: 0x00050E88 File Offset: 0x0004F088
	[Address(RVA = "0x20F7938", Offset = "0x20F7938", VA = "0x20F7938")]
	[Token(Token = "0x6002773")]
	public void method_22()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06002774 RID: 10100 RVA: 0x00050ECC File Offset: 0x0004F0CC
	[Token(Token = "0x6002774")]
	[Address(RVA = "0x20F8FE0", Offset = "0x20F8FE0", VA = "0x20F8FE0")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		Debug.Log("Done");
		GameObject gameObject = this.gameObject_2;
		long num = 1L;
		this.bool_1 = (num != 0L);
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x06002775 RID: 10101 RVA: 0x00050F18 File Offset: 0x0004F118
	[Address(RVA = "0x20F911C", Offset = "0x20F911C", VA = "0x20F911C")]
	[Token(Token = "0x6002775")]
	public void method_24()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
		GameObject gameObject2 = this.gameObject_2;
		long active3 = 1L;
		gameObject2.SetActive(active3 != 0L);
	}

	// Token: 0x06002776 RID: 10102 RVA: 0x00050F50 File Offset: 0x0004F150
	[Token(Token = "0x6002776")]
	[Address(RVA = "0x20F91A4", Offset = "0x20F91A4", VA = "0x20F91A4")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Debug.Log("true");
		GameObject gameObject = this.gameObject_2;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x06002777 RID: 10103 RVA: 0x00050F9C File Offset: 0x0004F19C
	[Token(Token = "0x6002777")]
	[Address(RVA = "0x20F92E0", Offset = "0x20F92E0", VA = "0x20F92E0")]
	public void method_26()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
		this.gameObject_3 = gameObject;
		Light light;
		this.light_0 = light;
		VolumetricLightBeam volumetricLightBeam;
		this.volumetricLightBeam_0 = volumetricLightBeam;
		float deltaTime = Time.deltaTime;
		Image image = this.image_0;
		image.fillAmount = deltaTime;
		float num = this.float_0;
		float r;
		if (this.bool_0)
		{
			Light light2 = this.light_0;
			this.float_0 = num;
			light2.gameObject.name == "RightHandAttachPoint";
			bool inRoom2 = PhotonNetwork.InRoom;
			Light light3 = this.light_0;
			float intensity = light3.intensity;
			float intensity2;
			light3.intensity = intensity2;
			r = this.color_0.r;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light light4 = this.light_0;
		this.float_0 = r;
		light4.gameObject.name == "n0";
		bool inRoom3 = PhotonNetwork.InRoom;
		Light light5 = this.light_0;
		light5.intensity = deltaTime3;
		float deltaTime4 = Time.deltaTime;
		this.audioSource_0.Stop();
		if (!this.bool_1)
		{
			this.audioSource_1.Play();
			Debug.Log("Push To Talk");
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		this.method_24();
	}

	// Token: 0x06002778 RID: 10104 RVA: 0x00050E88 File Offset: 0x0004F088
	[Address(RVA = "0x20F70D8", Offset = "0x20F70D8", VA = "0x20F70D8")]
	[Token(Token = "0x6002778")]
	public void method_27()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06002779 RID: 10105 RVA: 0x0005095C File Offset: 0x0004EB5C
	[Address(RVA = "0x20F983C", Offset = "0x20F983C", VA = "0x20F983C")]
	[Token(Token = "0x6002779")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
	}

	// Token: 0x0600277A RID: 10106 RVA: 0x0005095C File Offset: 0x0004EB5C
	[Address(RVA = "0x20F9924", Offset = "0x20F9924", VA = "0x20F9924")]
	[Token(Token = "0x600277A")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
	}

	// Token: 0x0600277B RID: 10107 RVA: 0x000510D8 File Offset: 0x0004F2D8
	[Address(RVA = "0x20F9A0C", Offset = "0x20F9A0C", VA = "0x20F9A0C")]
	[Token(Token = "0x600277B")]
	public void Update()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
		this.gameObject_3 = gameObject;
		Light light;
		this.light_0 = light;
		VolumetricLightBeam volumetricLightBeam;
		this.volumetricLightBeam_0 = volumetricLightBeam;
		float deltaTime = Time.deltaTime;
		Image image = this.image_0;
		image.fillAmount = deltaTime;
		float num = this.float_0;
		float r;
		if (this.bool_0)
		{
			float a;
			float num2;
			Mathf.Lerp(a, num2, num2);
			Light light2 = this.light_0;
			this.float_0 = num;
			light2.gameObject.name == "FLSPTLT";
			bool inRoom2 = PhotonNetwork.InRoom;
			Light light3 = this.light_0;
			float intensity = light3.intensity;
			float intensity2 = Mathf.Lerp(intensity, num2, num2);
			light3.intensity = intensity2;
			r = this.color_0.r;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light light4 = this.light_0;
		this.float_0 = r;
		light4.gameObject.name == "FLSPTLT";
		bool inRoom3 = PhotonNetwork.InRoom;
		Light light5 = this.light_0;
		light5.intensity = deltaTime3;
		float deltaTime4 = Time.deltaTime;
		this.audioSource_0.Stop();
		if (!this.bool_1)
		{
			this.audioSource_1.Play();
			Debug.Log("Charged!");
			long num3 = 1L;
			this.bool_1 = (num3 != 0L);
		}
		this.method_8();
	}

	// Token: 0x0600277C RID: 10108 RVA: 0x00002DB0 File Offset: 0x00000FB0
	[Token(Token = "0x600277C")]
	[Address(RVA = "0x20F9EE0", Offset = "0x20F9EE0", VA = "0x20F9EE0")]
	public WatchBatteryManager()
	{
	}

	// Token: 0x0600277D RID: 10109 RVA: 0x00051230 File Offset: 0x0004F430
	[Address(RVA = "0x20F9F00", Offset = "0x20F9F00", VA = "0x20F9F00")]
	[Token(Token = "0x600277D")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Debug.Log("Charging...");
		GameObject gameObject = this.gameObject_2;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x0600277E RID: 10110 RVA: 0x0005127C File Offset: 0x0004F47C
	[Address(RVA = "0x20FA03C", Offset = "0x20FA03C", VA = "0x20FA03C")]
	[Token(Token = "0x600277E")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		Debug.Log("MetaAuth");
		GameObject gameObject = this.gameObject_2;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x0600277F RID: 10111 RVA: 0x000512C0 File Offset: 0x0004F4C0
	[Token(Token = "0x600277F")]
	[Address(RVA = "0x20FA174", Offset = "0x20FA174", VA = "0x20FA174")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		Debug.Log(".Please press the button if you would like to play alone");
		GameObject gameObject = this.gameObject_2;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x06002780 RID: 10112 RVA: 0x00051304 File Offset: 0x0004F504
	[Token(Token = "0x6002780")]
	[Address(RVA = "0x20FA2AC", Offset = "0x20FA2AC", VA = "0x20FA2AC")]
	public void method_32()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06002781 RID: 10113 RVA: 0x00051348 File Offset: 0x0004F548
	[Address(RVA = "0x20FA304", Offset = "0x20FA304", VA = "0x20FA304")]
	[Token(Token = "0x6002781")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		Debug.Log("M/d/yyyy");
		GameObject gameObject = this.gameObject_2;
		long num = 1L;
		this.bool_1 = (num != 0L);
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x06002782 RID: 10114 RVA: 0x00051394 File Offset: 0x0004F594
	[Address(RVA = "0x20FA440", Offset = "0x20FA440", VA = "0x20FA440")]
	[Token(Token = "0x6002782")]
	public void method_34()
	{
		bool inRoom = PhotonNetwork.InRoom;
		GameObject gameObject = this.networkPlayerSpawner_0.gameObject_0;
		this.gameObject_3 = gameObject;
		Light light;
		this.light_0 = light;
		Light light2;
		this.volumetricLightBeam_0 = light2;
		float deltaTime = Time.deltaTime;
		Image image = this.image_0;
		image.fillAmount = deltaTime;
		float num = this.float_0;
		float r;
		if (this.bool_0)
		{
			Light light3 = this.light_0;
			this.float_0 = num;
			light3.gameObject.name == "XR Usage";
			bool inRoom2 = PhotonNetwork.InRoom;
			Light light4 = this.light_0;
			float intensity = light4.intensity;
			float intensity2;
			light4.intensity = intensity2;
			r = this.color_0.r;
			float deltaTime2 = Time.deltaTime;
			return;
		}
		float deltaTime3 = Time.deltaTime;
		Light light5 = this.light_0;
		this.float_0 = r;
		light5.gameObject.name == "next";
		bool inRoom3 = PhotonNetwork.InRoom;
		Light light6 = this.light_0;
		light6.intensity = deltaTime3;
		float deltaTime4 = Time.deltaTime;
		this.audioSource_0.Stop();
		if (!this.bool_1)
		{
			this.audioSource_1.Play();
			Debug.Log("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
		}
		this.method_1();
	}

	// Token: 0x06002783 RID: 10115 RVA: 0x00050B90 File Offset: 0x0004ED90
	[Token(Token = "0x6002783")]
	[Address(RVA = "0x20FA93C", Offset = "0x20FA93C", VA = "0x20FA93C")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		GameObject gameObject = this.gameObject_2;
		long num = 1L;
		this.bool_0 = (num != 0L);
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
	}

	// Token: 0x06002784 RID: 10116 RVA: 0x000506C8 File Offset: 0x0004E8C8
	[Address(RVA = "0x20F8E1C", Offset = "0x20F8E1C", VA = "0x20F8E1C")]
	[Token(Token = "0x6002784")]
	public void method_36()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		bool isPlaying = this.audioSource_2.isPlaying;
	}

	// Token: 0x06002785 RID: 10117 RVA: 0x000514C4 File Offset: 0x0004F6C4
	[Address(RVA = "0x20FAA28", Offset = "0x20FAA28", VA = "0x20FAA28")]
	[Token(Token = "0x6002785")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		Debug.Log("5BN");
		GameObject gameObject = this.gameObject_2;
		long num = 1L;
		this.bool_1 = (num != 0L);
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x06002786 RID: 10118 RVA: 0x00051510 File Offset: 0x0004F710
	[Address(RVA = "0x20FAB64", Offset = "0x20FAB64", VA = "0x20FAB64")]
	[Token(Token = "0x6002786")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<Charger>();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Debug.Log("liftoff failed!");
		GameObject gameObject = this.gameObject_2;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Play();
	}

	// Token: 0x06002787 RID: 10119 RVA: 0x0005155C File Offset: 0x0004F75C
	[Address(RVA = "0x20FACA0", Offset = "0x20FACA0", VA = "0x20FACA0")]
	[Token(Token = "0x6002787")]
	public void method_39()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		bool isPlaying = this.audioSource_2.isPlaying;
	}

	// Token: 0x06002788 RID: 10120 RVA: 0x000515AC File Offset: 0x0004F7AC
	[Address(RVA = "0x20F97E4", Offset = "0x20F97E4", VA = "0x20F97E4")]
	[Token(Token = "0x6002788")]
	public void method_40()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x040004FA RID: 1274
	[Token(Token = "0x40004FA")]
	[FieldOffset(Offset = "0x18")]
	public float float_0 = (float)17076;

	// Token: 0x040004FB RID: 1275
	[Token(Token = "0x40004FB")]
	[FieldOffset(Offset = "0x1C")]
	public bool bool_0;

	// Token: 0x040004FC RID: 1276
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004FC")]
	public float float_1;

	// Token: 0x040004FD RID: 1277
	[Token(Token = "0x40004FD")]
	[FieldOffset(Offset = "0x28")]
	public GameObject gameObject_0;

	// Token: 0x040004FE RID: 1278
	[Token(Token = "0x40004FE")]
	[FieldOffset(Offset = "0x30")]
	public GameObject gameObject_1;

	// Token: 0x040004FF RID: 1279
	[Token(Token = "0x40004FF")]
	[FieldOffset(Offset = "0x38")]
	public float float_2 = (float)16704;

	// Token: 0x04000500 RID: 1280
	[Token(Token = "0x4000500")]
	[FieldOffset(Offset = "0x40")]
	public AudioSource audioSource_0;

	// Token: 0x04000501 RID: 1281
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000501")]
	public AudioSource audioSource_1;

	// Token: 0x04000502 RID: 1282
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000502")]
	public AudioSource audioSource_2;

	// Token: 0x04000503 RID: 1283
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4000503")]
	public GameObject gameObject_2;

	// Token: 0x04000504 RID: 1284
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000504")]
	private bool bool_1;

	// Token: 0x04000505 RID: 1285
	[Token(Token = "0x4000505")]
	[FieldOffset(Offset = "0x61")]
	private bool bool_2;

	// Token: 0x04000506 RID: 1286
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000506")]
	private Light light_0;

	// Token: 0x04000507 RID: 1287
	[Token(Token = "0x4000507")]
	[FieldOffset(Offset = "0x70")]
	private VolumetricLightBeam volumetricLightBeam_0;

	// Token: 0x04000508 RID: 1288
	[Token(Token = "0x4000508")]
	[FieldOffset(Offset = "0x78")]
	public NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x04000509 RID: 1289
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000509")]
	private GameObject gameObject_3;

	// Token: 0x0400050A RID: 1290
	[Space]
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x400050A")]
	public Image image_0;

	// Token: 0x0400050B RID: 1291
	[Token(Token = "0x400050B")]
	[FieldOffset(Offset = "0x90")]
	private float float_3;

	// Token: 0x0400050C RID: 1292
	[Token(Token = "0x400050C")]
	[FieldOffset(Offset = "0x94")]
	private float float_4 = (float)17096;

	// Token: 0x0400050D RID: 1293
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x400050D")]
	public Color color_0;

	// Token: 0x0400050E RID: 1294
	[FieldOffset(Offset = "0xA8")]
	[Token(Token = "0x400050E")]
	public Color color_1;
}
