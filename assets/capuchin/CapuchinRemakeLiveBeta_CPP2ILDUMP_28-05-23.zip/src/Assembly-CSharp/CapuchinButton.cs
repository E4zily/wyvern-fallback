﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000017 RID: 23
[Token(Token = "0x2000017")]
public class CapuchinButton : MonoBehaviour
{
	// Token: 0x060002A1 RID: 673 RVA: 0x00009CB4 File Offset: 0x00007EB4
	[Token(Token = "0x60002A1")]
	[Address(RVA = "0x2AE51BC", Offset = "0x2AE51BC", VA = "0x2AE51BC")]
	private void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "tutorialCheck";
		base.StartCoroutine("hand 2");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002A2 RID: 674 RVA: 0x00009D04 File Offset: 0x00007F04
	[Token(Token = "0x60002A2")]
	[Address(RVA = "0x2AE5314", Offset = "0x2AE5314", VA = "0x2AE5314")]
	private void method_1(bool bool_0, float float_1, float float_2)
	{
		this.method_19(bool_0, float_1, float_2);
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002A3")]
	[Address(RVA = "0x2AE53E8", Offset = "0x2AE53E8", VA = "0x2AE53E8")]
	private IEnumerator method_2(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002A4 RID: 676 RVA: 0x00009D50 File Offset: 0x00007F50
	[Token(Token = "0x60002A4")]
	[Address(RVA = "0x2AE548C", Offset = "0x2AE548C", VA = "0x2AE548C")]
	private void method_3(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_62(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x00009D70 File Offset: 0x00007F70
	[Address(RVA = "0x2AE5560", Offset = "0x2AE5560", VA = "0x2AE5560")]
	[Token(Token = "0x60002A5")]
	private void method_4(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_23(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002A6 RID: 678 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002A6")]
	[Address(RVA = "0x2AE5634", Offset = "0x2AE5634", VA = "0x2AE5634", Slot = "4")]
	public virtual void vmethod_0()
	{
	}

	// Token: 0x060002A7 RID: 679 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002A7")]
	[Address(RVA = "0x2AE5638", Offset = "0x2AE5638", VA = "0x2AE5638", Slot = "5")]
	public virtual void vmethod_1()
	{
	}

	// Token: 0x060002A8 RID: 680 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002A8")]
	[Address(RVA = "0x2AE563C", Offset = "0x2AE563C", VA = "0x2AE563C", Slot = "6")]
	public virtual void vmethod_2()
	{
	}

	// Token: 0x060002A9 RID: 681 RVA: 0x00009D90 File Offset: 0x00007F90
	[Address(RVA = "0x2AE5640", Offset = "0x2AE5640", VA = "0x2AE5640")]
	[Token(Token = "0x60002A9")]
	private void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Already Own This Item";
		base.StartCoroutine("_Tint");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002AA RID: 682 RVA: 0x00009DE0 File Offset: 0x00007FE0
	[Address(RVA = "0x2AE5798", Offset = "0x2AE5798", VA = "0x2AE5798")]
	[Token(Token = "0x60002AA")]
	private void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerDeath";
		base.StartCoroutine("BLUTARG");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002AB RID: 683 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002AB")]
	[Address(RVA = "0x2AE58EC", Offset = "0x2AE58EC", VA = "0x2AE58EC")]
	private IEnumerator method_7(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002AC RID: 684 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002AC")]
	[Address(RVA = "0x2AE5990", Offset = "0x2AE5990", VA = "0x2AE5990")]
	private IEnumerator method_8(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002AD RID: 685 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE5A34", Offset = "0x2AE5A34", VA = "0x2AE5A34", Slot = "7")]
	[Token(Token = "0x60002AD")]
	public virtual void vmethod_3()
	{
	}

	// Token: 0x060002AE RID: 686 RVA: 0x00009E30 File Offset: 0x00008030
	[Address(RVA = "0x2AE5A38", Offset = "0x2AE5A38", VA = "0x2AE5A38")]
	[Token(Token = "0x60002AE")]
	private void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "hand 2";
		base.StartCoroutine("Cannot access index {0}. Buffer size is {1}");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002AF RID: 687 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE5B90", Offset = "0x2AE5B90", VA = "0x2AE5B90")]
	[Token(Token = "0x60002AF")]
	private IEnumerator method_10()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002B0")]
	[Address(RVA = "0x2AE5C08", Offset = "0x2AE5C08", VA = "0x2AE5C08", Slot = "8")]
	public virtual void vmethod_4(bool bool_0)
	{
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x00009EA8 File Offset: 0x000080A8
	[Token(Token = "0x60002B1")]
	[Address(RVA = "0x2AE5C0C", Offset = "0x2AE5C0C", VA = "0x2AE5C0C")]
	private void method_11(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_37(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002B2")]
	[Address(RVA = "0x2AE5CE0", Offset = "0x2AE5CE0", VA = "0x2AE5CE0", Slot = "9")]
	public virtual void vmethod_5(bool bool_0)
	{
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002B3")]
	[Address(RVA = "0x2AE5CE4", Offset = "0x2AE5CE4", VA = "0x2AE5CE4")]
	private IEnumerator method_12(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE5D88", Offset = "0x2AE5D88", VA = "0x2AE5D88", Slot = "10")]
	[Token(Token = "0x60002B4")]
	public virtual void vmethod_6()
	{
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE5D8C", Offset = "0x2AE5D8C", VA = "0x2AE5D8C")]
	[Token(Token = "0x60002B5")]
	private IEnumerator method_13()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x00009EC8 File Offset: 0x000080C8
	[Address(RVA = "0x2AE5E04", Offset = "0x2AE5E04", VA = "0x2AE5E04")]
	[Token(Token = "0x60002B6")]
	private void method_14(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		base.StartCoroutine("poweredup!");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x00009F10 File Offset: 0x00008110
	[Token(Token = "0x60002B7")]
	[Address(RVA = "0x2AE58BC", Offset = "0x2AE58BC", VA = "0x2AE58BC")]
	private void method_15(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_84(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x00009F30 File Offset: 0x00008130
	[Token(Token = "0x60002B8")]
	[Address(RVA = "0x2AE6000", Offset = "0x2AE6000", VA = "0x2AE6000")]
	private void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "A Player has left the Room.";
		base.StartCoroutine("tp 2");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x00009F80 File Offset: 0x00008180
	[Token(Token = "0x60002B9")]
	[Address(RVA = "0x2AE6128", Offset = "0x2AE6128", VA = "0x2AE6128")]
	private void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "typesOfTalk";
		base.StartCoroutine("Is Colliding");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002BA")]
	[Address(RVA = "0x2AE6280", Offset = "0x2AE6280", VA = "0x2AE6280", Slot = "11")]
	public virtual void vmethod_7()
	{
	}

	// Token: 0x060002BB RID: 699 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x60002BB")]
	[Address(RVA = "0x2AE6284", Offset = "0x2AE6284", VA = "0x2AE6284")]
	private IEnumerator method_18()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002BC RID: 700 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002BC")]
	[Address(RVA = "0x2AE62FC", Offset = "0x2AE62FC", VA = "0x2AE62FC", Slot = "12")]
	public virtual void vmethod_8()
	{
	}

	// Token: 0x060002BD RID: 701 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE5344", Offset = "0x2AE5344", VA = "0x2AE5344")]
	[Token(Token = "0x60002BD")]
	private IEnumerator method_19(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002BE RID: 702 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002BE")]
	[Address(RVA = "0x2AE6300", Offset = "0x2AE6300", VA = "0x2AE6300", Slot = "13")]
	public virtual void vmethod_9()
	{
	}

	// Token: 0x060002BF RID: 703 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE6304", Offset = "0x2AE6304", VA = "0x2AE6304", Slot = "14")]
	[Token(Token = "0x60002BF")]
	public virtual void vmethod_10(bool bool_0)
	{
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x00009FD0 File Offset: 0x000081D0
	[Address(RVA = "0x2AE6308", Offset = "0x2AE6308", VA = "0x2AE6308")]
	[Token(Token = "0x60002C0")]
	private void method_20(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_2(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x00009FF0 File Offset: 0x000081F0
	[Token(Token = "0x60002C1")]
	[Address(RVA = "0x2AE6338", Offset = "0x2AE6338", VA = "0x2AE6338")]
	private void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "PURCHASED";
		base.StartCoroutine("PRESS AGAIN TO CONFIRM");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002C2")]
	[Address(RVA = "0x2AE6460", Offset = "0x2AE6460", VA = "0x2AE6460", Slot = "15")]
	public virtual void vmethod_11(bool bool_0)
	{
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x0000A040 File Offset: 0x00008240
	[Address(RVA = "0x2AE6464", Offset = "0x2AE6464", VA = "0x2AE6464")]
	[Token(Token = "0x60002C3")]
	private void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE65BC", Offset = "0x2AE65BC", VA = "0x2AE65BC", Slot = "16")]
	[Token(Token = "0x60002C4")]
	public virtual void vmethod_12(bool bool_0)
	{
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002C5")]
	[Address(RVA = "0x2AE65C0", Offset = "0x2AE65C0", VA = "0x2AE65C0", Slot = "17")]
	public virtual void vmethod_13()
	{
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE5590", Offset = "0x2AE5590", VA = "0x2AE5590")]
	[Token(Token = "0x60002C6")]
	private IEnumerator method_23(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x0000A07C File Offset: 0x0000827C
	[Address(RVA = "0x2AE65C4", Offset = "0x2AE65C4", VA = "0x2AE65C4")]
	[Token(Token = "0x60002C7")]
	private void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		base.StartCoroutine("Player");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002C8 RID: 712 RVA: 0x0000A0CC File Offset: 0x000082CC
	[Token(Token = "0x60002C8")]
	[Address(RVA = "0x2AE66D8", Offset = "0x2AE66D8", VA = "0x2AE66D8")]
	private void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		base.StartCoroutine("back");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002C9 RID: 713 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE6800", Offset = "0x2AE6800", VA = "0x2AE6800")]
	[Token(Token = "0x60002C9")]
	private IEnumerator method_26()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002CA RID: 714 RVA: 0x0000A11C File Offset: 0x0000831C
	[Token(Token = "0x60002CA")]
	[Address(RVA = "0x2AE6878", Offset = "0x2AE6878", VA = "0x2AE6878")]
	private void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		base.StartCoroutine("Try Connect To Server...");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002CB RID: 715 RVA: 0x0000A16C File Offset: 0x0000836C
	[Address(RVA = "0x2AE69A0", Offset = "0x2AE69A0", VA = "0x2AE69A0")]
	[Token(Token = "0x60002CB")]
	private IEnumerator method_28()
	{
		new CapuchinButton.Class3((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060002CC RID: 716 RVA: 0x0000A190 File Offset: 0x00008390
	[Token(Token = "0x60002CC")]
	[Address(RVA = "0x2AE6A18", Offset = "0x2AE6A18", VA = "0x2AE6A18")]
	private void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == "retract broken";
		base.StartCoroutine("Did Hit");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002CD RID: 717 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE6B70", Offset = "0x2AE6B70", VA = "0x2AE6B70")]
	[Token(Token = "0x60002CD")]
	private IEnumerator method_30()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002CE RID: 718 RVA: 0x0000A1D8 File Offset: 0x000083D8
	[Address(RVA = "0x2AE6BE8", Offset = "0x2AE6BE8", VA = "0x2AE6BE8")]
	[Token(Token = "0x60002CE")]
	private void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "Update User Inventory";
		base.StartCoroutine("TurnAmount");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002CF RID: 719 RVA: 0x0000A228 File Offset: 0x00008428
	[Token(Token = "0x60002CF")]
	[Address(RVA = "0x2AE6D10", Offset = "0x2AE6D10", VA = "0x2AE6D10")]
	private void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "Skelechin";
		base.StartCoroutine("Left a room");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x0000A278 File Offset: 0x00008478
	[Address(RVA = "0x2AE6E38", Offset = "0x2AE6E38", VA = "0x2AE6E38")]
	[Token(Token = "0x60002D0")]
	private void method_33(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_8(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x0000A298 File Offset: 0x00008498
	[Token(Token = "0x60002D1")]
	[Address(RVA = "0x2AE6E68", Offset = "0x2AE6E68", VA = "0x2AE6E68")]
	private void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		base.StartCoroutine("User is on an outdated version of Capuchin. Your version is ");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002D2")]
	[Address(RVA = "0x2AE6F90", Offset = "0x2AE6F90", VA = "0x2AE6F90")]
	private IEnumerator method_35(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002D3")]
	[Address(RVA = "0x2AE7034", Offset = "0x2AE7034", VA = "0x2AE7034")]
	private IEnumerator method_36(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE5C3C", Offset = "0x2AE5C3C", VA = "0x2AE5C3C")]
	[Token(Token = "0x60002D4")]
	private IEnumerator method_37(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x60002D5")]
	[Address(RVA = "0x2AE70D8", Offset = "0x2AE70D8", VA = "0x2AE70D8")]
	private IEnumerator method_38()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE7150", Offset = "0x2AE7150", VA = "0x2AE7150")]
	[Token(Token = "0x60002D6")]
	private IEnumerator method_39(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002D7")]
	[Address(RVA = "0x2AE71F4", Offset = "0x2AE71F4", VA = "0x2AE71F4")]
	private IEnumerator method_40(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE7298", Offset = "0x2AE7298", VA = "0x2AE7298")]
	[Token(Token = "0x60002D8")]
	private IEnumerator method_41(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002D9")]
	[Address(RVA = "0x2AE733C", Offset = "0x2AE733C", VA = "0x2AE733C", Slot = "18")]
	public virtual void vmethod_14(bool bool_0)
	{
	}

	// Token: 0x060002DA RID: 730 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE7340", Offset = "0x2AE7340", VA = "0x2AE7340", Slot = "19")]
	[Token(Token = "0x60002DA")]
	public virtual void vmethod_15(bool bool_0)
	{
	}

	// Token: 0x060002DB RID: 731 RVA: 0x0000A2E8 File Offset: 0x000084E8
	[Address(RVA = "0x2AE7344", Offset = "0x2AE7344", VA = "0x2AE7344")]
	[Token(Token = "0x60002DB")]
	private void method_42(Collider collider_0)
	{
		collider_0.gameObject.tag == "Toxicity";
		base.StartCoroutine("ChangeToTagged");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002DC RID: 732 RVA: 0x0000A338 File Offset: 0x00008538
	[Address(RVA = "0x2AE749C", Offset = "0x2AE749C", VA = "0x2AE749C")]
	[Token(Token = "0x60002DC")]
	private void method_43(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Tint";
		base.StartCoroutine("retract broken");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002DD RID: 733 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE75C4", Offset = "0x2AE75C4", VA = "0x2AE75C4", Slot = "20")]
	[Token(Token = "0x60002DD")]
	public virtual void vmethod_16()
	{
	}

	// Token: 0x060002DE RID: 734 RVA: 0x0000A388 File Offset: 0x00008588
	[Address(RVA = "0x2AE75C8", Offset = "0x2AE75C8", VA = "0x2AE75C8")]
	[Token(Token = "0x60002DE")]
	private void method_44(Collider collider_0)
	{
		collider_0.gameObject.tag == "1BN";
		base.StartCoroutine("CapuchinRemade");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002DF RID: 735 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002DF")]
	[Address(RVA = "0x2AE76F0", Offset = "0x2AE76F0", VA = "0x2AE76F0")]
	private IEnumerator method_45(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x0000A3D8 File Offset: 0x000085D8
	[Token(Token = "0x60002E0")]
	[Address(RVA = "0x2AE7794", Offset = "0x2AE7794", VA = "0x2AE7794")]
	private void method_46(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_41(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE77C4", Offset = "0x2AE77C4", VA = "0x2AE77C4")]
	[Token(Token = "0x60002E1")]
	private IEnumerator method_47()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE783C", Offset = "0x2AE783C", VA = "0x2AE783C")]
	[Token(Token = "0x60002E2")]
	private IEnumerator method_48()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002E3")]
	[Address(RVA = "0x2AE78B4", Offset = "0x2AE78B4", VA = "0x2AE78B4")]
	private IEnumerator method_49(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x0000A3F8 File Offset: 0x000085F8
	[Token(Token = "0x60002E4")]
	[Address(RVA = "0x2AE5B60", Offset = "0x2AE5B60", VA = "0x2AE5B60")]
	private void method_50(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_86(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x60002E5")]
	[Address(RVA = "0x2AE79FC", Offset = "0x2AE79FC", VA = "0x2AE79FC")]
	private IEnumerator method_51()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002E6")]
	[Address(RVA = "0x2AE7A74", Offset = "0x2AE7A74", VA = "0x2AE7A74", Slot = "21")]
	public virtual void vmethod_17()
	{
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x60002E7")]
	[Address(RVA = "0x2AE7A78", Offset = "0x2AE7A78", VA = "0x2AE7A78")]
	private IEnumerator method_52()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x0000A418 File Offset: 0x00008618
	[Token(Token = "0x60002E8")]
	[Address(RVA = "0x2AE7AF0", Offset = "0x2AE7AF0", VA = "0x2AE7AF0")]
	private void method_53(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_7(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x0000A16C File Offset: 0x0000836C
	[Address(RVA = "0x2AE7B20", Offset = "0x2AE7B20", VA = "0x2AE7B20")]
	[Token(Token = "0x60002E9")]
	private IEnumerator method_54()
	{
		new CapuchinButton.Class3((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060002EA RID: 746 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002EA")]
	[Address(RVA = "0x2AE7B98", Offset = "0x2AE7B98", VA = "0x2AE7B98", Slot = "22")]
	public virtual void vmethod_18()
	{
	}

	// Token: 0x060002EB RID: 747 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002EB")]
	[Address(RVA = "0x2AE7B9C", Offset = "0x2AE7B9C", VA = "0x2AE7B9C")]
	private IEnumerator method_55(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002EC RID: 748 RVA: 0x0000A438 File Offset: 0x00008638
	[Token(Token = "0x60002EC")]
	[Address(RVA = "0x2AE7C40", Offset = "0x2AE7C40", VA = "0x2AE7C40")]
	private void method_56(Collider collider_0)
	{
		collider_0.gameObject.tag == "Reason: ";
		base.StartCoroutine("Add/Remove Glasses");
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002ED RID: 749 RVA: 0x0000A3D8 File Offset: 0x000085D8
	[Address(RVA = "0x2AE5F2C", Offset = "0x2AE5F2C", VA = "0x2AE5F2C")]
	[Token(Token = "0x60002ED")]
	private void method_57(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_41(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002EE RID: 750 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002EE")]
	[Address(RVA = "0x2AE7D98", Offset = "0x2AE7D98", VA = "0x2AE7D98")]
	private IEnumerator method_58(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002EF RID: 751 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x60002EF")]
	[Address(RVA = "0x2AE7E3C", Offset = "0x2AE7E3C", VA = "0x2AE7E3C")]
	private IEnumerator method_59()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE7EB4", Offset = "0x2AE7EB4", VA = "0x2AE7EB4", Slot = "23")]
	[Token(Token = "0x60002F0")]
	public virtual void vmethod_19(bool bool_0)
	{
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE7EB8", Offset = "0x2AE7EB8", VA = "0x2AE7EB8", Slot = "24")]
	[Token(Token = "0x60002F1")]
	public virtual void vmethod_20(bool bool_0)
	{
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x0000A47C File Offset: 0x0000867C
	[Address(RVA = "0x2AE52E4", Offset = "0x2AE52E4", VA = "0x2AE52E4")]
	[Token(Token = "0x60002F2")]
	private void method_60(bool bool_0, float float_1, float float_2)
	{
		this.method_49(bool_0, float_1, float_2);
	}

	// Token: 0x060002F3 RID: 755 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002F3")]
	[Address(RVA = "0x2AE7EBC", Offset = "0x2AE7EBC", VA = "0x2AE7EBC")]
	private IEnumerator method_61(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002F4 RID: 756 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE54BC", Offset = "0x2AE54BC", VA = "0x2AE54BC")]
	[Token(Token = "0x60002F4")]
	private IEnumerator method_62(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002F5 RID: 757 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x60002F5")]
	[Address(RVA = "0x2AE7F60", Offset = "0x2AE7F60", VA = "0x2AE7F60")]
	private IEnumerator method_63(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x060002F6 RID: 758 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE8004", Offset = "0x2AE8004", VA = "0x2AE8004", Slot = "25")]
	[Token(Token = "0x60002F6")]
	public virtual void vmethod_21(bool bool_0)
	{
	}

	// Token: 0x060002F7 RID: 759 RVA: 0x0000A494 File Offset: 0x00008694
	[Token(Token = "0x60002F7")]
	[Address(RVA = "0x2AE8008", Offset = "0x2AE8008", VA = "0x2AE8008")]
	private void method_64(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_39(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002F8 RID: 760 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE8038", Offset = "0x2AE8038", VA = "0x2AE8038", Slot = "26")]
	[Token(Token = "0x60002F8")]
	public virtual void vmethod_22(bool bool_0)
	{
	}

	// Token: 0x060002F9 RID: 761 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60002F9")]
	[Address(RVA = "0x2AE803C", Offset = "0x2AE803C", VA = "0x2AE803C", Slot = "27")]
	public virtual void vmethod_23(bool bool_0)
	{
	}

	// Token: 0x060002FA RID: 762 RVA: 0x00009F10 File Offset: 0x00008110
	[Address(RVA = "0x2AE6250", Offset = "0x2AE6250", VA = "0x2AE6250")]
	[Token(Token = "0x60002FA")]
	private void method_65(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_84(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002FB RID: 763 RVA: 0x00009D50 File Offset: 0x00007F50
	[Address(RVA = "0x2AE7D68", Offset = "0x2AE7D68", VA = "0x2AE7D68")]
	[Token(Token = "0x60002FB")]
	private void method_66(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_62(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002FC RID: 764 RVA: 0x0000A4B4 File Offset: 0x000086B4
	[Address(RVA = "0x2AE8040", Offset = "0x2AE8040", VA = "0x2AE8040")]
	[Token(Token = "0x60002FC")]
	private void method_67(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_105(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002FD RID: 765 RVA: 0x0000A4D4 File Offset: 0x000086D4
	[Address(RVA = "0x2AE8114", Offset = "0x2AE8114", VA = "0x2AE8114")]
	[Token(Token = "0x60002FD")]
	private void method_68(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		base.StartCoroutine("Stopped Colliding");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x060002FE RID: 766 RVA: 0x00009D50 File Offset: 0x00007F50
	[Address(RVA = "0x2AE6B40", Offset = "0x2AE6B40", VA = "0x2AE6B40")]
	[Token(Token = "0x60002FE")]
	private void method_69(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_62(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x060002FF RID: 767 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x60002FF")]
	[Address(RVA = "0x2AE823C", Offset = "0x2AE823C", VA = "0x2AE823C")]
	private IEnumerator method_70()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000300 RID: 768 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000300")]
	[Address(RVA = "0x2AE82B4", Offset = "0x2AE82B4", VA = "0x2AE82B4", Slot = "28")]
	public virtual void vmethod_24(bool bool_0)
	{
	}

	// Token: 0x06000301 RID: 769 RVA: 0x0000A524 File Offset: 0x00008724
	[Token(Token = "0x6000301")]
	[Address(RVA = "0x2AE82B8", Offset = "0x2AE82B8", VA = "0x2AE82B8")]
	private IEnumerator method_71(bool bool_0, float float_1, float float_2)
	{
		new CapuchinButton.Class4((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x06000302 RID: 770 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000302")]
	[Address(RVA = "0x2AE835C", Offset = "0x2AE835C", VA = "0x2AE835C", Slot = "29")]
	public virtual void vmethod_25()
	{
	}

	// Token: 0x06000303 RID: 771 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000303")]
	[Address(RVA = "0x2AE8360", Offset = "0x2AE8360", VA = "0x2AE8360", Slot = "30")]
	public virtual void vmethod_26(bool bool_0)
	{
	}

	// Token: 0x06000304 RID: 772 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE8364", Offset = "0x2AE8364", VA = "0x2AE8364", Slot = "31")]
	[Token(Token = "0x6000304")]
	public virtual void vmethod_27()
	{
	}

	// Token: 0x06000305 RID: 773 RVA: 0x0000A494 File Offset: 0x00008694
	[Address(RVA = "0x2AE658C", Offset = "0x2AE658C", VA = "0x2AE658C")]
	[Token(Token = "0x6000305")]
	private void method_72(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_39(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x06000306 RID: 774 RVA: 0x0000A4B4 File Offset: 0x000086B4
	[Address(RVA = "0x2AE746C", Offset = "0x2AE746C", VA = "0x2AE746C")]
	[Token(Token = "0x6000306")]
	private void method_73(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_105(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x06000307 RID: 775 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x6000307")]
	[Address(RVA = "0x2AE8368", Offset = "0x2AE8368", VA = "0x2AE8368")]
	private IEnumerator method_74()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000308 RID: 776 RVA: 0x0000A548 File Offset: 0x00008748
	[Address(RVA = "0x2AE83E0", Offset = "0x2AE83E0", VA = "0x2AE83E0")]
	[Token(Token = "0x6000308")]
	private void method_75(Collider collider_0)
	{
		collider_0.gameObject.tag == "Connected to Server.";
		base.StartCoroutine("Collided");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000309 RID: 777 RVA: 0x0000A598 File Offset: 0x00008798
	[Token(Token = "0x6000309")]
	[Address(RVA = "0x2AE8508", Offset = "0x2AE8508", VA = "0x2AE8508")]
	private void method_76(Collider collider_0)
	{
		collider_0.gameObject.tag == "Error";
		base.StartCoroutine("ChangeToTagged");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x0600030A RID: 778 RVA: 0x0000A5E8 File Offset: 0x000087E8
	[Address(RVA = "0x2AE8630", Offset = "0x2AE8630", VA = "0x2AE8630")]
	[Token(Token = "0x600030A")]
	private void method_77(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_58(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x0600030B RID: 779 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600030B")]
	[Address(RVA = "0x2AE8660", Offset = "0x2AE8660", VA = "0x2AE8660", Slot = "32")]
	public virtual void vmethod_28()
	{
	}

	// Token: 0x0600030C RID: 780 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600030C")]
	[Address(RVA = "0x2AE8664", Offset = "0x2AE8664", VA = "0x2AE8664", Slot = "33")]
	public virtual void vmethod_29(bool bool_0)
	{
	}

	// Token: 0x0600030D RID: 781 RVA: 0x0000A608 File Offset: 0x00008808
	[Address(RVA = "0x2AE8668", Offset = "0x2AE8668", VA = "0x2AE8668")]
	[Token(Token = "0x600030D")]
	private void method_78(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		base.StartCoroutine("true");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x0600030E RID: 782 RVA: 0x0000A650 File Offset: 0x00008850
	[Address(RVA = "0x2AE8790", Offset = "0x2AE8790", VA = "0x2AE8790")]
	[Token(Token = "0x600030E")]
	private void method_79(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		base.StartCoroutine("Removing ");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x0600030F RID: 783 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600030F")]
	[Address(RVA = "0x2AE88B8", Offset = "0x2AE88B8", VA = "0x2AE88B8", Slot = "34")]
	public virtual void vmethod_30(bool bool_0)
	{
	}

	// Token: 0x06000310 RID: 784 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000310")]
	[Address(RVA = "0x2AE88BC", Offset = "0x2AE88BC", VA = "0x2AE88BC", Slot = "35")]
	public virtual void vmethod_31()
	{
	}

	// Token: 0x06000311 RID: 785 RVA: 0x0000A6A0 File Offset: 0x000088A0
	[Token(Token = "0x6000311")]
	[Address(RVA = "0x2AE88C0", Offset = "0x2AE88C0", VA = "0x2AE88C0")]
	private void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		base.StartCoroutine("؁ӵ࡜Ճ");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000312 RID: 786 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2AE89E8", Offset = "0x2AE89E8", VA = "0x2AE89E8")]
	[Token(Token = "0x6000312")]
	public CapuchinButton()
	{
	}

	// Token: 0x06000313 RID: 787 RVA: 0x0000A6F0 File Offset: 0x000088F0
	[Token(Token = "0x6000313")]
	[Address(RVA = "0x2AE89FC", Offset = "0x2AE89FC", VA = "0x2AE89FC")]
	private void method_80(Collider collider_0)
	{
		collider_0.gameObject.tag == "Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}";
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000314 RID: 788 RVA: 0x00009FD0 File Offset: 0x000081D0
	[Address(RVA = "0x2AE5768", Offset = "0x2AE5768", VA = "0x2AE5768")]
	[Token(Token = "0x6000314")]
	private void method_81(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_2(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x06000315 RID: 789 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE8B24", Offset = "0x2AE8B24", VA = "0x2AE8B24")]
	[Token(Token = "0x6000315")]
	private IEnumerator method_82()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000316 RID: 790 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE8B9C", Offset = "0x2AE8B9C", VA = "0x2AE8B9C", Slot = "36")]
	[Token(Token = "0x6000316")]
	public virtual void vmethod_32()
	{
	}

	// Token: 0x06000317 RID: 791 RVA: 0x0000A72C File Offset: 0x0000892C
	[Address(RVA = "0x2AE8BA0", Offset = "0x2AE8BA0", VA = "0x2AE8BA0")]
	[Token(Token = "0x6000317")]
	private void method_83(Collider collider_0)
	{
		collider_0.gameObject.tag == "Version";
		base.StartCoroutine("Add/Remove Sword");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000318 RID: 792 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x6000318")]
	[Address(RVA = "0x2AE5F5C", Offset = "0x2AE5F5C", VA = "0x2AE5F5C")]
	private IEnumerator method_84(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000319 RID: 793 RVA: 0x0000A77C File Offset: 0x0000897C
	[Address(RVA = "0x2AE8CC8", Offset = "0x2AE8CC8", VA = "0x2AE8CC8")]
	[Token(Token = "0x6000319")]
	private void method_85(Collider collider_0)
	{
		collider_0.gameObject.tag == "Room1";
		base.StartCoroutine("DisableCosmetic");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x0600031A RID: 794 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE7958", Offset = "0x2AE7958", VA = "0x2AE7958")]
	[Token(Token = "0x600031A")]
	private IEnumerator method_86(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600031B RID: 795 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE8E20", Offset = "0x2AE8E20", VA = "0x2AE8E20")]
	[Token(Token = "0x600031B")]
	private IEnumerator method_87()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600031C RID: 796 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE8E98", Offset = "0x2AE8E98", VA = "0x2AE8E98", Slot = "37")]
	[Token(Token = "0x600031C")]
	public virtual void vmethod_33()
	{
	}

	// Token: 0x0600031D RID: 797 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE8E9C", Offset = "0x2AE8E9C", VA = "0x2AE8E9C")]
	[Token(Token = "0x600031D")]
	private IEnumerator method_88()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600031E RID: 798 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE8F14", Offset = "0x2AE8F14", VA = "0x2AE8F14")]
	[Token(Token = "0x600031E")]
	private IEnumerator method_89()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600031F RID: 799 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE8F8C", Offset = "0x2AE8F8C", VA = "0x2AE8F8C", Slot = "38")]
	[Token(Token = "0x600031F")]
	public virtual void vmethod_34()
	{
	}

	// Token: 0x06000320 RID: 800 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x6000320")]
	[Address(RVA = "0x2AE8F90", Offset = "0x2AE8F90", VA = "0x2AE8F90")]
	private IEnumerator method_90()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000321 RID: 801 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE9008", Offset = "0x2AE9008", VA = "0x2AE9008", Slot = "39")]
	[Token(Token = "0x6000321")]
	public virtual void vmethod_35()
	{
	}

	// Token: 0x06000322 RID: 802 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000322")]
	[Address(RVA = "0x2AE900C", Offset = "0x2AE900C", VA = "0x2AE900C", Slot = "40")]
	public virtual void vmethod_36()
	{
	}

	// Token: 0x06000323 RID: 803 RVA: 0x0000A7CC File Offset: 0x000089CC
	[Address(RVA = "0x2AE9010", Offset = "0x2AE9010", VA = "0x2AE9010")]
	[Token(Token = "0x6000323")]
	private void method_91(Collider collider_0)
	{
		collider_0.gameObject.tag == "containsStaff";
		base.StartCoroutine("typesOfTalk");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000324 RID: 804 RVA: 0x0000A81C File Offset: 0x00008A1C
	[Address(RVA = "0x2AE9134", Offset = "0x2AE9134", VA = "0x2AE9134")]
	[Token(Token = "0x6000324")]
	private void method_92(Collider collider_0)
	{
		collider_0.gameObject.tag == "NetworkGunShoot";
		base.StartCoroutine("FLSPTLT");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000325 RID: 805 RVA: 0x0000A86C File Offset: 0x00008A6C
	[Token(Token = "0x6000325")]
	[Address(RVA = "0x2AE925C", Offset = "0x2AE925C", VA = "0x2AE925C")]
	private void method_93(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "StartGamemode";
		base.StartCoroutine("1BN");
		IEnumerator routine;
		base.StartCoroutine(routine);
	}

	// Token: 0x06000326 RID: 806 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE9380", Offset = "0x2AE9380", VA = "0x2AE9380", Slot = "41")]
	[Token(Token = "0x6000326")]
	public virtual void vmethod_37(bool bool_0)
	{
	}

	// Token: 0x06000327 RID: 807 RVA: 0x0000A8A0 File Offset: 0x00008AA0
	[Address(RVA = "0x2AE9384", Offset = "0x2AE9384", VA = "0x2AE9384")]
	[Token(Token = "0x6000327")]
	private void method_94(Collider collider_0)
	{
		collider_0.gameObject.tag == "goUpRPC";
		base.StartCoroutine("BLUTARG");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000328 RID: 808 RVA: 0x0000A8F0 File Offset: 0x00008AF0
	[Token(Token = "0x6000328")]
	[Address(RVA = "0x2AE94AC", Offset = "0x2AE94AC", VA = "0x2AE94AC")]
	private void method_95(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_55(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x06000329 RID: 809 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000329")]
	[Address(RVA = "0x2AE94DC", Offset = "0x2AE94DC", VA = "0x2AE94DC", Slot = "42")]
	public virtual void vmethod_38(bool bool_0)
	{
	}

	// Token: 0x0600032A RID: 810 RVA: 0x00009E80 File Offset: 0x00008080
	[Address(RVA = "0x2AE94E0", Offset = "0x2AE94E0", VA = "0x2AE94E0")]
	[Token(Token = "0x600032A")]
	private IEnumerator method_96()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600032B RID: 811 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE9558", Offset = "0x2AE9558", VA = "0x2AE9558", Slot = "43")]
	[Token(Token = "0x600032B")]
	public virtual void vmethod_39()
	{
	}

	// Token: 0x0600032C RID: 812 RVA: 0x0000A4B4 File Offset: 0x000086B4
	[Address(RVA = "0x2AE8DF0", Offset = "0x2AE8DF0", VA = "0x2AE8DF0")]
	[Token(Token = "0x600032C")]
	private void method_97(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_105(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x0600032D RID: 813 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE955C", Offset = "0x2AE955C", VA = "0x2AE955C", Slot = "44")]
	[Token(Token = "0x600032D")]
	public virtual void vmethod_40(bool bool_0)
	{
	}

	// Token: 0x0600032E RID: 814 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE9560", Offset = "0x2AE9560", VA = "0x2AE9560", Slot = "45")]
	[Token(Token = "0x600032E")]
	public virtual void vmethod_41()
	{
	}

	// Token: 0x0600032F RID: 815 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Address(RVA = "0x2AE9564", Offset = "0x2AE9564", VA = "0x2AE9564")]
	[Token(Token = "0x600032F")]
	private IEnumerator method_98(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0000A910 File Offset: 0x00008B10
	[Token(Token = "0x6000330")]
	[Address(RVA = "0x2AE9608", Offset = "0x2AE9608", VA = "0x2AE9608")]
	private void method_99(bool bool_0, float float_1, float float_2)
	{
		IEnumerator routine = this.method_71(bool_0, float_1, float_2);
		base.StartCoroutine(routine);
	}

	// Token: 0x06000331 RID: 817 RVA: 0x0000A930 File Offset: 0x00008B30
	[Token(Token = "0x6000331")]
	[Address(RVA = "0x2AE9638", Offset = "0x2AE9638", VA = "0x2AE9638")]
	private void method_100(Collider collider_0)
	{
		collider_0.gameObject.tag == "Photon token acquired!";
		base.StartCoroutine("Player");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000332 RID: 818 RVA: 0x00009E80 File Offset: 0x00008080
	[Token(Token = "0x6000332")]
	[Address(RVA = "0x2AE9760", Offset = "0x2AE9760", VA = "0x2AE9760")]
	private IEnumerator method_101()
	{
		CapuchinButton.Class3 @class = new CapuchinButton.Class3((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000333 RID: 819 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE97D8", Offset = "0x2AE97D8", VA = "0x2AE97D8", Slot = "46")]
	[Token(Token = "0x6000333")]
	public virtual void vmethod_42()
	{
	}

	// Token: 0x06000334 RID: 820 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000334")]
	[Address(RVA = "0x2AE97DC", Offset = "0x2AE97DC", VA = "0x2AE97DC", Slot = "47")]
	public virtual void vmethod_43()
	{
	}

	// Token: 0x06000335 RID: 821 RVA: 0x0000A980 File Offset: 0x00008B80
	[Token(Token = "0x6000335")]
	[Address(RVA = "0x2AE97E0", Offset = "0x2AE97E0", VA = "0x2AE97E0")]
	private void method_102(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000336 RID: 822 RVA: 0x0000A9BC File Offset: 0x00008BBC
	[Address(RVA = "0x2AE98F4", Offset = "0x2AE98F4", VA = "0x2AE98F4")]
	[Token(Token = "0x6000336")]
	private void method_103(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "ChangeToTagged";
		base.StartCoroutine("A Player has left the Room.");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000337 RID: 823 RVA: 0x0000AA08 File Offset: 0x00008C08
	[Token(Token = "0x6000337")]
	[Address(RVA = "0x2AE9A1C", Offset = "0x2AE9A1C", VA = "0x2AE9A1C")]
	private void method_104(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Tint";
		base.StartCoroutine("ࡉٝܭ۲");
		bool bool_ = collider_0.GetComponent<PhysicsHand>().bool_3;
		IEnumerator routine;
		base.StartCoroutine(routine);
		bool bool_2 = collider_0.GetComponent<PhysicsHand>().bool_3;
	}

	// Token: 0x06000338 RID: 824 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AE9B44", Offset = "0x2AE9B44", VA = "0x2AE9B44", Slot = "48")]
	[Token(Token = "0x6000338")]
	public virtual void vmethod_44(bool bool_0)
	{
	}

	// Token: 0x06000339 RID: 825 RVA: 0x00009D1C File Offset: 0x00007F1C
	[Token(Token = "0x6000339")]
	[Address(RVA = "0x2AE8070", Offset = "0x2AE8070", VA = "0x2AE8070")]
	private IEnumerator method_105(bool bool_0, float float_1, float float_2)
	{
		CapuchinButton.Class4 @class = new CapuchinButton.Class4((int)0L);
		@class.<>4__this = this;
		@class.forLeftController = (typeof(CapuchinButton.Class4).TypeHandle != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600033A RID: 826 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600033A")]
	[Address(RVA = "0x2AE9B48", Offset = "0x2AE9B48", VA = "0x2AE9B48", Slot = "49")]
	public virtual void vmethod_45(bool bool_0)
	{
	}

	// Token: 0x0400005D RID: 93
	[Token(Token = "0x400005D")]
	[FieldOffset(Offset = "0x18")]
	private float float_0;
}
