﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000C8 RID: 200
[Token(Token = "0x20000C8")]
public class ElevatorManager : MonoBehaviour
{
	// Token: 0x06001C59 RID: 7257 RVA: 0x00035C0C File Offset: 0x00033E0C
	[Address(RVA = "0x10D5250", Offset = "0x10D5250", VA = "0x10D5250")]
	[Token(Token = "0x6001C59")]
	public void method_0()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 0L;
			boxCollider2.enabled = (enabled2 != 0L);
			this.float_0 = (float)16384;
		}
	}

	// Token: 0x06001C5A RID: 7258 RVA: 0x00035C58 File Offset: 0x00033E58
	[Address(RVA = "0x10D52DC", Offset = "0x10D52DC", VA = "0x10D52DC")]
	[Token(Token = "0x6001C5A")]
	public void method_1()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 0L;
			boxCollider2.enabled = (enabled2 != 0L);
			long num = 1L;
			this.float_0 = (float)32768;
			this.bool_2 = (num != 0L);
		}
	}

	// Token: 0x06001C5B RID: 7259 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D536C", Offset = "0x10D536C", VA = "0x10D536C")]
	[Token(Token = "0x6001C5B")]
	public void method_2()
	{
	}

	// Token: 0x06001C5C RID: 7260 RVA: 0x00035CC0 File Offset: 0x00033EC0
	[Address(RVA = "0x10D546C", Offset = "0x10D546C", VA = "0x10D546C")]
	[Token(Token = "0x6001C5C")]
	public void method_3()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 0L;
			boxCollider2.enabled = (enabled2 != 0L);
			this.float_0 = (float)32768;
		}
	}

	// Token: 0x06001C5D RID: 7261 RVA: 0x00035D0C File Offset: 0x00033F0C
	[Address(RVA = "0x10D54F8", Offset = "0x10D54F8", VA = "0x10D54F8")]
	[Token(Token = "0x6001C5D")]
	public void method_4()
	{
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
		BoxCollider boxCollider = this.boxCollider_1;
		this.bool_2 = (num != 0L);
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 1L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C5E RID: 7262 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D209C", Offset = "0x10D209C", VA = "0x10D209C")]
	[Token(Token = "0x6001C5E")]
	public void method_5()
	{
	}

	// Token: 0x06001C5F RID: 7263 RVA: 0x00035D54 File Offset: 0x00033F54
	[Address(RVA = "0x10D5550", Offset = "0x10D5550", VA = "0x10D5550")]
	[Token(Token = "0x6001C5F")]
	public void method_6()
	{
		BoxCollider boxCollider = this.boxCollider_1;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 1L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C60 RID: 7264 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D1AE4", Offset = "0x10D1AE4", VA = "0x10D1AE4")]
	[Token(Token = "0x6001C60")]
	public void method_7()
	{
	}

	// Token: 0x06001C61 RID: 7265 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D2378", Offset = "0x10D2378", VA = "0x10D2378")]
	[Token(Token = "0x6001C61")]
	public void method_8()
	{
	}

	// Token: 0x06001C62 RID: 7266 RVA: 0x00035D84 File Offset: 0x00033F84
	[Address(RVA = "0x10D55A4", Offset = "0x10D55A4", VA = "0x10D55A4")]
	[Token(Token = "0x6001C62")]
	public void method_9()
	{
		BoxCollider boxCollider = this.boxCollider_1;
		long num = 1L;
		this.bool_2 = (num != 0L);
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 0L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C63 RID: 7267 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D2730", Offset = "0x10D2730", VA = "0x10D2730")]
	[Token(Token = "0x6001C63")]
	public void method_10()
	{
	}

	// Token: 0x06001C64 RID: 7268 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D142C", Offset = "0x10D142C", VA = "0x10D142C")]
	[Token(Token = "0x6001C64")]
	public void method_11()
	{
	}

	// Token: 0x06001C65 RID: 7269 RVA: 0x00035DC0 File Offset: 0x00033FC0
	[PunRPC]
	[Address(RVA = "0x10D55FC", Offset = "0x10D55FC", VA = "0x10D55FC")]
	[Token(Token = "0x6001C65")]
	public void goUpRPC()
	{
		BoxCollider boxCollider = this.boxCollider_1;
		long num = 1L;
		this.bool_2 = (num != 0L);
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		long enabled2 = 0L;
		boxCollider.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C66 RID: 7270 RVA: 0x00035DF4 File Offset: 0x00033FF4
	[Address(RVA = "0x10D5654", Offset = "0x10D5654", VA = "0x10D5654")]
	[Token(Token = "0x6001C66")]
	public void method_12()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			long num = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 0L;
			boxCollider2.enabled = (enabled2 != 0L);
			this.float_0 = (float)32768;
			this.bool_2 = (num != 0L);
		}
	}

	// Token: 0x06001C67 RID: 7271 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D152C", Offset = "0x10D152C", VA = "0x10D152C")]
	[Token(Token = "0x6001C67")]
	public void method_13()
	{
	}

	// Token: 0x06001C68 RID: 7272 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D1808", Offset = "0x10D1808", VA = "0x10D1808")]
	[Token(Token = "0x6001C68")]
	public void method_14()
	{
	}

	// Token: 0x06001C69 RID: 7273 RVA: 0x00035E4C File Offset: 0x0003404C
	[Address(RVA = "0x10D56E4", Offset = "0x10D56E4", VA = "0x10D56E4")]
	[Token(Token = "0x6001C69")]
	public void method_15()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 1L;
			long num = 1L;
			boxCollider2.enabled = (enabled2 != 0L);
			this.float_0 = (float)16384;
			this.bool_2 = (num != 0L);
		}
	}

	// Token: 0x06001C6A RID: 7274 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D290C", Offset = "0x10D290C", VA = "0x10D290C")]
	[Token(Token = "0x6001C6A")]
	public void method_16()
	{
	}

	// Token: 0x06001C6B RID: 7275 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D2F58", Offset = "0x10D2F58", VA = "0x10D2F58")]
	[Token(Token = "0x6001C6B")]
	public void method_17()
	{
	}

	// Token: 0x06001C6C RID: 7276 RVA: 0x00035EA4 File Offset: 0x000340A4
	[Address(RVA = "0x10D5770", Offset = "0x10D5770", VA = "0x10D5770")]
	[Token(Token = "0x6001C6C")]
	public void Update()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 1L;
			boxCollider2.enabled = (enabled2 != 0L);
			this.float_0 = (float)16800;
		}
	}

	// Token: 0x06001C6D RID: 7277 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D1CC0", Offset = "0x10D1CC0", VA = "0x10D1CC0")]
	[Token(Token = "0x6001C6D")]
	public void method_18()
	{
	}

	// Token: 0x06001C6E RID: 7278 RVA: 0x00035EF0 File Offset: 0x000340F0
	[PunRPC]
	[Address(RVA = "0x10D57F0", Offset = "0x10D57F0", VA = "0x10D57F0")]
	[Token(Token = "0x6001C6E")]
	public void goDownRPC()
	{
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
		BoxCollider boxCollider = this.boxCollider_1;
		this.bool_2 = (num != 0L);
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 0L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C6F RID: 7279 RVA: 0x000029F7 File Offset: 0x00000BF7
	[Address(RVA = "0x10D5848", Offset = "0x10D5848", VA = "0x10D5848")]
	[Token(Token = "0x6001C6F")]
	public ElevatorManager()
	{
	}

	// Token: 0x06001C70 RID: 7280 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D19E4", Offset = "0x10D19E4", VA = "0x10D19E4")]
	[Token(Token = "0x6001C70")]
	public void method_19()
	{
	}

	// Token: 0x06001C71 RID: 7281 RVA: 0x00035F38 File Offset: 0x00034138
	[Address(RVA = "0x10D5858", Offset = "0x10D5858", VA = "0x10D5858")]
	[Token(Token = "0x6001C71")]
	public void method_20()
	{
		BoxCollider boxCollider = this.boxCollider_1;
		long num = 1L;
		this.bool_2 = (num != 0L);
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 0L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C72 RID: 7282 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D2554", Offset = "0x10D2554", VA = "0x10D2554")]
	[Token(Token = "0x6001C72")]
	public void method_21()
	{
	}

	// Token: 0x06001C73 RID: 7283 RVA: 0x00035F74 File Offset: 0x00034174
	[Address(RVA = "0x10D58B0", Offset = "0x10D58B0", VA = "0x10D58B0")]
	[Token(Token = "0x6001C73")]
	public void method_22()
	{
		BoxCollider boxCollider = this.boxCollider_1;
		long num = 1L;
		this.bool_2 = (num != 0L);
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 1L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C74 RID: 7284 RVA: 0x00035FAC File Offset: 0x000341AC
	[Address(RVA = "0x10D5908", Offset = "0x10D5908", VA = "0x10D5908")]
	[Token(Token = "0x6001C74")]
	public void method_23()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 1L;
			long num = 1L;
			boxCollider2.enabled = (enabled2 != 0L);
			this.float_0 = (float)16688;
			this.bool_2 = (num != 0L);
		}
	}

	// Token: 0x06001C75 RID: 7285 RVA: 0x00036004 File Offset: 0x00034204
	[Address(RVA = "0x10D5994", Offset = "0x10D5994", VA = "0x10D5994")]
	[Token(Token = "0x6001C75")]
	public void method_24()
	{
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
		BoxCollider boxCollider = this.boxCollider_1;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 0L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C76 RID: 7286 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D1708", Offset = "0x10D1708", VA = "0x10D1708")]
	[Token(Token = "0x6001C76")]
	public void method_25()
	{
	}

	// Token: 0x06001C77 RID: 7287 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D2278", Offset = "0x10D2278", VA = "0x10D2278")]
	[Token(Token = "0x6001C77")]
	public void method_26()
	{
	}

	// Token: 0x06001C78 RID: 7288 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D59EC", Offset = "0x10D59EC", VA = "0x10D59EC")]
	[Token(Token = "0x6001C78")]
	public void method_27()
	{
	}

	// Token: 0x06001C79 RID: 7289 RVA: 0x00036048 File Offset: 0x00034248
	[Address(RVA = "0x10D5AEC", Offset = "0x10D5AEC", VA = "0x10D5AEC")]
	[Token(Token = "0x6001C79")]
	public void method_28()
	{
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
		BoxCollider boxCollider = this.boxCollider_1;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 1L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C7A RID: 7290 RVA: 0x00035C58 File Offset: 0x00033E58
	[Address(RVA = "0x10D5B44", Offset = "0x10D5B44", VA = "0x10D5B44")]
	[Token(Token = "0x6001C7A")]
	public void method_29()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 0L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 0L;
			boxCollider2.enabled = (enabled2 != 0L);
			long num = 1L;
			this.float_0 = (float)32768;
			this.bool_2 = (num != 0L);
		}
	}

	// Token: 0x06001C7B RID: 7291 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D1F9C", Offset = "0x10D1F9C", VA = "0x10D1F9C")]
	[Token(Token = "0x6001C7B")]
	public void method_30()
	{
	}

	// Token: 0x06001C7C RID: 7292 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D3680", Offset = "0x10D3680", VA = "0x10D3680")]
	[Token(Token = "0x6001C7C")]
	public void method_31()
	{
	}

	// Token: 0x06001C7D RID: 7293 RVA: 0x0003608C File Offset: 0x0003428C
	[Address(RVA = "0x10D5BD4", Offset = "0x10D5BD4", VA = "0x10D5BD4")]
	[Token(Token = "0x6001C7D")]
	public void method_32()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			BoxCollider boxCollider = this.boxCollider_0;
			long enabled = 1L;
			long num = 1L;
			boxCollider.enabled = (enabled != 0L);
			BoxCollider boxCollider2 = this.boxCollider_1;
			long enabled2 = 1L;
			boxCollider2.enabled = (enabled2 != 0L);
			this.float_0 = (float)32768;
			this.bool_2 = (num != 0L);
		}
	}

	// Token: 0x06001C7E RID: 7294 RVA: 0x00036004 File Offset: 0x00034204
	[Address(RVA = "0x10D5C64", Offset = "0x10D5C64", VA = "0x10D5C64")]
	[Token(Token = "0x6001C7E")]
	public void method_33()
	{
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
		BoxCollider boxCollider = this.boxCollider_1;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 0L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C7F RID: 7295 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D3D8C", Offset = "0x10D3D8C", VA = "0x10D3D8C")]
	[Token(Token = "0x6001C7F")]
	public void method_34()
	{
	}

	// Token: 0x06001C80 RID: 7296 RVA: 0x000360E4 File Offset: 0x000342E4
	[Address(RVA = "0x10D5CBC", Offset = "0x10D5CBC", VA = "0x10D5CBC")]
	[Token(Token = "0x6001C80")]
	public void method_35()
	{
		BoxCollider boxCollider = this.boxCollider_1;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 0L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C81 RID: 7297 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D1DC0", Offset = "0x10D1DC0", VA = "0x10D1DC0")]
	[Token(Token = "0x6001C81")]
	public void method_36()
	{
	}

	// Token: 0x06001C82 RID: 7298 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D2AE8", Offset = "0x10D2AE8", VA = "0x10D2AE8")]
	[Token(Token = "0x6001C82")]
	public void method_37()
	{
	}

	// Token: 0x06001C83 RID: 7299 RVA: 0x00036114 File Offset: 0x00034314
	[Address(RVA = "0x10D5D10", Offset = "0x10D5D10", VA = "0x10D5D10")]
	[Token(Token = "0x6001C83")]
	public void method_38()
	{
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
		BoxCollider boxCollider = this.boxCollider_1;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 1L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C84 RID: 7300 RVA: 0x00036158 File Offset: 0x00034358
	[Address(RVA = "0x10D5D68", Offset = "0x10D5D68", VA = "0x10D5D68")]
	[Token(Token = "0x6001C84")]
	public void method_39()
	{
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
		BoxCollider boxCollider = this.boxCollider_1;
		this.bool_2 = (num != 0L);
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
		BoxCollider boxCollider2 = this.boxCollider_0;
		long enabled2 = 0L;
		boxCollider2.enabled = (enabled2 != 0L);
	}

	// Token: 0x06001C85 RID: 7301 RVA: 0x00035CB0 File Offset: 0x00033EB0
	[Address(RVA = "0x10D33C8", Offset = "0x10D33C8", VA = "0x10D33C8")]
	[Token(Token = "0x6001C85")]
	public void method_40()
	{
	}

	// Token: 0x040003DC RID: 988
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003DC")]
	public bool bool_0;

	// Token: 0x040003DD RID: 989
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x40003DD")]
	public bool bool_1;

	// Token: 0x040003DE RID: 990
	[Token(Token = "0x40003DE")]
	[FieldOffset(Offset = "0x20")]
	public DoorLerp doorLerp_0;

	// Token: 0x040003DF RID: 991
	[Token(Token = "0x40003DF")]
	[FieldOffset(Offset = "0x28")]
	public BoxCollider boxCollider_0;

	// Token: 0x040003E0 RID: 992
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003E0")]
	public BoxCollider boxCollider_1;

	// Token: 0x040003E1 RID: 993
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40003E1")]
	public PhotonView photonView_0;

	// Token: 0x040003E2 RID: 994
	[Token(Token = "0x40003E2")]
	[FieldOffset(Offset = "0x40")]
	public float float_0 = (float)16800;

	// Token: 0x040003E3 RID: 995
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x40003E3")]
	private bool bool_2;
}
