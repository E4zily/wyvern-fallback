﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000AD RID: 173
[Token(Token = "0x20000AD")]
public class CosmeticsController : MonoBehaviour
{
	// Token: 0x060018B8 RID: 6328 RVA: 0x00031EB0 File Offset: 0x000300B0
	[Address(RVA = "0x2A69EBC", Offset = "0x2A69EBC", VA = "0x2A69EBC")]
	[Token(Token = "0x60018B8")]
	public IEnumerator method_0()
	{
		/*
An exception occurred when decompiling this method (060018B8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::method_0()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class23(Class23::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060018B9 RID: 6329 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A69F18", Offset = "0x2A69F18", VA = "0x2A69F18")]
	[Token(Token = "0x60018B9")]
	public IEnumerator method_1()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018BA RID: 6330 RVA: 0x00031EF4 File Offset: 0x000300F4
	[Address(RVA = "0x2A69F90", Offset = "0x2A69F90", VA = "0x2A69F90")]
	[Token(Token = "0x60018BA")]
	private void method_2(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "Room1";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (flag)
		{
			return;
		}
		PlayerPrefs.SetString(this.string_0, "Mesh");
	}

	// Token: 0x060018BB RID: 6331 RVA: 0x00031F5C File Offset: 0x0003015C
	[Address(RVA = "0x2A6A1EC", Offset = "0x2A6A1EC", VA = "0x2A6A1EC")]
	[Token(Token = "0x60018BB")]
	private void method_3(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "Queue";
		Material material = base.GetComponent<Renderer>().material;
		if (this.bool_0)
		{
			string text = this.string_0;
			if (text == null || text != null)
			{
				return;
			}
		}
		else
		{
			string text2 = this.string_0;
			if (text2 == null || text2 != null)
			{
				PlayerPrefs.SetString(this.string_0, "SaveHeight");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060018BC RID: 6332 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6A484", Offset = "0x2A6A484", VA = "0x2A6A484")]
	[Token(Token = "0x60018BC")]
	public IEnumerator method_4()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018BD RID: 6333 RVA: 0x00031FD0 File Offset: 0x000301D0
	[Address(RVA = "0x2A6A4FC", Offset = "0x2A6A4FC", VA = "0x2A6A4FC")]
	[Token(Token = "0x60018BD")]
	private void method_5(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "PushToTalk";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (flag)
		{
			return;
		}
		PlayerPrefs.SetString(this.string_0, "Player");
	}

	// Token: 0x060018BE RID: 6334 RVA: 0x0000271D File Offset: 0x0000091D
	[Address(RVA = "0x2A6A774", Offset = "0x2A6A774", VA = "0x2A6A774")]
	[Token(Token = "0x60018BE")]
	public CosmeticsController()
	{
	}

	// Token: 0x060018BF RID: 6335 RVA: 0x00032038 File Offset: 0x00030238
	[Address(RVA = "0x2A6A788", Offset = "0x2A6A788", VA = "0x2A6A788")]
	[Token(Token = "0x60018BF")]
	private void method_6(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "Cannot access index {0}. Buffer size is {1}";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (flag)
		{
			return;
		}
		PlayerPrefs.SetString(this.string_0, "NetworkPlayer");
	}

	// Token: 0x060018C0 RID: 6336 RVA: 0x000320A0 File Offset: 0x000302A0
	[Address(RVA = "0x2A6AA00", Offset = "0x2A6AA00", VA = "0x2A6AA00")]
	[Token(Token = "0x60018C0")]
	private void method_7(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "hand 2";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		PhotonView photonView = this.photonView_0;
		if (flag)
		{
			object[] parameters = new object[1];
			string text = this.string_0;
			if (text == null || text != null)
			{
				photonView.RPC("You struck apon an error. ", RpcTarget.AllViaServer, parameters);
				return;
			}
		}
		else
		{
			string text2 = this.string_0;
			if (text2 == null || text2 != null)
			{
				PlayerPrefs.SetString(this.string_0, "goUpRPC");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060018C1 RID: 6337 RVA: 0x00032138 File Offset: 0x00030338
	[Address(RVA = "0x2A6ACA0", Offset = "0x2A6ACA0", VA = "0x2A6ACA0")]
	[Token(Token = "0x60018C1")]
	private void method_8(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "forced knee retract";
		Material material = base.GetComponent<Renderer>().material;
		if (this.bool_0)
		{
			string text = this.string_0;
			if (text == null || text != null)
			{
				return;
			}
		}
		else
		{
			string text2 = this.string_0;
			if (text2 == null || text2 != null)
			{
				PlayerPrefs.SetString(this.string_0, "\n Time: ");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060018C2 RID: 6338 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6AF3C", Offset = "0x2A6AF3C", VA = "0x2A6AF3C")]
	[Token(Token = "0x60018C2")]
	public IEnumerator method_9()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018C3 RID: 6339 RVA: 0x000321AC File Offset: 0x000303AC
	[Address(RVA = "0x2A6AFB4", Offset = "0x2A6AFB4", VA = "0x2A6AFB4")]
	[Token(Token = "0x60018C3")]
	private void method_10(Collider collider_0)
	{
		Renderer renderer;
		Material material = renderer.material;
	}

	// Token: 0x060018C4 RID: 6340 RVA: 0x00031EB0 File Offset: 0x000300B0
	[Address(RVA = "0x2A6B068", Offset = "0x2A6B068", VA = "0x2A6B068")]
	[Token(Token = "0x60018C4")]
	public IEnumerator method_11()
	{
		/*
An exception occurred when decompiling this method (060018C4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::method_11()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class23(Class23::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060018C5 RID: 6341 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6B0C4", Offset = "0x2A6B0C4", VA = "0x2A6B0C4")]
	[Token(Token = "0x60018C5")]
	public IEnumerator method_12()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018C6 RID: 6342 RVA: 0x000321C0 File Offset: 0x000303C0
	[Address(RVA = "0x2A6B13C", Offset = "0x2A6B13C", VA = "0x2A6B13C")]
	[Token(Token = "0x60018C6")]
	private void method_13(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "Player";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (flag)
		{
			return;
		}
		PlayerPrefs.SetString(this.string_0, "This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
	}

	// Token: 0x060018C7 RID: 6343 RVA: 0x00032228 File Offset: 0x00030428
	[Address(RVA = "0x2A6B3A4", Offset = "0x2A6B3A4", VA = "0x2A6B3A4")]
	[Token(Token = "0x60018C7")]
	private void method_14()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
		}
		if (this.bool_1)
		{
			string text = this.string_0;
			if (text != null && text == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060018C8 RID: 6344 RVA: 0x00031EB0 File Offset: 0x000300B0
	[Address(RVA = "0x2A6B514", Offset = "0x2A6B514", VA = "0x2A6B514")]
	[Token(Token = "0x60018C8")]
	public IEnumerator method_15()
	{
		/*
An exception occurred when decompiling this method (060018C8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::method_15()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class23(Class23::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060018C9 RID: 6345 RVA: 0x00032228 File Offset: 0x00030428
	[Address(RVA = "0x2A6B570", Offset = "0x2A6B570", VA = "0x2A6B570")]
	[Token(Token = "0x60018C9")]
	private void Update()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
		}
		if (this.bool_1)
		{
			string text = this.string_0;
			if (text != null && text == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060018CA RID: 6346 RVA: 0x00032228 File Offset: 0x00030428
	[Address(RVA = "0x2A6B6DC", Offset = "0x2A6B6DC", VA = "0x2A6B6DC")]
	[Token(Token = "0x60018CA")]
	private void method_16()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
		}
		if (this.bool_1)
		{
			string text = this.string_0;
			if (text != null && text == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060018CB RID: 6347 RVA: 0x00031EB0 File Offset: 0x000300B0
	[Address(RVA = "0x2A6B848", Offset = "0x2A6B848", VA = "0x2A6B848")]
	[Token(Token = "0x60018CB")]
	public IEnumerator method_17()
	{
		/*
An exception occurred when decompiling this method (060018CB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::method_17()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class23(Class23::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060018CC RID: 6348 RVA: 0x0003227C File Offset: 0x0003047C
	[Address(RVA = "0x2A6B8A4", Offset = "0x2A6B8A4", VA = "0x2A6B8A4")]
	[Token(Token = "0x60018CC")]
	public void Start()
	{
		PlayerPrefs.GetString(this.string_0) == "true";
		IEnumerator routine = this.method_21();
		base.StartCoroutine(routine);
		PlayerPrefs.GetString(this.string_0) == "false";
		IEnumerator routine2;
		base.StartCoroutine(routine2);
	}

	// Token: 0x060018CD RID: 6349 RVA: 0x000322D0 File Offset: 0x000304D0
	[Address(RVA = "0x2A6B9E0", Offset = "0x2A6B9E0", VA = "0x2A6B9E0")]
	[Token(Token = "0x60018CD")]
	private void OnTriggerEnter(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "FingerTip";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (flag)
		{
			return;
		}
		PlayerPrefs.SetString(this.string_0, "false");
	}

	// Token: 0x060018CE RID: 6350 RVA: 0x00032338 File Offset: 0x00030538
	[Address(RVA = "0x2A6BC2C", Offset = "0x2A6BC2C", VA = "0x2A6BC2C")]
	[Token(Token = "0x60018CE")]
	private void method_18(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "You have been banned for ";
		Material material = base.GetComponent<Renderer>().material;
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
	}

	// Token: 0x060018CF RID: 6351 RVA: 0x00032384 File Offset: 0x00030584
	[Address(RVA = "0x2A6BE88", Offset = "0x2A6BE88", VA = "0x2A6BE88")]
	[Token(Token = "0x60018CF")]
	private void method_19(Collider collider_0)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060018D0 RID: 6352 RVA: 0x00031EB0 File Offset: 0x000300B0
	[Address(RVA = "0x2A6BF3C", Offset = "0x2A6BF3C", VA = "0x2A6BF3C")]
	[Token(Token = "0x60018D0")]
	public IEnumerator method_20()
	{
		/*
An exception occurred when decompiling this method (060018D0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::method_20()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class23(Class23::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x060018D1 RID: 6353 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6B968", Offset = "0x2A6B968", VA = "0x2A6B968")]
	[Token(Token = "0x60018D1")]
	public IEnumerator method_21()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018D2 RID: 6354 RVA: 0x000323A0 File Offset: 0x000305A0
	[Address(RVA = "0x2A6BF98", Offset = "0x2A6BF98", VA = "0x2A6BF98")]
	[Token(Token = "0x60018D2")]
	private void method_22(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "Diffuse";
		Material material = base.GetComponent<Renderer>().material;
		if (this.bool_0)
		{
			string text = this.string_0;
			if (text == null || text != null)
			{
				return;
			}
		}
		else
		{
			string text2 = this.string_0;
			if (text2 == null || text2 != null)
			{
				PlayerPrefs.SetString(this.string_0, "\n Time: ");
				return;
			}
		}
		throw new ArrayTypeMismatchException();
	}

	// Token: 0x060018D3 RID: 6355 RVA: 0x00032384 File Offset: 0x00030584
	[Address(RVA = "0x2A6C238", Offset = "0x2A6C238", VA = "0x2A6C238")]
	[Token(Token = "0x60018D3")]
	private void method_23(Collider collider_0)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060018D4 RID: 6356 RVA: 0x00032414 File Offset: 0x00030614
	[Address(RVA = "0x2A6C2EC", Offset = "0x2A6C2EC", VA = "0x2A6C2EC")]
	[Token(Token = "0x60018D4")]
	private void method_24()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
		}
		if (this.bool_1)
		{
			string text = this.string_0;
			if (text != null && text == null)
			{
				throw new ArrayTypeMismatchException();
			}
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x060018D5 RID: 6357 RVA: 0x00032474 File Offset: 0x00030674
	[Address(RVA = "0x2A6C460", Offset = "0x2A6C460", VA = "0x2A6C460")]
	[Token(Token = "0x60018D5")]
	public void method_25()
	{
		PlayerPrefs.GetString(this.string_0) == "username";
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
		PlayerPrefs.GetString(this.string_0) == "CapuchinRemade";
		IEnumerator routine2;
		base.StartCoroutine(routine2);
	}

	// Token: 0x060018D6 RID: 6358 RVA: 0x00032384 File Offset: 0x00030584
	[Address(RVA = "0x2A6C59C", Offset = "0x2A6C59C", VA = "0x2A6C59C")]
	[Token(Token = "0x60018D6")]
	private void method_26(Collider collider_0)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060018D7 RID: 6359 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6C650", Offset = "0x2A6C650", VA = "0x2A6C650")]
	[Token(Token = "0x60018D7")]
	public IEnumerator method_27()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018D8 RID: 6360 RVA: 0x000324C8 File Offset: 0x000306C8
	[Address(RVA = "0x2A6C6C8", Offset = "0x2A6C6C8", VA = "0x2A6C6C8")]
	[Token(Token = "0x60018D8")]
	private void method_28(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == " and for the price of ";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (flag)
		{
			return;
		}
		PlayerPrefs.SetString(this.string_0, "{0}/{1:f0}");
	}

	// Token: 0x060018D9 RID: 6361 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6C924", Offset = "0x2A6C924", VA = "0x2A6C924")]
	[Token(Token = "0x60018D9")]
	public IEnumerator method_29()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018DA RID: 6362 RVA: 0x00032530 File Offset: 0x00030730
	[Address(RVA = "0x2A6C99C", Offset = "0x2A6C99C", VA = "0x2A6C99C")]
	[Token(Token = "0x60018DA")]
	public void method_30()
	{
		PlayerPrefs.GetString(this.string_0) == "Queue";
		IEnumerator routine = this.method_12();
		base.StartCoroutine(routine);
		PlayerPrefs.GetString(this.string_0) == "Open";
		IEnumerator routine2;
		base.StartCoroutine(routine2);
	}

	// Token: 0x060018DB RID: 6363 RVA: 0x00032584 File Offset: 0x00030784
	[Address(RVA = "0x2A6CABC", Offset = "0x2A6CABC", VA = "0x2A6CABC")]
	[Token(Token = "0x60018DB")]
	private void method_31()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
		}
		if (this.bool_1)
		{
			string text = this.string_0;
			if (text != null && text == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060018DC RID: 6364 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6CC28", Offset = "0x2A6CC28", VA = "0x2A6CC28")]
	[Token(Token = "0x60018DC")]
	public IEnumerator method_32()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018DD RID: 6365 RVA: 0x000325D8 File Offset: 0x000307D8
	[Address(RVA = "0x2A6CCA0", Offset = "0x2A6CCA0", VA = "0x2A6CCA0")]
	[Token(Token = "0x60018DD")]
	private void method_33(Collider collider_0)
	{
		bool inRoom = PhotonNetwork.InRoom;
		collider_0.gameObject.tag == "/";
		Material material = base.GetComponent<Renderer>().material;
		bool flag = this.bool_0;
		PhotonView photonView = this.photonView_0;
		object[] parameters = new object[0];
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		if (flag)
		{
			return;
		}
		photonView.RPC("Player", RpcTarget.AllViaServer, parameters);
		PlayerPrefs.SetString(this.string_0, "On");
	}

	// Token: 0x060018DE RID: 6366 RVA: 0x00032384 File Offset: 0x00030584
	[Address(RVA = "0x2A6CEF0", Offset = "0x2A6CEF0", VA = "0x2A6CEF0")]
	[Token(Token = "0x60018DE")]
	private void method_34(Collider collider_0)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060018DF RID: 6367 RVA: 0x00032384 File Offset: 0x00030584
	[Address(RVA = "0x2A6CFA4", Offset = "0x2A6CFA4", VA = "0x2A6CFA4")]
	[Token(Token = "0x60018DF")]
	private void OnTriggerExit(Collider collider_0)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060018E0 RID: 6368 RVA: 0x00032384 File Offset: 0x00030584
	[Address(RVA = "0x2A6D054", Offset = "0x2A6D054", VA = "0x2A6D054")]
	[Token(Token = "0x60018E0")]
	private void method_35(Collider collider_0)
	{
		Material material = base.GetComponent<Renderer>().material;
	}

	// Token: 0x060018E1 RID: 6369 RVA: 0x00032660 File Offset: 0x00030860
	[Address(RVA = "0x2A6D108", Offset = "0x2A6D108", VA = "0x2A6D108")]
	[Token(Token = "0x60018E1")]
	public void method_36()
	{
		PlayerPrefs.GetString(this.string_0) == "Network Player";
		IEnumerator routine = this.method_12();
		base.StartCoroutine(routine);
		PlayerPrefs.GetString(this.string_0) == "/";
		IEnumerator routine2;
		base.StartCoroutine(routine2);
	}

	// Token: 0x060018E2 RID: 6370 RVA: 0x00032228 File Offset: 0x00030428
	[Address(RVA = "0x2A6D1CC", Offset = "0x2A6D1CC", VA = "0x2A6D1CC")]
	[Token(Token = "0x60018E2")]
	private void method_37()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
		}
		if (this.bool_1)
		{
			string text = this.string_0;
			if (text != null && text == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060018E3 RID: 6371 RVA: 0x00031ECC File Offset: 0x000300CC
	[Address(RVA = "0x2A6C524", Offset = "0x2A6C524", VA = "0x2A6C524")]
	[Token(Token = "0x60018E3")]
	public IEnumerator method_38()
	{
		CosmeticsController.Class22 @class = new CosmeticsController.Class22((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018E4 RID: 6372 RVA: 0x00032228 File Offset: 0x00030428
	[Address(RVA = "0x2A6D33C", Offset = "0x2A6D33C", VA = "0x2A6D33C")]
	[Token(Token = "0x60018E4")]
	private void method_39()
	{
		bool inRoom = PhotonNetwork.InRoom;
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		if (networkPlayerSpawner.bool_0)
		{
			PhotonView component = networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
			this.photonView_0 = component;
		}
		if (this.bool_1)
		{
			string text = this.string_0;
			if (text != null && text == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
	}

	// Token: 0x060018E5 RID: 6373 RVA: 0x00031EB0 File Offset: 0x000300B0
	[Address(RVA = "0x2A6CA60", Offset = "0x2A6CA60", VA = "0x2A6CA60")]
	[Token(Token = "0x60018E5")]
	public IEnumerator method_40()
	{
		/*
An exception occurred when decompiling this method (060018E5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator CosmeticsController::method_40()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class23(Class23::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x04000334 RID: 820
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000334")]
	public bool bool_0;

	// Token: 0x04000335 RID: 821
	[Token(Token = "0x4000335")]
	[FieldOffset(Offset = "0x20")]
	public string string_0;

	// Token: 0x04000336 RID: 822
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000336")]
	private float float_0 = (float)52429;

	// Token: 0x04000337 RID: 823
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000337")]
	public NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x04000338 RID: 824
	[Token(Token = "0x4000338")]
	[FieldOffset(Offset = "0x38")]
	private PhotonView photonView_0;

	// Token: 0x04000339 RID: 825
	[Token(Token = "0x4000339")]
	[FieldOffset(Offset = "0x40")]
	private bool bool_1;
}
