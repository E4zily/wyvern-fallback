﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200017B RID: 379
[Token(Token = "0x200017B")]
public class GClass3
{
	// Token: 0x06003A2D RID: 14893 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A2D")]
	[Address(RVA = "0x217BAC4", Offset = "0x217BAC4", VA = "0x217BAC4")]
	public static Vector3 smethod_0(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A2E RID: 14894 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217BC50", Offset = "0x217BC50", VA = "0x217BC50")]
	[Token(Token = "0x6003A2E")]
	public static Vector3 smethod_1(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A2F RID: 14895 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217BDDC", Offset = "0x217BDDC", VA = "0x217BDDC")]
	[Token(Token = "0x6003A2F")]
	public static bool smethod_2(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A2F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_2(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A30 RID: 14896 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217BEBC", Offset = "0x217BEBC", VA = "0x217BEBC")]
	[Token(Token = "0x6003A30")]
	public static Vector3 smethod_3(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A31 RID: 14897 RVA: 0x000736B0 File Offset: 0x000718B0
	[Token(Token = "0x6003A31")]
	[Address(RVA = "0x217C048", Offset = "0x217C048", VA = "0x217C048")]
	public static bool smethod_4(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A31)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_4(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A32 RID: 14898 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A32")]
	[Address(RVA = "0x217C128", Offset = "0x217C128", VA = "0x217C128")]
	public static bool smethod_5(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A32)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_5(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A33 RID: 14899 RVA: 0x000736C8 File Offset: 0x000718C8
	[Address(RVA = "0x217C208", Offset = "0x217C208", VA = "0x217C208")]
	[Token(Token = "0x6003A33")]
	public static bool smethod_6(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A34 RID: 14900 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217C2EC", Offset = "0x217C2EC", VA = "0x217C2EC")]
	[Token(Token = "0x6003A34")]
	public static Vector3 smethod_7(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A35 RID: 14901 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217C478", Offset = "0x217C478", VA = "0x217C478")]
	[Token(Token = "0x6003A35")]
	public static bool smethod_8(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A35)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_8(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A36 RID: 14902 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217C558", Offset = "0x217C558", VA = "0x217C558")]
	[Token(Token = "0x6003A36")]
	public static Vector3 smethod_9(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A37 RID: 14903 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A37")]
	[Address(RVA = "0x217C6E4", Offset = "0x217C6E4", VA = "0x217C6E4")]
	public static bool smethod_10(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A37)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_10(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A38 RID: 14904 RVA: 0x000736E4 File Offset: 0x000718E4
	[Address(RVA = "0x217C7C4", Offset = "0x217C7C4", VA = "0x217C7C4")]
	[Token(Token = "0x6003A38")]
	public static bool smethod_11(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A39 RID: 14905 RVA: 0x000736F8 File Offset: 0x000718F8
	[Address(RVA = "0x217C878", Offset = "0x217C878", VA = "0x217C878")]
	[Token(Token = "0x6003A39")]
	public static bool smethod_12(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A3A RID: 14906 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217C920", Offset = "0x217C920", VA = "0x217C920")]
	[Token(Token = "0x6003A3A")]
	public static bool smethod_13(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A3A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_13(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A3B RID: 14907 RVA: 0x000020B4 File Offset: 0x000002B4
	[Token(Token = "0x6003A3B")]
	[Address(RVA = "0x217CA00", Offset = "0x217CA00", VA = "0x217CA00")]
	public GClass3()
	{
	}

	// Token: 0x06003A3C RID: 14908 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A3C")]
	[Address(RVA = "0x217CA08", Offset = "0x217CA08", VA = "0x217CA08")]
	public static Vector3 smethod_14(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A3D RID: 14909 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217CB94", Offset = "0x217CB94", VA = "0x217CB94")]
	[Token(Token = "0x6003A3D")]
	public static Vector3 smethod_15(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A3E RID: 14910 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217CD20", Offset = "0x217CD20", VA = "0x217CD20")]
	[Token(Token = "0x6003A3E")]
	public static bool smethod_16(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A3E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_16(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A3F RID: 14911 RVA: 0x000736F8 File Offset: 0x000718F8
	[Address(RVA = "0x217CE00", Offset = "0x217CE00", VA = "0x217CE00")]
	[Token(Token = "0x6003A3F")]
	public static bool smethod_17(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A40 RID: 14912 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217CEA8", Offset = "0x217CEA8", VA = "0x217CEA8")]
	[Token(Token = "0x6003A40")]
	public static Vector3 smethod_18(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A41 RID: 14913 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A41")]
	[Address(RVA = "0x217D034", Offset = "0x217D034", VA = "0x217D034")]
	public static bool smethod_19(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A41)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_19(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A42 RID: 14914 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A42")]
	[Address(RVA = "0x217D114", Offset = "0x217D114", VA = "0x217D114")]
	public static Vector3 smethod_20(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A43 RID: 14915 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A43")]
	[Address(RVA = "0x217D2A0", Offset = "0x217D2A0", VA = "0x217D2A0")]
	public static bool smethod_21(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A44 RID: 14916 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A44")]
	[Address(RVA = "0x217D384", Offset = "0x217D384", VA = "0x217D384")]
	public static bool smethod_22(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A45 RID: 14917 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A45")]
	[Address(RVA = "0x217D464", Offset = "0x217D464", VA = "0x217D464")]
	public static bool smethod_23(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A45)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_23(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A46 RID: 14918 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217D544", Offset = "0x217D544", VA = "0x217D544")]
	[Token(Token = "0x6003A46")]
	public static Vector3 smethod_24(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A47 RID: 14919 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A47")]
	[Address(RVA = "0x217D6D0", Offset = "0x217D6D0", VA = "0x217D6D0")]
	public static bool smethod_25(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A48 RID: 14920 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A48")]
	[Address(RVA = "0x217D778", Offset = "0x217D778", VA = "0x217D778")]
	public static bool smethod_26(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A48)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_26(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A49 RID: 14921 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A49")]
	[Address(RVA = "0x217D858", Offset = "0x217D858", VA = "0x217D858")]
	public static bool smethod_27(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A4A RID: 14922 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A4A")]
	[Address(RVA = "0x217D938", Offset = "0x217D938", VA = "0x217D938")]
	public static bool smethod_28(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A4B RID: 14923 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x217D9E0", Offset = "0x217D9E0", VA = "0x217D9E0")]
	[Token(Token = "0x6003A4B")]
	public static Vector3 smethod_29(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A4C RID: 14924 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A4C")]
	[Address(RVA = "0x217DB6C", Offset = "0x217DB6C", VA = "0x217DB6C")]
	public static bool smethod_30(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A4C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_30(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A4D RID: 14925 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A4D")]
	[Address(RVA = "0x217DC4C", Offset = "0x217DC4C", VA = "0x217DC4C")]
	public static bool smethod_31(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A4E RID: 14926 RVA: 0x000736F8 File Offset: 0x000718F8
	[Address(RVA = "0x217DD2C", Offset = "0x217DD2C", VA = "0x217DD2C")]
	[Token(Token = "0x6003A4E")]
	public static bool smethod_32(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A4F RID: 14927 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A4F")]
	[Address(RVA = "0x217DDD4", Offset = "0x217DDD4", VA = "0x217DDD4")]
	public static Vector3 smethod_33(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A50 RID: 14928 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A50")]
	[Address(RVA = "0x217DF60", Offset = "0x217DF60", VA = "0x217DF60")]
	public static Vector3 smethod_34(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A51 RID: 14929 RVA: 0x000736F8 File Offset: 0x000718F8
	[Address(RVA = "0x217E0EC", Offset = "0x217E0EC", VA = "0x217E0EC")]
	[Token(Token = "0x6003A51")]
	public static bool smethod_35(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A52 RID: 14930 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A52")]
	[Address(RVA = "0x217E194", Offset = "0x217E194", VA = "0x217E194")]
	public static Vector3 smethod_36(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A53 RID: 14931 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A53")]
	[Address(RVA = "0x217E320", Offset = "0x217E320", VA = "0x217E320")]
	public static Vector3 smethod_37(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A54 RID: 14932 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217E4AC", Offset = "0x217E4AC", VA = "0x217E4AC")]
	[Token(Token = "0x6003A54")]
	public static bool smethod_38(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A54)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_38(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A55 RID: 14933 RVA: 0x000736E4 File Offset: 0x000718E4
	[Address(RVA = "0x217E58C", Offset = "0x217E58C", VA = "0x217E58C")]
	[Token(Token = "0x6003A55")]
	public static bool smethod_39(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A56 RID: 14934 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A56")]
	[Address(RVA = "0x217E644", Offset = "0x217E644", VA = "0x217E644")]
	public static Vector3 smethod_40(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A57 RID: 14935 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A57")]
	[Address(RVA = "0x217E7D0", Offset = "0x217E7D0", VA = "0x217E7D0")]
	public static bool smethod_41(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A58 RID: 14936 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217E878", Offset = "0x217E878", VA = "0x217E878")]
	[Token(Token = "0x6003A58")]
	public static bool smethod_42(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A58)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_42(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A59 RID: 14937 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A59")]
	[Address(RVA = "0x217E958", Offset = "0x217E958", VA = "0x217E958")]
	public static bool smethod_43(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A5A RID: 14938 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A5A")]
	[Address(RVA = "0x217E9FC", Offset = "0x217E9FC", VA = "0x217E9FC")]
	public static Vector3 smethod_44(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A5B RID: 14939 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A5B")]
	[Address(RVA = "0x217EB88", Offset = "0x217EB88", VA = "0x217EB88")]
	public static bool smethod_45(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A5B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_45(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A5C RID: 14940 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A5C")]
	[Address(RVA = "0x217EC68", Offset = "0x217EC68", VA = "0x217EC68")]
	public static bool smethod_46(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A5D RID: 14941 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217ED48", Offset = "0x217ED48", VA = "0x217ED48")]
	[Token(Token = "0x6003A5D")]
	public static bool smethod_47(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A5D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_47(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A5E RID: 14942 RVA: 0x00073710 File Offset: 0x00071910
	[Token(Token = "0x6003A5E")]
	[Address(RVA = "0x217EE28", Offset = "0x217EE28", VA = "0x217EE28")]
	public static bool smethod_48(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A5F RID: 14943 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A5F")]
	[Address(RVA = "0x217EF08", Offset = "0x217EF08", VA = "0x217EF08")]
	public static Vector3 smethod_49(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A60 RID: 14944 RVA: 0x00073698 File Offset: 0x00071898
	[Address(RVA = "0x217F094", Offset = "0x217F094", VA = "0x217F094")]
	[Token(Token = "0x6003A60")]
	public static bool smethod_50(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A60)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_50(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A61 RID: 14945 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A61")]
	[Address(RVA = "0x217F174", Offset = "0x217F174", VA = "0x217F174")]
	public static Vector3 smethod_51(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A62 RID: 14946 RVA: 0x000736C8 File Offset: 0x000718C8
	[Address(RVA = "0x217F300", Offset = "0x217F300", VA = "0x217F300")]
	[Token(Token = "0x6003A62")]
	public static bool smethod_52(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A63 RID: 14947 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A63")]
	[Address(RVA = "0x217F3E0", Offset = "0x217F3E0", VA = "0x217F3E0")]
	public static bool smethod_53(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A64 RID: 14948 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A64")]
	[Address(RVA = "0x217F4C0", Offset = "0x217F4C0", VA = "0x217F4C0")]
	public static bool smethod_54(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A64)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_54(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A65 RID: 14949 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A65")]
	[Address(RVA = "0x217F5A0", Offset = "0x217F5A0", VA = "0x217F5A0")]
	public static Vector3 smethod_55(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A66 RID: 14950 RVA: 0x000736F8 File Offset: 0x000718F8
	[Address(RVA = "0x217F72C", Offset = "0x217F72C", VA = "0x217F72C")]
	[Token(Token = "0x6003A66")]
	public static bool smethod_56(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A67 RID: 14951 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A67")]
	[Address(RVA = "0x217F7D0", Offset = "0x217F7D0", VA = "0x217F7D0")]
	public static bool smethod_57(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A67)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_57(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A68 RID: 14952 RVA: 0x000736E4 File Offset: 0x000718E4
	[Token(Token = "0x6003A68")]
	[Address(RVA = "0x217F8B0", Offset = "0x217F8B0", VA = "0x217F8B0")]
	public static bool smethod_58(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A69 RID: 14953 RVA: 0x000736E4 File Offset: 0x000718E4
	[Token(Token = "0x6003A69")]
	[Address(RVA = "0x217F964", Offset = "0x217F964", VA = "0x217F964")]
	public static bool smethod_59(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A6A RID: 14954 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A6A")]
	[Address(RVA = "0x217FA18", Offset = "0x217FA18", VA = "0x217FA18")]
	public static bool smethod_60(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A6A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_60(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A6B RID: 14955 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A6B")]
	[Address(RVA = "0x217FAF8", Offset = "0x217FAF8", VA = "0x217FAF8")]
	public static Vector3 smethod_61(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A6C RID: 14956 RVA: 0x000736C8 File Offset: 0x000718C8
	[Address(RVA = "0x217FC84", Offset = "0x217FC84", VA = "0x217FC84")]
	[Token(Token = "0x6003A6C")]
	public static bool smethod_62(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A6D RID: 14957 RVA: 0x000736C8 File Offset: 0x000718C8
	[Address(RVA = "0x217FD68", Offset = "0x217FD68", VA = "0x217FD68")]
	[Token(Token = "0x6003A6D")]
	public static bool smethod_63(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A6E RID: 14958 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A6E")]
	[Address(RVA = "0x217FE48", Offset = "0x217FE48", VA = "0x217FE48")]
	public static bool smethod_64(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A6F RID: 14959 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A6F")]
	[Address(RVA = "0x217FF2C", Offset = "0x217FF2C", VA = "0x217FF2C")]
	public static Vector3 smethod_65(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A70 RID: 14960 RVA: 0x000736C8 File Offset: 0x000718C8
	[Address(RVA = "0x21800B8", Offset = "0x21800B8", VA = "0x21800B8")]
	[Token(Token = "0x6003A70")]
	public static bool smethod_66(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A71 RID: 14961 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A71")]
	[Address(RVA = "0x218019C", Offset = "0x218019C", VA = "0x218019C")]
	public static bool smethod_67(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A72 RID: 14962 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A72")]
	[Address(RVA = "0x218027C", Offset = "0x218027C", VA = "0x218027C")]
	public static Vector3 smethod_68(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A73 RID: 14963 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A73")]
	[Address(RVA = "0x2180408", Offset = "0x2180408", VA = "0x2180408")]
	public static Vector3 smethod_69(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A74 RID: 14964 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x2180594", Offset = "0x2180594", VA = "0x2180594")]
	[Token(Token = "0x6003A74")]
	public static Vector3 smethod_70(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A75 RID: 14965 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A75")]
	[Address(RVA = "0x2180720", Offset = "0x2180720", VA = "0x2180720")]
	public static bool smethod_71(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A75)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_71(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A76 RID: 14966 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A76")]
	[Address(RVA = "0x2180800", Offset = "0x2180800", VA = "0x2180800")]
	public static bool smethod_72(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A76)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_72(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A77 RID: 14967 RVA: 0x000736E4 File Offset: 0x000718E4
	[Token(Token = "0x6003A77")]
	[Address(RVA = "0x21808E0", Offset = "0x21808E0", VA = "0x21808E0")]
	public static bool smethod_73(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A78 RID: 14968 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A78")]
	[Address(RVA = "0x2180994", Offset = "0x2180994", VA = "0x2180994")]
	public static bool smethod_74(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A79 RID: 14969 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A79")]
	[Address(RVA = "0x2180A3C", Offset = "0x2180A3C", VA = "0x2180A3C")]
	public static Vector3 smethod_75(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A7A RID: 14970 RVA: 0x00073698 File Offset: 0x00071898
	[Token(Token = "0x6003A7A")]
	[Address(RVA = "0x2180BC8", Offset = "0x2180BC8", VA = "0x2180BC8")]
	public static bool smethod_76(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		/*
An exception occurred when decompiling this method (06003A7A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean GClass3::smethod_76(UnityEngine.Vector3,UnityEngine.LayerMask,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Vector3::get_up)); 	stloc:Vector3(arg_0B_0, callgetter:Vector3(Vector3::get_up)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
	}

	// Token: 0x06003A7B RID: 14971 RVA: 0x000736E4 File Offset: 0x000718E4
	[Address(RVA = "0x2180CA8", Offset = "0x2180CA8", VA = "0x2180CA8")]
	[Token(Token = "0x6003A7B")]
	public static bool smethod_77(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A7C RID: 14972 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A7C")]
	[Address(RVA = "0x2180D5C", Offset = "0x2180D5C", VA = "0x2180D5C")]
	public static Vector3 smethod_78(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A7D RID: 14973 RVA: 0x0007372C File Offset: 0x0007192C
	[Address(RVA = "0x2180EE8", Offset = "0x2180EE8", VA = "0x2180EE8")]
	[Token(Token = "0x6003A7D")]
	public static bool smethod_79(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A7E RID: 14974 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x2180FA0", Offset = "0x2180FA0", VA = "0x2180FA0")]
	[Token(Token = "0x6003A7E")]
	public static Vector3 smethod_80(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A7F RID: 14975 RVA: 0x000736E4 File Offset: 0x000718E4
	[Token(Token = "0x6003A7F")]
	[Address(RVA = "0x218112C", Offset = "0x218112C", VA = "0x218112C")]
	public static bool smethod_81(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A80 RID: 14976 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x21811E4", Offset = "0x21811E4", VA = "0x21811E4")]
	[Token(Token = "0x6003A80")]
	public static Vector3 smethod_82(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A81 RID: 14977 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A81")]
	[Address(RVA = "0x2181370", Offset = "0x2181370", VA = "0x2181370")]
	public static bool smethod_83(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A82 RID: 14978 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A82")]
	[Address(RVA = "0x2181418", Offset = "0x2181418", VA = "0x2181418")]
	public static Vector3 smethod_84(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A83 RID: 14979 RVA: 0x000736F8 File Offset: 0x000718F8
	[Address(RVA = "0x21815A4", Offset = "0x21815A4", VA = "0x21815A4")]
	[Token(Token = "0x6003A83")]
	public static bool smethod_85(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A84 RID: 14980 RVA: 0x000736E4 File Offset: 0x000718E4
	[Token(Token = "0x6003A84")]
	[Address(RVA = "0x218164C", Offset = "0x218164C", VA = "0x218164C")]
	public static bool smethod_86(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A85 RID: 14981 RVA: 0x000736F8 File Offset: 0x000718F8
	[Address(RVA = "0x2181704", Offset = "0x2181704", VA = "0x2181704")]
	[Token(Token = "0x6003A85")]
	public static bool smethod_87(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A86 RID: 14982 RVA: 0x000736E4 File Offset: 0x000718E4
	[Address(RVA = "0x21817AC", Offset = "0x21817AC", VA = "0x21817AC")]
	[Token(Token = "0x6003A86")]
	public static bool smethod_88(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A87 RID: 14983 RVA: 0x00073740 File Offset: 0x00071940
	[Address(RVA = "0x2181864", Offset = "0x2181864", VA = "0x2181864")]
	[Token(Token = "0x6003A87")]
	public static Vector3 smethod_89(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A88 RID: 14984 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A88")]
	[Address(RVA = "0x21819F0", Offset = "0x21819F0", VA = "0x21819F0")]
	public static Vector3 smethod_90(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A89 RID: 14985 RVA: 0x000736E4 File Offset: 0x000718E4
	[Address(RVA = "0x2181B7C", Offset = "0x2181B7C", VA = "0x2181B7C")]
	[Token(Token = "0x6003A89")]
	public static bool smethod_91(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A8A RID: 14986 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A8A")]
	[Address(RVA = "0x2181C20", Offset = "0x2181C20", VA = "0x2181C20")]
	public static bool smethod_92(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A8B RID: 14987 RVA: 0x00073670 File Offset: 0x00071870
	[Address(RVA = "0x2181D00", Offset = "0x2181D00", VA = "0x2181D00")]
	[Token(Token = "0x6003A8B")]
	public static Vector3 smethod_93(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A8C RID: 14988 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A8C")]
	[Address(RVA = "0x2181E8C", Offset = "0x2181E8C", VA = "0x2181E8C")]
	public static bool smethod_94(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A8D RID: 14989 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A8D")]
	[Address(RVA = "0x2181F34", Offset = "0x2181F34", VA = "0x2181F34")]
	public static Vector3 smethod_95(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A8E RID: 14990 RVA: 0x000736C8 File Offset: 0x000718C8
	[Address(RVA = "0x21820C0", Offset = "0x21820C0", VA = "0x21820C0")]
	[Token(Token = "0x6003A8E")]
	public static bool smethod_96(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A8F RID: 14991 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A8F")]
	[Address(RVA = "0x21821A0", Offset = "0x21821A0", VA = "0x21821A0")]
	public static bool smethod_97(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A90 RID: 14992 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A90")]
	[Address(RVA = "0x2182284", Offset = "0x2182284", VA = "0x2182284")]
	public static bool smethod_98(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A91 RID: 14993 RVA: 0x000736C8 File Offset: 0x000718C8
	[Token(Token = "0x6003A91")]
	[Address(RVA = "0x2182368", Offset = "0x2182368", VA = "0x2182368")]
	public static bool smethod_99(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		return false;
	}

	// Token: 0x06003A92 RID: 14994 RVA: 0x000736F8 File Offset: 0x000718F8
	[Token(Token = "0x6003A92")]
	[Address(RVA = "0x2182448", Offset = "0x2182448", VA = "0x2182448")]
	public static bool smethod_100(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		throw new NullReferenceException();
	}

	// Token: 0x06003A93 RID: 14995 RVA: 0x000736E4 File Offset: 0x000718E4
	[Address(RVA = "0x21824F0", Offset = "0x21824F0", VA = "0x21824F0")]
	[Token(Token = "0x6003A93")]
	public static bool smethod_101(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A94 RID: 14996 RVA: 0x000736E4 File Offset: 0x000718E4
	[Token(Token = "0x6003A94")]
	[Address(RVA = "0x21825A8", Offset = "0x21825A8", VA = "0x21825A8")]
	public static bool smethod_102(Vector3 vector3_0)
	{
		Vector3 up = Vector3.up;
		return false;
	}

	// Token: 0x06003A95 RID: 14997 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A95")]
	[Address(RVA = "0x2182660", Offset = "0x2182660", VA = "0x2182660")]
	public static Vector3 smethod_103(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A96 RID: 14998 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A96")]
	[Address(RVA = "0x21827EC", Offset = "0x21827EC", VA = "0x21827EC")]
	public static Vector3 smethod_104(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}

	// Token: 0x06003A97 RID: 14999 RVA: 0x00073670 File Offset: 0x00071870
	[Token(Token = "0x6003A97")]
	[Address(RVA = "0x2182978", Offset = "0x2182978", VA = "0x2182978")]
	public static Vector3 smethod_105(Vector3 vector3_0, LayerMask layerMask_0, float float_0, float float_1, float float_2)
	{
		Vector3 up = Vector3.up;
		Vector3 up2 = Vector3.up;
		Vector3 up3 = Vector3.up;
		Vector3 up4 = Vector3.up;
		Vector3 result;
		return result;
	}
}
