﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200009F RID: 159
[Token(Token = "0x200009F")]
public class RaycastAI : MonoBehaviour
{
	// Token: 0x06001784 RID: 6020 RVA: 0x00030118 File Offset: 0x0002E318
	[Address(RVA = "0x3481AFC", Offset = "0x3481AFC", VA = "0x3481AFC")]
	[Token(Token = "0x6001784")]
	private void method_0()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001785 RID: 6021 RVA: 0x0003015C File Offset: 0x0002E35C
	[Address(RVA = "0x3481D24", Offset = "0x3481D24", VA = "0x3481D24")]
	[Token(Token = "0x6001785")]
	private void method_1()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001786 RID: 6022 RVA: 0x00030118 File Offset: 0x0002E318
	[Token(Token = "0x6001786")]
	[Address(RVA = "0x3481F24", Offset = "0x3481F24", VA = "0x3481F24")]
	private void method_2()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001787 RID: 6023 RVA: 0x00030118 File Offset: 0x0002E318
	[Token(Token = "0x6001787")]
	[Address(RVA = "0x348212C", Offset = "0x348212C", VA = "0x348212C")]
	private void method_3()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001788 RID: 6024 RVA: 0x0003015C File Offset: 0x0002E35C
	[Address(RVA = "0x3482358", Offset = "0x3482358", VA = "0x3482358")]
	[Token(Token = "0x6001788")]
	private void method_4()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001789 RID: 6025 RVA: 0x00030118 File Offset: 0x0002E318
	[Token(Token = "0x6001789")]
	[Address(RVA = "0x3482558", Offset = "0x3482558", VA = "0x3482558")]
	private void method_5()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x0600178A RID: 6026 RVA: 0x0003015C File Offset: 0x0002E35C
	[Token(Token = "0x600178A")]
	[Address(RVA = "0x3482780", Offset = "0x3482780", VA = "0x3482780")]
	private void method_6()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x0600178B RID: 6027 RVA: 0x00030118 File Offset: 0x0002E318
	[Address(RVA = "0x3482980", Offset = "0x3482980", VA = "0x3482980")]
	[Token(Token = "0x600178B")]
	private void method_7()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x0600178C RID: 6028 RVA: 0x000301A0 File Offset: 0x0002E3A0
	[Token(Token = "0x600178C")]
	[Address(RVA = "0x3482B88", Offset = "0x3482B88", VA = "0x3482B88")]
	public RaycastAI()
	{
		long num = 1L;
		this.int_0 = (int)num;
		base..ctor();
	}

	// Token: 0x0600178D RID: 6029 RVA: 0x000301BC File Offset: 0x0002E3BC
	[Token(Token = "0x600178D")]
	[Address(RVA = "0x3482B98", Offset = "0x3482B98", VA = "0x3482B98")]
	private void method_8()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Transform transform;
		Vector3 forward = transform.forward;
		Transform transform2;
		Vector3 position2 = transform2.position;
		Transform transform3;
		Vector3 forward2 = transform3.forward;
	}

	// Token: 0x0600178E RID: 6030 RVA: 0x00030118 File Offset: 0x0002E318
	[Address(RVA = "0x3482DC0", Offset = "0x3482DC0", VA = "0x3482DC0")]
	[Token(Token = "0x600178E")]
	private void method_9()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x0600178F RID: 6031 RVA: 0x00030118 File Offset: 0x0002E318
	[Address(RVA = "0x3482FE8", Offset = "0x3482FE8", VA = "0x3482FE8")]
	[Token(Token = "0x600178F")]
	private void OnDrawGizmos()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001790 RID: 6032 RVA: 0x00030118 File Offset: 0x0002E318
	[Address(RVA = "0x3483210", Offset = "0x3483210", VA = "0x3483210")]
	[Token(Token = "0x6001790")]
	private void method_10()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001791 RID: 6033 RVA: 0x00030118 File Offset: 0x0002E318
	[Address(RVA = "0x3483418", Offset = "0x3483418", VA = "0x3483418")]
	[Token(Token = "0x6001791")]
	private void method_11()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x06001792 RID: 6034 RVA: 0x00030118 File Offset: 0x0002E318
	[Token(Token = "0x6001792")]
	[Address(RVA = "0x3483620", Offset = "0x3483620", VA = "0x3483620")]
	private void method_12()
	{
		Vector3 position = base.transform.position;
		Vector3 up = Vector3.up;
		Vector3 forward = base.transform.forward;
		Vector3 position2 = base.transform.position;
		Vector3 forward2 = base.transform.forward;
	}

	// Token: 0x04000307 RID: 775
	[Token(Token = "0x4000307")]
	[FieldOffset(Offset = "0x18")]
	public int int_0;

	// Token: 0x04000308 RID: 776
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000308")]
	public int int_1;
}
