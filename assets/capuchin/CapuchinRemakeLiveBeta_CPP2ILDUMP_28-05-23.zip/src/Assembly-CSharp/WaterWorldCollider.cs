﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F3 RID: 243
[Token(Token = "0x20000F3")]
public class WaterWorldCollider : MonoBehaviour
{
	// Token: 0x06002491 RID: 9361 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x21017C4", Offset = "0x21017C4", VA = "0x21017C4")]
	[Token(Token = "0x6002491")]
	public void method_0()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002492 RID: 9362 RVA: 0x00043EB8 File Offset: 0x000420B8
	[Address(RVA = "0x21017E4", Offset = "0x21017E4", VA = "0x21017E4")]
	[Token(Token = "0x6002492")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x06002493 RID: 9363 RVA: 0x00043F20 File Offset: 0x00042120
	[Address(RVA = "0x21018B8", Offset = "0x21018B8", VA = "0x21018B8")]
	[Token(Token = "0x6002493")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Toxicity");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		this.gameObject_2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_3;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06002494 RID: 9364 RVA: 0x00043F84 File Offset: 0x00042184
	[Address(RVA = "0x210198C", Offset = "0x210198C", VA = "0x210198C")]
	[Token(Token = "0x6002494")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("\n Time: ");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x06002495 RID: 9365 RVA: 0x00043EB8 File Offset: 0x000420B8
	[Address(RVA = "0x2101A60", Offset = "0x2101A60", VA = "0x2101A60")]
	[Token(Token = "0x6002495")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x06002496 RID: 9366 RVA: 0x00043FEC File Offset: 0x000421EC
	[Address(RVA = "0x2101B34", Offset = "0x2101B34", VA = "0x2101B34")]
	[Token(Token = "0x6002496")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x06002497 RID: 9367 RVA: 0x00044054 File Offset: 0x00042254
	[Address(RVA = "0x2101C08", Offset = "0x2101C08", VA = "0x2101C08")]
	[Token(Token = "0x6002497")]
	public void method_4(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.CompareTag("_Color");
		GameObject gameObject2 = this.gameObject_0;
		long active = 0L;
		gameObject2.SetActive(active != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active2 = 1L;
		gameObject3.SetActive(active2 != 0L);
		GameObject gameObject4 = this.gameObject_2;
		long active3 = 0L;
		gameObject4.SetActive(active3 != 0L);
		GameObject gameObject5 = this.gameObject_3;
		long active4 = 0L;
		gameObject5.SetActive(active4 != 0L);
	}

	// Token: 0x06002498 RID: 9368 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2101CDC", Offset = "0x2101CDC", VA = "0x2101CDC")]
	[Token(Token = "0x6002498")]
	public void method_5()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002499 RID: 9369 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2101CFC", Offset = "0x2101CFC", VA = "0x2101CFC")]
	[Token(Token = "0x6002499")]
	public void method_6()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600249A RID: 9370 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2101D1C", Offset = "0x2101D1C", VA = "0x2101D1C")]
	[Token(Token = "0x600249A")]
	public void method_7()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600249B RID: 9371 RVA: 0x000440DC File Offset: 0x000422DC
	[Address(RVA = "0x2101D3C", Offset = "0x2101D3C", VA = "0x2101D3C")]
	[Token(Token = "0x600249B")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("character limit reached");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x0600249C RID: 9372 RVA: 0x00044144 File Offset: 0x00042344
	[Address(RVA = "0x2101E10", Offset = "0x2101E10", VA = "0x2101E10")]
	[Token(Token = "0x600249C")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Purchase For ");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x0600249D RID: 9373 RVA: 0x000441AC File Offset: 0x000423AC
	[Address(RVA = "0x2101EE4", Offset = "0x2101EE4", VA = "0x2101EE4")]
	[Token(Token = "0x600249D")]
	public void method_10(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		GameObject gameObject2 = this.gameObject_0;
		long active = 0L;
		gameObject2.SetActive(active != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active2 = 1L;
		gameObject3.SetActive(active2 != 0L);
		GameObject gameObject4 = this.gameObject_2;
		long active3 = 1L;
		gameObject4.SetActive(active3 != 0L);
		GameObject gameObject5 = this.gameObject_3;
		long active4 = 0L;
		gameObject5.SetActive(active4 != 0L);
	}

	// Token: 0x0600249E RID: 9374 RVA: 0x0004420C File Offset: 0x0004240C
	[Address(RVA = "0x2101FB8", Offset = "0x2101FB8", VA = "0x2101FB8")]
	[Token(Token = "0x600249E")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("containsStaff");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x0600249F RID: 9375 RVA: 0x00044274 File Offset: 0x00042474
	[Address(RVA = "0x210208C", Offset = "0x210208C", VA = "0x210208C")]
	[Token(Token = "0x600249F")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PURCHASED");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024A0 RID: 9376 RVA: 0x000442DC File Offset: 0x000424DC
	[Address(RVA = "0x2102160", Offset = "0x2102160", VA = "0x2102160")]
	[Token(Token = "0x60024A0")]
	public void method_13(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.CompareTag("Name Changing Error. Error: ");
		GameObject gameObject2 = this.gameObject_0;
		long active = 1L;
		gameObject2.SetActive(active != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active2 = 1L;
		gameObject3.SetActive(active2 != 0L);
		GameObject gameObject4 = this.gameObject_2;
		long active3 = 0L;
		gameObject4.SetActive(active3 != 0L);
		GameObject gameObject5 = this.gameObject_3;
		long active4 = 1L;
		gameObject5.SetActive(active4 != 0L);
	}

	// Token: 0x060024A1 RID: 9377 RVA: 0x00044344 File Offset: 0x00042544
	[Address(RVA = "0x2102234", Offset = "0x2102234", VA = "0x2102234")]
	[Token(Token = "0x60024A1")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("\n");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024A2 RID: 9378 RVA: 0x000443AC File Offset: 0x000425AC
	[Address(RVA = "0x2102308", Offset = "0x2102308", VA = "0x2102308")]
	[Token(Token = "0x60024A2")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.CompareTag(", ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024A3 RID: 9379 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x21023DC", Offset = "0x21023DC", VA = "0x21023DC")]
	[Token(Token = "0x60024A3")]
	public void method_16()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024A4 RID: 9380 RVA: 0x00044414 File Offset: 0x00042614
	[Address(RVA = "0x21023FC", Offset = "0x21023FC", VA = "0x21023FC")]
	[Token(Token = "0x60024A4")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.CompareTag(" and the correct version is ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024A5 RID: 9381 RVA: 0x0004447C File Offset: 0x0004267C
	[Address(RVA = "0x21024D0", Offset = "0x21024D0", VA = "0x21024D0")]
	[Token(Token = "0x60024A5")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("/");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024A6 RID: 9382 RVA: 0x000444E4 File Offset: 0x000426E4
	[Address(RVA = "0x21025A4", Offset = "0x21025A4", VA = "0x21025A4")]
	[Token(Token = "0x60024A6")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("RainAndThunderWeather");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024A7 RID: 9383 RVA: 0x0004454C File Offset: 0x0004274C
	[Address(RVA = "0x2102678", Offset = "0x2102678", VA = "0x2102678")]
	[Token(Token = "0x60024A7")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024A8 RID: 9384 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x210274C", Offset = "0x210274C", VA = "0x210274C")]
	[Token(Token = "0x60024A8")]
	public void method_21()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024A9 RID: 9385 RVA: 0x000445B4 File Offset: 0x000427B4
	[Address(RVA = "0x210276C", Offset = "0x210276C", VA = "0x210276C")]
	[Token(Token = "0x60024A9")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024AA RID: 9386 RVA: 0x0004461C File Offset: 0x0004281C
	[Address(RVA = "0x2102840", Offset = "0x2102840", VA = "0x2102840")]
	[Token(Token = "0x60024AA")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024AB RID: 9387 RVA: 0x00044684 File Offset: 0x00042884
	[Address(RVA = "0x2102914", Offset = "0x2102914", VA = "0x2102914")]
	[Token(Token = "0x60024AB")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("vive");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024AC RID: 9388 RVA: 0x000446EC File Offset: 0x000428EC
	[Address(RVA = "0x21029E8", Offset = "0x21029E8", VA = "0x21029E8")]
	[Token(Token = "0x60024AC")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("retract broken");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024AD RID: 9389 RVA: 0x00044754 File Offset: 0x00042954
	[Address(RVA = "0x2102ABC", Offset = "0x2102ABC", VA = "0x2102ABC")]
	[Token(Token = "0x60024AD")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Update User Inventory");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024AE RID: 9390 RVA: 0x000447BC File Offset: 0x000429BC
	[Address(RVA = "0x2102B90", Offset = "0x2102B90", VA = "0x2102B90")]
	[Token(Token = "0x60024AE")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("KeyPos");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024AF RID: 9391 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2102C64", Offset = "0x2102C64", VA = "0x2102C64")]
	[Token(Token = "0x60024AF")]
	public void method_28()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024B0 RID: 9392 RVA: 0x00044824 File Offset: 0x00042A24
	[Address(RVA = "0x2102C84", Offset = "0x2102C84", VA = "0x2102C84")]
	[Token(Token = "0x60024B0")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Calling success callback. baking meshes");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024B1 RID: 9393 RVA: 0x0004488C File Offset: 0x00042A8C
	[Address(RVA = "0x2102D58", Offset = "0x2102D58", VA = "0x2102D58")]
	[Token(Token = "0x60024B1")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CapuchinStore");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024B2 RID: 9394 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2102E2C", Offset = "0x2102E2C", VA = "0x2102E2C")]
	[Token(Token = "0x60024B2")]
	public WaterWorldCollider()
	{
	}

	// Token: 0x060024B3 RID: 9395 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2102E34", Offset = "0x2102E34", VA = "0x2102E34")]
	[Token(Token = "0x60024B3")]
	public void method_31()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024B4 RID: 9396 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2102E54", Offset = "0x2102E54", VA = "0x2102E54")]
	[Token(Token = "0x60024B4")]
	public void method_32()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024B5 RID: 9397 RVA: 0x000448F4 File Offset: 0x00042AF4
	[Address(RVA = "0x2102E74", Offset = "0x2102E74", VA = "0x2102E74")]
	[Token(Token = "0x60024B5")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("NetworkPlayer");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024B6 RID: 9398 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2102F48", Offset = "0x2102F48", VA = "0x2102F48")]
	[Token(Token = "0x60024B6")]
	public void method_34()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024B7 RID: 9399 RVA: 0x0004495C File Offset: 0x00042B5C
	[Address(RVA = "0x2102F68", Offset = "0x2102F68", VA = "0x2102F68")]
	[Token(Token = "0x60024B7")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ChangeMaterialToNormal");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024B8 RID: 9400 RVA: 0x000449C4 File Offset: 0x00042BC4
	[Address(RVA = "0x210303C", Offset = "0x210303C", VA = "0x210303C")]
	[Token(Token = "0x60024B8")]
	public void method_36(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.CompareTag("FingerTip");
		GameObject gameObject2 = this.gameObject_0;
		long active = 0L;
		gameObject2.SetActive(active != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active2 = 1L;
		gameObject3.SetActive(active2 != 0L);
		GameObject gameObject4 = this.gameObject_2;
		long active3 = 1L;
		gameObject4.SetActive(active3 != 0L);
		GameObject gameObject5 = this.gameObject_3;
		long active4 = 1L;
		gameObject5.SetActive(active4 != 0L);
	}

	// Token: 0x060024B9 RID: 9401 RVA: 0x00044A2C File Offset: 0x00042C2C
	[Address(RVA = "0x2103110", Offset = "0x2103110", VA = "0x2103110")]
	[Token(Token = "0x60024B9")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("NormalWeather");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024BA RID: 9402 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x21031E4", Offset = "0x21031E4", VA = "0x21031E4")]
	[Token(Token = "0x60024BA")]
	public void method_38()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024BB RID: 9403 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2103204", Offset = "0x2103204", VA = "0x2103204")]
	[Token(Token = "0x60024BB")]
	public void method_39()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024BC RID: 9404 RVA: 0x00044A94 File Offset: 0x00042C94
	[Address(RVA = "0x2103224", Offset = "0x2103224", VA = "0x2103224")]
	[Token(Token = "0x60024BC")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Downloading image");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024BD RID: 9405 RVA: 0x00044AFC File Offset: 0x00042CFC
	[Address(RVA = "0x21032F8", Offset = "0x21032F8", VA = "0x21032F8")]
	[Token(Token = "0x60024BD")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PURCHASE");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024BE RID: 9406 RVA: 0x00044B64 File Offset: 0x00042D64
	[Address(RVA = "0x21033CC", Offset = "0x21033CC", VA = "0x21033CC")]
	[Token(Token = "0x60024BE")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Tint");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024BF RID: 9407 RVA: 0x00044BCC File Offset: 0x00042DCC
	[Address(RVA = "0x21034A0", Offset = "0x21034A0", VA = "0x21034A0")]
	[Token(Token = "0x60024BF")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("true");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024C0 RID: 9408 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2103574", Offset = "0x2103574", VA = "0x2103574")]
	[Token(Token = "0x60024C0")]
	public void method_44()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024C1 RID: 9409 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2103594", Offset = "0x2103594", VA = "0x2103594")]
	[Token(Token = "0x60024C1")]
	public void method_45()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024C2 RID: 9410 RVA: 0x00044C34 File Offset: 0x00042E34
	[Address(RVA = "0x21035B4", Offset = "0x21035B4", VA = "0x21035B4")]
	[Token(Token = "0x60024C2")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("All audio clips have been played.");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024C3 RID: 9411 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2103688", Offset = "0x2103688", VA = "0x2103688")]
	[Token(Token = "0x60024C3")]
	public void method_47()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024C4 RID: 9412 RVA: 0x00044C9C File Offset: 0x00042E9C
	[Address(RVA = "0x21036A8", Offset = "0x21036A8", VA = "0x21036A8")]
	[Token(Token = "0x60024C4")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("containsStaff");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024C5 RID: 9413 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x210377C", Offset = "0x210377C", VA = "0x210377C")]
	[Token(Token = "0x60024C5")]
	public void method_49()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024C6 RID: 9414 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x210379C", Offset = "0x210379C", VA = "0x210379C")]
	[Token(Token = "0x60024C6")]
	public void method_50()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024C7 RID: 9415 RVA: 0x00044D04 File Offset: 0x00042F04
	[Address(RVA = "0x21037BC", Offset = "0x21037BC", VA = "0x21037BC")]
	[Token(Token = "0x60024C7")]
	public void method_51(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Tint");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024C8 RID: 9416 RVA: 0x00044D6C File Offset: 0x00042F6C
	[Address(RVA = "0x2103890", Offset = "0x2103890", VA = "0x2103890")]
	[Token(Token = "0x60024C8")]
	public void method_52(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024C9 RID: 9417 RVA: 0x000440BC File Offset: 0x000422BC
	[Token(Token = "0x60024C9")]
	[Address(RVA = "0x2103964", Offset = "0x2103964", VA = "0x2103964")]
	public void method_53()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024CA RID: 9418 RVA: 0x00044DD4 File Offset: 0x00042FD4
	[Address(RVA = "0x2103984", Offset = "0x2103984", VA = "0x2103984")]
	[Token(Token = "0x60024CA")]
	public void method_54(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Cannot access index {0}. Buffer size is {1}");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024CB RID: 9419 RVA: 0x00044E3C File Offset: 0x0004303C
	[Address(RVA = "0x2103A58", Offset = "0x2103A58", VA = "0x2103A58")]
	[Token(Token = "0x60024CB")]
	public void method_55(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024CC RID: 9420 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2103B2C", Offset = "0x2103B2C", VA = "0x2103B2C")]
	[Token(Token = "0x60024CC")]
	public void method_56()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024CD RID: 9421 RVA: 0x00044EA4 File Offset: 0x000430A4
	[Address(RVA = "0x2103B4C", Offset = "0x2103B4C", VA = "0x2103B4C")]
	[Token(Token = "0x60024CD")]
	public void method_57(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("1BN");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024CE RID: 9422 RVA: 0x00044F0C File Offset: 0x0004310C
	[Address(RVA = "0x2103C20", Offset = "0x2103C20", VA = "0x2103C20")]
	[Token(Token = "0x60024CE")]
	public void method_58(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("BN");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024CF RID: 9423 RVA: 0x00044F74 File Offset: 0x00043174
	[Address(RVA = "0x2103CF4", Offset = "0x2103CF4", VA = "0x2103CF4")]
	[Token(Token = "0x60024CF")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.CompareTag(" hour. You were banned because of ");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_3;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x060024D0 RID: 9424 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2103DC8", Offset = "0x2103DC8", VA = "0x2103DC8")]
	[Token(Token = "0x60024D0")]
	public void method_60()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024D1 RID: 9425 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2103DE8", Offset = "0x2103DE8", VA = "0x2103DE8")]
	[Token(Token = "0x60024D1")]
	public void Start()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024D2 RID: 9426 RVA: 0x00044FCC File Offset: 0x000431CC
	[Address(RVA = "0x2103E08", Offset = "0x2103E08", VA = "0x2103E08")]
	[Token(Token = "0x60024D2")]
	public void method_61(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024D3 RID: 9427 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2103EDC", Offset = "0x2103EDC", VA = "0x2103EDC")]
	[Token(Token = "0x60024D3")]
	public void method_62()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024D4 RID: 9428 RVA: 0x00045034 File Offset: 0x00043234
	[Address(RVA = "0x2103EFC", Offset = "0x2103EFC", VA = "0x2103EFC")]
	[Token(Token = "0x60024D4")]
	public void method_63(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CASUAL");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024D5 RID: 9429 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x2103FD0", Offset = "0x2103FD0", VA = "0x2103FD0")]
	[Token(Token = "0x60024D5")]
	public void method_64()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024D6 RID: 9430 RVA: 0x0004509C File Offset: 0x0004329C
	[Address(RVA = "0x2103FF0", Offset = "0x2103FF0", VA = "0x2103FF0")]
	[Token(Token = "0x60024D6")]
	public void method_65(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Key");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024D7 RID: 9431 RVA: 0x00045104 File Offset: 0x00043304
	[Address(RVA = "0x21040C4", Offset = "0x21040C4", VA = "0x21040C4")]
	[Token(Token = "0x60024D7")]
	public void method_66(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Queue");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024D8 RID: 9432 RVA: 0x0004516C File Offset: 0x0004336C
	[Address(RVA = "0x2104198", Offset = "0x2104198", VA = "0x2104198")]
	[Token(Token = "0x60024D8")]
	public void method_67(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ChangeToTagged");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024D9 RID: 9433 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x210426C", Offset = "0x210426C", VA = "0x210426C")]
	[Token(Token = "0x60024D9")]
	public void method_68()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024DA RID: 9434 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x210428C", Offset = "0x210428C", VA = "0x210428C")]
	[Token(Token = "0x60024DA")]
	public void method_69()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024DB RID: 9435 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x21042AC", Offset = "0x21042AC", VA = "0x21042AC")]
	[Token(Token = "0x60024DB")]
	public void method_70()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024DC RID: 9436 RVA: 0x000440BC File Offset: 0x000422BC
	[Address(RVA = "0x21042CC", Offset = "0x21042CC", VA = "0x21042CC")]
	[Token(Token = "0x60024DC")]
	public void method_71()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024DD RID: 9437 RVA: 0x000451D4 File Offset: 0x000433D4
	[Address(RVA = "0x21042EC", Offset = "0x21042EC", VA = "0x21042EC")]
	[Token(Token = "0x60024DD")]
	public void method_72(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		GameObject gameObject2 = this.gameObject_0;
		long active = 1L;
		gameObject2.SetActive(active != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active2 = 1L;
		gameObject3.SetActive(active2 != 0L);
		GameObject gameObject4 = this.gameObject_2;
		long active3 = 0L;
		gameObject4.SetActive(active3 != 0L);
		GameObject gameObject5 = this.gameObject_3;
		long active4 = 0L;
		gameObject5.SetActive(active4 != 0L);
	}

	// Token: 0x060024DE RID: 9438 RVA: 0x00045234 File Offset: 0x00043434
	[Address(RVA = "0x21043C0", Offset = "0x21043C0", VA = "0x21043C0")]
	[Token(Token = "0x60024DE")]
	public void method_73(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Not connected to room");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024DF RID: 9439 RVA: 0x0004529C File Offset: 0x0004349C
	[Address(RVA = "0x2104494", Offset = "0x2104494", VA = "0x2104494")]
	[Token(Token = "0x60024DF")]
	public void method_74(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ErrorScreen");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024E0 RID: 9440 RVA: 0x00043E98 File Offset: 0x00042098
	[Address(RVA = "0x2104568", Offset = "0x2104568", VA = "0x2104568")]
	[Token(Token = "0x60024E0")]
	public void method_75()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060024E1 RID: 9441 RVA: 0x00045304 File Offset: 0x00043504
	[Address(RVA = "0x2104588", Offset = "0x2104588", VA = "0x2104588")]
	[Token(Token = "0x60024E1")]
	public void method_76(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("User has been reported for: ");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024E2 RID: 9442 RVA: 0x0004536C File Offset: 0x0004356C
	[Address(RVA = "0x210465C", Offset = "0x210465C", VA = "0x210465C")]
	[Token(Token = "0x60024E2")]
	public void method_77(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("containsStaff");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x060024E3 RID: 9443 RVA: 0x000453D4 File Offset: 0x000435D4
	[Address(RVA = "0x2104730", Offset = "0x2104730", VA = "0x2104730")]
	[Token(Token = "0x60024E3")]
	public void method_78(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("poweredup!");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_2;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_3;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x040004CC RID: 1228
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004CC")]
	public GameObject gameObject_0;

	// Token: 0x040004CD RID: 1229
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004CD")]
	public GameObject gameObject_1;

	// Token: 0x040004CE RID: 1230
	[Token(Token = "0x40004CE")]
	[FieldOffset(Offset = "0x28")]
	public GameObject gameObject_2;

	// Token: 0x040004CF RID: 1231
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004CF")]
	public GameObject gameObject_3;
}
