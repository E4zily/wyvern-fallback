﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000E7 RID: 231
[Token(Token = "0x20000E7")]
public class PlayerCosmetics : MonoBehaviour
{
	// Token: 0x0600227A RID: 8826 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A75C40", Offset = "0x2A75C40", VA = "0x2A75C40")]
	[Token(Token = "0x600227A")]
	private void method_0(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600227B RID: 8827 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A75D30", Offset = "0x2A75D30", VA = "0x2A75D30")]
	[Token(Token = "0x600227B")]
	private void method_1(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600227C RID: 8828 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A75DF4", Offset = "0x2A75DF4", VA = "0x2A75DF4")]
	[Token(Token = "0x600227C")]
	private void method_2(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600227D RID: 8829 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A75EE4", Offset = "0x2A75EE4", VA = "0x2A75EE4")]
	[Token(Token = "0x600227D")]
	private void method_3(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600227E RID: 8830 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A75FD4", Offset = "0x2A75FD4", VA = "0x2A75FD4")]
	[Token(Token = "0x600227E")]
	private void method_4(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600227F RID: 8831 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A7609C", Offset = "0x2A7609C", VA = "0x2A7609C")]
	[Token(Token = "0x600227F")]
	private void method_5(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002280 RID: 8832 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A7618C", Offset = "0x2A7618C", VA = "0x2A7618C")]
	[Token(Token = "0x6002280")]
	private void method_6(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002281 RID: 8833 RVA: 0x0003F480 File Offset: 0x0003D680
	[Address(RVA = "0x2A7627C", Offset = "0x2A7627C", VA = "0x2A7627C")]
	[Token(Token = "0x6002281")]
	private void method_7(string string_0)
	{
	}

	// Token: 0x06002282 RID: 8834 RVA: 0x00002068 File Offset: 0x00000268
	[PunRPC]
	[Address(RVA = "0x2A76344", Offset = "0x2A76344", VA = "0x2A76344")]
	[Token(Token = "0x6002282")]
	private void EnableCosmetic(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002283 RID: 8835 RVA: 0x00002068 File Offset: 0x00000268
	[PunRPC]
	[Address(RVA = "0x2A76434", Offset = "0x2A76434", VA = "0x2A76434")]
	[Token(Token = "0x6002283")]
	private void DisableCosmetic(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002284 RID: 8836 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76524", Offset = "0x2A76524", VA = "0x2A76524")]
	[Token(Token = "0x6002284")]
	private void method_8(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002285 RID: 8837 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A765EC", Offset = "0x2A765EC", VA = "0x2A765EC")]
	[Token(Token = "0x6002285")]
	private void method_9(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002286 RID: 8838 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A766B0", Offset = "0x2A766B0", VA = "0x2A766B0")]
	[Token(Token = "0x6002286")]
	private void method_10(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002287 RID: 8839 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A767A0", Offset = "0x2A767A0", VA = "0x2A767A0")]
	[Token(Token = "0x6002287")]
	private void method_11(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002288 RID: 8840 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76890", Offset = "0x2A76890", VA = "0x2A76890")]
	[Token(Token = "0x6002288")]
	private void method_12(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002289 RID: 8841 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76954", Offset = "0x2A76954", VA = "0x2A76954")]
	[Token(Token = "0x6002289")]
	private void method_13(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600228A RID: 8842 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76A44", Offset = "0x2A76A44", VA = "0x2A76A44")]
	[Token(Token = "0x600228A")]
	private void method_14(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600228B RID: 8843 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76B34", Offset = "0x2A76B34", VA = "0x2A76B34")]
	[Token(Token = "0x600228B")]
	private void method_15(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600228C RID: 8844 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A76C24", Offset = "0x2A76C24", VA = "0x2A76C24")]
	[Token(Token = "0x600228C")]
	public PlayerCosmetics()
	{
	}

	// Token: 0x0600228D RID: 8845 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76C2C", Offset = "0x2A76C2C", VA = "0x2A76C2C")]
	[Token(Token = "0x600228D")]
	private void method_16(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600228E RID: 8846 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76CF0", Offset = "0x2A76CF0", VA = "0x2A76CF0")]
	[Token(Token = "0x600228E")]
	private void method_17(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600228F RID: 8847 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76DB4", Offset = "0x2A76DB4", VA = "0x2A76DB4")]
	[Token(Token = "0x600228F")]
	private void method_18(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002290 RID: 8848 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2A76E7C", Offset = "0x2A76E7C", VA = "0x2A76E7C")]
	[Token(Token = "0x6002290")]
	private void method_19(string string_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0400047F RID: 1151
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400047F")]
	public List<GameObject> list_0;
}
