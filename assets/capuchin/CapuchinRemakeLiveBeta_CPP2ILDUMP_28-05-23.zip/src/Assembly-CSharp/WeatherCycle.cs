﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x02000104 RID: 260
[Token(Token = "0x2000104")]
public class WeatherCycle : MonoBehaviour
{
	// Token: 0x06002789 RID: 10121 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2104804", Offset = "0x2104804", VA = "0x2104804")]
	[Token(Token = "0x6002789")]
	private void method_0()
	{
	}

	// Token: 0x0600278A RID: 10122 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2104904", Offset = "0x2104904", VA = "0x2104904")]
	[Token(Token = "0x600278A")]
	private void method_1()
	{
	}

	// Token: 0x0600278B RID: 10123 RVA: 0x00051600 File Offset: 0x0004F800
	[Address(RVA = "0x2104A04", Offset = "0x2104A04", VA = "0x2104A04")]
	[Token(Token = "0x600278B")]
	public void method_2()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("TurnAmount", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0600278C RID: 10124 RVA: 0x000516B0 File Offset: 0x0004F8B0
	[Address(RVA = "0x2104BEC", Offset = "0x2104BEC", VA = "0x2104BEC")]
	[Token(Token = "0x600278C")]
	public void method_3()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("CapuchinRemade");
			material2 = this.material_2;
			material2.GetColor("PURCHASED");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:");
		this.material_2.GetColor("Push To Talk");
	}

	// Token: 0x0600278D RID: 10125 RVA: 0x00051754 File Offset: 0x0004F954
	[Address(RVA = "0x2104F38", Offset = "0x2104F38", VA = "0x2104F38")]
	[Token(Token = "0x600278D")]
	public void method_4()
	{
		LightmapData lightmapData = new LightmapData();
		Texture2D lightmapColor = this.texture2D_0;
		lightmapData.lightmapColor = lightmapColor;
		LightmapData[] lightmaps = LightmapSettings.lightmaps;
		if (lightmapData == null)
		{
			throw new ArrayTypeMismatchException();
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("SetColor");
			material2 = this.material_2;
			material2.GetColor("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("Charged!");
		this.material_2.GetColor("TurnAmount");
	}

	// Token: 0x0600278E RID: 10126 RVA: 0x000517F0 File Offset: 0x0004F9F0
	[Address(RVA = "0x2105284", Offset = "0x2105284", VA = "0x2105284")]
	[Token(Token = "0x600278E")]
	public void method_5()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Player", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x0600278F RID: 10127 RVA: 0x00051890 File Offset: 0x0004FA90
	[Address(RVA = "0x2105474", Offset = "0x2105474", VA = "0x2105474")]
	[Token(Token = "0x600278F")]
	private void method_6()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.float_5 = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("_WobbleZ", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)8192;
	}

	// Token: 0x06002790 RID: 10128 RVA: 0x00051994 File Offset: 0x0004FB94
	[Address(RVA = "0x210583C", Offset = "0x210583C", VA = "0x210583C")]
	[Token(Token = "0x6002790")]
	public void method_7()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Camera movement detected, calibrating height.", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x06002791 RID: 10129 RVA: 0x00051A44 File Offset: 0x0004FC44
	[Address(RVA = "0x2105A24", Offset = "0x2105A24", VA = "0x2105A24")]
	[Token(Token = "0x6002791")]
	public void method_8()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("Mesh");
			material2 = this.material_2;
			material2.GetColor("unlocked!");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("_BaseColor");
		this.material_2.GetColor("CapuchinRemade");
	}

	// Token: 0x06002792 RID: 10130 RVA: 0x00051AFC File Offset: 0x0004FCFC
	[Address(RVA = "0x2105D6C", Offset = "0x2105D6C", VA = "0x2105D6C")]
	[Token(Token = "0x6002792")]
	public void method_9()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x06002793 RID: 10131 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2105F54", Offset = "0x2105F54", VA = "0x2105F54")]
	[Token(Token = "0x6002793")]
	private void method_10()
	{
	}

	// Token: 0x06002794 RID: 10132 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2106054", Offset = "0x2106054", VA = "0x2106054")]
	[Token(Token = "0x6002794")]
	private void method_11()
	{
	}

	// Token: 0x06002795 RID: 10133 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2106154", Offset = "0x2106154", VA = "0x2106154")]
	[Token(Token = "0x6002795")]
	private void method_12()
	{
	}

	// Token: 0x06002796 RID: 10134 RVA: 0x00051BAC File Offset: 0x0004FDAC
	[Address(RVA = "0x2106254", Offset = "0x2106254", VA = "0x2106254")]
	[Token(Token = "0x6002796")]
	public void method_13()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)17332;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("FingerTip", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)16448;
	}

	// Token: 0x06002797 RID: 10135 RVA: 0x00051CCC File Offset: 0x0004FECC
	[PunRPC]
	[Address(RVA = "0x210660C", Offset = "0x210660C", VA = "0x210660C")]
	[Token(Token = "0x6002797")]
	public void NormalWeather()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value = Mathf.Lerp(deltaTime2, fogEndDistance, fogEndDistance);
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		float deltaTime3 = Time.deltaTime;
		Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float a = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num2 = Mathf.Lerp(a, fogEndDistance, fogEndDistance);
		audioSource.volume = num2;
	}

	// Token: 0x06002798 RID: 10136 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x21067E8", Offset = "0x21067E8", VA = "0x21067E8")]
	[Token(Token = "0x6002798")]
	public WeatherCycle()
	{
	}

	// Token: 0x06002799 RID: 10137 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2106868", Offset = "0x2106868", VA = "0x2106868")]
	[Token(Token = "0x6002799")]
	private void method_14()
	{
	}

	// Token: 0x0600279A RID: 10138 RVA: 0x00051DB0 File Offset: 0x0004FFB0
	[Token(Token = "0x600279A")]
	[Address(RVA = "0x2106968", Offset = "0x2106968", VA = "0x2106968")]
	public void method_15()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Faild To Add Winner Money: ", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0600279B RID: 10139 RVA: 0x00051E60 File Offset: 0x00050060
	[Token(Token = "0x600279B")]
	[Address(RVA = "0x2106B50", Offset = "0x2106B50", VA = "0x2106B50")]
	public void method_16()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("Add/Remove Sword");
			material2 = this.material_2;
			material2.GetColor("ChangeToRegular");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("Player");
		this.material_2.GetColor("NGNNoSound");
	}

	// Token: 0x0600279C RID: 10140 RVA: 0x00051F04 File Offset: 0x00050104
	[Address(RVA = "0x2106E74", Offset = "0x2106E74", VA = "0x2106E74")]
	[Token(Token = "0x600279C")]
	public void method_17()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("liftoff failed!", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x0600279D RID: 10141 RVA: 0x00051FC0 File Offset: 0x000501C0
	[Address(RVA = "0x2107060", Offset = "0x2107060", VA = "0x2107060")]
	[Token(Token = "0x600279D")]
	public void method_18()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Player", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0600279E RID: 10142 RVA: 0x00051FC0 File Offset: 0x000501C0
	[Address(RVA = "0x2107248", Offset = "0x2107248", VA = "0x2107248")]
	[Token(Token = "0x600279E")]
	public void method_19()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Player", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0600279F RID: 10143 RVA: 0x00052070 File Offset: 0x00050270
	[Address(RVA = "0x2107434", Offset = "0x2107434", VA = "0x2107434")]
	[Token(Token = "0x600279F")]
	public void method_20()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("casual", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x060027A0 RID: 10144 RVA: 0x0005212C File Offset: 0x0005032C
	[Address(RVA = "0x2107624", Offset = "0x2107624", VA = "0x2107624")]
	[Token(Token = "0x60027A0")]
	private void method_21()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		this.thunder_0.strike.Play();
		this.float_5 = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		float deltaTime4 = Time.deltaTime;
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)32768;
	}

	// Token: 0x060027A1 RID: 10145 RVA: 0x00052228 File Offset: 0x00050428
	[Address(RVA = "0x21079EC", Offset = "0x21079EC", VA = "0x21079EC")]
	[Token(Token = "0x60027A1")]
	public void method_22()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)40960;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("EnableCosmetic", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17653;
	}

	// Token: 0x060027A2 RID: 10146 RVA: 0x00052340 File Offset: 0x00050540
	[Address(RVA = "0x2107DA4", Offset = "0x2107DA4", VA = "0x2107DA4")]
	[Token(Token = "0x60027A2")]
	private void method_23()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17070;
	}

	// Token: 0x060027A3 RID: 10147 RVA: 0x00052460 File Offset: 0x00050660
	[Address(RVA = "0x2108168", Offset = "0x2108168", VA = "0x2108168")]
	[Token(Token = "0x60027A3")]
	public void method_24()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("Updating Material to: ");
			material2 = this.material_2;
			material2.GetColor("[InputHelpers.IsPressed] The value of <button> is out or the supported range.");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("containsStaff");
		this.material_2.GetColor("_Tint");
	}

	// Token: 0x060027A4 RID: 10148 RVA: 0x00052504 File Offset: 0x00050704
	[Address(RVA = "0x21084B4", Offset = "0x21084B4", VA = "0x21084B4")]
	[Token(Token = "0x60027A4")]
	public void method_25()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("true");
			material2 = this.material_2;
			material2.GetColor("HorrorAgreement");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor(". Please update you game to the latest version");
		this.material_2.GetColor("username");
	}

	// Token: 0x060027A5 RID: 10149 RVA: 0x000525BC File Offset: 0x000507BC
	[Address(RVA = "0x21087FC", Offset = "0x21087FC", VA = "0x21087FC")]
	[Token(Token = "0x60027A5")]
	public void method_26()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat(".Please press the button if you would like to play alone", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027A6 RID: 10150 RVA: 0x0005266C File Offset: 0x0005086C
	[Address(RVA = "0x21089E4", Offset = "0x21089E4", VA = "0x21089E4")]
	[Token(Token = "0x60027A6")]
	public void method_27()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			if (lightmaps.m_Dir == null)
			{
				throw new IndexOutOfRangeException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("HandR");
			material2 = this.material_2;
			material2.GetColor("");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("make more points bobo");
		this.material_2.GetColor("Player");
	}

	// Token: 0x060027A7 RID: 10151 RVA: 0x00052724 File Offset: 0x00050924
	[Address(RVA = "0x2108D2C", Offset = "0x2108D2C", VA = "0x2108D2C")]
	[Token(Token = "0x60027A7")]
	public void method_28()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("_Color", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027A8 RID: 10152 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Token(Token = "0x60027A8")]
	[Address(RVA = "0x2108F18", Offset = "0x2108F18", VA = "0x2108F18")]
	private void method_29()
	{
	}

	// Token: 0x060027A9 RID: 10153 RVA: 0x000527D4 File Offset: 0x000509D4
	[Address(RVA = "0x2109018", Offset = "0x2109018", VA = "0x2109018")]
	[Token(Token = "0x60027A9")]
	private void method_30()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17474;
	}

	// Token: 0x060027AA RID: 10154 RVA: 0x000528F4 File Offset: 0x00050AF4
	[Address(RVA = "0x21093DC", Offset = "0x21093DC", VA = "0x21093DC")]
	[Token(Token = "0x60027AA")]
	public void method_31()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("1BN", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x060027AB RID: 10155 RVA: 0x000529A8 File Offset: 0x00050BA8
	[Address(RVA = "0x21095C8", Offset = "0x21095C8", VA = "0x21095C8")]
	[Token(Token = "0x60027AB")]
	private void method_32()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("NetworkPlayer", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17377;
	}

	// Token: 0x060027AC RID: 10156 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2109988", Offset = "0x2109988", VA = "0x2109988")]
	[Token(Token = "0x60027AC")]
	private void method_33()
	{
	}

	// Token: 0x060027AD RID: 10157 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2109A88", Offset = "0x2109A88", VA = "0x2109A88")]
	[Token(Token = "0x60027AD")]
	private void method_34()
	{
	}

	// Token: 0x060027AE RID: 10158 RVA: 0x00052AC8 File Offset: 0x00050CC8
	[Address(RVA = "0x2109B88", Offset = "0x2109B88", VA = "0x2109B88")]
	[Token(Token = "0x60027AE")]
	public void method_35()
	{
		if (this.bool_4)
		{
			Texture2D dir = LightmapSettings.lightmaps.m_Dir;
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor(". Please update you game to the latest version");
			material2 = this.material_2;
			material2.GetColor("isLava");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2;
			RenderSettings.ambientSkyColor = ambientSkyColor2;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor5 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("NormalWeather");
		this.material_2.GetColor("CapuchinStore");
	}

	// Token: 0x060027AF RID: 10159 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2109ED4", Offset = "0x2109ED4", VA = "0x2109ED4")]
	[Token(Token = "0x60027AF")]
	private void method_36()
	{
	}

	// Token: 0x060027B0 RID: 10160 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2109FD4", Offset = "0x2109FD4", VA = "0x2109FD4")]
	[Token(Token = "0x60027B0")]
	private void method_37()
	{
	}

	// Token: 0x060027B1 RID: 10161 RVA: 0x00052B58 File Offset: 0x00050D58
	[Address(RVA = "0x210A0D4", Offset = "0x210A0D4", VA = "0x210A0D4")]
	[Token(Token = "0x60027B1")]
	public void method_38()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
			lightmaps.m_ShadowMask = lightmapData;
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("deathScream");
			material2 = this.material_2;
			material2.GetColor("goDownRPC");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("Vertical");
		this.material_2.GetColor("User has been reported for: ");
	}

	// Token: 0x060027B2 RID: 10162 RVA: 0x00052C04 File Offset: 0x00050E04
	[Address(RVA = "0x210A41C", Offset = "0x210A41C", VA = "0x210A41C")]
	[Token(Token = "0x60027B2")]
	public void method_39()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("cheeseTouch", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060027B3 RID: 10163 RVA: 0x00052CA8 File Offset: 0x00050EA8
	[Address(RVA = "0x210A604", Offset = "0x210A604", VA = "0x210A604")]
	[Token(Token = "0x60027B3")]
	private void method_40()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("FingerTip", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)32768;
	}

	// Token: 0x060027B4 RID: 10164 RVA: 0x00052DBC File Offset: 0x00050FBC
	[Address(RVA = "0x210A9CC", Offset = "0x210A9CC", VA = "0x210A9CC")]
	[Token(Token = "0x60027B4")]
	public void method_41()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)17434;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("User has been reported for: ", value);
		AudioSource audioSource;
		if (this.bool_1)
		{
			audioSource = this.audioSource_0;
			audioSource.Play();
		}
		AudioSource audioSource2 = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource2.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)16384;
	}

	// Token: 0x060027B5 RID: 10165 RVA: 0x00052ED8 File Offset: 0x000510D8
	[Address(RVA = "0x210AD84", Offset = "0x210AD84", VA = "0x210AD84")]
	[Token(Token = "0x60027B5")]
	public void method_42()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Added Winner Money", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027B6 RID: 10166 RVA: 0x00052F88 File Offset: 0x00051188
	[Token(Token = "0x60027B6")]
	[Address(RVA = "0x210AF68", Offset = "0x210AF68", VA = "0x210AF68")]
	private void method_43()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Updating Material to: ", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)8192;
	}

	// Token: 0x060027B7 RID: 10167 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x210B328", Offset = "0x210B328", VA = "0x210B328")]
	[Token(Token = "0x60027B7")]
	private void method_44()
	{
	}

	// Token: 0x060027B8 RID: 10168 RVA: 0x00053090 File Offset: 0x00051290
	[Address(RVA = "0x210B428", Offset = "0x210B428", VA = "0x210B428")]
	[Token(Token = "0x60027B8")]
	public void method_45()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("username", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027B9 RID: 10169 RVA: 0x00053140 File Offset: 0x00051340
	[Address(RVA = "0x210B614", Offset = "0x210B614", VA = "0x210B614")]
	[Token(Token = "0x60027B9")]
	public void method_46()
	{
		Color fogColor = RenderSettings.fogColor;
		Vector4 v;
		v;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Added Winner Money", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17600;
	}

	// Token: 0x060027BA RID: 10170 RVA: 0x00053260 File Offset: 0x00051460
	[Token(Token = "0x60027BA")]
	[Address(RVA = "0x210B9CC", Offset = "0x210B9CC", VA = "0x210B9CC")]
	public void method_47()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
	}

	// Token: 0x060027BB RID: 10171 RVA: 0x00053360 File Offset: 0x00051560
	[Address(RVA = "0x210BD50", Offset = "0x210BD50", VA = "0x210BD50")]
	[Token(Token = "0x60027BB")]
	public void method_48()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("ErrorScreen", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027BC RID: 10172 RVA: 0x00053410 File Offset: 0x00051610
	[Address(RVA = "0x210BF38", Offset = "0x210BF38", VA = "0x210BF38")]
	[Token(Token = "0x60027BC")]
	public void method_49()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		WeatherCycle.Thunder thunder = this.thunder_0;
		this.thunder_0.strike.Play();
		this.float_5 = thunder;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}", value);
		this.audioSource_0.Play();
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)16384;
	}

	// Token: 0x060027BD RID: 10173 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Token(Token = "0x60027BD")]
	[Address(RVA = "0x210C2F8", Offset = "0x210C2F8", VA = "0x210C2F8")]
	private void method_50()
	{
	}

	// Token: 0x060027BE RID: 10174 RVA: 0x00053524 File Offset: 0x00051724
	[Token(Token = "0x60027BE")]
	[Address(RVA = "0x210C3F8", Offset = "0x210C3F8", VA = "0x210C3F8")]
	public void method_51()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027BF RID: 10175 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x210C5E0", Offset = "0x210C5E0", VA = "0x210C5E0")]
	[Token(Token = "0x60027BF")]
	private void method_52()
	{
	}

	// Token: 0x060027C0 RID: 10176 RVA: 0x000535D4 File Offset: 0x000517D4
	[Token(Token = "0x60027C0")]
	[Address(RVA = "0x210C6E0", Offset = "0x210C6E0", VA = "0x210C6E0")]
	public void method_53()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)17348;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("FingerTip", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)49152;
	}

	// Token: 0x060027C1 RID: 10177 RVA: 0x000536E8 File Offset: 0x000518E8
	[Token(Token = "0x60027C1")]
	[Address(RVA = "0x210CAA0", Offset = "0x210CAA0", VA = "0x210CAA0")]
	public void method_54()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("Not connected to room");
			material2 = this.material_2;
			material2.GetColor("containsStaff");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("M/d/yyyy");
		this.material_2.GetColor("CapuchinRemade");
	}

	// Token: 0x060027C2 RID: 10178 RVA: 0x0005378C File Offset: 0x0005198C
	[Address(RVA = "0x210CDEC", Offset = "0x210CDEC", VA = "0x210CDEC")]
	[Token(Token = "0x60027C2")]
	private void method_55()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Photon token acquired!", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)16384;
	}

	// Token: 0x060027C3 RID: 10179 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Token(Token = "0x60027C3")]
	[Address(RVA = "0x210D1B0", Offset = "0x210D1B0", VA = "0x210D1B0")]
	private void method_56()
	{
	}

	// Token: 0x060027C4 RID: 10180 RVA: 0x000538AC File Offset: 0x00051AAC
	[Token(Token = "0x60027C4")]
	[Address(RVA = "0x210D2B0", Offset = "0x210D2B0", VA = "0x210D2B0")]
	private void method_57()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Vector3 position = this.thunder_0.thunderThing.transform.position;
		this.thunder_0.strike.Play();
		this.float_5 = (float)8192;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Updating Material to: ", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17302;
	}

	// Token: 0x060027C5 RID: 10181 RVA: 0x000539D4 File Offset: 0x00051BD4
	[Address(RVA = "0x210D670", Offset = "0x210D670", VA = "0x210D670")]
	[Token(Token = "0x60027C5")]
	private void method_58()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Creating and loadingtexture", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num3 = 1L;
			this.bool_1 = (num3 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num4 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num5;
		audioSource.volume = num5;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)16384;
	}

	// Token: 0x060027C6 RID: 10182 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x210DA3C", Offset = "0x210DA3C", VA = "0x210DA3C")]
	[Token(Token = "0x60027C6")]
	private void method_59()
	{
	}

	// Token: 0x060027C7 RID: 10183 RVA: 0x00053B00 File Offset: 0x00051D00
	[Address(RVA = "0x210DB3C", Offset = "0x210DB3C", VA = "0x210DB3C")]
	[Token(Token = "0x60027C7")]
	private void method_60()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Player", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		float deltaTime5 = Time.deltaTime;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17327;
	}

	// Token: 0x060027C8 RID: 10184 RVA: 0x00053BF4 File Offset: 0x00051DF4
	[Token(Token = "0x60027C8")]
	[Address(RVA = "0x210DEFC", Offset = "0x210DEFC", VA = "0x210DEFC")]
	public void method_61()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("ORGPORT", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027C9 RID: 10185 RVA: 0x00053CA4 File Offset: 0x00051EA4
	[Token(Token = "0x60027C9")]
	[Address(RVA = "0x210E0E4", Offset = "0x210E0E4", VA = "0x210E0E4")]
	public void method_62()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Players: ", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060027CA RID: 10186 RVA: 0x00053D48 File Offset: 0x00051F48
	[Address(RVA = "0x210E2D0", Offset = "0x210E2D0", VA = "0x210E2D0")]
	[Token(Token = "0x60027CA")]
	public void method_63()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)17401;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("_WobbleX", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)49152;
	}

	// Token: 0x060027CB RID: 10187 RVA: 0x00053E60 File Offset: 0x00052060
	[Token(Token = "0x60027CB")]
	[Address(RVA = "0x210E68C", Offset = "0x210E68C", VA = "0x210E68C")]
	public void method_64()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("PushToTalk", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17180;
	}

	// Token: 0x060027CC RID: 10188 RVA: 0x00053F80 File Offset: 0x00052180
	[Address(RVA = "0x210EA4C", Offset = "0x210EA4C", VA = "0x210EA4C")]
	[Token(Token = "0x60027CC")]
	public void method_65()
	{
		long num = 1L;
		this.bool_0 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("username", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x060027CD RID: 10189 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x210EC3C", Offset = "0x210EC3C", VA = "0x210EC3C")]
	[Token(Token = "0x60027CD")]
	private void method_66()
	{
	}

	// Token: 0x060027CE RID: 10190 RVA: 0x00051CCC File Offset: 0x0004FECC
	[Token(Token = "0x60027CE")]
	[Address(RVA = "0x210ED3C", Offset = "0x210ED3C", VA = "0x210ED3C")]
	public void method_67()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value = Mathf.Lerp(deltaTime2, fogEndDistance, fogEndDistance);
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		float deltaTime3 = Time.deltaTime;
		Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		Mathf.Lerp(fogEndDistance, fogEndDistance, fogEndDistance);
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float a = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num2 = Mathf.Lerp(a, fogEndDistance, fogEndDistance);
		audioSource.volume = num2;
	}

	// Token: 0x060027CF RID: 10191 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Token(Token = "0x60027CF")]
	[Address(RVA = "0x210EF14", Offset = "0x210EF14", VA = "0x210EF14")]
	private void method_68()
	{
	}

	// Token: 0x060027D0 RID: 10192 RVA: 0x0005403C File Offset: 0x0005223C
	[Token(Token = "0x60027D0")]
	[Address(RVA = "0x210F014", Offset = "0x210F014", VA = "0x210F014")]
	public void FixedUpdate()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material = this.material_1;
		bool flag = this.bool_3;
		material.GetColor("_Tint");
		if (flag)
		{
			this.material_2.GetColor("_Tint");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		this.material_2.GetColor("_Tint");
	}

	// Token: 0x060027D1 RID: 10193 RVA: 0x000540D0 File Offset: 0x000522D0
	[Address(RVA = "0x210F2C4", Offset = "0x210F2C4", VA = "0x210F2C4")]
	[Token(Token = "0x60027D1")]
	public void method_69()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		float deltaTime4 = Time.deltaTime;
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)17319;
	}

	// Token: 0x060027D2 RID: 10194 RVA: 0x000541CC File Offset: 0x000523CC
	[Address(RVA = "0x210F680", Offset = "0x210F680", VA = "0x210F680")]
	[Token(Token = "0x60027D2")]
	public void method_70()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)17493;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Universal Render Pipeline/Lit", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)49152;
	}

	// Token: 0x060027D3 RID: 10195 RVA: 0x000542E4 File Offset: 0x000524E4
	[Token(Token = "0x60027D3")]
	[Address(RVA = "0x210FA38", Offset = "0x210FA38", VA = "0x210FA38")]
	public void method_71()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("PRESS AGAIN TO CONFIRM", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)8192;
	}

	// Token: 0x060027D4 RID: 10196 RVA: 0x000543EC File Offset: 0x000525EC
	[Token(Token = "0x60027D4")]
	[Address(RVA = "0x210FDF4", Offset = "0x210FDF4", VA = "0x210FDF4")]
	public void method_72()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Trigger", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027D5 RID: 10197 RVA: 0x0005449C File Offset: 0x0005269C
	[Token(Token = "0x60027D5")]
	[Address(RVA = "0x210FFDC", Offset = "0x210FFDC", VA = "0x210FFDC")]
	public void method_73()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("character limit reached", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027D6 RID: 10198 RVA: 0x0005454C File Offset: 0x0005274C
	[Address(RVA = "0x21101C8", Offset = "0x21101C8", VA = "0x21101C8")]
	[Token(Token = "0x60027D6")]
	private void method_74()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)24576;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Did Hit", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)24576;
	}

	// Token: 0x060027D7 RID: 10199 RVA: 0x00051FC0 File Offset: 0x000501C0
	[Address(RVA = "0x211058C", Offset = "0x211058C", VA = "0x211058C")]
	[Token(Token = "0x60027D7")]
	public void method_75()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Player", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027D8 RID: 10200 RVA: 0x0005466C File Offset: 0x0005286C
	[Token(Token = "0x60027D8")]
	[Address(RVA = "0x2110774", Offset = "0x2110774", VA = "0x2110774")]
	public void method_76()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Player was caught cheating", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027D9 RID: 10201 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Token(Token = "0x60027D9")]
	[Address(RVA = "0x211095C", Offset = "0x211095C", VA = "0x211095C")]
	private void method_77()
	{
	}

	// Token: 0x060027DA RID: 10202 RVA: 0x0005471C File Offset: 0x0005291C
	[Address(RVA = "0x2110A5C", Offset = "0x2110A5C", VA = "0x2110A5C")]
	[Token(Token = "0x60027DA")]
	public void method_78()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("{0} ({1})", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027DB RID: 10203 RVA: 0x000547CC File Offset: 0x000529CC
	[Address(RVA = "0x2110C44", Offset = "0x2110C44", VA = "0x2110C44")]
	[Token(Token = "0x60027DB")]
	public void method_79()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("Player");
			material2 = this.material_2;
			material2.GetColor("_Tint");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("Right Hand");
		this.material_2.GetColor("ChangeMaterialToNormal");
	}

	// Token: 0x060027DC RID: 10204 RVA: 0x00054870 File Offset: 0x00052A70
	[Token(Token = "0x60027DC")]
	[Address(RVA = "0x2110F90", Offset = "0x2110F90", VA = "0x2110F90")]
	[PunRPC]
	private void RainAndThunderWeather()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
	}

	// Token: 0x060027DD RID: 10205 RVA: 0x0005497C File Offset: 0x00052B7C
	[Token(Token = "0x60027DD")]
	[Address(RVA = "0x211131C", Offset = "0x211131C", VA = "0x211131C")]
	public void method_80()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material = this.material_1;
		Material material2;
		if (this.bool_3)
		{
			material.GetColor("Version");
			material2 = this.material_2;
			material2.GetColor("Player");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material2.GetColor("Open");
		this.material_2.GetColor("A Player has left the Room.");
	}

	// Token: 0x060027DE RID: 10206 RVA: 0x00054A20 File Offset: 0x00052C20
	[Token(Token = "0x60027DE")]
	[Address(RVA = "0x2111668", Offset = "0x2111668", VA = "0x2111668")]
	private void method_81()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Transform transform = this.thunder_0.thunderThing.transform;
		this.thunder_0.strike.Play();
		this.float_5 = (float)24576;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		float deltaTime5 = Time.deltaTime;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)16384;
	}

	// Token: 0x060027DF RID: 10207 RVA: 0x00054B28 File Offset: 0x00052D28
	[Address(RVA = "0x2111A2C", Offset = "0x2111A2C", VA = "0x2111A2C")]
	[Token(Token = "0x60027DF")]
	private void method_82()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		long num = 1L;
		this.bool_0 = (num != 0L);
		Transform transform = this.thunder_0.thunderThing.transform;
		long maxExclusive = 0L;
		UnityEngine.Random.Range(0, (int)maxExclusive);
		this.thunder_0.strike.Play();
		this.float_5 = (float)17215;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num2;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("procedural animation script required on ", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)32768;
	}

	// Token: 0x060027E0 RID: 10208 RVA: 0x00054C4C File Offset: 0x00052E4C
	[Address(RVA = "0x2111DF0", Offset = "0x2111DF0", VA = "0x2111DF0")]
	[Token(Token = "0x60027E0")]
	public void method_83()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("HOLY MOLY THE STICK IS ON FIRE!!!!!!", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027E1 RID: 10209 RVA: 0x000515F0 File Offset: 0x0004F7F0
	[Address(RVA = "0x2111FD8", Offset = "0x2111FD8", VA = "0x2111FD8")]
	[Token(Token = "0x60027E1")]
	private void method_84()
	{
	}

	// Token: 0x060027E2 RID: 10210 RVA: 0x00054CFC File Offset: 0x00052EFC
	[Token(Token = "0x60027E2")]
	[Address(RVA = "0x21120D8", Offset = "0x21120D8", VA = "0x21120D8")]
	public void method_85()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("spatial", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027E3 RID: 10211 RVA: 0x00054DAC File Offset: 0x00052FAC
	[Token(Token = "0x60027E3")]
	[Address(RVA = "0x21122C0", Offset = "0x21122C0", VA = "0x21122C0")]
	public void method_86()
	{
		Color fogColor = RenderSettings.fogColor;
		this.particleSystem_0.Play();
		this.thunder_0.strike.Play();
		this.float_5 = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float fogEndDistance2 = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime3 = Time.deltaTime;
		volume.weight = flspeed;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("GET", value);
		if (this.bool_1)
		{
			this.audioSource_0.Play();
		}
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
		float fogEndDistance3 = RenderSettings.fogEndDistance;
		this.float_4 = (float)49152;
	}

	// Token: 0x060027E4 RID: 10212 RVA: 0x00054EB0 File Offset: 0x000530B0
	[Token(Token = "0x60027E4")]
	[Address(RVA = "0x211267C", Offset = "0x211267C", VA = "0x211267C")]
	public void method_87()
	{
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float flspeed = this.lerpSpeeds_0.FLspeed;
		Material material = this.material_0;
		this.lerpSpeeds_0.FLspeed = flspeed;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("FingerTip", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_2 = flspeed;
		float deltaTime4 = Time.deltaTime;
		volume.weight = flspeed;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x060027E5 RID: 10213 RVA: 0x00054F60 File Offset: 0x00053160
	[Address(RVA = "0x2112864", Offset = "0x2112864", VA = "0x2112864")]
	[Token(Token = "0x60027E5")]
	public void method_88()
	{
		if (this.bool_4)
		{
			LightmapData lightmapData = new LightmapData();
			Texture2D lightmapColor = this.texture2D_0;
			lightmapData.lightmapColor = lightmapColor;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			if (lightmapData == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}
		Material material;
		if (this.bool_3)
		{
			material = this.material_2;
			material.GetColor("PlayerHead");
			Color ambientSkyColor = RenderSettings.ambientSkyColor;
			Color ambientSkyColor2 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor3 = RenderSettings.ambientSkyColor;
			Color ambientSkyColor4 = RenderSettings.ambientSkyColor;
			return;
		}
		material.GetColor("HDRP/Lit");
		this.material_2.GetColor("deathScream");
	}

	// Token: 0x0400050F RID: 1295
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400050F")]
	public float float_0;

	// Token: 0x04000510 RID: 1296
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000510")]
	public float float_1;

	// Token: 0x04000511 RID: 1297
	[Token(Token = "0x4000511")]
	[FieldOffset(Offset = "0x20")]
	public WeatherCycle.GEnum12 genum12_0;

	// Token: 0x04000512 RID: 1298
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4000512")]
	public Color color_0;

	// Token: 0x04000513 RID: 1299
	[Token(Token = "0x4000513")]
	[FieldOffset(Offset = "0x38")]
	public ParticleSystem particleSystem_0;

	// Token: 0x04000514 RID: 1300
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000514")]
	public bool bool_0;

	// Token: 0x04000515 RID: 1301
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000515")]
	public Material material_0;

	// Token: 0x04000516 RID: 1302
	[Token(Token = "0x4000516")]
	[FieldOffset(Offset = "0x50")]
	public WeatherCycle.lerpSpeeds lerpSpeeds_0;

	// Token: 0x04000517 RID: 1303
	[Token(Token = "0x4000517")]
	[FieldOffset(Offset = "0x68")]
	[SerializeField]
	private Volume volume;

	// Token: 0x04000518 RID: 1304
	[Token(Token = "0x4000518")]
	[FieldOffset(Offset = "0x70")]
	private float float_2;

	// Token: 0x04000519 RID: 1305
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000519")]
	public GameObject gameObject_0;

	// Token: 0x0400051A RID: 1306
	[Token(Token = "0x400051A")]
	[FieldOffset(Offset = "0x80")]
	public AudioSource audioSource_0;

	// Token: 0x0400051B RID: 1307
	[Token(Token = "0x400051B")]
	[FieldOffset(Offset = "0x88")]
	private float float_3;

	// Token: 0x0400051C RID: 1308
	[Token(Token = "0x400051C")]
	[FieldOffset(Offset = "0x8C")]
	public bool bool_1;

	// Token: 0x0400051D RID: 1309
	[Token(Token = "0x400051D")]
	[FieldOffset(Offset = "0x90")]
	public WeatherCycle.Thunder thunder_0;

	// Token: 0x0400051E RID: 1310
	[Token(Token = "0x400051E")]
	[FieldOffset(Offset = "0xB8")]
	public WeatherCycle.Photon photon_0;

	// Token: 0x0400051F RID: 1311
	[Token(Token = "0x400051F")]
	[FieldOffset(Offset = "0xC0")]
	private bool bool_2;

	// Token: 0x04000520 RID: 1312
	[Token(Token = "0x4000520")]
	[FieldOffset(Offset = "0xC4")]
	private float float_4;

	// Token: 0x04000521 RID: 1313
	[Token(Token = "0x4000521")]
	[FieldOffset(Offset = "0xC8")]
	private float float_5;

	// Token: 0x04000522 RID: 1314
	[FieldOffset(Offset = "0xCC")]
	[Token(Token = "0x4000522")]
	public bool bool_3;

	// Token: 0x04000523 RID: 1315
	[Token(Token = "0x4000523")]
	[FieldOffset(Offset = "0xD0")]
	public Material material_1;

	// Token: 0x04000524 RID: 1316
	[Token(Token = "0x4000524")]
	[FieldOffset(Offset = "0xD8")]
	public Material material_2;

	// Token: 0x04000525 RID: 1317
	[Token(Token = "0x4000525")]
	[FieldOffset(Offset = "0xE0")]
	public float float_6;

	// Token: 0x04000526 RID: 1318
	[FieldOffset(Offset = "0xE4")]
	[Token(Token = "0x4000526")]
	private Color color_1;

	// Token: 0x04000527 RID: 1319
	[Token(Token = "0x4000527")]
	[FieldOffset(Offset = "0xF4")]
	private Color color_2;

	// Token: 0x04000528 RID: 1320
	[Token(Token = "0x4000528")]
	[FieldOffset(Offset = "0x104")]
	public Color color_3;

	// Token: 0x04000529 RID: 1321
	[Token(Token = "0x4000529")]
	[FieldOffset(Offset = "0x118")]
	public Texture2D texture2D_0;

	// Token: 0x0400052A RID: 1322
	[Token(Token = "0x400052A")]
	[FieldOffset(Offset = "0x120")]
	public Texture2D texture2D_1;

	// Token: 0x0400052B RID: 1323
	[FieldOffset(Offset = "0x128")]
	[Token(Token = "0x400052B")]
	public bool bool_4;

	// Token: 0x02000105 RID: 261
	[Token(Token = "0x2000105")]
	public enum GEnum12
	{
		// Token: 0x0400052D RID: 1325
		[Token(Token = "0x400052D")]
		const_0,
		// Token: 0x0400052E RID: 1326
		[Token(Token = "0x400052E")]
		[InspectorName("Rain & Thunder")]
		const_1
	}

	// Token: 0x02000106 RID: 262
	[Token(Token = "0x2000106")]
	[Serializable]
	public struct lerpSpeeds
	{
		// Token: 0x0400052F RID: 1327
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400052F")]
		[Header("Lerp Values (Order should be 10, 1, 1, and 1)")]
		public float FLspeed;

		// Token: 0x04000530 RID: 1328
		[Token(Token = "0x4000530")]
		[FieldOffset(Offset = "0x4")]
		public float volumeWeightSpeed;

		// Token: 0x04000531 RID: 1329
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4000531")]
		public float RLspeed;

		// Token: 0x04000532 RID: 1330
		[Token(Token = "0x4000532")]
		[FieldOffset(Offset = "0xC")]
		public float RALspeed;

		// Token: 0x04000533 RID: 1331
		[Token(Token = "0x4000533")]
		[FieldOffset(Offset = "0x10")]
		public float cloudLerpSpeed;
	}

	// Token: 0x02000107 RID: 263
	[Token(Token = "0x2000107")]
	[Serializable]
	public struct Thunder
	{
		// Token: 0x04000534 RID: 1332
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000534")]
		public Transform[] possibleLightningStrikes;

		// Token: 0x04000535 RID: 1333
		[Token(Token = "0x4000535")]
		[FieldOffset(Offset = "0x8")]
		public AudioSource thunder;

		// Token: 0x04000536 RID: 1334
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000536")]
		public AudioClip[] sounds;

		// Token: 0x04000537 RID: 1335
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000537")]
		public ParticleSystem strike;

		// Token: 0x04000538 RID: 1336
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000538")]
		public GameObject thunderThing;
	}

	// Token: 0x02000108 RID: 264
	[Token(Token = "0x2000108")]
	[Serializable]
	public struct Photon
	{
		// Token: 0x04000539 RID: 1337
		[Token(Token = "0x4000539")]
		[FieldOffset(Offset = "0x0")]
		public PhotonView photonView;
	}
}
