﻿using System;
using Cpp2IlInjected;

// Token: 0x02000151 RID: 337
[Token(Token = "0x2000151")]
public enum GEnum15
{
	// Token: 0x04000830 RID: 2096
	[Token(Token = "0x4000830")]
	const_0,
	// Token: 0x04000831 RID: 2097
	[Token(Token = "0x4000831")]
	const_1
}
