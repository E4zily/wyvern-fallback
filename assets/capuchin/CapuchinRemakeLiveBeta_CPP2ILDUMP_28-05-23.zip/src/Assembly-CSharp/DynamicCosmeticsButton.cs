﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x02000057 RID: 87
[Token(Token = "0x2000057")]
public class DynamicCosmeticsButton : MonoBehaviour
{
	// Token: 0x06000BDA RID: 3034 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C4B98", Offset = "0x10C4B98", VA = "0x10C4B98")]
	[Token(Token = "0x6000BDA")]
	private void method_0()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BDB RID: 3035 RVA: 0x0001A35C File Offset: 0x0001855C
	[Token(Token = "0x6000BDB")]
	[Address(RVA = "0x10C4BD8", Offset = "0x10C4BD8", VA = "0x10C4BD8")]
	private void method_1()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BDC RID: 3036 RVA: 0x0001A37C File Offset: 0x0001857C
	[Token(Token = "0x6000BDC")]
	[Address(RVA = "0x10C4C18", Offset = "0x10C4C18", VA = "0x10C4C18")]
	private void method_2()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BDD RID: 3037 RVA: 0x0001A3AC File Offset: 0x000185AC
	[Address(RVA = "0x10C4DE8", Offset = "0x10C4DE8", VA = "0x10C4DE8")]
	[Token(Token = "0x6000BDD")]
	private void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_77(this);
	}

	// Token: 0x06000BDE RID: 3038 RVA: 0x0001A35C File Offset: 0x0001855C
	[Token(Token = "0x6000BDE")]
	[Address(RVA = "0x10C4EBC", Offset = "0x10C4EBC", VA = "0x10C4EBC")]
	private void method_4()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BDF RID: 3039 RVA: 0x0001A3AC File Offset: 0x000185AC
	[Address(RVA = "0x10C4EFC", Offset = "0x10C4EFC", VA = "0x10C4EFC")]
	[Token(Token = "0x6000BDF")]
	private void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_77(this);
	}

	// Token: 0x06000BE0 RID: 3040 RVA: 0x0001A3D8 File Offset: 0x000185D8
	[Address(RVA = "0x10C4FD0", Offset = "0x10C4FD0", VA = "0x10C4FD0")]
	[Token(Token = "0x6000BE0")]
	private void method_6()
	{
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x0001A400 File Offset: 0x00018600
	[Token(Token = "0x6000BE1")]
	[Address(RVA = "0x10C51A4", Offset = "0x10C51A4", VA = "0x10C51A4")]
	private void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_7(this);
	}

	// Token: 0x06000BE2 RID: 3042 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C5278", Offset = "0x10C5278", VA = "0x10C5278")]
	[Token(Token = "0x6000BE2")]
	private void method_8()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BE3 RID: 3043 RVA: 0x0001A428 File Offset: 0x00018628
	[Address(RVA = "0x10C52B8", Offset = "0x10C52B8", VA = "0x10C52B8")]
	[Token(Token = "0x6000BE3")]
	private void method_9(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_150(this);
	}

	// Token: 0x06000BE4 RID: 3044 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000BE4")]
	[Address(RVA = "0x10C538C", Offset = "0x10C538C", VA = "0x10C538C")]
	public DynamicCosmeticsButton()
	{
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x0001A454 File Offset: 0x00018654
	[Token(Token = "0x6000BE5")]
	[Address(RVA = "0x10C5394", Offset = "0x10C5394", VA = "0x10C5394")]
	private void method_10()
	{
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x0001A464 File Offset: 0x00018664
	[Token(Token = "0x6000BE6")]
	[Address(RVA = "0x10C5564", Offset = "0x10C5564", VA = "0x10C5564")]
	private void method_11(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_7(this);
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C5638", Offset = "0x10C5638", VA = "0x10C5638")]
	[Token(Token = "0x6000BE7")]
	private void method_12()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BE8 RID: 3048 RVA: 0x0001A490 File Offset: 0x00018690
	[Token(Token = "0x6000BE8")]
	[Address(RVA = "0x10C5678", Offset = "0x10C5678", VA = "0x10C5678")]
	private void method_13(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_95(this);
	}

	// Token: 0x06000BE9 RID: 3049 RVA: 0x0001A37C File Offset: 0x0001857C
	[Address(RVA = "0x10C574C", Offset = "0x10C574C", VA = "0x10C574C")]
	[Token(Token = "0x6000BE9")]
	private void method_14()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BEA RID: 3050 RVA: 0x0001A4BC File Offset: 0x000186BC
	[Address(RVA = "0x10C591C", Offset = "0x10C591C", VA = "0x10C591C")]
	[Token(Token = "0x6000BEA")]
	private void method_15()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BEB RID: 3051 RVA: 0x0001A4EC File Offset: 0x000186EC
	[Token(Token = "0x6000BEB")]
	[Address(RVA = "0x10C5AEC", Offset = "0x10C5AEC", VA = "0x10C5AEC")]
	private void method_16()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BEC RID: 3052 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C5CC0", Offset = "0x10C5CC0", VA = "0x10C5CC0")]
	[Token(Token = "0x6000BEC")]
	private void method_17()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BED RID: 3053 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C5D00", Offset = "0x10C5D00", VA = "0x10C5D00")]
	[Token(Token = "0x6000BED")]
	private void method_18()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BEE RID: 3054 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C5D40", Offset = "0x10C5D40", VA = "0x10C5D40")]
	[Token(Token = "0x6000BEE")]
	private void method_19()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BEF RID: 3055 RVA: 0x0001A51C File Offset: 0x0001871C
	[Token(Token = "0x6000BEF")]
	[Address(RVA = "0x10C5D80", Offset = "0x10C5D80", VA = "0x10C5D80")]
	private void method_20(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_99(this);
	}

	// Token: 0x06000BF0 RID: 3056 RVA: 0x0001A548 File Offset: 0x00018748
	[Address(RVA = "0x10C5E54", Offset = "0x10C5E54", VA = "0x10C5E54")]
	[Token(Token = "0x6000BF0")]
	private void method_21(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06000BF1 RID: 3057 RVA: 0x0001A568 File Offset: 0x00018768
	[Address(RVA = "0x10C5F28", Offset = "0x10C5F28", VA = "0x10C5F28")]
	[Token(Token = "0x6000BF1")]
	private void method_22(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_43(this);
	}

	// Token: 0x06000BF2 RID: 3058 RVA: 0x0001A490 File Offset: 0x00018690
	[Address(RVA = "0x10C5FFC", Offset = "0x10C5FFC", VA = "0x10C5FFC")]
	[Token(Token = "0x6000BF2")]
	private void method_23(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_95(this);
	}

	// Token: 0x06000BF3 RID: 3059 RVA: 0x0001A4EC File Offset: 0x000186EC
	[Address(RVA = "0x10C60D0", Offset = "0x10C60D0", VA = "0x10C60D0")]
	[Token(Token = "0x6000BF3")]
	private void method_24()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BF4 RID: 3060 RVA: 0x0001A37C File Offset: 0x0001857C
	[Address(RVA = "0x10C62A4", Offset = "0x10C62A4", VA = "0x10C62A4")]
	[Token(Token = "0x6000BF4")]
	private void method_25()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BF5 RID: 3061 RVA: 0x0001A594 File Offset: 0x00018794
	[Address(RVA = "0x10C6474", Offset = "0x10C6474", VA = "0x10C6474")]
	[Token(Token = "0x6000BF5")]
	private void method_26(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_13(this);
	}

	// Token: 0x06000BF6 RID: 3062 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C6548", Offset = "0x10C6548", VA = "0x10C6548")]
	[Token(Token = "0x6000BF6")]
	private void method_27()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BF7 RID: 3063 RVA: 0x0001A5C0 File Offset: 0x000187C0
	[Address(RVA = "0x10C6588", Offset = "0x10C6588", VA = "0x10C6588")]
	[Token(Token = "0x6000BF7")]
	private void method_28(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_116(this);
	}

	// Token: 0x06000BF8 RID: 3064 RVA: 0x0001A5EC File Offset: 0x000187EC
	[Address(RVA = "0x10C665C", Offset = "0x10C665C", VA = "0x10C665C")]
	[Token(Token = "0x6000BF8")]
	private void method_29(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_78(this);
	}

	// Token: 0x06000BF9 RID: 3065 RVA: 0x0001A618 File Offset: 0x00018818
	[Address(RVA = "0x10C6730", Offset = "0x10C6730", VA = "0x10C6730")]
	[Token(Token = "0x6000BF9")]
	private void method_30()
	{
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BFA RID: 3066 RVA: 0x0001A37C File Offset: 0x0001857C
	[Address(RVA = "0x10C6904", Offset = "0x10C6904", VA = "0x10C6904")]
	[Token(Token = "0x6000BFA")]
	private void method_31()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000BFB RID: 3067 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C6AD4", Offset = "0x10C6AD4", VA = "0x10C6AD4")]
	[Token(Token = "0x6000BFB")]
	private void method_32()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000BFC RID: 3068 RVA: 0x0001A640 File Offset: 0x00018840
	[Address(RVA = "0x10C6B14", Offset = "0x10C6B14", VA = "0x10C6B14")]
	[Token(Token = "0x6000BFC")]
	private void method_33(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_130(this);
	}

	// Token: 0x06000BFD RID: 3069 RVA: 0x0001A5EC File Offset: 0x000187EC
	[Address(RVA = "0x10C6BE8", Offset = "0x10C6BE8", VA = "0x10C6BE8")]
	[Token(Token = "0x6000BFD")]
	private void method_34(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_78(this);
	}

	// Token: 0x06000BFE RID: 3070 RVA: 0x0001A5EC File Offset: 0x000187EC
	[Address(RVA = "0x10C6CBC", Offset = "0x10C6CBC", VA = "0x10C6CBC")]
	[Token(Token = "0x6000BFE")]
	private void method_35(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_78(this);
	}

	// Token: 0x06000BFF RID: 3071 RVA: 0x0001A66C File Offset: 0x0001886C
	[Address(RVA = "0x10C6D90", Offset = "0x10C6D90", VA = "0x10C6D90")]
	[Token(Token = "0x6000BFF")]
	private void method_36(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_121(this);
	}

	// Token: 0x06000C00 RID: 3072 RVA: 0x0001A698 File Offset: 0x00018898
	[Address(RVA = "0x10C6E64", Offset = "0x10C6E64", VA = "0x10C6E64")]
	[Token(Token = "0x6000C00")]
	private void method_37()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C01 RID: 3073 RVA: 0x0001A66C File Offset: 0x0001886C
	[Address(RVA = "0x10C7038", Offset = "0x10C7038", VA = "0x10C7038")]
	[Token(Token = "0x6000C01")]
	private void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_121(this);
	}

	// Token: 0x06000C02 RID: 3074 RVA: 0x0001A6C8 File Offset: 0x000188C8
	[Address(RVA = "0x10C710C", Offset = "0x10C710C", VA = "0x10C710C")]
	[Token(Token = "0x6000C02")]
	private void method_38(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_22(this);
	}

	// Token: 0x06000C03 RID: 3075 RVA: 0x0001A37C File Offset: 0x0001857C
	[Address(RVA = "0x10C71E0", Offset = "0x10C71E0", VA = "0x10C71E0")]
	[Token(Token = "0x6000C03")]
	private void method_39()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C04 RID: 3076 RVA: 0x0001A6F4 File Offset: 0x000188F4
	[Address(RVA = "0x10C73B0", Offset = "0x10C73B0", VA = "0x10C73B0")]
	[Token(Token = "0x6000C04")]
	private void method_40(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_80(this);
	}

	// Token: 0x06000C05 RID: 3077 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7484", Offset = "0x10C7484", VA = "0x10C7484")]
	[Token(Token = "0x6000C05")]
	private void method_41()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C06 RID: 3078 RVA: 0x0001A568 File Offset: 0x00018768
	[Address(RVA = "0x10C74C4", Offset = "0x10C74C4", VA = "0x10C74C4")]
	[Token(Token = "0x6000C06")]
	private void method_42(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_43(this);
	}

	// Token: 0x06000C07 RID: 3079 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7598", Offset = "0x10C7598", VA = "0x10C7598")]
	[Token(Token = "0x6000C07")]
	private void method_43()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C08 RID: 3080 RVA: 0x0001A720 File Offset: 0x00018920
	[Address(RVA = "0x10C75D8", Offset = "0x10C75D8", VA = "0x10C75D8")]
	[Token(Token = "0x6000C08")]
	private void method_44(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_64(this);
	}

	// Token: 0x06000C09 RID: 3081 RVA: 0x0001A74C File Offset: 0x0001894C
	[Address(RVA = "0x10C76AC", Offset = "0x10C76AC", VA = "0x10C76AC")]
	[Token(Token = "0x6000C09")]
	private void Update()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C0A RID: 3082 RVA: 0x0001A77C File Offset: 0x0001897C
	[Address(RVA = "0x10C787C", Offset = "0x10C787C", VA = "0x10C787C")]
	[Token(Token = "0x6000C0A")]
	private void method_45(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_108(this);
	}

	// Token: 0x06000C0B RID: 3083 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7950", Offset = "0x10C7950", VA = "0x10C7950")]
	[Token(Token = "0x6000C0B")]
	private void method_46()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C0C RID: 3084 RVA: 0x0001A428 File Offset: 0x00018628
	[Address(RVA = "0x10C7990", Offset = "0x10C7990", VA = "0x10C7990")]
	[Token(Token = "0x6000C0C")]
	private void method_47(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_150(this);
	}

	// Token: 0x06000C0D RID: 3085 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7A64", Offset = "0x10C7A64", VA = "0x10C7A64")]
	[Token(Token = "0x6000C0D")]
	private void method_48()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C0E RID: 3086 RVA: 0x0001A7A8 File Offset: 0x000189A8
	[Address(RVA = "0x10C7AA4", Offset = "0x10C7AA4", VA = "0x10C7AA4")]
	[Token(Token = "0x6000C0E")]
	private void method_49(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
	}

	// Token: 0x06000C0F RID: 3087 RVA: 0x0001A640 File Offset: 0x00018840
	[Address(RVA = "0x10C7B78", Offset = "0x10C7B78", VA = "0x10C7B78")]
	[Token(Token = "0x6000C0F")]
	private void method_50(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_130(this);
	}

	// Token: 0x06000C10 RID: 3088 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7C4C", Offset = "0x10C7C4C", VA = "0x10C7C4C")]
	[Token(Token = "0x6000C10")]
	private void Start()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C11 RID: 3089 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7C8C", Offset = "0x10C7C8C", VA = "0x10C7C8C")]
	[Token(Token = "0x6000C11")]
	private void method_51()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C12 RID: 3090 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7CCC", Offset = "0x10C7CCC", VA = "0x10C7CCC")]
	[Token(Token = "0x6000C12")]
	private void method_52()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C13 RID: 3091 RVA: 0x0001A4EC File Offset: 0x000186EC
	[Address(RVA = "0x10C7D0C", Offset = "0x10C7D0C", VA = "0x10C7D0C")]
	[Token(Token = "0x6000C13")]
	private void method_53()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C14 RID: 3092 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C7EE0", Offset = "0x10C7EE0", VA = "0x10C7EE0")]
	[Token(Token = "0x6000C14")]
	private void method_54()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C15 RID: 3093 RVA: 0x0001A7C8 File Offset: 0x000189C8
	[Address(RVA = "0x10C7F20", Offset = "0x10C7F20", VA = "0x10C7F20")]
	[Token(Token = "0x6000C15")]
	private void method_55(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_67(this);
	}

	// Token: 0x06000C16 RID: 3094 RVA: 0x0001A37C File Offset: 0x0001857C
	[Address(RVA = "0x10C7FF4", Offset = "0x10C7FF4", VA = "0x10C7FF4")]
	[Token(Token = "0x6000C16")]
	private void method_56()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C17 RID: 3095 RVA: 0x0001A7F4 File Offset: 0x000189F4
	[Address(RVA = "0x10C81C4", Offset = "0x10C81C4", VA = "0x10C81C4")]
	[Token(Token = "0x6000C17")]
	private void method_57(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_57(this);
	}

	// Token: 0x06000C18 RID: 3096 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C8298", Offset = "0x10C8298", VA = "0x10C8298")]
	[Token(Token = "0x6000C18")]
	private void method_58()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C19 RID: 3097 RVA: 0x0001A6F4 File Offset: 0x000188F4
	[Address(RVA = "0x10C82D8", Offset = "0x10C82D8", VA = "0x10C82D8")]
	[Token(Token = "0x6000C19")]
	private void method_59(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_80(this);
	}

	// Token: 0x06000C1A RID: 3098 RVA: 0x0001A7C8 File Offset: 0x000189C8
	[Address(RVA = "0x10C83AC", Offset = "0x10C83AC", VA = "0x10C83AC")]
	[Token(Token = "0x6000C1A")]
	private void method_60(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<HandColliders>();
		this.dynamicCosmetics_0.method_67(this);
	}

	// Token: 0x06000C1B RID: 3099 RVA: 0x0001A74C File Offset: 0x0001894C
	[Address(RVA = "0x10C8480", Offset = "0x10C8480", VA = "0x10C8480")]
	[Token(Token = "0x6000C1B")]
	private void method_61()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C1C RID: 3100 RVA: 0x0001A37C File Offset: 0x0001857C
	[Address(RVA = "0x10C8650", Offset = "0x10C8650", VA = "0x10C8650")]
	[Token(Token = "0x6000C1C")]
	private void method_62()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C1D RID: 3101 RVA: 0x0001A74C File Offset: 0x0001894C
	[Address(RVA = "0x10C8820", Offset = "0x10C8820", VA = "0x10C8820")]
	[Token(Token = "0x6000C1D")]
	private void method_63()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C1E RID: 3102 RVA: 0x0001A35C File Offset: 0x0001855C
	[Address(RVA = "0x10C89F0", Offset = "0x10C89F0", VA = "0x10C89F0")]
	[Token(Token = "0x6000C1E")]
	private void method_64()
	{
		string name = base.gameObject.name;
		this.string_0 = name;
	}

	// Token: 0x06000C1F RID: 3103 RVA: 0x0001A37C File Offset: 0x0001857C
	[Token(Token = "0x6000C1F")]
	[Address(RVA = "0x10C8A30", Offset = "0x10C8A30", VA = "0x10C8A30")]
	private void method_65()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C20 RID: 3104 RVA: 0x0001A37C File Offset: 0x0001857C
	[Token(Token = "0x6000C20")]
	[Address(RVA = "0x10C8C00", Offset = "0x10C8C00", VA = "0x10C8C00")]
	private void method_66()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C21 RID: 3105 RVA: 0x0001A4EC File Offset: 0x000186EC
	[Address(RVA = "0x10C8DD0", Offset = "0x10C8DD0", VA = "0x10C8DD0")]
	[Token(Token = "0x6000C21")]
	private void method_67()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C22 RID: 3106 RVA: 0x0001A820 File Offset: 0x00018A20
	[Token(Token = "0x6000C22")]
	[Address(RVA = "0x10C8FA4", Offset = "0x10C8FA4", VA = "0x10C8FA4")]
	private void method_68()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		if (num != 0L)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x06000C23 RID: 3107 RVA: 0x0001A4EC File Offset: 0x000186EC
	[Token(Token = "0x6000C23")]
	[Address(RVA = "0x10C9174", Offset = "0x10C9174", VA = "0x10C9174")]
	private void method_69()
	{
		long num = 1L;
		if (num != 0L)
		{
		}
		DynamicParent dynamicParent = this.dynamicParent_0;
		if (dynamicParent != null)
		{
		}
		string name = this.dynamicParent_0.gameObject_1.name;
	}

	// Token: 0x040001BF RID: 447
	[Token(Token = "0x40001BF")]
	[FieldOffset(Offset = "0x18")]
	public TMP_Text tmp_Text_0;

	// Token: 0x040001C0 RID: 448
	[Token(Token = "0x40001C0")]
	[FieldOffset(Offset = "0x20")]
	[HideInInspector]
	public string string_0;

	// Token: 0x040001C1 RID: 449
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40001C1")]
	public DynamicParent dynamicParent_0;

	// Token: 0x040001C2 RID: 450
	[Token(Token = "0x40001C2")]
	[FieldOffset(Offset = "0x30")]
	[HideInInspector]
	public bool bool_0;

	// Token: 0x040001C3 RID: 451
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40001C3")]
	public DynamicCosmetics dynamicCosmetics_0;
}
