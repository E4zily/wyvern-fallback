﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x0200004A RID: 74
[Token(Token = "0x200004A")]
public class ChangeVoiceType : MonoBehaviour
{
	// Token: 0x06000A01 RID: 2561 RVA: 0x00017808 File Offset: 0x00015A08
	[Token(Token = "0x6000A01")]
	[Address(RVA = "0x2AEB194", Offset = "0x2AEB194", VA = "0x2AEB194")]
	public void method_0()
	{
		PlayerPrefs.GetString("Camera movement detected, calibrating height.") == "token";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("ErrorScreen") == "Left a room";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("A new Player joined a Room.");
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		this.gameObject_1.SetActive(active5 != 0L);
	}

	// Token: 0x06000A02 RID: 2562 RVA: 0x000178B8 File Offset: 0x00015AB8
	[Address(RVA = "0x2AEB3A4", Offset = "0x2AEB3A4", VA = "0x2AEB3A4")]
	[Token(Token = "0x6000A02")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("spatial", "Reason: ");
			return;
		}
	}

	// Token: 0x06000A03 RID: 2563 RVA: 0x000022D6 File Offset: 0x000004D6
	[Token(Token = "0x6000A03")]
	[Address(RVA = "0x2AEB608", Offset = "0x2AEB608", VA = "0x2AEB608")]
	public void method_2()
	{
		this.method_10();
	}

	// Token: 0x06000A04 RID: 2564 RVA: 0x000022DE File Offset: 0x000004DE
	[Token(Token = "0x6000A04")]
	[Address(RVA = "0x2AEB81C", Offset = "0x2AEB81C", VA = "0x2AEB81C")]
	public void method_3()
	{
		this.method_43();
	}

	// Token: 0x06000A05 RID: 2565 RVA: 0x000022E6 File Offset: 0x000004E6
	[Address(RVA = "0x2AEBA30", Offset = "0x2AEBA30", VA = "0x2AEBA30")]
	[Token(Token = "0x6000A05")]
	public void method_4()
	{
		this.method_12();
	}

	// Token: 0x06000A06 RID: 2566 RVA: 0x0001790C File Offset: 0x00015B0C
	[Address(RVA = "0x2AEBC30", Offset = "0x2AEBC30", VA = "0x2AEBC30")]
	[Token(Token = "0x6000A06")]
	public void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000A07 RID: 2567 RVA: 0x000022EE File Offset: 0x000004EE
	[Token(Token = "0x6000A07")]
	[Address(RVA = "0x2AEBE7C", Offset = "0x2AEBE7C", VA = "0x2AEBE7C")]
	public void Start()
	{
		this.method_38();
	}

	// Token: 0x06000A08 RID: 2568 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2AEC034", Offset = "0x2AEC034", VA = "0x2AEC034")]
	[Token(Token = "0x6000A08")]
	public ChangeVoiceType()
	{
	}

	// Token: 0x06000A09 RID: 2569 RVA: 0x00017928 File Offset: 0x00015B28
	[Token(Token = "0x6000A09")]
	[Address(RVA = "0x2AEC03C", Offset = "0x2AEC03C", VA = "0x2AEC03C")]
	public void method_6()
	{
		PlayerPrefs.GetString("{0} ({1})") == "Display Name Changed!";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("TurnAmount") == "username";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("Update User Inventory") == "/";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A0A RID: 2570 RVA: 0x000179E8 File Offset: 0x00015BE8
	[Token(Token = "0x6000A0A")]
	[Address(RVA = "0x2AEC24C", Offset = "0x2AEC24C", VA = "0x2AEC24C")]
	public void method_7()
	{
		PlayerPrefs.GetString("Reason: ") == "Open";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("Display Name Changed!") == "Player";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("KeyPos") == "Player";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A0B RID: 2571 RVA: 0x0001790C File Offset: 0x00015B0C
	[Address(RVA = "0x2AEC448", Offset = "0x2AEC448", VA = "0x2AEC448")]
	[Token(Token = "0x6000A0B")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000A0C RID: 2572 RVA: 0x000022F6 File Offset: 0x000004F6
	[Address(RVA = "0x2AEC6AC", Offset = "0x2AEC6AC", VA = "0x2AEC6AC")]
	[Token(Token = "0x6000A0C")]
	public void method_9()
	{
		this.method_42();
	}

	// Token: 0x06000A0D RID: 2573 RVA: 0x00017AA8 File Offset: 0x00015CA8
	[Token(Token = "0x6000A0D")]
	[Address(RVA = "0x2AEB60C", Offset = "0x2AEB60C", VA = "0x2AEB60C")]
	public void method_10()
	{
		PlayerPrefs.GetString("Add/Remove Sword") == "StartSong";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("[InputHelpers.IsPressed] The value of <button> is out or the supported range.") == "Cannot access index {0}. Buffer size is {1}";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("Failed To Join Public Room Successfully. The error is: ") == "BN";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A0E RID: 2574 RVA: 0x000022FE File Offset: 0x000004FE
	[Address(RVA = "0x2AEC8C0", Offset = "0x2AEC8C0", VA = "0x2AEC8C0")]
	[Token(Token = "0x6000A0E")]
	public void method_11()
	{
		this.method_6();
	}

	// Token: 0x06000A0F RID: 2575 RVA: 0x00017B68 File Offset: 0x00015D68
	[Token(Token = "0x6000A0F")]
	[Address(RVA = "0x2AEBA34", Offset = "0x2AEBA34", VA = "0x2AEBA34")]
	public void method_12()
	{
		PlayerPrefs.GetString("Player") == "\tExpires: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("trol") == "EnableCosmetic";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("_BumpScale") == "_Tint";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A10 RID: 2576 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000A10")]
	[Address(RVA = "0x2AEC8C4", Offset = "0x2AEC8C4", VA = "0x2AEC8C4")]
	public void method_13(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000A11 RID: 2577 RVA: 0x00002306 File Offset: 0x00000506
	[Address(RVA = "0x2AECAF8", Offset = "0x2AECAF8", VA = "0x2AECAF8")]
	[Token(Token = "0x6000A11")]
	public void method_14()
	{
		this.method_21();
	}

	// Token: 0x06000A12 RID: 2578 RVA: 0x00017C28 File Offset: 0x00015E28
	[Token(Token = "0x6000A12")]
	[Address(RVA = "0x2AECD0C", Offset = "0x2AECD0C", VA = "0x2AECD0C")]
	public void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Player", "Combine textures & build combined mesh using coroutine");
			return;
		}
	}

	// Token: 0x06000A13 RID: 2579 RVA: 0x00017C7C File Offset: 0x00015E7C
	[Token(Token = "0x6000A13")]
	[Address(RVA = "0x2AECF64", Offset = "0x2AECF64", VA = "0x2AECF64")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("FingerTip", "ChangeMaterialToNormal");
			return;
		}
	}

	// Token: 0x06000A14 RID: 2580 RVA: 0x00017CD0 File Offset: 0x00015ED0
	[Token(Token = "0x6000A14")]
	[Address(RVA = "0x2AED1B8", Offset = "0x2AED1B8", VA = "0x2AED1B8")]
	public void method_17(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Failed to login, please restart", "HandR");
			return;
		}
	}

	// Token: 0x06000A15 RID: 2581 RVA: 0x00017D24 File Offset: 0x00015F24
	[Token(Token = "0x6000A15")]
	[Address(RVA = "0x2AED410", Offset = "0x2AED410", VA = "0x2AED410")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			return;
		}
	}

	// Token: 0x06000A16 RID: 2582 RVA: 0x00017D68 File Offset: 0x00015F68
	[Address(RVA = "0x2AED644", Offset = "0x2AED644", VA = "0x2AED644")]
	[Token(Token = "0x6000A16")]
	public void method_19()
	{
		PlayerPrefs.GetString("TurnAmount") == "MetaAuth";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("_Tint") == "Bare Torso";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("Skelechin") == "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A17 RID: 2583 RVA: 0x00017E28 File Offset: 0x00016028
	[Address(RVA = "0x2AED848", Offset = "0x2AED848", VA = "0x2AED848")]
	[Token(Token = "0x6000A17")]
	public void method_20()
	{
		PlayerPrefs.GetString("ErrorScreen") == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("BN") == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("PlayWave") == "unlocked!";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 1L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A18 RID: 2584 RVA: 0x00017EE8 File Offset: 0x000160E8
	[Address(RVA = "0x2AECAFC", Offset = "0x2AECAFC", VA = "0x2AECAFC")]
	[Token(Token = "0x6000A18")]
	public void method_21()
	{
		PlayerPrefs.GetString("FingerTip") == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("True") == "Horizontal";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("_Smoothness") == "";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A19 RID: 2585 RVA: 0x0000230E File Offset: 0x0000050E
	[Address(RVA = "0x2AEDA58", Offset = "0x2AEDA58", VA = "0x2AEDA58")]
	[Token(Token = "0x6000A19")]
	public void method_22()
	{
		this.method_20();
	}

	// Token: 0x06000A1A RID: 2586 RVA: 0x000022DE File Offset: 0x000004DE
	[Address(RVA = "0x2AEDA5C", Offset = "0x2AEDA5C", VA = "0x2AEDA5C")]
	[Token(Token = "0x6000A1A")]
	public void method_23()
	{
		this.method_43();
	}

	// Token: 0x06000A1B RID: 2587 RVA: 0x00017FA8 File Offset: 0x000161A8
	[Address(RVA = "0x2AEDA60", Offset = "0x2AEDA60", VA = "0x2AEDA60")]
	[Token(Token = "0x6000A1B")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("\tExpires: ", "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			return;
		}
	}

	// Token: 0x06000A1C RID: 2588 RVA: 0x00017FFC File Offset: 0x000161FC
	[Address(RVA = "0x2AEDCC4", Offset = "0x2AEDCC4", VA = "0x2AEDCC4")]
	[Token(Token = "0x6000A1C")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("true", "PRESS AGAIN TO CONFIRM");
			return;
		}
	}

	// Token: 0x06000A1D RID: 2589 RVA: 0x00018050 File Offset: 0x00016250
	[Token(Token = "0x6000A1D")]
	[Address(RVA = "0x2AEDF28", Offset = "0x2AEDF28", VA = "0x2AEDF28")]
	public void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			long active2 = 0L;
			gameObject.SetActive(active2 != 0L);
			PlayerPrefs.SetString("_Tint", "Are you sure you would like to buy 5000 Bananas for $9.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			return;
		}
	}

	// Token: 0x06000A1E RID: 2590 RVA: 0x0001809C File Offset: 0x0001629C
	[Address(RVA = "0x2AEE17C", Offset = "0x2AEE17C", VA = "0x2AEE17C")]
	[Token(Token = "0x6000A1E")]
	public void method_27(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("FingerTip", "Player");
			return;
		}
	}

	// Token: 0x06000A1F RID: 2591 RVA: 0x000180F0 File Offset: 0x000162F0
	[Token(Token = "0x6000A1F")]
	[Address(RVA = "0x2AEE3E0", Offset = "0x2AEE3E0", VA = "0x2AEE3E0")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("got funky mone", "liftoff failed!");
			return;
		}
	}

	// Token: 0x06000A20 RID: 2592 RVA: 0x000022D6 File Offset: 0x000004D6
	[Token(Token = "0x6000A20")]
	[Address(RVA = "0x2AEE644", Offset = "0x2AEE644", VA = "0x2AEE644")]
	public void method_29()
	{
		this.method_10();
	}

	// Token: 0x06000A21 RID: 2593 RVA: 0x0001790C File Offset: 0x00015B0C
	[Token(Token = "0x6000A21")]
	[Address(RVA = "0x2AEE648", Offset = "0x2AEE648", VA = "0x2AEE648")]
	public void method_30(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000A22 RID: 2594 RVA: 0x00018144 File Offset: 0x00016344
	[Address(RVA = "0x2AEE8AC", Offset = "0x2AEE8AC", VA = "0x2AEE8AC")]
	[Token(Token = "0x6000A22")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("oculus", "button");
			return;
		}
	}

	// Token: 0x06000A23 RID: 2595 RVA: 0x00002306 File Offset: 0x00000506
	[Token(Token = "0x6000A23")]
	[Address(RVA = "0x2AEEB10", Offset = "0x2AEEB10", VA = "0x2AEEB10")]
	public void method_32()
	{
		this.method_21();
	}

	// Token: 0x06000A24 RID: 2596 RVA: 0x00018198 File Offset: 0x00016398
	[Address(RVA = "0x2AEEB14", Offset = "0x2AEEB14", VA = "0x2AEEB14")]
	[Token(Token = "0x6000A24")]
	public void method_33()
	{
		PlayerPrefs.GetString("_Smoothness") == "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("Player") == "Player";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("Name Changing Error. Error: ") == "";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A25 RID: 2597 RVA: 0x00018258 File Offset: 0x00016458
	[Address(RVA = "0x2AEED10", Offset = "0x2AEED10", VA = "0x2AEED10")]
	[Token(Token = "0x6000A25")]
	public void method_34(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Joined a Room.", "Player");
			return;
		}
	}

	// Token: 0x06000A26 RID: 2598 RVA: 0x00002316 File Offset: 0x00000516
	[Address(RVA = "0x2AEEF74", Offset = "0x2AEEF74", VA = "0x2AEEF74")]
	[Token(Token = "0x6000A26")]
	public void method_35()
	{
		this.method_41();
	}

	// Token: 0x06000A27 RID: 2599 RVA: 0x000182AC File Offset: 0x000164AC
	[Address(RVA = "0x2AEF174", Offset = "0x2AEF174", VA = "0x2AEF174")]
	[Token(Token = "0x6000A27")]
	public void method_36()
	{
		PlayerPrefs.GetString("Player") == "HeadAttachPoint";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("HorrorAgreement") == "PlayerHead";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("Start Gamemode") == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A28 RID: 2600 RVA: 0x00002306 File Offset: 0x00000506
	[Token(Token = "0x6000A28")]
	[Address(RVA = "0x2AEF384", Offset = "0x2AEF384", VA = "0x2AEF384")]
	public void method_37()
	{
		this.method_21();
	}

	// Token: 0x06000A29 RID: 2601 RVA: 0x0001836C File Offset: 0x0001656C
	[Token(Token = "0x6000A29")]
	[Address(RVA = "0x2AEF388", Offset = "0x2AEF388", VA = "0x2AEF388")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("typesOfTalk", "True");
			return;
		}
	}

	// Token: 0x06000A2A RID: 2602 RVA: 0x000183C0 File Offset: 0x000165C0
	[Token(Token = "0x6000A2A")]
	[Address(RVA = "0x2AEBE80", Offset = "0x2AEBE80", VA = "0x2AEBE80")]
	public void method_38()
	{
		PlayerPrefs.GetString("typesOfTalk") == "True";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("typesOfTalk") == "True";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		long active4 = 0L;
		gameObject3.SetActive(active4 != 0L);
		PlayerPrefs.GetString("typesOfTalk");
		GameObject gameObject4 = this.gameObject_0;
		long active5 = 0L;
		gameObject4.SetActive(active5 != 0L);
		GameObject gameObject5 = this.gameObject_1;
		long active6 = 1L;
		gameObject5.SetActive(active6 != 0L);
	}

	// Token: 0x06000A2B RID: 2603 RVA: 0x00018470 File Offset: 0x00016670
	[Address(RVA = "0x2AEF5D4", Offset = "0x2AEF5D4", VA = "0x2AEF5D4")]
	[Token(Token = "0x6000A2B")]
	public void method_39(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("A new Player joined a Room.", "Purchase For ");
			return;
		}
	}

	// Token: 0x06000A2C RID: 2604 RVA: 0x00002306 File Offset: 0x00000506
	[Address(RVA = "0x2AEF82C", Offset = "0x2AEF82C", VA = "0x2AEF82C")]
	[Token(Token = "0x6000A2C")]
	public void method_40()
	{
		this.method_21();
	}

	// Token: 0x06000A2D RID: 2605 RVA: 0x000184C4 File Offset: 0x000166C4
	[Address(RVA = "0x2AEEF78", Offset = "0x2AEEF78", VA = "0x2AEEF78")]
	[Token(Token = "0x6000A2D")]
	public void method_41()
	{
	}

	// Token: 0x06000A2E RID: 2606 RVA: 0x000184D4 File Offset: 0x000166D4
	[Token(Token = "0x6000A2E")]
	[Address(RVA = "0x2AEC6B0", Offset = "0x2AEC6B0", VA = "0x2AEC6B0")]
	public void method_42()
	{
		PlayerPrefs.GetString("Grip") == "Not enough amount of currency";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		PlayerPrefs.GetString("procedural animation script required on ") == "This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("Thumb") == "";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A2F RID: 2607 RVA: 0x00018594 File Offset: 0x00016794
	[Address(RVA = "0x2AEB820", Offset = "0x2AEB820", VA = "0x2AEB820")]
	[Token(Token = "0x6000A2F")]
	public void method_43()
	{
		PlayerPrefs.GetString("TurnAmount") == "On";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		string a;
		a == "Version";
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_1;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		PlayerPrefs.GetString("ENABLE") == "User has been reported for: ";
		GameObject gameObject5 = this.gameObject_0;
		long active5 = 1L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_1;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
	}

	// Token: 0x06000A30 RID: 2608 RVA: 0x0001864C File Offset: 0x0001684C
	[Address(RVA = "0x2AEF830", Offset = "0x2AEF830", VA = "0x2AEF830")]
	[Token(Token = "0x6000A30")]
	public void method_44(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Charged!", "username");
			return;
		}
	}

	// Token: 0x06000A31 RID: 2609 RVA: 0x0000231E File Offset: 0x0000051E
	[Address(RVA = "0x2AEFA94", Offset = "0x2AEFA94", VA = "0x2AEFA94")]
	[Token(Token = "0x6000A31")]
	public void method_45()
	{
		this.method_33();
	}

	// Token: 0x06000A32 RID: 2610 RVA: 0x000186A0 File Offset: 0x000168A0
	[Address(RVA = "0x2AEFA98", Offset = "0x2AEFA98", VA = "0x2AEFA98")]
	[Token(Token = "0x6000A32")]
	public void method_46(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.genum2_0 == ChangeVoiceType.GEnum2.const_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			PlayerPrefs.SetString("Song Index: ", "A new Player joined a Room.");
			return;
		}
	}

	// Token: 0x06000A33 RID: 2611 RVA: 0x0001790C File Offset: 0x00015B0C
	[Token(Token = "0x6000A33")]
	[Address(RVA = "0x2AEFCFC", Offset = "0x2AEFCFC", VA = "0x2AEFCFC")]
	public void method_47(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000A34 RID: 2612 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000A34")]
	[Address(RVA = "0x2AEFF54", Offset = "0x2AEFF54", VA = "0x2AEFF54")]
	public void method_48(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x04000182 RID: 386
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000182")]
	public ChangeVoiceType.GEnum2 genum2_0;

	// Token: 0x04000183 RID: 387
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000183")]
	public GameObject gameObject_0;

	// Token: 0x04000184 RID: 388
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000184")]
	public GameObject gameObject_1;

	// Token: 0x04000185 RID: 389
	[Token(Token = "0x4000185")]
	[FieldOffset(Offset = "0x30")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x0200004B RID: 75
	[Token(Token = "0x200004B")]
	public enum GEnum2
	{
		// Token: 0x04000187 RID: 391
		[Token(Token = "0x4000187")]
		const_0,
		// Token: 0x04000188 RID: 392
		[Token(Token = "0x4000188")]
		const_1,
		// Token: 0x04000189 RID: 393
		[Token(Token = "0x4000189")]
		const_2
	}
}
