﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x020000A8 RID: 168
[Token(Token = "0x20000A8")]
public class BetterButton : MonoBehaviour
{
	// Token: 0x06001827 RID: 6183 RVA: 0x0003171C File Offset: 0x0002F91C
	[Address(RVA = "0x3669D30", Offset = "0x3669D30", VA = "0x3669D30")]
	[Token(Token = "0x6001827")]
	private void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_1.Invoke();
	}

	// Token: 0x06001828 RID: 6184 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3669DF4", Offset = "0x3669DF4", VA = "0x3669DF4")]
	[Token(Token = "0x6001828")]
	public BetterButton()
	{
	}

	// Token: 0x06001829 RID: 6185 RVA: 0x0003171C File Offset: 0x0002F91C
	[Address(RVA = "0x3669DFC", Offset = "0x3669DFC", VA = "0x3669DFC")]
	[Token(Token = "0x6001829")]
	private void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_1.Invoke();
	}

	// Token: 0x0600182A RID: 6186 RVA: 0x0003171C File Offset: 0x0002F91C
	[Address(RVA = "0x3669EC0", Offset = "0x3669EC0", VA = "0x3669EC0")]
	[Token(Token = "0x600182A")]
	private void method_2(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_1.Invoke();
	}

	// Token: 0x0600182B RID: 6187 RVA: 0x00031740 File Offset: 0x0002F940
	[Address(RVA = "0x3669F84", Offset = "0x3669F84", VA = "0x3669F84")]
	[Token(Token = "0x600182B")]
	private void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_0.Invoke();
	}

	// Token: 0x0600182C RID: 6188 RVA: 0x0003171C File Offset: 0x0002F91C
	[Address(RVA = "0x366A048", Offset = "0x366A048", VA = "0x366A048")]
	[Token(Token = "0x600182C")]
	private void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_1.Invoke();
	}

	// Token: 0x0600182D RID: 6189 RVA: 0x00031740 File Offset: 0x0002F940
	[Address(RVA = "0x366A10C", Offset = "0x366A10C", VA = "0x366A10C")]
	[Token(Token = "0x600182D")]
	private void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_0.Invoke();
	}

	// Token: 0x0600182E RID: 6190 RVA: 0x0003171C File Offset: 0x0002F91C
	[Address(RVA = "0x366A1D0", Offset = "0x366A1D0", VA = "0x366A1D0")]
	[Token(Token = "0x600182E")]
	private void method_6(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_1.Invoke();
	}

	// Token: 0x0600182F RID: 6191 RVA: 0x0001C40C File Offset: 0x0001A60C
	[Address(RVA = "0x366A294", Offset = "0x366A294", VA = "0x366A294")]
	[Token(Token = "0x600182F")]
	private void OnTriggerExit(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06001830 RID: 6192 RVA: 0x00031740 File Offset: 0x0002F940
	[Address(RVA = "0x366A358", Offset = "0x366A358", VA = "0x366A358")]
	[Token(Token = "0x6001830")]
	private void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_0.Invoke();
	}

	// Token: 0x06001831 RID: 6193 RVA: 0x00031740 File Offset: 0x0002F940
	[Address(RVA = "0x366A41C", Offset = "0x366A41C", VA = "0x366A41C")]
	[Token(Token = "0x6001831")]
	private void method_7(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_0.Invoke();
	}

	// Token: 0x06001832 RID: 6194 RVA: 0x00031740 File Offset: 0x0002F940
	[Address(RVA = "0x366A4E0", Offset = "0x366A4E0", VA = "0x366A4E0")]
	[Token(Token = "0x6001832")]
	private void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_0.Invoke();
	}

	// Token: 0x06001833 RID: 6195 RVA: 0x0003171C File Offset: 0x0002F91C
	[Address(RVA = "0x366A5A4", Offset = "0x366A5A4", VA = "0x366A5A4")]
	[Token(Token = "0x6001833")]
	private void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_1.Invoke();
	}

	// Token: 0x06001834 RID: 6196 RVA: 0x0001C40C File Offset: 0x0001A60C
	[Address(RVA = "0x366A668", Offset = "0x366A668", VA = "0x366A668")]
	[Token(Token = "0x6001834")]
	private void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06001835 RID: 6197 RVA: 0x00031740 File Offset: 0x0002F940
	[Address(RVA = "0x366A72C", Offset = "0x366A72C", VA = "0x366A72C")]
	[Token(Token = "0x6001835")]
	private void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_0.Invoke();
	}

	// Token: 0x06001836 RID: 6198 RVA: 0x0003171C File Offset: 0x0002F91C
	[Address(RVA = "0x366A7F0", Offset = "0x366A7F0", VA = "0x366A7F0")]
	[Token(Token = "0x6001836")]
	private void method_12(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.unityEvent_1.Invoke();
	}

	// Token: 0x06001837 RID: 6199 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x366A8B4", Offset = "0x366A8B4", VA = "0x366A8B4")]
	[Token(Token = "0x6001837")]
	private void method_13(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x04000322 RID: 802
	[Token(Token = "0x4000322")]
	[FieldOffset(Offset = "0x18")]
	public UnityEvent unityEvent_0;

	// Token: 0x04000323 RID: 803
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000323")]
	public UnityEvent unityEvent_1;
}
