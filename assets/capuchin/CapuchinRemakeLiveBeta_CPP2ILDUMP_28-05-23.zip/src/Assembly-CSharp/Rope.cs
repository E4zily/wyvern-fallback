﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000042 RID: 66
[Token(Token = "0x2000042")]
public class Rope : MonoBehaviour
{
	// Token: 0x06000892 RID: 2194 RVA: 0x00012C8C File Offset: 0x00010E8C
	[Address(RVA = "0x2E14674", Offset = "0x2E14674", VA = "0x2E14674")]
	[Token(Token = "0x6000892")]
	private void method_0()
	{
		float z = this.float_12;
		float deltaTime = Time.deltaTime;
		Transform transform = this.transform_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_0.position;
		Vector3 position3 = this.transform_1.position;
		float z2 = this.float_1;
		Transform transform2 = this.transform_0;
		Vector3 position4 = transform2.position;
		Vector3 position5 = this.transform_0.position;
		Transform transform3 = this.transform_0;
		float num = this.float_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		Vector3 position8 = this.transform_1.position;
		Transform transform4 = this.transform_1;
		Vector3 position9 = transform4.position;
		float value;
		Mathf.Clamp01(value);
		Transform transform5 = this.transform_1;
		Vector3 position10 = transform5.position;
		this.float_11 = num;
		this.vector3_5.z = z2;
		float deltaTime2 = Time.deltaTime;
		float num2 = this.float_7;
		float num3 = this.float_8;
		float x = this.vector3_3.x;
		this.float_6 = num2;
		this.float_4 = num3;
		Transform transform6 = this.transform_0;
		this.vector3_1.z = z;
		this.vector3_3.x = x;
		Vector3 position11 = transform6.position;
		Vector3 position12 = this.transform_1.position;
		this.float_12 = (float)16384;
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x000022AC File Offset: 0x000004AC
	[Address(RVA = "0x2E14EEC", Offset = "0x2E14EEC", VA = "0x2E14EEC")]
	[Token(Token = "0x6000893")]
	public Rope()
	{
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x00012DD4 File Offset: 0x00010FD4
	[Address(RVA = "0x2E14EFC", Offset = "0x2E14EFC", VA = "0x2E14EFC")]
	[Token(Token = "0x6000894")]
	private void method_1()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x00012E20 File Offset: 0x00011020
	[Address(RVA = "0x2E15060", Offset = "0x2E15060", VA = "0x2E15060")]
	[Token(Token = "0x6000895")]
	private void method_2()
	{
		float z = this.float_12;
		float deltaTime = Time.deltaTime;
		Transform transform = this.transform_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_0.position;
		Vector3 position3 = this.transform_1.position;
		Transform transform2 = this.transform_0;
		Vector3 position4 = transform2.position;
		Vector3 position5 = this.transform_0.position;
		Transform transform3 = this.transform_0;
		float num = this.float_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		Vector3 position8 = this.transform_1.position;
		Transform transform4 = this.transform_1;
		Vector3 position9 = transform4.position;
		float value;
		Mathf.Clamp01(value);
		Transform transform5 = this.transform_1;
		Vector3 position10 = transform5.position;
		this.float_11 = num;
		float deltaTime2 = Time.deltaTime;
		float num2 = this.float_7;
		float num3 = this.float_8;
		float x = this.vector3_3.x;
		this.float_6 = num2;
		this.float_4 = num3;
		Transform transform6 = this.transform_0;
		this.vector3_1.z = z;
		this.vector3_3.x = x;
		Vector3 position11 = transform6.position;
		Vector3 position12 = this.transform_1.position;
		this.float_12 = (float)32768;
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000896")]
	[Address(RVA = "0x2E1547C", Offset = "0x2E1547C", VA = "0x2E1547C")]
	private Vector3 method_3(List<Vector3> list_1, float float_13)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x00012F54 File Offset: 0x00011154
	[Address(RVA = "0x2E15760", Offset = "0x2E15760", VA = "0x2E15760")]
	[Token(Token = "0x6000897")]
	private void Update()
	{
		float deltaTime = Time.deltaTime;
		Transform transform = this.transform_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_0.position;
		Vector3 position3 = this.transform_1.position;
		float z = this.float_1;
		float y = this.float_2;
		Transform transform2 = this.transform_0;
		Vector3 position4 = transform2.position;
		Vector3 position5 = this.transform_0.position;
		Transform transform3 = this.transform_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		Vector3 position8 = this.transform_1.position;
		Transform transform4 = this.transform_1;
		Vector3 position9 = transform4.position;
		float value;
		Mathf.Clamp01(value);
		Transform transform5 = this.transform_1;
		Vector3 position10 = transform5.position;
		this.vector3_5.y = y;
		this.vector3_5.z = z;
		float deltaTime2 = Time.deltaTime;
		float num = this.float_7;
		float num2 = this.float_8;
		this.float_6 = num;
		this.float_4 = num2;
		Vector3 position11 = this.transform_0.position;
		Vector3 position12 = this.transform_1.position;
	}

	// Token: 0x06000898 RID: 2200 RVA: 0x00013064 File Offset: 0x00011264
	[Token(Token = "0x6000898")]
	[Address(RVA = "0x2E15F60", Offset = "0x2E15F60", VA = "0x2E15F60")]
	private void method_4()
	{
		float z = this.float_12;
		float deltaTime = Time.deltaTime;
		Transform transform = this.transform_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_0.position;
		Vector3 position3 = this.transform_1.position;
		Transform transform2 = this.transform_0;
		Vector3 position4 = transform2.position;
		Vector3 position5 = this.transform_0.position;
		Transform transform3 = this.transform_0;
		float num = this.float_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		Vector3 position8 = this.transform_1.position;
		Transform transform4 = this.transform_1;
		Vector3 position9 = transform4.position;
		float value;
		Mathf.Clamp01(value);
		Transform transform5 = this.transform_1;
		Vector3 position10 = transform5.position;
		this.float_11 = num;
		float deltaTime2 = Time.deltaTime;
		float num2 = this.float_7;
		float num3 = this.float_8;
		float x = this.vector3_3.x;
		this.float_6 = num2;
		this.float_4 = num3;
		Transform transform6 = this.transform_0;
		this.vector3_1.z = z;
		this.vector3_3.x = x;
		Vector3 position11 = transform6.position;
		Vector3 position12 = this.transform_1.position;
		this.float_12 = (float)16384;
	}

	// Token: 0x06000899 RID: 2201 RVA: 0x00012E20 File Offset: 0x00011020
	[Token(Token = "0x6000899")]
	[Address(RVA = "0x2E1637C", Offset = "0x2E1637C", VA = "0x2E1637C")]
	private void method_5()
	{
		float z = this.float_12;
		float deltaTime = Time.deltaTime;
		Transform transform = this.transform_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_0.position;
		Vector3 position3 = this.transform_1.position;
		Transform transform2 = this.transform_0;
		Vector3 position4 = transform2.position;
		Vector3 position5 = this.transform_0.position;
		Transform transform3 = this.transform_0;
		float num = this.float_0;
		Vector3 position6 = transform3.position;
		Vector3 position7 = this.transform_1.position;
		Vector3 position8 = this.transform_1.position;
		Transform transform4 = this.transform_1;
		Vector3 position9 = transform4.position;
		float value;
		Mathf.Clamp01(value);
		Transform transform5 = this.transform_1;
		Vector3 position10 = transform5.position;
		this.float_11 = num;
		float deltaTime2 = Time.deltaTime;
		float num2 = this.float_7;
		float num3 = this.float_8;
		float x = this.vector3_3.x;
		this.float_6 = num2;
		this.float_4 = num3;
		Transform transform6 = this.transform_0;
		this.vector3_1.z = z;
		this.vector3_3.x = x;
		Vector3 position11 = transform6.position;
		Vector3 position12 = this.transform_1.position;
		this.float_12 = (float)32768;
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x00012DD4 File Offset: 0x00010FD4
	[Address(RVA = "0x2E168FC", Offset = "0x2E168FC", VA = "0x2E168FC")]
	[Token(Token = "0x600089A")]
	private void method_6()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x0600089B RID: 2203 RVA: 0x00012DD4 File Offset: 0x00010FD4
	[Address(RVA = "0x2E16A60", Offset = "0x2E16A60", VA = "0x2E16A60")]
	[Token(Token = "0x600089B")]
	private void method_7()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x0600089C RID: 2204 RVA: 0x00013198 File Offset: 0x00011398
	[Address(RVA = "0x2E16BC4", Offset = "0x2E16BC4", VA = "0x2E16BC4")]
	[Token(Token = "0x600089C")]
	private void method_8(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			int positionCount2 = this.lineRenderer_0.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x000131E0 File Offset: 0x000113E0
	[Address(RVA = "0x2E16D28", Offset = "0x2E16D28", VA = "0x2E16D28")]
	[Token(Token = "0x600089D")]
	private void method_9()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600089E")]
	[Address(RVA = "0x2E14A90", Offset = "0x2E14A90", VA = "0x2E14A90")]
	private Vector3 method_10(List<Vector3> list_1, float float_13)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x00012DD4 File Offset: 0x00010FD4
	[Token(Token = "0x600089F")]
	[Address(RVA = "0x2E16E8C", Offset = "0x2E16E8C", VA = "0x2E16E8C")]
	private void method_11()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x0001322C File Offset: 0x0001142C
	[Token(Token = "0x60008A0")]
	[Address(RVA = "0x2E15E2C", Offset = "0x2E15E2C", VA = "0x2E15E2C")]
	private void method_12(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			LineRenderer lineRenderer2 = this.lineRenderer_0;
			int positionCount2 = lineRenderer2.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x00012DD4 File Offset: 0x00010FD4
	[Token(Token = "0x60008A1")]
	[Address(RVA = "0x2E16FF0", Offset = "0x2E16FF0", VA = "0x2E16FF0")]
	private void method_13()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x00013198 File Offset: 0x00011398
	[Token(Token = "0x60008A2")]
	[Address(RVA = "0x2E16798", Offset = "0x2E16798", VA = "0x2E16798")]
	private void method_14(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			int positionCount2 = this.lineRenderer_0.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x00013198 File Offset: 0x00011398
	[Address(RVA = "0x2E17154", Offset = "0x2E17154", VA = "0x2E17154")]
	[Token(Token = "0x60008A3")]
	private void method_15(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			int positionCount2 = this.lineRenderer_0.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x0001322C File Offset: 0x0001142C
	[Token(Token = "0x60008A4")]
	[Address(RVA = "0x2E172B8", Offset = "0x2E172B8", VA = "0x2E172B8")]
	private void method_16(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			LineRenderer lineRenderer2 = this.lineRenderer_0;
			int positionCount2 = lineRenderer2.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008A5")]
	[Address(RVA = "0x2E17424", Offset = "0x2E17424", VA = "0x2E17424")]
	private Vector3 method_17(List<Vector3> list_1, float float_13)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008A6 RID: 2214 RVA: 0x00012DD4 File Offset: 0x00010FD4
	[Token(Token = "0x60008A6")]
	[Address(RVA = "0x2E17674", Offset = "0x2E17674", VA = "0x2E17674")]
	private void method_18()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Vector3 position3 = this.transform_0.position;
		Vector3 position4 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x060008A7 RID: 2215 RVA: 0x00013278 File Offset: 0x00011478
	[Token(Token = "0x60008A7")]
	[Address(RVA = "0x2E177D8", Offset = "0x2E177D8", VA = "0x2E177D8")]
	private void OnDrawGizmos()
	{
		Color red = Color.red;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Vector3 position3 = this.transform_1.position;
		Color yellow = Color.yellow;
	}

	// Token: 0x060008A8 RID: 2216 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x60008A8")]
	[Address(RVA = "0x2E15B44", Offset = "0x2E15B44", VA = "0x2E15B44")]
	private Vector3 method_19(List<Vector3> list_1, float float_13)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x0001322C File Offset: 0x0001142C
	[Token(Token = "0x60008A9")]
	[Address(RVA = "0x2E17938", Offset = "0x2E17938", VA = "0x2E17938")]
	private void method_20(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			LineRenderer lineRenderer2 = this.lineRenderer_0;
			int positionCount2 = lineRenderer2.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x000132B8 File Offset: 0x000114B8
	[Address(RVA = "0x2E14D80", Offset = "0x2E14D80", VA = "0x2E14D80")]
	[Token(Token = "0x60008AA")]
	private void method_21(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			int positionCount2 = lineRenderer.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x0001322C File Offset: 0x0001142C
	[Address(RVA = "0x2E17AA4", Offset = "0x2E17AA4", VA = "0x2E17AA4")]
	[Token(Token = "0x60008AB")]
	private void method_22(Vector3 vector3_7, Vector3 vector3_8, Vector3 vector3_9)
	{
		do
		{
			LineRenderer lineRenderer = this.lineRenderer_0;
			int positionCount = this.int_0;
			lineRenderer.positionCount = positionCount;
			LineRenderer lineRenderer2 = this.lineRenderer_0;
			int positionCount2 = lineRenderer2.positionCount;
			int positionCount3 = this.lineRenderer_0.positionCount;
		}
		while (this.lineRenderer_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x04000125 RID: 293
	[Token(Token = "0x4000125")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x04000126 RID: 294
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000126")]
	public Transform transform_1;

	// Token: 0x04000127 RID: 295
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000127")]
	public LineRenderer lineRenderer_0;

	// Token: 0x04000128 RID: 296
	[Token(Token = "0x4000128")]
	[FieldOffset(Offset = "0x30")]
	public List<Vector3> list_0;

	// Token: 0x04000129 RID: 297
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000129")]
	public float float_0;

	// Token: 0x0400012A RID: 298
	[Token(Token = "0x400012A")]
	[FieldOffset(Offset = "0x3C")]
	public float float_1;

	// Token: 0x0400012B RID: 299
	[Token(Token = "0x400012B")]
	[FieldOffset(Offset = "0x40")]
	public float float_2;

	// Token: 0x0400012C RID: 300
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x400012C")]
	private Vector3 vector3_0;

	// Token: 0x0400012D RID: 301
	[Token(Token = "0x400012D")]
	[FieldOffset(Offset = "0x50")]
	private Vector3 vector3_1;

	// Token: 0x0400012E RID: 302
	[Token(Token = "0x400012E")]
	[FieldOffset(Offset = "0x5C")]
	private Vector3 vector3_2;

	// Token: 0x0400012F RID: 303
	[Token(Token = "0x400012F")]
	[FieldOffset(Offset = "0x68")]
	private Vector3 vector3_3;

	// Token: 0x04000130 RID: 304
	[Token(Token = "0x4000130")]
	[FieldOffset(Offset = "0x74")]
	private Vector3 vector3_4;

	// Token: 0x04000131 RID: 305
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000131")]
	private float float_3;

	// Token: 0x04000132 RID: 306
	[Token(Token = "0x4000132")]
	[FieldOffset(Offset = "0x84")]
	private float float_4;

	// Token: 0x04000133 RID: 307
	[Token(Token = "0x4000133")]
	[FieldOffset(Offset = "0x88")]
	private float float_5;

	// Token: 0x04000134 RID: 308
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x4000134")]
	private float float_6;

	// Token: 0x04000135 RID: 309
	[Token(Token = "0x4000135")]
	[FieldOffset(Offset = "0x90")]
	public float float_7;

	// Token: 0x04000136 RID: 310
	[Token(Token = "0x4000136")]
	[FieldOffset(Offset = "0x94")]
	public float float_8;

	// Token: 0x04000137 RID: 311
	[Token(Token = "0x4000137")]
	[FieldOffset(Offset = "0x98")]
	public float float_9;

	// Token: 0x04000138 RID: 312
	[FieldOffset(Offset = "0x9C")]
	[Token(Token = "0x4000138")]
	public int int_0 = 200;

	// Token: 0x04000139 RID: 313
	[Token(Token = "0x4000139")]
	[FieldOffset(Offset = "0xA0")]
	public bool bool_0;

	// Token: 0x0400013A RID: 314
	[Token(Token = "0x400013A")]
	[FieldOffset(Offset = "0xA4")]
	public float float_10;

	// Token: 0x0400013B RID: 315
	[Token(Token = "0x400013B")]
	[FieldOffset(Offset = "0xA8")]
	public float float_11;

	// Token: 0x0400013C RID: 316
	[Token(Token = "0x400013C")]
	[FieldOffset(Offset = "0xAC")]
	private float float_12;

	// Token: 0x0400013D RID: 317
	[FieldOffset(Offset = "0xB0")]
	[Token(Token = "0x400013D")]
	private Vector3 vector3_5;

	// Token: 0x0400013E RID: 318
	[FieldOffset(Offset = "0xBC")]
	[Token(Token = "0x400013E")]
	private Vector3 vector3_6;
}
