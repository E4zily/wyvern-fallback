﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200001E RID: 30
[Token(Token = "0x200001E")]
public class TextureSwap : MonoBehaviour
{
	// Token: 0x060003CD RID: 973 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CE0E4", Offset = "0x25CE0E4", VA = "0x25CE0E4")]
	[Token(Token = "0x60003CD")]
	public IEnumerator method_0()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003CE RID: 974 RVA: 0x0000C1F0 File Offset: 0x0000A3F0
	[Address(RVA = "0x25CE15C", Offset = "0x25CE15C", VA = "0x25CE15C")]
	[Token(Token = "0x60003CE")]
	public void method_1()
	{
		IEnumerator routine = this.method_4();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003CF RID: 975 RVA: 0x0000C20C File Offset: 0x0000A40C
	[Address(RVA = "0x25CE200", Offset = "0x25CE200", VA = "0x25CE200")]
	[Token(Token = "0x60003CF")]
	public void method_2()
	{
		IEnumerator routine = this.method_53();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x0000C228 File Offset: 0x0000A428
	[Token(Token = "0x60003D0")]
	[Address(RVA = "0x25CE2A4", Offset = "0x25CE2A4", VA = "0x25CE2A4")]
	public void method_3()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003D1 RID: 977 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003D1")]
	[Address(RVA = "0x25CE188", Offset = "0x25CE188", VA = "0x25CE188")]
	public IEnumerator method_4()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D2 RID: 978 RVA: 0x0000C244 File Offset: 0x0000A444
	[Token(Token = "0x60003D2")]
	[Address(RVA = "0x25CE348", Offset = "0x25CE348", VA = "0x25CE348")]
	public IEnumerator method_5()
	{
		new TextureSwap.Class6((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060003D3 RID: 979 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CE3C0", Offset = "0x25CE3C0", VA = "0x25CE3C0")]
	[Token(Token = "0x60003D3")]
	public IEnumerator method_6()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D4 RID: 980 RVA: 0x0000C268 File Offset: 0x0000A468
	[Token(Token = "0x60003D4")]
	[Address(RVA = "0x25CE438", Offset = "0x25CE438", VA = "0x25CE438")]
	public void method_7()
	{
		IEnumerator routine = this.method_60();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003D5 RID: 981 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003D5")]
	[Address(RVA = "0x25CE4DC", Offset = "0x25CE4DC", VA = "0x25CE4DC")]
	public IEnumerator method_8()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003D6 RID: 982 RVA: 0x0000C284 File Offset: 0x0000A484
	[Token(Token = "0x60003D6")]
	[Address(RVA = "0x25CE554", Offset = "0x25CE554", VA = "0x25CE554")]
	public void method_9()
	{
		IEnumerator routine = this.method_6();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003D7 RID: 983 RVA: 0x0000C2A0 File Offset: 0x0000A4A0
	[Address(RVA = "0x25CE580", Offset = "0x25CE580", VA = "0x25CE580")]
	[Token(Token = "0x60003D7")]
	public void method_10()
	{
		IEnumerator routine = this.method_15();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x0000C2BC File Offset: 0x0000A4BC
	[Address(RVA = "0x25CE624", Offset = "0x25CE624", VA = "0x25CE624")]
	[Token(Token = "0x60003D8")]
	public void method_11()
	{
		IEnumerator routine = this.method_45();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CE6C8", Offset = "0x25CE6C8", VA = "0x25CE6C8")]
	[Token(Token = "0x60003D9")]
	public IEnumerator method_12()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003DA RID: 986 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003DA")]
	[Address(RVA = "0x25CE740", Offset = "0x25CE740", VA = "0x25CE740")]
	public IEnumerator method_13()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003DB RID: 987 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003DB")]
	[Address(RVA = "0x25CE7B8", Offset = "0x25CE7B8", VA = "0x25CE7B8")]
	public IEnumerator method_14()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003DC RID: 988 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003DC")]
	[Address(RVA = "0x25CE5AC", Offset = "0x25CE5AC", VA = "0x25CE5AC")]
	public IEnumerator method_15()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003DD RID: 989 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003DD")]
	[Address(RVA = "0x25CE830", Offset = "0x25CE830", VA = "0x25CE830")]
	public IEnumerator method_16()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003DE RID: 990 RVA: 0x0000C2D8 File Offset: 0x0000A4D8
	[Token(Token = "0x60003DE")]
	[Address(RVA = "0x25CE8A8", Offset = "0x25CE8A8", VA = "0x25CE8A8")]
	public void method_17()
	{
		IEnumerator routine = this.method_33();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003DF RID: 991 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003DF")]
	[Address(RVA = "0x25CE94C", Offset = "0x25CE94C", VA = "0x25CE94C")]
	public IEnumerator method_18()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E0 RID: 992 RVA: 0x0000C2F4 File Offset: 0x0000A4F4
	[Token(Token = "0x60003E0")]
	[Address(RVA = "0x25CE9C4", Offset = "0x25CE9C4", VA = "0x25CE9C4")]
	public void method_19()
	{
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003E1")]
	[Address(RVA = "0x25CEA68", Offset = "0x25CEA68", VA = "0x25CEA68")]
	public IEnumerator method_20()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CEAE0", Offset = "0x25CEAE0", VA = "0x25CEAE0")]
	[Token(Token = "0x60003E2")]
	public IEnumerator method_21()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x0000C310 File Offset: 0x0000A510
	[Address(RVA = "0x25CEB58", Offset = "0x25CEB58", VA = "0x25CEB58")]
	[Token(Token = "0x60003E3")]
	public void method_22()
	{
		IEnumerator routine = this.method_35();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x0000C32C File Offset: 0x0000A52C
	[Address(RVA = "0x25CEBFC", Offset = "0x25CEBFC", VA = "0x25CEBFC")]
	[Token(Token = "0x60003E4")]
	public void method_23()
	{
		IEnumerator routine = this.method_76();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x0000C2BC File Offset: 0x0000A4BC
	[Address(RVA = "0x25CECA0", Offset = "0x25CECA0", VA = "0x25CECA0")]
	[Token(Token = "0x60003E5")]
	public void method_24()
	{
		IEnumerator routine = this.method_45();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003E6")]
	[Address(RVA = "0x25CECCC", Offset = "0x25CECCC", VA = "0x25CECCC")]
	public IEnumerator method_25()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x0000C2D8 File Offset: 0x0000A4D8
	[Token(Token = "0x60003E7")]
	[Address(RVA = "0x25CED44", Offset = "0x25CED44", VA = "0x25CED44")]
	public void method_26()
	{
		IEnumerator routine = this.method_33();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CED70", Offset = "0x25CED70", VA = "0x25CED70")]
	[Token(Token = "0x60003E8")]
	public IEnumerator method_27()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003E9")]
	[Address(RVA = "0x25CEDE8", Offset = "0x25CEDE8", VA = "0x25CEDE8")]
	public IEnumerator method_28()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CEE60", Offset = "0x25CEE60", VA = "0x25CEE60")]
	[Token(Token = "0x60003EA")]
	public IEnumerator method_29()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x0000C2D8 File Offset: 0x0000A4D8
	[Address(RVA = "0x25CEED8", Offset = "0x25CEED8", VA = "0x25CEED8")]
	[Token(Token = "0x60003EB")]
	public void method_30()
	{
		IEnumerator routine = this.method_33();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CEF04", Offset = "0x25CEF04", VA = "0x25CEF04")]
	[Token(Token = "0x60003EC")]
	public IEnumerator method_31()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x0000C348 File Offset: 0x0000A548
	[Address(RVA = "0x25CEF7C", Offset = "0x25CEF7C", VA = "0x25CEF7C")]
	[Token(Token = "0x60003ED")]
	public void method_32()
	{
		IEnumerator routine = this.method_73();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CE8D4", Offset = "0x25CE8D4", VA = "0x25CE8D4")]
	[Token(Token = "0x60003EE")]
	public IEnumerator method_33()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003EF RID: 1007 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF020", Offset = "0x25CF020", VA = "0x25CF020")]
	[Token(Token = "0x60003EF")]
	public IEnumerator method_34()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003F0 RID: 1008 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x25CF098", Offset = "0x25CF098", VA = "0x25CF098")]
	[Token(Token = "0x60003F0")]
	public TextureSwap()
	{
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003F1")]
	[Address(RVA = "0x25CEB84", Offset = "0x25CEB84", VA = "0x25CEB84")]
	public IEnumerator method_35()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003F2 RID: 1010 RVA: 0x0000C364 File Offset: 0x0000A564
	[Token(Token = "0x60003F2")]
	[Address(RVA = "0x25CF0A0", Offset = "0x25CF0A0", VA = "0x25CF0A0")]
	public void method_36()
	{
		IEnumerator routine = this.method_5();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003F3")]
	[Address(RVA = "0x25CF0CC", Offset = "0x25CF0CC", VA = "0x25CF0CC")]
	public IEnumerator method_37()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003F4 RID: 1012 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CE9F0", Offset = "0x25CE9F0", VA = "0x25CE9F0")]
	[Token(Token = "0x60003F4")]
	public IEnumerator method_38()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003F5 RID: 1013 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003F5")]
	[Address(RVA = "0x25CF144", Offset = "0x25CF144", VA = "0x25CF144")]
	public IEnumerator method_39()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003F6 RID: 1014 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003F6")]
	[Address(RVA = "0x25CF1BC", Offset = "0x25CF1BC", VA = "0x25CF1BC")]
	public IEnumerator method_40()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003F7 RID: 1015 RVA: 0x0000C380 File Offset: 0x0000A580
	[Address(RVA = "0x25CF234", Offset = "0x25CF234", VA = "0x25CF234")]
	[Token(Token = "0x60003F7")]
	public void Start()
	{
		IEnumerator routine = this.method_18();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003F8 RID: 1016 RVA: 0x0000C39C File Offset: 0x0000A59C
	[Token(Token = "0x60003F8")]
	[Address(RVA = "0x25CF260", Offset = "0x25CF260", VA = "0x25CF260")]
	public void method_41()
	{
		IEnumerator routine = this.method_27();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF28C", Offset = "0x25CF28C", VA = "0x25CF28C")]
	[Token(Token = "0x60003F9")]
	public IEnumerator method_42()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x60003FA")]
	[Address(RVA = "0x25CE2D0", Offset = "0x25CE2D0", VA = "0x25CE2D0")]
	public IEnumerator method_43()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x0000C3B8 File Offset: 0x0000A5B8
	[Address(RVA = "0x25CF304", Offset = "0x25CF304", VA = "0x25CF304")]
	[Token(Token = "0x60003FB")]
	public void method_44()
	{
		IEnumerator routine = this.method_51();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003FC RID: 1020 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CE650", Offset = "0x25CE650", VA = "0x25CE650")]
	[Token(Token = "0x60003FC")]
	public IEnumerator method_45()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003FD RID: 1021 RVA: 0x0000C3D4 File Offset: 0x0000A5D4
	[Token(Token = "0x60003FD")]
	[Address(RVA = "0x25CF3A8", Offset = "0x25CF3A8", VA = "0x25CF3A8")]
	public void method_46()
	{
		IEnumerator routine = this.method_42();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x0000C3B8 File Offset: 0x0000A5B8
	[Token(Token = "0x60003FE")]
	[Address(RVA = "0x25CF3D4", Offset = "0x25CF3D4", VA = "0x25CF3D4")]
	public void method_47()
	{
		IEnumerator routine = this.method_51();
		base.StartCoroutine(routine);
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x0000C284 File Offset: 0x0000A484
	[Token(Token = "0x60003FF")]
	[Address(RVA = "0x25CF400", Offset = "0x25CF400", VA = "0x25CF400")]
	public void method_48()
	{
		IEnumerator routine = this.method_6();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x0000C3F0 File Offset: 0x0000A5F0
	[Address(RVA = "0x25CF42C", Offset = "0x25CF42C", VA = "0x25CF42C")]
	[Token(Token = "0x6000400")]
	public void method_49()
	{
		IEnumerator routine = this.method_21();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000401 RID: 1025 RVA: 0x0000C40C File Offset: 0x0000A60C
	[Token(Token = "0x6000401")]
	[Address(RVA = "0x25CF458", Offset = "0x25CF458", VA = "0x25CF458")]
	public void method_50()
	{
		IEnumerator routine = this.method_16();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000402 RID: 1026 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF330", Offset = "0x25CF330", VA = "0x25CF330")]
	[Token(Token = "0x6000402")]
	public IEnumerator method_51()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x0000C428 File Offset: 0x0000A628
	[Address(RVA = "0x25CF484", Offset = "0x25CF484", VA = "0x25CF484")]
	[Token(Token = "0x6000403")]
	public void method_52()
	{
		IEnumerator routine = this.method_39();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x6000404")]
	[Address(RVA = "0x25CE22C", Offset = "0x25CE22C", VA = "0x25CE22C")]
	public IEnumerator method_53()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x6000405")]
	[Address(RVA = "0x25CF4B0", Offset = "0x25CF4B0", VA = "0x25CF4B0")]
	public IEnumerator method_54()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x0000C444 File Offset: 0x0000A644
	[Address(RVA = "0x25CF528", Offset = "0x25CF528", VA = "0x25CF528")]
	[Token(Token = "0x6000406")]
	public void method_55()
	{
		IEnumerator routine = this.method_13();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x0000C460 File Offset: 0x0000A660
	[Address(RVA = "0x25CF554", Offset = "0x25CF554", VA = "0x25CF554")]
	[Token(Token = "0x6000407")]
	public void method_56()
	{
		IEnumerator routine = this.method_40();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF580", Offset = "0x25CF580", VA = "0x25CF580")]
	[Token(Token = "0x6000408")]
	public IEnumerator method_57()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x0000C47C File Offset: 0x0000A67C
	[Token(Token = "0x6000409")]
	[Address(RVA = "0x25CF5F8", Offset = "0x25CF5F8", VA = "0x25CF5F8")]
	public void method_58()
	{
		IEnumerator routine = this.method_77();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x0000C2F4 File Offset: 0x0000A4F4
	[Address(RVA = "0x25CF69C", Offset = "0x25CF69C", VA = "0x25CF69C")]
	[Token(Token = "0x600040A")]
	public void method_59()
	{
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CE464", Offset = "0x25CE464", VA = "0x25CE464")]
	[Token(Token = "0x600040B")]
	public IEnumerator method_60()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x0000C498 File Offset: 0x0000A698
	[Token(Token = "0x600040C")]
	[Address(RVA = "0x25CF6C8", Offset = "0x25CF6C8", VA = "0x25CF6C8")]
	public void method_61()
	{
		IEnumerator routine = this.method_54();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF6F4", Offset = "0x25CF6F4", VA = "0x25CF6F4")]
	[Token(Token = "0x600040D")]
	public IEnumerator method_62()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x600040E")]
	[Address(RVA = "0x25CF76C", Offset = "0x25CF76C", VA = "0x25CF76C")]
	public IEnumerator method_63()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF7E4", Offset = "0x25CF7E4", VA = "0x25CF7E4")]
	[Token(Token = "0x600040F")]
	public IEnumerator method_64()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x6000410")]
	[Address(RVA = "0x25CF85C", Offset = "0x25CF85C", VA = "0x25CF85C")]
	public IEnumerator method_65()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x0000C32C File Offset: 0x0000A52C
	[Address(RVA = "0x25CF8D4", Offset = "0x25CF8D4", VA = "0x25CF8D4")]
	[Token(Token = "0x6000411")]
	public void method_66()
	{
		IEnumerator routine = this.method_76();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF900", Offset = "0x25CF900", VA = "0x25CF900")]
	[Token(Token = "0x6000412")]
	public IEnumerator method_67()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Address(RVA = "0x25CF978", Offset = "0x25CF978", VA = "0x25CF978")]
	[Token(Token = "0x6000413")]
	public IEnumerator method_68()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x0000C4B4 File Offset: 0x0000A6B4
	[Token(Token = "0x6000414")]
	[Address(RVA = "0x25CF9F0", Offset = "0x25CF9F0", VA = "0x25CF9F0")]
	public void method_69()
	{
		IEnumerator routine = this.method_64();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x0000C39C File Offset: 0x0000A59C
	[Address(RVA = "0x25CFA1C", Offset = "0x25CFA1C", VA = "0x25CFA1C")]
	[Token(Token = "0x6000415")]
	public void method_70()
	{
		IEnumerator routine = this.method_27();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x0000C364 File Offset: 0x0000A564
	[Address(RVA = "0x25CFA48", Offset = "0x25CFA48", VA = "0x25CFA48")]
	[Token(Token = "0x6000416")]
	public void method_71()
	{
		IEnumerator routine = this.method_5();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x6000417")]
	[Address(RVA = "0x25CFA74", Offset = "0x25CFA74", VA = "0x25CFA74")]
	public IEnumerator method_72()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x25CEFA8", Offset = "0x25CEFA8", VA = "0x25CEFA8")]
	[Token(Token = "0x6000418")]
	public IEnumerator method_73()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x0000C4D0 File Offset: 0x0000A6D0
	[Token(Token = "0x6000419")]
	[Address(RVA = "0x25CFAEC", Offset = "0x25CFAEC", VA = "0x25CFAEC")]
	public void method_74()
	{
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x600041A")]
	[Address(RVA = "0x25CFB18", Offset = "0x25CFB18", VA = "0x25CFB18")]
	public IEnumerator method_75()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x600041B")]
	[Address(RVA = "0x25CEC28", Offset = "0x25CEC28", VA = "0x25CEC28")]
	public IEnumerator method_76()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
	[Token(Token = "0x600041C")]
	[Address(RVA = "0x25CF624", Offset = "0x25CF624", VA = "0x25CF624")]
	public IEnumerator method_77()
	{
		TextureSwap.Class6 @class = new TextureSwap.Class6((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x0000C444 File Offset: 0x0000A644
	[Address(RVA = "0x25CFB90", Offset = "0x25CFB90", VA = "0x25CFB90")]
	[Token(Token = "0x600041D")]
	public void method_78()
	{
		IEnumerator routine = this.method_13();
		base.StartCoroutine(routine);
	}

	// Token: 0x0400007A RID: 122
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400007A")]
	public Texture2D texture2D_0;

	// Token: 0x0400007B RID: 123
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400007B")]
	public Texture2D texture2D_1;

	// Token: 0x0400007C RID: 124
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400007C")]
	public Texture2D texture2D_2;

	// Token: 0x0400007D RID: 125
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400007D")]
	public float float_0;

	// Token: 0x0400007E RID: 126
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x400007E")]
	public float float_1;

	// Token: 0x0400007F RID: 127
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400007F")]
	public Material material_0;
}
