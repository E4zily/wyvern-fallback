﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200007F RID: 127
[Token(Token = "0x200007F")]
public class MB_BatchPrepareObjectsForDynamicBatchingDescription : MonoBehaviour
{
	// Token: 0x060011F6 RID: 4598 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60011F6")]
	[Address(RVA = "0x2428A78", Offset = "0x2428A78", VA = "0x2428A78")]
	public MB_BatchPrepareObjectsForDynamicBatchingDescription()
	{
	}

	// Token: 0x060011F7 RID: 4599 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60011F7")]
	[Address(RVA = "0x2428A80", Offset = "0x2428A80", VA = "0x2428A80")]
	private void method_0()
	{
	}

	// Token: 0x060011F8 RID: 4600 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60011F8")]
	[Address(RVA = "0x2428B60", Offset = "0x2428B60", VA = "0x2428B60")]
	private void method_1()
	{
	}

	// Token: 0x060011F9 RID: 4601 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2428C40", Offset = "0x2428C40", VA = "0x2428C40")]
	[Token(Token = "0x60011F9")]
	private void method_2()
	{
	}

	// Token: 0x060011FA RID: 4602 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2428D20", Offset = "0x2428D20", VA = "0x2428D20")]
	[Token(Token = "0x60011FA")]
	private void method_3()
	{
	}

	// Token: 0x060011FB RID: 4603 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60011FB")]
	[Address(RVA = "0x2428E00", Offset = "0x2428E00", VA = "0x2428E00")]
	private void method_4()
	{
	}

	// Token: 0x060011FC RID: 4604 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2428EE0", Offset = "0x2428EE0", VA = "0x2428EE0")]
	[Token(Token = "0x60011FC")]
	private void method_5()
	{
	}

	// Token: 0x060011FD RID: 4605 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60011FD")]
	[Address(RVA = "0x2428FC0", Offset = "0x2428FC0", VA = "0x2428FC0")]
	private void method_6()
	{
	}

	// Token: 0x060011FE RID: 4606 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60011FE")]
	[Address(RVA = "0x24290A0", Offset = "0x24290A0", VA = "0x24290A0")]
	private void method_7()
	{
	}

	// Token: 0x060011FF RID: 4607 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2429180", Offset = "0x2429180", VA = "0x2429180")]
	[Token(Token = "0x60011FF")]
	private void method_8()
	{
	}

	// Token: 0x06001200 RID: 4608 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2429260", Offset = "0x2429260", VA = "0x2429260")]
	[Token(Token = "0x6001200")]
	private void method_9()
	{
	}

	// Token: 0x06001201 RID: 4609 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001201")]
	[Address(RVA = "0x2429340", Offset = "0x2429340", VA = "0x2429340")]
	private void method_10()
	{
	}

	// Token: 0x06001202 RID: 4610 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001202")]
	[Address(RVA = "0x2429420", Offset = "0x2429420", VA = "0x2429420")]
	private void method_11()
	{
	}

	// Token: 0x06001203 RID: 4611 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2429500", Offset = "0x2429500", VA = "0x2429500")]
	[Token(Token = "0x6001203")]
	private void method_12()
	{
	}

	// Token: 0x06001204 RID: 4612 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001204")]
	[Address(RVA = "0x24295E0", Offset = "0x24295E0", VA = "0x24295E0")]
	private void method_13()
	{
	}

	// Token: 0x06001205 RID: 4613 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001205")]
	[Address(RVA = "0x24296C0", Offset = "0x24296C0", VA = "0x24296C0")]
	private void method_14()
	{
	}

	// Token: 0x06001206 RID: 4614 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x24297A0", Offset = "0x24297A0", VA = "0x24297A0")]
	[Token(Token = "0x6001206")]
	private void method_15()
	{
	}

	// Token: 0x06001207 RID: 4615 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2429880", Offset = "0x2429880", VA = "0x2429880")]
	[Token(Token = "0x6001207")]
	private void method_16()
	{
	}

	// Token: 0x06001208 RID: 4616 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001208")]
	[Address(RVA = "0x2429960", Offset = "0x2429960", VA = "0x2429960")]
	private void method_17()
	{
	}

	// Token: 0x06001209 RID: 4617 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2429A40", Offset = "0x2429A40", VA = "0x2429A40")]
	[Token(Token = "0x6001209")]
	private void method_18()
	{
	}

	// Token: 0x0600120A RID: 4618 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600120A")]
	[Address(RVA = "0x2429B20", Offset = "0x2429B20", VA = "0x2429B20")]
	private void method_19()
	{
	}

	// Token: 0x0600120B RID: 4619 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600120B")]
	[Address(RVA = "0x2429C00", Offset = "0x2429C00", VA = "0x2429C00")]
	private void method_20()
	{
	}

	// Token: 0x0600120C RID: 4620 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2429CE0", Offset = "0x2429CE0", VA = "0x2429CE0")]
	[Token(Token = "0x600120C")]
	private void method_21()
	{
	}

	// Token: 0x0600120D RID: 4621 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2429DC0", Offset = "0x2429DC0", VA = "0x2429DC0")]
	[Token(Token = "0x600120D")]
	private void method_22()
	{
	}

	// Token: 0x0600120E RID: 4622 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600120E")]
	[Address(RVA = "0x2429EA0", Offset = "0x2429EA0", VA = "0x2429EA0")]
	private void method_23()
	{
	}

	// Token: 0x0600120F RID: 4623 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600120F")]
	[Address(RVA = "0x2429F80", Offset = "0x2429F80", VA = "0x2429F80")]
	private void method_24()
	{
	}

	// Token: 0x06001210 RID: 4624 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001210")]
	[Address(RVA = "0x242A060", Offset = "0x242A060", VA = "0x242A060")]
	private void method_25()
	{
	}

	// Token: 0x06001211 RID: 4625 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242A140", Offset = "0x242A140", VA = "0x242A140")]
	[Token(Token = "0x6001211")]
	private void method_26()
	{
	}

	// Token: 0x06001212 RID: 4626 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001212")]
	[Address(RVA = "0x242A220", Offset = "0x242A220", VA = "0x242A220")]
	private void method_27()
	{
	}

	// Token: 0x06001213 RID: 4627 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001213")]
	[Address(RVA = "0x242A300", Offset = "0x242A300", VA = "0x242A300")]
	private void method_28()
	{
	}

	// Token: 0x06001214 RID: 4628 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x242A3E0", Offset = "0x242A3E0", VA = "0x242A3E0")]
	[Token(Token = "0x6001214")]
	private void OnGUI()
	{
	}

	// Token: 0x06001215 RID: 4629 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001215")]
	[Address(RVA = "0x242A4C0", Offset = "0x242A4C0", VA = "0x242A4C0")]
	private void method_29()
	{
	}

	// Token: 0x06001216 RID: 4630 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001216")]
	[Address(RVA = "0x242A5A0", Offset = "0x242A5A0", VA = "0x242A5A0")]
	private void method_30()
	{
	}

	// Token: 0x06001217 RID: 4631 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001217")]
	[Address(RVA = "0x242A680", Offset = "0x242A680", VA = "0x242A680")]
	private void method_31()
	{
	}

	// Token: 0x06001218 RID: 4632 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001218")]
	[Address(RVA = "0x242A760", Offset = "0x242A760", VA = "0x242A760")]
	private void method_32()
	{
	}
}
