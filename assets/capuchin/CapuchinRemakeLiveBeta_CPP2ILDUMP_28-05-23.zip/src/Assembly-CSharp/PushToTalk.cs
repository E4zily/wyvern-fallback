﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200009C RID: 156
[Token(Token = "0x200009C")]
public class PushToTalk : MonoBehaviour
{
	// Token: 0x06001727 RID: 5927 RVA: 0x0002D250 File Offset: 0x0002B450
	[Address(RVA = "0x2A88738", Offset = "0x2A88738", VA = "0x2A88738")]
	[Token(Token = "0x6001727")]
	public void method_0()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x06001728 RID: 5928 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x6001728")]
	[Address(RVA = "0x2A8891C", Offset = "0x2A8891C", VA = "0x2A8891C")]
	public void method_1()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x06001729 RID: 5929 RVA: 0x0002D250 File Offset: 0x0002B450
	[Address(RVA = "0x2A88B00", Offset = "0x2A88B00", VA = "0x2A88B00")]
	[Token(Token = "0x6001729")]
	public void method_2()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600172A RID: 5930 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x600172A")]
	[Address(RVA = "0x2A88CE4", Offset = "0x2A88CE4", VA = "0x2A88CE4")]
	public void method_3()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600172B RID: 5931 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x600172B")]
	[Address(RVA = "0x2A88EC8", Offset = "0x2A88EC8", VA = "0x2A88EC8")]
	public void method_4()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600172C RID: 5932 RVA: 0x0002D278 File Offset: 0x0002B478
	[Token(Token = "0x600172C")]
	[Address(RVA = "0x2A8909C", Offset = "0x2A8909C", VA = "0x2A8909C")]
	public void method_5()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600172D RID: 5933 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A89280", Offset = "0x2A89280", VA = "0x2A89280")]
	[Token(Token = "0x600172D")]
	public PushToTalk()
	{
	}

	// Token: 0x0600172E RID: 5934 RVA: 0x0002D250 File Offset: 0x0002B450
	[Address(RVA = "0x2A89288", Offset = "0x2A89288", VA = "0x2A89288")]
	[Token(Token = "0x600172E")]
	public void method_6()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600172F RID: 5935 RVA: 0x0002D250 File Offset: 0x0002B450
	[Address(RVA = "0x2A8944C", Offset = "0x2A8944C", VA = "0x2A8944C")]
	[Token(Token = "0x600172F")]
	public void method_7()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x06001730 RID: 5936 RVA: 0x0002D2A0 File Offset: 0x0002B4A0
	[Token(Token = "0x6001730")]
	[Address(RVA = "0x2A89630", Offset = "0x2A89630", VA = "0x2A89630")]
	public void method_8()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001731 RID: 5937 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x6001731")]
	[Address(RVA = "0x2A897F4", Offset = "0x2A897F4", VA = "0x2A897F4")]
	public void method_9()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x06001732 RID: 5938 RVA: 0x0002D2A0 File Offset: 0x0002B4A0
	[Address(RVA = "0x2A899C8", Offset = "0x2A899C8", VA = "0x2A899C8")]
	[Token(Token = "0x6001732")]
	public void method_10()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001733 RID: 5939 RVA: 0x0002D250 File Offset: 0x0002B450
	[Address(RVA = "0x2A89B9C", Offset = "0x2A89B9C", VA = "0x2A89B9C")]
	[Token(Token = "0x6001733")]
	public void method_11()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x06001734 RID: 5940 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x6001734")]
	[Address(RVA = "0x2A89D80", Offset = "0x2A89D80", VA = "0x2A89D80")]
	public void method_12()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x06001735 RID: 5941 RVA: 0x0002D2D8 File Offset: 0x0002B4D8
	[Token(Token = "0x6001735")]
	[Address(RVA = "0x2A89F74", Offset = "0x2A89F74", VA = "0x2A89F74")]
	public void method_13()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(this.xrnode_1);
		if (deviceAtXRNode != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		if (deviceAtXRNode != null)
		{
		}
		GameObject gameObject2 = this.gameObject_0;
		if (deviceAtXRNode != null)
		{
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		if (deviceAtXRNode != null)
		{
		}
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		if (deviceAtXRNode != null)
		{
		}
		GameObject gameObject4 = this.gameObject_0;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x06001736 RID: 5942 RVA: 0x0002D360 File Offset: 0x0002B560
	[Token(Token = "0x6001736")]
	[Address(RVA = "0x2A8A138", Offset = "0x2A8A138", VA = "0x2A8A138")]
	public void method_14()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_0;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x06001737 RID: 5943 RVA: 0x0002D3D4 File Offset: 0x0002B5D4
	[Address(RVA = "0x2A8A2EC", Offset = "0x2A8A2EC", VA = "0x2A8A2EC")]
	[Token(Token = "0x6001737")]
	public void method_15()
	{
		InputDevice inputDevice;
		if (inputDevice != null)
		{
		}
	}

	// Token: 0x06001738 RID: 5944 RVA: 0x0002D3E4 File Offset: 0x0002B5E4
	[Address(RVA = "0x2A8A4A0", Offset = "0x2A8A4A0", VA = "0x2A8A4A0")]
	[Token(Token = "0x6001738")]
	public void method_16()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001739 RID: 5945 RVA: 0x0002D430 File Offset: 0x0002B630
	[Address(RVA = "0x2A8A674", Offset = "0x2A8A674", VA = "0x2A8A674")]
	[Token(Token = "0x6001739")]
	public void method_17()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x0600173A RID: 5946 RVA: 0x0002D430 File Offset: 0x0002B630
	[Token(Token = "0x600173A")]
	[Address(RVA = "0x2A8A838", Offset = "0x2A8A838", VA = "0x2A8A838")]
	public void method_18()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x0600173B RID: 5947 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x600173B")]
	[Address(RVA = "0x2A8A9FC", Offset = "0x2A8A9FC", VA = "0x2A8A9FC")]
	public void method_19()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600173C RID: 5948 RVA: 0x0002D490 File Offset: 0x0002B690
	[Token(Token = "0x600173C")]
	[Address(RVA = "0x2A8ABE0", Offset = "0x2A8ABE0", VA = "0x2A8ABE0")]
	public void Update()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_0;
		long active4 = 1L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x0600173D RID: 5949 RVA: 0x0002D250 File Offset: 0x0002B450
	[Address(RVA = "0x2A8AD94", Offset = "0x2A8AD94", VA = "0x2A8AD94")]
	[Token(Token = "0x600173D")]
	public void method_20()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600173E RID: 5950 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x600173E")]
	[Address(RVA = "0x2A8AF68", Offset = "0x2A8AF68", VA = "0x2A8AF68")]
	public void method_21()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x0600173F RID: 5951 RVA: 0x0002D504 File Offset: 0x0002B704
	[Address(RVA = "0x2A8B13C", Offset = "0x2A8B13C", VA = "0x2A8B13C")]
	[Token(Token = "0x600173F")]
	public void method_22()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001740 RID: 5952 RVA: 0x0002D3E4 File Offset: 0x0002B5E4
	[Token(Token = "0x6001740")]
	[Address(RVA = "0x2A8B300", Offset = "0x2A8B300", VA = "0x2A8B300")]
	public void method_23()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001741 RID: 5953 RVA: 0x0002D250 File Offset: 0x0002B450
	[Token(Token = "0x6001741")]
	[Address(RVA = "0x2A8B4D4", Offset = "0x2A8B4D4", VA = "0x2A8B4D4")]
	public void method_24()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
	}

	// Token: 0x06001742 RID: 5954 RVA: 0x0002D53C File Offset: 0x0002B73C
	[Token(Token = "0x6001742")]
	[Address(RVA = "0x2A8B6B8", Offset = "0x2A8B6B8", VA = "0x2A8B6B8")]
	public void method_25()
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		if (InputDevices.GetDeviceAtXRNode(this.xrnode_1) != null)
		{
		}
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_0;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
	}

	// Token: 0x040002FC RID: 764
	[Token(Token = "0x40002FC")]
	[FieldOffset(Offset = "0x18")]
	public XRNode xrnode_0;

	// Token: 0x040002FD RID: 765
	[Token(Token = "0x40002FD")]
	[FieldOffset(Offset = "0x1C")]
	public XRNode xrnode_1;

	// Token: 0x040002FE RID: 766
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40002FE")]
	public GameObject gameObject_0;
}
