﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200005D RID: 93
[Token(Token = "0x200005D")]
public class ElectricalBox : MonoBehaviour
{
	// Token: 0x06000CE4 RID: 3300 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000CE4")]
	[Address(RVA = "0x10CE0A8", Offset = "0x10CE0A8", VA = "0x10CE0A8")]
	public void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000CE5 RID: 3301 RVA: 0x00002371 File Offset: 0x00000571
	[Token(Token = "0x6000CE5")]
	[Address(RVA = "0x10CE15C", Offset = "0x10CE15C", VA = "0x10CE15C")]
	private void method_1()
	{
		if (this.bool_1)
		{
			this.method_70();
		}
	}

	// Token: 0x06000CE6 RID: 3302 RVA: 0x0001C23C File Offset: 0x0001A43C
	[Address(RVA = "0x10CE2CC", Offset = "0x10CE2CC", VA = "0x10CE2CC")]
	[Token(Token = "0x6000CE6")]
	public void method_2()
	{
		if (this.bool_0)
		{
			Debug.Log("Room Name: ");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("FingerTip");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000CE7 RID: 3303 RVA: 0x0001C284 File Offset: 0x0001A484
	[Token(Token = "0x6000CE7")]
	[Address(RVA = "0x10CE410", Offset = "0x10CE410", VA = "0x10CE410")]
	public void method_3()
	{
		if (this.bool_0)
		{
			Debug.Log("Not connected to room");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("/");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000CE8 RID: 3304 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10CE554", Offset = "0x10CE554", VA = "0x10CE554")]
	[Token(Token = "0x6000CE8")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000CE9 RID: 3305 RVA: 0x00002381 File Offset: 0x00000581
	[Token(Token = "0x6000CE9")]
	[Address(RVA = "0x10CE60C", Offset = "0x10CE60C", VA = "0x10CE60C")]
	private void method_5()
	{
		if (this.bool_1)
		{
			this.method_56();
		}
	}

	// Token: 0x06000CEA RID: 3306 RVA: 0x00002391 File Offset: 0x00000591
	[Address(RVA = "0x10CE77C", Offset = "0x10CE77C", VA = "0x10CE77C")]
	[Token(Token = "0x6000CEA")]
	private void method_6()
	{
		if (this.bool_1)
		{
			this.method_78();
		}
	}

	// Token: 0x06000CEB RID: 3307 RVA: 0x000023A1 File Offset: 0x000005A1
	[Token(Token = "0x6000CEB")]
	[Address(RVA = "0x10CE8EC", Offset = "0x10CE8EC", VA = "0x10CE8EC")]
	private void method_7()
	{
		if (this.bool_1)
		{
			this.method_83();
		}
	}

	// Token: 0x06000CEC RID: 3308 RVA: 0x000023B1 File Offset: 0x000005B1
	[Token(Token = "0x6000CEC")]
	[Address(RVA = "0x10CEA5C", Offset = "0x10CEA5C", VA = "0x10CEA5C")]
	private void method_8()
	{
		this.method_3();
	}

	// Token: 0x06000CED RID: 3309 RVA: 0x0001C220 File Offset: 0x0001A420
	[Address(RVA = "0x10CEA60", Offset = "0x10CEA60", VA = "0x10CEA60")]
	[Token(Token = "0x6000CED")]
	public void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000CEE RID: 3310 RVA: 0x0001C2F8 File Offset: 0x0001A4F8
	[Address(RVA = "0x10CEB14", Offset = "0x10CEB14", VA = "0x10CEB14")]
	[Token(Token = "0x6000CEE")]
	public void method_10()
	{
		if (this.bool_0)
		{
			Debug.Log("{0} ({1})");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("Joined a Room.");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000CEF RID: 3311 RVA: 0x0001C340 File Offset: 0x0001A540
	[Token(Token = "0x6000CEF")]
	[Address(RVA = "0x10CEC58", Offset = "0x10CEC58", VA = "0x10CEC58")]
	private void method_11()
	{
		if (this.bool_1)
		{
			this.method_17();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000CF0 RID: 3312 RVA: 0x0001C364 File Offset: 0x0001A564
	[Token(Token = "0x6000CF0")]
	[Address(RVA = "0x10CEDCC", Offset = "0x10CEDCC", VA = "0x10CEDCC")]
	public void method_12()
	{
		if (this.bool_0)
		{
			Debug.Log("We don't need this electrical box");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("KeyPos");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000CF1 RID: 3313 RVA: 0x000023B9 File Offset: 0x000005B9
	[Address(RVA = "0x10CEF10", Offset = "0x10CEF10", VA = "0x10CEF10")]
	[Token(Token = "0x6000CF1")]
	private void method_13()
	{
		this.method_88();
	}

	// Token: 0x06000CF2 RID: 3314 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000CF2")]
	[Address(RVA = "0x10CF058", Offset = "0x10CF058", VA = "0x10CF058")]
	public ElectricalBox()
	{
	}

	// Token: 0x06000CF3 RID: 3315 RVA: 0x000023C1 File Offset: 0x000005C1
	[Address(RVA = "0x10CF060", Offset = "0x10CF060", VA = "0x10CF060")]
	[Token(Token = "0x6000CF3")]
	private void method_14()
	{
		if (this.bool_1)
		{
			this.method_2();
		}
	}

	// Token: 0x06000CF4 RID: 3316 RVA: 0x0001C3AC File Offset: 0x0001A5AC
	[Token(Token = "0x6000CF4")]
	[Address(RVA = "0x10CF08C", Offset = "0x10CF08C", VA = "0x10CF08C")]
	public void method_15()
	{
		Debug.Log("/");
	}

	// Token: 0x06000CF5 RID: 3317 RVA: 0x000023D1 File Offset: 0x000005D1
	[Token(Token = "0x6000CF5")]
	[Address(RVA = "0x10CF1D0", Offset = "0x10CF1D0", VA = "0x10CF1D0")]
	private void method_16()
	{
		this.method_17();
	}

	// Token: 0x06000CF6 RID: 3318 RVA: 0x0001C3C4 File Offset: 0x0001A5C4
	[Address(RVA = "0x10CEC88", Offset = "0x10CEC88", VA = "0x10CEC88")]
	[Token(Token = "0x6000CF6")]
	public void method_17()
	{
		if (this.bool_0)
		{
			Debug.Log("Thumb");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("You Already Own This Item");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000CF7 RID: 3319 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Token(Token = "0x6000CF7")]
	[Address(RVA = "0x10CF1D4", Offset = "0x10CF1D4", VA = "0x10CF1D4")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000CF8 RID: 3320 RVA: 0x0001C40C File Offset: 0x0001A60C
	[Token(Token = "0x6000CF8")]
	[Address(RVA = "0x10CF28C", Offset = "0x10CF28C", VA = "0x10CF28C")]
	public void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000CF9 RID: 3321 RVA: 0x0001C428 File Offset: 0x0001A628
	[Address(RVA = "0x10CF344", Offset = "0x10CF344", VA = "0x10CF344")]
	[Token(Token = "0x6000CF9")]
	private void method_20()
	{
		if (this.bool_1)
		{
			this.method_88();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000CFA RID: 3322 RVA: 0x0001C44C File Offset: 0x0001A64C
	[Token(Token = "0x6000CFA")]
	[Address(RVA = "0x10CF374", Offset = "0x10CF374", VA = "0x10CF374")]
	public void method_21()
	{
		if (this.bool_0)
		{
			Debug.Log("hh:mmtt");
			return;
		}
		GameObject[] array;
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000CFB RID: 3323 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10CF4B8", Offset = "0x10CF4B8", VA = "0x10CF4B8")]
	[Token(Token = "0x6000CFB")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000CFC RID: 3324 RVA: 0x000023D9 File Offset: 0x000005D9
	[Address(RVA = "0x10CF570", Offset = "0x10CF570", VA = "0x10CF570")]
	[Token(Token = "0x6000CFC")]
	private void Start()
	{
		this.method_12();
	}

	// Token: 0x06000CFD RID: 3325 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000CFD")]
	[Address(RVA = "0x10CF574", Offset = "0x10CF574", VA = "0x10CF574")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000CFE RID: 3326 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000CFE")]
	[Address(RVA = "0x10CF628", Offset = "0x10CF628", VA = "0x10CF628")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000CFF RID: 3327 RVA: 0x000023E1 File Offset: 0x000005E1
	[Token(Token = "0x6000CFF")]
	[Address(RVA = "0x10CF6DC", Offset = "0x10CF6DC", VA = "0x10CF6DC")]
	private void method_24()
	{
		this.method_31();
	}

	// Token: 0x06000D00 RID: 3328 RVA: 0x000023E9 File Offset: 0x000005E9
	[Address(RVA = "0x10CF824", Offset = "0x10CF824", VA = "0x10CF824")]
	[Token(Token = "0x6000D00")]
	private void method_25()
	{
		if (this.bool_1)
		{
			this.method_21();
		}
	}

	// Token: 0x06000D01 RID: 3329 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10CF850", Offset = "0x10CF850", VA = "0x10CF850")]
	[Token(Token = "0x6000D01")]
	public void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D02 RID: 3330 RVA: 0x000023F9 File Offset: 0x000005F9
	[Token(Token = "0x6000D02")]
	[Address(RVA = "0x10CF908", Offset = "0x10CF908", VA = "0x10CF908")]
	private void method_27()
	{
		this.method_74();
	}

	// Token: 0x06000D03 RID: 3331 RVA: 0x000023D9 File Offset: 0x000005D9
	[Token(Token = "0x6000D03")]
	[Address(RVA = "0x10CFA50", Offset = "0x10CFA50", VA = "0x10CFA50")]
	private void method_28()
	{
		this.method_12();
	}

	// Token: 0x06000D04 RID: 3332 RVA: 0x0001C220 File Offset: 0x0001A420
	[Address(RVA = "0x10CFA54", Offset = "0x10CFA54", VA = "0x10CFA54")]
	[Token(Token = "0x6000D04")]
	public void method_29(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D05 RID: 3333 RVA: 0x00002401 File Offset: 0x00000601
	[Token(Token = "0x6000D05")]
	[Address(RVA = "0x10CFB08", Offset = "0x10CFB08", VA = "0x10CFB08")]
	private void method_30()
	{
		this.method_15();
	}

	// Token: 0x06000D06 RID: 3334 RVA: 0x0001C488 File Offset: 0x0001A688
	[Address(RVA = "0x10CF6E0", Offset = "0x10CF6E0", VA = "0x10CF6E0")]
	[Token(Token = "0x6000D06")]
	public void method_31()
	{
		if (this.bool_0)
		{
			Debug.Log("BN");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("\tExpires: ");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D07 RID: 3335 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D07")]
	[Address(RVA = "0x10CFB0C", Offset = "0x10CFB0C", VA = "0x10CFB0C")]
	public void method_32(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D08 RID: 3336 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D08")]
	[Address(RVA = "0x10CFBC0", Offset = "0x10CFBC0", VA = "0x10CFBC0")]
	public void method_33(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D09 RID: 3337 RVA: 0x00002409 File Offset: 0x00000609
	[Token(Token = "0x6000D09")]
	[Address(RVA = "0x10CFC74", Offset = "0x10CFC74", VA = "0x10CFC74")]
	private void method_34()
	{
		if (this.bool_1)
		{
			this.method_10();
		}
	}

	// Token: 0x06000D0A RID: 3338 RVA: 0x000023F9 File Offset: 0x000005F9
	[Token(Token = "0x6000D0A")]
	[Address(RVA = "0x10CFCA0", Offset = "0x10CFCA0", VA = "0x10CFCA0")]
	private void method_35()
	{
		this.method_74();
	}

	// Token: 0x06000D0B RID: 3339 RVA: 0x0001C4D0 File Offset: 0x0001A6D0
	[Token(Token = "0x6000D0B")]
	[Address(RVA = "0x10CFCA4", Offset = "0x10CFCA4", VA = "0x10CFCA4")]
	public void method_36()
	{
		if (this.bool_0)
		{
			Debug.Log("Regular");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("Trying Getting Entilement...");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D0C RID: 3340 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10CFDE8", Offset = "0x10CFDE8", VA = "0x10CFDE8")]
	[Token(Token = "0x6000D0C")]
	public void method_37(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D0D RID: 3341 RVA: 0x00002419 File Offset: 0x00000619
	[Token(Token = "0x6000D0D")]
	[Address(RVA = "0x10CFEA0", Offset = "0x10CFEA0", VA = "0x10CFEA0")]
	private void method_38()
	{
		this.method_2();
	}

	// Token: 0x06000D0E RID: 3342 RVA: 0x00002421 File Offset: 0x00000621
	[Address(RVA = "0x10CFEA4", Offset = "0x10CFEA4", VA = "0x10CFEA4")]
	[Token(Token = "0x6000D0E")]
	private void method_39()
	{
		this.method_78();
	}

	// Token: 0x06000D0F RID: 3343 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Token(Token = "0x6000D0F")]
	[Address(RVA = "0x10CFEA8", Offset = "0x10CFEA8", VA = "0x10CFEA8")]
	public void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D10 RID: 3344 RVA: 0x00002429 File Offset: 0x00000629
	[Address(RVA = "0x10CFF60", Offset = "0x10CFF60", VA = "0x10CFF60")]
	[Token(Token = "0x6000D10")]
	private void method_41()
	{
		this.method_96();
	}

	// Token: 0x06000D11 RID: 3345 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Token(Token = "0x6000D11")]
	[Address(RVA = "0x10D00A8", Offset = "0x10D00A8", VA = "0x10D00A8")]
	public void method_42(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D12 RID: 3346 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D12")]
	[Address(RVA = "0x10D0160", Offset = "0x10D0160", VA = "0x10D0160")]
	public void method_43(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D13 RID: 3347 RVA: 0x0001C220 File Offset: 0x0001A420
	[Address(RVA = "0x10D0214", Offset = "0x10D0214", VA = "0x10D0214")]
	[Token(Token = "0x6000D13")]
	public void method_44(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D14 RID: 3348 RVA: 0x000023F9 File Offset: 0x000005F9
	[Address(RVA = "0x10D02C8", Offset = "0x10D02C8", VA = "0x10D02C8")]
	[Token(Token = "0x6000D14")]
	private void method_45()
	{
		this.method_74();
	}

	// Token: 0x06000D15 RID: 3349 RVA: 0x00002391 File Offset: 0x00000591
	[Token(Token = "0x6000D15")]
	[Address(RVA = "0x10D02CC", Offset = "0x10D02CC", VA = "0x10D02CC")]
	private void method_46()
	{
		if (this.bool_1)
		{
			this.method_78();
		}
	}

	// Token: 0x06000D16 RID: 3350 RVA: 0x00002431 File Offset: 0x00000631
	[Token(Token = "0x6000D16")]
	[Address(RVA = "0x10D02F8", Offset = "0x10D02F8", VA = "0x10D02F8")]
	private void method_47()
	{
		this.method_10();
	}

	// Token: 0x06000D17 RID: 3351 RVA: 0x00002439 File Offset: 0x00000639
	[Address(RVA = "0x10D02FC", Offset = "0x10D02FC", VA = "0x10D02FC")]
	[Token(Token = "0x6000D17")]
	private void method_48()
	{
		this.method_58();
	}

	// Token: 0x06000D18 RID: 3352 RVA: 0x00002401 File Offset: 0x00000601
	[Token(Token = "0x6000D18")]
	[Address(RVA = "0x10D0444", Offset = "0x10D0444", VA = "0x10D0444")]
	private void method_49()
	{
		this.method_15();
	}

	// Token: 0x06000D19 RID: 3353 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10D0448", Offset = "0x10D0448", VA = "0x10D0448")]
	[Token(Token = "0x6000D19")]
	public void method_50(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D1A RID: 3354 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Token(Token = "0x6000D1A")]
	[Address(RVA = "0x10D0500", Offset = "0x10D0500", VA = "0x10D0500")]
	public void method_51(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D1B RID: 3355 RVA: 0x00002441 File Offset: 0x00000641
	[Token(Token = "0x6000D1B")]
	[Address(RVA = "0x10D05B8", Offset = "0x10D05B8", VA = "0x10D05B8")]
	private void method_52()
	{
		if (this.bool_1)
		{
			this.method_15();
		}
	}

	// Token: 0x06000D1C RID: 3356 RVA: 0x000023D1 File Offset: 0x000005D1
	[Address(RVA = "0x10D05E4", Offset = "0x10D05E4", VA = "0x10D05E4")]
	[Token(Token = "0x6000D1C")]
	private void method_53()
	{
		this.method_17();
	}

	// Token: 0x06000D1D RID: 3357 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Token(Token = "0x6000D1D")]
	[Address(RVA = "0x10D05E8", Offset = "0x10D05E8", VA = "0x10D05E8")]
	public void method_54(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D1E RID: 3358 RVA: 0x0001C340 File Offset: 0x0001A540
	[Token(Token = "0x6000D1E")]
	[Address(RVA = "0x10D06A0", Offset = "0x10D06A0", VA = "0x10D06A0")]
	private void method_55()
	{
		if (this.bool_1)
		{
			this.method_17();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000D1F RID: 3359 RVA: 0x0001C518 File Offset: 0x0001A718
	[Address(RVA = "0x10CE638", Offset = "0x10CE638", VA = "0x10CE638")]
	[Token(Token = "0x6000D1F")]
	public void method_56()
	{
		if (this.bool_0)
		{
			Debug.Log("DisableCosmetic");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("BLUPORT");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D20 RID: 3360 RVA: 0x00002451 File Offset: 0x00000651
	[Token(Token = "0x6000D20")]
	[Address(RVA = "0x10D06D0", Offset = "0x10D06D0", VA = "0x10D06D0")]
	private void method_57()
	{
		if (this.bool_1)
		{
			this.method_36();
		}
	}

	// Token: 0x06000D21 RID: 3361 RVA: 0x0001C560 File Offset: 0x0001A760
	[Address(RVA = "0x10D0300", Offset = "0x10D0300", VA = "0x10D0300")]
	[Token(Token = "0x6000D21")]
	public void method_58()
	{
	}

	// Token: 0x06000D22 RID: 3362 RVA: 0x00002461 File Offset: 0x00000661
	[Address(RVA = "0x10D06FC", Offset = "0x10D06FC", VA = "0x10D06FC")]
	[Token(Token = "0x6000D22")]
	private void method_59()
	{
		this.method_56();
	}

	// Token: 0x06000D23 RID: 3363 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D23")]
	[Address(RVA = "0x10D0700", Offset = "0x10D0700", VA = "0x10D0700")]
	public void method_60(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D24 RID: 3364 RVA: 0x00002469 File Offset: 0x00000669
	[Token(Token = "0x6000D24")]
	[Address(RVA = "0x10D07B4", Offset = "0x10D07B4", VA = "0x10D07B4")]
	private void method_61()
	{
		if (this.bool_1)
		{
			this.method_88();
		}
	}

	// Token: 0x06000D25 RID: 3365 RVA: 0x0001C570 File Offset: 0x0001A770
	[Token(Token = "0x6000D25")]
	[Address(RVA = "0x10D07E0", Offset = "0x10D07E0", VA = "0x10D07E0")]
	private void method_62()
	{
		if (this.bool_1)
		{
			this.method_96();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000D26 RID: 3366 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10D0810", Offset = "0x10D0810", VA = "0x10D0810")]
	[Token(Token = "0x6000D26")]
	public void method_63(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D27 RID: 3367 RVA: 0x000023B1 File Offset: 0x000005B1
	[Address(RVA = "0x10D08C8", Offset = "0x10D08C8", VA = "0x10D08C8")]
	[Token(Token = "0x6000D27")]
	private void method_64()
	{
		this.method_3();
	}

	// Token: 0x06000D28 RID: 3368 RVA: 0x000023E9 File Offset: 0x000005E9
	[Token(Token = "0x6000D28")]
	[Address(RVA = "0x10D08CC", Offset = "0x10D08CC", VA = "0x10D08CC")]
	private void method_65()
	{
		if (this.bool_1)
		{
			this.method_21();
		}
	}

	// Token: 0x06000D29 RID: 3369 RVA: 0x00002479 File Offset: 0x00000679
	[Token(Token = "0x6000D29")]
	[Address(RVA = "0x10D08F8", Offset = "0x10D08F8", VA = "0x10D08F8")]
	private void method_66()
	{
		if (this.bool_1)
		{
			this.method_74();
		}
	}

	// Token: 0x06000D2A RID: 3370 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10D0924", Offset = "0x10D0924", VA = "0x10D0924")]
	[Token(Token = "0x6000D2A")]
	public void method_67(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D2B RID: 3371 RVA: 0x00002419 File Offset: 0x00000619
	[Token(Token = "0x6000D2B")]
	[Address(RVA = "0x10D09DC", Offset = "0x10D09DC", VA = "0x10D09DC")]
	private void method_68()
	{
		this.method_2();
	}

	// Token: 0x06000D2C RID: 3372 RVA: 0x00002489 File Offset: 0x00000689
	[Address(RVA = "0x10D09E0", Offset = "0x10D09E0", VA = "0x10D09E0")]
	[Token(Token = "0x6000D2C")]
	private void method_69()
	{
		if (this.bool_1)
		{
			this.method_31();
		}
	}

	// Token: 0x06000D2D RID: 3373 RVA: 0x0001C594 File Offset: 0x0001A794
	[Token(Token = "0x6000D2D")]
	[Address(RVA = "0x10CE188", Offset = "0x10CE188", VA = "0x10CE188")]
	public void method_70()
	{
		if (this.bool_0)
		{
			Debug.Log("Completed baking textures on frame ");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("CASUAL");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D2E RID: 3374 RVA: 0x0001C5DC File Offset: 0x0001A7DC
	[Token(Token = "0x6000D2E")]
	[Address(RVA = "0x10D0A0C", Offset = "0x10D0A0C", VA = "0x10D0A0C")]
	public void method_71(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D2F RID: 3375 RVA: 0x00002499 File Offset: 0x00000699
	[Address(RVA = "0x10D0AC0", Offset = "0x10D0AC0", VA = "0x10D0AC0")]
	[Token(Token = "0x6000D2F")]
	private void method_72()
	{
		if (this.bool_1)
		{
			this.method_12();
		}
	}

	// Token: 0x06000D30 RID: 3376 RVA: 0x00002409 File Offset: 0x00000609
	[Token(Token = "0x6000D30")]
	[Address(RVA = "0x10D0AEC", Offset = "0x10D0AEC", VA = "0x10D0AEC")]
	private void method_73()
	{
		if (this.bool_1)
		{
			this.method_10();
		}
	}

	// Token: 0x06000D31 RID: 3377 RVA: 0x0001C5F0 File Offset: 0x0001A7F0
	[Token(Token = "0x6000D31")]
	[Address(RVA = "0x10CF90C", Offset = "0x10CF90C", VA = "0x10CF90C")]
	public void method_74()
	{
		if (this.bool_0)
		{
			Debug.Log("containsStaff");
			return;
		}
		GameObject.FindGameObjectsWithTag("betaAgree");
		UnityEngine.Random.Range(0, 0);
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D32 RID: 3378 RVA: 0x0001C220 File Offset: 0x0001A420
	[Address(RVA = "0x10D0B18", Offset = "0x10D0B18", VA = "0x10D0B18")]
	[Token(Token = "0x6000D32")]
	public void method_75(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D33 RID: 3379 RVA: 0x00002421 File Offset: 0x00000621
	[Token(Token = "0x6000D33")]
	[Address(RVA = "0x10D0BCC", Offset = "0x10D0BCC", VA = "0x10D0BCC")]
	private void method_76()
	{
		this.method_78();
	}

	// Token: 0x06000D34 RID: 3380 RVA: 0x00002479 File Offset: 0x00000679
	[Address(RVA = "0x10D0BD0", Offset = "0x10D0BD0", VA = "0x10D0BD0")]
	[Token(Token = "0x6000D34")]
	private void method_77()
	{
		if (this.bool_1)
		{
			this.method_74();
		}
	}

	// Token: 0x06000D35 RID: 3381 RVA: 0x0001C638 File Offset: 0x0001A838
	[Address(RVA = "0x10CE7A8", Offset = "0x10CE7A8", VA = "0x10CE7A8")]
	[Token(Token = "0x6000D35")]
	public void method_78()
	{
		Debug.Log("Name Changing Error. Error: ");
	}

	// Token: 0x06000D36 RID: 3382 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Token(Token = "0x6000D36")]
	[Address(RVA = "0x10D0BFC", Offset = "0x10D0BFC", VA = "0x10D0BFC")]
	public void method_79(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D37 RID: 3383 RVA: 0x0001C650 File Offset: 0x0001A850
	[Token(Token = "0x6000D37")]
	[Address(RVA = "0x10D0CB4", Offset = "0x10D0CB4", VA = "0x10D0CB4")]
	private void method_80()
	{
		if (this.bool_1)
		{
			this.method_70();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000D38 RID: 3384 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D38")]
	[Address(RVA = "0x10D0CE4", Offset = "0x10D0CE4", VA = "0x10D0CE4")]
	public void method_81(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D39 RID: 3385 RVA: 0x000023D9 File Offset: 0x000005D9
	[Address(RVA = "0x10D0D98", Offset = "0x10D0D98", VA = "0x10D0D98")]
	[Token(Token = "0x6000D39")]
	private void method_82()
	{
		this.method_12();
	}

	// Token: 0x06000D3A RID: 3386 RVA: 0x0001C674 File Offset: 0x0001A874
	[Address(RVA = "0x10CE918", Offset = "0x10CE918", VA = "0x10CE918")]
	[Token(Token = "0x6000D3A")]
	public void method_83()
	{
		if (this.bool_0)
		{
			Debug.Log("username");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("Squeeze");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D3B RID: 3387 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D3B")]
	[Address(RVA = "0x10D0D9C", Offset = "0x10D0D9C", VA = "0x10D0D9C")]
	public void method_84(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D3C RID: 3388 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Token(Token = "0x6000D3C")]
	[Address(RVA = "0x10D0E50", Offset = "0x10D0E50", VA = "0x10D0E50")]
	public void method_85(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D3D RID: 3389 RVA: 0x00002499 File Offset: 0x00000699
	[Address(RVA = "0x10D0F08", Offset = "0x10D0F08", VA = "0x10D0F08")]
	[Token(Token = "0x6000D3D")]
	private void Update()
	{
		if (this.bool_1)
		{
			this.method_12();
		}
	}

	// Token: 0x06000D3E RID: 3390 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D3E")]
	[Address(RVA = "0x10D0F34", Offset = "0x10D0F34", VA = "0x10D0F34")]
	public void method_86(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D3F RID: 3391 RVA: 0x0001C6BC File Offset: 0x0001A8BC
	[Address(RVA = "0x10D0FE8", Offset = "0x10D0FE8", VA = "0x10D0FE8")]
	[Token(Token = "0x6000D3F")]
	private void method_87()
	{
		if (this.bool_1)
		{
			this.method_58();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000D40 RID: 3392 RVA: 0x0001C6E0 File Offset: 0x0001A8E0
	[Token(Token = "0x6000D40")]
	[Address(RVA = "0x10CEF14", Offset = "0x10CEF14", VA = "0x10CEF14")]
	public void method_88()
	{
		if (this.bool_0)
		{
			Debug.Log("\tExpires: ");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("username");
		this.gameObject_0 = array;
		Transform transform;
		Vector3 position = transform.position;
	}

	// Token: 0x06000D41 RID: 3393 RVA: 0x000024A9 File Offset: 0x000006A9
	[Token(Token = "0x6000D41")]
	[Address(RVA = "0x10D1018", Offset = "0x10D1018", VA = "0x10D1018")]
	private void method_89()
	{
		if (this.bool_1)
		{
			this.method_3();
		}
	}

	// Token: 0x06000D42 RID: 3394 RVA: 0x00002439 File Offset: 0x00000639
	[Address(RVA = "0x10D1044", Offset = "0x10D1044", VA = "0x10D1044")]
	[Token(Token = "0x6000D42")]
	private void method_90()
	{
		this.method_58();
	}

	// Token: 0x06000D43 RID: 3395 RVA: 0x0001C220 File Offset: 0x0001A420
	[Address(RVA = "0x10D1048", Offset = "0x10D1048", VA = "0x10D1048")]
	[Token(Token = "0x6000D43")]
	public void method_91(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D44 RID: 3396 RVA: 0x000023F9 File Offset: 0x000005F9
	[Token(Token = "0x6000D44")]
	[Address(RVA = "0x10D10FC", Offset = "0x10D10FC", VA = "0x10D10FC")]
	private void method_92()
	{
		this.method_74();
	}

	// Token: 0x06000D45 RID: 3397 RVA: 0x0001C220 File Offset: 0x0001A420
	[Token(Token = "0x6000D45")]
	[Address(RVA = "0x10D1100", Offset = "0x10D1100", VA = "0x10D1100")]
	public void method_93(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x06000D46 RID: 3398 RVA: 0x00002499 File Offset: 0x00000699
	[Address(RVA = "0x10D11B4", Offset = "0x10D11B4", VA = "0x10D11B4")]
	[Token(Token = "0x6000D46")]
	private void method_94()
	{
		if (this.bool_1)
		{
			this.method_12();
		}
	}

	// Token: 0x06000D47 RID: 3399 RVA: 0x000023C1 File Offset: 0x000005C1
	[Token(Token = "0x6000D47")]
	[Address(RVA = "0x10D11E0", Offset = "0x10D11E0", VA = "0x10D11E0")]
	private void method_95()
	{
		if (this.bool_1)
		{
			this.method_2();
		}
	}

	// Token: 0x06000D48 RID: 3400 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	[Address(RVA = "0x10D120C", Offset = "0x10D120C", VA = "0x10D120C")]
	[Token(Token = "0x6000D48")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		DoorLerp doorLerp = this.doorLerp_0;
		long num = 1L;
		doorLerp.bool_0 = (num != 0L);
	}

	// Token: 0x06000D49 RID: 3401 RVA: 0x0001C71C File Offset: 0x0001A91C
	[Token(Token = "0x6000D49")]
	[Address(RVA = "0x10CFF64", Offset = "0x10CFF64", VA = "0x10CFF64")]
	public void method_96()
	{
		if (this.bool_0)
		{
			Debug.Log("You are not the master of the server, you cannot start the game.");
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("{0}/{1:f0}");
		this.gameObject_0 = array;
		Transform transform = this.gameObject_1.transform;
		Transform transform2;
		Vector3 position = transform2.position;
	}

	// Token: 0x06000D4A RID: 3402 RVA: 0x000024B9 File Offset: 0x000006B9
	[Address(RVA = "0x10D12C4", Offset = "0x10D12C4", VA = "0x10D12C4")]
	[Token(Token = "0x6000D4A")]
	private void method_97()
	{
		if (this.bool_1)
		{
			this.method_96();
		}
	}

	// Token: 0x06000D4B RID: 3403 RVA: 0x0001C650 File Offset: 0x0001A850
	[Token(Token = "0x6000D4B")]
	[Address(RVA = "0x10D12F0", Offset = "0x10D12F0", VA = "0x10D12F0")]
	private void method_98()
	{
		if (this.bool_1)
		{
			this.method_70();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x06000D4C RID: 3404 RVA: 0x0001C764 File Offset: 0x0001A964
	[Token(Token = "0x6000D4C")]
	[Address(RVA = "0x10D1320", Offset = "0x10D1320", VA = "0x10D1320")]
	private void method_99()
	{
		if (this.bool_1)
		{
			this.method_21();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
	}

	// Token: 0x040001E9 RID: 489
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001E9")]
	public GameObject[] gameObject_0;

	// Token: 0x040001EA RID: 490
	[Token(Token = "0x40001EA")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_1;

	// Token: 0x040001EB RID: 491
	[Token(Token = "0x40001EB")]
	[FieldOffset(Offset = "0x28")]
	public DoorLerp doorLerp_0;

	// Token: 0x040001EC RID: 492
	[Token(Token = "0x40001EC")]
	[FieldOffset(Offset = "0x30")]
	public bool bool_0;

	// Token: 0x040001ED RID: 493
	[Token(Token = "0x40001ED")]
	[FieldOffset(Offset = "0x31")]
	public bool bool_1;
}
