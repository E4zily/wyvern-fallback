﻿using System;
using Cpp2IlInjected;
using Locomotion;
using UnityEngine;

// Token: 0x020000D3 RID: 211
[Token(Token = "0x20000D3")]
public class LavaKill : MonoBehaviour
{
	// Token: 0x06001EF6 RID: 7926 RVA: 0x00038F64 File Offset: 0x00037164
	[Address(RVA = "0x35E4D5C", Offset = "0x35E4D5C", VA = "0x35E4D5C")]
	[Token(Token = "0x6001EF6")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.name == "retract broken";
		Player.player_0.method_20();
	}

	// Token: 0x06001EF7 RID: 7927 RVA: 0x00038F94 File Offset: 0x00037194
	[Address(RVA = "0x35E525C", Offset = "0x35E525C", VA = "0x35E525C")]
	[Token(Token = "0x6001EF7")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.name == "Regular";
		this.lavaManager_0.method_56();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_59();
	}

	// Token: 0x06001EF8 RID: 7928 RVA: 0x00038FF8 File Offset: 0x000371F8
	[Address(RVA = "0x35E5394", Offset = "0x35E5394", VA = "0x35E5394")]
	[Token(Token = "0x6001EF8")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.name == "_Tint";
		this.lavaManager_0.method_56();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_50();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001EF9 RID: 7929 RVA: 0x00039070 File Offset: 0x00037270
	[Address(RVA = "0x35E56B4", Offset = "0x35E56B4", VA = "0x35E56B4")]
	[Token(Token = "0x6001EF9")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.name == "Right Hand";
		this.lavaManager_0.method_59();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_59();
	}

	// Token: 0x06001EFA RID: 7930 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x35E57EC", Offset = "0x35E57EC", VA = "0x35E57EC")]
	[Token(Token = "0x6001EFA")]
	public LavaKill()
	{
	}

	// Token: 0x06001EFB RID: 7931 RVA: 0x000390C8 File Offset: 0x000372C8
	[Address(RVA = "0x35E57F4", Offset = "0x35E57F4", VA = "0x35E57F4")]
	[Token(Token = "0x6001EFB")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.name == "FingerTip";
		this.lavaManager_0.method_50();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
	}

	// Token: 0x06001EFC RID: 7932 RVA: 0x0003912C File Offset: 0x0003732C
	[Address(RVA = "0x35E5B0C", Offset = "0x35E5B0C", VA = "0x35E5B0C")]
	[Token(Token = "0x6001EFC")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.name == "Skelechin";
		this.lavaManager_0.method_3();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_50();
	}

	// Token: 0x06001EFD RID: 7933 RVA: 0x00039184 File Offset: 0x00037384
	[Address(RVA = "0x35E5C44", Offset = "0x35E5C44", VA = "0x35E5C44")]
	[Token(Token = "0x6001EFD")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.name == "cosmos";
		this.lavaManager_0.method_14();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_1();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001EFE RID: 7934 RVA: 0x000391FC File Offset: 0x000373FC
	[Address(RVA = "0x35E6120", Offset = "0x35E6120", VA = "0x35E6120")]
	[Token(Token = "0x6001EFE")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.name == "TurnAmount";
		this.lavaManager_0.method_50();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_56();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001EFF RID: 7935 RVA: 0x00039274 File Offset: 0x00037474
	[Address(RVA = "0x35E625C", Offset = "0x35E625C", VA = "0x35E625C")]
	[Token(Token = "0x6001EFF")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.name == "_Tint";
		this.lavaManager_0.method_59();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_50();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F00 RID: 7936 RVA: 0x000392EC File Offset: 0x000374EC
	[Address(RVA = "0x35E6398", Offset = "0x35E6398", VA = "0x35E6398")]
	[Token(Token = "0x6001F00")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.name == "";
		this.lavaManager_0.method_30();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_50();
	}

	// Token: 0x06001F01 RID: 7937 RVA: 0x00039350 File Offset: 0x00037550
	[Address(RVA = "0x35E66B4", Offset = "0x35E66B4", VA = "0x35E66B4")]
	[Token(Token = "0x6001F01")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.name == "sound play play";
		this.lavaManager_0.method_59();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_1();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F02 RID: 7938 RVA: 0x000393C8 File Offset: 0x000375C8
	[Address(RVA = "0x35E67F0", Offset = "0x35E67F0", VA = "0x35E67F0")]
	[Token(Token = "0x6001F02")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.name == "Name Changing Error. Error: ";
		this.lavaManager_0.method_3();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_1();
	}

	// Token: 0x06001F03 RID: 7939 RVA: 0x0003942C File Offset: 0x0003762C
	[Address(RVA = "0x35E6928", Offset = "0x35E6928", VA = "0x35E6928")]
	[Token(Token = "0x6001F03")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.name == " and the correct version is ";
		this.lavaManager_0.method_3();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_14();
	}

	// Token: 0x06001F04 RID: 7940 RVA: 0x00039490 File Offset: 0x00037690
	[Address(RVA = "0x35E6A60", Offset = "0x35E6A60", VA = "0x35E6A60")]
	[Token(Token = "0x6001F04")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.name == "_Tint";
		this.lavaManager_0.method_30();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_30();
	}

	// Token: 0x06001F05 RID: 7941 RVA: 0x000394F4 File Offset: 0x000376F4
	[Address(RVA = "0x35E6B98", Offset = "0x35E6B98", VA = "0x35E6B98")]
	[Token(Token = "0x6001F05")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.name == "You have been banned for ";
		this.lavaManager_0.method_1();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_1();
	}

	// Token: 0x06001F06 RID: 7942 RVA: 0x0003954C File Offset: 0x0003774C
	[Address(RVA = "0x35E6CD4", Offset = "0x35E6CD4", VA = "0x35E6CD4")]
	[Token(Token = "0x6001F06")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.name == "Joined Public Room Successfully";
		this.lavaManager_0.method_59();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_50();
	}

	// Token: 0x06001F07 RID: 7943 RVA: 0x000395B0 File Offset: 0x000377B0
	[Address(RVA = "0x35E6E0C", Offset = "0x35E6E0C", VA = "0x35E6E0C")]
	[Token(Token = "0x6001F07")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.name == "Starting to bake textures on frame ";
		this.lavaManager_0.method_56();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_30();
	}

	// Token: 0x06001F08 RID: 7944 RVA: 0x00039614 File Offset: 0x00037814
	[Address(RVA = "0x35E6F44", Offset = "0x35E6F44", VA = "0x35E6F44")]
	[Token(Token = "0x6001F08")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.name == "FingerTip";
		this.lavaManager_0.method_3();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F09 RID: 7945 RVA: 0x0003968C File Offset: 0x0003788C
	[Address(RVA = "0x35E7080", Offset = "0x35E7080", VA = "0x35E7080")]
	[Token(Token = "0x6001F09")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.name == "{0} ({1})";
		this.lavaManager_0.method_3();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_14();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F0A RID: 7946 RVA: 0x00039704 File Offset: 0x00037904
	[Address(RVA = "0x35E71BC", Offset = "0x35E71BC", VA = "0x35E71BC")]
	[Token(Token = "0x6001F0A")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.name == "cosmos";
		this.lavaManager_0.method_56();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
	}

	// Token: 0x06001F0B RID: 7947 RVA: 0x00039768 File Offset: 0x00037968
	[Address(RVA = "0x35E72F4", Offset = "0x35E72F4", VA = "0x35E72F4")]
	[Token(Token = "0x6001F0B")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.name == "isLava";
		this.lavaManager_0.method_3();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
	}

	// Token: 0x06001F0C RID: 7948 RVA: 0x000397CC File Offset: 0x000379CC
	[Address(RVA = "0x35E742C", Offset = "0x35E742C", VA = "0x35E742C")]
	[Token(Token = "0x6001F0C")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.name == "";
		this.lavaManager_0.method_30();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_30();
	}

	// Token: 0x06001F0D RID: 7949 RVA: 0x00039830 File Offset: 0x00037A30
	[Address(RVA = "0x35E7564", Offset = "0x35E7564", VA = "0x35E7564")]
	[Token(Token = "0x6001F0D")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.name == ", ";
		this.lavaManager_0.method_30();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_14();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F0E RID: 7950 RVA: 0x000398A8 File Offset: 0x00037AA8
	[Address(RVA = "0x35E76A0", Offset = "0x35E76A0", VA = "0x35E76A0")]
	[Token(Token = "0x6001F0E")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.name == "{0}/{1:f0}";
		this.lavaManager_0.method_30();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.lavaManager_0.method_30();
	}

	// Token: 0x06001F0F RID: 7951 RVA: 0x00039908 File Offset: 0x00037B08
	[Address(RVA = "0x35E77D8", Offset = "0x35E77D8", VA = "0x35E77D8")]
	[Token(Token = "0x6001F0F")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.name == "Purchase For ";
		this.lavaManager_0.method_1();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_14();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F10 RID: 7952 RVA: 0x00039980 File Offset: 0x00037B80
	[Address(RVA = "0x35E7914", Offset = "0x35E7914", VA = "0x35E7914")]
	[Token(Token = "0x6001F10")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.name == "Did Hit";
		this.lavaManager_0.method_56();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F11 RID: 7953 RVA: 0x000399F8 File Offset: 0x00037BF8
	[Address(RVA = "0x35E7A50", Offset = "0x35E7A50", VA = "0x35E7A50")]
	[Token(Token = "0x6001F11")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.name == "Not connected to room";
		this.lavaManager_0.method_1();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_1();
	}

	// Token: 0x06001F12 RID: 7954 RVA: 0x00039A5C File Offset: 0x00037C5C
	[Address(RVA = "0x35E7B88", Offset = "0x35E7B88", VA = "0x35E7B88")]
	[Token(Token = "0x6001F12")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.name == "goDownRPC";
		this.lavaManager_0.method_3();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_59();
	}

	// Token: 0x06001F13 RID: 7955 RVA: 0x00039AC0 File Offset: 0x00037CC0
	[Address(RVA = "0x35E7CC4", Offset = "0x35E7CC4", VA = "0x35E7CC4")]
	[Token(Token = "0x6001F13")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.name == "Photon token acquired!";
		this.lavaManager_0.method_30();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F14 RID: 7956 RVA: 0x00039B38 File Offset: 0x00037D38
	[Address(RVA = "0x35E7E00", Offset = "0x35E7E00", VA = "0x35E7E00")]
	[Token(Token = "0x6001F14")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.name == "monke is not my monke";
		this.lavaManager_0.method_50();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F15 RID: 7957 RVA: 0x00039BA4 File Offset: 0x00037DA4
	[Address(RVA = "0x35E7F3C", Offset = "0x35E7F3C", VA = "0x35E7F3C")]
	[Token(Token = "0x6001F15")]
	public void OnTriggerEnter(Collider collider_0)
	{
		string name = collider_0.gameObject.name;
		this.lavaManager_0.method_59();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F16 RID: 7958 RVA: 0x00039C08 File Offset: 0x00037E08
	[Address(RVA = "0x35E8070", Offset = "0x35E8070", VA = "0x35E8070")]
	[Token(Token = "0x6001F16")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.name == "Display Name Changed!";
		this.lavaManager_0.method_59();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_30();
	}

	// Token: 0x06001F17 RID: 7959 RVA: 0x00039C6C File Offset: 0x00037E6C
	[Address(RVA = "0x35E81A8", Offset = "0x35E81A8", VA = "0x35E81A8")]
	[Token(Token = "0x6001F17")]
	public void method_31(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.name == "BN";
		this.lavaManager_0.method_30();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_14();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F18 RID: 7960 RVA: 0x00039CE0 File Offset: 0x00037EE0
	[Address(RVA = "0x35E82E4", Offset = "0x35E82E4", VA = "0x35E82E4")]
	[Token(Token = "0x6001F18")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.name == "INSIGNIFICANT CURRENCY";
		this.lavaManager_0.method_3();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_1();
	}

	// Token: 0x06001F19 RID: 7961 RVA: 0x00039D44 File Offset: 0x00037F44
	[Address(RVA = "0x35E841C", Offset = "0x35E841C", VA = "0x35E841C")]
	[Token(Token = "0x6001F19")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.name == "DisableCosmetic";
		this.lavaManager_0.method_3();
		Player.player_0.method_15();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_30();
	}

	// Token: 0x06001F1A RID: 7962 RVA: 0x00039DA8 File Offset: 0x00037FA8
	[Address(RVA = "0x35E8554", Offset = "0x35E8554", VA = "0x35E8554")]
	[Token(Token = "0x6001F1A")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.name == "false";
		this.lavaManager_0.method_59();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_2;
		Vector3 position2 = transform2.position;
		this.lavaManager_0.method_3();
		LavaManager lavaManager = this.lavaManager_0;
		long bool_ = 1L;
		lavaManager.bool_1 = (bool_ != 0L);
	}

	// Token: 0x06001F1B RID: 7963 RVA: 0x00039E20 File Offset: 0x00038020
	[Address(RVA = "0x35E8690", Offset = "0x35E8690", VA = "0x35E8690")]
	[Token(Token = "0x6001F1B")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.name == "DisableCosmetic";
		this.lavaManager_0.method_59();
		Player.player_0.method_20();
		Transform transform = this.transform_2;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_2.position;
		this.lavaManager_0.method_3();
	}

	// Token: 0x0400040F RID: 1039
	[Token(Token = "0x400040F")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x04000410 RID: 1040
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000410")]
	public Transform transform_1;

	// Token: 0x04000411 RID: 1041
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000411")]
	public Transform transform_2;

	// Token: 0x04000412 RID: 1042
	[Token(Token = "0x4000412")]
	[FieldOffset(Offset = "0x30")]
	public LavaManager lavaManager_0;

	// Token: 0x04000413 RID: 1043
	[Token(Token = "0x4000413")]
	[FieldOffset(Offset = "0x38")]
	public PhysicsHand[] physicsHand_0;

	// Token: 0x04000414 RID: 1044
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000414")]
	public Rigidbody rigidbody_0;

	// Token: 0x04000415 RID: 1045
	[Token(Token = "0x4000415")]
	[FieldOffset(Offset = "0x48")]
	public Rigidbody rigidbody_1;

	// Token: 0x04000416 RID: 1046
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000416")]
	public Rigidbody rigidbody_2;

	// Token: 0x04000417 RID: 1047
	[Token(Token = "0x4000417")]
	[FieldOffset(Offset = "0x58")]
	public Swimmy swimmy_0;
}
