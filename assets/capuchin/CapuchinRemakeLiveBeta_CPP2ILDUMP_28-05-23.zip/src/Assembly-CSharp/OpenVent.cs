﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200002D RID: 45
[Token(Token = "0x200002D")]
public class OpenVent : MonoBehaviour
{
	// Token: 0x0600057E RID: 1406 RVA: 0x0000F404 File Offset: 0x0000D604
	[Token(Token = "0x600057E")]
	[Address(RVA = "0x3458FF4", Offset = "0x3458FF4", VA = "0x3458FF4")]
	public void method_0()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x0000F404 File Offset: 0x0000D604
	[Address(RVA = "0x3459000", Offset = "0x3459000", VA = "0x3459000")]
	[Token(Token = "0x600057F")]
	public void method_1()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x0000F41C File Offset: 0x0000D61C
	[Token(Token = "0x6000580")]
	[Address(RVA = "0x345900C", Offset = "0x345900C", VA = "0x345900C")]
	private void method_2()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				AudioSource audioSource2 = this.audioSource_1;
				AudioClip clip2 = this.audioClip_1;
				audioSource2.PlayOneShot(clip2);
				return;
			}
		}
		else
		{
			float deltaTime2 = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource3 = this.audioSource_0;
				AudioClip clip3 = this.audioClip_0;
				audioSource3.PlayOneShot(clip3);
				AudioSource audioSource4 = this.audioSource_1;
				AudioClip clip4 = this.audioClip_1;
				audioSource4.PlayOneShot(clip4);
				long num = 1L;
				this.bool_3 = (num != 0L);
				return;
			}
		}
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x0000F4C0 File Offset: 0x0000D6C0
	[Address(RVA = "0x3459158", Offset = "0x3459158", VA = "0x3459158")]
	[Token(Token = "0x6000581")]
	private void Update()
	{
		float num = this.float_0;
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			return;
		}
		float deltaTime2 = Time.deltaTime;
		bool flag = this.bool_3;
		this.float_0 = num;
		if (flag)
		{
			AudioSource audioSource = this.audioSource_0;
			AudioClip clip = this.audioClip_0;
			audioSource.PlayOneShot(clip);
			AudioSource audioSource2 = this.audioSource_1;
			AudioClip clip2 = this.audioClip_1;
			audioSource2.PlayOneShot(clip2);
			return;
		}
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x0000F404 File Offset: 0x0000D604
	[Token(Token = "0x6000582")]
	[Address(RVA = "0x3459274", Offset = "0x3459274", VA = "0x3459274")]
	public void method_3()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000583")]
	[Address(RVA = "0x3459280", Offset = "0x3459280", VA = "0x3459280")]
	public void method_4()
	{
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x0000F404 File Offset: 0x0000D604
	[Address(RVA = "0x3459288", Offset = "0x3459288", VA = "0x3459288")]
	[Token(Token = "0x6000584")]
	public void method_5()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x0000F404 File Offset: 0x0000D604
	[Token(Token = "0x6000585")]
	[Address(RVA = "0x3459294", Offset = "0x3459294", VA = "0x3459294")]
	public void method_6()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x34592A0", Offset = "0x34592A0", VA = "0x34592A0")]
	[Token(Token = "0x6000586")]
	public void method_7()
	{
	}

	// Token: 0x06000587 RID: 1415 RVA: 0x0000F404 File Offset: 0x0000D604
	[Token(Token = "0x6000587")]
	[Address(RVA = "0x34592A8", Offset = "0x34592A8", VA = "0x34592A8")]
	public void method_8()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x06000588 RID: 1416 RVA: 0x0000F530 File Offset: 0x0000D730
	[Token(Token = "0x6000588")]
	[Address(RVA = "0x34592B4", Offset = "0x34592B4", VA = "0x34592B4")]
	public OpenVent()
	{
		long num = 1L;
		this.bool_3 = (num != 0L);
		base..ctor();
	}

	// Token: 0x06000589 RID: 1417 RVA: 0x0000F41C File Offset: 0x0000D61C
	[Token(Token = "0x6000589")]
	[Address(RVA = "0x34592C4", Offset = "0x34592C4", VA = "0x34592C4")]
	private void method_9()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				AudioSource audioSource2 = this.audioSource_1;
				AudioClip clip2 = this.audioClip_1;
				audioSource2.PlayOneShot(clip2);
				return;
			}
		}
		else
		{
			float deltaTime2 = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource3 = this.audioSource_0;
				AudioClip clip3 = this.audioClip_0;
				audioSource3.PlayOneShot(clip3);
				AudioSource audioSource4 = this.audioSource_1;
				AudioClip clip4 = this.audioClip_1;
				audioSource4.PlayOneShot(clip4);
				long num = 1L;
				this.bool_3 = (num != 0L);
				return;
			}
		}
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x0000F404 File Offset: 0x0000D604
	[Address(RVA = "0x3459410", Offset = "0x3459410", VA = "0x3459410")]
	[Token(Token = "0x600058A")]
	public void method_10()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x0000F54C File Offset: 0x0000D74C
	[Address(RVA = "0x345941C", Offset = "0x345941C", VA = "0x345941C")]
	[Token(Token = "0x600058B")]
	private void method_11()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			return;
		}
		float deltaTime2 = Time.deltaTime;
		if (this.bool_3)
		{
			AudioSource audioSource = this.audioSource_0;
			AudioClip clip = this.audioClip_0;
			audioSource.PlayOneShot(clip);
			AudioSource audioSource2 = this.audioSource_1;
			AudioClip clip2 = this.audioClip_1;
			audioSource2.PlayOneShot(clip2);
			long num = 1L;
			this.bool_3 = (num != 0L);
			return;
		}
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x0000F404 File Offset: 0x0000D604
	[Address(RVA = "0x3459538", Offset = "0x3459538", VA = "0x3459538")]
	[Token(Token = "0x600058C")]
	public void method_12()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0000F5B4 File Offset: 0x0000D7B4
	[Address(RVA = "0x3459544", Offset = "0x3459544", VA = "0x3459544")]
	[Token(Token = "0x600058D")]
	private void method_13()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			return;
		}
		float deltaTime2 = Time.deltaTime;
		if (this.bool_3)
		{
			AudioSource audioSource = this.audioSource_0;
			AudioClip clip = this.audioClip_0;
			audioSource.PlayOneShot(clip);
			AudioSource audioSource2 = this.audioSource_1;
			AudioClip clip2 = this.audioClip_1;
			audioSource2.PlayOneShot(clip2);
			return;
		}
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600058E")]
	[Address(RVA = "0x3459660", Offset = "0x3459660", VA = "0x3459660")]
	public void method_14()
	{
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600058F")]
	[Address(RVA = "0x3459668", Offset = "0x3459668", VA = "0x3459668")]
	public void method_15()
	{
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3459670", Offset = "0x3459670", VA = "0x3459670")]
	[Token(Token = "0x6000590")]
	public void method_16()
	{
	}

	// Token: 0x06000591 RID: 1425 RVA: 0x0000F41C File Offset: 0x0000D61C
	[Address(RVA = "0x3459678", Offset = "0x3459678", VA = "0x3459678")]
	[Token(Token = "0x6000591")]
	private void method_17()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				AudioSource audioSource2 = this.audioSource_1;
				AudioClip clip2 = this.audioClip_1;
				audioSource2.PlayOneShot(clip2);
				return;
			}
		}
		else
		{
			float deltaTime2 = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource3 = this.audioSource_0;
				AudioClip clip3 = this.audioClip_0;
				audioSource3.PlayOneShot(clip3);
				AudioSource audioSource4 = this.audioSource_1;
				AudioClip clip4 = this.audioClip_1;
				audioSource4.PlayOneShot(clip4);
				long num = 1L;
				this.bool_3 = (num != 0L);
				return;
			}
		}
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000592")]
	[Address(RVA = "0x34597C4", Offset = "0x34597C4", VA = "0x34597C4")]
	public void method_18()
	{
	}

	// Token: 0x06000593 RID: 1427 RVA: 0x0000F614 File Offset: 0x0000D814
	[Token(Token = "0x6000593")]
	[Address(RVA = "0x34597CC", Offset = "0x34597CC", VA = "0x34597CC")]
	private void method_19()
	{
		if (this.bool_2)
		{
			float deltaTime = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource = this.audioSource_0;
				AudioClip clip = this.audioClip_0;
				audioSource.PlayOneShot(clip);
				AudioSource audioSource2 = this.audioSource_1;
				AudioClip clip2 = this.audioClip_1;
				audioSource2.PlayOneShot(clip2);
				long num = 1L;
				this.bool_3 = (num != 0L);
				return;
			}
		}
		else
		{
			float deltaTime2 = Time.deltaTime;
			if (this.bool_3)
			{
				AudioSource audioSource3 = this.audioSource_0;
				AudioClip clip3 = this.audioClip_0;
				audioSource3.PlayOneShot(clip3);
				AudioSource audioSource4 = this.audioSource_1;
				AudioClip clip4 = this.audioClip_1;
				audioSource4.PlayOneShot(clip4);
			}
		}
	}

	// Token: 0x06000594 RID: 1428 RVA: 0x0000F404 File Offset: 0x0000D604
	[Address(RVA = "0x3459914", Offset = "0x3459914", VA = "0x3459914")]
	[Token(Token = "0x6000594")]
	public void method_20()
	{
		long num = 1L;
		this.bool_2 = (num != 0L);
	}

	// Token: 0x040000CD RID: 205
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40000CD")]
	public Transform transform_0;

	// Token: 0x040000CE RID: 206
	[Token(Token = "0x40000CE")]
	[FieldOffset(Offset = "0x20")]
	public Vector3 vector3_0;

	// Token: 0x040000CF RID: 207
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x40000CF")]
	public Vector3 vector3_1;

	// Token: 0x040000D0 RID: 208
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40000D0")]
	public bool bool_0;

	// Token: 0x040000D1 RID: 209
	[Token(Token = "0x40000D1")]
	[FieldOffset(Offset = "0x39")]
	public bool bool_1;

	// Token: 0x040000D2 RID: 210
	[Token(Token = "0x40000D2")]
	[FieldOffset(Offset = "0x3C")]
	public float float_0;

	// Token: 0x040000D3 RID: 211
	[Token(Token = "0x40000D3")]
	[FieldOffset(Offset = "0x40")]
	public bool bool_2;

	// Token: 0x040000D4 RID: 212
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x40000D4")]
	public float float_1;

	// Token: 0x040000D5 RID: 213
	[Token(Token = "0x40000D5")]
	[FieldOffset(Offset = "0x48")]
	public AudioSource audioSource_0;

	// Token: 0x040000D6 RID: 214
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40000D6")]
	public AudioClip audioClip_0;

	// Token: 0x040000D7 RID: 215
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40000D7")]
	private bool bool_3;

	// Token: 0x040000D8 RID: 216
	[Token(Token = "0x40000D8")]
	[FieldOffset(Offset = "0x59")]
	public bool bool_4;

	// Token: 0x040000D9 RID: 217
	[Token(Token = "0x40000D9")]
	[FieldOffset(Offset = "0x60")]
	public AudioSource audioSource_1;

	// Token: 0x040000DA RID: 218
	[Token(Token = "0x40000DA")]
	[FieldOffset(Offset = "0x68")]
	public AudioClip audioClip_1;
}
