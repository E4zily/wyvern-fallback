﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Networking;

// Token: 0x020000D0 RID: 208
[Token(Token = "0x20000D0")]
public class ImageDownloader : MonoBehaviour
{
	// Token: 0x06001E03 RID: 7683 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3387EB8", Offset = "0x3387EB8", VA = "0x3387EB8")]
	[Token(Token = "0x6001E03")]
	private IEnumerator method_0()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E04 RID: 7684 RVA: 0x000386D0 File Offset: 0x000368D0
	[Address(RVA = "0x3387F30", Offset = "0x3387F30", VA = "0x3387F30")]
	[Token(Token = "0x6001E04")]
	private UnityWebRequest method_1()
	{
		return "Add/Remove Sword";
	}

	// Token: 0x06001E05 RID: 7685 RVA: 0x000386E4 File Offset: 0x000368E4
	[Address(RVA = "0x3388278", Offset = "0x3388278", VA = "0x3388278")]
	[Token(Token = "0x6001E05")]
	private void method_2()
	{
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E06 RID: 7686 RVA: 0x00038700 File Offset: 0x00036900
	[Address(RVA = "0x338831C", Offset = "0x338831C", VA = "0x338831C")]
	[Token(Token = "0x6001E06")]
	private UnityWebRequest method_3()
	{
		return "/";
	}

	// Token: 0x06001E07 RID: 7687 RVA: 0x00038714 File Offset: 0x00036914
	[Address(RVA = "0x3388658", Offset = "0x3388658", VA = "0x3388658")]
	[Token(Token = "0x6001E07")]
	private void method_4()
	{
		IEnumerator routine = this.method_8();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E08 RID: 7688 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x33886FC", Offset = "0x33886FC", VA = "0x33886FC")]
	[Token(Token = "0x6001E08")]
	private IEnumerator method_5()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E09 RID: 7689 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3388774", Offset = "0x3388774", VA = "0x3388774")]
	[Token(Token = "0x6001E09")]
	private IEnumerator method_6()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E0A RID: 7690 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x33887EC", Offset = "0x33887EC", VA = "0x33887EC")]
	[Token(Token = "0x6001E0A")]
	private IEnumerator method_7()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E0B RID: 7691 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3388684", Offset = "0x3388684", VA = "0x3388684")]
	[Token(Token = "0x6001E0B")]
	private IEnumerator method_8()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E0C RID: 7692 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3388864", Offset = "0x3388864", VA = "0x3388864")]
	[Token(Token = "0x6001E0C")]
	private IEnumerator method_9()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E0D RID: 7693 RVA: 0x00038730 File Offset: 0x00036930
	[Address(RVA = "0x33888DC", Offset = "0x33888DC", VA = "0x33888DC")]
	[Token(Token = "0x6001E0D")]
	private UnityWebRequest method_10()
	{
		return "\n";
	}

	// Token: 0x06001E0E RID: 7694 RVA: 0x00038744 File Offset: 0x00036944
	[Address(RVA = "0x3388C0C", Offset = "0x3388C0C", VA = "0x3388C0C")]
	[Token(Token = "0x6001E0E")]
	private UnityWebRequest method_11()
	{
		return "Agreed";
	}

	// Token: 0x06001E0F RID: 7695 RVA: 0x00038758 File Offset: 0x00036958
	[Address(RVA = "0x3388F34", Offset = "0x3388F34", VA = "0x3388F34")]
	[Token(Token = "0x6001E0F")]
	private UnityWebRequest method_12()
	{
		return "NetworkPlayer";
	}

	// Token: 0x06001E10 RID: 7696 RVA: 0x0003876C File Offset: 0x0003696C
	[Address(RVA = "0x3389274", Offset = "0x3389274", VA = "0x3389274")]
	[Token(Token = "0x6001E10")]
	private UnityWebRequest method_13()
	{
		return "typesOfTalk";
	}

	// Token: 0x06001E11 RID: 7697 RVA: 0x00038780 File Offset: 0x00036980
	[Address(RVA = "0x3389598", Offset = "0x3389598", VA = "0x3389598")]
	[Token(Token = "0x6001E11")]
	private UnityWebRequest method_14()
	{
		return " ";
	}

	// Token: 0x06001E12 RID: 7698 RVA: 0x00038794 File Offset: 0x00036994
	[Address(RVA = "0x33898CC", Offset = "0x33898CC", VA = "0x33898CC")]
	[Token(Token = "0x6001E12")]
	private void method_15()
	{
		IEnumerator routine = this.method_18();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E13 RID: 7699 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3389970", Offset = "0x3389970", VA = "0x3389970")]
	[Token(Token = "0x6001E13")]
	private IEnumerator method_16()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E14 RID: 7700 RVA: 0x000387B0 File Offset: 0x000369B0
	[Address(RVA = "0x33899E8", Offset = "0x33899E8", VA = "0x33899E8")]
	[Token(Token = "0x6001E14")]
	private UnityWebRequest method_17()
	{
		return "gameMode";
	}

	// Token: 0x06001E15 RID: 7701 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x33898F8", Offset = "0x33898F8", VA = "0x33898F8")]
	[Token(Token = "0x6001E15")]
	private IEnumerator method_18()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E16 RID: 7702 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3389D18", Offset = "0x3389D18", VA = "0x3389D18")]
	[Token(Token = "0x6001E16")]
	private IEnumerator method_19()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E17 RID: 7703 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3389D90", Offset = "0x3389D90", VA = "0x3389D90")]
	[Token(Token = "0x6001E17")]
	private IEnumerator method_20()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E18 RID: 7704 RVA: 0x000387C4 File Offset: 0x000369C4
	[Address(RVA = "0x3389E08", Offset = "0x3389E08", VA = "0x3389E08")]
	[Token(Token = "0x6001E18")]
	private void method_21()
	{
		IEnumerator routine = this.method_84();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E19 RID: 7705 RVA: 0x000387E0 File Offset: 0x000369E0
	[Address(RVA = "0x3389EAC", Offset = "0x3389EAC", VA = "0x3389EAC")]
	[Token(Token = "0x6001E19")]
	private UnityWebRequest method_22()
	{
		return "A new Player joined a Room.";
	}

	// Token: 0x06001E1A RID: 7706 RVA: 0x000387F4 File Offset: 0x000369F4
	[Address(RVA = "0x338A1E4", Offset = "0x338A1E4", VA = "0x338A1E4")]
	[Token(Token = "0x6001E1A")]
	private UnityWebRequest method_23()
	{
		return "username";
	}

	// Token: 0x06001E1B RID: 7707 RVA: 0x00038808 File Offset: 0x00036A08
	[Address(RVA = "0x338A50C", Offset = "0x338A50C", VA = "0x338A50C")]
	[Token(Token = "0x6001E1B")]
	private UnityWebRequest method_24()
	{
		return "Player";
	}

	// Token: 0x06001E1C RID: 7708 RVA: 0x0003881C File Offset: 0x00036A1C
	[Address(RVA = "0x338A844", Offset = "0x338A844", VA = "0x338A844")]
	[Token(Token = "0x6001E1C")]
	private UnityWebRequest method_25()
	{
		return "_Tint";
	}

	// Token: 0x06001E1D RID: 7709 RVA: 0x00038830 File Offset: 0x00036A30
	[Address(RVA = "0x338AB84", Offset = "0x338AB84", VA = "0x338AB84")]
	[Token(Token = "0x6001E1D")]
	private UnityWebRequest method_26()
	{
		return "typesOfTalk";
	}

	// Token: 0x06001E1E RID: 7710 RVA: 0x00038844 File Offset: 0x00036A44
	[Address(RVA = "0x338AEBC", Offset = "0x338AEBC", VA = "0x338AEBC")]
	[Token(Token = "0x6001E1E")]
	private UnityWebRequest method_27()
	{
		return "openvr";
	}

	// Token: 0x06001E1F RID: 7711 RVA: 0x00038858 File Offset: 0x00036A58
	[Address(RVA = "0x338B1F8", Offset = "0x338B1F8", VA = "0x338B1F8")]
	[Token(Token = "0x6001E1F")]
	private void method_28()
	{
		IEnumerator routine = this.method_9();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E20 RID: 7712 RVA: 0x00038858 File Offset: 0x00036A58
	[Address(RVA = "0x338B224", Offset = "0x338B224", VA = "0x338B224")]
	[Token(Token = "0x6001E20")]
	private void method_29()
	{
		IEnumerator routine = this.method_9();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E21 RID: 7713 RVA: 0x00038808 File Offset: 0x00036A08
	[Address(RVA = "0x338B250", Offset = "0x338B250", VA = "0x338B250")]
	[Token(Token = "0x6001E21")]
	private UnityWebRequest method_30()
	{
		return "Player";
	}

	// Token: 0x06001E22 RID: 7714 RVA: 0x00038858 File Offset: 0x00036A58
	[Address(RVA = "0x338B590", Offset = "0x338B590", VA = "0x338B590")]
	[Token(Token = "0x6001E22")]
	private void method_31()
	{
		IEnumerator routine = this.method_9();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E23 RID: 7715 RVA: 0x00038874 File Offset: 0x00036A74
	[Address(RVA = "0x338B5BC", Offset = "0x338B5BC", VA = "0x338B5BC")]
	[Token(Token = "0x6001E23")]
	private UnityWebRequest method_32()
	{
		return "Mesh";
	}

	// Token: 0x06001E24 RID: 7716 RVA: 0x00038888 File Offset: 0x00036A88
	[Address(RVA = "0x338B8F8", Offset = "0x338B8F8", VA = "0x338B8F8")]
	[Token(Token = "0x6001E24")]
	private void method_33()
	{
		IEnumerator routine = this.method_87();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E25 RID: 7717 RVA: 0x000388A4 File Offset: 0x00036AA4
	[Address(RVA = "0x338B99C", Offset = "0x338B99C", VA = "0x338B99C")]
	[Token(Token = "0x6001E25")]
	private void method_34()
	{
		IEnumerator routine = this.method_89();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E26 RID: 7718 RVA: 0x000388C0 File Offset: 0x00036AC0
	[Address(RVA = "0x338BA40", Offset = "0x338BA40", VA = "0x338BA40")]
	[Token(Token = "0x6001E26")]
	private UnityWebRequest method_35()
	{
		return "Done";
	}

	// Token: 0x06001E27 RID: 7719 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338BD74", Offset = "0x338BD74", VA = "0x338BD74")]
	[Token(Token = "0x6001E27")]
	private IEnumerator method_36()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E28 RID: 7720 RVA: 0x000388D4 File Offset: 0x00036AD4
	[Address(RVA = "0x338BDEC", Offset = "0x338BDEC", VA = "0x338BDEC")]
	[Token(Token = "0x6001E28")]
	private UnityWebRequest method_37()
	{
		return "Tagged";
	}

	// Token: 0x06001E29 RID: 7721 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x33882A4", Offset = "0x33882A4", VA = "0x33882A4")]
	[Token(Token = "0x6001E29")]
	private IEnumerator method_38()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E2A RID: 7722 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338C130", Offset = "0x338C130", VA = "0x338C130")]
	[Token(Token = "0x6001E2A")]
	private IEnumerator method_39()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E2B RID: 7723 RVA: 0x000388E8 File Offset: 0x00036AE8
	[Address(RVA = "0x338C1A8", Offset = "0x338C1A8", VA = "0x338C1A8")]
	[Token(Token = "0x6001E2B")]
	private UnityWebRequest method_40()
	{
		return "M/d/yyyy";
	}

	// Token: 0x06001E2C RID: 7724 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338C4E4", Offset = "0x338C4E4", VA = "0x338C4E4")]
	[Token(Token = "0x6001E2C")]
	private IEnumerator method_41()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E2D RID: 7725 RVA: 0x000388FC File Offset: 0x00036AFC
	[Address(RVA = "0x338C55C", Offset = "0x338C55C", VA = "0x338C55C")]
	[Token(Token = "0x6001E2D")]
	private void method_42()
	{
		IEnumerator routine = this.method_55();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E2E RID: 7726 RVA: 0x00038918 File Offset: 0x00036B18
	[Address(RVA = "0x338C600", Offset = "0x338C600", VA = "0x338C600")]
	[Token(Token = "0x6001E2E")]
	private UnityWebRequest method_43()
	{
		return "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:";
	}

	// Token: 0x06001E2F RID: 7727 RVA: 0x0003892C File Offset: 0x00036B2C
	[Address(RVA = "0x338C938", Offset = "0x338C938", VA = "0x338C938")]
	[Token(Token = "0x6001E2F")]
	private UnityWebRequest method_44()
	{
		return "https://raw.githubusercontent.com/";
	}

	// Token: 0x06001E30 RID: 7728 RVA: 0x00038940 File Offset: 0x00036B40
	[Address(RVA = "0x338CC40", Offset = "0x338CC40", VA = "0x338CC40")]
	[Token(Token = "0x6001E30")]
	private void method_45()
	{
		IEnumerator routine = this.method_61();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E31 RID: 7729 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338CCE4", Offset = "0x338CCE4", VA = "0x338CCE4")]
	[Token(Token = "0x6001E31")]
	private IEnumerator method_46()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E32 RID: 7730 RVA: 0x0003895C File Offset: 0x00036B5C
	[Address(RVA = "0x338CD5C", Offset = "0x338CD5C", VA = "0x338CD5C")]
	[Token(Token = "0x6001E32")]
	private UnityWebRequest method_47()
	{
		return "tutorialCheck";
	}

	// Token: 0x06001E33 RID: 7731 RVA: 0x00038758 File Offset: 0x00036958
	[Address(RVA = "0x338D098", Offset = "0x338D098", VA = "0x338D098")]
	[Token(Token = "0x6001E33")]
	private UnityWebRequest method_48()
	{
		return "NetworkPlayer";
	}

	// Token: 0x06001E34 RID: 7732 RVA: 0x00038970 File Offset: 0x00036B70
	[Address(RVA = "0x338D3CC", Offset = "0x338D3CC", VA = "0x338D3CC")]
	[Token(Token = "0x6001E34")]
	private UnityWebRequest method_49()
	{
		return "ChangePlayerSize";
	}

	// Token: 0x06001E35 RID: 7733 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338D6F4", Offset = "0x338D6F4", VA = "0x338D6F4")]
	[Token(Token = "0x6001E35")]
	private IEnumerator method_50()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E36 RID: 7734 RVA: 0x00038984 File Offset: 0x00036B84
	[Address(RVA = "0x338D76C", Offset = "0x338D76C", VA = "0x338D76C")]
	[Token(Token = "0x6001E36")]
	private UnityWebRequest method_51()
	{
		return "DISABLE";
	}

	// Token: 0x06001E37 RID: 7735 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338DAA4", Offset = "0x338DAA4", VA = "0x338DAA4")]
	[Token(Token = "0x6001E37")]
	private IEnumerator method_52()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E38 RID: 7736 RVA: 0x0003876C File Offset: 0x0003696C
	[Address(RVA = "0x338DB1C", Offset = "0x338DB1C", VA = "0x338DB1C")]
	[Token(Token = "0x6001E38")]
	private UnityWebRequest method_53()
	{
		return "typesOfTalk";
	}

	// Token: 0x06001E39 RID: 7737 RVA: 0x00038998 File Offset: 0x00036B98
	[Address(RVA = "0x338DE50", Offset = "0x338DE50", VA = "0x338DE50")]
	[Token(Token = "0x6001E39")]
	private UnityWebRequest method_54()
	{
		return "Hats";
	}

	// Token: 0x06001E3A RID: 7738 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338C588", Offset = "0x338C588", VA = "0x338C588")]
	[Token(Token = "0x6001E3A")]
	private IEnumerator method_55()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E3B RID: 7739 RVA: 0x000389AC File Offset: 0x00036BAC
	[Address(RVA = "0x338E190", Offset = "0x338E190", VA = "0x338E190")]
	[Token(Token = "0x6001E3B")]
	private UnityWebRequest method_56()
	{
		return "MetaAuth";
	}

	// Token: 0x06001E3C RID: 7740 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338E4C4", Offset = "0x338E4C4", VA = "0x338E4C4")]
	[Token(Token = "0x6001E3C")]
	private IEnumerator method_57()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E3D RID: 7741 RVA: 0x00038940 File Offset: 0x00036B40
	[Address(RVA = "0x338E53C", Offset = "0x338E53C", VA = "0x338E53C")]
	[Token(Token = "0x6001E3D")]
	private void method_58()
	{
		IEnumerator routine = this.method_61();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E3E RID: 7742 RVA: 0x000389C0 File Offset: 0x00036BC0
	[Address(RVA = "0x338E568", Offset = "0x338E568", VA = "0x338E568")]
	[Token(Token = "0x6001E3E")]
	private void method_59()
	{
		IEnumerator routine = this.method_64();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E3F RID: 7743 RVA: 0x000388FC File Offset: 0x00036AFC
	[Address(RVA = "0x338E60C", Offset = "0x338E60C", VA = "0x338E60C")]
	[Token(Token = "0x6001E3F")]
	private void Awake()
	{
		IEnumerator routine = this.method_55();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E40 RID: 7744 RVA: 0x00038794 File Offset: 0x00036994
	[Address(RVA = "0x338E638", Offset = "0x338E638", VA = "0x338E638")]
	[Token(Token = "0x6001E40")]
	private void method_60()
	{
		IEnumerator routine = this.method_18();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E41 RID: 7745 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338CC6C", Offset = "0x338CC6C", VA = "0x338CC6C")]
	[Token(Token = "0x6001E41")]
	private IEnumerator method_61()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E42 RID: 7746 RVA: 0x000389DC File Offset: 0x00036BDC
	[Address(RVA = "0x338E664", Offset = "0x338E664", VA = "0x338E664")]
	[Token(Token = "0x6001E42")]
	private void method_62()
	{
		IEnumerator routine = this.method_66();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E43 RID: 7747 RVA: 0x000389F8 File Offset: 0x00036BF8
	[Address(RVA = "0x338E708", Offset = "0x338E708", VA = "0x338E708")]
	[Token(Token = "0x6001E43")]
	private UnityWebRequest method_63()
	{
		return "Downloading image";
	}

	// Token: 0x06001E44 RID: 7748 RVA: 0x00002A12 File Offset: 0x00000C12
	[Address(RVA = "0x338EA4C", Offset = "0x338EA4C", VA = "0x338EA4C")]
	[Token(Token = "0x6001E44")]
	public ImageDownloader()
	{
	}

	// Token: 0x06001E45 RID: 7749 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338E594", Offset = "0x338E594", VA = "0x338E594")]
	[Token(Token = "0x6001E45")]
	private IEnumerator method_64()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E46 RID: 7750 RVA: 0x00038A0C File Offset: 0x00036C0C
	[Address(RVA = "0x338EB1C", Offset = "0x338EB1C", VA = "0x338EB1C")]
	[Token(Token = "0x6001E46")]
	private UnityWebRequest method_65()
	{
		return "got funky mone";
	}

	// Token: 0x06001E47 RID: 7751 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338E690", Offset = "0x338E690", VA = "0x338E690")]
	[Token(Token = "0x6001E47")]
	private IEnumerator method_66()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E48 RID: 7752 RVA: 0x00038A20 File Offset: 0x00036C20
	[Address(RVA = "0x338EE44", Offset = "0x338EE44", VA = "0x338EE44")]
	[Token(Token = "0x6001E48")]
	private void method_67()
	{
		IEnumerator routine = this.method_52();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E49 RID: 7753 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338EE70", Offset = "0x338EE70", VA = "0x338EE70")]
	[Token(Token = "0x6001E49")]
	private IEnumerator method_68()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E4A RID: 7754 RVA: 0x00038A3C File Offset: 0x00036C3C
	[Address(RVA = "0x338EEE8", Offset = "0x338EEE8", VA = "0x338EEE8")]
	[Token(Token = "0x6001E4A")]
	private void method_69()
	{
		IEnumerator routine = this.method_57();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E4B RID: 7755 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338EF14", Offset = "0x338EF14", VA = "0x338EF14")]
	[Token(Token = "0x6001E4B")]
	private IEnumerator method_70()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E4C RID: 7756 RVA: 0x00038A58 File Offset: 0x00036C58
	[Address(RVA = "0x338EF8C", Offset = "0x338EF8C", VA = "0x338EF8C")]
	[Token(Token = "0x6001E4C")]
	private UnityWebRequest method_71()
	{
		return "PlayWave";
	}

	// Token: 0x06001E4D RID: 7757 RVA: 0x00038A6C File Offset: 0x00036C6C
	[Address(RVA = "0x338F2CC", Offset = "0x338F2CC", VA = "0x338F2CC")]
	[Token(Token = "0x6001E4D")]
	private void method_72()
	{
		IEnumerator routine = this.method_103();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E4E RID: 7758 RVA: 0x00038A88 File Offset: 0x00036C88
	[Address(RVA = "0x338F370", Offset = "0x338F370", VA = "0x338F370")]
	[Token(Token = "0x6001E4E")]
	private void method_73()
	{
		IEnumerator routine = this.method_7();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E4F RID: 7759 RVA: 0x00038AA4 File Offset: 0x00036CA4
	[Address(RVA = "0x338F39C", Offset = "0x338F39C", VA = "0x338F39C")]
	[Token(Token = "0x6001E4F")]
	private UnityWebRequest method_74()
	{
		return "User is on an outdated version of Capuchin. Your version is ";
	}

	// Token: 0x06001E50 RID: 7760 RVA: 0x00038AB8 File Offset: 0x00036CB8
	[Address(RVA = "0x338F6D0", Offset = "0x338F6D0", VA = "0x338F6D0")]
	[Token(Token = "0x6001E50")]
	private void method_75()
	{
		IEnumerator routine = this.method_76();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E51 RID: 7761 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338F6FC", Offset = "0x338F6FC", VA = "0x338F6FC")]
	[Token(Token = "0x6001E51")]
	private IEnumerator method_76()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E52 RID: 7762 RVA: 0x00038AD4 File Offset: 0x00036CD4
	[Address(RVA = "0x338F774", Offset = "0x338F774", VA = "0x338F774")]
	[Token(Token = "0x6001E52")]
	private void method_77()
	{
		IEnumerator routine = this.method_50();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E53 RID: 7763 RVA: 0x00038794 File Offset: 0x00036994
	[Address(RVA = "0x338F7A0", Offset = "0x338F7A0", VA = "0x338F7A0")]
	[Token(Token = "0x6001E53")]
	private void method_78()
	{
		IEnumerator routine = this.method_18();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E54 RID: 7764 RVA: 0x00038AF0 File Offset: 0x00036CF0
	[Address(RVA = "0x338F7CC", Offset = "0x338F7CC", VA = "0x338F7CC")]
	[Token(Token = "0x6001E54")]
	private UnityWebRequest method_79()
	{
		return "META";
	}

	// Token: 0x06001E55 RID: 7765 RVA: 0x00038B04 File Offset: 0x00036D04
	[Address(RVA = "0x338FB00", Offset = "0x338FB00", VA = "0x338FB00")]
	[Token(Token = "0x6001E55")]
	private UnityWebRequest method_80()
	{
		return "Trigger";
	}

	// Token: 0x06001E56 RID: 7766 RVA: 0x00038858 File Offset: 0x00036A58
	[Address(RVA = "0x338FE38", Offset = "0x338FE38", VA = "0x338FE38")]
	[Token(Token = "0x6001E56")]
	private void method_81()
	{
		IEnumerator routine = this.method_9();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E57 RID: 7767 RVA: 0x00038B18 File Offset: 0x00036D18
	[Address(RVA = "0x338FE64", Offset = "0x338FE64", VA = "0x338FE64")]
	[Token(Token = "0x6001E57")]
	private UnityWebRequest method_82()
	{
		string text = this.string_0;
		if (text != null && text == null)
		{
			throw new ArrayTypeMismatchException();
		}
		return ". Please update you game to the latest version";
	}

	// Token: 0x06001E58 RID: 7768 RVA: 0x00038B40 File Offset: 0x00036D40
	[Address(RVA = "0x33901A0", Offset = "0x33901A0", VA = "0x33901A0")]
	[Token(Token = "0x6001E58")]
	private UnityWebRequest method_83()
	{
		return "Time to bake textures: ";
	}

	// Token: 0x06001E59 RID: 7769 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3389E34", Offset = "0x3389E34", VA = "0x3389E34")]
	[Token(Token = "0x6001E59")]
	private IEnumerator method_84()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E5A RID: 7770 RVA: 0x00038B54 File Offset: 0x00036D54
	[Address(RVA = "0x33904E0", Offset = "0x33904E0", VA = "0x33904E0")]
	[Token(Token = "0x6001E5A")]
	private void method_85()
	{
		IEnumerator routine = this.method_101();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E5B RID: 7771 RVA: 0x00038B70 File Offset: 0x00036D70
	[Address(RVA = "0x3390584", Offset = "0x3390584", VA = "0x3390584")]
	[Token(Token = "0x6001E5B")]
	private UnityWebRequest method_86()
	{
		return "ChangeMaterialToNormal";
	}

	// Token: 0x06001E5C RID: 7772 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338B924", Offset = "0x338B924", VA = "0x338B924")]
	[Token(Token = "0x6001E5C")]
	private IEnumerator method_87()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E5D RID: 7773 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x33908C0", Offset = "0x33908C0", VA = "0x33908C0")]
	[Token(Token = "0x6001E5D")]
	private IEnumerator method_88()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E5E RID: 7774 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338B9C8", Offset = "0x338B9C8", VA = "0x338B9C8")]
	[Token(Token = "0x6001E5E")]
	private IEnumerator method_89()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E5F RID: 7775 RVA: 0x00038B84 File Offset: 0x00036D84
	[Address(RVA = "0x3390938", Offset = "0x3390938", VA = "0x3390938")]
	[Token(Token = "0x6001E5F")]
	private void method_90()
	{
		IEnumerator routine = this.method_36();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E60 RID: 7776 RVA: 0x00038BA0 File Offset: 0x00036DA0
	[Address(RVA = "0x3390964", Offset = "0x3390964", VA = "0x3390964")]
	[Token(Token = "0x6001E60")]
	private void method_91()
	{
		IEnumerator routine = this.method_88();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E61 RID: 7777 RVA: 0x00038700 File Offset: 0x00036900
	[Address(RVA = "0x3390990", Offset = "0x3390990", VA = "0x3390990")]
	[Token(Token = "0x6001E61")]
	private UnityWebRequest method_92()
	{
		return "/";
	}

	// Token: 0x06001E62 RID: 7778 RVA: 0x00038BBC File Offset: 0x00036DBC
	[Address(RVA = "0x3390CD0", Offset = "0x3390CD0", VA = "0x3390CD0")]
	[Token(Token = "0x6001E62")]
	private UnityWebRequest method_93()
	{
		return "Damaged Arm";
	}

	// Token: 0x06001E63 RID: 7779 RVA: 0x00038BD0 File Offset: 0x00036DD0
	[Address(RVA = "0x339100C", Offset = "0x339100C", VA = "0x339100C")]
	[Token(Token = "0x6001E63")]
	private UnityWebRequest method_94()
	{
		return "Charged!";
	}

	// Token: 0x06001E64 RID: 7780 RVA: 0x00038BE4 File Offset: 0x00036DE4
	[Address(RVA = "0x339134C", Offset = "0x339134C", VA = "0x339134C")]
	[Token(Token = "0x6001E64")]
	private void method_95()
	{
		IEnumerator routine = this.method_6();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E65 RID: 7781 RVA: 0x00038C00 File Offset: 0x00036E00
	[Address(RVA = "0x3391378", Offset = "0x3391378", VA = "0x3391378")]
	[Token(Token = "0x6001E65")]
	private void method_96()
	{
		IEnumerator routine = this.method_5();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E66 RID: 7782 RVA: 0x00038C1C File Offset: 0x00036E1C
	[Address(RVA = "0x33913A4", Offset = "0x33913A4", VA = "0x33913A4")]
	[Token(Token = "0x6001E66")]
	private UnityWebRequest method_97()
	{
		return "CapuchinRemade";
	}

	// Token: 0x06001E67 RID: 7783 RVA: 0x0003876C File Offset: 0x0003696C
	[Address(RVA = "0x33916D8", Offset = "0x33916D8", VA = "0x33916D8")]
	[Token(Token = "0x6001E67")]
	private UnityWebRequest method_98()
	{
		return "typesOfTalk";
	}

	// Token: 0x06001E68 RID: 7784 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3391A0C", Offset = "0x3391A0C", VA = "0x3391A0C")]
	[Token(Token = "0x6001E68")]
	private IEnumerator method_99()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E69 RID: 7785 RVA: 0x00038C30 File Offset: 0x00036E30
	[Address(RVA = "0x3391A84", Offset = "0x3391A84", VA = "0x3391A84")]
	[Token(Token = "0x6001E69")]
	private void method_100()
	{
		IEnumerator routine = this.method_102();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E6A RID: 7786 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x339050C", Offset = "0x339050C", VA = "0x339050C")]
	[Token(Token = "0x6001E6A")]
	private IEnumerator method_101()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E6B RID: 7787 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3391AB0", Offset = "0x3391AB0", VA = "0x3391AB0")]
	[Token(Token = "0x6001E6B")]
	private IEnumerator method_102()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E6C RID: 7788 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x338F2F8", Offset = "0x338F2F8", VA = "0x338F2F8")]
	[Token(Token = "0x6001E6C")]
	private IEnumerator method_103()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E6D RID: 7789 RVA: 0x000386A8 File Offset: 0x000368A8
	[Address(RVA = "0x3391B28", Offset = "0x3391B28", VA = "0x3391B28")]
	[Token(Token = "0x6001E6D")]
	private IEnumerator method_104()
	{
		ImageDownloader.Class31 @class = new ImageDownloader.Class31((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001E6E RID: 7790 RVA: 0x00038A3C File Offset: 0x00036C3C
	[Address(RVA = "0x3391BA0", Offset = "0x3391BA0", VA = "0x3391BA0")]
	[Token(Token = "0x6001E6E")]
	private void method_105()
	{
		IEnumerator routine = this.method_57();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001E6F RID: 7791 RVA: 0x00038C4C File Offset: 0x00036E4C
	[Address(RVA = "0x3391BCC", Offset = "0x3391BCC", VA = "0x3391BCC")]
	[Token(Token = "0x6001E6F")]
	private UnityWebRequest method_106()
	{
		return "INSIGNIFICANT CURRENCY";
	}

	// Token: 0x06001E70 RID: 7792 RVA: 0x00038940 File Offset: 0x00036B40
	[Address(RVA = "0x3391F08", Offset = "0x3391F08", VA = "0x3391F08")]
	[Token(Token = "0x6001E70")]
	private void method_107()
	{
		IEnumerator routine = this.method_61();
		base.StartCoroutine(routine);
	}

	// Token: 0x040003FD RID: 1021
	[Token(Token = "0x40003FD")]
	[FieldOffset(Offset = "0x18")]
	public string string_0 = "fchb1239";

	// Token: 0x040003FE RID: 1022
	[Token(Token = "0x40003FE")]
	[FieldOffset(Offset = "0x20")]
	public string string_1 = "UnityImageDownloader";

	// Token: 0x040003FF RID: 1023
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40003FF")]
	public string string_2 = "main";

	// Token: 0x04000400 RID: 1024
	[Token(Token = "0x4000400")]
	[FieldOffset(Offset = "0x30")]
	public string string_3 = "TestImages/MyImage.png";

	// Token: 0x04000401 RID: 1025
	[Token(Token = "0x4000401")]
	[FieldOffset(Offset = "0x38")]
	public int int_0;

	// Token: 0x04000402 RID: 1026
	[Token(Token = "0x4000402")]
	[FieldOffset(Offset = "0x3C")]
	public int int_1;
}
