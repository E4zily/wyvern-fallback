﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000073 RID: 115
[Token(Token = "0x2000073")]
public class InteractableCosmetic : MonoBehaviour
{
	// Token: 0x06001034 RID: 4148 RVA: 0x0001F33C File Offset: 0x0001D53C
	[Token(Token = "0x6001034")]
	[Address(RVA = "0x3391FEC", Offset = "0x3391FEC", VA = "0x3391FEC")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("FingerTip");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001035 RID: 4149 RVA: 0x0001F390 File Offset: 0x0001D590
	[Token(Token = "0x6001035")]
	[Address(RVA = "0x3392120", Offset = "0x3392120", VA = "0x3392120")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("BN");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001036 RID: 4150 RVA: 0x0001F3E4 File Offset: 0x0001D5E4
	[Token(Token = "0x6001036")]
	[Address(RVA = "0x3392254", Offset = "0x3392254", VA = "0x3392254")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("TurnAmount");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001037 RID: 4151 RVA: 0x0001F438 File Offset: 0x0001D638
	[Token(Token = "0x6001037")]
	[Address(RVA = "0x3392388", Offset = "0x3392388", VA = "0x3392388")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log(" hour. You were banned because of ");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001038 RID: 4152 RVA: 0x0001F48C File Offset: 0x0001D68C
	[Token(Token = "0x6001038")]
	[Address(RVA = "0x33924BC", Offset = "0x33924BC", VA = "0x33924BC")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("username");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001039 RID: 4153 RVA: 0x0001F4E0 File Offset: 0x0001D6E0
	[Token(Token = "0x6001039")]
	[Address(RVA = "0x33925F0", Offset = "0x33925F0", VA = "0x33925F0")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("PURCHASED");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600103A RID: 4154 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3392724", Offset = "0x3392724", VA = "0x3392724")]
	[Token(Token = "0x600103A")]
	public InteractableCosmetic()
	{
	}

	// Token: 0x0600103B RID: 4155 RVA: 0x0001F534 File Offset: 0x0001D734
	[Token(Token = "0x600103B")]
	[Address(RVA = "0x339272C", Offset = "0x339272C", VA = "0x339272C")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600103C RID: 4156 RVA: 0x0001F588 File Offset: 0x0001D788
	[Token(Token = "0x600103C")]
	[Address(RVA = "0x3392860", Offset = "0x3392860", VA = "0x3392860")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("containsStaff");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600103D RID: 4157 RVA: 0x0001F5DC File Offset: 0x0001D7DC
	[Token(Token = "0x600103D")]
	[Address(RVA = "0x3392994", Offset = "0x3392994", VA = "0x3392994")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("SaveHeight");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600103E RID: 4158 RVA: 0x0001F534 File Offset: 0x0001D734
	[Address(RVA = "0x3392AC8", Offset = "0x3392AC8", VA = "0x3392AC8")]
	[Token(Token = "0x600103E")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600103F RID: 4159 RVA: 0x0001F630 File Offset: 0x0001D830
	[Token(Token = "0x600103F")]
	[Address(RVA = "0x3392BFC", Offset = "0x3392BFC", VA = "0x3392BFC")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Cannot access an empty buffer.");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001040 RID: 4160 RVA: 0x0001F684 File Offset: 0x0001D884
	[Address(RVA = "0x3392D30", Offset = "0x3392D30", VA = "0x3392D30")]
	[Token(Token = "0x6001040")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("/");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001041 RID: 4161 RVA: 0x0001F6D8 File Offset: 0x0001D8D8
	[Address(RVA = "0x3392E64", Offset = "0x3392E64", VA = "0x3392E64")]
	[Token(Token = "0x6001041")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Version");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001042 RID: 4162 RVA: 0x0001F72C File Offset: 0x0001D92C
	[Token(Token = "0x6001042")]
	[Address(RVA = "0x3392F98", Offset = "0x3392F98", VA = "0x3392F98")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Player");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001043 RID: 4163 RVA: 0x0001F780 File Offset: 0x0001D980
	[Address(RVA = "0x33930CC", Offset = "0x33930CC", VA = "0x33930CC")]
	[Token(Token = "0x6001043")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("sound play stopped");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001044 RID: 4164 RVA: 0x0001F7D4 File Offset: 0x0001D9D4
	[Token(Token = "0x6001044")]
	[Address(RVA = "0x3393200", Offset = "0x3393200", VA = "0x3393200")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("retract broken");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001045 RID: 4165 RVA: 0x0001F828 File Offset: 0x0001DA28
	[Address(RVA = "0x3393334", Offset = "0x3393334", VA = "0x3393334")]
	[Token(Token = "0x6001045")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log(" hours. You were banned because of ");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001046 RID: 4166 RVA: 0x0001F87C File Offset: 0x0001DA7C
	[Address(RVA = "0x3393468", Offset = "0x3393468", VA = "0x3393468")]
	[Token(Token = "0x6001046")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Camera movement detected, calibrating height.");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001047 RID: 4167 RVA: 0x0001F8D0 File Offset: 0x0001DAD0
	[Address(RVA = "0x339359C", Offset = "0x339359C", VA = "0x339359C")]
	[Token(Token = "0x6001047")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Trying Getting Entilement...");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001048 RID: 4168 RVA: 0x0001F924 File Offset: 0x0001DB24
	[Address(RVA = "0x33936D0", Offset = "0x33936D0", VA = "0x33936D0")]
	[Token(Token = "0x6001048")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("https://raw.githubusercontent.com/");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001049 RID: 4169 RVA: 0x0001F978 File Offset: 0x0001DB78
	[Address(RVA = "0x3393804", Offset = "0x3393804", VA = "0x3393804")]
	[Token(Token = "0x6001049")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("NetworkGunShoot");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600104A RID: 4170 RVA: 0x0001F9CC File Offset: 0x0001DBCC
	[Address(RVA = "0x3393938", Offset = "0x3393938", VA = "0x3393938")]
	[Token(Token = "0x600104A")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("HOLY MOLY THE STICK IS ON FIRE!!!!!!");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600104B RID: 4171 RVA: 0x0001F72C File Offset: 0x0001D92C
	[Address(RVA = "0x3393A6C", Offset = "0x3393A6C", VA = "0x3393A6C")]
	[Token(Token = "0x600104B")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Player");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600104C RID: 4172 RVA: 0x0001F33C File Offset: 0x0001D53C
	[Address(RVA = "0x3393BA0", Offset = "0x3393BA0", VA = "0x3393BA0")]
	[Token(Token = "0x600104C")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("FingerTip");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600104D RID: 4173 RVA: 0x0001F33C File Offset: 0x0001D53C
	[Token(Token = "0x600104D")]
	[Address(RVA = "0x3393CD4", Offset = "0x3393CD4", VA = "0x3393CD4")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("FingerTip");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600104E RID: 4174 RVA: 0x0001FA20 File Offset: 0x0001DC20
	[Token(Token = "0x600104E")]
	[Address(RVA = "0x3393E08", Offset = "0x3393E08", VA = "0x3393E08")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Cannot take elements from an empty buffer.");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600104F RID: 4175 RVA: 0x0001FA74 File Offset: 0x0001DC74
	[Token(Token = "0x600104F")]
	[Address(RVA = "0x3393F3C", Offset = "0x3393F3C", VA = "0x3393F3C")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("got funky mone");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001050 RID: 4176 RVA: 0x0001FAC8 File Offset: 0x0001DCC8
	[Token(Token = "0x6001050")]
	[Address(RVA = "0x3394070", Offset = "0x3394070", VA = "0x3394070")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("true");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001051 RID: 4177 RVA: 0x0001FB1C File Offset: 0x0001DD1C
	[Address(RVA = "0x33941A4", Offset = "0x33941A4", VA = "0x33941A4")]
	[Token(Token = "0x6001051")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("amongus");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001052 RID: 4178 RVA: 0x0001F33C File Offset: 0x0001D53C
	[Address(RVA = "0x33942D8", Offset = "0x33942D8", VA = "0x33942D8")]
	[Token(Token = "0x6001052")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("FingerTip");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001053 RID: 4179 RVA: 0x0001FA74 File Offset: 0x0001DC74
	[Address(RVA = "0x339440C", Offset = "0x339440C", VA = "0x339440C")]
	[Token(Token = "0x6001053")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("got funky mone");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001054 RID: 4180 RVA: 0x0001FB70 File Offset: 0x0001DD70
	[Token(Token = "0x6001054")]
	[Address(RVA = "0x3394540", Offset = "0x3394540", VA = "0x3394540")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("token");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001055 RID: 4181 RVA: 0x0001FBC4 File Offset: 0x0001DDC4
	[Token(Token = "0x6001055")]
	[Address(RVA = "0x3394674", Offset = "0x3394674", VA = "0x3394674")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("You Already Own This Item");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001056 RID: 4182 RVA: 0x0001FC18 File Offset: 0x0001DE18
	[Address(RVA = "0x33947A8", Offset = "0x33947A8", VA = "0x33947A8")]
	[Token(Token = "0x6001056")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("_Tint");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001057 RID: 4183 RVA: 0x0001F390 File Offset: 0x0001D590
	[Token(Token = "0x6001057")]
	[Address(RVA = "0x33948DC", Offset = "0x33948DC", VA = "0x33948DC")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("BN");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001058 RID: 4184 RVA: 0x0001F48C File Offset: 0x0001D68C
	[Token(Token = "0x6001058")]
	[Address(RVA = "0x3394A10", Offset = "0x3394A10", VA = "0x3394A10")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("username");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001059 RID: 4185 RVA: 0x0001FC6C File Offset: 0x0001DE6C
	[Address(RVA = "0x3394B44", Offset = "0x3394B44", VA = "0x3394B44")]
	[Token(Token = "0x6001059")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Reason: ");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600105A RID: 4186 RVA: 0x0001FCC0 File Offset: 0x0001DEC0
	[Address(RVA = "0x3394C78", Offset = "0x3394C78", VA = "0x3394C78")]
	[Token(Token = "0x600105A")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600105B RID: 4187 RVA: 0x0001FD14 File Offset: 0x0001DF14
	[Token(Token = "0x600105B")]
	[Address(RVA = "0x3394DAC", Offset = "0x3394DAC", VA = "0x3394DAC")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("CapuchinRemade");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600105C RID: 4188 RVA: 0x0001FD68 File Offset: 0x0001DF68
	[Token(Token = "0x600105C")]
	[Address(RVA = "0x3394EE0", Offset = "0x3394EE0", VA = "0x3394EE0")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Tagged");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600105D RID: 4189 RVA: 0x0001F72C File Offset: 0x0001D92C
	[Address(RVA = "0x3395014", Offset = "0x3395014", VA = "0x3395014")]
	[Token(Token = "0x600105D")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Player");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600105E RID: 4190 RVA: 0x0001F33C File Offset: 0x0001D53C
	[Token(Token = "0x600105E")]
	[Address(RVA = "0x3395148", Offset = "0x3395148", VA = "0x3395148")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("FingerTip");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x0600105F RID: 4191 RVA: 0x0001F72C File Offset: 0x0001D92C
	[Token(Token = "0x600105F")]
	[Address(RVA = "0x339527C", Offset = "0x339527C", VA = "0x339527C")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Player");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001060 RID: 4192 RVA: 0x0001FDBC File Offset: 0x0001DFBC
	[Address(RVA = "0x33953B0", Offset = "0x33953B0", VA = "0x33953B0")]
	[Token(Token = "0x6001060")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("ENABLE");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001061 RID: 4193 RVA: 0x0001FE10 File Offset: 0x0001E010
	[Address(RVA = "0x33954E4", Offset = "0x33954E4", VA = "0x33954E4")]
	[Token(Token = "0x6001061")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("Calling success callback. baking meshes");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001062 RID: 4194 RVA: 0x0001FE64 File Offset: 0x0001E064
	[Token(Token = "0x6001062")]
	[Address(RVA = "0x3395618", Offset = "0x3395618", VA = "0x3395618")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("MetaAuth");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001063 RID: 4195 RVA: 0x0001F588 File Offset: 0x0001D788
	[Token(Token = "0x6001063")]
	[Address(RVA = "0x339574C", Offset = "0x339574C", VA = "0x339574C")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("containsStaff");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001064 RID: 4196 RVA: 0x0001FEB8 File Offset: 0x0001E0B8
	[Token(Token = "0x6001064")]
	[Address(RVA = "0x3395880", Offset = "0x3395880", VA = "0x3395880")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("User has been reported for: ");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001065 RID: 4197 RVA: 0x0001F588 File Offset: 0x0001D788
	[Token(Token = "0x6001065")]
	[Address(RVA = "0x33959B4", Offset = "0x33959B4", VA = "0x33959B4")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("containsStaff");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001066 RID: 4198 RVA: 0x0001F3E4 File Offset: 0x0001D5E4
	[Address(RVA = "0x3395AE8", Offset = "0x3395AE8", VA = "0x3395AE8")]
	[Token(Token = "0x6001066")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("TurnAmount");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x06001067 RID: 4199 RVA: 0x0001FF0C File Offset: 0x0001E10C
	[Address(RVA = "0x3395C1C", Offset = "0x3395C1C", VA = "0x3395C1C")]
	[Token(Token = "0x6001067")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.GetComponent<InteractableCosmeticCollider>();
		if (this.fireAndStick_0 != null)
		{
			this.fireAndStick_0.fire.Play();
			Debug.Log("ChangeMaterialToNormal");
			this.fireAndStick_0.fireCrackling.Play();
			return;
		}
	}

	// Token: 0x04000260 RID: 608
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000260")]
	public InteractableCosmetic.FireAndStick fireAndStick_0;

	// Token: 0x02000074 RID: 116
	[Token(Token = "0x2000074")]
	[Serializable]
	public struct FireAndStick
	{
		// Token: 0x04000261 RID: 609
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000261")]
		public bool isStick;

		// Token: 0x04000262 RID: 610
		[Token(Token = "0x4000262")]
		[FieldOffset(Offset = "0x8")]
		public ParticleSystem fire;

		// Token: 0x04000263 RID: 611
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000263")]
		public AudioSource fireCrackling;
	}
}
