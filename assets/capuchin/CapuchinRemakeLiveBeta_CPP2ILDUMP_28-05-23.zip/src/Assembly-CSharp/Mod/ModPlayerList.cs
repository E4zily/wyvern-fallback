﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000198 RID: 408
	[Token(Token = "0x2000198")]
	public class ModPlayerList : MonoBehaviour
	{
		// Token: 0x06003CD6 RID: 15574 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003CD6")]
		[Address(RVA = "0x2E665E8", Offset = "0x2E665E8", VA = "0x2E665E8")]
		private void Start()
		{
		}

		// Token: 0x06003CD7 RID: 15575 RVA: 0x00077234 File Offset: 0x00075434
		[Address(RVA = "0x2E665F0", Offset = "0x2E665F0", VA = "0x2E665F0")]
		[Token(Token = "0x6003CD7")]
		private void Update()
		{
			bool inRoom = PhotonNetwork.InRoom;
			GameObject[] array = GameObject.FindGameObjectsWithTag("NetworkPlayer");
			this.players = array;
			byte playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
		}

		// Token: 0x06003CD8 RID: 15576 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x2E668B4", Offset = "0x2E668B4", VA = "0x2E668B4")]
		[Token(Token = "0x6003CD8")]
		public ModPlayerList()
		{
		}

		// Token: 0x04000B29 RID: 2857
		[Token(Token = "0x4000B29")]
		[FieldOffset(Offset = "0x18")]
		public GameObject[] players;

		// Token: 0x04000B2A RID: 2858
		[Token(Token = "0x4000B2A")]
		[FieldOffset(Offset = "0x20")]
		public GameObject[] playerItems;

		// Token: 0x04000B2B RID: 2859
		[Token(Token = "0x4000B2B")]
		[FieldOffset(Offset = "0x28")]
		private int prevPlayerc;
	}
}
