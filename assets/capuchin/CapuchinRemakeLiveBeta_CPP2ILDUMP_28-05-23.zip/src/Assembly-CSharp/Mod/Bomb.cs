﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200019A RID: 410
	[Token(Token = "0x200019A")]
	public class Bomb : MonoBehaviour
	{
		// Token: 0x06003CDF RID: 15583 RVA: 0x00077394 File Offset: 0x00075594
		[Address(RVA = "0x25A9AE8", Offset = "0x25A9AE8", VA = "0x25A9AE8")]
		[Token(Token = "0x6003CDF")]
		private void Start()
		{
			Rigidbody component = GameObject.Find("XR Origin").GetComponent<Rigidbody>();
			this.player = component;
		}

		// Token: 0x06003CE0 RID: 15584 RVA: 0x000773B8 File Offset: 0x000755B8
		[Address(RVA = "0x25A9B68", Offset = "0x25A9B68", VA = "0x25A9B68")]
		[Token(Token = "0x6003CE0")]
		private void Update()
		{
			long num = 1L;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			Vector3 position2 = this.target.position;
			Transform transform2 = base.transform;
			Transform transform3 = this.target;
			transform2.LookAt(transform3);
			Vector3 position3 = this.raycastPoint.position;
			Vector3 forward = this.raycastPoint.forward;
			Vector3 position4 = this.raycastPoint.position;
			Vector3 forward2 = this.raycastPoint.forward;
			Color white = Color.white;
			if (num != 0L)
			{
			}
			if (!this.exploded)
			{
				Debug.Log("hit ground");
				MeshRenderer component = base.GetComponent<MeshRenderer>();
				long enabled = 0L;
				component.enabled = (enabled != 0L);
				Collider collider;
				Transform transform4 = collider.transform;
				Transform transform5 = this.hitPoint;
				Vector3 position5 = transform5.position;
				this.system.Play();
				IEnumerator routine = this.wait();
				base.StartCoroutine(routine);
				long num2 = 1L;
				this.exploded = (num2 != 0L);
			}
		}

		// Token: 0x06003CE1 RID: 15585 RVA: 0x000774A0 File Offset: 0x000756A0
		[Address(RVA = "0x25A9F64", Offset = "0x25A9F64", VA = "0x25A9F64")]
		[Token(Token = "0x6003CE1")]
		private IEnumerator wait()
		{
			new Bomb.<wait>d__11((int)0L);
			throw new NullReferenceException();
		}

		// Token: 0x06003CE2 RID: 15586 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x25A9FDC", Offset = "0x25A9FDC", VA = "0x25A9FDC")]
		[Token(Token = "0x6003CE2")]
		public Bomb()
		{
		}

		// Token: 0x04000B35 RID: 2869
		[Token(Token = "0x4000B35")]
		[FieldOffset(Offset = "0x18")]
		public Transform target;

		// Token: 0x04000B36 RID: 2870
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B36")]
		public float speed;

		// Token: 0x04000B37 RID: 2871
		[Token(Token = "0x4000B37")]
		[FieldOffset(Offset = "0x28")]
		public Transform raycastPoint;

		// Token: 0x04000B38 RID: 2872
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000B38")]
		public float rayDis;

		// Token: 0x04000B39 RID: 2873
		[Token(Token = "0x4000B39")]
		[FieldOffset(Offset = "0x38")]
		private Transform hitPoint;

		// Token: 0x04000B3A RID: 2874
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000B3A")]
		public ParticleSystem system;

		// Token: 0x04000B3B RID: 2875
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000B3B")]
		private Rigidbody player;

		// Token: 0x04000B3C RID: 2876
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000B3C")]
		private bool exploded;

		// Token: 0x04000B3D RID: 2877
		[Token(Token = "0x4000B3D")]
		[FieldOffset(Offset = "0x54")]
		public int i;
	}
}
