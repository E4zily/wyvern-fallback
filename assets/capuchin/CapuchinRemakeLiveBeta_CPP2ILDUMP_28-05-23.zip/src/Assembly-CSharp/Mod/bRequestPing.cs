﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x020001A3 RID: 419
	[Token(Token = "0x20001A3")]
	public class bRequestPing : MonoBehaviour
	{
		// Token: 0x06003CFF RID: 15615 RVA: 0x00077734 File Offset: 0x00075934
		[Address(RVA = "0x354DD98", Offset = "0x354DD98", VA = "0x354DD98")]
		[Token(Token = "0x6003CFF")]
		[PunRPC]
		public void Ping(string target)
		{
			string nickName = PhotonNetwork.LocalPlayer.nickName;
			target == nickName;
			string <UserId>k__BackingField = PhotonNetwork.LocalPlayer.<UserId>k__BackingField;
			if (<UserId>k__BackingField != null && <UserId>k__BackingField == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}

		// Token: 0x06003D00 RID: 15616 RVA: 0x00077770 File Offset: 0x00075970
		[Address(RVA = "0x354DF04", Offset = "0x354DF04", VA = "0x354DF04")]
		[PunRPC]
		[Token(Token = "0x6003D00")]
		public void Pong(string uid)
		{
			this.targetUid = uid;
		}

		// Token: 0x06003D01 RID: 15617 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003D01")]
		[Address(RVA = "0x354DF34", Offset = "0x354DF34", VA = "0x354DF34")]
		public bRequestPing()
		{
		}

		// Token: 0x04000B64 RID: 2916
		[Token(Token = "0x4000B64")]
		[FieldOffset(Offset = "0x18")]
		public PhotonView view;

		// Token: 0x04000B65 RID: 2917
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B65")]
		public string targetUid;

		// Token: 0x04000B66 RID: 2918
		[Token(Token = "0x4000B66")]
		[FieldOffset(Offset = "0x28")]
		public bool recieved;
	}
}
