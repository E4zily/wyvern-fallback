﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Mod
{
	// Token: 0x02000199 RID: 409
	[Token(Token = "0x2000199")]
	public class PlayerItem : MonoBehaviour
	{
		// Token: 0x06003CD9 RID: 15577 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x2A7817C", Offset = "0x2A7817C", VA = "0x2A7817C")]
		[Token(Token = "0x6003CD9")]
		private void Start()
		{
		}

		// Token: 0x06003CDA RID: 15578 RVA: 0x00077264 File Offset: 0x00075464
		[Address(RVA = "0x2A78180", Offset = "0x2A78180", VA = "0x2A78180")]
		[Token(Token = "0x6003CDA")]
		private void LateUpdate()
		{
			bool isOn = this.toggle.m_IsOn;
			this.audioIsolated = isOn;
		}

		// Token: 0x06003CDB RID: 15579 RVA: 0x00077284 File Offset: 0x00075484
		[Address(RVA = "0x2A7820C", Offset = "0x2A7820C", VA = "0x2A7820C")]
		[Token(Token = "0x6003CDB")]
		public void KickPlayer()
		{
			this.kick.view.RequestOwnership();
			Player <Owner>k__BackingField = this.player.<Owner>k__BackingField;
			Kicks kicks = this.kick;
			string nickName = <Owner>k__BackingField.nickName;
			IEnumerator routine = kicks.SendWebhook(nickName);
			kicks.StartCoroutine(routine);
			string nickName2 = this.player.<Owner>k__BackingField.nickName;
			if (nickName2 != null && nickName2 == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}

		// Token: 0x06003CDC RID: 15580 RVA: 0x000772EC File Offset: 0x000754EC
		[Address(RVA = "0x2A78354", Offset = "0x2A78354", VA = "0x2A78354")]
		[Token(Token = "0x6003CDC")]
		public void Fling()
		{
			this.troller.photonView_0.RequestOwnership();
			string nickName = this.player.<Owner>k__BackingField.nickName;
			if (nickName != null && nickName == null)
			{
				throw new ArrayTypeMismatchException();
			}
		}

		// Token: 0x06003CDD RID: 15581 RVA: 0x00077328 File Offset: 0x00075528
		[Token(Token = "0x6003CDD")]
		[Address(RVA = "0x2A784C8", Offset = "0x2A784C8", VA = "0x2A784C8")]
		public void sTaunt()
		{
			this.troller.photonView_0.RequestOwnership();
			string nickName = this.player.<Owner>k__BackingField.nickName;
			if (nickName != null && nickName == null)
			{
				throw new ArrayTypeMismatchException();
			}
			string name = this.taunt.name;
			Transform transform = this.player.transform;
			long index = 0L;
			Vector3 position = transform.GetChild((int)index).position;
			Quaternion identity = Quaternion.identity;
		}

		// Token: 0x06003CDE RID: 15582 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003CDE")]
		[Address(RVA = "0x2A78720", Offset = "0x2A78720", VA = "0x2A78720")]
		public PlayerItem()
		{
		}

		// Token: 0x04000B2C RID: 2860
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000B2C")]
		public PhotonView player;

		// Token: 0x04000B2D RID: 2861
		[Token(Token = "0x4000B2D")]
		[FieldOffset(Offset = "0x20")]
		public TMP_Text text;

		// Token: 0x04000B2E RID: 2862
		[Token(Token = "0x4000B2E")]
		[FieldOffset(Offset = "0x28")]
		public Kicks kick;

		// Token: 0x04000B2F RID: 2863
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000B2F")]
		public AudioSource playera;

		// Token: 0x04000B30 RID: 2864
		[Token(Token = "0x4000B30")]
		[FieldOffset(Offset = "0x38")]
		public bool audioIsolated;

		// Token: 0x04000B31 RID: 2865
		[Token(Token = "0x4000B31")]
		[FieldOffset(Offset = "0x40")]
		public GameObject disabledAudio;

		// Token: 0x04000B32 RID: 2866
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000B32")]
		public Toggle toggle;

		// Token: 0x04000B33 RID: 2867
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000B33")]
		public troller troller;

		// Token: 0x04000B34 RID: 2868
		[Token(Token = "0x4000B34")]
		[FieldOffset(Offset = "0x58")]
		public GameObject taunt;
	}
}
