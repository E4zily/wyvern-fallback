﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200019C RID: 412
	[Token(Token = "0x200019C")]
	public class BombManager : MonoBehaviourPun
	{
		// Token: 0x06003CE9 RID: 15593 RVA: 0x000038EB File Offset: 0x00001AEB
		[Token(Token = "0x6003CE9")]
		[Address(RVA = "0x25A9FE4", Offset = "0x25A9FE4", VA = "0x25A9FE4")]
		private void Start()
		{
			BombManager.Instance = this;
		}

		// Token: 0x06003CEA RID: 15594 RVA: 0x00077514 File Offset: 0x00075714
		[Address(RVA = "0x25AA038", Offset = "0x25AA038", VA = "0x25AA038")]
		[Token(Token = "0x6003CEA")]
		public void Bomb(BombManager.bomb bombChoice, BombMenu menu)
		{
			if (!base.photonView.<IsMine>k__BackingField)
			{
				bool inRoom = PhotonNetwork.InRoom;
				PhotonView photonView = base.photonView;
			}
			string b_target = menu.b_target;
			this.target = b_target;
			if (bombChoice == BombManager.bomb.missile)
			{
				PhotonView photonView2 = base.photonView;
				return;
			}
		}

		// Token: 0x06003CEB RID: 15595 RVA: 0x00077554 File Offset: 0x00075754
		[Token(Token = "0x6003CEB")]
		[Address(RVA = "0x25AA260", Offset = "0x25AA260", VA = "0x25AA260")]
		[PunRPC]
		private void LaunchMissile(bool nuke)
		{
		}

		// Token: 0x06003CEC RID: 15596 RVA: 0x00002095 File Offset: 0x00000295
		[Address(RVA = "0x25AA3E4", Offset = "0x25AA3E4", VA = "0x25AA3E4")]
		[Token(Token = "0x6003CEC")]
		public BombManager()
		{
		}

		// Token: 0x04000B41 RID: 2881
		[Token(Token = "0x4000B41")]
		public static BombManager Instance;

		// Token: 0x04000B42 RID: 2882
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B42")]
		public Transform[] missileTargets;

		// Token: 0x04000B43 RID: 2883
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000B43")]
		public Transform bridge;

		// Token: 0x04000B44 RID: 2884
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000B44")]
		public Transform shop;

		// Token: 0x04000B45 RID: 2885
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000B45")]
		public Transform waterfall;

		// Token: 0x04000B46 RID: 2886
		[Token(Token = "0x4000B46")]
		[FieldOffset(Offset = "0x40")]
		public Transform start;

		// Token: 0x04000B47 RID: 2887
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000B47")]
		public GameObject nukePrefab;

		// Token: 0x04000B48 RID: 2888
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000B48")]
		public GameObject missilePrefab;

		// Token: 0x04000B49 RID: 2889
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000B49")]
		public string target;

		// Token: 0x0200019D RID: 413
		[Token(Token = "0x200019D")]
		public enum bomb
		{
			// Token: 0x04000B4B RID: 2891
			[Token(Token = "0x4000B4B")]
			missile,
			// Token: 0x04000B4C RID: 2892
			[Token(Token = "0x4000B4C")]
			nuke
		}
	}
}
