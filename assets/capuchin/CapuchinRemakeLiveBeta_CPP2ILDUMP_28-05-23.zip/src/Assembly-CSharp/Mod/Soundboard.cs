﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200019F RID: 415
	[Token(Token = "0x200019F")]
	public class Soundboard : MonoBehaviour
	{
		// Token: 0x06003CF1 RID: 15601 RVA: 0x00077598 File Offset: 0x00075798
		[Token(Token = "0x6003CF1")]
		[Address(RVA = "0x2B9802C", Offset = "0x2B9802C", VA = "0x2B9802C")]
		[PunRPC]
		public void PlaySound(int sound)
		{
		}

		// Token: 0x06003CF2 RID: 15602 RVA: 0x00003906 File Offset: 0x00001B06
		[Token(Token = "0x6003CF2")]
		[Address(RVA = "0x2B98074", Offset = "0x2B98074", VA = "0x2B98074")]
		[PunRPC]
		public void Stop()
		{
			this.audioSource.Stop();
		}

		// Token: 0x06003CF3 RID: 15603 RVA: 0x000113BC File Offset: 0x0000F5BC
		[Token(Token = "0x6003CF3")]
		[Address(RVA = "0x2B98090", Offset = "0x2B98090", VA = "0x2B98090")]
		public void remoteSound(int sound)
		{
		}

		// Token: 0x06003CF4 RID: 15604 RVA: 0x00035CB0 File Offset: 0x00033EB0
		[Address(RVA = "0x2B9819C", Offset = "0x2B9819C", VA = "0x2B9819C")]
		[Token(Token = "0x6003CF4")]
		public void remoteStop()
		{
		}

		// Token: 0x06003CF5 RID: 15605 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003CF5")]
		[Address(RVA = "0x2B9829C", Offset = "0x2B9829C", VA = "0x2B9829C")]
		public Soundboard()
		{
		}

		// Token: 0x04000B50 RID: 2896
		[Token(Token = "0x4000B50")]
		[FieldOffset(Offset = "0x18")]
		public PhotonView view;

		// Token: 0x04000B51 RID: 2897
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B51")]
		public AudioClip[] sounds;

		// Token: 0x04000B52 RID: 2898
		[Token(Token = "0x4000B52")]
		[FieldOffset(Offset = "0x28")]
		public AudioSource audioSource;
	}
}
