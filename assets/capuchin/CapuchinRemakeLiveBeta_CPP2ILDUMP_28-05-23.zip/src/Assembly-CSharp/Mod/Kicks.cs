﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cpp2IlInjected;
using Locomotion;
using Photon.Pun;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000196 RID: 406
	[Token(Token = "0x2000196")]
	public class Kicks : MonoBehaviour
	{
		// Token: 0x06003CCB RID: 15563 RVA: 0x000770A0 File Offset: 0x000752A0
		[Token(Token = "0x6003CCB")]
		[Address(RVA = "0x35E4B08", Offset = "0x35E4B08", VA = "0x35E4B08")]
		private void Update()
		{
			long num = 1L;
			if (num != 0L)
			{
			}
			string nickName = PhotonNetwork.LocalPlayer.nickName;
			long num2;
			if (!this.isKicked)
			{
				Player.player_0.method_20();
				Transform transform = this.backrooms;
				Vector3 position = transform.position;
				Transform transform2 = this.backrooms;
				Vector3 position2 = transform2.position;
				num2 = 1L;
				this.isKicked = (num2 != 0L);
			}
			if (num2 != 0L)
			{
			}
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06003CCC RID: 15564 RVA: 0x00077104 File Offset: 0x00075304
		[PunRPC]
		[Address(RVA = "0x35E4C5C", Offset = "0x35E4C5C", VA = "0x35E4C5C")]
		[Token(Token = "0x6003CCC")]
		public void KickPlayer(string player)
		{
		}

		// Token: 0x06003CCD RID: 15565 RVA: 0x00077114 File Offset: 0x00075314
		[Address(RVA = "0x35E4CC0", Offset = "0x35E4CC0", VA = "0x35E4CC0")]
		[Token(Token = "0x6003CCD")]
		public IEnumerator SendWebhook(string name)
		{
			Kicks.<SendWebhook>d__10 <SendWebhook>d__ = new Kicks.<SendWebhook>d__10((int)0L);
			<SendWebhook>d__.<>4__this = this;
			<SendWebhook>d__.name = name;
			throw new NullReferenceException();
		}

		// Token: 0x06003CCE RID: 15566 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x35E4D54", Offset = "0x35E4D54", VA = "0x35E4D54")]
		[Token(Token = "0x6003CCE")]
		public Kicks()
		{
		}

		// Token: 0x04000B1C RID: 2844
		[Token(Token = "0x4000B1C")]
		[FieldOffset(Offset = "0x18")]
		public List<string> deadPeople;

		// Token: 0x04000B1D RID: 2845
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B1D")]
		public PhotonView view;

		// Token: 0x04000B1E RID: 2846
		[Token(Token = "0x4000B1E")]
		[FieldOffset(Offset = "0x28")]
		[Header("trolling")]
		public bool isKicked;

		// Token: 0x04000B1F RID: 2847
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000B1F")]
		public Transform xrOrigin;

		// Token: 0x04000B20 RID: 2848
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000B20")]
		public Transform physRig;

		// Token: 0x04000B21 RID: 2849
		[Token(Token = "0x4000B21")]
		[FieldOffset(Offset = "0x40")]
		public PhysicsHand[] hands;

		// Token: 0x04000B22 RID: 2850
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000B22")]
		public Transform backrooms;

		// Token: 0x04000B23 RID: 2851
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000B23")]
		[Header("webhook")]
		public string wHookurl;
	}
}
