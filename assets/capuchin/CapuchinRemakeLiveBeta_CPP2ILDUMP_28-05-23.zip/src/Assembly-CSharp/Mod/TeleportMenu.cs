﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x020001A2 RID: 418
	[Token(Token = "0x20001A2")]
	public class TeleportMenu : MonoBehaviour
	{
		// Token: 0x06003CFD RID: 15613 RVA: 0x00077714 File Offset: 0x00075914
		[Token(Token = "0x6003CFD")]
		[Address(RVA = "0x2D342F8", Offset = "0x2D342F8", VA = "0x2D342F8")]
		public void tp(int location)
		{
			Transform transform = this.player;
			Vector3 position = transform.position;
		}

		// Token: 0x06003CFE RID: 15614 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003CFE")]
		[Address(RVA = "0x2D34408", Offset = "0x2D34408", VA = "0x2D34408")]
		public TeleportMenu()
		{
		}

		// Token: 0x04000B60 RID: 2912
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000B60")]
		public Transform player;

		// Token: 0x04000B61 RID: 2913
		[Token(Token = "0x4000B61")]
		[FieldOffset(Offset = "0x20")]
		public Transform physrig;

		// Token: 0x04000B62 RID: 2914
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000B62")]
		public Transform[] teleports;

		// Token: 0x04000B63 RID: 2915
		[Token(Token = "0x4000B63")]
		[FieldOffset(Offset = "0x30")]
		public PhysicsHand[] hands;
	}
}
