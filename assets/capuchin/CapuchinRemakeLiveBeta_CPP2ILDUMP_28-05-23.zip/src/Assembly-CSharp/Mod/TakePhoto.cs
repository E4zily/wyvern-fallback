﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

namespace Mod
{
	// Token: 0x020001A1 RID: 417
	[Token(Token = "0x20001A1")]
	public class TakePhoto : MonoBehaviour
	{
		// Token: 0x06003CFB RID: 15611 RVA: 0x00077688 File Offset: 0x00075888
		[Address(RVA = "0x2D2F518", Offset = "0x2D2F518", VA = "0x2D2F518")]
		[Token(Token = "0x6003CFB")]
		public void Update()
		{
			if (InputDevices.GetDeviceAtXRNode(this.Controller) != null)
			{
			}
			if (!this.idk)
			{
				string str = DateTime.UtcNow.ToLocalTime().ToString("hh:mm:sstt");
				string str2 = DateTime.UtcNow.ToLocalTime().ToString("M/d/yyyy");
				PhotoHandler photoHandler = this.PhotoHandler;
				string message = "Date: " + str2 + "\n Time: " + str;
				photoHandler.Message = message;
				this.PhotoHandler.CaptureScreenShot();
				this.clipSound.Play();
				return;
			}
		}

		// Token: 0x06003CFC RID: 15612 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x2D2F734", Offset = "0x2D2F734", VA = "0x2D2F734")]
		[Token(Token = "0x6003CFC")]
		public TakePhoto()
		{
		}

		// Token: 0x04000B5C RID: 2908
		[Token(Token = "0x4000B5C")]
		[FieldOffset(Offset = "0x18")]
		public XRNode Controller;

		// Token: 0x04000B5D RID: 2909
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B5D")]
		public PhotoHandler PhotoHandler;

		// Token: 0x04000B5E RID: 2910
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000B5E")]
		public AudioSource clipSound;

		// Token: 0x04000B5F RID: 2911
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000B5F")]
		private bool idk;
	}
}
