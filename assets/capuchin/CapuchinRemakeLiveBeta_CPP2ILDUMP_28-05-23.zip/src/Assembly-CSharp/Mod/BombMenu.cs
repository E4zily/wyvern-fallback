﻿using System;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200019E RID: 414
	[Token(Token = "0x200019E")]
	public class BombMenu : MonoBehaviour
	{
		// Token: 0x06003CED RID: 15597 RVA: 0x00077564 File Offset: 0x00075764
		[Token(Token = "0x6003CED")]
		[Address(RVA = "0x25AA3EC", Offset = "0x25AA3EC", VA = "0x25AA3EC")]
		public void SetTarget()
		{
			string text;
			this.b_target = text;
		}

		// Token: 0x06003CEE RID: 15598 RVA: 0x00077578 File Offset: 0x00075778
		[Token(Token = "0x6003CEE")]
		[Address(RVA = "0x25AA43C", Offset = "0x25AA43C", VA = "0x25AA43C")]
		public void LaunchSingleMissile()
		{
			if (this.Launching)
			{
				return;
			}
			long launching = 1L;
			this.Launching = (launching != 0L);
		}

		// Token: 0x06003CEF RID: 15599 RVA: 0x00077578 File Offset: 0x00075778
		[Token(Token = "0x6003CEF")]
		[Address(RVA = "0x25AA4B8", Offset = "0x25AA4B8", VA = "0x25AA4B8")]
		public void LaunchNuke()
		{
			if (this.Launching)
			{
				return;
			}
			long launching = 1L;
			this.Launching = (launching != 0L);
		}

		// Token: 0x06003CF0 RID: 15600 RVA: 0x000038F3 File Offset: 0x00001AF3
		[Address(RVA = "0x25AA534", Offset = "0x25AA534", VA = "0x25AA534")]
		[Token(Token = "0x6003CF0")]
		public BombMenu()
		{
		}

		// Token: 0x04000B4D RID: 2893
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000B4D")]
		public bool Launching;

		// Token: 0x04000B4E RID: 2894
		[Token(Token = "0x4000B4E")]
		[FieldOffset(Offset = "0x20")]
		public string b_target = "Bridge";

		// Token: 0x04000B4F RID: 2895
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000B4F")]
		public TMP_Dropdown dropdown;
	}
}
