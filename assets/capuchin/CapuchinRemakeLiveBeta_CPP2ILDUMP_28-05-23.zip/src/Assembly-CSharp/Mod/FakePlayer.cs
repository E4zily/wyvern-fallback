﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000195 RID: 405
	[Token(Token = "0x2000195")]
	public class FakePlayer : MonoBehaviour
	{
		// Token: 0x06003CC9 RID: 15561 RVA: 0x00077070 File Offset: 0x00075270
		[Token(Token = "0x6003CC9")]
		[Address(RVA = "0x10DA6BC", Offset = "0x10DA6BC", VA = "0x10DA6BC")]
		public void ChangeState()
		{
			GameObject networkManager = this.NetworkManager;
			if (this.enable)
			{
				long active = 1L;
				networkManager.SetActive(active != 0L);
				return;
			}
			long active2 = 0L;
			networkManager.SetActive(active2 != 0L);
		}

		// Token: 0x06003CCA RID: 15562 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x10DA6F4", Offset = "0x10DA6F4", VA = "0x10DA6F4")]
		[Token(Token = "0x6003CCA")]
		public FakePlayer()
		{
		}

		// Token: 0x04000B1A RID: 2842
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000B1A")]
		public GameObject NetworkManager;

		// Token: 0x04000B1B RID: 2843
		[Token(Token = "0x4000B1B")]
		[FieldOffset(Offset = "0x20")]
		public bool enable;
	}
}
