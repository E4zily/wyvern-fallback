﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000194 RID: 404
	[Token(Token = "0x2000194")]
	public class PlayerList : MonoBehaviour
	{
		// Token: 0x06003CC7 RID: 15559 RVA: 0x0007704C File Offset: 0x0007524C
		[Address(RVA = "0x2A78728", Offset = "0x2A78728", VA = "0x2A78728")]
		[Token(Token = "0x6003CC7")]
		private void Update()
		{
			string[] array = new string[PhotonNetwork.PlayerList.actorNumber];
			this.usernames = array;
		}

		// Token: 0x06003CC8 RID: 15560 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003CC8")]
		[Address(RVA = "0x2A78960", Offset = "0x2A78960", VA = "0x2A78960")]
		public PlayerList()
		{
		}

		// Token: 0x04000B18 RID: 2840
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000B18")]
		public string[] usernames;

		// Token: 0x04000B19 RID: 2841
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B19")]
		public TMP_Text displaySpot;
	}
}
