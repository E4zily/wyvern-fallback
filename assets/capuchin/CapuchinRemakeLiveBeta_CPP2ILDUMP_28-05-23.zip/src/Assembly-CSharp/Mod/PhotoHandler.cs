﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

namespace Mod
{
	// Token: 0x02000191 RID: 401
	[Token(Token = "0x2000191")]
	[AddComponentMenu("CameraPhoto/PhotoHandler/Screen Shot DEMO")]
	public class PhotoHandler : MonoBehaviour
	{
		// Token: 0x06003CBC RID: 15548 RVA: 0x00076E8C File Offset: 0x0007508C
		[Address(RVA = "0x3052E94", Offset = "0x3052E94", VA = "0x3052E94")]
		[Token(Token = "0x6003CBC")]
		public void CaptureScreenShot()
		{
			Camera component = base.GetComponent<Camera>();
			this.cam = component;
		}

		// Token: 0x06003CBD RID: 15549 RVA: 0x00076EA8 File Offset: 0x000750A8
		[Address(RVA = "0x305317C", Offset = "0x305317C", VA = "0x305317C")]
		[Token(Token = "0x6003CBD")]
		private IEnumerator SendWebhook(string link, string messgae, byte[] photo)
		{
			PhotoHandler.<SendWebhook>d__15 <SendWebhook>d__ = new PhotoHandler.<SendWebhook>d__15((int)0L);
			<SendWebhook>d__.<>4__this = this;
			<SendWebhook>d__.link = link;
			<SendWebhook>d__.messgae = messgae;
			<SendWebhook>d__.photo = photo;
			throw new NullReferenceException();
		}

		// Token: 0x06003CBE RID: 15550 RVA: 0x00076EE8 File Offset: 0x000750E8
		[Token(Token = "0x6003CBE")]
		[Address(RVA = "0x3053240", Offset = "0x3053240", VA = "0x3053240")]
		private void Update()
		{
			this.previewCam.Render();
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003CBF RID: 15551 RVA: 0x00076F08 File Offset: 0x00075108
		[Address(RVA = "0x30532A4", Offset = "0x30532A4", VA = "0x30532A4")]
		[Token(Token = "0x6003CBF")]
		public PhotoHandler()
		{
			long num = 2L;
			this.res = (PhotoHandler.Resolution)num;
			this.webhooklink = "";
			this.Message = "New Photo!";
			this.FileName = "Photo";
			base..ctor();
		}

		// Token: 0x04000AFF RID: 2815
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000AFF")]
		public int captureWidth;

		// Token: 0x04000B00 RID: 2816
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000B00")]
		public int captureHeight;

		// Token: 0x04000B01 RID: 2817
		[Token(Token = "0x4000B01")]
		[FieldOffset(Offset = "0x20")]
		public PhotoHandler.Resolution res;

		// Token: 0x04000B02 RID: 2818
		[Token(Token = "0x4000B02")]
		[FieldOffset(Offset = "0x28")]
		public GameObject hideGameObject;

		// Token: 0x04000B03 RID: 2819
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000B03")]
		private Rect rect;

		// Token: 0x04000B04 RID: 2820
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000B04")]
		private RenderTexture renderTexture;

		// Token: 0x04000B05 RID: 2821
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000B05")]
		private Texture2D screenShot;

		// Token: 0x04000B06 RID: 2822
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000B06")]
		private Camera cam;

		// Token: 0x04000B07 RID: 2823
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000B07")]
		public string webhooklink;

		// Token: 0x04000B08 RID: 2824
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x4000B08")]
		public string Message;

		// Token: 0x04000B09 RID: 2825
		[Token(Token = "0x4000B09")]
		[FieldOffset(Offset = "0x68")]
		public string FileName;

		// Token: 0x04000B0A RID: 2826
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000B0A")]
		public Camera previewCam;

		// Token: 0x04000B0B RID: 2827
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4000B0B")]
		private float timer;

		// Token: 0x02000192 RID: 402
		[Token(Token = "0x2000192")]
		public enum Resolution
		{
			// Token: 0x04000B0D RID: 2829
			[Token(Token = "0x4000B0D")]
			_480p,
			// Token: 0x04000B0E RID: 2830
			[Token(Token = "0x4000B0E")]
			_720p,
			// Token: 0x04000B0F RID: 2831
			[Token(Token = "0x4000B0F")]
			_1080p,
			// Token: 0x04000B10 RID: 2832
			[Token(Token = "0x4000B10")]
			_4k
		}
	}
}
