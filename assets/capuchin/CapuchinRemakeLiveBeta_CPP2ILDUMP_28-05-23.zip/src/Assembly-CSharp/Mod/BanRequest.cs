﻿using System;
using System.Collections;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

namespace Mod
{
	// Token: 0x0200018E RID: 398
	[Token(Token = "0x200018E")]
	public class BanRequest : MonoBehaviour
	{
		// Token: 0x06003CA8 RID: 15528 RVA: 0x00076D2C File Offset: 0x00074F2C
		[Token(Token = "0x6003CA8")]
		[Address(RVA = "0x2BFE6F4", Offset = "0x2BFE6F4", VA = "0x2BFE6F4")]
		public void banReq()
		{
			string nickName = this.playerItem.player.<Owner>k__BackingField.nickName;
			if (nickName != null && nickName == null)
			{
				throw new ArrayTypeMismatchException();
			}
			IEnumerator routine = this.pinged();
			base.StartCoroutine(routine);
		}

		// Token: 0x06003CA9 RID: 15529 RVA: 0x00076D6C File Offset: 0x00074F6C
		[Address(RVA = "0x2BFE884", Offset = "0x2BFE884", VA = "0x2BFE884")]
		[Token(Token = "0x6003CA9")]
		public void LateUpdate()
		{
		}

		// Token: 0x06003CAA RID: 15530 RVA: 0x0000385A File Offset: 0x00001A5A
		[Address(RVA = "0x2BFE910", Offset = "0x2BFE910", VA = "0x2BFE910")]
		[Token(Token = "0x6003CAA")]
		public void selectPlayer(PlayerItem p)
		{
			this.playerItem = p;
		}

		// Token: 0x06003CAB RID: 15531 RVA: 0x00076D7C File Offset: 0x00074F7C
		[Address(RVA = "0x2BFE918", Offset = "0x2BFE918", VA = "0x2BFE918")]
		[Token(Token = "0x6003CAB")]
		public IEnumerator SendWebhook()
		{
			BanRequest.<SendWebhook>d__9 <SendWebhook>d__ = new BanRequest.<SendWebhook>d__9((int)0L);
			<SendWebhook>d__.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003CAC RID: 15532 RVA: 0x00076DA4 File Offset: 0x00074FA4
		[Address(RVA = "0x2BFE80C", Offset = "0x2BFE80C", VA = "0x2BFE80C")]
		[Token(Token = "0x6003CAC")]
		public IEnumerator pinged()
		{
			new BanRequest.<pinged>d__10((int)0L);
			throw new NullReferenceException();
		}

		// Token: 0x06003CAD RID: 15533 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003CAD")]
		[Address(RVA = "0x2BFE990", Offset = "0x2BFE990", VA = "0x2BFE990")]
		public BanRequest()
		{
		}

		// Token: 0x04000AF2 RID: 2802
		[Token(Token = "0x4000AF2")]
		[FieldOffset(Offset = "0x18")]
		public string wHookurl;

		// Token: 0x04000AF3 RID: 2803
		[Token(Token = "0x4000AF3")]
		[FieldOffset(Offset = "0x20")]
		public PlayerItem playerItem;

		// Token: 0x04000AF4 RID: 2804
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000AF4")]
		public bRequestPing uid;

		// Token: 0x04000AF5 RID: 2805
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000AF5")]
		public TMP_Dropdown dropdown;

		// Token: 0x04000AF6 RID: 2806
		[Token(Token = "0x4000AF6")]
		[FieldOffset(Offset = "0x38")]
		public TMP_Text title;

		// Token: 0x04000AF7 RID: 2807
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000AF7")]
		public string[] banReasons;
	}
}
