﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Video;

namespace Mod
{
	// Token: 0x020001A0 RID: 416
	[Token(Token = "0x20001A0")]
	public class TVScreenManager : MonoBehaviour
	{
		// Token: 0x06003CF6 RID: 15606 RVA: 0x00035CB0 File Offset: 0x00033EB0
		[Address(RVA = "0x3092490", Offset = "0x3092490", VA = "0x3092490")]
		[Token(Token = "0x6003CF6")]
		public void ITSHAPPENINGBRO()
		{
		}

		// Token: 0x06003CF7 RID: 15607 RVA: 0x000775A8 File Offset: 0x000757A8
		[Address(RVA = "0x3092590", Offset = "0x3092590", VA = "0x3092590")]
		[Token(Token = "0x6003CF7")]
		private void Update()
		{
			float deltaTime = Time.deltaTime;
			bool inRoom = PhotonNetwork.InRoom;
		}

		// Token: 0x06003CF8 RID: 15608 RVA: 0x000775C4 File Offset: 0x000757C4
		[Token(Token = "0x6003CF8")]
		[PunRPC]
		[Address(RVA = "0x309272C", Offset = "0x309272C", VA = "0x309272C")]
		public void BringTheTVDown()
		{
			GameObject gameObject = this.tv;
			long active = 1L;
			long num = 1L;
			gameObject.SetActive(active != 0L);
			Animator animator = this.Animator;
			long value = 1L;
			animator.SetBool("GoDown", value != 0L);
			GameObject gameObject2 = this.otherTVPart;
			this.levaemealone = (num != 0L);
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.otherotherTVPart;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			this.VideoPlayer.Play();
		}

		// Token: 0x06003CF9 RID: 15609 RVA: 0x00077634 File Offset: 0x00075834
		[PunRPC]
		[Token(Token = "0x6003CF9")]
		[Address(RVA = "0x30927DC", Offset = "0x30927DC", VA = "0x30927DC")]
		public void BringTVUp()
		{
			Animator animator = this.Animator;
			long value = 0L;
			animator.SetBool("GoDown", value != 0L);
			GameObject gameObject = this.otherTVPart;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.otherotherTVPart;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.VideoPlayer.Stop();
		}

		// Token: 0x06003CFA RID: 15610 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003CFA")]
		[Address(RVA = "0x3092874", Offset = "0x3092874", VA = "0x3092874")]
		public TVScreenManager()
		{
		}

		// Token: 0x04000B53 RID: 2899
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000B53")]
		public Animator Animator;

		// Token: 0x04000B54 RID: 2900
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B54")]
		public PhotonView PhotonView;

		// Token: 0x04000B55 RID: 2901
		[Token(Token = "0x4000B55")]
		[FieldOffset(Offset = "0x28")]
		public VideoPlayer VideoPlayer;

		// Token: 0x04000B56 RID: 2902
		[Token(Token = "0x4000B56")]
		[FieldOffset(Offset = "0x30")]
		public GameObject tv;

		// Token: 0x04000B57 RID: 2903
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000B57")]
		private bool levaemealone;

		// Token: 0x04000B58 RID: 2904
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000B58")]
		public GameObject otherTVPart;

		// Token: 0x04000B59 RID: 2905
		[Token(Token = "0x4000B59")]
		[FieldOffset(Offset = "0x48")]
		public GameObject otherotherTVPart;

		// Token: 0x04000B5A RID: 2906
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000B5A")]
		public float timer;

		// Token: 0x04000B5B RID: 2907
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x4000B5B")]
		public bool debug;
	}
}
