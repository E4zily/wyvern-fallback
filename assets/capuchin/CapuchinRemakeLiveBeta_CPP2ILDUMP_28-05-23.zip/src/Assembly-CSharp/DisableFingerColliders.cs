﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000BB RID: 187
[Token(Token = "0x20000BB")]
public class DisableFingerColliders : MonoBehaviour
{
	// Token: 0x06001A9E RID: 6814 RVA: 0x00034A88 File Offset: 0x00032C88
	[Address(RVA = "0x2EA5DE4", Offset = "0x2EA5DE4", VA = "0x2EA5DE4")]
	[Token(Token = "0x6001A9E")]
	private void method_0()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001A9F RID: 6815 RVA: 0x00034AB8 File Offset: 0x00032CB8
	[Address(RVA = "0x2EA5E30", Offset = "0x2EA5E30", VA = "0x2EA5E30")]
	[Token(Token = "0x6001A9F")]
	private void method_1()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AA0 RID: 6816 RVA: 0x00034AF8 File Offset: 0x00032CF8
	[Address(RVA = "0x2EA5E8C", Offset = "0x2EA5E8C", VA = "0x2EA5E8C")]
	[Token(Token = "0x6001AA0")]
	private void method_2()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AA1 RID: 6817 RVA: 0x00034B3C File Offset: 0x00032D3C
	[Address(RVA = "0x2EA5EE8", Offset = "0x2EA5EE8", VA = "0x2EA5EE8")]
	[Token(Token = "0x6001AA1")]
	private void method_3()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001AA2 RID: 6818 RVA: 0x00034B5C File Offset: 0x00032D5C
	[Address(RVA = "0x2EA5F44", Offset = "0x2EA5F44", VA = "0x2EA5F44")]
	[Token(Token = "0x6001AA2")]
	private void method_4()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2;
		if (<IsMine>k__BackingField)
		{
			active2 = 1L;
			return;
		}
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AA3 RID: 6819 RVA: 0x00034BA0 File Offset: 0x00032DA0
	[Address(RVA = "0x2EA5FA0", Offset = "0x2EA5FA0", VA = "0x2EA5FA0")]
	[Token(Token = "0x6001AA3")]
	private void method_5()
	{
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001AA4 RID: 6820 RVA: 0x00034BC0 File Offset: 0x00032DC0
	[Address(RVA = "0x2EA5FEC", Offset = "0x2EA5FEC", VA = "0x2EA5FEC")]
	[Token(Token = "0x6001AA4")]
	private void method_6()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AA5 RID: 6821 RVA: 0x00034BF0 File Offset: 0x00032DF0
	[Address(RVA = "0x2EA6038", Offset = "0x2EA6038", VA = "0x2EA6038")]
	[Token(Token = "0x6001AA5")]
	private void method_7()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AA6 RID: 6822 RVA: 0x00034C30 File Offset: 0x00032E30
	[Address(RVA = "0x2EA6094", Offset = "0x2EA6094", VA = "0x2EA6094")]
	[Token(Token = "0x6001AA6")]
	private void method_8()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 0L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001AA7 RID: 6823 RVA: 0x00034AB8 File Offset: 0x00032CB8
	[Address(RVA = "0x2EA6104", Offset = "0x2EA6104", VA = "0x2EA6104")]
	[Token(Token = "0x6001AA7")]
	private void method_9()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AA8 RID: 6824 RVA: 0x00034C84 File Offset: 0x00032E84
	[Address(RVA = "0x2EA6160", Offset = "0x2EA6160", VA = "0x2EA6160")]
	[Token(Token = "0x6001AA8")]
	private void method_10()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AA9 RID: 6825 RVA: 0x00034CC4 File Offset: 0x00032EC4
	[Address(RVA = "0x2EA61BC", Offset = "0x2EA61BC", VA = "0x2EA61BC")]
	[Token(Token = "0x6001AA9")]
	private void method_11()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 0L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001AAA RID: 6826 RVA: 0x00034BF0 File Offset: 0x00032DF0
	[Address(RVA = "0x2EA622C", Offset = "0x2EA622C", VA = "0x2EA622C")]
	[Token(Token = "0x6001AAA")]
	private void method_12()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AAB RID: 6827 RVA: 0x00034D18 File Offset: 0x00032F18
	[Address(RVA = "0x2EA6288", Offset = "0x2EA6288", VA = "0x2EA6288")]
	[Token(Token = "0x6001AAB")]
	private void method_13()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AAC RID: 6828 RVA: 0x00034C30 File Offset: 0x00032E30
	[Address(RVA = "0x2EA62E4", Offset = "0x2EA62E4", VA = "0x2EA62E4")]
	[Token(Token = "0x6001AAC")]
	private void method_14()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 0L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001AAD RID: 6829 RVA: 0x00034CC4 File Offset: 0x00032EC4
	[Address(RVA = "0x2EA6354", Offset = "0x2EA6354", VA = "0x2EA6354")]
	[Token(Token = "0x6001AAD")]
	private void method_15()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 0L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001AAE RID: 6830 RVA: 0x00034C30 File Offset: 0x00032E30
	[Address(RVA = "0x2EA63C4", Offset = "0x2EA63C4", VA = "0x2EA63C4")]
	[Token(Token = "0x6001AAE")]
	private void method_16()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 0L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001AAF RID: 6831 RVA: 0x00034BC0 File Offset: 0x00032DC0
	[Address(RVA = "0x2EA6434", Offset = "0x2EA6434", VA = "0x2EA6434")]
	[Token(Token = "0x6001AAF")]
	private void method_17()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AB0 RID: 6832 RVA: 0x00034D5C File Offset: 0x00032F5C
	[Address(RVA = "0x2EA6480", Offset = "0x2EA6480", VA = "0x2EA6480")]
	[Token(Token = "0x6001AB0")]
	private void method_18()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AB1 RID: 6833 RVA: 0x00034D8C File Offset: 0x00032F8C
	[Address(RVA = "0x2EA64CC", Offset = "0x2EA64CC", VA = "0x2EA64CC")]
	[Token(Token = "0x6001AB1")]
	private void method_19()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AB2 RID: 6834 RVA: 0x00034D8C File Offset: 0x00032F8C
	[Address(RVA = "0x2EA6528", Offset = "0x2EA6528", VA = "0x2EA6528")]
	[Token(Token = "0x6001AB2")]
	private void method_20()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AB3 RID: 6835 RVA: 0x00034DD0 File Offset: 0x00032FD0
	[Address(RVA = "0x2EA6584", Offset = "0x2EA6584", VA = "0x2EA6584")]
	[Token(Token = "0x6001AB3")]
	private void Update()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 1L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001AB4 RID: 6836 RVA: 0x00034E24 File Offset: 0x00033024
	[Address(RVA = "0x2EA65F4", Offset = "0x2EA65F4", VA = "0x2EA65F4")]
	[Token(Token = "0x6001AB4")]
	private void method_21()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AB5 RID: 6837 RVA: 0x00034AB8 File Offset: 0x00032CB8
	[Address(RVA = "0x2EA6650", Offset = "0x2EA6650", VA = "0x2EA6650")]
	[Token(Token = "0x6001AB5")]
	private void method_22()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AB6 RID: 6838 RVA: 0x00034E68 File Offset: 0x00033068
	[Address(RVA = "0x2EA66AC", Offset = "0x2EA66AC", VA = "0x2EA66AC")]
	[Token(Token = "0x6001AB6")]
	private void method_23()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001AB7 RID: 6839 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2EA6708", Offset = "0x2EA6708", VA = "0x2EA6708")]
	[Token(Token = "0x6001AB7")]
	public DisableFingerColliders()
	{
	}

	// Token: 0x06001AB8 RID: 6840 RVA: 0x00034EA8 File Offset: 0x000330A8
	[Address(RVA = "0x2EA6710", Offset = "0x2EA6710", VA = "0x2EA6710")]
	[Token(Token = "0x6001AB8")]
	private void method_24()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001AB9 RID: 6841 RVA: 0x00034BC0 File Offset: 0x00032DC0
	[Address(RVA = "0x2EA676C", Offset = "0x2EA676C", VA = "0x2EA676C")]
	[Token(Token = "0x6001AB9")]
	private void method_25()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001ABA RID: 6842 RVA: 0x00034EC8 File Offset: 0x000330C8
	[Address(RVA = "0x2EA67B8", Offset = "0x2EA67B8", VA = "0x2EA67B8")]
	[Token(Token = "0x6001ABA")]
	private void method_26()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		long active2 = 0L;
		gameObject.SetActive(active2 != 0L);
		long active3 = 1L;
		gameObject.SetActive(active3 != 0L);
	}

	// Token: 0x06001ABB RID: 6843 RVA: 0x00034F0C File Offset: 0x0003310C
	[Address(RVA = "0x2EA6828", Offset = "0x2EA6828", VA = "0x2EA6828")]
	[Token(Token = "0x6001ABB")]
	private void method_27()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 1L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		long active3 = 0L;
		gameObject2.SetActive(active3 != 0L);
	}

	// Token: 0x06001ABC RID: 6844 RVA: 0x00034AB8 File Offset: 0x00032CB8
	[Address(RVA = "0x2EA6898", Offset = "0x2EA6898", VA = "0x2EA6898")]
	[Token(Token = "0x6001ABC")]
	private void method_28()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001ABD RID: 6845 RVA: 0x00034E24 File Offset: 0x00033024
	[Address(RVA = "0x2EA68F4", Offset = "0x2EA68F4", VA = "0x2EA68F4")]
	[Token(Token = "0x6001ABD")]
	private void method_29()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		bool <IsMine>k__BackingField = photonView.<IsMine>k__BackingField;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		if (<IsMine>k__BackingField)
		{
			return;
		}
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06001ABE RID: 6846 RVA: 0x00034F58 File Offset: 0x00033158
	[Address(RVA = "0x2EA6950", Offset = "0x2EA6950", VA = "0x2EA6950")]
	[Token(Token = "0x6001ABE")]
	private void method_30()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		GameObject gameObject2;
		if (photonView.<IsMine>k__BackingField)
		{
			long active = 1L;
			gameObject.SetActive(active != 0L);
			gameObject2 = this.gameObject_1;
			return;
		}
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x04000370 RID: 880
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000370")]
	public PhotonView photonView_0;

	// Token: 0x04000371 RID: 881
	[Token(Token = "0x4000371")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_0;

	// Token: 0x04000372 RID: 882
	[Token(Token = "0x4000372")]
	[FieldOffset(Offset = "0x28")]
	public GameObject gameObject_1;
}
