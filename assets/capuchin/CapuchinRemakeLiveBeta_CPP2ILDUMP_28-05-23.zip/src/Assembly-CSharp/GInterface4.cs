﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000150 RID: 336
[Token(Token = "0x2000150")]
public interface GInterface4
{
	// Token: 0x060035CA RID: 13770
	[Address(Slot = "0")]
	[Token(Token = "0x60035CA")]
	void imethod_0(Collision collision_0, GEnum15 genum15_0);
}
