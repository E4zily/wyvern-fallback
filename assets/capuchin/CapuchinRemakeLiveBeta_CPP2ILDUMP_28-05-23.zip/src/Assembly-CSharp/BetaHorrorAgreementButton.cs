﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000005 RID: 5
[Token(Token = "0x2000005")]
public class BetaHorrorAgreementButton : MonoBehaviour
{
	// Token: 0x060000C0 RID: 192 RVA: 0x00004BCC File Offset: 0x00002DCC
	[Token(Token = "0x60000C0")]
	[Address(RVA = "0x3667160", Offset = "0x3667160", VA = "0x3667160")]
	public void method_0()
	{
		PlayerPrefs.GetString("openvr") == "Regular";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x00004C00 File Offset: 0x00002E00
	[Token(Token = "0x60000C1")]
	[Address(RVA = "0x36671E4", Offset = "0x36671E4", VA = "0x36671E4")]
	public void method_1()
	{
		PlayerPrefs.GetString("htc") == "CapuchinRemade";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00004C34 File Offset: 0x00002E34
	[Address(RVA = "0x3667268", Offset = "0x3667268", VA = "0x3667268")]
	[Token(Token = "0x60000C2")]
	public void method_2()
	{
		PlayerPrefs.GetString("FingerTip") == "Wear Hoodie";
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3667300", Offset = "0x3667300", VA = "0x3667300")]
	[Token(Token = "0x60000C3")]
	public void method_3(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x00004C58 File Offset: 0x00002E58
	[Token(Token = "0x60000C4")]
	[Address(RVA = "0x3667400", Offset = "0x3667400", VA = "0x3667400")]
	public void Start()
	{
		PlayerPrefs.GetString("HorrorAgreement") == "Agreed";
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x00004C7C File Offset: 0x00002E7C
	[Address(RVA = "0x3667498", Offset = "0x3667498", VA = "0x3667498")]
	[Token(Token = "0x60000C5")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("StartSong", "tutorialCheck");
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00004CA4 File Offset: 0x00002EA4
	[Token(Token = "0x60000C6")]
	[Address(RVA = "0x3667598", Offset = "0x3667598", VA = "0x3667598")]
	public void method_5()
	{
		PlayerPrefs.GetString("got funky mone") == "Tagged";
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x00004CC8 File Offset: 0x00002EC8
	[Address(RVA = "0x3667630", Offset = "0x3667630", VA = "0x3667630")]
	[Token(Token = "0x60000C7")]
	public void method_6()
	{
		PlayerPrefs.GetString("Room Name: ") == "typesOfTalk";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x00004CFC File Offset: 0x00002EFC
	[Address(RVA = "0x36676B4", Offset = "0x36676B4", VA = "0x36676B4")]
	[Token(Token = "0x60000C8")]
	public void method_7()
	{
		PlayerPrefs.GetString("true") == "username";
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x00004D20 File Offset: 0x00002F20
	[Token(Token = "0x60000C9")]
	[Address(RVA = "0x366774C", Offset = "0x366774C", VA = "0x366774C")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Removing ", "Stopped Colliding");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000CA RID: 202 RVA: 0x00004D58 File Offset: 0x00002F58
	[Address(RVA = "0x366784C", Offset = "0x366784C", VA = "0x366784C")]
	[Token(Token = "0x60000CA")]
	public void method_9()
	{
		PlayerPrefs.GetString("Date: ") == "clickLol";
	}

	// Token: 0x060000CB RID: 203 RVA: 0x00004D7C File Offset: 0x00002F7C
	[Token(Token = "0x60000CB")]
	[Address(RVA = "0x36678E4", Offset = "0x36678E4", VA = "0x36678E4")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Not connected to room", "Cannot access an empty buffer.");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000CC RID: 204 RVA: 0x00004DB4 File Offset: 0x00002FB4
	[Token(Token = "0x60000CC")]
	[Address(RVA = "0x36679E4", Offset = "0x36679E4", VA = "0x36679E4")]
	public void method_11()
	{
		PlayerPrefs.GetString("Joined a Room.") == "true";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00004DE8 File Offset: 0x00002FE8
	[Token(Token = "0x60000CD")]
	[Address(RVA = "0x3667A68", Offset = "0x3667A68", VA = "0x3667A68")]
	public void method_12(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Hats", "META");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000CE RID: 206 RVA: 0x00004E20 File Offset: 0x00003020
	[Address(RVA = "0x3667B68", Offset = "0x3667B68", VA = "0x3667B68")]
	[Token(Token = "0x60000CE")]
	public void method_13()
	{
		PlayerPrefs.GetString("Damaged Arm") == "/";
	}

	// Token: 0x060000CF RID: 207 RVA: 0x00004E44 File Offset: 0x00003044
	[Address(RVA = "0x3667C00", Offset = "0x3667C00", VA = "0x3667C00")]
	[Token(Token = "0x60000CF")]
	public void method_14()
	{
		string a;
		a == "M/d/yyyy";
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00004E60 File Offset: 0x00003060
	[Token(Token = "0x60000D0")]
	[Address(RVA = "0x3667C98", Offset = "0x3667C98", VA = "0x3667C98")]
	public void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("true", "Purchase For ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x00004E98 File Offset: 0x00003098
	[Token(Token = "0x60000D1")]
	[Address(RVA = "0x3667D98", Offset = "0x3667D98", VA = "0x3667D98")]
	public void method_16()
	{
		PlayerPrefs.GetString("gamemode") == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60000D2")]
	[Address(RVA = "0x3667E1C", Offset = "0x3667E1C", VA = "0x3667E1C")]
	public BetaHorrorAgreementButton()
	{
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x00004ECC File Offset: 0x000030CC
	[Token(Token = "0x60000D3")]
	[Address(RVA = "0x3667E24", Offset = "0x3667E24", VA = "0x3667E24")]
	public void method_17()
	{
		string a;
		a == "Cannot access index {0}. Buffer size is {1}";
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x00004EE8 File Offset: 0x000030E8
	[Token(Token = "0x60000D4")]
	[Address(RVA = "0x3667EBC", Offset = "0x3667EBC", VA = "0x3667EBC")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("gamemode", "You Already Own This Item");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x00004F20 File Offset: 0x00003120
	[Token(Token = "0x60000D5")]
	[Address(RVA = "0x3667FBC", Offset = "0x3667FBC", VA = "0x3667FBC")]
	public void method_19()
	{
		throw new MissingMethodException();
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x00004F34 File Offset: 0x00003134
	[Token(Token = "0x60000D6")]
	[Address(RVA = "0x3668040", Offset = "0x3668040", VA = "0x3668040")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Add/Remove Hat", "Tagged");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x00004F6C File Offset: 0x0000316C
	[Address(RVA = "0x3668140", Offset = "0x3668140", VA = "0x3668140")]
	[Token(Token = "0x60000D7")]
	public void method_21()
	{
		PlayerPrefs.GetString("Diffuse") == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x00004FA0 File Offset: 0x000031A0
	[Token(Token = "0x60000D8")]
	[Address(RVA = "0x36681C4", Offset = "0x36681C4", VA = "0x36681C4")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("HorrorAgreement", "Agreed");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x00004FD8 File Offset: 0x000031D8
	[Address(RVA = "0x36682C4", Offset = "0x36682C4", VA = "0x36682C4")]
	[Token(Token = "0x60000D9")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("spooky guy true", "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000DA RID: 218 RVA: 0x00005010 File Offset: 0x00003210
	[Address(RVA = "0x36683C4", Offset = "0x36683C4", VA = "0x36683C4")]
	[Token(Token = "0x60000DA")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("htc", "FingerTip");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000DB RID: 219 RVA: 0x00005048 File Offset: 0x00003248
	[Token(Token = "0x60000DB")]
	[Address(RVA = "0x36684C4", Offset = "0x36684C4", VA = "0x36684C4")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("goUpRPC", "Updating Material to: ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000DC RID: 220 RVA: 0x00005080 File Offset: 0x00003280
	[Address(RVA = "0x36685C4", Offset = "0x36685C4", VA = "0x36685C4")]
	[Token(Token = "0x60000DC")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("true", "Player");
	}

	// Token: 0x060000DD RID: 221 RVA: 0x000050A8 File Offset: 0x000032A8
	[Token(Token = "0x60000DD")]
	[Address(RVA = "0x36686C4", Offset = "0x36686C4", VA = "0x36686C4")]
	public void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000DE RID: 222 RVA: 0x000050D4 File Offset: 0x000032D4
	[Token(Token = "0x60000DE")]
	[Address(RVA = "0x36687C4", Offset = "0x36687C4", VA = "0x36687C4")]
	public void method_27()
	{
		PlayerPrefs.GetString("Round end") == "Cannot access index {0}. Buffer size is {1}";
	}

	// Token: 0x060000DF RID: 223 RVA: 0x000050F8 File Offset: 0x000032F8
	[Address(RVA = "0x366885C", Offset = "0x366885C", VA = "0x366885C")]
	[Token(Token = "0x60000DF")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Cannot access index {0}. Buffer is empty", "trol");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x00005130 File Offset: 0x00003330
	[Token(Token = "0x60000E0")]
	[Address(RVA = "0x366895C", Offset = "0x366895C", VA = "0x366895C")]
	public void method_29(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("NetworkPlayer", "duration done");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x00005168 File Offset: 0x00003368
	[Address(RVA = "0x3668A5C", Offset = "0x3668A5C", VA = "0x3668A5C")]
	[Token(Token = "0x60000E1")]
	public void method_30(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Network Player", "Skelechin");
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x00005190 File Offset: 0x00003390
	[Token(Token = "0x60000E2")]
	[Address(RVA = "0x3668B5C", Offset = "0x3668B5C", VA = "0x3668B5C")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("", "Name Changing Error. Error: ");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x000051C8 File Offset: 0x000033C8
	[Address(RVA = "0x3668C5C", Offset = "0x3668C5C", VA = "0x3668C5C")]
	[Token(Token = "0x60000E3")]
	public void method_32()
	{
		PlayerPrefs.GetString("PURCHASED!") == "EnableCosmetic";
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x000050A8 File Offset: 0x000032A8
	[Address(RVA = "0x3668CF4", Offset = "0x3668CF4", VA = "0x3668CF4")]
	[Token(Token = "0x60000E4")]
	public void method_33(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x000051EC File Offset: 0x000033EC
	[Address(RVA = "0x3668DF4", Offset = "0x3668DF4", VA = "0x3668DF4")]
	[Token(Token = "0x60000E5")]
	public void method_34()
	{
		PlayerPrefs.GetString("Combine textures & build combined mesh using coroutine") == "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x00005220 File Offset: 0x00003420
	[Token(Token = "0x60000E6")]
	[Address(RVA = "0x3668E78", Offset = "0x3668E78", VA = "0x3668E78")]
	public void method_35()
	{
		PlayerPrefs.GetString("knuckles") == "lava";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x00005254 File Offset: 0x00003454
	[Address(RVA = "0x3668EFC", Offset = "0x3668EFC", VA = "0x3668EFC")]
	[Token(Token = "0x60000E7")]
	public void method_36()
	{
		PlayerPrefs.GetString("retract broken") == "username";
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x00005278 File Offset: 0x00003478
	[Address(RVA = "0x3668F94", Offset = "0x3668F94", VA = "0x3668F94")]
	[Token(Token = "0x60000E8")]
	public void method_37(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("lava", "SetColor");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x000052B0 File Offset: 0x000034B0
	[Token(Token = "0x60000E9")]
	[Address(RVA = "0x3669094", Offset = "0x3669094", VA = "0x3669094")]
	public void method_38()
	{
		PlayerPrefs.GetString("ORGTARG") == "Version";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000EA RID: 234 RVA: 0x000052E4 File Offset: 0x000034E4
	[Token(Token = "0x60000EA")]
	[Address(RVA = "0x3669118", Offset = "0x3669118", VA = "0x3669118")]
	public void method_39(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Failed to get catalog, cosmetic name, and price. Exact error details is: ", "Player");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000EB RID: 235 RVA: 0x0000531C File Offset: 0x0000351C
	[Token(Token = "0x60000EB")]
	[Address(RVA = "0x3669218", Offset = "0x3669218", VA = "0x3669218")]
	public void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Player", "Player");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000EC RID: 236 RVA: 0x00005354 File Offset: 0x00003554
	[Address(RVA = "0x3669304", Offset = "0x3669304", VA = "0x3669304")]
	[Token(Token = "0x60000EC")]
	public void method_41(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("lava", "ENABLE");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000ED RID: 237 RVA: 0x0000538C File Offset: 0x0000358C
	[Token(Token = "0x60000ED")]
	[Address(RVA = "0x3669404", Offset = "0x3669404", VA = "0x3669404")]
	public void method_42(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("isLava", "PlayWave");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000EE RID: 238 RVA: 0x000053C4 File Offset: 0x000035C4
	[Token(Token = "0x60000EE")]
	[Address(RVA = "0x3669504", Offset = "0x3669504", VA = "0x3669504")]
	public void method_43()
	{
		PlayerPrefs.GetString("sound play stopped") == "Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}";
	}

	// Token: 0x060000EF RID: 239 RVA: 0x000053E8 File Offset: 0x000035E8
	[Address(RVA = "0x366959C", Offset = "0x366959C", VA = "0x366959C")]
	[Token(Token = "0x60000EF")]
	public void method_44()
	{
		PlayerPrefs.GetString("PRESS AGAIN TO CONFIRM") == " ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x0000541C File Offset: 0x0000361C
	[Token(Token = "0x60000F0")]
	[Address(RVA = "0x3669620", Offset = "0x3669620", VA = "0x3669620")]
	public void method_45(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("Regular", "username");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x00005454 File Offset: 0x00003654
	[Token(Token = "0x60000F1")]
	[Address(RVA = "0x3669720", Offset = "0x3669720", VA = "0x3669720")]
	public void method_46()
	{
		PlayerPrefs.GetString("Start Gamemode") == "Combine textures & build combined mesh all at once";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x00005488 File Offset: 0x00003688
	[Address(RVA = "0x36697A4", Offset = "0x36697A4", VA = "0x36697A4")]
	[Token(Token = "0x60000F2")]
	public void method_47(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("make more points bobo", "NGNNoSound");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x000054C0 File Offset: 0x000036C0
	[Token(Token = "0x60000F3")]
	[Address(RVA = "0x36698A4", Offset = "0x36698A4", VA = "0x36698A4")]
	public void method_48()
	{
		PlayerPrefs.GetString("goUpRPC") == "unlocked!";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x000054F4 File Offset: 0x000036F4
	[Token(Token = "0x60000F4")]
	[Address(RVA = "0x3669928", Offset = "0x3669928", VA = "0x3669928")]
	public void method_49()
	{
		PlayerPrefs.GetString("") == "Adding ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x00005528 File Offset: 0x00003728
	[Token(Token = "0x60000F5")]
	[Address(RVA = "0x36699AC", Offset = "0x36699AC", VA = "0x36699AC")]
	public void method_50(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		collider_0;
		PlayerPrefs.SetString("PushToTalk", "hh:mmtt");
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x00005564 File Offset: 0x00003764
	[Address(RVA = "0x3669AAC", Offset = "0x3669AAC", VA = "0x3669AAC")]
	[Token(Token = "0x60000F6")]
	public void method_51(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		PlayerPrefs.SetString("\n", "unlocked!");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x0000559C File Offset: 0x0000379C
	[Address(RVA = "0x3669BAC", Offset = "0x3669BAC", VA = "0x3669BAC")]
	[Token(Token = "0x60000F7")]
	public void method_52(Collider collider_0)
	{
		HandColliders exists;
		exists;
		PlayerPrefs.SetString("", "ORGTARG");
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x000055D0 File Offset: 0x000037D0
	[Token(Token = "0x60000F8")]
	[Address(RVA = "0x3669CAC", Offset = "0x3669CAC", VA = "0x3669CAC")]
	public void method_53()
	{
		PlayerPrefs.GetString("ENABLE") == "User has been reported for: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0400000A RID: 10
	[Token(Token = "0x400000A")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;
}
