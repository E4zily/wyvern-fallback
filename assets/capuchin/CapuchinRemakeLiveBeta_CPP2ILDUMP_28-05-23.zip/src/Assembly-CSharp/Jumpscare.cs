﻿using System;
using Cpp2IlInjected;
using Locomotion;
using UnityEngine;

// Token: 0x02000077 RID: 119
[Token(Token = "0x2000077")]
public class Jumpscare : MonoBehaviour
{
	// Token: 0x060010B0 RID: 4272 RVA: 0x00020268 File Offset: 0x0001E468
	[Token(Token = "0x60010B0")]
	[Address(RVA = "0x3128AF8", Offset = "0x3128AF8", VA = "0x3128AF8")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("FingerTip");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Tagged");
	}

	// Token: 0x060010B1 RID: 4273 RVA: 0x00020334 File Offset: 0x0001E534
	[Token(Token = "0x60010B1")]
	[Address(RVA = "0x3128DCC", Offset = "0x3128DCC", VA = "0x3128DCC")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "BN";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Right Hand");
	}

	// Token: 0x060010B2 RID: 4274 RVA: 0x00020400 File Offset: 0x0001E600
	[Address(RVA = "0x31290A0", Offset = "0x31290A0", VA = "0x31290A0")]
	[Token(Token = "0x60010B2")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "Holdable";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("BN");
	}

	// Token: 0x060010B3 RID: 4275 RVA: 0x000204CC File Offset: 0x0001E6CC
	[Token(Token = "0x60010B3")]
	[Address(RVA = "0x3129360", Offset = "0x3129360", VA = "0x3129360")]
	public void method_3()
	{
		Debug.Log("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("ENABLE");
		Debug.Log("PlayWave");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("ChangeToRegular");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("Player");
		Player.player_0.method_20();
		Debug.Log("vive");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Open");
	}

	// Token: 0x060010B4 RID: 4276 RVA: 0x000205A0 File Offset: 0x0001E7A0
	[Address(RVA = "0x3129570", Offset = "0x3129570", VA = "0x3129570")]
	[Token(Token = "0x60010B4")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("EnableCosmetic");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x060010B5 RID: 4277 RVA: 0x0002066C File Offset: 0x0001E86C
	[Token(Token = "0x60010B5")]
	[Address(RVA = "0x3129844", Offset = "0x3129844", VA = "0x3129844")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "HandR";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("This is the 5000 Bananas button, and it was just clicked");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("KeyPos");
	}

	// Token: 0x060010B6 RID: 4278 RVA: 0x00020738 File Offset: 0x0001E938
	[Address(RVA = "0x3129B18", Offset = "0x3129B18", VA = "0x3129B18")]
	[Token(Token = "0x60010B6")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("/");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Player");
	}

	// Token: 0x060010B7 RID: 4279 RVA: 0x00020804 File Offset: 0x0001EA04
	[Token(Token = "0x60010B7")]
	[Address(RVA = "0x3129DD8", Offset = "0x3129DD8", VA = "0x3129DD8")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "openvr";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("Display Name Changed!");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("FLSPTLT");
	}

	// Token: 0x060010B8 RID: 4280 RVA: 0x000208D0 File Offset: 0x0001EAD0
	[Token(Token = "0x60010B8")]
	[Address(RVA = "0x312A0AC", Offset = "0x312A0AC", VA = "0x312A0AC")]
	public void method_8()
	{
		Debug.Log("True");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("containsStaff");
		Debug.Log("Not connected to room");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("htc");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("PlayNoise");
		Player.player_0.method_20();
		Debug.Log("monke is not my monke");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Not enough amount of currency");
	}

	// Token: 0x060010B9 RID: 4281 RVA: 0x000209A4 File Offset: 0x0001EBA4
	[Token(Token = "0x60010B9")]
	[Address(RVA = "0x312A2BC", Offset = "0x312A2BC", VA = "0x312A2BC")]
	public void method_9()
	{
		Debug.Log("ChangeToTagged");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("PlayerHead");
		Debug.Log("Muted");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Bruh i cannot go here you stupid L bozo");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("closeToObject");
		Player.player_0.method_15();
		Debug.Log("PlayerDeath");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}");
	}

	// Token: 0x060010BA RID: 4282 RVA: 0x00020A78 File Offset: 0x0001EC78
	[Address(RVA = "0x312A4CC", Offset = "0x312A4CC", VA = "0x312A4CC")]
	[Token(Token = "0x60010BA")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("_Color");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("SetColor");
	}

	// Token: 0x060010BB RID: 4283 RVA: 0x00020B44 File Offset: 0x0001ED44
	[Address(RVA = "0x312A7A0", Offset = "0x312A7A0", VA = "0x312A7A0")]
	[Token(Token = "0x60010BB")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "True";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("Start Gamemode");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("manual footTimings length should be equal to the leg count");
	}

	// Token: 0x060010BC RID: 4284 RVA: 0x00020C10 File Offset: 0x0001EE10
	[Token(Token = "0x60010BC")]
	[Address(RVA = "0x312AA74", Offset = "0x312AA74", VA = "0x312AA74")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "Combine textures & build combined mesh using coroutine";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("true");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("gamemode");
	}

	// Token: 0x060010BD RID: 4285 RVA: 0x00020CDC File Offset: 0x0001EEDC
	[Address(RVA = "0x312AD48", Offset = "0x312AD48", VA = "0x312AD48")]
	[Token(Token = "0x60010BD")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("hand 1");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("sound play play");
	}

	// Token: 0x060010BE RID: 4286 RVA: 0x00020DA8 File Offset: 0x0001EFA8
	[Token(Token = "0x60010BE")]
	[Address(RVA = "0x312B018", Offset = "0x312B018", VA = "0x312B018")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("HandL");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("A new Player joined a Room.");
	}

	// Token: 0x060010BF RID: 4287 RVA: 0x00020E74 File Offset: 0x0001F074
	[Token(Token = "0x60010BF")]
	[Address(RVA = "0x312B2EC", Offset = "0x312B2EC", VA = "0x312B2EC")]
	public void method_14()
	{
		Debug.Log("PURCHASED");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("Add/Remove Glasses");
		Debug.Log("True");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("FLSPTLT");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("Tagging");
		Player.player_0.method_20();
		Debug.Log("PRESS AGAIN TO CONFIRM");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("5BN");
	}

	// Token: 0x060010C0 RID: 4288 RVA: 0x00020F48 File Offset: 0x0001F148
	[Token(Token = "0x60010C0")]
	[Address(RVA = "0x312B4FC", Offset = "0x312B4FC", VA = "0x312B4FC")]
	public void method_15()
	{
		Debug.Log("Song Index: ");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("GET");
		Debug.Log("Round end");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("cheeseTouch");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("BN");
		Player.player_0.method_15();
		Debug.Log("\tExpires: ");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Stopped Colliding");
	}

	// Token: 0x060010C1 RID: 4289 RVA: 0x0002101C File Offset: 0x0001F21C
	[Address(RVA = "0x312B70C", Offset = "0x312B70C", VA = "0x312B70C")]
	[Token(Token = "0x60010C1")]
	public void method_16()
	{
		Debug.Log("Wear Hoodie");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("'s Grabber is not assigned.");
		Debug.Log("PushToTalk");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("BN");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("oculus");
		Player.player_0.method_15();
		Debug.Log("Regular");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("procedural animation script required on ");
	}

	// Token: 0x060010C2 RID: 4290 RVA: 0x000210F0 File Offset: 0x0001F2F0
	[Address(RVA = "0x312B91C", Offset = "0x312B91C", VA = "0x312B91C")]
	[Token(Token = "0x60010C2")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "Bare Torso";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("Damaged Arm");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Players: ");
	}

	// Token: 0x060010C3 RID: 4291 RVA: 0x000211BC File Offset: 0x0001F3BC
	[Token(Token = "0x60010C3")]
	[Address(RVA = "0x312BBF0", Offset = "0x312BBF0", VA = "0x312BBF0")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "True";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("FingerTip");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("gamemode");
	}

	// Token: 0x060010C4 RID: 4292 RVA: 0x00021288 File Offset: 0x0001F488
	[Address(RVA = "0x312BEC4", Offset = "0x312BEC4", VA = "0x312BEC4")]
	[Token(Token = "0x60010C4")]
	public void method_19()
	{
		Debug.Log("You Look Like Butt");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("_Tint");
		Debug.Log("HandL");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("username");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("tp 2");
		Player.player_0.method_15();
		Debug.Log("Squeeze");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Player");
	}

	// Token: 0x060010C5 RID: 4293 RVA: 0x0002135C File Offset: 0x0001F55C
	[Token(Token = "0x60010C5")]
	[Address(RVA = "0x312C0D4", Offset = "0x312C0D4", VA = "0x312C0D4")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayWave";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("sound play stopped");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Player");
	}

	// Token: 0x060010C6 RID: 4294 RVA: 0x00021428 File Offset: 0x0001F628
	[Token(Token = "0x60010C6")]
	[Address(RVA = "0x312C3A8", Offset = "0x312C3A8", VA = "0x312C3A8")]
	public void method_21()
	{
		Debug.Log("EnableCosmetic");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("TurnAmount");
		Debug.Log("Cannot access index {0}. Buffer size is {1}");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Squeeze");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("hh:mm:sstt");
		Player.player_0.method_15();
		Debug.Log("containsStaff");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("poweredup!");
	}

	// Token: 0x060010C7 RID: 4295 RVA: 0x000214FC File Offset: 0x0001F6FC
	[Address(RVA = "0x312C5B8", Offset = "0x312C5B8", VA = "0x312C5B8")]
	[Token(Token = "0x60010C7")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "BN";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("You Already Own This Item");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Stopped Colliding");
	}

	// Token: 0x060010C8 RID: 4296 RVA: 0x000215C8 File Offset: 0x0001F7C8
	[Address(RVA = "0x312C88C", Offset = "0x312C88C", VA = "0x312C88C")]
	[Token(Token = "0x60010C8")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("Update User Inventory");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.");
	}

	// Token: 0x060010C9 RID: 4297 RVA: 0x00021694 File Offset: 0x0001F894
	[Token(Token = "0x60010C9")]
	[Address(RVA = "0x312CB60", Offset = "0x312CB60", VA = "0x312CB60")]
	public void method_24()
	{
		Debug.Log("Queue");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("_BumpScale");
		Debug.Log("PURCHASED!");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Push To Talk");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("Player");
		Player.player_0.method_15();
		Debug.Log("Collided");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("ChangeToTagged");
	}

	// Token: 0x060010CA RID: 4298 RVA: 0x00021768 File Offset: 0x0001F968
	[Token(Token = "0x60010CA")]
	[Address(RVA = "0x312CD70", Offset = "0x312CD70", VA = "0x312CD70")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "A new Player joined a Room.";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("Agreed");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("EnableCosmetic");
	}

	// Token: 0x060010CB RID: 4299 RVA: 0x00021834 File Offset: 0x0001FA34
	[Token(Token = "0x60010CB")]
	[Address(RVA = "0x312D044", Offset = "0x312D044", VA = "0x312D044")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("FingerTip");
	}

	// Token: 0x060010CC RID: 4300 RVA: 0x00021900 File Offset: 0x0001FB00
	[Address(RVA = "0x312D318", Offset = "0x312D318", VA = "0x312D318")]
	[Token(Token = "0x60010CC")]
	public void method_27()
	{
		Debug.Log("{0} ({1})");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("\tExpires: ");
		Debug.Log("Player");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Joined a Room.");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("trol");
		Player.player_0.method_15();
		Debug.Log("FingerTip");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Connected to Server.");
	}

	// Token: 0x060010CD RID: 4301 RVA: 0x000219D4 File Offset: 0x0001FBD4
	[Address(RVA = "0x312D528", Offset = "0x312D528", VA = "0x312D528")]
	[Token(Token = "0x60010CD")]
	public void method_28()
	{
		Debug.Log("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("Regular");
		Debug.Log("NetworkPlayer");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log(". Please update you game to the latest version");
		Player.player_0.method_20();
		Debug.Log("Update User Inventory");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("_WobbleX");
	}

	// Token: 0x060010CE RID: 4302 RVA: 0x00021AA8 File Offset: 0x0001FCA8
	[Address(RVA = "0x312D738", Offset = "0x312D738", VA = "0x312D738")]
	[Token(Token = "0x60010CE")]
	public void method_29()
	{
		Debug.Log("CapuchinStore");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("FLSPTLT");
		Debug.Log("'s Grabber is not assigned.");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("CapuchinRemade");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("Trying Getting Entilement...");
		Player.player_0.method_20();
		Debug.Log("FLSPTLT");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("false");
	}

	// Token: 0x060010CF RID: 4303 RVA: 0x00021B7C File Offset: 0x0001FD7C
	[Address(RVA = "0x312D934", Offset = "0x312D934", VA = "0x312D934")]
	[Token(Token = "0x60010CF")]
	public void method_30()
	{
		Debug.Log("Cannot take elements from an empty buffer.");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("_Tint");
		Debug.Log("username");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("True");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("retract broken");
		Player.player_0.method_20();
		Debug.Log("typesOfTalk");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("_Tint");
	}

	// Token: 0x060010D0 RID: 4304 RVA: 0x00021C50 File Offset: 0x0001FE50
	[Token(Token = "0x60010D0")]
	[Address(RVA = "0x312DB38", Offset = "0x312DB38", VA = "0x312DB38")]
	public void method_31()
	{
		Debug.Log("NetworkGunShoot");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("ChangeToRegular");
		Debug.Log("cheeseTouch");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("RightHandAttachPoint");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("Player");
		Player.player_0.method_15();
		Debug.Log("_Tint");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Applying to material");
	}

	// Token: 0x060010D1 RID: 4305 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60010D1")]
	[Address(RVA = "0x312DD48", Offset = "0x312DD48", VA = "0x312DD48")]
	public Jumpscare()
	{
	}

	// Token: 0x060010D2 RID: 4306 RVA: 0x00021D24 File Offset: 0x0001FF24
	[Token(Token = "0x60010D2")]
	[Address(RVA = "0x312DD50", Offset = "0x312DD50", VA = "0x312DD50")]
	public void method_32()
	{
		Debug.Log("Cannot access index {0}. Buffer is empty");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("TurnAmount");
		Debug.Log("Failed to login, please restart");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Holdable");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("_Tint");
		Player.player_0.method_15();
		Debug.Log("username");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Regular");
	}

	// Token: 0x060010D3 RID: 4307 RVA: 0x00021DF8 File Offset: 0x0001FFF8
	[Address(RVA = "0x312DF60", Offset = "0x312DF60", VA = "0x312DF60")]
	[Token(Token = "0x60010D3")]
	public void method_33()
	{
		throw new MissingMethodException();
	}

	// Token: 0x060010D4 RID: 4308 RVA: 0x00021E0C File Offset: 0x0002000C
	[Token(Token = "0x60010D4")]
	[Address(RVA = "0x312E150", Offset = "0x312E150", VA = "0x312E150")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "Add/Remove Hat";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("FingerTip");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("username");
	}

	// Token: 0x060010D5 RID: 4309 RVA: 0x00021ED8 File Offset: 0x000200D8
	[Address(RVA = "0x312E424", Offset = "0x312E424", VA = "0x312E424")]
	[Token(Token = "0x60010D5")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "True";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("ChangeToRegular");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}");
	}

	// Token: 0x060010D6 RID: 4310 RVA: 0x00021FA4 File Offset: 0x000201A4
	[Token(Token = "0x60010D6")]
	[Address(RVA = "0x312E6F8", Offset = "0x312E6F8", VA = "0x312E6F8")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "deathScream";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("We don't need this electrical box");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Player");
	}

	// Token: 0x060010D7 RID: 4311 RVA: 0x00022070 File Offset: 0x00020270
	[Token(Token = "0x60010D7")]
	[Address(RVA = "0x312E9CC", Offset = "0x312E9CC", VA = "0x312E9CC")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "Update User Inventory";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("Bare Torso");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("manual footTimings length should be equal to the leg count");
	}

	// Token: 0x060010D8 RID: 4312 RVA: 0x0002213C File Offset: 0x0002033C
	[Address(RVA = "0x312ECA0", Offset = "0x312ECA0", VA = "0x312ECA0")]
	[Token(Token = "0x60010D8")]
	public void method_38()
	{
		Debug.Log("forced knee");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("Player");
		Debug.Log("HorrorAgreement");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Player");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("");
		Player.player_0.method_15();
		Debug.Log("");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("/");
	}

	// Token: 0x060010D9 RID: 4313 RVA: 0x00022210 File Offset: 0x00020410
	[Token(Token = "0x60010D9")]
	[Address(RVA = "0x312EE88", Offset = "0x312EE88", VA = "0x312EE88")]
	public void method_39()
	{
		Debug.Log("EnableCosmetic");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("Player");
		Debug.Log("Round end");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("lock unlocked!");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("SaveHeight");
		Player.player_0.method_15();
		Debug.Log("_Tint");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("CapuchinRemade");
	}

	// Token: 0x060010DA RID: 4314 RVA: 0x000222E4 File Offset: 0x000204E4
	[Token(Token = "0x60010DA")]
	[Address(RVA = "0x312F098", Offset = "0x312F098", VA = "0x312F098")]
	public void method_40()
	{
		Debug.Log("waited for your bullshit unity grrr");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("sound play stopped");
		Debug.Log("duration done");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("spooky guy true");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("jump char false");
		Player.player_0.method_20();
		Debug.Log("hand 2");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("tp 2");
	}

	// Token: 0x060010DB RID: 4315 RVA: 0x000223B8 File Offset: 0x000205B8
	[Token(Token = "0x60010DB")]
	[Address(RVA = "0x312F2A8", Offset = "0x312F2A8", VA = "0x312F2A8")]
	public void method_41()
	{
		Debug.Log("PURCHASED");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("token");
		Debug.Log("Player");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("got funky mone");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("liftoff failed!");
		Player.player_0.method_15();
		Debug.Log("Cannot access an empty buffer.");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Regular");
	}

	// Token: 0x060010DC RID: 4316 RVA: 0x0002248C File Offset: 0x0002068C
	[Address(RVA = "0x312F4B8", Offset = "0x312F4B8", VA = "0x312F4B8")]
	[Token(Token = "0x60010DC")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.tag == "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("username");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("hand 1");
	}

	// Token: 0x060010DD RID: 4317 RVA: 0x00022558 File Offset: 0x00020758
	[Token(Token = "0x60010DD")]
	[Address(RVA = "0x312F78C", Offset = "0x312F78C", VA = "0x312F78C")]
	public void method_43()
	{
		Debug.Log("NoseAttachPoint");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("DisableCosmetic");
		Debug.Log("PlayerHead");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("username");
		Player.player_0.method_20();
		Debug.Log("Players: ");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Hate Speech");
	}

	// Token: 0x060010DE RID: 4318 RVA: 0x0002262C File Offset: 0x0002082C
	[Address(RVA = "0x312F99C", Offset = "0x312F99C", VA = "0x312F99C")]
	[Token(Token = "0x60010DE")]
	public void method_44()
	{
		Debug.Log("lava");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("Muted");
		Debug.Log("\n");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("\tExpires: ");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("Open");
		Player.player_0.method_15();
		Debug.Log("down unstuck");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("You Look Like Butt");
	}

	// Token: 0x060010DF RID: 4319 RVA: 0x00022700 File Offset: 0x00020900
	[Token(Token = "0x60010DF")]
	[Address(RVA = "0x312FBAC", Offset = "0x312FBAC", VA = "0x312FBAC")]
	public void method_45()
	{
		Debug.Log("PlayWave");
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("Starting to bake textures on frame ");
		Debug.Log("RightHandAttachPoint");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("https://raw.githubusercontent.com/");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("CapuchinRemade");
		Player.player_0.method_15();
		Debug.Log("forced knee");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("DISABLE");
	}

	// Token: 0x060010E0 RID: 4320 RVA: 0x000227D4 File Offset: 0x000209D4
	[Token(Token = "0x60010E0")]
	[Address(RVA = "0x312FDBC", Offset = "0x312FDBC", VA = "0x312FDBC")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.tag == "cheese";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("username");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("hh:mm:sstt");
	}

	// Token: 0x060010E1 RID: 4321 RVA: 0x000228A0 File Offset: 0x00020AA0
	[Address(RVA = "0x3130090", Offset = "0x3130090", VA = "0x3130090")]
	[Token(Token = "0x60010E1")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.tag == "Failed To Join Public Room Successfully. The error is: ";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_20();
		Debug.Log("CapuchinRemade");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("FingerTip");
	}

	// Token: 0x060010E2 RID: 4322 RVA: 0x0002296C File Offset: 0x00020B6C
	[Token(Token = "0x60010E2")]
	[Address(RVA = "0x3130364", Offset = "0x3130364", VA = "0x3130364")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Tint";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("FingerTip");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("Combine textures & build combined mesh all at once");
	}

	// Token: 0x060010E3 RID: 4323 RVA: 0x00022A38 File Offset: 0x00020C38
	[Token(Token = "0x60010E3")]
	[Address(RVA = "0x3130638", Offset = "0x3130638", VA = "0x3130638")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log("PlayerHead");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log(". Please update you game to the latest version");
	}

	// Token: 0x060010E4 RID: 4324 RVA: 0x00022B04 File Offset: 0x00020D04
	[Token(Token = "0x60010E4")]
	[Address(RVA = "0x313090C", Offset = "0x313090C", VA = "0x313090C")]
	public void method_50()
	{
		Debug.Log("Failed To Join Public Room Successfully. The error is: ");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("Room Name: ");
		Debug.Log("PURCHASE");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("Player");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("All audio clips have been played.");
		Player.player_0.method_15();
		Debug.Log("Is Colliding");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("Charging...");
	}

	// Token: 0x060010E5 RID: 4325 RVA: 0x00022BD8 File Offset: 0x00020DD8
	[Token(Token = "0x60010E5")]
	[Address(RVA = "0x3130B1C", Offset = "0x3130B1C", VA = "0x3130B1C")]
	public void method_51(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 0L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Vector3 position = base.transform.position;
		Quaternion identity = Quaternion.identity;
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Player.player_0.method_15();
		Debug.Log(".Please press the button if you would like to play alone");
		Transform transform = this.transform_0;
		Vector3 position2 = transform.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		this.audioSource_0.Play();
		Debug.Log("username");
	}

	// Token: 0x060010E6 RID: 4326 RVA: 0x00022CA4 File Offset: 0x00020EA4
	[Address(RVA = "0x3130DF0", Offset = "0x3130DF0", VA = "0x3130DF0")]
	[Token(Token = "0x60010E6")]
	public void method_52()
	{
		Debug.Log("Version");
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		this.audioSource_0.Stop();
		Debug.Log("spatial");
		Debug.Log("{0}/{1:f0}");
		GameObject gameObject2 = this.gameObject_2;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		Debug.Log("liftoff failed!");
		GameObject gameObject3 = this.gameObject_0;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
		Debug.Log("Charged!");
		Player.player_0.method_15();
		Debug.Log("A new Player joined a Room.");
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		Transform transform2 = this.transform_1;
		Vector3 position2 = transform2.position;
		Rigidbody rigidbody = this.rigidbody_0;
		long isKinematic = 1L;
		rigidbody.isKinematic = (isKinematic != 0L);
		Debug.Log("PURCHASE");
	}

	// Token: 0x04000266 RID: 614
	[Token(Token = "0x4000266")]
	[FieldOffset(Offset = "0x18")]
	public float float_0;

	// Token: 0x04000267 RID: 615
	[Token(Token = "0x4000267")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_0;

	// Token: 0x04000268 RID: 616
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000268")]
	public GameObject gameObject_1;

	// Token: 0x04000269 RID: 617
	[Token(Token = "0x4000269")]
	[FieldOffset(Offset = "0x30")]
	public AudioSource audioSource_0;

	// Token: 0x0400026A RID: 618
	[Token(Token = "0x400026A")]
	[FieldOffset(Offset = "0x38")]
	public GameObject gameObject_2;

	// Token: 0x0400026B RID: 619
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400026B")]
	public Transform transform_0;

	// Token: 0x0400026C RID: 620
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400026C")]
	public Transform transform_1;

	// Token: 0x0400026D RID: 621
	[Token(Token = "0x400026D")]
	[FieldOffset(Offset = "0x50")]
	public Transform transform_2;

	// Token: 0x0400026E RID: 622
	[Token(Token = "0x400026E")]
	[FieldOffset(Offset = "0x58")]
	public Transform transform_3;

	// Token: 0x0400026F RID: 623
	[Token(Token = "0x400026F")]
	[FieldOffset(Offset = "0x60")]
	public Rigidbody rigidbody_0;
}
