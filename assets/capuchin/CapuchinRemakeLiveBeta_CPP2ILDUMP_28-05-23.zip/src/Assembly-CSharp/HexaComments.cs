﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000A1 RID: 161
[Token(Token = "0x20000A1")]
public class HexaComments : MonoBehaviour
{
	// Token: 0x060017A0 RID: 6048 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x326DA5C", Offset = "0x326DA5C", VA = "0x326DA5C")]
	[Token(Token = "0x60017A0")]
	public HexaComments()
	{
	}

	// Token: 0x0400030C RID: 780
	[Multiline]
	[Token(Token = "0x400030C")]
	[FieldOffset(Offset = "0x18")]
	public string string_0;
}
