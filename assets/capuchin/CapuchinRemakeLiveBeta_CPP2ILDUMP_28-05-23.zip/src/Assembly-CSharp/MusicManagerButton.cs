﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000092 RID: 146
[Token(Token = "0x2000092")]
public class MusicManagerButton : MonoBehaviour
{
	// Token: 0x060014D1 RID: 5329 RVA: 0x00029630 File Offset: 0x00027830
	[Token(Token = "0x60014D1")]
	[Address(RVA = "0x2E70F9C", Offset = "0x2E70F9C", VA = "0x2E70F9C")]
	public void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x060014D2 RID: 5330 RVA: 0x00029644 File Offset: 0x00027844
	[Address(RVA = "0x2E7105C", Offset = "0x2E7105C", VA = "0x2E7105C")]
	[Token(Token = "0x60014D2")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_2();
	}

	// Token: 0x060014D3 RID: 5331 RVA: 0x00029668 File Offset: 0x00027868
	[Token(Token = "0x60014D3")]
	[Address(RVA = "0x2E7111C", Offset = "0x2E7111C", VA = "0x2E7111C")]
	public void method_2(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_36();
	}

	// Token: 0x060014D4 RID: 5332 RVA: 0x0002968C File Offset: 0x0002788C
	[Token(Token = "0x60014D4")]
	[Address(RVA = "0x2E711DC", Offset = "0x2E711DC", VA = "0x2E711DC")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_25();
	}

	// Token: 0x060014D5 RID: 5333 RVA: 0x000296B0 File Offset: 0x000278B0
	[Address(RVA = "0x2E7129C", Offset = "0x2E7129C", VA = "0x2E7129C")]
	[Token(Token = "0x60014D5")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_34();
	}

	// Token: 0x060014D6 RID: 5334 RVA: 0x000296D4 File Offset: 0x000278D4
	[Token(Token = "0x60014D6")]
	[Address(RVA = "0x2E7135C", Offset = "0x2E7135C", VA = "0x2E7135C")]
	public void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_32();
	}

	// Token: 0x060014D7 RID: 5335 RVA: 0x00029668 File Offset: 0x00027868
	[Address(RVA = "0x2E7141C", Offset = "0x2E7141C", VA = "0x2E7141C")]
	[Token(Token = "0x60014D7")]
	public void method_6(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_36();
	}

	// Token: 0x060014D8 RID: 5336 RVA: 0x0002968C File Offset: 0x0002788C
	[Address(RVA = "0x2E714DC", Offset = "0x2E714DC", VA = "0x2E714DC")]
	[Token(Token = "0x60014D8")]
	public void method_7(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_25();
	}

	// Token: 0x060014D9 RID: 5337 RVA: 0x000296B0 File Offset: 0x000278B0
	[Address(RVA = "0x2E7159C", Offset = "0x2E7159C", VA = "0x2E7159C")]
	[Token(Token = "0x60014D9")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_34();
	}

	// Token: 0x060014DA RID: 5338 RVA: 0x0002968C File Offset: 0x0002788C
	[Address(RVA = "0x2E7165C", Offset = "0x2E7165C", VA = "0x2E7165C")]
	[Token(Token = "0x60014DA")]
	public void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_25();
	}

	// Token: 0x060014DB RID: 5339 RVA: 0x000296F8 File Offset: 0x000278F8
	[Address(RVA = "0x2E7171C", Offset = "0x2E7171C", VA = "0x2E7171C")]
	[Token(Token = "0x60014DB")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		collider_0;
		this.musicManager_0.method_5();
	}

	// Token: 0x060014DC RID: 5340 RVA: 0x0002968C File Offset: 0x0002788C
	[Address(RVA = "0x2E717DC", Offset = "0x2E717DC", VA = "0x2E717DC")]
	[Token(Token = "0x60014DC")]
	public void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_25();
	}

	// Token: 0x060014DD RID: 5341 RVA: 0x00029668 File Offset: 0x00027868
	[Address(RVA = "0x2E7189C", Offset = "0x2E7189C", VA = "0x2E7189C")]
	[Token(Token = "0x60014DD")]
	public void method_12(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_36();
	}

	// Token: 0x060014DE RID: 5342 RVA: 0x000296B0 File Offset: 0x000278B0
	[Address(RVA = "0x2E7195C", Offset = "0x2E7195C", VA = "0x2E7195C")]
	[Token(Token = "0x60014DE")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_34();
	}

	// Token: 0x060014DF RID: 5343 RVA: 0x00029720 File Offset: 0x00027920
	[Address(RVA = "0x2E71A1C", Offset = "0x2E71A1C", VA = "0x2E71A1C")]
	[Token(Token = "0x60014DF")]
	public void method_14(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_15();
	}

	// Token: 0x060014E0 RID: 5344 RVA: 0x00029744 File Offset: 0x00027944
	[Token(Token = "0x60014E0")]
	[Address(RVA = "0x2E71ADC", Offset = "0x2E71ADC", VA = "0x2E71ADC")]
	public void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_44();
	}

	// Token: 0x060014E1 RID: 5345 RVA: 0x000296B0 File Offset: 0x000278B0
	[Token(Token = "0x60014E1")]
	[Address(RVA = "0x2E71B9C", Offset = "0x2E71B9C", VA = "0x2E71B9C")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_34();
	}

	// Token: 0x060014E2 RID: 5346 RVA: 0x00029720 File Offset: 0x00027920
	[Address(RVA = "0x2E71C5C", Offset = "0x2E71C5C", VA = "0x2E71C5C")]
	[Token(Token = "0x60014E2")]
	public void method_17(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_15();
	}

	// Token: 0x060014E3 RID: 5347 RVA: 0x0001C40C File Offset: 0x0001A60C
	[Address(RVA = "0x2E71D1C", Offset = "0x2E71D1C", VA = "0x2E71D1C")]
	[Token(Token = "0x60014E3")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x060014E4 RID: 5348 RVA: 0x00029668 File Offset: 0x00027868
	[Token(Token = "0x60014E4")]
	[Address(RVA = "0x2E71DDC", Offset = "0x2E71DDC", VA = "0x2E71DDC")]
	public void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_36();
	}

	// Token: 0x060014E5 RID: 5349 RVA: 0x000296B0 File Offset: 0x000278B0
	[Token(Token = "0x60014E5")]
	[Address(RVA = "0x2E71E9C", Offset = "0x2E71E9C", VA = "0x2E71E9C")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_34();
	}

	// Token: 0x060014E6 RID: 5350 RVA: 0x00029720 File Offset: 0x00027920
	[Address(RVA = "0x2E71F5C", Offset = "0x2E71F5C", VA = "0x2E71F5C")]
	[Token(Token = "0x60014E6")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_15();
	}

	// Token: 0x060014E7 RID: 5351 RVA: 0x00029768 File Offset: 0x00027968
	[Token(Token = "0x60014E7")]
	[Address(RVA = "0x2E7201C", Offset = "0x2E7201C", VA = "0x2E7201C")]
	public void method_22(Collider collider_0)
	{
		HandColliders exists;
		exists;
		this.musicManager_0.method_14();
	}

	// Token: 0x060014E8 RID: 5352 RVA: 0x00029788 File Offset: 0x00027988
	[Address(RVA = "0x2E720DC", Offset = "0x2E720DC", VA = "0x2E720DC")]
	[Token(Token = "0x60014E8")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_5();
	}

	// Token: 0x060014E9 RID: 5353 RVA: 0x00029668 File Offset: 0x00027868
	[Token(Token = "0x60014E9")]
	[Address(RVA = "0x2E7219C", Offset = "0x2E7219C", VA = "0x2E7219C")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_36();
	}

	// Token: 0x060014EA RID: 5354 RVA: 0x00029668 File Offset: 0x00027868
	[Address(RVA = "0x2E7225C", Offset = "0x2E7225C", VA = "0x2E7225C")]
	[Token(Token = "0x60014EA")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_36();
	}

	// Token: 0x060014EB RID: 5355 RVA: 0x000297AC File Offset: 0x000279AC
	[Token(Token = "0x60014EB")]
	[Address(RVA = "0x2E7231C", Offset = "0x2E7231C", VA = "0x2E7231C")]
	public void method_26(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_14();
	}

	// Token: 0x060014EC RID: 5356 RVA: 0x000296D4 File Offset: 0x000278D4
	[Address(RVA = "0x2E723DC", Offset = "0x2E723DC", VA = "0x2E723DC")]
	[Token(Token = "0x60014EC")]
	public void method_27(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_32();
	}

	// Token: 0x060014ED RID: 5357 RVA: 0x0002968C File Offset: 0x0002788C
	[Token(Token = "0x60014ED")]
	[Address(RVA = "0x2E7249C", Offset = "0x2E7249C", VA = "0x2E7249C")]
	public void method_28(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_25();
	}

	// Token: 0x060014EE RID: 5358 RVA: 0x000296D4 File Offset: 0x000278D4
	[Address(RVA = "0x2E7255C", Offset = "0x2E7255C", VA = "0x2E7255C")]
	[Token(Token = "0x60014EE")]
	public void method_29(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_32();
	}

	// Token: 0x060014EF RID: 5359 RVA: 0x00029788 File Offset: 0x00027988
	[Address(RVA = "0x2E7261C", Offset = "0x2E7261C", VA = "0x2E7261C")]
	[Token(Token = "0x60014EF")]
	public void method_30(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_5();
	}

	// Token: 0x060014F0 RID: 5360 RVA: 0x00029788 File Offset: 0x00027988
	[Address(RVA = "0x2E726DC", Offset = "0x2E726DC", VA = "0x2E726DC")]
	[Token(Token = "0x60014F0")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_5();
	}

	// Token: 0x060014F1 RID: 5361 RVA: 0x000296B0 File Offset: 0x000278B0
	[Address(RVA = "0x2E7279C", Offset = "0x2E7279C", VA = "0x2E7279C")]
	[Token(Token = "0x60014F1")]
	public void method_31(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_34();
	}

	// Token: 0x060014F2 RID: 5362 RVA: 0x000297AC File Offset: 0x000279AC
	[Address(RVA = "0x2E7285C", Offset = "0x2E7285C", VA = "0x2E7285C")]
	[Token(Token = "0x60014F2")]
	public void method_32(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_14();
	}

	// Token: 0x060014F3 RID: 5363 RVA: 0x0001C40C File Offset: 0x0001A60C
	[Address(RVA = "0x2E7291C", Offset = "0x2E7291C", VA = "0x2E7291C")]
	[Token(Token = "0x60014F3")]
	public void method_33(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
	}

	// Token: 0x060014F4 RID: 5364 RVA: 0x000296D4 File Offset: 0x000278D4
	[Address(RVA = "0x2E729DC", Offset = "0x2E729DC", VA = "0x2E729DC")]
	[Token(Token = "0x60014F4")]
	public void method_34(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_32();
	}

	// Token: 0x060014F5 RID: 5365 RVA: 0x000297D0 File Offset: 0x000279D0
	[Address(RVA = "0x2E72A9C", Offset = "0x2E72A9C", VA = "0x2E72A9C")]
	[Token(Token = "0x60014F5")]
	public void method_35(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_14();
	}

	// Token: 0x060014F6 RID: 5366 RVA: 0x00029644 File Offset: 0x00027844
	[Token(Token = "0x60014F6")]
	[Address(RVA = "0x2E72B5C", Offset = "0x2E72B5C", VA = "0x2E72B5C")]
	public void method_36(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_2();
	}

	// Token: 0x060014F7 RID: 5367 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60014F7")]
	[Address(RVA = "0x2E72C1C", Offset = "0x2E72C1C", VA = "0x2E72C1C")]
	public MusicManagerButton()
	{
	}

	// Token: 0x060014F8 RID: 5368 RVA: 0x000297AC File Offset: 0x000279AC
	[Address(RVA = "0x2E72C24", Offset = "0x2E72C24", VA = "0x2E72C24")]
	[Token(Token = "0x60014F8")]
	public void method_37(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_14();
	}

	// Token: 0x060014F9 RID: 5369 RVA: 0x00029644 File Offset: 0x00027844
	[Token(Token = "0x60014F9")]
	[Address(RVA = "0x2E72CE4", Offset = "0x2E72CE4", VA = "0x2E72CE4")]
	public void method_38(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_2();
	}

	// Token: 0x060014FA RID: 5370 RVA: 0x000297AC File Offset: 0x000279AC
	[Address(RVA = "0x2E72DA4", Offset = "0x2E72DA4", VA = "0x2E72DA4")]
	[Token(Token = "0x60014FA")]
	public void method_39(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_14();
	}

	// Token: 0x060014FB RID: 5371 RVA: 0x000296D4 File Offset: 0x000278D4
	[Token(Token = "0x60014FB")]
	[Address(RVA = "0x2E72E64", Offset = "0x2E72E64", VA = "0x2E72E64")]
	public void method_40(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		this.musicManager_0.method_32();
	}

	// Token: 0x040002C2 RID: 706
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002C2")]
	public MusicManager musicManager_0;
}
