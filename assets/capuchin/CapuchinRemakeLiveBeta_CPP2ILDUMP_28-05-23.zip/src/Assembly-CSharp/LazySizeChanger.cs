﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000D7 RID: 215
[Token(Token = "0x20000D7")]
public class LazySizeChanger : MonoBehaviourPunCallbacks
{
	// Token: 0x06001F9D RID: 8093 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8B484", Offset = "0x2D8B484", VA = "0x2D8B484")]
	[Token(Token = "0x6001F9D")]
	public void method_0()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001F9E RID: 8094 RVA: 0x0003BA08 File Offset: 0x00039C08
	[Address(RVA = "0x2D8B550", Offset = "0x2D8B550", VA = "0x2D8B550")]
	[Token(Token = "0x6001F9E")]
	public void method_1()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			this.sizeChecker_1.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_2;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
		}
		SizeChecker sizeChecker3 = this.sizeChecker_0;
		float num3 = this.float_0;
		sizeChecker3.float_0 = num3;
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001F9F RID: 8095 RVA: 0x0003BAA0 File Offset: 0x00039CA0
	[Address(RVA = "0x2D8B61C", Offset = "0x2D8B61C", VA = "0x2D8B61C")]
	[Token(Token = "0x6001F9F")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "Tagging";
		this.bool_0 = (257 != 0);
		this.method_39();
	}

	// Token: 0x06001FA0 RID: 8096 RVA: 0x0003BAD4 File Offset: 0x00039CD4
	[Address(RVA = "0x2D8B808", Offset = "0x2D8B808", VA = "0x2D8B808")]
	[Token(Token = "0x6001FA0")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.tag == "poweredup!";
		this.bool_0 = (257 != 0);
		this.method_42();
	}

	// Token: 0x06001FA1 RID: 8097 RVA: 0x0003BB08 File Offset: 0x00039D08
	[Address(RVA = "0x2D8B9F4", Offset = "0x2D8B9F4", VA = "0x2D8B9F4")]
	[Token(Token = "0x6001FA1")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		this.bool_0 = (257 != 0);
		this.method_69();
	}

	// Token: 0x06001FA2 RID: 8098 RVA: 0x0003BB3C File Offset: 0x00039D3C
	[Address(RVA = "0x2D8BBE4", Offset = "0x2D8BBE4", VA = "0x2D8BBE4")]
	[Token(Token = "0x6001FA2")]
	public void method_5()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FA3 RID: 8099 RVA: 0x0003BBE0 File Offset: 0x00039DE0
	[Address(RVA = "0x2D8BCB0", Offset = "0x2D8BCB0", VA = "0x2D8BCB0")]
	[Token(Token = "0x6001FA3")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		this.method_35();
	}

	// Token: 0x06001FA4 RID: 8100 RVA: 0x0003BC0C File Offset: 0x00039E0C
	[Address(RVA = "0x2D8BE98", Offset = "0x2D8BE98", VA = "0x2D8BE98")]
	[Token(Token = "0x6001FA4")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "Body";
	}

	// Token: 0x06001FA5 RID: 8101 RVA: 0x0003BC30 File Offset: 0x00039E30
	[Address(RVA = "0x2D8BF34", Offset = "0x2D8BF34", VA = "0x2D8BF34")]
	[Token(Token = "0x6001FA5")]
	public void method_8()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FA6 RID: 8102 RVA: 0x0003BC58 File Offset: 0x00039E58
	[Address(RVA = "0x2D8C084", Offset = "0x2D8C084", VA = "0x2D8C084")]
	[Token(Token = "0x6001FA6")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		this.bool_0 = (257 != 0);
		this.method_24();
	}

	// Token: 0x06001FA7 RID: 8103 RVA: 0x0003BC8C File Offset: 0x00039E8C
	[Address(RVA = "0x2D8C270", Offset = "0x2D8C270", VA = "0x2D8C270")]
	[Token(Token = "0x6001FA7")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "false";
		this.method_24();
	}

	// Token: 0x06001FA8 RID: 8104 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8C308", Offset = "0x2D8C308", VA = "0x2D8C308")]
	[Token(Token = "0x6001FA8")]
	public void method_11()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FA9 RID: 8105 RVA: 0x0003BCB8 File Offset: 0x00039EB8
	[Address(RVA = "0x2D8C3D4", Offset = "0x2D8C3D4", VA = "0x2D8C3D4")]
	[Token(Token = "0x6001FA9")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "Open";
		long num = 256L;
		this.bool_0 = (num != 0L);
		this.method_42();
	}

	// Token: 0x06001FAA RID: 8106 RVA: 0x0003BCF0 File Offset: 0x00039EF0
	[Address(RVA = "0x2D8C470", Offset = "0x2D8C470", VA = "0x2D8C470")]
	[Token(Token = "0x6001FAA")]
	public void method_13()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FAB RID: 8107 RVA: 0x0003BD18 File Offset: 0x00039F18
	[Address(RVA = "0x2D8C5C0", Offset = "0x2D8C5C0", VA = "0x2D8C5C0")]
	[Token(Token = "0x6001FAB")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == "5BN";
		long num = 256L;
		this.bool_0 = (num != 0L);
		this.method_35();
	}

	// Token: 0x06001FAC RID: 8108 RVA: 0x0003BD50 File Offset: 0x00039F50
	[Address(RVA = "0x2D8C65C", Offset = "0x2D8C65C", VA = "0x2D8C65C")]
	[Token(Token = "0x6001FAC")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_69();
	}

	// Token: 0x06001FAD RID: 8109 RVA: 0x0003BD84 File Offset: 0x00039F84
	[Address(RVA = "0x2D8C6F8", Offset = "0x2D8C6F8", VA = "0x2D8C6F8")]
	[Token(Token = "0x6001FAD")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_40();
	}

	// Token: 0x06001FAE RID: 8110 RVA: 0x0003BDB8 File Offset: 0x00039FB8
	[Address(RVA = "0x2D8C8E8", Offset = "0x2D8C8E8", VA = "0x2D8C8E8")]
	[Token(Token = "0x6001FAE")]
	public void method_17()
	{
		SizeChecker sizeChecker = this.sizeChecker_0;
		float num = this.float_0;
		sizeChecker.float_0 = num;
		SizeChecker sizeChecker2 = this.sizeChecker_1;
		float num2 = this.float_0;
		sizeChecker2.float_0 = num2;
		SizeChecker sizeChecker3 = this.sizeChecker_2;
		float num3 = this.float_0;
		sizeChecker3.float_0 = num3;
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FAF RID: 8111 RVA: 0x0003BE54 File Offset: 0x0003A054
	[Address(RVA = "0x2D8C9B4", Offset = "0x2D8C9B4", VA = "0x2D8C9B4")]
	[Token(Token = "0x6001FAF")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "Update User Inventory";
		this.method_66();
	}

	// Token: 0x06001FB0 RID: 8112 RVA: 0x0003BE80 File Offset: 0x0003A080
	[Address(RVA = "0x2D8CBA0", Offset = "0x2D8CBA0", VA = "0x2D8CBA0")]
	[Token(Token = "0x6001FB0")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "containsStaff";
		this.method_13();
	}

	// Token: 0x06001FB1 RID: 8113 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8CC38", Offset = "0x2D8CC38", VA = "0x2D8CC38")]
	[Token(Token = "0x6001FB1")]
	public void method_20()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FB2 RID: 8114 RVA: 0x0003BEAC File Offset: 0x0003A0AC
	[Address(RVA = "0x2D8CD04", Offset = "0x2D8CD04", VA = "0x2D8CD04")]
	[Token(Token = "0x6001FB2")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_8();
	}

	// Token: 0x06001FB3 RID: 8115 RVA: 0x0003BEE0 File Offset: 0x0003A0E0
	[Address(RVA = "0x2D8CDA0", Offset = "0x2D8CDA0", VA = "0x2D8CDA0")]
	[Token(Token = "0x6001FB3")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		long num = 256L;
		this.bool_0 = (num != 0L);
		this.method_32();
	}

	// Token: 0x06001FB4 RID: 8116 RVA: 0x0003BF18 File Offset: 0x0003A118
	[Address(RVA = "0x2D8CF8C", Offset = "0x2D8CF8C", VA = "0x2D8CF8C")]
	[Token(Token = "0x6001FB4")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "Tagging";
		this.method_39();
	}

	// Token: 0x06001FB5 RID: 8117 RVA: 0x0003BF44 File Offset: 0x0003A144
	[Address(RVA = "0x2D8D024", Offset = "0x2D8D024", VA = "0x2D8D024")]
	[Token(Token = "0x6001FB5")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		this.bool_0 = (257 != 0);
		this.method_42();
	}

	// Token: 0x06001FB6 RID: 8118 RVA: 0x0000208D File Offset: 0x0000028D
	[Address(RVA = "0x2D8D0C0", Offset = "0x2D8D0C0", VA = "0x2D8D0C0")]
	[Token(Token = "0x6001FB6")]
	public LazySizeChanger()
	{
	}

	// Token: 0x06001FB7 RID: 8119 RVA: 0x0003BC30 File Offset: 0x00039E30
	[Address(RVA = "0x2D8C120", Offset = "0x2D8C120", VA = "0x2D8C120")]
	[Token(Token = "0x6001FB7")]
	public void method_24()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FB8 RID: 8120 RVA: 0x0003BF78 File Offset: 0x0003A178
	[Address(RVA = "0x2D8D0C8", Offset = "0x2D8D0C8", VA = "0x2D8D0C8")]
	[Token(Token = "0x6001FB8")]
	public void method_25(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		this.bool_0 = (257 != 0);
		this.method_27();
	}

	// Token: 0x06001FB9 RID: 8121 RVA: 0x0003BFA4 File Offset: 0x0003A1A4
	[Address(RVA = "0x2D8D2B8", Offset = "0x2D8D2B8", VA = "0x2D8D2B8")]
	[Token(Token = "0x6001FB9")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "NormalWeather";
		this.bool_0 = (257 != 0);
		this.method_32();
	}

	// Token: 0x06001FBA RID: 8122 RVA: 0x0003BCF0 File Offset: 0x00039EF0
	[Address(RVA = "0x2D8D164", Offset = "0x2D8D164", VA = "0x2D8D164")]
	[Token(Token = "0x6001FBA")]
	public void method_27()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FBB RID: 8123 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8D354", Offset = "0x2D8D354", VA = "0x2D8D354")]
	[Token(Token = "0x6001FBB")]
	public void method_28()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FBC RID: 8124 RVA: 0x0003BFD8 File Offset: 0x0003A1D8
	[Address(RVA = "0x2D8D420", Offset = "0x2D8D420", VA = "0x2D8D420")]
	[Token(Token = "0x6001FBC")]
	public void method_29()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			this.sizeChecker_2.float_0 = num2;
		}
		SizeChecker sizeChecker3 = this.sizeChecker_0;
		float num3 = this.float_0;
		sizeChecker3.float_0 = num3;
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001FBD RID: 8125 RVA: 0x0003C070 File Offset: 0x0003A270
	[Address(RVA = "0x2D8D4E8", Offset = "0x2D8D4E8", VA = "0x2D8D4E8")]
	[Token(Token = "0x6001FBD")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == "Left Hand";
		this.method_66();
	}

	// Token: 0x06001FBE RID: 8126 RVA: 0x0003C09C File Offset: 0x0003A29C
	[Address(RVA = "0x2D8D580", Offset = "0x2D8D580", VA = "0x2D8D580")]
	[Token(Token = "0x6001FBE")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "\n Time: ";
		long num = 256L;
		this.bool_0 = (num != 0L);
		this.method_39();
	}

	// Token: 0x06001FBF RID: 8127 RVA: 0x0003BC30 File Offset: 0x00039E30
	[Address(RVA = "0x2D8CE3C", Offset = "0x2D8CE3C", VA = "0x2D8CE3C")]
	[Token(Token = "0x6001FBF")]
	public void method_32()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FC0 RID: 8128 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8D61C", Offset = "0x2D8D61C", VA = "0x2D8D61C")]
	[Token(Token = "0x6001FC0")]
	public void method_33()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FC1 RID: 8129 RVA: 0x0003C0D4 File Offset: 0x0003A2D4
	[Address(RVA = "0x2D8D6E8", Offset = "0x2D8D6E8", VA = "0x2D8D6E8")]
	[Token(Token = "0x6001FC1")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "Unpause";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_35();
	}

	// Token: 0x06001FC2 RID: 8130 RVA: 0x0003C108 File Offset: 0x0003A308
	[Address(RVA = "0x2D8BD48", Offset = "0x2D8BD48", VA = "0x2D8BD48")]
	[Token(Token = "0x6001FC2")]
	public void method_35()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FC3 RID: 8131 RVA: 0x0003C130 File Offset: 0x0003A330
	[Address(RVA = "0x2D8D784", Offset = "0x2D8D784", VA = "0x2D8D784")]
	[Token(Token = "0x6001FC3")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "button";
		long num = 256L;
		this.bool_0 = (num != 0L);
		this.method_8();
	}

	// Token: 0x06001FC4 RID: 8132 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8D820", Offset = "0x2D8D820", VA = "0x2D8D820")]
	[Token(Token = "0x6001FC4")]
	public void method_37()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FC5 RID: 8133 RVA: 0x0003C168 File Offset: 0x0003A368
	[Address(RVA = "0x2D8D8EC", Offset = "0x2D8D8EC", VA = "0x2D8D8EC")]
	[Token(Token = "0x6001FC5")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		this.bool_0 = (257 != 0);
		this.method_13();
	}

	// Token: 0x06001FC6 RID: 8134 RVA: 0x0003BCF0 File Offset: 0x00039EF0
	[Address(RVA = "0x2D8B6B8", Offset = "0x2D8B6B8", VA = "0x2D8B6B8")]
	[Token(Token = "0x6001FC6")]
	public void method_39()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FC7 RID: 8135 RVA: 0x0003C19C File Offset: 0x0003A39C
	[Address(RVA = "0x2D8C794", Offset = "0x2D8C794", VA = "0x2D8C794")]
	[Token(Token = "0x6001FC7")]
	public void method_40()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
		this.sizeChecker_1 = typeof(float).TypeHandle;
	}

	// Token: 0x06001FC8 RID: 8136 RVA: 0x0003C1CC File Offset: 0x0003A3CC
	[Address(RVA = "0x2D8D988", Offset = "0x2D8D988", VA = "0x2D8D988")]
	[Token(Token = "0x6001FC8")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.tag == "Connected to Server.";
		this.method_66();
	}

	// Token: 0x06001FC9 RID: 8137 RVA: 0x0003BCF0 File Offset: 0x00039EF0
	[Address(RVA = "0x2D8B8A4", Offset = "0x2D8B8A4", VA = "0x2D8B8A4")]
	[Token(Token = "0x6001FC9")]
	public void method_42()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FCA RID: 8138 RVA: 0x0003C1F8 File Offset: 0x0003A3F8
	[Address(RVA = "0x2D8DA24", Offset = "0x2D8DA24", VA = "0x2D8DA24")]
	[Token(Token = "0x6001FCA")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.tag == "You are not the master of the server, you cannot start the game.";
		this.bool_0 = (257 != 0);
		this.method_39();
	}

	// Token: 0x06001FCB RID: 8139 RVA: 0x0003C22C File Offset: 0x0003A42C
	[Address(RVA = "0x2D8DAC0", Offset = "0x2D8DAC0", VA = "0x2D8DAC0")]
	[Token(Token = "0x6001FCB")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Smoothness";
		this.bool_0 = (257 != 0);
		this.method_66();
	}

	// Token: 0x06001FCC RID: 8140 RVA: 0x0003C260 File Offset: 0x0003A460
	[Address(RVA = "0x2D8DB5C", Offset = "0x2D8DB5C", VA = "0x2D8DB5C")]
	[Token(Token = "0x6001FCC")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot take elements from an empty buffer.";
		this.bool_0 = (257 != 0);
		this.method_13();
	}

	// Token: 0x06001FCD RID: 8141 RVA: 0x0003C294 File Offset: 0x0003A494
	[Address(RVA = "0x2D8DBF8", Offset = "0x2D8DBF8", VA = "0x2D8DBF8")]
	[Token(Token = "0x6001FCD")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.tag == "https://raw.githubusercontent.com/";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_27();
	}

	// Token: 0x06001FCE RID: 8142 RVA: 0x0003C2C8 File Offset: 0x0003A4C8
	[Address(RVA = "0x2D8DC94", Offset = "0x2D8DC94", VA = "0x2D8DC94")]
	[Token(Token = "0x6001FCE")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.tag == "Display Name Changed!";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_8();
	}

	// Token: 0x06001FCF RID: 8143 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8DD30", Offset = "0x2D8DD30", VA = "0x2D8DD30")]
	[Token(Token = "0x6001FCF")]
	public void method_48()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FD0 RID: 8144 RVA: 0x0003C2FC File Offset: 0x0003A4FC
	[Address(RVA = "0x2D8DDF8", Offset = "0x2D8DDF8", VA = "0x2D8DDF8")]
	[Token(Token = "0x6001FD0")]
	public void method_49()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
		}
		SizeChecker sizeChecker3 = this.sizeChecker_0;
		float num3 = this.float_0;
		sizeChecker3.float_0 = num3;
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001FD1 RID: 8145 RVA: 0x0003C388 File Offset: 0x0003A588
	[Address(RVA = "0x2D8DEC4", Offset = "0x2D8DEC4", VA = "0x2D8DEC4")]
	[Token(Token = "0x6001FD1")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerHead";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_8();
	}

	// Token: 0x06001FD2 RID: 8146 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8DF60", Offset = "0x2D8DF60", VA = "0x2D8DF60")]
	[Token(Token = "0x6001FD2")]
	public void method_51()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FD3 RID: 8147 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8E02C", Offset = "0x2D8E02C", VA = "0x2D8E02C")]
	[Token(Token = "0x6001FD3")]
	public void method_52()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FD4 RID: 8148 RVA: 0x0003C3BC File Offset: 0x0003A5BC
	[Address(RVA = "0x2D8E0F8", Offset = "0x2D8E0F8", VA = "0x2D8E0F8")]
	[Token(Token = "0x6001FD4")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		this.method_60();
	}

	// Token: 0x06001FD5 RID: 8149 RVA: 0x0003C3E8 File Offset: 0x0003A5E8
	[Address(RVA = "0x2D8E2E4", Offset = "0x2D8E2E4", VA = "0x2D8E2E4")]
	[Token(Token = "0x6001FD5")]
	public void method_54(Collider collider_0)
	{
		collider_0.gameObject.tag == "CapuchinRemade";
		this.method_35();
	}

	// Token: 0x06001FD6 RID: 8150 RVA: 0x0003C414 File Offset: 0x0003A614
	[Address(RVA = "0x2D8E37C", Offset = "0x2D8E37C", VA = "0x2D8E37C")]
	[Token(Token = "0x6001FD6")]
	public void Update()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
		}
		SizeChecker sizeChecker3 = this.sizeChecker_0;
		float num3 = this.float_0;
		sizeChecker3.float_0 = num3;
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
	}

	// Token: 0x06001FD7 RID: 8151 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8E420", Offset = "0x2D8E420", VA = "0x2D8E420")]
	[Token(Token = "0x6001FD7")]
	public void method_55()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FD8 RID: 8152 RVA: 0x0003C488 File Offset: 0x0003A688
	[Address(RVA = "0x2D8E4EC", Offset = "0x2D8E4EC", VA = "0x2D8E4EC")]
	[Token(Token = "0x6001FD8")]
	public void method_56(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_27();
	}

	// Token: 0x06001FD9 RID: 8153 RVA: 0x0003C4BC File Offset: 0x0003A6BC
	[Address(RVA = "0x2D8E588", Offset = "0x2D8E588", VA = "0x2D8E588")]
	[Token(Token = "0x6001FD9")]
	public void method_57()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001FDA RID: 8154 RVA: 0x0003C548 File Offset: 0x0003A748
	[Address(RVA = "0x2D8E650", Offset = "0x2D8E650", VA = "0x2D8E650")]
	[Token(Token = "0x6001FDA")]
	public void method_58(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		this.method_60();
	}

	// Token: 0x06001FDB RID: 8155 RVA: 0x0003C574 File Offset: 0x0003A774
	[Address(RVA = "0x2D8E6E8", Offset = "0x2D8E6E8", VA = "0x2D8E6E8")]
	[Token(Token = "0x6001FDB")]
	public void method_59()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			float num3 = this.float_0;
			sizeChecker2.float_0 = num3;
		}
		SizeChecker sizeChecker3 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker3.float_0 = num4;
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker4.float_0 = num5;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker5.float_0 = num6;
	}

	// Token: 0x06001FDC RID: 8156 RVA: 0x0003BC30 File Offset: 0x00039E30
	[Address(RVA = "0x2D8E190", Offset = "0x2D8E190", VA = "0x2D8E190")]
	[Token(Token = "0x6001FDC")]
	public void method_60()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FDD RID: 8157 RVA: 0x0003B964 File Offset: 0x00039B64
	[Address(RVA = "0x2D8E7B4", Offset = "0x2D8E7B4", VA = "0x2D8E7B4")]
	[Token(Token = "0x6001FDD")]
	public void method_61()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FDE RID: 8158 RVA: 0x0003C4BC File Offset: 0x0003A6BC
	[Token(Token = "0x6001FDE")]
	[Address(RVA = "0x2D8E880", Offset = "0x2D8E880", VA = "0x2D8E880")]
	public void method_62()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001FDF RID: 8159 RVA: 0x0003B964 File Offset: 0x00039B64
	[Token(Token = "0x6001FDF")]
	[Address(RVA = "0x2D8E94C", Offset = "0x2D8E94C", VA = "0x2D8E94C")]
	public void method_63()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_1;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
		SizeChecker sizeChecker6 = this.sizeChecker_2;
		float num6 = this.float_0;
		sizeChecker6.float_0 = num6;
	}

	// Token: 0x06001FE0 RID: 8160 RVA: 0x0003C610 File Offset: 0x0003A810
	[Address(RVA = "0x2D8EA18", Offset = "0x2D8EA18", VA = "0x2D8EA18")]
	[Token(Token = "0x6001FE0")]
	public void method_64()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			SizeChecker sizeChecker3 = this.sizeChecker_2;
			float num3 = this.float_0;
			sizeChecker3.float_0 = num3;
		}
		SizeChecker sizeChecker4 = this.sizeChecker_0;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001FE1 RID: 8161 RVA: 0x0003BFD8 File Offset: 0x0003A1D8
	[Token(Token = "0x6001FE1")]
	[Address(RVA = "0x2D8EAE4", Offset = "0x2D8EAE4", VA = "0x2D8EAE4")]
	public void method_65()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_1;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
			this.sizeChecker_2.float_0 = num2;
		}
		SizeChecker sizeChecker3 = this.sizeChecker_0;
		float num3 = this.float_0;
		sizeChecker3.float_0 = num3;
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001FE2 RID: 8162 RVA: 0x0003BC30 File Offset: 0x00039E30
	[Address(RVA = "0x2D8CA4C", Offset = "0x2D8CA4C", VA = "0x2D8CA4C")]
	[Token(Token = "0x6001FE2")]
	public void method_66()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FE3 RID: 8163 RVA: 0x0003C69C File Offset: 0x0003A89C
	[Address(RVA = "0x2D8EBAC", Offset = "0x2D8EBAC", VA = "0x2D8EBAC")]
	[Token(Token = "0x6001FE3")]
	public void method_67(Collider collider_0)
	{
		collider_0.gameObject.tag == "button";
	}

	// Token: 0x06001FE4 RID: 8164 RVA: 0x0003C6C0 File Offset: 0x0003A8C0
	[Token(Token = "0x6001FE4")]
	[Address(RVA = "0x2D8EC44", Offset = "0x2D8EC44", VA = "0x2D8EC44")]
	public void method_68(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "On";
		this.bool_0 = (257 != 0);
		this.method_13();
	}

	// Token: 0x06001FE5 RID: 8165 RVA: 0x0003C108 File Offset: 0x0003A308
	[Address(RVA = "0x2D8BA90", Offset = "0x2D8BA90", VA = "0x2D8BA90")]
	[Token(Token = "0x6001FE5")]
	public void method_69()
	{
		PhotonView component = this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
		this.photonView_0 = component;
	}

	// Token: 0x06001FE6 RID: 8166 RVA: 0x0003C6F0 File Offset: 0x0003A8F0
	[Token(Token = "0x6001FE6")]
	[Address(RVA = "0x2D8ECE0", Offset = "0x2D8ECE0", VA = "0x2D8ECE0")]
	public void method_70(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot access index {0}. Buffer is empty";
		this.bool_0 = (257 != 0);
		this.method_8();
	}

	// Token: 0x06001FE7 RID: 8167 RVA: 0x0003C724 File Offset: 0x0003A924
	[Token(Token = "0x6001FE7")]
	[Address(RVA = "0x2D8ED7C", Offset = "0x2D8ED7C", VA = "0x2D8ED7C")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		long num = 256L;
		this.bool_0 = (num != 0L);
		this.method_8();
	}

	// Token: 0x06001FE8 RID: 8168 RVA: 0x0003BA08 File Offset: 0x00039C08
	[Address(RVA = "0x2D8EE18", Offset = "0x2D8EE18", VA = "0x2D8EE18")]
	[Token(Token = "0x6001FE8")]
	public void method_71()
	{
		if (this.bool_0)
		{
			SizeChecker sizeChecker = this.sizeChecker_0;
			float num = this.float_0;
			sizeChecker.float_0 = num;
			this.sizeChecker_1.float_0 = num;
			SizeChecker sizeChecker2 = this.sizeChecker_2;
			float num2 = this.float_0;
			sizeChecker2.float_0 = num2;
		}
		SizeChecker sizeChecker3 = this.sizeChecker_0;
		float num3 = this.float_0;
		sizeChecker3.float_0 = num3;
		SizeChecker sizeChecker4 = this.sizeChecker_1;
		float num4 = this.float_0;
		sizeChecker4.float_0 = num4;
		SizeChecker sizeChecker5 = this.sizeChecker_2;
		float num5 = this.float_0;
		sizeChecker5.float_0 = num5;
	}

	// Token: 0x06001FE9 RID: 8169 RVA: 0x0003C75C File Offset: 0x0003A95C
	[Token(Token = "0x6001FE9")]
	[Address(RVA = "0x2D8EEE4", Offset = "0x2D8EEE4", VA = "0x2D8EEE4")]
	public void method_72(Collider collider_0)
	{
		collider_0.gameObject.tag == "Right Hand";
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.method_42();
	}

	// Token: 0x06001FEA RID: 8170 RVA: 0x0003C790 File Offset: 0x0003A990
	[Address(RVA = "0x2D8EF80", Offset = "0x2D8EF80", VA = "0x2D8EF80")]
	[Token(Token = "0x6001FEA")]
	public void method_73(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		long num = 256L;
		this.bool_0 = (num != 0L);
		this.method_13();
	}

	// Token: 0x04000445 RID: 1093
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000445")]
	public SizeChecker sizeChecker_0;

	// Token: 0x04000446 RID: 1094
	[Token(Token = "0x4000446")]
	[FieldOffset(Offset = "0x28")]
	public SizeChecker sizeChecker_1;

	// Token: 0x04000447 RID: 1095
	[Token(Token = "0x4000447")]
	[FieldOffset(Offset = "0x30")]
	public SizeChecker sizeChecker_2;

	// Token: 0x04000448 RID: 1096
	[Token(Token = "0x4000448")]
	[FieldOffset(Offset = "0x38")]
	public bool bool_0;

	// Token: 0x04000449 RID: 1097
	[FieldOffset(Offset = "0x39")]
	[Token(Token = "0x4000449")]
	public bool bool_1;

	// Token: 0x0400044A RID: 1098
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x400044A")]
	public float float_0;

	// Token: 0x0400044B RID: 1099
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400044B")]
	public NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x0400044C RID: 1100
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400044C")]
	private PhotonView photonView_0;
}
