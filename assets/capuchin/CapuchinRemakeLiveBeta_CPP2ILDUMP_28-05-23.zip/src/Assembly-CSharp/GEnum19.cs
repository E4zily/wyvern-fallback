﻿using System;
using Cpp2IlInjected;

// Token: 0x02000162 RID: 354
[Token(Token = "0x2000162")]
public enum GEnum19
{
	// Token: 0x04000956 RID: 2390
	[Token(Token = "0x4000956")]
	const_0,
	// Token: 0x04000957 RID: 2391
	[Token(Token = "0x4000957")]
	const_1
}
