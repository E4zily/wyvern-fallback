﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000DA RID: 218
[Token(Token = "0x20000DA")]
public class MirrorEnable : MonoBehaviour
{
	// Token: 0x0600206A RID: 8298 RVA: 0x0003C828 File Offset: 0x0003AA28
	[Address(RVA = "0x2E64BA0", Offset = "0x2E64BA0", VA = "0x2E64BA0")]
	[Token(Token = "0x600206A")]
	public void method_0(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600206B RID: 8299 RVA: 0x0003C854 File Offset: 0x0003AA54
	[Address(RVA = "0x2E64C40", Offset = "0x2E64C40", VA = "0x2E64C40")]
	[Token(Token = "0x600206B")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "Body";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600206C RID: 8300 RVA: 0x0003C888 File Offset: 0x0003AA88
	[Address(RVA = "0x2E64CE0", Offset = "0x2E64CE0", VA = "0x2E64CE0")]
	[Token(Token = "0x600206C")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "_WobbleX";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600206D RID: 8301 RVA: 0x0003C828 File Offset: 0x0003AA28
	[Address(RVA = "0x2E64D80", Offset = "0x2E64D80", VA = "0x2E64D80")]
	[Token(Token = "0x600206D")]
	public void method_3(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600206E RID: 8302 RVA: 0x0003C8BC File Offset: 0x0003AABC
	[Address(RVA = "0x2E64E20", Offset = "0x2E64E20", VA = "0x2E64E20")]
	[Token(Token = "0x600206E")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600206F RID: 8303 RVA: 0x0003C8F0 File Offset: 0x0003AAF0
	[Address(RVA = "0x2E64EC0", Offset = "0x2E64EC0", VA = "0x2E64EC0")]
	[Token(Token = "0x600206F")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002070 RID: 8304 RVA: 0x0003C924 File Offset: 0x0003AB24
	[Address(RVA = "0x2E64F60", Offset = "0x2E64F60", VA = "0x2E64F60")]
	[Token(Token = "0x6002070")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002071 RID: 8305 RVA: 0x0003C958 File Offset: 0x0003AB58
	[Address(RVA = "0x2E65000", Offset = "0x2E65000", VA = "0x2E65000")]
	[Token(Token = "0x6002071")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "next";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002072 RID: 8306 RVA: 0x0003C98C File Offset: 0x0003AB8C
	[Address(RVA = "0x2E650A0", Offset = "0x2E650A0", VA = "0x2E650A0")]
	[Token(Token = "0x6002072")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "HandL";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002073 RID: 8307 RVA: 0x0003C9C0 File Offset: 0x0003ABC0
	[Address(RVA = "0x2E65140", Offset = "0x2E65140", VA = "0x2E65140")]
	[Token(Token = "0x6002073")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002074 RID: 8308 RVA: 0x0003C9F4 File Offset: 0x0003ABF4
	[Address(RVA = "0x2E651E0", Offset = "0x2E651E0", VA = "0x2E651E0")]
	[Token(Token = "0x6002074")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "EnableCosmetic";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002075 RID: 8309 RVA: 0x0003CA28 File Offset: 0x0003AC28
	[Address(RVA = "0x2E65280", Offset = "0x2E65280", VA = "0x2E65280")]
	[Token(Token = "0x6002075")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002076 RID: 8310 RVA: 0x0003CA5C File Offset: 0x0003AC5C
	[Address(RVA = "0x2E65320", Offset = "0x2E65320", VA = "0x2E65320")]
	[Token(Token = "0x6002076")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "Joined a Room.";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002077 RID: 8311 RVA: 0x0003CA90 File Offset: 0x0003AC90
	[Address(RVA = "0x2E653C0", Offset = "0x2E653C0", VA = "0x2E653C0")]
	[Token(Token = "0x6002077")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "Not enough amount of currency";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002078 RID: 8312 RVA: 0x0003CAC4 File Offset: 0x0003ACC4
	[Address(RVA = "0x2E65460", Offset = "0x2E65460", VA = "0x2E65460")]
	[Token(Token = "0x6002078")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "hand 1";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002079 RID: 8313 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2E65500", Offset = "0x2E65500", VA = "0x2E65500")]
	[Token(Token = "0x6002079")]
	public MirrorEnable()
	{
	}

	// Token: 0x0600207A RID: 8314 RVA: 0x0003CAF8 File Offset: 0x0003ACF8
	[Address(RVA = "0x2E65508", Offset = "0x2E65508", VA = "0x2E65508")]
	[Token(Token = "0x600207A")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600207B RID: 8315 RVA: 0x0003CB2C File Offset: 0x0003AD2C
	[Address(RVA = "0x2E655A8", Offset = "0x2E655A8", VA = "0x2E655A8")]
	[Token(Token = "0x600207B")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == "hh:mmtt";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600207C RID: 8316 RVA: 0x0003CB60 File Offset: 0x0003AD60
	[Address(RVA = "0x2E65648", Offset = "0x2E65648", VA = "0x2E65648")]
	[Token(Token = "0x600207C")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "Skelechin";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600207D RID: 8317 RVA: 0x0003CB94 File Offset: 0x0003AD94
	[Address(RVA = "0x2E656E8", Offset = "0x2E656E8", VA = "0x2E656E8")]
	[Token(Token = "0x600207D")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "character limit reached";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600207E RID: 8318 RVA: 0x0003CBC8 File Offset: 0x0003ADC8
	[Address(RVA = "0x2E65788", Offset = "0x2E65788", VA = "0x2E65788")]
	[Token(Token = "0x600207E")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "procedural animation script required on ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600207F RID: 8319 RVA: 0x0003CBFC File Offset: 0x0003ADFC
	[Address(RVA = "0x2E65828", Offset = "0x2E65828", VA = "0x2E65828")]
	[Token(Token = "0x600207F")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "Queue";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002080 RID: 8320 RVA: 0x0003CC30 File Offset: 0x0003AE30
	[Address(RVA = "0x2E658C8", Offset = "0x2E658C8", VA = "0x2E658C8")]
	[Token(Token = "0x6002080")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot take elements from an empty buffer.";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002081 RID: 8321 RVA: 0x0003CC64 File Offset: 0x0003AE64
	[Address(RVA = "0x2E65968", Offset = "0x2E65968", VA = "0x2E65968")]
	[Token(Token = "0x6002081")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayNoise";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002082 RID: 8322 RVA: 0x0003CC98 File Offset: 0x0003AE98
	[Address(RVA = "0x2E65A08", Offset = "0x2E65A08", VA = "0x2E65A08")]
	[Token(Token = "0x6002082")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Tint";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002083 RID: 8323 RVA: 0x0003CCCC File Offset: 0x0003AECC
	[Address(RVA = "0x2E65AA8", Offset = "0x2E65AA8", VA = "0x2E65AA8")]
	[Token(Token = "0x6002083")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "DisableCosmetic";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002084 RID: 8324 RVA: 0x0003C9C0 File Offset: 0x0003ABC0
	[Address(RVA = "0x2E65B48", Offset = "0x2E65B48", VA = "0x2E65B48")]
	[Token(Token = "0x6002084")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002085 RID: 8325 RVA: 0x0003CD00 File Offset: 0x0003AF00
	[Address(RVA = "0x2E65BE8", Offset = "0x2E65BE8", VA = "0x2E65BE8")]
	[Token(Token = "0x6002085")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "token";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002086 RID: 8326 RVA: 0x0003C924 File Offset: 0x0003AB24
	[Address(RVA = "0x2E65C88", Offset = "0x2E65C88", VA = "0x2E65C88")]
	[Token(Token = "0x6002086")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002087 RID: 8327 RVA: 0x0003CD34 File Offset: 0x0003AF34
	[Address(RVA = "0x2E65D28", Offset = "0x2E65D28", VA = "0x2E65D28")]
	[Token(Token = "0x6002087")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "duration done";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002088 RID: 8328 RVA: 0x0003CD68 File Offset: 0x0003AF68
	[Address(RVA = "0x2E65DC8", Offset = "0x2E65DC8", VA = "0x2E65DC8")]
	[Token(Token = "0x6002088")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "typesOfTalk";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002089 RID: 8329 RVA: 0x0003CD9C File Offset: 0x0003AF9C
	[Address(RVA = "0x2E65E68", Offset = "0x2E65E68", VA = "0x2E65E68")]
	[Token(Token = "0x6002089")]
	public void method_28(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "lock unlocked!";
		GameObject gameObject2 = this.gameObject_0;
		long active = 1L;
		gameObject2.SetActive(active != 0L);
	}

	// Token: 0x0600208A RID: 8330 RVA: 0x0003CDCC File Offset: 0x0003AFCC
	[Address(RVA = "0x2E65F08", Offset = "0x2E65F08", VA = "0x2E65F08")]
	[Token(Token = "0x600208A")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == "gravThing";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600208B RID: 8331 RVA: 0x0003CE00 File Offset: 0x0003B000
	[Address(RVA = "0x2E65FA8", Offset = "0x2E65FA8", VA = "0x2E65FA8")]
	[Token(Token = "0x600208B")]
	public void method_30(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		throw new MissingMethodException();
	}

	// Token: 0x0600208C RID: 8332 RVA: 0x0003CE20 File Offset: 0x0003B020
	[Address(RVA = "0x2E66048", Offset = "0x2E66048", VA = "0x2E66048")]
	[Token(Token = "0x600208C")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot access index {0}. Buffer is empty";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600208D RID: 8333 RVA: 0x0003C924 File Offset: 0x0003AB24
	[Address(RVA = "0x2E660E8", Offset = "0x2E660E8", VA = "0x2E660E8")]
	[Token(Token = "0x600208D")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600208E RID: 8334 RVA: 0x0003CE54 File Offset: 0x0003B054
	[Address(RVA = "0x2E66188", Offset = "0x2E66188", VA = "0x2E66188")]
	[Token(Token = "0x600208E")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == "Push To Talk";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600208F RID: 8335 RVA: 0x0003CA28 File Offset: 0x0003AC28
	[Address(RVA = "0x2E66228", Offset = "0x2E66228", VA = "0x2E66228")]
	[Token(Token = "0x600208F")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002090 RID: 8336 RVA: 0x0003CE88 File Offset: 0x0003B088
	[Address(RVA = "0x2E662C8", Offset = "0x2E662C8", VA = "0x2E662C8")]
	[Token(Token = "0x6002090")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002091 RID: 8337 RVA: 0x0003CEBC File Offset: 0x0003B0BC
	[Address(RVA = "0x2E66368", Offset = "0x2E66368", VA = "0x2E66368")]
	[Token(Token = "0x6002091")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "Found Gameobject: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002092 RID: 8338 RVA: 0x0003CEF0 File Offset: 0x0003B0F0
	[Address(RVA = "0x2E66408", Offset = "0x2E66408", VA = "0x2E66408")]
	[Token(Token = "0x6002092")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vertical";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002093 RID: 8339 RVA: 0x0003CF24 File Offset: 0x0003B124
	[Address(RVA = "0x2E664A8", Offset = "0x2E664A8", VA = "0x2E664A8")]
	[Token(Token = "0x6002093")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.tag == "BloodKill";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06002094 RID: 8340 RVA: 0x0003CF58 File Offset: 0x0003B158
	[Address(RVA = "0x2E66548", Offset = "0x2E66548", VA = "0x2E66548")]
	[Token(Token = "0x6002094")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
	}

	// Token: 0x0400044F RID: 1103
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400044F")]
	public GameObject gameObject_0;
}
