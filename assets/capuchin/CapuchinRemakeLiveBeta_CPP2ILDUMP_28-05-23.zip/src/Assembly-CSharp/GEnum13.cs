﻿using System;
using Cpp2IlInjected;

// Token: 0x0200012D RID: 301
[Token(Token = "0x200012D")]
public enum GEnum13
{
	// Token: 0x040005D7 RID: 1495
	[Token(Token = "0x40005D7")]
	const_0,
	// Token: 0x040005D8 RID: 1496
	[Token(Token = "0x40005D8")]
	const_1,
	// Token: 0x040005D9 RID: 1497
	[Token(Token = "0x40005D9")]
	const_2,
	// Token: 0x040005DA RID: 1498
	[Token(Token = "0x40005DA")]
	const_3
}
