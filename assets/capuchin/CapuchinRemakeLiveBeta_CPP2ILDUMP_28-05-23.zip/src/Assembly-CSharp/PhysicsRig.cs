﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000098 RID: 152
[Token(Token = "0x2000098")]
public class PhysicsRig : MonoBehaviour
{
	// Token: 0x06001611 RID: 5649 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x30577FC", Offset = "0x30577FC", VA = "0x30577FC")]
	[Token(Token = "0x6001611")]
	private void method_0()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001612 RID: 5650 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001612")]
	[Address(RVA = "0x3057998", Offset = "0x3057998", VA = "0x3057998")]
	private void method_1()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001613 RID: 5651 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3057B34", Offset = "0x3057B34", VA = "0x3057B34")]
	[Token(Token = "0x6001613")]
	private void method_2()
	{
	}

	// Token: 0x06001614 RID: 5652 RVA: 0x0002AB84 File Offset: 0x00028D84
	[Token(Token = "0x6001614")]
	[Address(RVA = "0x3057B38", Offset = "0x3057B38", VA = "0x3057B38")]
	private void method_3()
	{
		Vector3 localPosition = this.transform_0.localPosition;
		Transform transform = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform2 = this.transform_1;
		Vector3 localPosition5 = transform2.localPosition;
		Transform transform3 = this.transform_1;
		Quaternion localRotation = transform3.localRotation;
		Transform transform4 = this.transform_2;
		Vector3 localPosition6 = transform4.localPosition;
		Transform transform5 = this.transform_2;
		Quaternion localRotation2 = transform5.localRotation;
		Transform transform6 = this.transform_0;
		Vector3 localPosition7 = transform6.localPosition;
		Transform transform7 = this.transform_0;
		Quaternion localRotation3 = transform7.localRotation;
	}

	// Token: 0x06001615 RID: 5653 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001615")]
	[Address(RVA = "0x3057CD4", Offset = "0x3057CD4", VA = "0x3057CD4")]
	private void method_4()
	{
	}

	// Token: 0x06001616 RID: 5654 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3057CD8", Offset = "0x3057CD8", VA = "0x3057CD8")]
	[Token(Token = "0x6001616")]
	private void method_5()
	{
	}

	// Token: 0x06001617 RID: 5655 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3057CDC", Offset = "0x3057CDC", VA = "0x3057CDC")]
	[Token(Token = "0x6001617")]
	private void method_6()
	{
	}

	// Token: 0x06001618 RID: 5656 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001618")]
	[Address(RVA = "0x3057CE0", Offset = "0x3057CE0", VA = "0x3057CE0")]
	private void method_7()
	{
	}

	// Token: 0x06001619 RID: 5657 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3057CE4", Offset = "0x3057CE4", VA = "0x3057CE4")]
	[Token(Token = "0x6001619")]
	private void method_8()
	{
	}

	// Token: 0x0600161A RID: 5658 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x600161A")]
	[Address(RVA = "0x3057CE8", Offset = "0x3057CE8", VA = "0x3057CE8")]
	private void method_9()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600161B RID: 5659 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x3057E84", Offset = "0x3057E84", VA = "0x3057E84")]
	[Token(Token = "0x600161B")]
	private void method_10()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600161C RID: 5660 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x3058020", Offset = "0x3058020", VA = "0x3058020")]
	[Token(Token = "0x600161C")]
	private void method_11()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600161D RID: 5661 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x30581BC", Offset = "0x30581BC", VA = "0x30581BC")]
	[Token(Token = "0x600161D")]
	private void method_12()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600161E RID: 5662 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x600161E")]
	[Address(RVA = "0x3058358", Offset = "0x3058358", VA = "0x3058358")]
	private void method_13()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600161F RID: 5663 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x600161F")]
	[Address(RVA = "0x30584F4", Offset = "0x30584F4", VA = "0x30584F4")]
	private void method_14()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001620 RID: 5664 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x3058690", Offset = "0x3058690", VA = "0x3058690")]
	[Token(Token = "0x6001620")]
	private void method_15()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001621 RID: 5665 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001621")]
	[Address(RVA = "0x305882C", Offset = "0x305882C", VA = "0x305882C")]
	private void method_16()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001622 RID: 5666 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001622")]
	[Address(RVA = "0x30589C8", Offset = "0x30589C8", VA = "0x30589C8")]
	private void LateUpdate()
	{
	}

	// Token: 0x06001623 RID: 5667 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001623")]
	[Address(RVA = "0x30589CC", Offset = "0x30589CC", VA = "0x30589CC")]
	private void method_17()
	{
	}

	// Token: 0x06001624 RID: 5668 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001624")]
	[Address(RVA = "0x30589D0", Offset = "0x30589D0", VA = "0x30589D0")]
	private void method_18()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001625 RID: 5669 RVA: 0x0002AC30 File Offset: 0x00028E30
	[Token(Token = "0x6001625")]
	[Address(RVA = "0x3058B6C", Offset = "0x3058B6C", VA = "0x3058B6C")]
	private void method_19()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Quaternion localRotation3 = this.transform_0.localRotation;
	}

	// Token: 0x06001626 RID: 5670 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001626")]
	[Address(RVA = "0x3058D08", Offset = "0x3058D08", VA = "0x3058D08")]
	private void method_20()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001627 RID: 5671 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001627")]
	[Address(RVA = "0x3058EA4", Offset = "0x3058EA4", VA = "0x3058EA4")]
	private void method_21()
	{
	}

	// Token: 0x06001628 RID: 5672 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001628")]
	[Address(RVA = "0x3058EA8", Offset = "0x3058EA8", VA = "0x3058EA8")]
	private void method_22()
	{
	}

	// Token: 0x06001629 RID: 5673 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001629")]
	[Address(RVA = "0x3058EAC", Offset = "0x3058EAC", VA = "0x3058EAC")]
	private void method_23()
	{
	}

	// Token: 0x0600162A RID: 5674 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3058EB0", Offset = "0x3058EB0", VA = "0x3058EB0")]
	[Token(Token = "0x600162A")]
	private void method_24()
	{
	}

	// Token: 0x0600162B RID: 5675 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600162B")]
	[Address(RVA = "0x3058EB4", Offset = "0x3058EB4", VA = "0x3058EB4")]
	private void method_25()
	{
	}

	// Token: 0x0600162C RID: 5676 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3058EB8", Offset = "0x3058EB8", VA = "0x3058EB8")]
	[Token(Token = "0x600162C")]
	private void method_26()
	{
	}

	// Token: 0x0600162D RID: 5677 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3058EBC", Offset = "0x3058EBC", VA = "0x3058EBC")]
	[Token(Token = "0x600162D")]
	private void method_27()
	{
	}

	// Token: 0x0600162E RID: 5678 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3058EC0", Offset = "0x3058EC0", VA = "0x3058EC0")]
	[Token(Token = "0x600162E")]
	private void method_28()
	{
	}

	// Token: 0x0600162F RID: 5679 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600162F")]
	[Address(RVA = "0x3058EC4", Offset = "0x3058EC4", VA = "0x3058EC4")]
	private void method_29()
	{
	}

	// Token: 0x06001630 RID: 5680 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3058EC8", Offset = "0x3058EC8", VA = "0x3058EC8")]
	[Token(Token = "0x6001630")]
	private void method_30()
	{
	}

	// Token: 0x06001631 RID: 5681 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3058ECC", Offset = "0x3058ECC", VA = "0x3058ECC")]
	[Token(Token = "0x6001631")]
	private void method_31()
	{
	}

	// Token: 0x06001632 RID: 5682 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x3058ED0", Offset = "0x3058ED0", VA = "0x3058ED0")]
	[Token(Token = "0x6001632")]
	private void method_32()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001633 RID: 5683 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305906C", Offset = "0x305906C", VA = "0x305906C")]
	[Token(Token = "0x6001633")]
	private void method_33()
	{
	}

	// Token: 0x06001634 RID: 5684 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001634")]
	[Address(RVA = "0x3059070", Offset = "0x3059070", VA = "0x3059070")]
	private void method_34()
	{
	}

	// Token: 0x06001635 RID: 5685 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059074", Offset = "0x3059074", VA = "0x3059074")]
	[Token(Token = "0x6001635")]
	private void method_35()
	{
	}

	// Token: 0x06001636 RID: 5686 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059078", Offset = "0x3059078", VA = "0x3059078")]
	[Token(Token = "0x6001636")]
	private void method_36()
	{
	}

	// Token: 0x06001637 RID: 5687 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305907C", Offset = "0x305907C", VA = "0x305907C")]
	[Token(Token = "0x6001637")]
	private void method_37()
	{
	}

	// Token: 0x06001638 RID: 5688 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059080", Offset = "0x3059080", VA = "0x3059080")]
	[Token(Token = "0x6001638")]
	private void method_38()
	{
	}

	// Token: 0x06001639 RID: 5689 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059084", Offset = "0x3059084", VA = "0x3059084")]
	[Token(Token = "0x6001639")]
	private void method_39()
	{
	}

	// Token: 0x0600163A RID: 5690 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600163A")]
	[Address(RVA = "0x3059088", Offset = "0x3059088", VA = "0x3059088")]
	private void method_40()
	{
	}

	// Token: 0x0600163B RID: 5691 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x600163B")]
	[Address(RVA = "0x305908C", Offset = "0x305908C", VA = "0x305908C")]
	private void method_41()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600163C RID: 5692 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x3059228", Offset = "0x3059228", VA = "0x3059228")]
	[Token(Token = "0x600163C")]
	private void method_42()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600163D RID: 5693 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x30593C4", Offset = "0x30593C4", VA = "0x30593C4")]
	[Token(Token = "0x600163D")]
	private void method_43()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600163E RID: 5694 RVA: 0x0002ACE8 File Offset: 0x00028EE8
	[Token(Token = "0x600163E")]
	[Address(RVA = "0x3059560", Offset = "0x3059560", VA = "0x3059560")]
	private void method_44()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Vector3 localPosition5 = transform2.localPosition;
		Transform transform3 = this.transform_1;
		Quaternion localRotation = transform3.localRotation;
		Transform transform4 = this.transform_2;
		Vector3 localPosition6 = transform4.localPosition;
		Transform transform5 = this.transform_2;
		Quaternion localRotation2 = transform5.localRotation;
		Transform transform6 = this.transform_0;
		Vector3 localPosition7 = transform6.localPosition;
		Transform transform7 = this.transform_0;
		Quaternion localRotation3 = transform7.localRotation;
	}

	// Token: 0x0600163F RID: 5695 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x30596FC", Offset = "0x30596FC", VA = "0x30596FC")]
	[Token(Token = "0x600163F")]
	private void method_45()
	{
	}

	// Token: 0x06001640 RID: 5696 RVA: 0x0002AD9C File Offset: 0x00028F9C
	[Token(Token = "0x6001640")]
	[Address(RVA = "0x3059700", Offset = "0x3059700", VA = "0x3059700")]
	private void method_46()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Vector3 localPosition7 = this.transform_0.localPosition;
		Transform transform7 = this.transform_0;
		Quaternion localRotation3 = transform7.localRotation;
	}

	// Token: 0x06001641 RID: 5697 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001641")]
	[Address(RVA = "0x305989C", Offset = "0x305989C", VA = "0x305989C")]
	private void method_47()
	{
	}

	// Token: 0x06001642 RID: 5698 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001642")]
	[Address(RVA = "0x30598A0", Offset = "0x30598A0", VA = "0x30598A0")]
	private void method_48()
	{
	}

	// Token: 0x06001643 RID: 5699 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001643")]
	[Address(RVA = "0x30598A4", Offset = "0x30598A4", VA = "0x30598A4")]
	private void method_49()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001644 RID: 5700 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001644")]
	[Address(RVA = "0x3059A40", Offset = "0x3059A40", VA = "0x3059A40")]
	private void method_50()
	{
	}

	// Token: 0x06001645 RID: 5701 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059A44", Offset = "0x3059A44", VA = "0x3059A44")]
	[Token(Token = "0x6001645")]
	private void method_51()
	{
	}

	// Token: 0x06001646 RID: 5702 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001646")]
	[Address(RVA = "0x3059A48", Offset = "0x3059A48", VA = "0x3059A48")]
	private void method_52()
	{
	}

	// Token: 0x06001647 RID: 5703 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001647")]
	[Address(RVA = "0x3059A4C", Offset = "0x3059A4C", VA = "0x3059A4C")]
	private void method_53()
	{
	}

	// Token: 0x06001648 RID: 5704 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001648")]
	[Address(RVA = "0x3059A50", Offset = "0x3059A50", VA = "0x3059A50")]
	private void method_54()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001649 RID: 5705 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059BEC", Offset = "0x3059BEC", VA = "0x3059BEC")]
	[Token(Token = "0x6001649")]
	private void method_55()
	{
	}

	// Token: 0x0600164A RID: 5706 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059BF0", Offset = "0x3059BF0", VA = "0x3059BF0")]
	[Token(Token = "0x600164A")]
	private void method_56()
	{
	}

	// Token: 0x0600164B RID: 5707 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059BF4", Offset = "0x3059BF4", VA = "0x3059BF4")]
	[Token(Token = "0x600164B")]
	private void method_57()
	{
	}

	// Token: 0x0600164C RID: 5708 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059BF8", Offset = "0x3059BF8", VA = "0x3059BF8")]
	[Token(Token = "0x600164C")]
	private void method_58()
	{
	}

	// Token: 0x0600164D RID: 5709 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600164D")]
	[Address(RVA = "0x3059BFC", Offset = "0x3059BFC", VA = "0x3059BFC")]
	private void method_59()
	{
	}

	// Token: 0x0600164E RID: 5710 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3059C00", Offset = "0x3059C00", VA = "0x3059C00")]
	[Token(Token = "0x600164E")]
	public PhysicsRig()
	{
	}

	// Token: 0x0600164F RID: 5711 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059C14", Offset = "0x3059C14", VA = "0x3059C14")]
	[Token(Token = "0x600164F")]
	private void method_60()
	{
	}

	// Token: 0x06001650 RID: 5712 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059C18", Offset = "0x3059C18", VA = "0x3059C18")]
	[Token(Token = "0x6001650")]
	private void method_61()
	{
	}

	// Token: 0x06001651 RID: 5713 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059C1C", Offset = "0x3059C1C", VA = "0x3059C1C")]
	[Token(Token = "0x6001651")]
	private void method_62()
	{
	}

	// Token: 0x06001652 RID: 5714 RVA: 0x0002ACE8 File Offset: 0x00028EE8
	[Token(Token = "0x6001652")]
	[Address(RVA = "0x3059C20", Offset = "0x3059C20", VA = "0x3059C20")]
	private void Update()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Vector3 localPosition5 = transform2.localPosition;
		Transform transform3 = this.transform_1;
		Quaternion localRotation = transform3.localRotation;
		Transform transform4 = this.transform_2;
		Vector3 localPosition6 = transform4.localPosition;
		Transform transform5 = this.transform_2;
		Quaternion localRotation2 = transform5.localRotation;
		Transform transform6 = this.transform_0;
		Vector3 localPosition7 = transform6.localPosition;
		Transform transform7 = this.transform_0;
		Quaternion localRotation3 = transform7.localRotation;
	}

	// Token: 0x06001653 RID: 5715 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059DBC", Offset = "0x3059DBC", VA = "0x3059DBC")]
	[Token(Token = "0x6001653")]
	private void method_63()
	{
	}

	// Token: 0x06001654 RID: 5716 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059DC0", Offset = "0x3059DC0", VA = "0x3059DC0")]
	[Token(Token = "0x6001654")]
	private void method_64()
	{
	}

	// Token: 0x06001655 RID: 5717 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059DC4", Offset = "0x3059DC4", VA = "0x3059DC4")]
	[Token(Token = "0x6001655")]
	private void method_65()
	{
	}

	// Token: 0x06001656 RID: 5718 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x3059DC8", Offset = "0x3059DC8", VA = "0x3059DC8")]
	[Token(Token = "0x6001656")]
	private void method_66()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001657 RID: 5719 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3059F64", Offset = "0x3059F64", VA = "0x3059F64")]
	[Token(Token = "0x6001657")]
	private void method_67()
	{
	}

	// Token: 0x06001658 RID: 5720 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001658")]
	[Address(RVA = "0x3059F68", Offset = "0x3059F68", VA = "0x3059F68")]
	private void method_68()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001659 RID: 5721 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305A104", Offset = "0x305A104", VA = "0x305A104")]
	[Token(Token = "0x6001659")]
	private void method_69()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600165A RID: 5722 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305A2A0", Offset = "0x305A2A0", VA = "0x305A2A0")]
	[Token(Token = "0x600165A")]
	private void method_70()
	{
	}

	// Token: 0x0600165B RID: 5723 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305A2A4", Offset = "0x305A2A4", VA = "0x305A2A4")]
	[Token(Token = "0x600165B")]
	private void method_71()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600165C RID: 5724 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600165C")]
	[Address(RVA = "0x305A440", Offset = "0x305A440", VA = "0x305A440")]
	private void method_72()
	{
	}

	// Token: 0x0600165D RID: 5725 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305A444", Offset = "0x305A444", VA = "0x305A444")]
	[Token(Token = "0x600165D")]
	private void method_73()
	{
	}

	// Token: 0x0600165E RID: 5726 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305A448", Offset = "0x305A448", VA = "0x305A448")]
	[Token(Token = "0x600165E")]
	private void method_74()
	{
	}

	// Token: 0x0600165F RID: 5727 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305A44C", Offset = "0x305A44C", VA = "0x305A44C")]
	[Token(Token = "0x600165F")]
	private void method_75()
	{
	}

	// Token: 0x06001660 RID: 5728 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001660")]
	[Address(RVA = "0x305A450", Offset = "0x305A450", VA = "0x305A450")]
	private void method_76()
	{
	}

	// Token: 0x06001661 RID: 5729 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001661")]
	[Address(RVA = "0x305A454", Offset = "0x305A454", VA = "0x305A454")]
	private void method_77()
	{
	}

	// Token: 0x06001662 RID: 5730 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305A458", Offset = "0x305A458", VA = "0x305A458")]
	[Token(Token = "0x6001662")]
	private void method_78()
	{
	}

	// Token: 0x06001663 RID: 5731 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001663")]
	[Address(RVA = "0x305A45C", Offset = "0x305A45C", VA = "0x305A45C")]
	private void method_79()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001664 RID: 5732 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001664")]
	[Address(RVA = "0x305A5F8", Offset = "0x305A5F8", VA = "0x305A5F8")]
	private void method_80()
	{
	}

	// Token: 0x06001665 RID: 5733 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305A5FC", Offset = "0x305A5FC", VA = "0x305A5FC")]
	[Token(Token = "0x6001665")]
	private void method_81()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001666 RID: 5734 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001666")]
	[Address(RVA = "0x305A798", Offset = "0x305A798", VA = "0x305A798")]
	private void method_82()
	{
	}

	// Token: 0x06001667 RID: 5735 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305A79C", Offset = "0x305A79C", VA = "0x305A79C")]
	[Token(Token = "0x6001667")]
	private void method_83()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001668 RID: 5736 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001668")]
	[Address(RVA = "0x305A938", Offset = "0x305A938", VA = "0x305A938")]
	private void method_84()
	{
	}

	// Token: 0x06001669 RID: 5737 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001669")]
	[Address(RVA = "0x305A93C", Offset = "0x305A93C", VA = "0x305A93C")]
	private void method_85()
	{
	}

	// Token: 0x0600166A RID: 5738 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305A940", Offset = "0x305A940", VA = "0x305A940")]
	[Token(Token = "0x600166A")]
	private void method_86()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600166B RID: 5739 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600166B")]
	[Address(RVA = "0x305AADC", Offset = "0x305AADC", VA = "0x305AADC")]
	private void method_87()
	{
	}

	// Token: 0x0600166C RID: 5740 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AAE0", Offset = "0x305AAE0", VA = "0x305AAE0")]
	[Token(Token = "0x600166C")]
	private void method_88()
	{
	}

	// Token: 0x0600166D RID: 5741 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600166D")]
	[Address(RVA = "0x305AAE4", Offset = "0x305AAE4", VA = "0x305AAE4")]
	private void method_89()
	{
	}

	// Token: 0x0600166E RID: 5742 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AAE8", Offset = "0x305AAE8", VA = "0x305AAE8")]
	[Token(Token = "0x600166E")]
	private void method_90()
	{
	}

	// Token: 0x0600166F RID: 5743 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305AAEC", Offset = "0x305AAEC", VA = "0x305AAEC")]
	[Token(Token = "0x600166F")]
	private void method_91()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001670 RID: 5744 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001670")]
	[Address(RVA = "0x305AC88", Offset = "0x305AC88", VA = "0x305AC88")]
	private void method_92()
	{
	}

	// Token: 0x06001671 RID: 5745 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001671")]
	[Address(RVA = "0x305AC8C", Offset = "0x305AC8C", VA = "0x305AC8C")]
	private void method_93()
	{
	}

	// Token: 0x06001672 RID: 5746 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001672")]
	[Address(RVA = "0x305AC90", Offset = "0x305AC90", VA = "0x305AC90")]
	private void method_94()
	{
	}

	// Token: 0x06001673 RID: 5747 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001673")]
	[Address(RVA = "0x305AC94", Offset = "0x305AC94", VA = "0x305AC94")]
	private void method_95()
	{
	}

	// Token: 0x06001674 RID: 5748 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AC98", Offset = "0x305AC98", VA = "0x305AC98")]
	[Token(Token = "0x6001674")]
	private void method_96()
	{
	}

	// Token: 0x06001675 RID: 5749 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001675")]
	[Address(RVA = "0x305AC9C", Offset = "0x305AC9C", VA = "0x305AC9C")]
	private void method_97()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001676 RID: 5750 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001676")]
	[Address(RVA = "0x305AE38", Offset = "0x305AE38", VA = "0x305AE38")]
	private void method_98()
	{
	}

	// Token: 0x06001677 RID: 5751 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AE3C", Offset = "0x305AE3C", VA = "0x305AE3C")]
	[Token(Token = "0x6001677")]
	private void Start()
	{
	}

	// Token: 0x06001678 RID: 5752 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305AE40", Offset = "0x305AE40", VA = "0x305AE40")]
	[Token(Token = "0x6001678")]
	private void method_99()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001679 RID: 5753 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AFDC", Offset = "0x305AFDC", VA = "0x305AFDC")]
	[Token(Token = "0x6001679")]
	private void method_100()
	{
	}

	// Token: 0x0600167A RID: 5754 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AFE0", Offset = "0x305AFE0", VA = "0x305AFE0")]
	[Token(Token = "0x600167A")]
	private void method_101()
	{
	}

	// Token: 0x0600167B RID: 5755 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AFE4", Offset = "0x305AFE4", VA = "0x305AFE4")]
	[Token(Token = "0x600167B")]
	private void method_102()
	{
	}

	// Token: 0x0600167C RID: 5756 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305AFE8", Offset = "0x305AFE8", VA = "0x305AFE8")]
	[Token(Token = "0x600167C")]
	private void method_103()
	{
	}

	// Token: 0x0600167D RID: 5757 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305AFEC", Offset = "0x305AFEC", VA = "0x305AFEC")]
	[Token(Token = "0x600167D")]
	private void method_104()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600167E RID: 5758 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600167E")]
	[Address(RVA = "0x305B188", Offset = "0x305B188", VA = "0x305B188")]
	private void method_105()
	{
	}

	// Token: 0x0600167F RID: 5759 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305B18C", Offset = "0x305B18C", VA = "0x305B18C")]
	[Token(Token = "0x600167F")]
	private void method_106()
	{
	}

	// Token: 0x06001680 RID: 5760 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001680")]
	[Address(RVA = "0x305B190", Offset = "0x305B190", VA = "0x305B190")]
	private void method_107()
	{
	}

	// Token: 0x06001681 RID: 5761 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305B194", Offset = "0x305B194", VA = "0x305B194")]
	[Token(Token = "0x6001681")]
	private void method_108()
	{
	}

	// Token: 0x06001682 RID: 5762 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305B198", Offset = "0x305B198", VA = "0x305B198")]
	[Token(Token = "0x6001682")]
	private void method_109()
	{
	}

	// Token: 0x06001683 RID: 5763 RVA: 0x0002AE54 File Offset: 0x00029054
	[Address(RVA = "0x305B19C", Offset = "0x305B19C", VA = "0x305B19C")]
	[Token(Token = "0x6001683")]
	private void method_110()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_0;
		Vector3 localPosition7 = transform6.localPosition;
		Transform transform7 = this.transform_0;
		Quaternion localRotation2 = transform7.localRotation;
	}

	// Token: 0x06001684 RID: 5764 RVA: 0x0002AD9C File Offset: 0x00028F9C
	[Address(RVA = "0x305B338", Offset = "0x305B338", VA = "0x305B338")]
	[Token(Token = "0x6001684")]
	private void method_111()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Vector3 localPosition7 = this.transform_0.localPosition;
		Transform transform7 = this.transform_0;
		Quaternion localRotation3 = transform7.localRotation;
	}

	// Token: 0x06001685 RID: 5765 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305B4D4", Offset = "0x305B4D4", VA = "0x305B4D4")]
	[Token(Token = "0x6001685")]
	private void method_112()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001686 RID: 5766 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305B670", Offset = "0x305B670", VA = "0x305B670")]
	[Token(Token = "0x6001686")]
	private void method_113()
	{
	}

	// Token: 0x06001687 RID: 5767 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x6001687")]
	[Address(RVA = "0x305B674", Offset = "0x305B674", VA = "0x305B674")]
	private void method_114()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x06001688 RID: 5768 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305B810", Offset = "0x305B810", VA = "0x305B810")]
	[Token(Token = "0x6001688")]
	private void method_115()
	{
	}

	// Token: 0x06001689 RID: 5769 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305B814", Offset = "0x305B814", VA = "0x305B814")]
	[Token(Token = "0x6001689")]
	private void method_116()
	{
	}

	// Token: 0x0600168A RID: 5770 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x600168A")]
	[Address(RVA = "0x305B818", Offset = "0x305B818", VA = "0x305B818")]
	private void method_117()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600168B RID: 5771 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Address(RVA = "0x305B9B4", Offset = "0x305B9B4", VA = "0x305B9B4")]
	[Token(Token = "0x600168B")]
	private void method_118()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600168C RID: 5772 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305BB50", Offset = "0x305BB50", VA = "0x305BB50")]
	[Token(Token = "0x600168C")]
	private void method_119()
	{
	}

	// Token: 0x0600168D RID: 5773 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600168D")]
	[Address(RVA = "0x305BB54", Offset = "0x305BB54", VA = "0x305BB54")]
	private void method_120()
	{
	}

	// Token: 0x0600168E RID: 5774 RVA: 0x0002AAC8 File Offset: 0x00028CC8
	[Token(Token = "0x600168E")]
	[Address(RVA = "0x305BB58", Offset = "0x305BB58", VA = "0x305BB58")]
	private void method_121()
	{
		Transform transform = this.transform_0;
		CapsuleCollider capsuleCollider = this.capsuleCollider_0;
		Vector3 localPosition = transform.localPosition;
		float height;
		capsuleCollider.height = height;
		Transform transform2 = this.capsuleCollider_0.transform;
		Vector3 localPosition2 = this.transform_0.localPosition;
		Vector3 localPosition3 = this.transform_0.localPosition;
		Vector3 localPosition4 = this.transform_0.localPosition;
		Transform transform3 = this.transform_1;
		Vector3 localPosition5 = transform3.localPosition;
		Transform transform4 = this.transform_1;
		Quaternion localRotation = transform4.localRotation;
		Transform transform5 = this.transform_2;
		Vector3 localPosition6 = transform5.localPosition;
		Transform transform6 = this.transform_2;
		Quaternion localRotation2 = transform6.localRotation;
		Transform transform7 = this.transform_0;
		Vector3 localPosition7 = transform7.localPosition;
		Transform transform8 = this.transform_0;
		Quaternion localRotation3 = transform8.localRotation;
	}

	// Token: 0x0600168F RID: 5775 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305BCF4", Offset = "0x305BCF4", VA = "0x305BCF4")]
	[Token(Token = "0x600168F")]
	private void method_122()
	{
	}

	// Token: 0x06001690 RID: 5776 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x305BCF8", Offset = "0x305BCF8", VA = "0x305BCF8")]
	[Token(Token = "0x6001690")]
	private void method_123()
	{
	}

	// Token: 0x040002DF RID: 735
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002DF")]
	public Transform transform_0;

	// Token: 0x040002E0 RID: 736
	[Token(Token = "0x40002E0")]
	[FieldOffset(Offset = "0x20")]
	public Transform transform_1;

	// Token: 0x040002E1 RID: 737
	[Token(Token = "0x40002E1")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_2;

	// Token: 0x040002E2 RID: 738
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40002E2")]
	public ConfigurableJoint configurableJoint_0;

	// Token: 0x040002E3 RID: 739
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40002E3")]
	public ConfigurableJoint configurableJoint_1;

	// Token: 0x040002E4 RID: 740
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40002E4")]
	public ConfigurableJoint configurableJoint_2;

	// Token: 0x040002E5 RID: 741
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40002E5")]
	public CapsuleCollider capsuleCollider_0;

	// Token: 0x040002E6 RID: 742
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40002E6")]
	public Transform transform_3;

	// Token: 0x040002E7 RID: 743
	[Token(Token = "0x40002E7")]
	[FieldOffset(Offset = "0x58")]
	public float float_0;

	// Token: 0x040002E8 RID: 744
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x40002E8")]
	public float float_1;
}
