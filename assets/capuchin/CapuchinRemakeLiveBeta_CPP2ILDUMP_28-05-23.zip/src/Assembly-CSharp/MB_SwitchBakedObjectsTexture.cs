﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000089 RID: 137
[Token(Token = "0x2000089")]
public class MB_SwitchBakedObjectsTexture : MonoBehaviour
{
	// Token: 0x060013D0 RID: 5072 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013D0")]
	[Address(RVA = "0x16D7484", Offset = "0x16D7484", VA = "0x16D7484")]
	public void method_0()
	{
	}

	// Token: 0x060013D1 RID: 5073 RVA: 0x000282B0 File Offset: 0x000264B0
	[Token(Token = "0x60013D1")]
	[Address(RVA = "0x16D7564", Offset = "0x16D7564", VA = "0x16D7564")]
	public void method_1()
	{
	}

	// Token: 0x060013D2 RID: 5074 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16D7608", Offset = "0x16D7608", VA = "0x16D7608")]
	[Token(Token = "0x60013D2")]
	public void Start()
	{
	}

	// Token: 0x060013D3 RID: 5075 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013D3")]
	[Address(RVA = "0x16D76AC", Offset = "0x16D76AC", VA = "0x16D76AC")]
	public void method_2()
	{
	}

	// Token: 0x060013D4 RID: 5076 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013D4")]
	[Address(RVA = "0x16D778C", Offset = "0x16D778C", VA = "0x16D778C")]
	public void method_3()
	{
	}

	// Token: 0x060013D5 RID: 5077 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013D5")]
	[Address(RVA = "0x16D786C", Offset = "0x16D786C", VA = "0x16D786C")]
	public void method_4()
	{
	}

	// Token: 0x060013D6 RID: 5078 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16D794C", Offset = "0x16D794C", VA = "0x16D794C")]
	[Token(Token = "0x60013D6")]
	public void method_5()
	{
	}

	// Token: 0x060013D7 RID: 5079 RVA: 0x000282C0 File Offset: 0x000264C0
	[Token(Token = "0x60013D7")]
	[Address(RVA = "0x16D79F0", Offset = "0x16D79F0", VA = "0x16D79F0")]
	public void method_6()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013D8 RID: 5080 RVA: 0x000282F0 File Offset: 0x000264F0
	[Token(Token = "0x60013D8")]
	[Address(RVA = "0x16D7C8C", Offset = "0x16D7C8C", VA = "0x16D7C8C")]
	public void method_7()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013D9 RID: 5081 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013D9")]
	[Address(RVA = "0x16D7F38", Offset = "0x16D7F38", VA = "0x16D7F38")]
	public void method_8()
	{
	}

	// Token: 0x060013DA RID: 5082 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16D8018", Offset = "0x16D8018", VA = "0x16D8018")]
	[Token(Token = "0x60013DA")]
	public void method_9()
	{
	}

	// Token: 0x060013DB RID: 5083 RVA: 0x00028320 File Offset: 0x00026520
	[Address(RVA = "0x16D80BC", Offset = "0x16D80BC", VA = "0x16D80BC")]
	[Token(Token = "0x60013DB")]
	public void method_10()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013DC RID: 5084 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16D8358", Offset = "0x16D8358", VA = "0x16D8358")]
	[Token(Token = "0x60013DC")]
	public void method_11()
	{
	}

	// Token: 0x060013DD RID: 5085 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013DD")]
	[Address(RVA = "0x16D8438", Offset = "0x16D8438", VA = "0x16D8438")]
	public void method_12()
	{
	}

	// Token: 0x060013DE RID: 5086 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16D8518", Offset = "0x16D8518", VA = "0x16D8518")]
	[Token(Token = "0x60013DE")]
	public void method_13()
	{
	}

	// Token: 0x060013DF RID: 5087 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013DF")]
	[Address(RVA = "0x16D85F8", Offset = "0x16D85F8", VA = "0x16D85F8")]
	public void method_14()
	{
	}

	// Token: 0x060013E0 RID: 5088 RVA: 0x000276A0 File Offset: 0x000258A0
	[Token(Token = "0x60013E0")]
	[Address(RVA = "0x16D86D8", Offset = "0x16D86D8", VA = "0x16D86D8")]
	public void method_15()
	{
	}

	// Token: 0x060013E1 RID: 5089 RVA: 0x00028350 File Offset: 0x00026550
	[Address(RVA = "0x16D877C", Offset = "0x16D877C", VA = "0x16D877C")]
	[Token(Token = "0x60013E1")]
	public void method_16()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013E2 RID: 5090 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16D8A34", Offset = "0x16D8A34", VA = "0x16D8A34")]
	[Token(Token = "0x60013E2")]
	public void method_17()
	{
	}

	// Token: 0x060013E3 RID: 5091 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013E3")]
	[Address(RVA = "0x16D8B14", Offset = "0x16D8B14", VA = "0x16D8B14")]
	public void method_18()
	{
	}

	// Token: 0x060013E4 RID: 5092 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16D8BF4", Offset = "0x16D8BF4", VA = "0x16D8BF4")]
	[Token(Token = "0x60013E4")]
	public void method_19()
	{
	}

	// Token: 0x060013E5 RID: 5093 RVA: 0x00028380 File Offset: 0x00026580
	[Address(RVA = "0x16D8CD4", Offset = "0x16D8CD4", VA = "0x16D8CD4")]
	[Token(Token = "0x60013E5")]
	public void method_20()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013E6 RID: 5094 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16D8F80", Offset = "0x16D8F80", VA = "0x16D8F80")]
	[Token(Token = "0x60013E6")]
	public void method_21()
	{
	}

	// Token: 0x060013E7 RID: 5095 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16D9060", Offset = "0x16D9060", VA = "0x16D9060")]
	[Token(Token = "0x60013E7")]
	public void method_22()
	{
	}

	// Token: 0x060013E8 RID: 5096 RVA: 0x000283B0 File Offset: 0x000265B0
	[Token(Token = "0x60013E8")]
	[Address(RVA = "0x16D9104", Offset = "0x16D9104", VA = "0x16D9104")]
	public void method_23()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
			sharedMaterial == sharedMaterial;
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013E9 RID: 5097 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16D93B0", Offset = "0x16D93B0", VA = "0x16D93B0")]
	[Token(Token = "0x60013E9")]
	public void method_24()
	{
	}

	// Token: 0x060013EA RID: 5098 RVA: 0x00028380 File Offset: 0x00026580
	[Token(Token = "0x60013EA")]
	[Address(RVA = "0x16D9490", Offset = "0x16D9490", VA = "0x16D9490")]
	public void method_25()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013EB RID: 5099 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16D972C", Offset = "0x16D972C", VA = "0x16D972C")]
	[Token(Token = "0x60013EB")]
	public void method_26()
	{
	}

	// Token: 0x060013EC RID: 5100 RVA: 0x000283E8 File Offset: 0x000265E8
	[Token(Token = "0x60013EC")]
	[Address(RVA = "0x16D980C", Offset = "0x16D980C", VA = "0x16D980C")]
	public void method_27()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013ED RID: 5101 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013ED")]
	[Address(RVA = "0x16D9AC0", Offset = "0x16D9AC0", VA = "0x16D9AC0")]
	public void method_28()
	{
	}

	// Token: 0x060013EE RID: 5102 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x16D9BA0", Offset = "0x16D9BA0", VA = "0x16D9BA0")]
	[Token(Token = "0x60013EE")]
	public MB_SwitchBakedObjectsTexture()
	{
	}

	// Token: 0x060013EF RID: 5103 RVA: 0x00028418 File Offset: 0x00026618
	[Token(Token = "0x60013EF")]
	[Address(RVA = "0x16D9BA8", Offset = "0x16D9BA8", VA = "0x16D9BA8")]
	public void Update()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013F0 RID: 5104 RVA: 0x00028448 File Offset: 0x00026648
	[Address(RVA = "0x16D9E54", Offset = "0x16D9E54", VA = "0x16D9E54")]
	[Token(Token = "0x60013F0")]
	public void method_29()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013F1 RID: 5105 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013F1")]
	[Address(RVA = "0x16DA10C", Offset = "0x16DA10C", VA = "0x16DA10C")]
	public void method_30()
	{
	}

	// Token: 0x060013F2 RID: 5106 RVA: 0x00028448 File Offset: 0x00026648
	[Token(Token = "0x60013F2")]
	[Address(RVA = "0x16DA1EC", Offset = "0x16DA1EC", VA = "0x16DA1EC")]
	public void method_31()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013F3 RID: 5107 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DA488", Offset = "0x16DA488", VA = "0x16DA488")]
	[Token(Token = "0x60013F3")]
	public void method_32()
	{
	}

	// Token: 0x060013F4 RID: 5108 RVA: 0x00028478 File Offset: 0x00026678
	[Address(RVA = "0x16DA568", Offset = "0x16DA568", VA = "0x16DA568")]
	[Token(Token = "0x60013F4")]
	public void method_33()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013F5 RID: 5109 RVA: 0x000284A8 File Offset: 0x000266A8
	[Address(RVA = "0x16DA804", Offset = "0x16DA804", VA = "0x16DA804")]
	[Token(Token = "0x60013F5")]
	public void method_34()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013F6 RID: 5110 RVA: 0x00028350 File Offset: 0x00026550
	[Address(RVA = "0x16DAABC", Offset = "0x16DAABC", VA = "0x16DAABC")]
	[Token(Token = "0x60013F6")]
	public void method_35()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x060013F7 RID: 5111 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DAD70", Offset = "0x16DAD70", VA = "0x16DAD70")]
	[Token(Token = "0x60013F7")]
	public void method_36()
	{
	}

	// Token: 0x060013F8 RID: 5112 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60013F8")]
	[Address(RVA = "0x16DAE50", Offset = "0x16DAE50", VA = "0x16DAE50")]
	public void method_37()
	{
	}

	// Token: 0x060013F9 RID: 5113 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16DAF30", Offset = "0x16DAF30", VA = "0x16DAF30")]
	[Token(Token = "0x60013F9")]
	public void method_38()
	{
	}

	// Token: 0x060013FA RID: 5114 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16DAFD4", Offset = "0x16DAFD4", VA = "0x16DAFD4")]
	[Token(Token = "0x60013FA")]
	public void method_39()
	{
	}

	// Token: 0x060013FB RID: 5115 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16DB078", Offset = "0x16DB078", VA = "0x16DB078")]
	[Token(Token = "0x60013FB")]
	public void method_40()
	{
	}

	// Token: 0x060013FC RID: 5116 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DB11C", Offset = "0x16DB11C", VA = "0x16DB11C")]
	[Token(Token = "0x60013FC")]
	public void method_41()
	{
	}

	// Token: 0x060013FD RID: 5117 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DB1FC", Offset = "0x16DB1FC", VA = "0x16DB1FC")]
	[Token(Token = "0x60013FD")]
	public void method_42()
	{
	}

	// Token: 0x060013FE RID: 5118 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16DB2DC", Offset = "0x16DB2DC", VA = "0x16DB2DC")]
	[Token(Token = "0x60013FE")]
	public void method_43()
	{
	}

	// Token: 0x060013FF RID: 5119 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DB380", Offset = "0x16DB380", VA = "0x16DB380")]
	[Token(Token = "0x60013FF")]
	public void method_44()
	{
	}

	// Token: 0x06001400 RID: 5120 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001400")]
	[Address(RVA = "0x16DB460", Offset = "0x16DB460", VA = "0x16DB460")]
	public void method_45()
	{
	}

	// Token: 0x06001401 RID: 5121 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001401")]
	[Address(RVA = "0x16DB540", Offset = "0x16DB540", VA = "0x16DB540")]
	public void method_46()
	{
	}

	// Token: 0x06001402 RID: 5122 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DB620", Offset = "0x16DB620", VA = "0x16DB620")]
	[Token(Token = "0x6001402")]
	public void method_47()
	{
	}

	// Token: 0x06001403 RID: 5123 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DB700", Offset = "0x16DB700", VA = "0x16DB700")]
	[Token(Token = "0x6001403")]
	public void method_48()
	{
	}

	// Token: 0x06001404 RID: 5124 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DB7E0", Offset = "0x16DB7E0", VA = "0x16DB7E0")]
	[Token(Token = "0x6001404")]
	public void method_49()
	{
	}

	// Token: 0x06001405 RID: 5125 RVA: 0x000284D8 File Offset: 0x000266D8
	[Token(Token = "0x6001405")]
	[Address(RVA = "0x16DB8C0", Offset = "0x16DB8C0", VA = "0x16DB8C0")]
	public void method_50()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001406 RID: 5126 RVA: 0x00028320 File Offset: 0x00026520
	[Address(RVA = "0x16DBB70", Offset = "0x16DBB70", VA = "0x16DBB70")]
	[Token(Token = "0x6001406")]
	public void method_51()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001407 RID: 5127 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16DBE0C", Offset = "0x16DBE0C", VA = "0x16DBE0C")]
	[Token(Token = "0x6001407")]
	public void method_52()
	{
	}

	// Token: 0x06001408 RID: 5128 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DBEB0", Offset = "0x16DBEB0", VA = "0x16DBEB0")]
	[Token(Token = "0x6001408")]
	public void method_53()
	{
	}

	// Token: 0x06001409 RID: 5129 RVA: 0x000276A0 File Offset: 0x000258A0
	[Token(Token = "0x6001409")]
	[Address(RVA = "0x16DBF90", Offset = "0x16DBF90", VA = "0x16DBF90")]
	public void method_54()
	{
	}

	// Token: 0x0600140A RID: 5130 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DC034", Offset = "0x16DC034", VA = "0x16DC034")]
	[Token(Token = "0x600140A")]
	public void method_55()
	{
	}

	// Token: 0x0600140B RID: 5131 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DC114", Offset = "0x16DC114", VA = "0x16DC114")]
	[Token(Token = "0x600140B")]
	public void method_56()
	{
	}

	// Token: 0x0600140C RID: 5132 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DC1F4", Offset = "0x16DC1F4", VA = "0x16DC1F4")]
	[Token(Token = "0x600140C")]
	public void method_57()
	{
	}

	// Token: 0x0600140D RID: 5133 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600140D")]
	[Address(RVA = "0x16DC2D4", Offset = "0x16DC2D4", VA = "0x16DC2D4")]
	public void OnGUI()
	{
	}

	// Token: 0x0600140E RID: 5134 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16DC3B4", Offset = "0x16DC3B4", VA = "0x16DC3B4")]
	[Token(Token = "0x600140E")]
	public void method_58()
	{
	}

	// Token: 0x0600140F RID: 5135 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DC458", Offset = "0x16DC458", VA = "0x16DC458")]
	[Token(Token = "0x600140F")]
	public void method_59()
	{
	}

	// Token: 0x06001410 RID: 5136 RVA: 0x000276A0 File Offset: 0x000258A0
	[Token(Token = "0x6001410")]
	[Address(RVA = "0x16DC538", Offset = "0x16DC538", VA = "0x16DC538")]
	public void method_60()
	{
	}

	// Token: 0x06001411 RID: 5137 RVA: 0x00028508 File Offset: 0x00026708
	[Token(Token = "0x6001411")]
	[Address(RVA = "0x16DC5DC", Offset = "0x16DC5DC", VA = "0x16DC5DC")]
	public void method_61()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001412 RID: 5138 RVA: 0x000283E8 File Offset: 0x000265E8
	[Token(Token = "0x6001412")]
	[Address(RVA = "0x16DC87C", Offset = "0x16DC87C", VA = "0x16DC87C")]
	public void method_62()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001413 RID: 5139 RVA: 0x000284D8 File Offset: 0x000266D8
	[Token(Token = "0x6001413")]
	[Address(RVA = "0x16DCB18", Offset = "0x16DCB18", VA = "0x16DCB18")]
	public void method_63()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001414 RID: 5140 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001414")]
	[Address(RVA = "0x16DCDC8", Offset = "0x16DCDC8", VA = "0x16DCDC8")]
	public void method_64()
	{
	}

	// Token: 0x06001415 RID: 5141 RVA: 0x000276A0 File Offset: 0x000258A0
	[Address(RVA = "0x16DCEA8", Offset = "0x16DCEA8", VA = "0x16DCEA8")]
	[Token(Token = "0x6001415")]
	public void method_65()
	{
	}

	// Token: 0x06001416 RID: 5142 RVA: 0x000276A0 File Offset: 0x000258A0
	[Token(Token = "0x6001416")]
	[Address(RVA = "0x16DCF4C", Offset = "0x16DCF4C", VA = "0x16DCF4C")]
	public void method_66()
	{
	}

	// Token: 0x06001417 RID: 5143 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DCFF0", Offset = "0x16DCFF0", VA = "0x16DCFF0")]
	[Token(Token = "0x6001417")]
	public void method_67()
	{
	}

	// Token: 0x06001418 RID: 5144 RVA: 0x00028320 File Offset: 0x00026520
	[Token(Token = "0x6001418")]
	[Address(RVA = "0x16DD0D0", Offset = "0x16DD0D0", VA = "0x16DD0D0")]
	public void method_68()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			if (this.material_0 != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x06001419 RID: 5145 RVA: 0x00028538 File Offset: 0x00026738
	[Address(RVA = "0x16DD36C", Offset = "0x16DD36C", VA = "0x16DD36C")]
	[Token(Token = "0x6001419")]
	public void method_69()
	{
		do
		{
			Material sharedMaterial = this.meshRenderer_0.sharedMaterial;
			Material[] array = this.material_0;
			if (array != null)
			{
			}
		}
		while (this.material_0 != null);
		throw new NullReferenceException();
	}

	// Token: 0x0600141A RID: 5146 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x16DD624", Offset = "0x16DD624", VA = "0x16DD624")]
	[Token(Token = "0x600141A")]
	public void method_70()
	{
	}

	// Token: 0x0600141B RID: 5147 RVA: 0x000276A0 File Offset: 0x000258A0
	[Token(Token = "0x600141B")]
	[Address(RVA = "0x16DD704", Offset = "0x16DD704", VA = "0x16DD704")]
	public void method_71()
	{
	}

	// Token: 0x0600141C RID: 5148 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600141C")]
	[Address(RVA = "0x16DD7A8", Offset = "0x16DD7A8", VA = "0x16DD7A8")]
	public void method_72()
	{
	}

	// Token: 0x040002A2 RID: 674
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40002A2")]
	public MeshRenderer meshRenderer_0;

	// Token: 0x040002A3 RID: 675
	[Token(Token = "0x40002A3")]
	[FieldOffset(Offset = "0x20")]
	public Material[] material_0;

	// Token: 0x040002A4 RID: 676
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40002A4")]
	public MB3_MeshBaker mb3_MeshBaker_0;
}
