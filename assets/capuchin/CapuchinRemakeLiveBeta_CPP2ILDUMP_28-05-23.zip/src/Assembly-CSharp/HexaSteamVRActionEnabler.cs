﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000A2 RID: 162
[Token(Token = "0x20000A2")]
public class HexaSteamVRActionEnabler : MonoBehaviour
{
	// Token: 0x060017A1 RID: 6049 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EED8", Offset = "0x337EED8", VA = "0x337EED8")]
	[Token(Token = "0x60017A1")]
	private void method_0()
	{
	}

	// Token: 0x060017A2 RID: 6050 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EEDC", Offset = "0x337EEDC", VA = "0x337EEDC")]
	[Token(Token = "0x60017A2")]
	private void method_1()
	{
	}

	// Token: 0x060017A3 RID: 6051 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EEE0", Offset = "0x337EEE0", VA = "0x337EEE0")]
	[Token(Token = "0x60017A3")]
	private void method_2()
	{
	}

	// Token: 0x060017A4 RID: 6052 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017A4")]
	[Address(RVA = "0x337EEE4", Offset = "0x337EEE4", VA = "0x337EEE4")]
	private void method_3()
	{
	}

	// Token: 0x060017A5 RID: 6053 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EEE8", Offset = "0x337EEE8", VA = "0x337EEE8")]
	[Token(Token = "0x60017A5")]
	private void method_4()
	{
	}

	// Token: 0x060017A6 RID: 6054 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60017A6")]
	[Address(RVA = "0x337EEEC", Offset = "0x337EEEC", VA = "0x337EEEC")]
	public HexaSteamVRActionEnabler()
	{
	}

	// Token: 0x060017A7 RID: 6055 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017A7")]
	[Address(RVA = "0x337EEFC", Offset = "0x337EEFC", VA = "0x337EEFC")]
	private void method_5()
	{
	}

	// Token: 0x060017A8 RID: 6056 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017A8")]
	[Address(RVA = "0x337EF00", Offset = "0x337EF00", VA = "0x337EF00")]
	private void method_6()
	{
	}

	// Token: 0x060017A9 RID: 6057 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017A9")]
	[Address(RVA = "0x337EF04", Offset = "0x337EF04", VA = "0x337EF04")]
	private void method_7()
	{
	}

	// Token: 0x060017AA RID: 6058 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017AA")]
	[Address(RVA = "0x337EF08", Offset = "0x337EF08", VA = "0x337EF08")]
	private void method_8()
	{
	}

	// Token: 0x060017AB RID: 6059 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017AB")]
	[Address(RVA = "0x337EF0C", Offset = "0x337EF0C", VA = "0x337EF0C")]
	private void method_9()
	{
	}

	// Token: 0x060017AC RID: 6060 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EF10", Offset = "0x337EF10", VA = "0x337EF10")]
	[Token(Token = "0x60017AC")]
	private void method_10()
	{
	}

	// Token: 0x060017AD RID: 6061 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017AD")]
	[Address(RVA = "0x337EF14", Offset = "0x337EF14", VA = "0x337EF14")]
	private void method_11()
	{
	}

	// Token: 0x060017AE RID: 6062 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EF18", Offset = "0x337EF18", VA = "0x337EF18")]
	[Token(Token = "0x60017AE")]
	private void OnDestroy()
	{
	}

	// Token: 0x060017AF RID: 6063 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017AF")]
	[Address(RVA = "0x337EF1C", Offset = "0x337EF1C", VA = "0x337EF1C")]
	private void method_12()
	{
	}

	// Token: 0x060017B0 RID: 6064 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EF20", Offset = "0x337EF20", VA = "0x337EF20")]
	[Token(Token = "0x60017B0")]
	private void method_13()
	{
	}

	// Token: 0x060017B1 RID: 6065 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017B1")]
	[Address(RVA = "0x337EF24", Offset = "0x337EF24", VA = "0x337EF24")]
	private void method_14()
	{
	}

	// Token: 0x060017B2 RID: 6066 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017B2")]
	[Address(RVA = "0x337EF28", Offset = "0x337EF28", VA = "0x337EF28")]
	private void method_15()
	{
	}

	// Token: 0x060017B3 RID: 6067 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EF2C", Offset = "0x337EF2C", VA = "0x337EF2C")]
	[Token(Token = "0x60017B3")]
	private void Start()
	{
	}

	// Token: 0x060017B4 RID: 6068 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017B4")]
	[Address(RVA = "0x337EF30", Offset = "0x337EF30", VA = "0x337EF30")]
	private void method_16()
	{
	}

	// Token: 0x060017B5 RID: 6069 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017B5")]
	[Address(RVA = "0x337EF34", Offset = "0x337EF34", VA = "0x337EF34")]
	private void method_17()
	{
	}

	// Token: 0x060017B6 RID: 6070 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017B6")]
	[Address(RVA = "0x337EF38", Offset = "0x337EF38", VA = "0x337EF38")]
	private void method_18()
	{
	}

	// Token: 0x060017B7 RID: 6071 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EF3C", Offset = "0x337EF3C", VA = "0x337EF3C")]
	[Token(Token = "0x60017B7")]
	private void method_19()
	{
	}

	// Token: 0x060017B8 RID: 6072 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017B8")]
	[Address(RVA = "0x337EF40", Offset = "0x337EF40", VA = "0x337EF40")]
	private void method_20()
	{
	}

	// Token: 0x060017B9 RID: 6073 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EF44", Offset = "0x337EF44", VA = "0x337EF44")]
	[Token(Token = "0x60017B9")]
	private void method_21()
	{
	}

	// Token: 0x060017BA RID: 6074 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017BA")]
	[Address(RVA = "0x337EF48", Offset = "0x337EF48", VA = "0x337EF48")]
	private void method_22()
	{
	}

	// Token: 0x060017BB RID: 6075 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017BB")]
	[Address(RVA = "0x337EF4C", Offset = "0x337EF4C", VA = "0x337EF4C")]
	private void method_23()
	{
	}

	// Token: 0x060017BC RID: 6076 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x337EF50", Offset = "0x337EF50", VA = "0x337EF50")]
	[Token(Token = "0x60017BC")]
	private void method_24()
	{
	}

	// Token: 0x060017BD RID: 6077 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017BD")]
	[Address(RVA = "0x337EF54", Offset = "0x337EF54", VA = "0x337EF54")]
	private void method_25()
	{
	}

	// Token: 0x060017BE RID: 6078 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x60017BE")]
	[Address(RVA = "0x337EF58", Offset = "0x337EF58", VA = "0x337EF58")]
	private void method_26()
	{
	}

	// Token: 0x0400030D RID: 781
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400030D")]
	public bool bool_0;

	// Token: 0x0400030E RID: 782
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x400030E")]
	public bool bool_1;

	// Token: 0x0400030F RID: 783
	[Token(Token = "0x400030F")]
	[FieldOffset(Offset = "0x1A")]
	public bool bool_2;
}
