﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000072 RID: 114
[Token(Token = "0x2000072")]
public class InputFocus : MonoBehaviour
{
	// Token: 0x06001007 RID: 4103 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F34", Offset = "0x3391F34", VA = "0x3391F34")]
	[Token(Token = "0x6001007")]
	private void method_0()
	{
	}

	// Token: 0x06001008 RID: 4104 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F38", Offset = "0x3391F38", VA = "0x3391F38")]
	[Token(Token = "0x6001008")]
	private void method_1()
	{
	}

	// Token: 0x06001009 RID: 4105 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F3C", Offset = "0x3391F3C", VA = "0x3391F3C")]
	[Token(Token = "0x6001009")]
	private void method_2()
	{
	}

	// Token: 0x0600100A RID: 4106 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F40", Offset = "0x3391F40", VA = "0x3391F40")]
	[Token(Token = "0x600100A")]
	private void method_3()
	{
	}

	// Token: 0x0600100B RID: 4107 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F44", Offset = "0x3391F44", VA = "0x3391F44")]
	[Token(Token = "0x600100B")]
	private void method_4()
	{
	}

	// Token: 0x0600100C RID: 4108 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F48", Offset = "0x3391F48", VA = "0x3391F48")]
	[Token(Token = "0x600100C")]
	private void method_5()
	{
	}

	// Token: 0x0600100D RID: 4109 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600100D")]
	[Address(RVA = "0x3391F4C", Offset = "0x3391F4C", VA = "0x3391F4C")]
	private void method_6()
	{
	}

	// Token: 0x0600100E RID: 4110 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F50", Offset = "0x3391F50", VA = "0x3391F50")]
	[Token(Token = "0x600100E")]
	private void method_7()
	{
	}

	// Token: 0x0600100F RID: 4111 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F54", Offset = "0x3391F54", VA = "0x3391F54")]
	[Token(Token = "0x600100F")]
	private void method_8()
	{
	}

	// Token: 0x06001010 RID: 4112 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001010")]
	[Address(RVA = "0x3391F58", Offset = "0x3391F58", VA = "0x3391F58")]
	private void method_9()
	{
	}

	// Token: 0x06001011 RID: 4113 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001011")]
	[Address(RVA = "0x3391F5C", Offset = "0x3391F5C", VA = "0x3391F5C")]
	private void method_10()
	{
	}

	// Token: 0x06001012 RID: 4114 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001012")]
	[Address(RVA = "0x3391F60", Offset = "0x3391F60", VA = "0x3391F60")]
	private void method_11()
	{
	}

	// Token: 0x06001013 RID: 4115 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F64", Offset = "0x3391F64", VA = "0x3391F64")]
	[Token(Token = "0x6001013")]
	private void method_12()
	{
	}

	// Token: 0x06001014 RID: 4116 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001014")]
	[Address(RVA = "0x3391F68", Offset = "0x3391F68", VA = "0x3391F68")]
	private void method_13()
	{
	}

	// Token: 0x06001015 RID: 4117 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001015")]
	[Address(RVA = "0x3391F6C", Offset = "0x3391F6C", VA = "0x3391F6C")]
	private void method_14()
	{
	}

	// Token: 0x06001016 RID: 4118 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F70", Offset = "0x3391F70", VA = "0x3391F70")]
	[Token(Token = "0x6001016")]
	private void method_15()
	{
	}

	// Token: 0x06001017 RID: 4119 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001017")]
	[Address(RVA = "0x3391F74", Offset = "0x3391F74", VA = "0x3391F74")]
	private void method_16()
	{
	}

	// Token: 0x06001018 RID: 4120 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001018")]
	[Address(RVA = "0x3391F78", Offset = "0x3391F78", VA = "0x3391F78")]
	private void method_17()
	{
	}

	// Token: 0x06001019 RID: 4121 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3391F7C", Offset = "0x3391F7C", VA = "0x3391F7C")]
	[Token(Token = "0x6001019")]
	public InputFocus()
	{
	}

	// Token: 0x0600101A RID: 4122 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600101A")]
	[Address(RVA = "0x3391F84", Offset = "0x3391F84", VA = "0x3391F84")]
	private void method_18()
	{
	}

	// Token: 0x0600101B RID: 4123 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F88", Offset = "0x3391F88", VA = "0x3391F88")]
	[Token(Token = "0x600101B")]
	private void method_19()
	{
	}

	// Token: 0x0600101C RID: 4124 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600101C")]
	[Address(RVA = "0x3391F8C", Offset = "0x3391F8C", VA = "0x3391F8C")]
	private void method_20()
	{
	}

	// Token: 0x0600101D RID: 4125 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600101D")]
	[Address(RVA = "0x3391F90", Offset = "0x3391F90", VA = "0x3391F90")]
	private void method_21()
	{
	}

	// Token: 0x0600101E RID: 4126 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600101E")]
	[Address(RVA = "0x3391F94", Offset = "0x3391F94", VA = "0x3391F94")]
	private void method_22()
	{
	}

	// Token: 0x0600101F RID: 4127 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F98", Offset = "0x3391F98", VA = "0x3391F98")]
	[Token(Token = "0x600101F")]
	private void method_23()
	{
	}

	// Token: 0x06001020 RID: 4128 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391F9C", Offset = "0x3391F9C", VA = "0x3391F9C")]
	[Token(Token = "0x6001020")]
	private void method_24()
	{
	}

	// Token: 0x06001021 RID: 4129 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FA0", Offset = "0x3391FA0", VA = "0x3391FA0")]
	[Token(Token = "0x6001021")]
	private void method_25()
	{
	}

	// Token: 0x06001022 RID: 4130 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001022")]
	[Address(RVA = "0x3391FA4", Offset = "0x3391FA4", VA = "0x3391FA4")]
	private void method_26()
	{
	}

	// Token: 0x06001023 RID: 4131 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FA8", Offset = "0x3391FA8", VA = "0x3391FA8")]
	[Token(Token = "0x6001023")]
	private void method_27()
	{
	}

	// Token: 0x06001024 RID: 4132 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001024")]
	[Address(RVA = "0x3391FAC", Offset = "0x3391FAC", VA = "0x3391FAC")]
	private void method_28()
	{
	}

	// Token: 0x06001025 RID: 4133 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FB0", Offset = "0x3391FB0", VA = "0x3391FB0")]
	[Token(Token = "0x6001025")]
	private void method_29()
	{
	}

	// Token: 0x06001026 RID: 4134 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001026")]
	[Address(RVA = "0x3391FB4", Offset = "0x3391FB4", VA = "0x3391FB4")]
	private void method_30()
	{
	}

	// Token: 0x06001027 RID: 4135 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FB8", Offset = "0x3391FB8", VA = "0x3391FB8")]
	[Token(Token = "0x6001027")]
	private void Update()
	{
	}

	// Token: 0x06001028 RID: 4136 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001028")]
	[Address(RVA = "0x3391FBC", Offset = "0x3391FBC", VA = "0x3391FBC")]
	private void method_31()
	{
	}

	// Token: 0x06001029 RID: 4137 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001029")]
	[Address(RVA = "0x3391FC0", Offset = "0x3391FC0", VA = "0x3391FC0")]
	private void method_32()
	{
	}

	// Token: 0x0600102A RID: 4138 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FC4", Offset = "0x3391FC4", VA = "0x3391FC4")]
	[Token(Token = "0x600102A")]
	private void method_33()
	{
	}

	// Token: 0x0600102B RID: 4139 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600102B")]
	[Address(RVA = "0x3391FC8", Offset = "0x3391FC8", VA = "0x3391FC8")]
	private void method_34()
	{
	}

	// Token: 0x0600102C RID: 4140 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FCC", Offset = "0x3391FCC", VA = "0x3391FCC")]
	[Token(Token = "0x600102C")]
	private void method_35()
	{
	}

	// Token: 0x0600102D RID: 4141 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FD0", Offset = "0x3391FD0", VA = "0x3391FD0")]
	[Token(Token = "0x600102D")]
	private void method_36()
	{
	}

	// Token: 0x0600102E RID: 4142 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FD4", Offset = "0x3391FD4", VA = "0x3391FD4")]
	[Token(Token = "0x600102E")]
	private void method_37()
	{
	}

	// Token: 0x0600102F RID: 4143 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FD8", Offset = "0x3391FD8", VA = "0x3391FD8")]
	[Token(Token = "0x600102F")]
	private void method_38()
	{
	}

	// Token: 0x06001030 RID: 4144 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FDC", Offset = "0x3391FDC", VA = "0x3391FDC")]
	[Token(Token = "0x6001030")]
	private void method_39()
	{
	}

	// Token: 0x06001031 RID: 4145 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FE0", Offset = "0x3391FE0", VA = "0x3391FE0")]
	[Token(Token = "0x6001031")]
	private void method_40()
	{
	}

	// Token: 0x06001032 RID: 4146 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001032")]
	[Address(RVA = "0x3391FE4", Offset = "0x3391FE4", VA = "0x3391FE4")]
	private void method_41()
	{
	}

	// Token: 0x06001033 RID: 4147 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3391FE8", Offset = "0x3391FE8", VA = "0x3391FE8")]
	[Token(Token = "0x6001033")]
	private void method_42()
	{
	}
}
