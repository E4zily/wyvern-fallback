﻿using System;
using System.Collections;
using CapuchinPlayFab;
using Cpp2IlInjected;
using Locomotion;
using Photon.Pun;
using PlayFab;
using PlayFab.ClientModels;
using UnityEngine;

// Token: 0x020000D4 RID: 212
[Token(Token = "0x20000D4")]
public class LavaManager : MonoBehaviour
{
	// Token: 0x06001F1C RID: 7964 RVA: 0x00002C3D File Offset: 0x00000E3D
	[Address(RVA = "0x35E87C8", Offset = "0x35E87C8", VA = "0x35E87C8")]
	[Token(Token = "0x6001F1C")]
	private void method_0(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("HorrorAgreement");
		this.loginManager_0.method_43();
	}

	// Token: 0x06001F1D RID: 7965 RVA: 0x00039E80 File Offset: 0x00038080
	[Address(RVA = "0x35E5F50", Offset = "0x35E5F50", VA = "0x35E5F50")]
	[Token(Token = "0x6001F1D")]
	public void method_1()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F1E RID: 7966 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35E8854", Offset = "0x35E8854", VA = "0x35E8854")]
	[Token(Token = "0x6001F1E")]
	private void method_2()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F1F RID: 7967 RVA: 0x00039E80 File Offset: 0x00038080
	[Address(RVA = "0x35E592C", Offset = "0x35E592C", VA = "0x35E592C")]
	[Token(Token = "0x6001F1F")]
	public void method_3()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F20 RID: 7968 RVA: 0x00039EC4 File Offset: 0x000380C4
	[Address(RVA = "0x35E89CC", Offset = "0x35E89CC", VA = "0x35E89CC")]
	[Token(Token = "0x6001F20")]
	public void method_4(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_20();
			Transform transform = this.transform_4;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_4;
			Vector3 position2 = transform2.position;
			return;
		}
	}

	// Token: 0x06001F21 RID: 7969 RVA: 0x00039F0C File Offset: 0x0003810C
	[Address(RVA = "0x35E8AB8", Offset = "0x35E8AB8", VA = "0x35E8AB8")]
	[Token(Token = "0x6001F21")]
	public void method_5(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F22 RID: 7970 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35E8BD4", Offset = "0x35E8BD4", VA = "0x35E8BD4")]
	[Token(Token = "0x6001F22")]
	private void method_6()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F23 RID: 7971 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35E8D48", Offset = "0x35E8D48", VA = "0x35E8D48")]
	[Token(Token = "0x6001F23")]
	private void method_7()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F24 RID: 7972 RVA: 0x00002C54 File Offset: 0x00000E54
	[Address(RVA = "0x35E8EC0", Offset = "0x35E8EC0", VA = "0x35E8EC0")]
	[Token(Token = "0x6001F24")]
	private void method_8(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("Downloading image");
		this.loginManager_0.method_62();
	}

	// Token: 0x06001F25 RID: 7973 RVA: 0x00039F24 File Offset: 0x00038124
	[Address(RVA = "0x35E8F4C", Offset = "0x35E8F4C", VA = "0x35E8F4C")]
	[Token(Token = "0x6001F25")]
	private void method_9()
	{
		if (!this.bool_0)
		{
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			bool flag = this.bool_1;
			long num = 1L;
			this.vector3_0.z = (float)24576;
			this.float_0 = (float)16384;
			this.bool_2 = (num != 0L);
			if (flag)
			{
				Transform transform2 = this.transform_4;
				Vector3 position2 = transform2.position;
				Transform transform3 = this.transform_4;
				Vector3 position3 = transform3.position;
				GameObject gameObject = this.gameObject_8;
				long active = 1L;
				gameObject.SetActive(active != 0L);
				GameObject gameObject2 = this.gameObject_9;
				long active2 = 0L;
				gameObject2.SetActive(active2 != 0L);
				GameObject gameObject3 = this.gameObject_12;
				long active3 = 0L;
				gameObject3.SetActive(active3 != 0L);
				if (this.bool_1 && this.bool_3)
				{
					Rigidbody rigidbody = this.rigidbody_0;
					long useGravity = 0L;
					rigidbody.useGravity = (useGravity != 0L);
					Rigidbody rigidbody2 = this.rigidbody_1;
					long useGravity2 = 0L;
					rigidbody2.useGravity = (useGravity2 != 0L);
					Rigidbody rigidbody3 = this.rigidbody_2;
					long useGravity3 = 1L;
					rigidbody3.useGravity = (useGravity3 != 0L);
					this.method_24();
					Swimmy swimmy = this.swimmy_0;
					long enabled = 0L;
					swimmy.enabled = (enabled != 0L);
					this.method_22();
					return;
				}
			}
			GameObject gameObject4 = this.gameObject_2;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_6;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_7;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_8;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_9;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 0L;
			gameObject10.SetActive(active10 != 0L);
			GameObject gameObject11 = this.gameObject_10;
			long active11 = 1L;
			gameObject11.SetActive(active11 != 0L);
			GameObject gameObject12 = this.gameObject_3;
			long active12 = 1L;
			gameObject12.SetActive(active12 != 0L);
			GameObject gameObject13 = this.transform_0.gameObject;
			long active13 = 1L;
			gameObject13.SetActive(active13 != 0L);
			return;
		}
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.transform_0.gameObject;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_2;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_6;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_7;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_11;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		GameObject gameObject21 = this.gameObject_10;
		long active21 = 1L;
		gameObject21.SetActive(active21 != 0L);
		GameObject gameObject22 = this.gameObject_8;
		if (this.bool_1)
		{
			long active22 = 1L;
			gameObject22.SetActive(active22 != 0L);
			return;
		}
		GameObject gameObject23 = this.gameObject_9;
		long active23 = 1L;
		gameObject23.SetActive(active23 != 0L);
		GameObject gameObject24 = this.gameObject_3;
		long active24 = 1L;
		long num2 = 1L;
		gameObject24.SetActive(active24 != 0L);
		bool flag2 = this.bool_2;
		this.bool_3 = (num2 != 0L);
		if (!flag2)
		{
			IEnumerator routine = this.method_49();
			base.StartCoroutine(routine);
		}
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float deltaTime = Time.deltaTime;
		}
		Vector3 position4 = this.transform_0.position;
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
		}
		float deltaTime2 = Time.deltaTime;
	}

	// Token: 0x06001F26 RID: 7974 RVA: 0x0003A254 File Offset: 0x00038454
	[Address(RVA = "0x35E9938", Offset = "0x35E9938", VA = "0x35E9938")]
	[Token(Token = "0x6001F26")]
	private void method_10(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		Application.Quit();
	}

	// Token: 0x06001F27 RID: 7975 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35E9A10", Offset = "0x35E9A10", VA = "0x35E9A10")]
	[Token(Token = "0x6001F27")]
	public IEnumerator method_11()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001F28 RID: 7976 RVA: 0x00002C6B File Offset: 0x00000E6B
	[Address(RVA = "0x35E9A88", Offset = "0x35E9A88", VA = "0x35E9A88")]
	[Token(Token = "0x6001F28")]
	private void method_12(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("Added Winner Money");
		this.loginManager_0.method_43();
	}

	// Token: 0x06001F29 RID: 7977 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35E9B14", Offset = "0x35E9B14", VA = "0x35E9B14")]
	[Token(Token = "0x6001F29")]
	private void method_13()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F2A RID: 7978 RVA: 0x00039E80 File Offset: 0x00038080
	[Address(RVA = "0x35E5D80", Offset = "0x35E5D80", VA = "0x35E5D80")]
	[Token(Token = "0x6001F2A")]
	public void method_14()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F2B RID: 7979 RVA: 0x0003A254 File Offset: 0x00038454
	[Address(RVA = "0x35E9C8C", Offset = "0x35E9C8C", VA = "0x35E9C8C")]
	[Token(Token = "0x6001F2B")]
	private void method_15(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		Application.Quit();
	}

	// Token: 0x06001F2C RID: 7980 RVA: 0x0003A298 File Offset: 0x00038498
	[Address(RVA = "0x35E9D64", Offset = "0x35E9D64", VA = "0x35E9D64")]
	[Token(Token = "0x6001F2C")]
	public void method_16(bool bool_5)
	{
		PhotonView photonView = this.photonView_0;
		photonView.RequestOwnership();
		if (photonView.Group == 0)
		{
			throw new IndexOutOfRangeException();
		}
		photonView.instantiationDataField = typeof(bool).TypeHandle;
	}

	// Token: 0x06001F2D RID: 7981 RVA: 0x0003A2CC File Offset: 0x000384CC
	[Address(RVA = "0x35E9E80", Offset = "0x35E9E80", VA = "0x35E9E80")]
	[Token(Token = "0x6001F2D")]
	public void method_17(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F2E RID: 7982 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35E9F98", Offset = "0x35E9F98", VA = "0x35E9F98")]
	[Token(Token = "0x6001F2E")]
	public IEnumerator method_18()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001F2F RID: 7983 RVA: 0x00002C82 File Offset: 0x00000E82
	[Address(RVA = "0x35EA010", Offset = "0x35EA010", VA = "0x35EA010")]
	[Token(Token = "0x6001F2F")]
	private void method_19(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("hand 2");
		this.loginManager_0.method_62();
	}

	// Token: 0x06001F30 RID: 7984 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x35EA09C", Offset = "0x35EA09C", VA = "0x35EA09C")]
	[Token(Token = "0x6001F30")]
	public LavaManager()
	{
	}

	// Token: 0x06001F31 RID: 7985 RVA: 0x00039EC4 File Offset: 0x000380C4
	[PunRPC]
	[Address(RVA = "0x35EA0A4", Offset = "0x35EA0A4", VA = "0x35EA0A4")]
	[Token(Token = "0x6001F31")]
	public void gamemode(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_20();
			Transform transform = this.transform_4;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_4;
			Vector3 position2 = transform2.position;
			return;
		}
	}

	// Token: 0x06001F32 RID: 7986 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35EA18C", Offset = "0x35EA18C", VA = "0x35EA18C")]
	[Token(Token = "0x6001F32")]
	private void method_20()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F33 RID: 7987 RVA: 0x0003A2E4 File Offset: 0x000384E4
	[Address(RVA = "0x35EA304", Offset = "0x35EA304", VA = "0x35EA304")]
	[Token(Token = "0x6001F33")]
	public void method_21(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_15();
			Transform transform = this.transform_4;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_4;
			Vector3 position2 = transform2.position;
			return;
		}
	}

	// Token: 0x06001F34 RID: 7988 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35E97C0", Offset = "0x35E97C0", VA = "0x35E97C0")]
	[Token(Token = "0x6001F34")]
	private void method_22()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F35 RID: 7989 RVA: 0x0003A254 File Offset: 0x00038454
	[Address(RVA = "0x35EA3F8", Offset = "0x35EA3F8", VA = "0x35EA3F8")]
	[Token(Token = "0x6001F35")]
	private void method_23(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		Application.Quit();
	}

	// Token: 0x06001F36 RID: 7990 RVA: 0x0003A32C File Offset: 0x0003852C
	[Address(RVA = "0x35E95E0", Offset = "0x35E95E0", VA = "0x35E95E0")]
	[Token(Token = "0x6001F36")]
	public void method_24()
	{
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F37 RID: 7991 RVA: 0x00002C6B File Offset: 0x00000E6B
	[Address(RVA = "0x35EA4D0", Offset = "0x35EA4D0", VA = "0x35EA4D0")]
	[Token(Token = "0x6001F37")]
	private void method_25(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("Added Winner Money");
		this.loginManager_0.method_43();
	}

	// Token: 0x06001F38 RID: 7992 RVA: 0x0003A254 File Offset: 0x00038454
	[Address(RVA = "0x35EA55C", Offset = "0x35EA55C", VA = "0x35EA55C")]
	[Token(Token = "0x6001F38")]
	private void method_26(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		Application.Quit();
	}

	// Token: 0x06001F39 RID: 7993 RVA: 0x0003A34C File Offset: 0x0003854C
	[Address(RVA = "0x35EA634", Offset = "0x35EA634", VA = "0x35EA634")]
	[Token(Token = "0x6001F39")]
	public void method_27()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F3A RID: 7994 RVA: 0x0003A36C File Offset: 0x0003856C
	[Address(RVA = "0x35EA814", Offset = "0x35EA814", VA = "0x35EA814")]
	[Token(Token = "0x6001F3A")]
	public void method_28()
	{
		NetworkPlayerSpawner networkPlayerSpawner = this.networkPlayerSpawner_0;
		networkPlayerSpawner.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F3B RID: 7995 RVA: 0x00002C99 File Offset: 0x00000E99
	[Address(RVA = "0x35EA9FC", Offset = "0x35EA9FC", VA = "0x35EA9FC")]
	[Token(Token = "0x6001F3B")]
	private void method_29(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("amongus");
		this.loginManager_0.method_62();
	}

	// Token: 0x06001F3C RID: 7996 RVA: 0x00039E80 File Offset: 0x00038080
	[Address(RVA = "0x35E64D0", Offset = "0x35E64D0", VA = "0x35E64D0")]
	[Token(Token = "0x6001F3C")]
	public void method_30()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F3D RID: 7997 RVA: 0x0003A38C File Offset: 0x0003858C
	[Address(RVA = "0x35EAA88", Offset = "0x35EAA88", VA = "0x35EAA88")]
	[Token(Token = "0x6001F3D")]
	private void method_31()
	{
		if (!this.bool_0)
		{
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			bool flag = this.bool_1;
			this.vector3_0.z = (float)17040;
			this.float_0 = (float)40960;
			if (flag)
			{
				Transform transform2 = this.transform_4;
				Vector3 position2 = transform2.position;
				Transform transform3 = this.transform_4;
				Vector3 position3 = transform3.position;
				GameObject gameObject = this.gameObject_8;
				long active = 0L;
				gameObject.SetActive(active != 0L);
				GameObject gameObject2 = this.gameObject_9;
				long active2 = 1L;
				gameObject2.SetActive(active2 != 0L);
				GameObject gameObject3 = this.gameObject_12;
				long active3 = 1L;
				gameObject3.SetActive(active3 != 0L);
				if (this.bool_1 && this.bool_3)
				{
					Rigidbody rigidbody = this.rigidbody_0;
					long useGravity = 1L;
					rigidbody.useGravity = (useGravity != 0L);
					Rigidbody rigidbody2 = this.rigidbody_1;
					long useGravity2 = 0L;
					rigidbody2.useGravity = (useGravity2 != 0L);
					Rigidbody rigidbody3 = this.rigidbody_2;
					long useGravity3 = 0L;
					rigidbody3.useGravity = (useGravity3 != 0L);
					long num = 1L;
					this.bool_4 = (num != 0L);
					Swimmy swimmy = this.swimmy_0;
					long enabled = 0L;
					swimmy.enabled = (enabled != 0L);
					this.method_54();
					this.bool_3 = (num != 0L);
					return;
				}
			}
			GameObject gameObject4 = this.gameObject_2;
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_6;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			long active6 = 1L;
			gameObject5.SetActive(active6 != 0L);
			GameObject gameObject6 = this.gameObject_8;
			long active7 = 1L;
			gameObject6.SetActive(active7 != 0L);
			GameObject gameObject7 = this.gameObject_9;
			long active8 = 0L;
			gameObject7.SetActive(active8 != 0L);
			GameObject gameObject8 = this.gameObject_0;
			long active9 = 1L;
			gameObject8.SetActive(active9 != 0L);
			GameObject gameObject9 = this.gameObject_1;
			long active10 = 0L;
			gameObject9.SetActive(active10 != 0L);
			GameObject gameObject10 = this.gameObject_10;
			long active11 = 1L;
			gameObject10.SetActive(active11 != 0L);
			GameObject gameObject11 = this.gameObject_3;
			long active12 = 1L;
			gameObject11.SetActive(active12 != 0L);
			GameObject gameObject12 = this.transform_0.gameObject;
			long active13 = 1L;
			gameObject12.SetActive(active13 != 0L);
			return;
		}
		GameObject gameObject13 = this.gameObject_0;
		long active14 = 0L;
		gameObject13.SetActive(active14 != 0L);
		GameObject gameObject14 = this.gameObject_1;
		long active15 = 0L;
		gameObject14.SetActive(active15 != 0L);
		GameObject gameObject15 = this.transform_0.gameObject;
		long active16 = 1L;
		gameObject15.SetActive(active16 != 0L);
		GameObject gameObject16 = this.gameObject_2;
		long active17 = 1L;
		gameObject16.SetActive(active17 != 0L);
		GameObject gameObject17 = this.gameObject_6;
		long active18 = 0L;
		gameObject17.SetActive(active18 != 0L);
		GameObject gameObject18 = this.gameObject_7;
		long active19 = 0L;
		gameObject18.SetActive(active19 != 0L);
		GameObject gameObject19 = this.gameObject_11;
		long active20 = 1L;
		gameObject19.SetActive(active20 != 0L);
		GameObject gameObject20 = this.gameObject_10;
		long active21 = 0L;
		gameObject20.SetActive(active21 != 0L);
		GameObject gameObject21 = this.gameObject_8;
		bool flag2 = this.bool_1;
		long active22 = 0L;
		gameObject21.SetActive(active22 != 0L);
		if (flag2)
		{
			return;
		}
		GameObject gameObject22 = this.gameObject_3;
		long active23 = 1L;
		long num3 = 1L;
		gameObject22.SetActive(active23 != 0L);
		bool flag3 = this.bool_2;
		this.bool_3 = (num3 != 0L);
		if (!flag3)
		{
			IEnumerator routine = this.method_48();
			base.StartCoroutine(routine);
		}
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float deltaTime = Time.deltaTime;
		}
		Vector3 position4 = this.transform_0.position;
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
		}
		float deltaTime2 = Time.deltaTime;
	}

	// Token: 0x06001F3E RID: 7998 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35EB27C", Offset = "0x35EB27C", VA = "0x35EB27C")]
	[Token(Token = "0x6001F3E")]
	public IEnumerator method_32()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001F3F RID: 7999 RVA: 0x00002CB0 File Offset: 0x00000EB0
	[Address(RVA = "0x35EB2F4", Offset = "0x35EB2F4", VA = "0x35EB2F4")]
	[Token(Token = "0x6001F3F")]
	private void method_33(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("Error");
		this.loginManager_0.method_43();
	}

	// Token: 0x06001F40 RID: 8000 RVA: 0x0003A2CC File Offset: 0x000384CC
	[Address(RVA = "0x35EB380", Offset = "0x35EB380", VA = "0x35EB380")]
	[Token(Token = "0x6001F40")]
	public void method_34(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F41 RID: 8001 RVA: 0x0003A6B4 File Offset: 0x000388B4
	[Address(RVA = "0x35EB4A0", Offset = "0x35EB4A0", VA = "0x35EB4A0")]
	[Token(Token = "0x6001F41")]
	public void method_35(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_15();
			Transform transform = this.transform_4;
			Vector3 position = transform.position;
			Vector3 position2 = this.transform_4.position;
			return;
		}
		this.vector3_0.z = (float)49152;
		this.float_0 = (float)16384;
	}

	// Token: 0x06001F42 RID: 8002 RVA: 0x00039F0C File Offset: 0x0003810C
	[Address(RVA = "0x35EB594", Offset = "0x35EB594", VA = "0x35EB594")]
	[Token(Token = "0x6001F42")]
	public void method_36(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F43 RID: 8003 RVA: 0x0003A714 File Offset: 0x00038914
	[Address(RVA = "0x35EB6B0", Offset = "0x35EB6B0", VA = "0x35EB6B0")]
	[Token(Token = "0x6001F43")]
	private void method_37()
	{
		if (!this.bool_0)
		{
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			bool flag = this.bool_1;
			this.vector3_0.z = (float)40960;
			this.float_0 = (float)49152;
			if (flag)
			{
				Transform transform2 = this.transform_4;
				Vector3 position2 = transform2.position;
				Transform transform3 = this.transform_4;
				Vector3 position3 = transform3.position;
				GameObject gameObject = this.gameObject_8;
				long active = 1L;
				gameObject.SetActive(active != 0L);
				GameObject gameObject2 = this.gameObject_9;
				long active2 = 0L;
				gameObject2.SetActive(active2 != 0L);
				GameObject gameObject3 = this.gameObject_12;
				long active3 = 1L;
				gameObject3.SetActive(active3 != 0L);
				if (this.bool_1 && this.bool_3)
				{
					Rigidbody rigidbody = this.rigidbody_0;
					long useGravity = 1L;
					rigidbody.useGravity = (useGravity != 0L);
					Rigidbody rigidbody2 = this.rigidbody_1;
					long useGravity2 = 0L;
					rigidbody2.useGravity = (useGravity2 != 0L);
					Rigidbody rigidbody3 = this.rigidbody_2;
					long useGravity3 = 0L;
					rigidbody3.useGravity = (useGravity3 != 0L);
					this.method_24();
					Swimmy swimmy = this.swimmy_0;
					long enabled = 1L;
					long num = 1L;
					swimmy.enabled = (enabled != 0L);
					this.method_2();
					this.bool_3 = (num != 0L);
					return;
				}
			}
			GameObject gameObject4 = this.gameObject_2;
			long num2 = 1L;
			this.bool_1 = (num2 != 0L);
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_6;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_7;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_8;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_9;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 0L;
			gameObject10.SetActive(active10 != 0L);
			GameObject gameObject11 = this.gameObject_10;
			long active11 = 1L;
			gameObject11.SetActive(active11 != 0L);
			GameObject gameObject12 = this.gameObject_3;
			long active12 = 0L;
			gameObject12.SetActive(active12 != 0L);
			GameObject gameObject13 = this.transform_0.gameObject;
			long active13 = 0L;
			gameObject13.SetActive(active13 != 0L);
			return;
		}
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 0L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.transform_0.gameObject;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_2;
		long active17 = 0L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_6;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_7;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_11;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		GameObject gameObject21 = this.gameObject_10;
		long active21 = 0L;
		gameObject21.SetActive(active21 != 0L);
		GameObject gameObject22 = this.gameObject_8;
		bool flag2 = this.bool_1;
		long active22 = 0L;
		gameObject22.SetActive(active22 != 0L);
		if (flag2)
		{
			return;
		}
		GameObject gameObject23 = this.gameObject_3;
		long active23 = 1L;
		long num3 = 1L;
		gameObject23.SetActive(active23 != 0L);
		bool flag3 = this.bool_2;
		this.bool_3 = (num3 != 0L);
		if (!flag3)
		{
			IEnumerator routine = this.method_49();
			base.StartCoroutine(routine);
		}
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float deltaTime = Time.deltaTime;
		}
		Vector3 position4 = this.transform_0.position;
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
		}
		float deltaTime2 = Time.deltaTime;
	}

	// Token: 0x06001F44 RID: 8004 RVA: 0x00002CC7 File Offset: 0x00000EC7
	[Address(RVA = "0x35EBCA4", Offset = "0x35EBCA4", VA = "0x35EBCA4")]
	[Token(Token = "0x6001F44")]
	private void method_38(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("hand 2");
		this.loginManager_0.method_43();
	}

	// Token: 0x06001F45 RID: 8005 RVA: 0x00039F0C File Offset: 0x0003810C
	[Address(RVA = "0x35EBD30", Offset = "0x35EBD30", VA = "0x35EBD30")]
	[Token(Token = "0x6001F45")]
	public void method_39(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F46 RID: 8006 RVA: 0x0003AA40 File Offset: 0x00038C40
	[Address(RVA = "0x35EBE4C", Offset = "0x35EBE4C", VA = "0x35EBE4C")]
	[Token(Token = "0x6001F46")]
	private void method_40()
	{
		if (!this.bool_0)
		{
			Transform transform = this.transform_1;
			Vector3 position = transform.position;
			bool flag = this.bool_1;
			this.vector3_0.z = (float)8192;
			this.float_0 = (float)17526;
			if (flag)
			{
				Transform transform2 = this.transform_4;
				Vector3 position2 = transform2.position;
				Transform transform3 = this.transform_4;
				Vector3 position3 = transform3.position;
				GameObject gameObject = this.gameObject_8;
				long active = 1L;
				gameObject.SetActive(active != 0L);
				GameObject gameObject2 = this.gameObject_9;
				long active2 = 0L;
				gameObject2.SetActive(active2 != 0L);
				GameObject gameObject3 = this.gameObject_12;
				long active3 = 1L;
				gameObject3.SetActive(active3 != 0L);
				if (this.bool_3)
				{
					Rigidbody rigidbody = this.rigidbody_0;
					long useGravity = 0L;
					rigidbody.useGravity = (useGravity != 0L);
					Rigidbody rigidbody2 = this.rigidbody_1;
					long useGravity2 = 1L;
					rigidbody2.useGravity = (useGravity2 != 0L);
					Rigidbody rigidbody3 = this.rigidbody_2;
					long useGravity3 = 0L;
					rigidbody3.useGravity = (useGravity3 != 0L);
					this.method_27();
					Swimmy swimmy = this.swimmy_0;
					long enabled = 0L;
					swimmy.enabled = (enabled != 0L);
					this.method_53();
					return;
				}
			}
			GameObject gameObject4 = this.gameObject_2;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_6;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_7;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_8;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_9;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_0;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			GameObject gameObject10 = this.gameObject_1;
			long active10 = 0L;
			gameObject10.SetActive(active10 != 0L);
			GameObject gameObject11 = this.gameObject_10;
			long active11 = 1L;
			gameObject11.SetActive(active11 != 0L);
			GameObject gameObject12 = this.gameObject_3;
			long active12 = 0L;
			gameObject12.SetActive(active12 != 0L);
			GameObject gameObject13 = this.transform_0.gameObject;
			long active13 = 0L;
			gameObject13.SetActive(active13 != 0L);
			return;
		}
		GameObject gameObject14 = this.gameObject_0;
		long active14 = 1L;
		gameObject14.SetActive(active14 != 0L);
		GameObject gameObject15 = this.gameObject_1;
		long active15 = 0L;
		gameObject15.SetActive(active15 != 0L);
		GameObject gameObject16 = this.transform_0.gameObject;
		long active16 = 1L;
		gameObject16.SetActive(active16 != 0L);
		GameObject gameObject17 = this.gameObject_2;
		long active17 = 1L;
		gameObject17.SetActive(active17 != 0L);
		GameObject gameObject18 = this.gameObject_6;
		long active18 = 1L;
		gameObject18.SetActive(active18 != 0L);
		GameObject gameObject19 = this.gameObject_7;
		long active19 = 1L;
		gameObject19.SetActive(active19 != 0L);
		GameObject gameObject20 = this.gameObject_11;
		long active20 = 1L;
		gameObject20.SetActive(active20 != 0L);
		GameObject gameObject21 = this.gameObject_10;
		long active21 = 0L;
		gameObject21.SetActive(active21 != 0L);
		GameObject gameObject22 = this.gameObject_8;
		bool flag2 = this.bool_1;
		long active22 = 1L;
		gameObject22.SetActive(active22 != 0L);
		if (flag2)
		{
			return;
		}
		GameObject gameObject23 = this.gameObject_3;
		long active23 = 0L;
		gameObject23.SetActive(active23 != 0L);
		bool flag3 = this.bool_2;
		long num = 1L;
		this.bool_3 = (num != 0L);
		if (!flag3)
		{
			IEnumerator routine = this.method_48();
			base.StartCoroutine(routine);
			this.bool_2 = (num != 0L);
		}
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float deltaTime = Time.deltaTime;
		}
		Vector3 position4 = this.transform_0.position;
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
		}
		float deltaTime2 = Time.deltaTime;
	}

	// Token: 0x06001F47 RID: 8007 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35EC5D4", Offset = "0x35EC5D4", VA = "0x35EC5D4")]
	[Token(Token = "0x6001F47")]
	public IEnumerator method_41()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001F48 RID: 8008 RVA: 0x00002C99 File Offset: 0x00000E99
	[Address(RVA = "0x35EC64C", Offset = "0x35EC64C", VA = "0x35EC64C")]
	[Token(Token = "0x6001F48")]
	private void method_42(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("amongus");
		this.loginManager_0.method_62();
	}

	// Token: 0x06001F49 RID: 8009 RVA: 0x00002CDE File Offset: 0x00000EDE
	[Address(RVA = "0x35EC6D8", Offset = "0x35EC6D8", VA = "0x35EC6D8")]
	[Token(Token = "0x6001F49")]
	private void method_43(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("ErrorScreen");
		this.loginManager_0.method_43();
	}

	// Token: 0x06001F4A RID: 8010 RVA: 0x0003A254 File Offset: 0x00038454
	[Address(RVA = "0x35EC764", Offset = "0x35EC764", VA = "0x35EC764")]
	[Token(Token = "0x6001F4A")]
	private void method_44(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		Application.Quit();
	}

	// Token: 0x06001F4B RID: 8011 RVA: 0x0003A2E4 File Offset: 0x000384E4
	[Address(RVA = "0x35EC83C", Offset = "0x35EC83C", VA = "0x35EC83C")]
	[Token(Token = "0x6001F4B")]
	public void method_45(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_15();
			Transform transform = this.transform_4;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_4;
			Vector3 position2 = transform2.position;
			return;
		}
	}

	// Token: 0x06001F4C RID: 8012 RVA: 0x00002CF5 File Offset: 0x00000EF5
	[Address(RVA = "0x35EC92C", Offset = "0x35EC92C", VA = "0x35EC92C")]
	[Token(Token = "0x6001F4C")]
	private void method_46(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("FingerTip");
		this.loginManager_0.method_62();
	}

	// Token: 0x06001F4D RID: 8013 RVA: 0x0003A254 File Offset: 0x00038454
	[Address(RVA = "0x35EC9B8", Offset = "0x35EC9B8", VA = "0x35EC9B8")]
	[Token(Token = "0x6001F4D")]
	private void method_47(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		Application.Quit();
	}

	// Token: 0x06001F4E RID: 8014 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35EB08C", Offset = "0x35EB08C", VA = "0x35EB08C")]
	[Token(Token = "0x6001F4E")]
	public IEnumerator method_48()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001F4F RID: 8015 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x35E9568", Offset = "0x35E9568", VA = "0x35E9568")]
	[Token(Token = "0x6001F4F")]
	public IEnumerator method_49()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06001F50 RID: 8016 RVA: 0x0003AD58 File Offset: 0x00038F58
	[Address(RVA = "0x35E54D0", Offset = "0x35E54D0", VA = "0x35E54D0")]
	[Token(Token = "0x6001F50")]
	public void method_50()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F51 RID: 8017 RVA: 0x0003A2E4 File Offset: 0x000384E4
	[Address(RVA = "0x35ECA90", Offset = "0x35ECA90", VA = "0x35ECA90")]
	[Token(Token = "0x6001F51")]
	public void method_51(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_15();
			Transform transform = this.transform_4;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_4;
			Vector3 position2 = transform2.position;
			return;
		}
	}

	// Token: 0x06001F52 RID: 8018 RVA: 0x0003A254 File Offset: 0x00038454
	[Address(RVA = "0x35ECB80", Offset = "0x35ECB80", VA = "0x35ECB80")]
	[Token(Token = "0x6001F52")]
	private void method_52(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.LogError(message);
		Application.Quit();
	}

	// Token: 0x06001F53 RID: 8019 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35EC45C", Offset = "0x35EC45C", VA = "0x35EC45C")]
	[Token(Token = "0x6001F53")]
	private void method_53()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F54 RID: 8020 RVA: 0x00039EA0 File Offset: 0x000380A0
	[Address(RVA = "0x35EB104", Offset = "0x35EB104", VA = "0x35EB104")]
	[Token(Token = "0x6001F54")]
	private void method_54()
	{
		AddUserVirtualCurrencyRequest addUserVirtualCurrencyRequest = new AddUserVirtualCurrencyRequest();
		string virtualCurrency = this.string_0;
		addUserVirtualCurrencyRequest.VirtualCurrency = virtualCurrency;
	}

	// Token: 0x06001F55 RID: 8021 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35ECC58", Offset = "0x35ECC58", VA = "0x35ECC58")]
	[Token(Token = "0x6001F55")]
	public IEnumerator method_55()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001F56 RID: 8022 RVA: 0x0003AD78 File Offset: 0x00038F78
	[Address(RVA = "0x35ECCD0", Offset = "0x35ECCD0", VA = "0x35ECCD0")]
	[Token(Token = "0x6001F56")]
	private void Update()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.transform_0.gameObject;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
		GameObject gameObject4 = this.gameObject_2;
		long active4 = 0L;
		gameObject4.SetActive(active4 != 0L);
		GameObject gameObject5 = this.gameObject_6;
		long active5 = 0L;
		gameObject5.SetActive(active5 != 0L);
		GameObject gameObject6 = this.gameObject_7;
		long active6 = 0L;
		gameObject6.SetActive(active6 != 0L);
		GameObject gameObject7 = this.gameObject_11;
		long active7 = 1L;
		gameObject7.SetActive(active7 != 0L);
		GameObject gameObject8 = this.gameObject_10;
		long active8 = 0L;
		gameObject8.SetActive(active8 != 0L);
		GameObject gameObject9 = this.gameObject_8;
		if (this.bool_1)
		{
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
		GameObject gameObject10 = this.gameObject_9;
		long active10 = 1L;
		gameObject10.SetActive(active10 != 0L);
		GameObject gameObject11 = this.gameObject_3;
		long active11 = 1L;
		long num = 1L;
		gameObject11.SetActive(active11 != 0L);
		bool flag = this.bool_2;
		this.bool_3 = (num != 0L);
		if (!flag)
		{
			IEnumerator routine = this.method_32();
			base.StartCoroutine(routine);
			this.bool_2 = (num != 0L);
		}
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float deltaTime = Time.deltaTime;
		}
		Vector3 position = this.transform_0.position;
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
		}
		float deltaTime2 = Time.deltaTime;
	}

	// Token: 0x06001F57 RID: 8023 RVA: 0x0003AECC File Offset: 0x000390CC
	[Address(RVA = "0x35E5074", Offset = "0x35E5074", VA = "0x35E5074")]
	[Token(Token = "0x6001F57")]
	public void method_56()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F58 RID: 8024 RVA: 0x00002D0C File Offset: 0x00000F0C
	[Address(RVA = "0x35ED2DC", Offset = "0x35ED2DC", VA = "0x35ED2DC")]
	[Token(Token = "0x6001F58")]
	private void method_57(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		Debug.Log("ENABLE");
		this.loginManager_0.method_49();
	}

	// Token: 0x06001F59 RID: 8025 RVA: 0x0003A2CC File Offset: 0x000384CC
	[Address(RVA = "0x35ED368", Offset = "0x35ED368", VA = "0x35ED368")]
	[Token(Token = "0x6001F59")]
	public void method_58(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F5A RID: 8026 RVA: 0x0003AD58 File Offset: 0x00038F58
	[Address(RVA = "0x35E4E94", Offset = "0x35E4E94", VA = "0x35E4E94")]
	[Token(Token = "0x6001F5A")]
	public void method_59()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F5B RID: 8027 RVA: 0x0003A2CC File Offset: 0x000384CC
	[Address(RVA = "0x35ED480", Offset = "0x35ED480", VA = "0x35ED480")]
	[Token(Token = "0x6001F5B")]
	public void method_60(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F5C RID: 8028 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35ED59C", Offset = "0x35ED59C", VA = "0x35ED59C")]
	[Token(Token = "0x6001F5C")]
	public IEnumerator method_61()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001F5D RID: 8029 RVA: 0x00039EC4 File Offset: 0x000380C4
	[Address(RVA = "0x35ED614", Offset = "0x35ED614", VA = "0x35ED614")]
	[Token(Token = "0x6001F5D")]
	public void method_62(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_20();
			Transform transform = this.transform_4;
			Vector3 position = transform.position;
			Transform transform2 = this.transform_4;
			Vector3 position2 = transform2.position;
			return;
		}
	}

	// Token: 0x06001F5E RID: 8030 RVA: 0x0003A2CC File Offset: 0x000384CC
	[Address(RVA = "0x35ED704", Offset = "0x35ED704", VA = "0x35ED704")]
	[Token(Token = "0x6001F5E")]
	public void method_63(bool bool_5)
	{
		this.photonView_0.RequestOwnership();
	}

	// Token: 0x06001F5F RID: 8031 RVA: 0x0003AEEC File Offset: 0x000390EC
	[Address(RVA = "0x35ED824", Offset = "0x35ED824", VA = "0x35ED824")]
	[Token(Token = "0x6001F5F")]
	public void method_64(bool bool_5)
	{
		bool flag;
		if (flag = this.bool_4)
		{
			this.bool_0 = flag;
			Player.player_0.method_15();
			Transform transform = this.transform_4;
			Transform transform2 = this.transform_2;
			Vector3 position = transform.position;
			Vector3 position2 = transform2.position;
			return;
		}
	}

	// Token: 0x06001F60 RID: 8032 RVA: 0x0003AF34 File Offset: 0x00039134
	[Address(RVA = "0x35ED918", Offset = "0x35ED918", VA = "0x35ED918")]
	[Token(Token = "0x6001F60")]
	public void method_65()
	{
		this.networkPlayerSpawner_0.gameObject_0.GetComponent<PhotonView>();
	}

	// Token: 0x06001F61 RID: 8033 RVA: 0x0003A270 File Offset: 0x00038470
	[Address(RVA = "0x35EDAE4", Offset = "0x35EDAE4", VA = "0x35EDAE4")]
	[Token(Token = "0x6001F61")]
	public IEnumerator method_66()
	{
		LavaManager.Class32 @class = new LavaManager.Class32((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x04000418 RID: 1048
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000418")]
	public PhotonView photonView_0;

	// Token: 0x04000419 RID: 1049
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000419")]
	public Transform transform_0;

	// Token: 0x0400041A RID: 1050
	[Token(Token = "0x400041A")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_1;

	// Token: 0x0400041B RID: 1051
	[Token(Token = "0x400041B")]
	[FieldOffset(Offset = "0x30")]
	public Vector3 vector3_0;

	// Token: 0x0400041C RID: 1052
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400041C")]
	public GameObject gameObject_0;

	// Token: 0x0400041D RID: 1053
	[Token(Token = "0x400041D")]
	[FieldOffset(Offset = "0x48")]
	public GameObject gameObject_1;

	// Token: 0x0400041E RID: 1054
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400041E")]
	public GameObject gameObject_2;

	// Token: 0x0400041F RID: 1055
	[Token(Token = "0x400041F")]
	[FieldOffset(Offset = "0x58")]
	public GameObject gameObject_3;

	// Token: 0x04000420 RID: 1056
	[Token(Token = "0x4000420")]
	[FieldOffset(Offset = "0x60")]
	public Transform transform_2;

	// Token: 0x04000421 RID: 1057
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000421")]
	public Transform transform_3;

	// Token: 0x04000422 RID: 1058
	[Token(Token = "0x4000422")]
	[FieldOffset(Offset = "0x70")]
	public Transform transform_4;

	// Token: 0x04000423 RID: 1059
	[Token(Token = "0x4000423")]
	[FieldOffset(Offset = "0x78")]
	public AudioLowPassFilter[] audioLowPassFilter_0;

	// Token: 0x04000424 RID: 1060
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000424")]
	public AudioSource[] audioSource_0;

	// Token: 0x04000425 RID: 1061
	[Token(Token = "0x4000425")]
	[FieldOffset(Offset = "0x88")]
	public GameObject gameObject_4;

	// Token: 0x04000426 RID: 1062
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x4000426")]
	public GameObject gameObject_5;

	// Token: 0x04000427 RID: 1063
	[Token(Token = "0x4000427")]
	[FieldOffset(Offset = "0x98")]
	public GameObject gameObject_6;

	// Token: 0x04000428 RID: 1064
	[Token(Token = "0x4000428")]
	[FieldOffset(Offset = "0xA0")]
	public GameObject gameObject_7;

	// Token: 0x04000429 RID: 1065
	[Token(Token = "0x4000429")]
	[FieldOffset(Offset = "0xA8")]
	public bool bool_0;

	// Token: 0x0400042A RID: 1066
	[Token(Token = "0x400042A")]
	[FieldOffset(Offset = "0xA9")]
	public bool bool_1;

	// Token: 0x0400042B RID: 1067
	[Token(Token = "0x400042B")]
	[FieldOffset(Offset = "0xAA")]
	private bool bool_2;

	// Token: 0x0400042C RID: 1068
	[FieldOffset(Offset = "0xAB")]
	[Token(Token = "0x400042C")]
	private bool bool_3;

	// Token: 0x0400042D RID: 1069
	[FieldOffset(Offset = "0xB0")]
	[Token(Token = "0x400042D")]
	public LoginManager loginManager_0;

	// Token: 0x0400042E RID: 1070
	[Token(Token = "0x400042E")]
	[FieldOffset(Offset = "0xB8")]
	public GameObject gameObject_8;

	// Token: 0x0400042F RID: 1071
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x400042F")]
	public GameObject gameObject_9;

	// Token: 0x04000430 RID: 1072
	[FieldOffset(Offset = "0xC8")]
	[Token(Token = "0x4000430")]
	public GameObject gameObject_10;

	// Token: 0x04000431 RID: 1073
	[Token(Token = "0x4000431")]
	[FieldOffset(Offset = "0xD0")]
	public AudioSource audioSource_1;

	// Token: 0x04000432 RID: 1074
	[FieldOffset(Offset = "0xD8")]
	[Token(Token = "0x4000432")]
	public Rigidbody rigidbody_0;

	// Token: 0x04000433 RID: 1075
	[FieldOffset(Offset = "0xE0")]
	[Token(Token = "0x4000433")]
	public Rigidbody rigidbody_1;

	// Token: 0x04000434 RID: 1076
	[FieldOffset(Offset = "0xE8")]
	[Token(Token = "0x4000434")]
	public Rigidbody rigidbody_2;

	// Token: 0x04000435 RID: 1077
	[FieldOffset(Offset = "0xF0")]
	[Token(Token = "0x4000435")]
	public Swimmy swimmy_0;

	// Token: 0x04000436 RID: 1078
	[FieldOffset(Offset = "0xF8")]
	[Token(Token = "0x4000436")]
	public float float_0;

	// Token: 0x04000437 RID: 1079
	[FieldOffset(Offset = "0xFC")]
	[Token(Token = "0x4000437")]
	public bool bool_4;

	// Token: 0x04000438 RID: 1080
	[Token(Token = "0x4000438")]
	[FieldOffset(Offset = "0x100")]
	public GameObject gameObject_11;

	// Token: 0x04000439 RID: 1081
	[Token(Token = "0x4000439")]
	[FieldOffset(Offset = "0x108")]
	public NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x0400043A RID: 1082
	[FieldOffset(Offset = "0x110")]
	[Token(Token = "0x400043A")]
	public GameObject gameObject_12;

	// Token: 0x0400043B RID: 1083
	[Token(Token = "0x400043B")]
	[FieldOffset(Offset = "0x118")]
	public string string_0;
}
