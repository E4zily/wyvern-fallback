﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000A6 RID: 166
[Token(Token = "0x20000A6")]
public class BananaManStare : MonoBehaviour
{
	// Token: 0x060017F3 RID: 6131 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFE9B4", Offset = "0x2BFE9B4", VA = "0x2BFE9B4")]
	[Token(Token = "0x60017F3")]
	private IEnumerator method_0()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017F4 RID: 6132 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFEA2C", Offset = "0x2BFEA2C", VA = "0x2BFEA2C")]
	[Token(Token = "0x60017F4")]
	private IEnumerator method_1()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017F5 RID: 6133 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFEAA4", Offset = "0x2BFEAA4", VA = "0x2BFEAA4")]
	[Token(Token = "0x60017F5")]
	private IEnumerator method_2()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017F6 RID: 6134 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Token(Token = "0x60017F6")]
	[Address(RVA = "0x2BFEB1C", Offset = "0x2BFEB1C", VA = "0x2BFEB1C")]
	private IEnumerator method_3()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017F7 RID: 6135 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFEB94", Offset = "0x2BFEB94", VA = "0x2BFEB94")]
	[Token(Token = "0x60017F7")]
	private IEnumerator method_4()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017F8 RID: 6136 RVA: 0x00030CD4 File Offset: 0x0002EED4
	[Address(RVA = "0x2BFEC0C", Offset = "0x2BFEC0C", VA = "0x2BFEC0C")]
	[Token(Token = "0x60017F8")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "hh:mmtt";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("Player", value != 0L);
		IEnumerator routine = this.method_42();
		base.StartCoroutine(routine);
	}

	// Token: 0x060017F9 RID: 6137 RVA: 0x00030D30 File Offset: 0x0002EF30
	[Address(RVA = "0x2BFED68", Offset = "0x2BFED68", VA = "0x2BFED68")]
	[Token(Token = "0x60017F9")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("username", value != 0L);
	}

	// Token: 0x060017FA RID: 6138 RVA: 0x00030D6C File Offset: 0x0002EF6C
	[Address(RVA = "0x2BFEE4C", Offset = "0x2BFEE4C", VA = "0x2BFEE4C")]
	[Token(Token = "0x60017FA")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "Queue";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("ENABLE", value != 0L);
	}

	// Token: 0x060017FB RID: 6139 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFEF30", Offset = "0x2BFEF30", VA = "0x2BFEF30")]
	[Token(Token = "0x60017FB")]
	private IEnumerator method_8()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017FC RID: 6140 RVA: 0x00030DB8 File Offset: 0x0002EFB8
	[Address(RVA = "0x2BFEFA8", Offset = "0x2BFEFA8", VA = "0x2BFEFA8")]
	[Token(Token = "0x60017FC")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "closeToObject";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("Stopped Colliding", value != 0L);
		IEnumerator routine = this.method_0();
		base.StartCoroutine(routine);
	}

	// Token: 0x060017FD RID: 6141 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFF08C", Offset = "0x2BFF08C", VA = "0x2BFF08C")]
	[Token(Token = "0x60017FD")]
	private IEnumerator method_10()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060017FE RID: 6142 RVA: 0x00030E14 File Offset: 0x0002F014
	[Address(RVA = "0x2BFF104", Offset = "0x2BFF104", VA = "0x2BFF104")]
	[Token(Token = "0x60017FE")]
	public void method_11(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n";
		GameObject gameObject2 = this.gameObject_0;
		long active = 0L;
		gameObject2.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("\tExpires: ", value != 0L);
	}

	// Token: 0x060017FF RID: 6143 RVA: 0x00030E5C File Offset: 0x0002F05C
	[Token(Token = "0x60017FF")]
	[Address(RVA = "0x2BFF1E8", Offset = "0x2BFF1E8", VA = "0x2BFF1E8")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("/", value != 0L);
		this.method_1();
	}

	// Token: 0x06001800 RID: 6144 RVA: 0x00030EB0 File Offset: 0x0002F0B0
	[Address(RVA = "0x2BFF2CC", Offset = "0x2BFF2CC", VA = "0x2BFF2CC")]
	[Token(Token = "0x6001800")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "Combine textures & build combined mesh all at once";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("casual", value != 0L);
		IEnumerator routine = this.method_21();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001801 RID: 6145 RVA: 0x00030F0C File Offset: 0x0002F10C
	[Token(Token = "0x6001801")]
	[Address(RVA = "0x2BFF428", Offset = "0x2BFF428", VA = "0x2BFF428")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == "Open";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("FingerTip", value != 0L);
	}

	// Token: 0x06001802 RID: 6146 RVA: 0x00030F58 File Offset: 0x0002F158
	[Address(RVA = "0x2BFF50C", Offset = "0x2BFF50C", VA = "0x2BFF50C")]
	[Token(Token = "0x6001802")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "Tagged";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("Player", value != 0L);
	}

	// Token: 0x06001803 RID: 6147 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFF5F0", Offset = "0x2BFF5F0", VA = "0x2BFF5F0")]
	[Token(Token = "0x6001803")]
	private IEnumerator method_16()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001804 RID: 6148 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFF668", Offset = "0x2BFF668", VA = "0x2BFF668")]
	[Token(Token = "0x6001804")]
	private IEnumerator method_17()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001805 RID: 6149 RVA: 0x00030FA4 File Offset: 0x0002F1A4
	[Token(Token = "0x6001805")]
	[Address(RVA = "0x2BFF6E0", Offset = "0x2BFF6E0", VA = "0x2BFF6E0")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "Add/Remove Hat";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n", value != 0L);
		IEnumerator routine = this.method_28();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001806 RID: 6150 RVA: 0x00031000 File Offset: 0x0002F200
	[Address(RVA = "0x2BFF83C", Offset = "0x2BFF83C", VA = "0x2BFF83C")]
	[Token(Token = "0x6001806")]
	public void method_19(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "Regular";
		GameObject gameObject2 = this.gameObject_0;
		long active = 0L;
		gameObject2.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("Calling success callback. baking meshes", value != 0L);
	}

	// Token: 0x06001807 RID: 6151 RVA: 0x00031048 File Offset: 0x0002F248
	[Token(Token = "0x6001807")]
	[Address(RVA = "0x2BFF920", Offset = "0x2BFF920", VA = "0x2BFF920")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "ENABLE";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("true", value != 0L);
		IEnumerator routine = this.method_0();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001808 RID: 6152 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Token(Token = "0x6001808")]
	[Address(RVA = "0x2BFF3B0", Offset = "0x2BFF3B0", VA = "0x2BFF3B0")]
	private IEnumerator method_21()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001809 RID: 6153 RVA: 0x000310A4 File Offset: 0x0002F2A4
	[Token(Token = "0x6001809")]
	[Address(RVA = "0x2BFFA04", Offset = "0x2BFFA04", VA = "0x2BFFA04")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerDeath";
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("Player", value != 0L);
		IEnumerator routine = this.method_0();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600180A RID: 6154 RVA: 0x000310F0 File Offset: 0x0002F2F0
	[Address(RVA = "0x2BFFAE8", Offset = "0x2BFFAE8", VA = "0x2BFFAE8")]
	[Token(Token = "0x600180A")]
	public void method_23(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "TurnAmount";
		GameObject gameObject2 = this.gameObject_0;
		long active = 0L;
		gameObject2.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("INSIGNIFICANT CURRENCY", value != 0L);
		IEnumerator routine = this.method_3();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600180B RID: 6155 RVA: 0x00031148 File Offset: 0x0002F348
	[Token(Token = "0x600180B")]
	[Address(RVA = "0x2BFFBCC", Offset = "0x2BFFBCC", VA = "0x2BFFBCC")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "containsStaff";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("tutorialCheck", value != 0L);
	}

	// Token: 0x0600180C RID: 6156 RVA: 0x00031194 File Offset: 0x0002F394
	[Address(RVA = "0x2BFFCB0", Offset = "0x2BFFCB0", VA = "0x2BFFCB0")]
	[Token(Token = "0x600180C")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("PlayWave", value != 0L);
	}

	// Token: 0x0600180D RID: 6157 RVA: 0x000311E0 File Offset: 0x0002F3E0
	[Token(Token = "0x600180D")]
	[Address(RVA = "0x2BFFD94", Offset = "0x2BFFD94", VA = "0x2BFFD94")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "Agreed";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("Player", value != 0L);
		IEnumerator routine = this.method_17();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600180E RID: 6158 RVA: 0x0003123C File Offset: 0x0002F43C
	[Token(Token = "0x600180E")]
	[Address(RVA = "0x2BFFE78", Offset = "0x2BFFE78", VA = "0x2BFFE78")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "This is the 2500 Bananas button, and it was just clicked";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("EnableCosmetic", value != 0L);
	}

	// Token: 0x0600180F RID: 6159 RVA: 0x00031288 File Offset: 0x0002F488
	[Token(Token = "0x600180F")]
	[Address(RVA = "0x2BFFF5C", Offset = "0x2BFFF5C", VA = "0x2BFFF5C")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "Purchased: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("Player", value != 0L);
	}

	// Token: 0x06001810 RID: 6160 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFF7C4", Offset = "0x2BFF7C4", VA = "0x2BFF7C4")]
	[Token(Token = "0x6001810")]
	private IEnumerator method_28()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001811 RID: 6161 RVA: 0x000312D4 File Offset: 0x0002F4D4
	[Token(Token = "0x6001811")]
	[Address(RVA = "0x2C00040", Offset = "0x2C00040", VA = "0x2C00040")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == "NoseAttachPoint";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("NoseAttachPoint", value != 0L);
	}

	// Token: 0x06001812 RID: 6162 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Token(Token = "0x6001812")]
	[Address(RVA = "0x2C00124", Offset = "0x2C00124", VA = "0x2C00124")]
	private IEnumerator method_30()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001813 RID: 6163 RVA: 0x00031320 File Offset: 0x0002F520
	[Address(RVA = "0x2C0019C", Offset = "0x2C0019C", VA = "0x2C0019C")]
	[Token(Token = "0x6001813")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "Players Online: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.", value != 0L);
		IEnumerator routine = this.method_8();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001814 RID: 6164 RVA: 0x0003137C File Offset: 0x0002F57C
	[Address(RVA = "0x2C00280", Offset = "0x2C00280", VA = "0x2C00280")]
	[Token(Token = "0x6001814")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("A new Player joined a Room.", value != 0L);
		IEnumerator routine = this.method_0();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001815 RID: 6165 RVA: 0x000313D8 File Offset: 0x0002F5D8
	[Address(RVA = "0x2C00364", Offset = "0x2C00364", VA = "0x2C00364")]
	[Token(Token = "0x6001815")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("duration done", value != 0L);
	}

	// Token: 0x06001816 RID: 6166 RVA: 0x00031424 File Offset: 0x0002F624
	[Address(RVA = "0x2C00448", Offset = "0x2C00448", VA = "0x2C00448")]
	[Token(Token = "0x6001816")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Look Like Butt";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("ScoreCounter", value != 0L);
	}

	// Token: 0x06001817 RID: 6167 RVA: 0x00031470 File Offset: 0x0002F670
	[Address(RVA = "0x2C0052C", Offset = "0x2C0052C", VA = "0x2C0052C")]
	[Token(Token = "0x6001817")]
	public void method_35(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("_Tint", value != 0L);
		IEnumerator routine = this.method_8();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001818 RID: 6168 RVA: 0x000314C4 File Offset: 0x0002F6C4
	[Address(RVA = "0x2C00610", Offset = "0x2C00610", VA = "0x2C00610")]
	[Token(Token = "0x6001818")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 0L;
		animator.SetBool("oculus", value != 0L);
	}

	// Token: 0x06001819 RID: 6169 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2C006F4", Offset = "0x2C006F4", VA = "0x2C006F4")]
	[Token(Token = "0x6001819")]
	public BananaManStare()
	{
	}

	// Token: 0x0600181A RID: 6170 RVA: 0x00031510 File Offset: 0x0002F710
	[Address(RVA = "0x2C006FC", Offset = "0x2C006FC", VA = "0x2C006FC")]
	[Token(Token = "0x600181A")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "Failed To Join Public Room Successfully. The error is: ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("hh:mmtt", value != 0L);
		IEnumerator routine = this.method_8();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600181B RID: 6171 RVA: 0x0003156C File Offset: 0x0002F76C
	[Address(RVA = "0x2C007E0", Offset = "0x2C007E0", VA = "0x2C007E0")]
	[Token(Token = "0x600181B")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.tag == "character limit reached";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("NGNNoSound", value != 0L);
	}

	// Token: 0x0600181C RID: 6172 RVA: 0x000315B8 File Offset: 0x0002F7B8
	[Address(RVA = "0x2C008C4", Offset = "0x2C008C4", VA = "0x2C008C4")]
	[Token(Token = "0x600181C")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.tag == "_WobbleZ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("This is the 1000 Bananas button, and it was just clicked", value != 0L);
		IEnumerator routine = this.method_0();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600181D RID: 6173 RVA: 0x00031614 File Offset: 0x0002F814
	[Address(RVA = "0x2C009A8", Offset = "0x2C009A8", VA = "0x2C009A8")]
	[Token(Token = "0x600181D")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Already Own This Item";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("Player", value != 0L);
		IEnumerator routine = this.method_21();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600181E RID: 6174 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2C00A8C", Offset = "0x2C00A8C", VA = "0x2C00A8C")]
	[Token(Token = "0x600181E")]
	private IEnumerator method_41()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600181F RID: 6175 RVA: 0x00030CAC File Offset: 0x0002EEAC
	[Address(RVA = "0x2BFECF0", Offset = "0x2BFECF0", VA = "0x2BFECF0")]
	[Token(Token = "0x600181F")]
	private IEnumerator method_42()
	{
		BananaManStare.Class19 @class = new BananaManStare.Class19((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001820 RID: 6176 RVA: 0x00031670 File Offset: 0x0002F870
	[Address(RVA = "0x2C00B04", Offset = "0x2C00B04", VA = "0x2C00B04")]
	[Token(Token = "0x6001820")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		Animator animator = this.animator_0;
		long value = 1L;
		animator.SetBool("PlayWave", value != 0L);
		IEnumerator routine = this.method_1();
		base.StartCoroutine(routine);
	}

	// Token: 0x0400031B RID: 795
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400031B")]
	public GameObject gameObject_0;

	// Token: 0x0400031C RID: 796
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400031C")]
	public Transform transform_0;

	// Token: 0x0400031D RID: 797
	[Token(Token = "0x400031D")]
	[FieldOffset(Offset = "0x28")]
	public Quaternion quaternion_0;

	// Token: 0x0400031E RID: 798
	[Token(Token = "0x400031E")]
	[FieldOffset(Offset = "0x38")]
	public Animator animator_0;
}
