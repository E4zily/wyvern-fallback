﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200001C RID: 28
[Token(Token = "0x200001C")]
public class TeleportObject : MonoBehaviour
{
	// Token: 0x0600038C RID: 908 RVA: 0x0000B83C File Offset: 0x00009A3C
	[Token(Token = "0x600038C")]
	[Address(RVA = "0x2D34410", Offset = "0x2D34410", VA = "0x2D34410")]
	public void method_0(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("oculus");
			return;
		}
	}

	// Token: 0x0600038D RID: 909 RVA: 0x0000B888 File Offset: 0x00009A88
	[Token(Token = "0x600038D")]
	[Address(RVA = "0x2D344D8", Offset = "0x2D344D8", VA = "0x2D344D8")]
	public void method_1(Collider collider_0)
	{
		GameObject gameObject;
		string tag = gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("TurnAmount");
			return;
		}
	}

	// Token: 0x0600038E RID: 910 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D345A0", Offset = "0x2D345A0", VA = "0x2D345A0")]
	[Token(Token = "0x600038E")]
	private IEnumerator method_2()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600038F RID: 911 RVA: 0x0000B8F8 File Offset: 0x00009AF8
	[Token(Token = "0x600038F")]
	[Address(RVA = "0x2D34618", Offset = "0x2D34618", VA = "0x2D34618")]
	public void method_3(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("betaAgree");
			return;
		}
	}

	// Token: 0x06000390 RID: 912 RVA: 0x0000B944 File Offset: 0x00009B44
	[Address(RVA = "0x2D346E0", Offset = "0x2D346E0", VA = "0x2D346E0")]
	[Token(Token = "0x6000390")]
	public void method_4(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("ࡉٝܭ۲");
			return;
		}
	}

	// Token: 0x06000391 RID: 913 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D347A8", Offset = "0x2D347A8", VA = "0x2D347A8")]
	[Token(Token = "0x6000391")]
	private IEnumerator method_5()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000392 RID: 914 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x6000392")]
	[Address(RVA = "0x2D34820", Offset = "0x2D34820", VA = "0x2D34820")]
	private IEnumerator method_6()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000393 RID: 915 RVA: 0x0000B990 File Offset: 0x00009B90
	[Token(Token = "0x6000393")]
	[Address(RVA = "0x2D34898", Offset = "0x2D34898", VA = "0x2D34898")]
	public void OnTriggerEnter(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("׎ٸࢦ܈");
			return;
		}
	}

	// Token: 0x06000394 RID: 916 RVA: 0x0000B9DC File Offset: 0x00009BDC
	[Token(Token = "0x6000394")]
	[Address(RVA = "0x2D34960", Offset = "0x2D34960", VA = "0x2D34960")]
	public void method_7(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("NetworkPlayer");
			return;
		}
	}

	// Token: 0x06000395 RID: 917 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D34A28", Offset = "0x2D34A28", VA = "0x2D34A28")]
	[Token(Token = "0x6000395")]
	private IEnumerator method_8()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000396 RID: 918 RVA: 0x0000BA28 File Offset: 0x00009C28
	[Address(RVA = "0x2D34AA0", Offset = "0x2D34AA0", VA = "0x2D34AA0")]
	[Token(Token = "0x6000396")]
	public void method_9(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		base.StartCoroutine("HandR");
	}

	// Token: 0x06000397 RID: 919 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x6000397")]
	[Address(RVA = "0x2D34B68", Offset = "0x2D34B68", VA = "0x2D34B68")]
	private IEnumerator method_10()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000398 RID: 920 RVA: 0x0000BA6C File Offset: 0x00009C6C
	[Token(Token = "0x6000398")]
	[Address(RVA = "0x2D34BE0", Offset = "0x2D34BE0", VA = "0x2D34BE0")]
	public void method_11(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("gamemode");
			return;
		}
	}

	// Token: 0x06000399 RID: 921 RVA: 0x0000BAB8 File Offset: 0x00009CB8
	[Address(RVA = "0x2D34CA8", Offset = "0x2D34CA8", VA = "0x2D34CA8")]
	[Token(Token = "0x6000399")]
	public void method_12(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Holdable");
			return;
		}
	}

	// Token: 0x0600039A RID: 922 RVA: 0x0000BAF4 File Offset: 0x00009CF4
	[Address(RVA = "0x2D34D70", Offset = "0x2D34D70", VA = "0x2D34D70")]
	[Token(Token = "0x600039A")]
	private IEnumerator method_13()
	{
		new TeleportObject.Class5((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x0600039B RID: 923 RVA: 0x0000BAF4 File Offset: 0x00009CF4
	[Address(RVA = "0x2D34DE8", Offset = "0x2D34DE8", VA = "0x2D34DE8")]
	[Token(Token = "0x600039B")]
	private IEnumerator method_14()
	{
		new TeleportObject.Class5((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x0600039C RID: 924 RVA: 0x0000BB18 File Offset: 0x00009D18
	[Address(RVA = "0x2D34E60", Offset = "0x2D34E60", VA = "0x2D34E60")]
	[Token(Token = "0x600039C")]
	public void method_15(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("character limit reached");
			return;
		}
	}

	// Token: 0x0600039D RID: 925 RVA: 0x0000BB64 File Offset: 0x00009D64
	[Token(Token = "0x600039D")]
	[Address(RVA = "0x2D34F28", Offset = "0x2D34F28", VA = "0x2D34F28")]
	public void method_16(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("isLava");
			return;
		}
	}

	// Token: 0x0600039E RID: 926 RVA: 0x0000BBB0 File Offset: 0x00009DB0
	[Token(Token = "0x600039E")]
	[Address(RVA = "0x2D34FF0", Offset = "0x2D34FF0", VA = "0x2D34FF0")]
	public void method_17(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("NoseAttachPoint");
			return;
		}
	}

	// Token: 0x0600039F RID: 927 RVA: 0x0000BBFC File Offset: 0x00009DFC
	[Token(Token = "0x600039F")]
	[Address(RVA = "0x2D350B8", Offset = "0x2D350B8", VA = "0x2D350B8")]
	public void method_18(Collider collider_0)
	{
		GameObject gameObject;
		string tag = gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
			return;
		}
	}

	// Token: 0x060003A0 RID: 928 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D35180", Offset = "0x2D35180", VA = "0x2D35180")]
	[Token(Token = "0x60003A0")]
	private IEnumerator method_19()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A1 RID: 929 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x60003A1")]
	[Address(RVA = "0x2D351F8", Offset = "0x2D351F8", VA = "0x2D351F8")]
	private IEnumerator method_20()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x0000BC44 File Offset: 0x00009E44
	[Token(Token = "0x60003A2")]
	[Address(RVA = "0x2D35270", Offset = "0x2D35270", VA = "0x2D35270")]
	public void method_21(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			base.StartCoroutine("User has been reported for: ");
			return;
		}
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x60003A3")]
	[Address(RVA = "0x2D35338", Offset = "0x2D35338", VA = "0x2D35338")]
	private IEnumerator method_22()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x0000BC84 File Offset: 0x00009E84
	[Address(RVA = "0x2D353B0", Offset = "0x2D353B0", VA = "0x2D353B0")]
	[Token(Token = "0x60003A4")]
	private IEnumerator method_23()
	{
		TeleportObject.Class5 @class;
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x0000BCA0 File Offset: 0x00009EA0
	[Address(RVA = "0x2D35428", Offset = "0x2D35428", VA = "0x2D35428")]
	[Token(Token = "0x60003A5")]
	public void method_24(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("PRESS AGAIN TO CONFIRM");
			return;
		}
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x0000BCEC File Offset: 0x00009EEC
	[Address(RVA = "0x2D354F0", Offset = "0x2D354F0", VA = "0x2D354F0")]
	[Token(Token = "0x60003A6")]
	public void method_25(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Players Online: ");
			return;
		}
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x0000BD38 File Offset: 0x00009F38
	[Token(Token = "0x60003A7")]
	[Address(RVA = "0x2D355B8", Offset = "0x2D355B8", VA = "0x2D355B8")]
	public void method_26(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Regular");
			return;
		}
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D35680", Offset = "0x2D35680", VA = "0x2D35680")]
	[Token(Token = "0x60003A8")]
	private IEnumerator method_27()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D356F8", Offset = "0x2D356F8", VA = "0x2D356F8")]
	[Token(Token = "0x60003A9")]
	private IEnumerator method_28()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003AA RID: 938 RVA: 0x0000BD84 File Offset: 0x00009F84
	[Token(Token = "0x60003AA")]
	[Address(RVA = "0x2D35770", Offset = "0x2D35770", VA = "0x2D35770")]
	public void method_29(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("username");
			return;
		}
	}

	// Token: 0x060003AB RID: 939 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D35838", Offset = "0x2D35838", VA = "0x2D35838")]
	[Token(Token = "0x60003AB")]
	private IEnumerator method_30()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003AC RID: 940 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x60003AC")]
	[Address(RVA = "0x2D358B0", Offset = "0x2D358B0", VA = "0x2D358B0")]
	private IEnumerator method_31()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003AD RID: 941 RVA: 0x0000BDD0 File Offset: 0x00009FD0
	[Address(RVA = "0x2D35928", Offset = "0x2D35928", VA = "0x2D35928")]
	[Token(Token = "0x60003AD")]
	public void method_32(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Updating Material to: ");
			return;
		}
	}

	// Token: 0x060003AE RID: 942 RVA: 0x0000BE1C File Offset: 0x0000A01C
	[Address(RVA = "0x2D359F0", Offset = "0x2D359F0", VA = "0x2D359F0")]
	[Token(Token = "0x60003AE")]
	public void method_33(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("ChangeToTagged");
			return;
		}
	}

	// Token: 0x060003AF RID: 943 RVA: 0x0000BE68 File Offset: 0x0000A068
	[Address(RVA = "0x2D35AB8", Offset = "0x2D35AB8", VA = "0x2D35AB8")]
	[Token(Token = "0x60003AF")]
	public void method_34(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("BLUPORT");
			return;
		}
	}

	// Token: 0x060003B0 RID: 944 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x60003B0")]
	[Address(RVA = "0x2D35B80", Offset = "0x2D35B80", VA = "0x2D35B80")]
	private IEnumerator method_35()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B1 RID: 945 RVA: 0x0000B8F8 File Offset: 0x00009AF8
	[Address(RVA = "0x2D35BF8", Offset = "0x2D35BF8", VA = "0x2D35BF8")]
	[Token(Token = "0x60003B1")]
	public void method_36(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("betaAgree");
			return;
		}
	}

	// Token: 0x060003B2 RID: 946 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x60003B2")]
	[Address(RVA = "0x2D35CC0", Offset = "0x2D35CC0", VA = "0x2D35CC0")]
	private IEnumerator method_37()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x0000BEB4 File Offset: 0x0000A0B4
	[Token(Token = "0x60003B3")]
	[Address(RVA = "0x2D35D38", Offset = "0x2D35D38", VA = "0x2D35D38")]
	public void method_38(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Start Gamemode");
			return;
		}
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D35E00", Offset = "0x2D35E00", VA = "0x2D35E00")]
	[Token(Token = "0x60003B4")]
	private IEnumerator method_39()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D35E78", Offset = "0x2D35E78", VA = "0x2D35E78")]
	[Token(Token = "0x60003B5")]
	private IEnumerator method_40()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B6 RID: 950 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D35EF0", Offset = "0x2D35EF0", VA = "0x2D35EF0")]
	[Token(Token = "0x60003B6")]
	private IEnumerator method_41()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B7 RID: 951 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x60003B7")]
	[Address(RVA = "0x2D35F68", Offset = "0x2D35F68", VA = "0x2D35F68")]
	private IEnumerator method_42()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x0000BF00 File Offset: 0x0000A100
	[Address(RVA = "0x2D35FE0", Offset = "0x2D35FE0", VA = "0x2D35FE0")]
	[Token(Token = "0x60003B8")]
	public void method_43(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			return;
		}
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D360A8", Offset = "0x2D360A8", VA = "0x2D360A8")]
	[Token(Token = "0x60003B9")]
	private IEnumerator method_44()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003BA RID: 954 RVA: 0x0000BF4C File Offset: 0x0000A14C
	[Address(RVA = "0x2D36120", Offset = "0x2D36120", VA = "0x2D36120")]
	[Token(Token = "0x60003BA")]
	public void method_45(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("PlayNoise");
			return;
		}
	}

	// Token: 0x060003BB RID: 955 RVA: 0x0000BF98 File Offset: 0x0000A198
	[Token(Token = "0x60003BB")]
	[Address(RVA = "0x2D361E8", Offset = "0x2D361E8", VA = "0x2D361E8")]
	public void method_46(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		base.StartCoroutine(" needs Pelvis transform assigned.");
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2D362B0", Offset = "0x2D362B0", VA = "0x2D362B0")]
	[Token(Token = "0x60003BC")]
	public TeleportObject()
	{
	}

	// Token: 0x060003BD RID: 957 RVA: 0x0000BFDC File Offset: 0x0000A1DC
	[Address(RVA = "0x2D362B8", Offset = "0x2D362B8", VA = "0x2D362B8")]
	[Token(Token = "0x60003BD")]
	public void method_47(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Display Name Changed!");
			return;
		}
	}

	// Token: 0x060003BE RID: 958 RVA: 0x0000C028 File Offset: 0x0000A228
	[Token(Token = "0x60003BE")]
	[Address(RVA = "0x2D36380", Offset = "0x2D36380", VA = "0x2D36380")]
	public void method_48(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("DisableCosmetic");
			return;
		}
	}

	// Token: 0x060003BF RID: 959 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D36448", Offset = "0x2D36448", VA = "0x2D36448")]
	[Token(Token = "0x60003BF")]
	private IEnumerator method_49()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x0000C074 File Offset: 0x0000A274
	[Token(Token = "0x60003C0")]
	[Address(RVA = "0x2D364C0", Offset = "0x2D364C0", VA = "0x2D364C0")]
	public void method_50(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("EnableCosmetic");
			return;
		}
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D36588", Offset = "0x2D36588", VA = "0x2D36588")]
	[Token(Token = "0x60003C1")]
	private IEnumerator method_51()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003C2 RID: 962 RVA: 0x0000C0C0 File Offset: 0x0000A2C0
	[Address(RVA = "0x2D36600", Offset = "0x2D36600", VA = "0x2D36600")]
	[Token(Token = "0x60003C2")]
	public void method_52(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("Faild To Add Winner Money: ");
			return;
		}
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Token(Token = "0x60003C3")]
	[Address(RVA = "0x2D366C8", Offset = "0x2D366C8", VA = "0x2D366C8")]
	private IEnumerator method_53()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x0000C10C File Offset: 0x0000A30C
	[Address(RVA = "0x2D36740", Offset = "0x2D36740", VA = "0x2D36740")]
	[Token(Token = "0x60003C4")]
	public void method_54(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
		if (this.bool_0)
		{
			base.StartCoroutine("{0}/{1:f0}");
			return;
		}
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D36808", Offset = "0x2D36808", VA = "0x2D36808")]
	[Token(Token = "0x60003C5")]
	private IEnumerator method_55()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x0000B8D0 File Offset: 0x00009AD0
	[Address(RVA = "0x2D36880", Offset = "0x2D36880", VA = "0x2D36880")]
	[Token(Token = "0x60003C6")]
	private IEnumerator method_56()
	{
		TeleportObject.Class5 @class = new TeleportObject.Class5((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x04000072 RID: 114
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000072")]
	public Transform transform_0;

	// Token: 0x04000073 RID: 115
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000073")]
	public Transform transform_1;

	// Token: 0x04000074 RID: 116
	[Token(Token = "0x4000074")]
	[FieldOffset(Offset = "0x28")]
	public string string_0;

	// Token: 0x04000075 RID: 117
	[Token(Token = "0x4000075")]
	[FieldOffset(Offset = "0x30")]
	public GameObject gameObject_0;

	// Token: 0x04000076 RID: 118
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000076")]
	public bool bool_0;
}
