﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000DB RID: 219
[Token(Token = "0x20000DB")]
public class MonkeScream : MonoBehaviour
{
	// Token: 0x06002095 RID: 8341 RVA: 0x0003CF7C File Offset: 0x0003B17C
	[Address(RVA = "0x2E668BC", Offset = "0x2E668BC", VA = "0x2E668BC")]
	[Token(Token = "0x6002095")]
	public void method_0()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Charged!");
	}

	// Token: 0x06002096 RID: 8342 RVA: 0x0003CFB0 File Offset: 0x0003B1B0
	[Address(RVA = "0x2E66984", Offset = "0x2E66984", VA = "0x2E66984")]
	[Token(Token = "0x6002096")]
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		Debug.Log("monke screamed");
	}

	// Token: 0x06002097 RID: 8343 RVA: 0x0003CFD0 File Offset: 0x0003B1D0
	[Address(RVA = "0x2E66B2C", Offset = "0x2E66B2C", VA = "0x2E66B2C")]
	[Token(Token = "0x6002097")]
	public void Start()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("monke is not my monke");
	}

	// Token: 0x06002098 RID: 8344 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E66BF0", Offset = "0x2E66BF0", VA = "0x2E66BF0")]
	[Token(Token = "0x6002098")]
	private void method_1()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06002099 RID: 8345 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E66C70", Offset = "0x2E66C70", VA = "0x2E66C70")]
	[Token(Token = "0x6002099")]
	private void method_2()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x0600209A RID: 8346 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E66CF0", Offset = "0x2E66CF0", VA = "0x2E66CF0")]
	[Token(Token = "0x600209A")]
	private void method_3()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x0600209B RID: 8347 RVA: 0x0003D01C File Offset: 0x0003B21C
	[Address(RVA = "0x2E66D70", Offset = "0x2E66D70", VA = "0x2E66D70")]
	[Token(Token = "0x600209B")]
	public void method_4()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
	}

	// Token: 0x0600209C RID: 8348 RVA: 0x0003D050 File Offset: 0x0003B250
	[Address(RVA = "0x2E66E38", Offset = "0x2E66E38", VA = "0x2E66E38")]
	[Token(Token = "0x600209C")]
	public void method_5()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Not enough amount of currency");
	}

	// Token: 0x0600209D RID: 8349 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E66EFC", Offset = "0x2E66EFC", VA = "0x2E66EFC")]
	[Token(Token = "0x600209D")]
	private void method_6()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x0600209E RID: 8350 RVA: 0x0003D084 File Offset: 0x0003B284
	[Address(RVA = "0x2E66F7C", Offset = "0x2E66F7C", VA = "0x2E66F7C")]
	[Token(Token = "0x600209E")]
	public void method_7()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("This is the 2500 Bananas button, and it was just clicked");
	}

	// Token: 0x0600209F RID: 8351 RVA: 0x0003D0B8 File Offset: 0x0003B2B8
	[Address(RVA = "0x2E67044", Offset = "0x2E67044", VA = "0x2E67044")]
	[Token(Token = "0x600209F")]
	public void method_8()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("Player");
			return;
		}
	}

	// Token: 0x060020A0 RID: 8352 RVA: 0x0003D0E4 File Offset: 0x0003B2E4
	[Address(RVA = "0x2E671F4", Offset = "0x2E671F4", VA = "0x2E671F4")]
	[Token(Token = "0x60020A0")]
	public void method_9()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("Purchase For ");
			return;
		}
	}

	// Token: 0x060020A1 RID: 8353 RVA: 0x0003D110 File Offset: 0x0003B310
	[Address(RVA = "0x2E673A0", Offset = "0x2E673A0", VA = "0x2E673A0")]
	[Token(Token = "0x60020A1")]
	public void method_10()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("retract broken");
	}

	// Token: 0x060020A2 RID: 8354 RVA: 0x0003D144 File Offset: 0x0003B344
	[Address(RVA = "0x2E67468", Offset = "0x2E67468", VA = "0x2E67468")]
	[Token(Token = "0x60020A2")]
	public void method_11()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("BN");
	}

	// Token: 0x060020A3 RID: 8355 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E67530", Offset = "0x2E67530", VA = "0x2E67530")]
	[Token(Token = "0x60020A3")]
	private void method_12()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020A4 RID: 8356 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E675B0", Offset = "0x2E675B0", VA = "0x2E675B0")]
	[Token(Token = "0x60020A4")]
	private void method_13()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020A5 RID: 8357 RVA: 0x0003D178 File Offset: 0x0003B378
	[Address(RVA = "0x2E67630", Offset = "0x2E67630", VA = "0x2E67630")]
	[Token(Token = "0x60020A5")]
	public void method_14()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("username");
	}

	// Token: 0x060020A6 RID: 8358 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E676F8", Offset = "0x2E676F8", VA = "0x2E676F8")]
	[Token(Token = "0x60020A6")]
	private void method_15()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020A7 RID: 8359 RVA: 0x0003D004 File Offset: 0x0003B204
	[PunRPC]
	[Address(RVA = "0x2E67778", Offset = "0x2E67778", VA = "0x2E67778")]
	[Token(Token = "0x60020A7")]
	private void monkeScream()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020A8 RID: 8360 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E677F8", Offset = "0x2E677F8", VA = "0x2E677F8")]
	[Token(Token = "0x60020A8")]
	private void method_16()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020A9 RID: 8361 RVA: 0x0003D178 File Offset: 0x0003B378
	[Address(RVA = "0x2E67878", Offset = "0x2E67878", VA = "0x2E67878")]
	[Token(Token = "0x60020A9")]
	public void method_17()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("username");
	}

	// Token: 0x060020AA RID: 8362 RVA: 0x0003D1AC File Offset: 0x0003B3AC
	[Address(RVA = "0x2E67940", Offset = "0x2E67940", VA = "0x2E67940")]
	[Token(Token = "0x60020AA")]
	public void method_18()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("Regular");
			return;
		}
	}

	// Token: 0x060020AB RID: 8363 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E67AF0", Offset = "0x2E67AF0", VA = "0x2E67AF0")]
	[Token(Token = "0x60020AB")]
	private void method_19()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020AC RID: 8364 RVA: 0x0003D1D8 File Offset: 0x0003B3D8
	[Address(RVA = "0x2E67B70", Offset = "0x2E67B70", VA = "0x2E67B70")]
	[Token(Token = "0x60020AC")]
	public void method_20()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("FingerTip");
	}

	// Token: 0x060020AD RID: 8365 RVA: 0x0003D20C File Offset: 0x0003B40C
	[Address(RVA = "0x2E67C38", Offset = "0x2E67C38", VA = "0x2E67C38")]
	[Token(Token = "0x60020AD")]
	public void method_21()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("Head");
			return;
		}
	}

	// Token: 0x060020AE RID: 8366 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E67DE4", Offset = "0x2E67DE4", VA = "0x2E67DE4")]
	[Token(Token = "0x60020AE")]
	private void method_22()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020AF RID: 8367 RVA: 0x0003D238 File Offset: 0x0003B438
	[Address(RVA = "0x2E67E64", Offset = "0x2E67E64", VA = "0x2E67E64")]
	[Token(Token = "0x60020AF")]
	public void method_23()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("got funky mone");
			return;
		}
	}

	// Token: 0x060020B0 RID: 8368 RVA: 0x0003D264 File Offset: 0x0003B464
	[Address(RVA = "0x2E68014", Offset = "0x2E68014", VA = "0x2E68014")]
	[Token(Token = "0x60020B0")]
	public void method_24()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("Key");
			return;
		}
	}

	// Token: 0x060020B1 RID: 8369 RVA: 0x0003D290 File Offset: 0x0003B490
	[Address(RVA = "0x2E681C4", Offset = "0x2E681C4", VA = "0x2E681C4")]
	[Token(Token = "0x60020B1")]
	public void method_25()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("username");
			return;
		}
	}

	// Token: 0x060020B2 RID: 8370 RVA: 0x0003D2BC File Offset: 0x0003B4BC
	[Address(RVA = "0x2E68374", Offset = "0x2E68374", VA = "0x2E68374")]
	[Token(Token = "0x60020B2")]
	public void method_26()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Player was caught cheating");
	}

	// Token: 0x060020B3 RID: 8371 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E6843C", Offset = "0x2E6843C", VA = "0x2E6843C")]
	[Token(Token = "0x60020B3")]
	private void method_27()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020B4 RID: 8372 RVA: 0x0003D2F0 File Offset: 0x0003B4F0
	[Address(RVA = "0x2E684BC", Offset = "0x2E684BC", VA = "0x2E684BC")]
	[Token(Token = "0x60020B4")]
	public void method_28()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("retract broken");
	}

	// Token: 0x060020B5 RID: 8373 RVA: 0x0003D324 File Offset: 0x0003B524
	[Address(RVA = "0x2E68584", Offset = "0x2E68584", VA = "0x2E68584")]
	[Token(Token = "0x60020B5")]
	public void method_29()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Player");
	}

	// Token: 0x060020B6 RID: 8374 RVA: 0x0003D358 File Offset: 0x0003B558
	[Address(RVA = "0x2E6864C", Offset = "0x2E6864C", VA = "0x2E6864C")]
	[Token(Token = "0x60020B6")]
	public void method_30()
	{
		float deltaTime = Time.deltaTime;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Debug.Log("ORGTARG");
			return;
		}
	}

	// Token: 0x060020B7 RID: 8375 RVA: 0x0003D004 File Offset: 0x0003B204
	[Address(RVA = "0x2E687FC", Offset = "0x2E687FC", VA = "0x2E687FC")]
	[Token(Token = "0x60020B7")]
	private void method_31()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x060020B8 RID: 8376 RVA: 0x0003D384 File Offset: 0x0003B584
	[Address(RVA = "0x2E6887C", Offset = "0x2E6887C", VA = "0x2E6887C")]
	[Token(Token = "0x60020B8")]
	public void method_32()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Cannot take elements from an empty buffer.");
	}

	// Token: 0x060020B9 RID: 8377 RVA: 0x0003D3B8 File Offset: 0x0003B5B8
	[Address(RVA = "0x2E68944", Offset = "0x2E68944", VA = "0x2E68944")]
	[Token(Token = "0x60020B9")]
	public void method_33()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Hats");
	}

	// Token: 0x060020BA RID: 8378 RVA: 0x0003D178 File Offset: 0x0003B378
	[Address(RVA = "0x2E68A0C", Offset = "0x2E68A0C", VA = "0x2E68A0C")]
	[Token(Token = "0x60020BA")]
	public void method_34()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("username");
	}

	// Token: 0x060020BB RID: 8379 RVA: 0x0003D3EC File Offset: 0x0003B5EC
	[Address(RVA = "0x2E68AD4", Offset = "0x2E68AD4", VA = "0x2E68AD4")]
	[Token(Token = "0x60020BB")]
	public void method_35()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
	}

	// Token: 0x060020BC RID: 8380 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2E68B9C", Offset = "0x2E68B9C", VA = "0x2E68B9C")]
	[Token(Token = "0x60020BC")]
	public MonkeScream()
	{
	}

	// Token: 0x060020BD RID: 8381 RVA: 0x0003D414 File Offset: 0x0003B614
	[Address(RVA = "0x2E68BA4", Offset = "0x2E68BA4", VA = "0x2E68BA4")]
	[Token(Token = "0x60020BD")]
	public void method_36()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Game Started");
	}

	// Token: 0x060020BE RID: 8382 RVA: 0x0003D448 File Offset: 0x0003B648
	[Address(RVA = "0x2E68C6C", Offset = "0x2E68C6C", VA = "0x2E68C6C")]
	[Token(Token = "0x60020BE")]
	public void method_37()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			float volume;
			this.audioSource_0.volume = volume;
			return;
		}
		Debug.Log("Error");
	}

	// Token: 0x04000450 RID: 1104
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000450")]
	public AudioClip[] audioClip_0;

	// Token: 0x04000451 RID: 1105
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000451")]
	public AudioSource audioSource_0;

	// Token: 0x04000452 RID: 1106
	[Token(Token = "0x4000452")]
	[FieldOffset(Offset = "0x28")]
	public float float_0;

	// Token: 0x04000453 RID: 1107
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000453")]
	public PhotonView photonView_0;
}
