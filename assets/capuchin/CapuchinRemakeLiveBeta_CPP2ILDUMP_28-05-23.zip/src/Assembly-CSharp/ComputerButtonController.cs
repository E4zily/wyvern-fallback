﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

// Token: 0x020000B5 RID: 181
[Token(Token = "0x20000B5")]
public class ComputerButtonController : BirbButton
{
	// Token: 0x06001A10 RID: 6672 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A638BC", Offset = "0x2A638BC", VA = "0x2A638BC")]
	[Token(Token = "0x6001A10")]
	private IEnumerator method_43()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A11 RID: 6673 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A63934", Offset = "0x2A63934", VA = "0x2A63934")]
	[Token(Token = "0x6001A11")]
	private IEnumerator method_44()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A12 RID: 6674 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A639AC", Offset = "0x2A639AC", VA = "0x2A639AC")]
	[Token(Token = "0x6001A12")]
	private IEnumerator method_45()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A13 RID: 6675 RVA: 0x00033A54 File Offset: 0x00031C54
	[Address(RVA = "0x2A63A24", Offset = "0x2A63A24", VA = "0x2A63A24")]
	[Token(Token = "0x6001A13")]
	public void method_46()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		string str2 = UnityEngine.Random.Range(0, 135).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A14 RID: 6676 RVA: 0x00033AA4 File Offset: 0x00031CA4
	[Address(RVA = "0x2A63B58", Offset = "0x2A63B58", VA = "0x2A63B58")]
	[Token(Token = "0x6001A14")]
	private void method_47(PlayFabError playFabError_0)
	{
		base.StartCoroutine("run");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A15 RID: 6677 RVA: 0x00033AD0 File Offset: 0x00031CD0
	[Address(RVA = "0x2A63CC8", Offset = "0x2A63CC8", VA = "0x2A63CC8")]
	[Token(Token = "0x6001A15")]
	public void method_48()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		long minInclusive = 1L;
		string str2 = UnityEngine.Random.Range((int)minInclusive, 72).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A16 RID: 6678 RVA: 0x000027EF File Offset: 0x000009EF
	[Address(RVA = "0x2A63DFC", Offset = "0x2A63DFC", VA = "0x2A63DFC")]
	[Token(Token = "0x6001A16")]
	public ComputerButtonController()
	{
	}

	// Token: 0x06001A17 RID: 6679 RVA: 0x00033B24 File Offset: 0x00031D24
	[Address(RVA = "0x2A63E04", Offset = "0x2A63E04", VA = "0x2A63E04")]
	[Token(Token = "0x6001A17")]
	private void method_49(PlayFabError playFabError_0)
	{
		base.StartCoroutine("Grip");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A18 RID: 6680 RVA: 0x00033B50 File Offset: 0x00031D50
	[Address(RVA = "0x2A63F74", Offset = "0x2A63F74", VA = "0x2A63F74")]
	[Token(Token = "0x6001A18")]
	public void method_50()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		string str2 = UnityEngine.Random.Range(0, 45).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A19 RID: 6681 RVA: 0x00033BA0 File Offset: 0x00031DA0
	[Address(RVA = "0x2A640A8", Offset = "0x2A640A8", VA = "0x2A640A8")]
	[Token(Token = "0x6001A19")]
	public void method_51()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		string str2 = UnityEngine.Random.Range(0, 170).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A1A RID: 6682 RVA: 0x00033BF0 File Offset: 0x00031DF0
	[Address(RVA = "0x2A641DC", Offset = "0x2A641DC", VA = "0x2A641DC")]
	[Token(Token = "0x6001A1A")]
	private void method_52(PlayFabError playFabError_0)
	{
		base.StartCoroutine("EnableCosmetic");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A1B RID: 6683 RVA: 0x00033C1C File Offset: 0x00031E1C
	[Address(RVA = "0x2A6434C", Offset = "0x2A6434C", VA = "0x2A6434C")]
	[Token(Token = "0x6001A1B")]
	public new void Start()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		long minInclusive = 1L;
		string str2 = UnityEngine.Random.Range((int)minInclusive, 1000).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A1C RID: 6684 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A64480", Offset = "0x2A64480", VA = "0x2A64480")]
	[Token(Token = "0x6001A1C")]
	private IEnumerator method_53()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A1D RID: 6685 RVA: 0x00033C70 File Offset: 0x00031E70
	[Address(RVA = "0x2A644F8", Offset = "0x2A644F8", VA = "0x2A644F8")]
	[Token(Token = "0x6001A1D")]
	public void method_54()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		long minInclusive = 1L;
		string str2 = UnityEngine.Random.Range((int)minInclusive, 70).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A1E RID: 6686 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A6462C", Offset = "0x2A6462C", VA = "0x2A6462C")]
	[Token(Token = "0x6001A1E")]
	private IEnumerator method_55()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A1F RID: 6687 RVA: 0x00033CC4 File Offset: 0x00031EC4
	[CompilerGenerated]
	[Address(RVA = "0x2A646A4", Offset = "0x2A646A4", VA = "0x2A646A4")]
	[Token(Token = "0x6001A1F")]
	private void method_56(PlayFabError playFabError_0)
	{
		base.StartCoroutine("ࡉٝܭ۲");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A20 RID: 6688 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A64800", Offset = "0x2A64800", VA = "0x2A64800")]
	[Token(Token = "0x6001A20")]
	private IEnumerator method_57()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A21 RID: 6689 RVA: 0x00033CF0 File Offset: 0x00031EF0
	[Address(RVA = "0x2A64878", Offset = "0x2A64878", VA = "0x2A64878")]
	[Token(Token = "0x6001A21")]
	private void method_58(PlayFabError playFabError_0)
	{
		base.StartCoroutine("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
	}

	// Token: 0x06001A22 RID: 6690 RVA: 0x00033D14 File Offset: 0x00031F14
	[Address(RVA = "0x2A649E8", Offset = "0x2A649E8", VA = "0x2A649E8")]
	[Token(Token = "0x6001A22")]
	private void method_59(PlayFabError playFabError_0)
	{
		base.StartCoroutine("Add/Remove Sword");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A23 RID: 6691 RVA: 0x00033CC4 File Offset: 0x00031EC4
	[CompilerGenerated]
	[Address(RVA = "0x2A64B58", Offset = "0x2A64B58", VA = "0x2A64B58")]
	[Token(Token = "0x6001A23")]
	private void method_60(PlayFabError playFabError_0)
	{
		base.StartCoroutine("ࡉٝܭ۲");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A24 RID: 6692 RVA: 0x00033D40 File Offset: 0x00031F40
	[Address(RVA = "0x2A64CB4", Offset = "0x2A64CB4", VA = "0x2A64CB4")]
	[Token(Token = "0x6001A24")]
	private void method_61(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A25 RID: 6693 RVA: 0x00033D60 File Offset: 0x00031F60
	[Address(RVA = "0x2A64E24", Offset = "0x2A64E24", VA = "0x2A64E24")]
	[Token(Token = "0x6001A25")]
	private void method_62(PlayFabError playFabError_0)
	{
		base.StartCoroutine("Player");
		if (playFabError_0 != null)
		{
			return;
		}
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A26 RID: 6694 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A64F94", Offset = "0x2A64F94", VA = "0x2A64F94")]
	[Token(Token = "0x6001A26")]
	private IEnumerator method_63()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A27 RID: 6695 RVA: 0x00033D88 File Offset: 0x00031F88
	[Address(RVA = "0x2A6500C", Offset = "0x2A6500C", VA = "0x2A6500C")]
	[Token(Token = "0x6001A27")]
	public void method_64()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		long maxExclusive = 0L;
		string str = 0.ToString();
		string str2 = UnityEngine.Random.Range(1, (int)maxExclusive).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A28 RID: 6696 RVA: 0x00033DD8 File Offset: 0x00031FD8
	[Address(RVA = "0x2A65140", Offset = "0x2A65140", VA = "0x2A65140", Slot = "15")]
	[Token(Token = "0x6001A28")]
	public override void vmethod_11(bool bool_4)
	{
		if (this.bool_1)
		{
			return;
		}
		if (this.textMeshPro_0 != null)
		{
			Player localPlayer = PhotonNetwork.LocalPlayer;
			UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
			string @string = PlayerPrefs.GetString("username");
			updateUserTitleDisplayNameRequest.DisplayName = @string;
			if (ComputerButtonController.<>c.<>9__15_2 == null)
			{
				Action<UpdateUserTitleDisplayNameResult> <>9__15_;
				ComputerButtonController.<>c.<>9__15_2 = <>9__15_;
			}
			return;
		}
		Player localPlayer2 = PhotonNetwork.LocalPlayer;
		UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest2 = new UpdateUserTitleDisplayNameRequest();
		string string2 = PlayerPrefs.GetString("username");
		updateUserTitleDisplayNameRequest2.DisplayName = string2;
		if (ComputerButtonController.<>c.<>9__15_0 == null)
		{
			Action<UpdateUserTitleDisplayNameResult> <>9__15_2;
			ComputerButtonController.<>c.<>9__15_0 = <>9__15_2;
		}
	}

	// Token: 0x06001A29 RID: 6697 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A656C8", Offset = "0x2A656C8", VA = "0x2A656C8")]
	[Token(Token = "0x6001A29")]
	private IEnumerator method_65()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A2A RID: 6698 RVA: 0x00033E58 File Offset: 0x00032058
	[Address(RVA = "0x2A65740", Offset = "0x2A65740", VA = "0x2A65740")]
	[Token(Token = "0x6001A2A")]
	public void method_66()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		string str2 = UnityEngine.Random.Range(0, 166).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A2B RID: 6699 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A65874", Offset = "0x2A65874", VA = "0x2A65874")]
	[Token(Token = "0x6001A2B")]
	private IEnumerator method_67()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A2C RID: 6700 RVA: 0x00033EA8 File Offset: 0x000320A8
	[Address(RVA = "0x2A658EC", Offset = "0x2A658EC", VA = "0x2A658EC")]
	[Token(Token = "0x6001A2C")]
	private void method_68(PlayFabError playFabError_0)
	{
		base.StartCoroutine("Player");
	}

	// Token: 0x06001A2D RID: 6701 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A65A48", Offset = "0x2A65A48", VA = "0x2A65A48")]
	[Token(Token = "0x6001A2D")]
	private IEnumerator method_69()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A2E RID: 6702 RVA: 0x00033EC4 File Offset: 0x000320C4
	[Address(RVA = "0x2A65AC0", Offset = "0x2A65AC0", VA = "0x2A65AC0")]
	[Token(Token = "0x6001A2E")]
	private void method_70(PlayFabError playFabError_0)
	{
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A2F RID: 6703 RVA: 0x00033EE4 File Offset: 0x000320E4
	[Address(RVA = "0x2A65C30", Offset = "0x2A65C30", VA = "0x2A65C30")]
	[Token(Token = "0x6001A2F")]
	private void method_71(PlayFabError playFabError_0)
	{
		base.StartCoroutine("PlayWave");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A30 RID: 6704 RVA: 0x00033F10 File Offset: 0x00032110
	[Address(RVA = "0x2A65DA0", Offset = "0x2A65DA0", VA = "0x2A65DA0")]
	[Token(Token = "0x6001A30")]
	private void method_72(PlayFabError playFabError_0)
	{
		base.StartCoroutine("Version");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A31 RID: 6705 RVA: 0x00033F3C File Offset: 0x0003213C
	[Address(RVA = "0x2A65F10", Offset = "0x2A65F10", VA = "0x2A65F10")]
	[Token(Token = "0x6001A31")]
	public void method_73()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		long maxExclusive = 0L;
		string str = 0.ToString();
		string str2 = UnityEngine.Random.Range(0, (int)maxExclusive).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A32 RID: 6706 RVA: 0x00033F8C File Offset: 0x0003218C
	[Address(RVA = "0x2A66044", Offset = "0x2A66044", VA = "0x2A66044")]
	[Token(Token = "0x6001A32")]
	private void method_74(PlayFabError playFabError_0)
	{
		base.StartCoroutine("PushToTalk");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A33 RID: 6707 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x2A661B4", Offset = "0x2A661B4", VA = "0x2A661B4")]
	[Token(Token = "0x6001A33")]
	private IEnumerator method_75()
	{
		throw new NullReferenceException();
	}

	// Token: 0x06001A34 RID: 6708 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A6622C", Offset = "0x2A6622C", VA = "0x2A6622C")]
	[Token(Token = "0x6001A34")]
	private IEnumerator method_76()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A35 RID: 6709 RVA: 0x00033A2C File Offset: 0x00031C2C
	[Address(RVA = "0x2A662A4", Offset = "0x2A662A4", VA = "0x2A662A4")]
	[Token(Token = "0x6001A35")]
	private IEnumerator method_77()
	{
		ComputerButtonController.Class25 @class = new ComputerButtonController.Class25((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001A36 RID: 6710 RVA: 0x00033FB8 File Offset: 0x000321B8
	[Address(RVA = "0x2A6631C", Offset = "0x2A6631C", VA = "0x2A6631C")]
	[Token(Token = "0x6001A36")]
	public void method_78()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		this.boxCollider_1 = component;
		string str = 0.ToString();
		long minInclusive = 1L;
		long maxExclusive = 128L;
		string str2 = UnityEngine.Random.Range((int)minInclusive, (int)maxExclusive).ToString();
		string text = str + str2;
		this.string_4 = text;
		TextMeshPro textMeshPro;
		this.textMeshPro_1 = textMeshPro;
	}

	// Token: 0x06001A37 RID: 6711 RVA: 0x00034010 File Offset: 0x00032210
	[Address(RVA = "0x2A66450", Offset = "0x2A66450", VA = "0x2A66450")]
	[Token(Token = "0x6001A37")]
	private void method_79(PlayFabError playFabError_0)
	{
		base.StartCoroutine("_Tint");
		if (playFabError_0 != null)
		{
			return;
		}
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A38 RID: 6712 RVA: 0x00034038 File Offset: 0x00032238
	[Address(RVA = "0x2A665C0", Offset = "0x2A665C0", VA = "0x2A665C0")]
	[Token(Token = "0x6001A38")]
	private void method_80(PlayFabError playFabError_0)
	{
		base.StartCoroutine("PRESS AGAIN TO CONFIRM");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x06001A39 RID: 6713 RVA: 0x00034038 File Offset: 0x00032238
	[Address(RVA = "0x2A66730", Offset = "0x2A66730", VA = "0x2A66730")]
	[Token(Token = "0x6001A39")]
	private void method_81(PlayFabError playFabError_0)
	{
		base.StartCoroutine("PRESS AGAIN TO CONFIRM");
		if (playFabError_0 != null)
		{
			return;
		}
		string message;
		Debug.Log(message);
		if (playFabError_0 != null)
		{
			return;
		}
		Application.Quit();
	}

	// Token: 0x04000359 RID: 857
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000359")]
	public string string_0;

	// Token: 0x0400035A RID: 858
	[Token(Token = "0x400035A")]
	[FieldOffset(Offset = "0x38")]
	public GameObject gameObject_0;

	// Token: 0x0400035B RID: 859
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400035B")]
	public TextMeshPro textMeshPro_0;

	// Token: 0x0400035C RID: 860
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400035C")]
	public bool bool_1;

	// Token: 0x0400035D RID: 861
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400035D")]
	public string string_1;

	// Token: 0x0400035E RID: 862
	[Token(Token = "0x400035E")]
	[FieldOffset(Offset = "0x58")]
	public bool bool_2;

	// Token: 0x0400035F RID: 863
	[Token(Token = "0x400035F")]
	[FieldOffset(Offset = "0x59")]
	public bool bool_3;

	// Token: 0x04000360 RID: 864
	[Token(Token = "0x4000360")]
	[FieldOffset(Offset = "0x60")]
	public string[] string_2;

	// Token: 0x04000361 RID: 865
	[Token(Token = "0x4000361")]
	[FieldOffset(Offset = "0x68")]
	public string[] string_3;

	// Token: 0x04000362 RID: 866
	[Token(Token = "0x4000362")]
	[FieldOffset(Offset = "0x70")]
	public string string_4;

	// Token: 0x04000363 RID: 867
	[Token(Token = "0x4000363")]
	[FieldOffset(Offset = "0x78")]
	private BoxCollider boxCollider_1;

	// Token: 0x04000364 RID: 868
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4000364")]
	public GameObject gameObject_1;

	// Token: 0x04000365 RID: 869
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x4000365")]
	public TextMeshPro textMeshPro_1;
}
