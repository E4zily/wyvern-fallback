﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using TMPro;
using UnityEngine;

// Token: 0x02000101 RID: 257
[Token(Token = "0x2000101")]
public class UtilityMenu : MonoBehaviour
{
	// Token: 0x06002738 RID: 10040 RVA: 0x000504CC File Offset: 0x0004E6CC
	[Address(RVA = "0x20F5DC8", Offset = "0x20F5DC8", VA = "0x20F5DC8")]
	[Token(Token = "0x6002738")]
	private void method_0()
	{
		new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x06002739 RID: 10041 RVA: 0x00002D9F File Offset: 0x00000F9F
	[Address(RVA = "0x20F5FA0", Offset = "0x20F5FA0", VA = "0x20F5FA0")]
	[Token(Token = "0x6002739")]
	private void method_1()
	{
		UtilityMenu.utilityMenu_0 = this;
	}

	// Token: 0x0600273A RID: 10042 RVA: 0x000504CC File Offset: 0x0004E6CC
	[Address(RVA = "0x20F5FF4", Offset = "0x20F5FF4", VA = "0x20F5FF4")]
	[Token(Token = "0x600273A")]
	private void Update()
	{
		new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x0600273B RID: 10043 RVA: 0x00002D9F File Offset: 0x00000F9F
	[Address(RVA = "0x20F61CC", Offset = "0x20F61CC", VA = "0x20F61CC")]
	[Token(Token = "0x600273B")]
	private void Start()
	{
		UtilityMenu.utilityMenu_0 = this;
	}

	// Token: 0x0600273C RID: 10044 RVA: 0x00002DA7 File Offset: 0x00000FA7
	[Address(RVA = "0x20F6220", Offset = "0x20F6220", VA = "0x20F6220")]
	[Token(Token = "0x600273C")]
	public void method_2(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x0600273D RID: 10045 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600273D")]
	[Address(RVA = "0x20F6228", Offset = "0x20F6228", VA = "0x20F6228")]
	public UtilityMenu()
	{
	}

	// Token: 0x0600273E RID: 10046 RVA: 0x00002D9F File Offset: 0x00000F9F
	[Address(RVA = "0x20F6230", Offset = "0x20F6230", VA = "0x20F6230")]
	[Token(Token = "0x600273E")]
	private void method_3()
	{
		UtilityMenu.utilityMenu_0 = this;
	}

	// Token: 0x0600273F RID: 10047 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600273F")]
	[Address(RVA = "0x20F6284", Offset = "0x20F6284", VA = "0x20F6284")]
	public void method_4()
	{
	}

	// Token: 0x06002740 RID: 10048 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002740")]
	[Address(RVA = "0x20F6288", Offset = "0x20F6288", VA = "0x20F6288")]
	public void method_5()
	{
	}

	// Token: 0x06002741 RID: 10049 RVA: 0x000504EC File Offset: 0x0004E6EC
	[Address(RVA = "0x20F628C", Offset = "0x20F628C", VA = "0x20F628C")]
	[Token(Token = "0x6002741")]
	public void method_6(GameObject gameObject_0)
	{
		string name = gameObject_0.name;
		if (name != null)
		{
			name == "friend";
			return;
		}
	}

	// Token: 0x06002742 RID: 10050 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002742")]
	[Address(RVA = "0x20F62FC", Offset = "0x20F62FC", VA = "0x20F62FC")]
	public void method_7()
	{
	}

	// Token: 0x06002743 RID: 10051 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002743")]
	[Address(RVA = "0x20F6300", Offset = "0x20F6300", VA = "0x20F6300")]
	public void method_8()
	{
	}

	// Token: 0x06002744 RID: 10052 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002744")]
	[Address(RVA = "0x20F6304", Offset = "0x20F6304", VA = "0x20F6304")]
	public void method_9()
	{
	}

	// Token: 0x06002745 RID: 10053 RVA: 0x00002DA7 File Offset: 0x00000FA7
	[Token(Token = "0x6002745")]
	[Address(RVA = "0x20F6308", Offset = "0x20F6308", VA = "0x20F6308")]
	public void method_10(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x06002746 RID: 10054 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F6310", Offset = "0x20F6310", VA = "0x20F6310")]
	[Token(Token = "0x6002746")]
	public void method_11()
	{
	}

	// Token: 0x06002747 RID: 10055 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F6314", Offset = "0x20F6314", VA = "0x20F6314")]
	[Token(Token = "0x6002747")]
	public void method_12()
	{
	}

	// Token: 0x06002748 RID: 10056 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F6318", Offset = "0x20F6318", VA = "0x20F6318")]
	[Token(Token = "0x6002748")]
	public void method_13()
	{
	}

	// Token: 0x06002749 RID: 10057 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F631C", Offset = "0x20F631C", VA = "0x20F631C")]
	[Token(Token = "0x6002749")]
	public void method_14()
	{
	}

	// Token: 0x0600274A RID: 10058 RVA: 0x00002DA7 File Offset: 0x00000FA7
	[Token(Token = "0x600274A")]
	[Address(RVA = "0x20F6320", Offset = "0x20F6320", VA = "0x20F6320")]
	public void method_15(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x0600274B RID: 10059 RVA: 0x00050510 File Offset: 0x0004E710
	[Token(Token = "0x600274B")]
	[Address(RVA = "0x20F6328", Offset = "0x20F6328", VA = "0x20F6328")]
	private void method_16()
	{
		new string[PhotonNetwork.PlayerList.actorNumber];
	}

	// Token: 0x0600274C RID: 10060 RVA: 0x00050530 File Offset: 0x0004E730
	[Token(Token = "0x600274C")]
	[Address(RVA = "0x20F64DC", Offset = "0x20F64DC", VA = "0x20F64DC")]
	public void method_17(GameObject gameObject_0)
	{
		string name = gameObject_0.name;
		if (name != null)
		{
			name == "Player";
			return;
		}
	}

	// Token: 0x0600274D RID: 10061 RVA: 0x00050554 File Offset: 0x0004E754
	[Token(Token = "0x600274D")]
	[Address(RVA = "0x20F654C", Offset = "0x20F654C", VA = "0x20F654C")]
	public void method_18(GameObject gameObject_0)
	{
		string name = gameObject_0.name;
		if (name != null)
		{
			name == "Failed to get catalog, cosmetic name, and price. Exact error details is: ";
			return;
		}
	}

	// Token: 0x0600274E RID: 10062 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F65BC", Offset = "0x20F65BC", VA = "0x20F65BC")]
	[Token(Token = "0x600274E")]
	public void method_19()
	{
	}

	// Token: 0x0600274F RID: 10063 RVA: 0x00002DA7 File Offset: 0x00000FA7
	[Token(Token = "0x600274F")]
	[Address(RVA = "0x20F65C0", Offset = "0x20F65C0", VA = "0x20F65C0")]
	public void method_20(int int_1)
	{
		this.int_0 = int_1;
	}

	// Token: 0x040004F6 RID: 1270
	[Token(Token = "0x40004F6")]
	public static UtilityMenu utilityMenu_0;

	// Token: 0x040004F7 RID: 1271
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004F7")]
	private int int_0;

	// Token: 0x040004F8 RID: 1272
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004F8")]
	public TMP_Text[] tmp_Text_0;
}
