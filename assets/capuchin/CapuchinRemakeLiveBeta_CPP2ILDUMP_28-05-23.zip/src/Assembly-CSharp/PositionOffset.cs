﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E8 RID: 232
[Token(Token = "0x20000E8")]
public class PositionOffset : MonoBehaviour
{
	// Token: 0x06002291 RID: 8849 RVA: 0x0003F490 File Offset: 0x0003D690
	[Address(RVA = "0x2A7C3EC", Offset = "0x2A7C3EC", VA = "0x2A7C3EC")]
	[Token(Token = "0x6002291")]
	private void method_0()
	{
		Transform transform = base.transform;
		Transform transform2 = this.transform_0;
		if (transform2 == null)
		{
			throw new NullReferenceException();
		}
		Vector3 position = transform2.position;
	}

	// Token: 0x06002292 RID: 8850 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C44C", Offset = "0x2A7C44C", VA = "0x2A7C44C")]
	[Token(Token = "0x6002292")]
	private void method_1()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002293 RID: 8851 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C4AC", Offset = "0x2A7C4AC", VA = "0x2A7C4AC")]
	[Token(Token = "0x6002293")]
	private void method_2()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002294 RID: 8852 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C50C", Offset = "0x2A7C50C", VA = "0x2A7C50C")]
	[Token(Token = "0x6002294")]
	private void method_3()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002295 RID: 8853 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C56C", Offset = "0x2A7C56C", VA = "0x2A7C56C")]
	[Token(Token = "0x6002295")]
	private void method_4()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002296 RID: 8854 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C5CC", Offset = "0x2A7C5CC", VA = "0x2A7C5CC")]
	[Token(Token = "0x6002296")]
	private void method_5()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002297 RID: 8855 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C62C", Offset = "0x2A7C62C", VA = "0x2A7C62C")]
	[Token(Token = "0x6002297")]
	private void method_6()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002298 RID: 8856 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C68C", Offset = "0x2A7C68C", VA = "0x2A7C68C")]
	[Token(Token = "0x6002298")]
	private void method_7()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002299 RID: 8857 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C6EC", Offset = "0x2A7C6EC", VA = "0x2A7C6EC")]
	[Token(Token = "0x6002299")]
	private void method_8()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600229A RID: 8858 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C74C", Offset = "0x2A7C74C", VA = "0x2A7C74C")]
	[Token(Token = "0x600229A")]
	private void method_9()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600229B RID: 8859 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A7C7AC", Offset = "0x2A7C7AC", VA = "0x2A7C7AC")]
	[Token(Token = "0x600229B")]
	public PositionOffset()
	{
	}

	// Token: 0x0600229C RID: 8860 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C7B4", Offset = "0x2A7C7B4", VA = "0x2A7C7B4")]
	[Token(Token = "0x600229C")]
	private void method_10()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600229D RID: 8861 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C814", Offset = "0x2A7C814", VA = "0x2A7C814")]
	[Token(Token = "0x600229D")]
	private void method_11()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600229E RID: 8862 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C874", Offset = "0x2A7C874", VA = "0x2A7C874")]
	[Token(Token = "0x600229E")]
	private void method_12()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600229F RID: 8863 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C8D4", Offset = "0x2A7C8D4", VA = "0x2A7C8D4")]
	[Token(Token = "0x600229F")]
	private void method_13()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A0 RID: 8864 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C934", Offset = "0x2A7C934", VA = "0x2A7C934")]
	[Token(Token = "0x60022A0")]
	private void method_14()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A1 RID: 8865 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C994", Offset = "0x2A7C994", VA = "0x2A7C994")]
	[Token(Token = "0x60022A1")]
	private void method_15()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A2 RID: 8866 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7C9F4", Offset = "0x2A7C9F4", VA = "0x2A7C9F4")]
	[Token(Token = "0x60022A2")]
	private void method_16()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A3 RID: 8867 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CA54", Offset = "0x2A7CA54", VA = "0x2A7CA54")]
	[Token(Token = "0x60022A3")]
	private void method_17()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A4 RID: 8868 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CAB4", Offset = "0x2A7CAB4", VA = "0x2A7CAB4")]
	[Token(Token = "0x60022A4")]
	private void method_18()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A5 RID: 8869 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CB14", Offset = "0x2A7CB14", VA = "0x2A7CB14")]
	[Token(Token = "0x60022A5")]
	private void method_19()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A6 RID: 8870 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CB74", Offset = "0x2A7CB74", VA = "0x2A7CB74")]
	[Token(Token = "0x60022A6")]
	private void method_20()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A7 RID: 8871 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CBD4", Offset = "0x2A7CBD4", VA = "0x2A7CBD4")]
	[Token(Token = "0x60022A7")]
	private void method_21()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A8 RID: 8872 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CC34", Offset = "0x2A7CC34", VA = "0x2A7CC34")]
	[Token(Token = "0x60022A8")]
	private void method_22()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022A9 RID: 8873 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CC94", Offset = "0x2A7CC94", VA = "0x2A7CC94")]
	[Token(Token = "0x60022A9")]
	private void method_23()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022AA RID: 8874 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CCF4", Offset = "0x2A7CCF4", VA = "0x2A7CCF4")]
	[Token(Token = "0x60022AA")]
	private void method_24()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022AB RID: 8875 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CD54", Offset = "0x2A7CD54", VA = "0x2A7CD54")]
	[Token(Token = "0x60022AB")]
	private void method_25()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022AC RID: 8876 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CDB4", Offset = "0x2A7CDB4", VA = "0x2A7CDB4")]
	[Token(Token = "0x60022AC")]
	private void method_26()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022AD RID: 8877 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CE14", Offset = "0x2A7CE14", VA = "0x2A7CE14")]
	[Token(Token = "0x60022AD")]
	private void method_27()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022AE RID: 8878 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CE74", Offset = "0x2A7CE74", VA = "0x2A7CE74")]
	[Token(Token = "0x60022AE")]
	private void method_28()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022AF RID: 8879 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CED4", Offset = "0x2A7CED4", VA = "0x2A7CED4")]
	[Token(Token = "0x60022AF")]
	private void method_29()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B0 RID: 8880 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CF34", Offset = "0x2A7CF34", VA = "0x2A7CF34")]
	[Token(Token = "0x60022B0")]
	private void method_30()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B1 RID: 8881 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CF94", Offset = "0x2A7CF94", VA = "0x2A7CF94")]
	[Token(Token = "0x60022B1")]
	private void method_31()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B2 RID: 8882 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7CFF4", Offset = "0x2A7CFF4", VA = "0x2A7CFF4")]
	[Token(Token = "0x60022B2")]
	private void method_32()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B3 RID: 8883 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D054", Offset = "0x2A7D054", VA = "0x2A7D054")]
	[Token(Token = "0x60022B3")]
	private void method_33()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B4 RID: 8884 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D0B4", Offset = "0x2A7D0B4", VA = "0x2A7D0B4")]
	[Token(Token = "0x60022B4")]
	private void method_34()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B5 RID: 8885 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D114", Offset = "0x2A7D114", VA = "0x2A7D114")]
	[Token(Token = "0x60022B5")]
	private void method_35()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B6 RID: 8886 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D174", Offset = "0x2A7D174", VA = "0x2A7D174")]
	[Token(Token = "0x60022B6")]
	private void method_36()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B7 RID: 8887 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D1D4", Offset = "0x2A7D1D4", VA = "0x2A7D1D4")]
	[Token(Token = "0x60022B7")]
	private void method_37()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B8 RID: 8888 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D234", Offset = "0x2A7D234", VA = "0x2A7D234")]
	[Token(Token = "0x60022B8")]
	private void method_38()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022B9 RID: 8889 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D294", Offset = "0x2A7D294", VA = "0x2A7D294")]
	[Token(Token = "0x60022B9")]
	private void method_39()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022BA RID: 8890 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D2F4", Offset = "0x2A7D2F4", VA = "0x2A7D2F4")]
	[Token(Token = "0x60022BA")]
	private void method_40()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022BB RID: 8891 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D354", Offset = "0x2A7D354", VA = "0x2A7D354")]
	[Token(Token = "0x60022BB")]
	private void method_41()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022BC RID: 8892 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D3B4", Offset = "0x2A7D3B4", VA = "0x2A7D3B4")]
	[Token(Token = "0x60022BC")]
	private void method_42()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x060022BD RID: 8893 RVA: 0x0003F4BC File Offset: 0x0003D6BC
	[Address(RVA = "0x2A7D414", Offset = "0x2A7D414", VA = "0x2A7D414")]
	[Token(Token = "0x60022BD")]
	private void Update()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x04000480 RID: 1152
	[Token(Token = "0x4000480")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x04000481 RID: 1153
	[Token(Token = "0x4000481")]
	[FieldOffset(Offset = "0x20")]
	public Vector3 vector3_0;
}
