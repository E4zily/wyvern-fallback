﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000EC RID: 236
[Token(Token = "0x20000EC")]
public class SizeChecker : MonoBehaviour
{
	// Token: 0x06002354 RID: 9044 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B92F8C", Offset = "0x2B92F8C", VA = "0x2B92F8C")]
	[Token(Token = "0x6002354")]
	private void method_0()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002355 RID: 9045 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93010", Offset = "0x2B93010", VA = "0x2B93010")]
	[Token(Token = "0x6002355")]
	private void method_1()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002356 RID: 9046 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B9306C", Offset = "0x2B9306C", VA = "0x2B9306C")]
	[Token(Token = "0x6002356")]
	public void method_2()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002357 RID: 9047 RVA: 0x00042BAC File Offset: 0x00040DAC
	[Address(RVA = "0x2B93094", Offset = "0x2B93094", VA = "0x2B93094")]
	[Token(Token = "0x6002357")]
	private void method_3()
	{
		Vector3 localScale = base.transform.localScale;
		Transform transform;
		Vector3 localScale2 = transform.localScale;
	}

	// Token: 0x06002358 RID: 9048 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93118", Offset = "0x2B93118", VA = "0x2B93118")]
	[Token(Token = "0x6002358")]
	private void method_4()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002359 RID: 9049 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93174", Offset = "0x2B93174", VA = "0x2B93174")]
	[Token(Token = "0x6002359")]
	private void method_5()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600235A RID: 9050 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B931D0", Offset = "0x2B931D0", VA = "0x2B931D0")]
	[Token(Token = "0x600235A")]
	private void method_6()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600235B RID: 9051 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B9322C", Offset = "0x2B9322C", VA = "0x2B9322C")]
	[Token(Token = "0x600235B")]
	private void method_7()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600235C RID: 9052 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B932B0", Offset = "0x2B932B0", VA = "0x2B932B0")]
	[Token(Token = "0x600235C")]
	public void method_8()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600235D RID: 9053 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B932D8", Offset = "0x2B932D8", VA = "0x2B932D8")]
	[Token(Token = "0x600235D")]
	public void method_9()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600235E RID: 9054 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93300", Offset = "0x2B93300", VA = "0x2B93300")]
	[Token(Token = "0x600235E")]
	public void method_10()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600235F RID: 9055 RVA: 0x00042BAC File Offset: 0x00040DAC
	[Address(RVA = "0x2B93328", Offset = "0x2B93328", VA = "0x2B93328")]
	[Token(Token = "0x600235F")]
	private void method_11()
	{
		Vector3 localScale = base.transform.localScale;
		Transform transform;
		Vector3 localScale2 = transform.localScale;
	}

	// Token: 0x06002360 RID: 9056 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B933AC", Offset = "0x2B933AC", VA = "0x2B933AC")]
	[Token(Token = "0x6002360")]
	public void method_12()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002361 RID: 9057 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B933D4", Offset = "0x2B933D4", VA = "0x2B933D4")]
	[Token(Token = "0x6002361")]
	public void method_13()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002362 RID: 9058 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B933FC", Offset = "0x2B933FC", VA = "0x2B933FC")]
	[Token(Token = "0x6002362")]
	private void method_14()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002363 RID: 9059 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93458", Offset = "0x2B93458", VA = "0x2B93458")]
	[Token(Token = "0x6002363")]
	private void method_15()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002364 RID: 9060 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B934B4", Offset = "0x2B934B4", VA = "0x2B934B4")]
	[Token(Token = "0x6002364")]
	public void method_16()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002365 RID: 9061 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B934DC", Offset = "0x2B934DC", VA = "0x2B934DC")]
	[Token(Token = "0x6002365")]
	private void method_17()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002366 RID: 9062 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93538", Offset = "0x2B93538", VA = "0x2B93538")]
	[Token(Token = "0x6002366")]
	private void method_18()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002367 RID: 9063 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93594", Offset = "0x2B93594", VA = "0x2B93594")]
	[Token(Token = "0x6002367")]
	public void method_19()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002368 RID: 9064 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B935BC", Offset = "0x2B935BC", VA = "0x2B935BC")]
	[Token(Token = "0x6002368")]
	public void method_20()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002369 RID: 9065 RVA: 0x00042BAC File Offset: 0x00040DAC
	[Address(RVA = "0x2B935E4", Offset = "0x2B935E4", VA = "0x2B935E4")]
	[Token(Token = "0x6002369")]
	private void method_21()
	{
		Vector3 localScale = base.transform.localScale;
		Transform transform;
		Vector3 localScale2 = transform.localScale;
	}

	// Token: 0x0600236A RID: 9066 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93668", Offset = "0x2B93668", VA = "0x2B93668")]
	[Token(Token = "0x600236A")]
	private void method_22()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600236B RID: 9067 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B936C4", Offset = "0x2B936C4", VA = "0x2B936C4")]
	[Token(Token = "0x600236B")]
	public void method_23()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600236C RID: 9068 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B936EC", Offset = "0x2B936EC", VA = "0x2B936EC")]
	[Token(Token = "0x600236C")]
	public void method_24()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600236D RID: 9069 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93714", Offset = "0x2B93714", VA = "0x2B93714")]
	[Token(Token = "0x600236D")]
	private void method_25()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600236E RID: 9070 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93770", Offset = "0x2B93770", VA = "0x2B93770")]
	[Token(Token = "0x600236E")]
	public void method_26()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600236F RID: 9071 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93798", Offset = "0x2B93798", VA = "0x2B93798")]
	[Token(Token = "0x600236F")]
	public void method_27()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002370 RID: 9072 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B937C0", Offset = "0x2B937C0", VA = "0x2B937C0")]
	[Token(Token = "0x6002370")]
	public void method_28()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002371 RID: 9073 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B937E8", Offset = "0x2B937E8", VA = "0x2B937E8")]
	[Token(Token = "0x6002371")]
	private void method_29()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002372 RID: 9074 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B9386C", Offset = "0x2B9386C", VA = "0x2B9386C")]
	[Token(Token = "0x6002372")]
	private void method_30()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002373 RID: 9075 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B938C8", Offset = "0x2B938C8", VA = "0x2B938C8")]
	[Token(Token = "0x6002373")]
	private void method_31()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002374 RID: 9076 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B9394C", Offset = "0x2B9394C", VA = "0x2B9394C")]
	[Token(Token = "0x6002374")]
	public void method_32()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002375 RID: 9077 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B93974", Offset = "0x2B93974", VA = "0x2B93974")]
	[Token(Token = "0x6002375")]
	private void method_33()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002376 RID: 9078 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B939F8", Offset = "0x2B939F8", VA = "0x2B939F8")]
	[Token(Token = "0x6002376")]
	private void method_34()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002377 RID: 9079 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	[Address(RVA = "0x2B93A54", Offset = "0x2B93A54", VA = "0x2B93A54")]
	[Token(Token = "0x6002377")]
	private void method_35()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002378 RID: 9080 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B93AB0", Offset = "0x2B93AB0", VA = "0x2B93AB0")]
	[Token(Token = "0x6002378")]
	private void method_36()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002379 RID: 9081 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93B30", Offset = "0x2B93B30", VA = "0x2B93B30")]
	[Token(Token = "0x6002379")]
	public void method_37()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600237A RID: 9082 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93B58", Offset = "0x2B93B58", VA = "0x2B93B58")]
	[Token(Token = "0x600237A")]
	private void method_38()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600237B RID: 9083 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B93BB4", Offset = "0x2B93BB4", VA = "0x2B93BB4")]
	[Token(Token = "0x600237B")]
	private void method_39()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600237C RID: 9084 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93C38", Offset = "0x2B93C38", VA = "0x2B93C38")]
	[Token(Token = "0x600237C")]
	public void method_40()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600237D RID: 9085 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B93C60", Offset = "0x2B93C60", VA = "0x2B93C60")]
	[Token(Token = "0x600237D")]
	private void method_41()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600237E RID: 9086 RVA: 0x00042BCC File Offset: 0x00040DCC
	[Address(RVA = "0x2B93CE4", Offset = "0x2B93CE4", VA = "0x2B93CE4")]
	[Token(Token = "0x600237E")]
	public void method_42()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600237F RID: 9087 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B93D0C", Offset = "0x2B93D0C", VA = "0x2B93D0C")]
	[Token(Token = "0x600237F")]
	private void method_43()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002380 RID: 9088 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93D90", Offset = "0x2B93D90", VA = "0x2B93D90")]
	[Token(Token = "0x6002380")]
	public void method_44()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002381 RID: 9089 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B93DB8", Offset = "0x2B93DB8", VA = "0x2B93DB8")]
	[Token(Token = "0x6002381")]
	private void method_45()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002382 RID: 9090 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B93E3C", Offset = "0x2B93E3C", VA = "0x2B93E3C")]
	[Token(Token = "0x6002382")]
	private void method_46()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002383 RID: 9091 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93E98", Offset = "0x2B93E98", VA = "0x2B93E98")]
	[Token(Token = "0x6002383")]
	public void method_47()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002384 RID: 9092 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93EC0", Offset = "0x2B93EC0", VA = "0x2B93EC0")]
	[Token(Token = "0x6002384")]
	public void method_48()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002385 RID: 9093 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93EE8", Offset = "0x2B93EE8", VA = "0x2B93EE8")]
	[Token(Token = "0x6002385")]
	public void method_49()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002386 RID: 9094 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93F10", Offset = "0x2B93F10", VA = "0x2B93F10")]
	[Token(Token = "0x6002386")]
	public void method_50()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002387 RID: 9095 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93F38", Offset = "0x2B93F38", VA = "0x2B93F38")]
	[Token(Token = "0x6002387")]
	public void method_51()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002388 RID: 9096 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93F60", Offset = "0x2B93F60", VA = "0x2B93F60")]
	[Token(Token = "0x6002388")]
	public void method_52()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002389 RID: 9097 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B93F88", Offset = "0x2B93F88", VA = "0x2B93F88")]
	[Token(Token = "0x6002389")]
	public void method_53()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600238A RID: 9098 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B93FB0", Offset = "0x2B93FB0", VA = "0x2B93FB0")]
	[Token(Token = "0x600238A")]
	private void method_54()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600238B RID: 9099 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B94034", Offset = "0x2B94034", VA = "0x2B94034")]
	[Token(Token = "0x600238B")]
	private void method_55()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600238C RID: 9100 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94090", Offset = "0x2B94090", VA = "0x2B94090")]
	[Token(Token = "0x600238C")]
	public void method_56()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600238D RID: 9101 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B940B8", Offset = "0x2B940B8", VA = "0x2B940B8")]
	[Token(Token = "0x600238D")]
	public void method_57()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600238E RID: 9102 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B940E0", Offset = "0x2B940E0", VA = "0x2B940E0")]
	[Token(Token = "0x600238E")]
	public void method_58()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600238F RID: 9103 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94108", Offset = "0x2B94108", VA = "0x2B94108")]
	[Token(Token = "0x600238F")]
	private void method_59()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002390 RID: 9104 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B9418C", Offset = "0x2B9418C", VA = "0x2B9418C")]
	[Token(Token = "0x6002390")]
	public void method_60()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x06002391 RID: 9105 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B941B4", Offset = "0x2B941B4", VA = "0x2B941B4")]
	[Token(Token = "0x6002391")]
	private void method_61()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002392 RID: 9106 RVA: 0x00042BE0 File Offset: 0x00040DE0
	[Address(RVA = "0x2B94210", Offset = "0x2B94210", VA = "0x2B94210")]
	[Token(Token = "0x6002392")]
	private void method_62()
	{
		Physics.gravity = base.transform.localScale;
		Vector3 localScale = base.transform.localScale;
	}

	// Token: 0x06002393 RID: 9107 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B94294", Offset = "0x2B94294", VA = "0x2B94294")]
	[Token(Token = "0x6002393")]
	private void method_63()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002394 RID: 9108 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B942F0", Offset = "0x2B942F0", VA = "0x2B942F0")]
	[Token(Token = "0x6002394")]
	private void method_64()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002395 RID: 9109 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B9434C", Offset = "0x2B9434C", VA = "0x2B9434C")]
	[Token(Token = "0x6002395")]
	private void method_65()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002396 RID: 9110 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B943D0", Offset = "0x2B943D0", VA = "0x2B943D0")]
	[Token(Token = "0x6002396")]
	private void method_66()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x06002397 RID: 9111 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B9442C", Offset = "0x2B9442C", VA = "0x2B9442C")]
	[Token(Token = "0x6002397")]
	private void method_67()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002398 RID: 9112 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B944B0", Offset = "0x2B944B0", VA = "0x2B944B0")]
	[Token(Token = "0x6002398")]
	private void method_68()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x06002399 RID: 9113 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94534", Offset = "0x2B94534", VA = "0x2B94534")]
	[Token(Token = "0x6002399")]
	private void method_69()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600239A RID: 9114 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B945B8", Offset = "0x2B945B8", VA = "0x2B945B8")]
	[Token(Token = "0x600239A")]
	private void method_70()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600239B RID: 9115 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B94614", Offset = "0x2B94614", VA = "0x2B94614")]
	[Token(Token = "0x600239B")]
	private void method_71()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x0600239C RID: 9116 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94670", Offset = "0x2B94670", VA = "0x2B94670")]
	[Token(Token = "0x600239C")]
	private void method_72()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600239D RID: 9117 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B946F4", Offset = "0x2B946F4", VA = "0x2B946F4")]
	[Token(Token = "0x600239D")]
	public void Start()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x0600239E RID: 9118 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B9471C", Offset = "0x2B9471C", VA = "0x2B9471C")]
	[Token(Token = "0x600239E")]
	private void method_73()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x0600239F RID: 9119 RVA: 0x00042C0C File Offset: 0x00040E0C
	[Address(RVA = "0x2B947A0", Offset = "0x2B947A0", VA = "0x2B947A0")]
	[Token(Token = "0x600239F")]
	private void Update()
	{
		Vector3 localScale = base.transform.localScale;
		Transform transform;
		Vector3 localScale2 = transform.localScale;
	}

	// Token: 0x060023A0 RID: 9120 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B9481C", Offset = "0x2B9481C", VA = "0x2B9481C")]
	[Token(Token = "0x60023A0")]
	private void method_74()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x060023A1 RID: 9121 RVA: 0x00042BE0 File Offset: 0x00040DE0
	[Address(RVA = "0x2B94878", Offset = "0x2B94878", VA = "0x2B94878")]
	[Token(Token = "0x60023A1")]
	private void method_75()
	{
		Physics.gravity = base.transform.localScale;
		Vector3 localScale = base.transform.localScale;
	}

	// Token: 0x060023A2 RID: 9122 RVA: 0x00042BE0 File Offset: 0x00040DE0
	[Address(RVA = "0x2B948FC", Offset = "0x2B948FC", VA = "0x2B948FC")]
	[Token(Token = "0x60023A2")]
	private void method_76()
	{
		Physics.gravity = base.transform.localScale;
		Vector3 localScale = base.transform.localScale;
	}

	// Token: 0x060023A3 RID: 9123 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94980", Offset = "0x2B94980", VA = "0x2B94980")]
	[Token(Token = "0x60023A3")]
	public void method_77()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023A4 RID: 9124 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B949A8", Offset = "0x2B949A8", VA = "0x2B949A8")]
	[Token(Token = "0x60023A4")]
	private void method_78()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x060023A5 RID: 9125 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94A04", Offset = "0x2B94A04", VA = "0x2B94A04")]
	[Token(Token = "0x60023A5")]
	public void method_79()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023A6 RID: 9126 RVA: 0x00042BE0 File Offset: 0x00040DE0
	[Address(RVA = "0x2B94A2C", Offset = "0x2B94A2C", VA = "0x2B94A2C")]
	[Token(Token = "0x60023A6")]
	private void method_80()
	{
		Physics.gravity = base.transform.localScale;
		Vector3 localScale = base.transform.localScale;
	}

	// Token: 0x060023A7 RID: 9127 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B94AAC", Offset = "0x2B94AAC", VA = "0x2B94AAC")]
	[Token(Token = "0x60023A7")]
	private void method_81()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x060023A8 RID: 9128 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B94B08", Offset = "0x2B94B08", VA = "0x2B94B08")]
	[Token(Token = "0x60023A8")]
	private void method_82()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x060023A9 RID: 9129 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94B64", Offset = "0x2B94B64", VA = "0x2B94B64")]
	[Token(Token = "0x60023A9")]
	private void method_83()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023AA RID: 9130 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94BE8", Offset = "0x2B94BE8", VA = "0x2B94BE8")]
	[Token(Token = "0x60023AA")]
	public void method_84()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023AB RID: 9131 RVA: 0x00042C2C File Offset: 0x00040E2C
	[Address(RVA = "0x2B94C10", Offset = "0x2B94C10", VA = "0x2B94C10")]
	[Token(Token = "0x60023AB")]
	public SizeChecker()
	{
		long num = 1065353216L;
		this.float_0 = (float)num;
		base..ctor();
	}

	// Token: 0x060023AC RID: 9132 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94C20", Offset = "0x2B94C20", VA = "0x2B94C20")]
	[Token(Token = "0x60023AC")]
	private void method_85()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023AD RID: 9133 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94CA4", Offset = "0x2B94CA4", VA = "0x2B94CA4")]
	[Token(Token = "0x60023AD")]
	public void method_86()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023AE RID: 9134 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94CCC", Offset = "0x2B94CCC", VA = "0x2B94CCC")]
	[Token(Token = "0x60023AE")]
	private void method_87()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023AF RID: 9135 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94D50", Offset = "0x2B94D50", VA = "0x2B94D50")]
	[Token(Token = "0x60023AF")]
	public void method_88()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023B0 RID: 9136 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94D78", Offset = "0x2B94D78", VA = "0x2B94D78")]
	[Token(Token = "0x60023B0")]
	public void method_89()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023B1 RID: 9137 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94DA0", Offset = "0x2B94DA0", VA = "0x2B94DA0")]
	[Token(Token = "0x60023B1")]
	public void method_90()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023B2 RID: 9138 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B94DC8", Offset = "0x2B94DC8", VA = "0x2B94DC8")]
	[Token(Token = "0x60023B2")]
	public void method_91()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023B3 RID: 9139 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94DF0", Offset = "0x2B94DF0", VA = "0x2B94DF0")]
	[Token(Token = "0x60023B3")]
	private void method_92()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023B4 RID: 9140 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B94E74", Offset = "0x2B94E74", VA = "0x2B94E74")]
	[Token(Token = "0x60023B4")]
	private void LateUpdate()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x060023B5 RID: 9141 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B94ED0", Offset = "0x2B94ED0", VA = "0x2B94ED0")]
	[Token(Token = "0x60023B5")]
	private void method_93()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x060023B6 RID: 9142 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94F2C", Offset = "0x2B94F2C", VA = "0x2B94F2C")]
	[Token(Token = "0x60023B6")]
	private void method_94()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023B7 RID: 9143 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B94FB0", Offset = "0x2B94FB0", VA = "0x2B94FB0")]
	[Token(Token = "0x60023B7")]
	private void method_95()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023B8 RID: 9144 RVA: 0x00042B98 File Offset: 0x00040D98
	[Address(RVA = "0x2B95034", Offset = "0x2B95034", VA = "0x2B95034")]
	[Token(Token = "0x60023B8")]
	public void method_96()
	{
		float defaultContactOffset = Physics.defaultContactOffset;
	}

	// Token: 0x060023B9 RID: 9145 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B9505C", Offset = "0x2B9505C", VA = "0x2B9505C")]
	[Token(Token = "0x60023B9")]
	private void method_97()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x060023BA RID: 9146 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B950B8", Offset = "0x2B950B8", VA = "0x2B950B8")]
	[Token(Token = "0x60023BA")]
	private void method_98()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023BB RID: 9147 RVA: 0x00042B50 File Offset: 0x00040D50
	[Address(RVA = "0x2B9513C", Offset = "0x2B9513C", VA = "0x2B9513C")]
	[Token(Token = "0x60023BB")]
	private void method_99()
	{
		Vector3 localScale = base.transform.localScale;
		Vector3 localScale2 = base.transform.localScale;
	}

	// Token: 0x060023BC RID: 9148 RVA: 0x00042C0C File Offset: 0x00040E0C
	[Address(RVA = "0x2B951C0", Offset = "0x2B951C0", VA = "0x2B951C0")]
	[Token(Token = "0x60023BC")]
	private void method_100()
	{
		Vector3 localScale = base.transform.localScale;
		Transform transform;
		Vector3 localScale2 = transform.localScale;
	}

	// Token: 0x060023BD RID: 9149 RVA: 0x00042B78 File Offset: 0x00040D78
	[Address(RVA = "0x2B95244", Offset = "0x2B95244", VA = "0x2B95244")]
	[Token(Token = "0x60023BD")]
	private void method_101()
	{
		Transform transform = base.gameObject.transform;
		Vector3 one = Vector3.one;
	}

	// Token: 0x040004B5 RID: 1205
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004B5")]
	public float float_0;

	// Token: 0x040004B6 RID: 1206
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004B6")]
	public Camera camera_0;

	// Token: 0x040004B7 RID: 1207
	[Token(Token = "0x40004B7")]
	[FieldOffset(Offset = "0x28")]
	private float float_1;
}
