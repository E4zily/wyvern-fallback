﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000B9 RID: 185
[Token(Token = "0x20000B9")]
public class DeathyBlock : MonoBehaviour
{
	// Token: 0x06001A68 RID: 6760 RVA: 0x00034554 File Offset: 0x00032754
	[Address(RVA = "0x2A060D0", Offset = "0x2A060D0", VA = "0x2A060D0")]
	[Token(Token = "0x6001A68")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "Login has failed, therefore we block deez cosmetics... deez cosmetics? more like deez nuts :trol:";
		Application.Quit();
	}

	// Token: 0x06001A69 RID: 6761 RVA: 0x0003457C File Offset: 0x0003277C
	[Address(RVA = "0x2A0622C", Offset = "0x2A0622C", VA = "0x2A0622C")]
	[Token(Token = "0x6001A69")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Tint";
		Application.Quit();
	}

	// Token: 0x06001A6A RID: 6762 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A06388", Offset = "0x2A06388", VA = "0x2A06388")]
	[Token(Token = "0x6001A6A")]
	public void method_2()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A6B RID: 6763 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A063A4", Offset = "0x2A063A4", VA = "0x2A063A4")]
	[Token(Token = "0x6001A6B")]
	public void method_3()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A6C RID: 6764 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A063C0", Offset = "0x2A063C0", VA = "0x2A063C0")]
	[Token(Token = "0x6001A6C")]
	public void method_4()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A6D RID: 6765 RVA: 0x000345A4 File Offset: 0x000327A4
	[Address(RVA = "0x2A063DC", Offset = "0x2A063DC", VA = "0x2A063DC")]
	[Token(Token = "0x6001A6D")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "This is the 5000 Bananas button, and it was just clicked";
		Application.Quit();
	}

	// Token: 0x06001A6E RID: 6766 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A06538", Offset = "0x2A06538", VA = "0x2A06538")]
	[Token(Token = "0x6001A6E")]
	public void method_6()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A6F RID: 6767 RVA: 0x00002826 File Offset: 0x00000A26
	[PunRPC]
	[Address(RVA = "0x2A06554", Offset = "0x2A06554", VA = "0x2A06554")]
	[Token(Token = "0x6001A6F")]
	public void deathScream()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A70 RID: 6768 RVA: 0x000345CC File Offset: 0x000327CC
	[Address(RVA = "0x2A06570", Offset = "0x2A06570", VA = "0x2A06570")]
	[Token(Token = "0x6001A70")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "PLAYER IS BANNED";
		Application.Quit();
	}

	// Token: 0x06001A71 RID: 6769 RVA: 0x000345F4 File Offset: 0x000327F4
	[Address(RVA = "0x2A066CC", Offset = "0x2A066CC", VA = "0x2A066CC")]
	[Token(Token = "0x6001A71")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		Application.Quit();
	}

	// Token: 0x06001A72 RID: 6770 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A06828", Offset = "0x2A06828", VA = "0x2A06828")]
	[Token(Token = "0x6001A72")]
	public void method_9()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A73 RID: 6771 RVA: 0x0003461C File Offset: 0x0003281C
	[Address(RVA = "0x2A06844", Offset = "0x2A06844", VA = "0x2A06844")]
	[Token(Token = "0x6001A73")]
	public void OnTriggerEnter(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "Player";
		Application.Quit();
	}

	// Token: 0x06001A74 RID: 6772 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A069A0", Offset = "0x2A069A0", VA = "0x2A069A0")]
	[Token(Token = "0x6001A74")]
	public void method_10()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A75 RID: 6773 RVA: 0x00034640 File Offset: 0x00032840
	[Address(RVA = "0x2A069BC", Offset = "0x2A069BC", VA = "0x2A069BC")]
	[Token(Token = "0x6001A75")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "Not enough amount of currency";
		Application.Quit();
	}

	// Token: 0x06001A76 RID: 6774 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A06B18", Offset = "0x2A06B18", VA = "0x2A06B18")]
	[Token(Token = "0x6001A76")]
	public void method_12()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A77 RID: 6775 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A06B34", Offset = "0x2A06B34", VA = "0x2A06B34")]
	[Token(Token = "0x6001A77")]
	public void method_13()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A78 RID: 6776 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A06B50", Offset = "0x2A06B50", VA = "0x2A06B50")]
	[Token(Token = "0x6001A78")]
	public void method_14()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A79 RID: 6777 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A06B6C", Offset = "0x2A06B6C", VA = "0x2A06B6C")]
	[Token(Token = "0x6001A79")]
	public void method_15()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A7A RID: 6778 RVA: 0x00034668 File Offset: 0x00032868
	[Address(RVA = "0x2A06B88", Offset = "0x2A06B88", VA = "0x2A06B88")]
	[Token(Token = "0x6001A7A")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "isLava";
		Application.Quit();
	}

	// Token: 0x06001A7B RID: 6779 RVA: 0x00034690 File Offset: 0x00032890
	[Address(RVA = "0x2A06CE4", Offset = "0x2A06CE4", VA = "0x2A06CE4")]
	[Token(Token = "0x6001A7B")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Application.Quit();
	}

	// Token: 0x06001A7C RID: 6780 RVA: 0x000346B8 File Offset: 0x000328B8
	[Address(RVA = "0x2A06E40", Offset = "0x2A06E40", VA = "0x2A06E40")]
	[Token(Token = "0x6001A7C")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		Application.Quit();
	}

	// Token: 0x06001A7D RID: 6781 RVA: 0x000346E0 File Offset: 0x000328E0
	[Address(RVA = "0x2A06F9C", Offset = "0x2A06F9C", VA = "0x2A06F9C")]
	[Token(Token = "0x6001A7D")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "procedural animation script required on ";
		Application.Quit();
	}

	// Token: 0x06001A7E RID: 6782 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A070F8", Offset = "0x2A070F8", VA = "0x2A070F8")]
	[Token(Token = "0x6001A7E")]
	public void method_20()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A7F RID: 6783 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A07114", Offset = "0x2A07114", VA = "0x2A07114")]
	[Token(Token = "0x6001A7F")]
	public void method_21()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A80 RID: 6784 RVA: 0x00034708 File Offset: 0x00032908
	[Address(RVA = "0x2A07130", Offset = "0x2A07130", VA = "0x2A07130")]
	[Token(Token = "0x6001A80")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "All audio clips have been played.";
		Application.Quit();
	}

	// Token: 0x06001A81 RID: 6785 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A0728C", Offset = "0x2A0728C", VA = "0x2A0728C")]
	[Token(Token = "0x6001A81")]
	public void method_23()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A82 RID: 6786 RVA: 0x0003457C File Offset: 0x0003277C
	[Address(RVA = "0x2A072A8", Offset = "0x2A072A8", VA = "0x2A072A8")]
	[Token(Token = "0x6001A82")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Tint";
		Application.Quit();
	}

	// Token: 0x06001A83 RID: 6787 RVA: 0x00034730 File Offset: 0x00032930
	[Address(RVA = "0x2A07404", Offset = "0x2A07404", VA = "0x2A07404")]
	[Token(Token = "0x6001A83")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "Trigger";
		Application.Quit();
	}

	// Token: 0x06001A84 RID: 6788 RVA: 0x00034758 File Offset: 0x00032958
	[Address(RVA = "0x2A07560", Offset = "0x2A07560", VA = "0x2A07560")]
	[Token(Token = "0x6001A84")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "Connected to Server.";
		Application.Quit();
	}

	// Token: 0x06001A85 RID: 6789 RVA: 0x00034780 File Offset: 0x00032980
	[Address(RVA = "0x2A076BC", Offset = "0x2A076BC", VA = "0x2A076BC")]
	[Token(Token = "0x6001A85")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "cheese";
		Application.Quit();
	}

	// Token: 0x06001A86 RID: 6790 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A07818", Offset = "0x2A07818", VA = "0x2A07818")]
	[Token(Token = "0x6001A86")]
	public void method_28()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A87 RID: 6791 RVA: 0x000347A8 File Offset: 0x000329A8
	[Address(RVA = "0x2A07834", Offset = "0x2A07834", VA = "0x2A07834")]
	[Token(Token = "0x6001A87")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == " hour. You were banned because of ";
		Application.Quit();
	}

	// Token: 0x06001A88 RID: 6792 RVA: 0x000347D0 File Offset: 0x000329D0
	[Address(RVA = "0x2A07990", Offset = "0x2A07990", VA = "0x2A07990")]
	[Token(Token = "0x6001A88")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == "HandL";
		Application.Quit();
	}

	// Token: 0x06001A89 RID: 6793 RVA: 0x000345F4 File Offset: 0x000327F4
	[Address(RVA = "0x2A07AEC", Offset = "0x2A07AEC", VA = "0x2A07AEC")]
	[Token(Token = "0x6001A89")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		Application.Quit();
	}

	// Token: 0x06001A8A RID: 6794 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A07C48", Offset = "0x2A07C48", VA = "0x2A07C48")]
	[Token(Token = "0x6001A8A")]
	public void method_32()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A8B RID: 6795 RVA: 0x000347F8 File Offset: 0x000329F8
	[Address(RVA = "0x2A07C64", Offset = "0x2A07C64", VA = "0x2A07C64")]
	[Token(Token = "0x6001A8B")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == "betaAgree";
		Application.Quit();
	}

	// Token: 0x06001A8C RID: 6796 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A07DC0", Offset = "0x2A07DC0", VA = "0x2A07DC0")]
	[Token(Token = "0x6001A8C")]
	public void method_34()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A8D RID: 6797 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A07DDC", Offset = "0x2A07DDC", VA = "0x2A07DDC")]
	[Token(Token = "0x6001A8D")]
	public void method_35()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A8E RID: 6798 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2A07DF8", Offset = "0x2A07DF8", VA = "0x2A07DF8")]
	[Token(Token = "0x6001A8E")]
	public DeathyBlock()
	{
	}

	// Token: 0x06001A8F RID: 6799 RVA: 0x00002826 File Offset: 0x00000A26
	[Address(RVA = "0x2A07E00", Offset = "0x2A07E00", VA = "0x2A07E00")]
	[Token(Token = "0x6001A8F")]
	public void method_36()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06001A90 RID: 6800 RVA: 0x00034820 File Offset: 0x00032A20
	[Address(RVA = "0x2A07E1C", Offset = "0x2A07E1C", VA = "0x2A07E1C")]
	[Token(Token = "0x6001A90")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "containsStaff";
		Application.Quit();
	}

	// Token: 0x0400036D RID: 877
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400036D")]
	public PhotonView photonView_0;

	// Token: 0x0400036E RID: 878
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400036E")]
	public AudioSource audioSource_0;
}
