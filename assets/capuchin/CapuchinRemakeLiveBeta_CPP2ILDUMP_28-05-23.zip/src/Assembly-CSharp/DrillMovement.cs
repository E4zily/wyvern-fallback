﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200005C RID: 92
[Token(Token = "0x200005C")]
public class DrillMovement : MonoBehaviour
{
	// Token: 0x06000CD1 RID: 3281 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Token(Token = "0x6000CD1")]
	[Address(RVA = "0x2EAB3C8", Offset = "0x2EAB3C8", VA = "0x2EAB3C8")]
	private void method_0()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CD2 RID: 3282 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000CD2")]
	[Address(RVA = "0x2EAB400", Offset = "0x2EAB400", VA = "0x2EAB400")]
	public DrillMovement()
	{
	}

	// Token: 0x06000CD3 RID: 3283 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Address(RVA = "0x2EAB408", Offset = "0x2EAB408", VA = "0x2EAB408")]
	[Token(Token = "0x6000CD3")]
	private void method_1()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CD4 RID: 3284 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Token(Token = "0x6000CD4")]
	[Address(RVA = "0x2EAB440", Offset = "0x2EAB440", VA = "0x2EAB440")]
	private void method_2()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CD5 RID: 3285 RVA: 0x0001BE20 File Offset: 0x0001A020
	[Address(RVA = "0x2EAB478", Offset = "0x2EAB478", VA = "0x2EAB478")]
	[Token(Token = "0x6000CD5")]
	private void method_3()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		this.float_8 = (float)17189;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CD6 RID: 3286 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Token(Token = "0x6000CD6")]
	[Address(RVA = "0x2EAB67C", Offset = "0x2EAB67C", VA = "0x2EAB67C")]
	private void Start()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CD7 RID: 3287 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Address(RVA = "0x2EAB6B4", Offset = "0x2EAB6B4", VA = "0x2EAB6B4")]
	[Token(Token = "0x6000CD7")]
	private void method_4()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CD8 RID: 3288 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Token(Token = "0x6000CD8")]
	[Address(RVA = "0x2EAB6EC", Offset = "0x2EAB6EC", VA = "0x2EAB6EC")]
	private void method_5()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CD9 RID: 3289 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Token(Token = "0x6000CD9")]
	[Address(RVA = "0x2EAB724", Offset = "0x2EAB724", VA = "0x2EAB724")]
	private void method_6()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CDA RID: 3290 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Address(RVA = "0x2EAB75C", Offset = "0x2EAB75C", VA = "0x2EAB75C")]
	[Token(Token = "0x6000CDA")]
	private void method_7()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CDB RID: 3291 RVA: 0x0001BEB4 File Offset: 0x0001A0B4
	[Address(RVA = "0x2EAB794", Offset = "0x2EAB794", VA = "0x2EAB794")]
	[Token(Token = "0x6000CDB")]
	private void method_8()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		this.float_8 = (float)17370;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CDC RID: 3292 RVA: 0x0001BF48 File Offset: 0x0001A148
	[Token(Token = "0x6000CDC")]
	[Address(RVA = "0x2EAB998", Offset = "0x2EAB998", VA = "0x2EAB998")]
	private void method_9()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		this.float_8 = (float)24576;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CDD RID: 3293 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Token(Token = "0x6000CDD")]
	[Address(RVA = "0x2EABBA0", Offset = "0x2EABBA0", VA = "0x2EABBA0")]
	private void method_10()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x06000CDE RID: 3294 RVA: 0x0001BFDC File Offset: 0x0001A1DC
	[Address(RVA = "0x2EABBD8", Offset = "0x2EABBD8", VA = "0x2EABBD8")]
	[Token(Token = "0x6000CDE")]
	private void Update()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CDF RID: 3295 RVA: 0x0001C064 File Offset: 0x0001A264
	[Token(Token = "0x6000CDF")]
	[Address(RVA = "0x2EABDD4", Offset = "0x2EABDD4", VA = "0x2EABDD4")]
	private void method_11()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		this.float_8 = (float)24576;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CE0 RID: 3296 RVA: 0x0001C0F8 File Offset: 0x0001A2F8
	[Address(RVA = "0x2EABFDC", Offset = "0x2EABFDC", VA = "0x2EABFDC")]
	[Token(Token = "0x6000CE0")]
	private void method_12()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		this.float_8 = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CE1 RID: 3297 RVA: 0x0001C0F8 File Offset: 0x0001A2F8
	[Token(Token = "0x6000CE1")]
	[Address(RVA = "0x2EAC1E4", Offset = "0x2EAC1E4", VA = "0x2EAC1E4")]
	private void method_13()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		this.float_8 = (float)32768;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CE2 RID: 3298 RVA: 0x0001C18C File Offset: 0x0001A38C
	[Token(Token = "0x6000CE2")]
	[Address(RVA = "0x2EAC3EC", Offset = "0x2EAC3EC", VA = "0x2EAC3EC")]
	private void method_14()
	{
		float num = this.float_4;
		float num2 = this.float_2;
		float deltaTime = Time.deltaTime;
		this.float_2 = num2;
		float deltaTime2 = Time.deltaTime;
		this.float_4 = num;
		float deltaTime3 = Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_2.position;
		float deltaTime4 = Time.deltaTime;
		Mathf.Clamp01(deltaTime4);
		float num3 = this.float_2;
		this.float_2 = num3;
		this.float_8 = (float)49152;
		float deltaTime5 = Time.deltaTime;
		this.float_8 = num3;
	}

	// Token: 0x06000CE3 RID: 3299 RVA: 0x0001BE04 File Offset: 0x0001A004
	[Token(Token = "0x6000CE3")]
	[Address(RVA = "0x2EAC5F4", Offset = "0x2EAC5F4", VA = "0x2EAC5F4")]
	private void method_15()
	{
		Vector3 position = this.transform_2.position;
	}

	// Token: 0x040001D8 RID: 472
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40001D8")]
	public float float_0;

	// Token: 0x040001D9 RID: 473
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40001D9")]
	public float float_1;

	// Token: 0x040001DA RID: 474
	[Token(Token = "0x40001DA")]
	[FieldOffset(Offset = "0x20")]
	public float float_2;

	// Token: 0x040001DB RID: 475
	[Token(Token = "0x40001DB")]
	[FieldOffset(Offset = "0x28")]
	public Transform transform_0;

	// Token: 0x040001DC RID: 476
	[Token(Token = "0x40001DC")]
	[FieldOffset(Offset = "0x30")]
	public Transform transform_1;

	// Token: 0x040001DD RID: 477
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40001DD")]
	public Transform transform_2;

	// Token: 0x040001DE RID: 478
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40001DE")]
	public Vector3 vector3_0;

	// Token: 0x040001DF RID: 479
	[Token(Token = "0x40001DF")]
	[FieldOffset(Offset = "0x4C")]
	public Vector3 vector3_1;

	// Token: 0x040001E0 RID: 480
	[Token(Token = "0x40001E0")]
	[FieldOffset(Offset = "0x58")]
	public Vector3 vector3_2;

	// Token: 0x040001E1 RID: 481
	[Token(Token = "0x40001E1")]
	[FieldOffset(Offset = "0x64")]
	public float float_3;

	// Token: 0x040001E2 RID: 482
	[Token(Token = "0x40001E2")]
	[FieldOffset(Offset = "0x68")]
	private float float_4;

	// Token: 0x040001E3 RID: 483
	[Token(Token = "0x40001E3")]
	[FieldOffset(Offset = "0x6C")]
	public float float_5;

	// Token: 0x040001E4 RID: 484
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40001E4")]
	public float float_6;

	// Token: 0x040001E5 RID: 485
	[FieldOffset(Offset = "0x74")]
	[Token(Token = "0x40001E5")]
	public bool bool_0;

	// Token: 0x040001E6 RID: 486
	[Token(Token = "0x40001E6")]
	[FieldOffset(Offset = "0x78")]
	public float float_7;

	// Token: 0x040001E7 RID: 487
	[Token(Token = "0x40001E7")]
	[FieldOffset(Offset = "0x7C")]
	private float float_8;

	// Token: 0x040001E8 RID: 488
	[Token(Token = "0x40001E8")]
	[FieldOffset(Offset = "0x80")]
	private Vector3 vector3_3;
}
