﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000CD RID: 205
[Token(Token = "0x20000CD")]
public class Head : MonoBehaviour
{
	// Token: 0x06001D67 RID: 7527 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3637DF8", Offset = "0x3637DF8", VA = "0x3637DF8")]
	[Token(Token = "0x6001D67")]
	private void method_0()
	{
	}

	// Token: 0x06001D68 RID: 7528 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x3637DFC", Offset = "0x3637DFC", VA = "0x3637DFC")]
	[Token(Token = "0x6001D68")]
	private void method_1()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D69 RID: 7529 RVA: 0x000380D0 File Offset: 0x000362D0
	[Address(RVA = "0x3637F28", Offset = "0x3637F28", VA = "0x3637F28")]
	[Token(Token = "0x6001D69")]
	private void method_2()
	{
		Vector3 position = base.transform.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform = this.transform_0;
		Vector3 position3 = transform.position;
		Transform transform2 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D6A RID: 7530 RVA: 0x00038130 File Offset: 0x00036330
	[Address(RVA = "0x3638054", Offset = "0x3638054", VA = "0x3638054")]
	[Token(Token = "0x6001D6A")]
	private void method_3()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position2 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D6B RID: 7531 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3638180", Offset = "0x3638180", VA = "0x3638180")]
	[Token(Token = "0x6001D6B")]
	private void Start()
	{
	}

	// Token: 0x06001D6C RID: 7532 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x3638184", Offset = "0x3638184", VA = "0x3638184")]
	[Token(Token = "0x6001D6C")]
	private void method_4()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D6D RID: 7533 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x36382B0", Offset = "0x36382B0", VA = "0x36382B0")]
	[Token(Token = "0x6001D6D")]
	private void method_5()
	{
	}

	// Token: 0x06001D6E RID: 7534 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x36382B4", Offset = "0x36382B4", VA = "0x36382B4")]
	[Token(Token = "0x6001D6E")]
	private void method_6()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D6F RID: 7535 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x36383E0", Offset = "0x36383E0", VA = "0x36383E0")]
	[Token(Token = "0x6001D6F")]
	public Head()
	{
	}

	// Token: 0x06001D70 RID: 7536 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x36383E8", Offset = "0x36383E8", VA = "0x36383E8")]
	[Token(Token = "0x6001D70")]
	private void method_7()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D71 RID: 7537 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x3638514", Offset = "0x3638514", VA = "0x3638514")]
	[Token(Token = "0x6001D71")]
	private void method_8()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D72 RID: 7538 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x3638640", Offset = "0x3638640", VA = "0x3638640")]
	[Token(Token = "0x6001D72")]
	private void Update()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D73 RID: 7539 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x3638768", Offset = "0x3638768", VA = "0x3638768")]
	[Token(Token = "0x6001D73")]
	private void method_9()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D74 RID: 7540 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3638894", Offset = "0x3638894", VA = "0x3638894")]
	[Token(Token = "0x6001D74")]
	private void method_10()
	{
	}

	// Token: 0x06001D75 RID: 7541 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3638898", Offset = "0x3638898", VA = "0x3638898")]
	[Token(Token = "0x6001D75")]
	private void method_11()
	{
	}

	// Token: 0x06001D76 RID: 7542 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x363889C", Offset = "0x363889C", VA = "0x363889C")]
	[Token(Token = "0x6001D76")]
	private void method_12()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D77 RID: 7543 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x36389C8", Offset = "0x36389C8", VA = "0x36389C8")]
	[Token(Token = "0x6001D77")]
	private void method_13()
	{
	}

	// Token: 0x06001D78 RID: 7544 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x36389CC", Offset = "0x36389CC", VA = "0x36389CC")]
	[Token(Token = "0x6001D78")]
	private void method_14()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D79 RID: 7545 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3638AF8", Offset = "0x3638AF8", VA = "0x3638AF8")]
	[Token(Token = "0x6001D79")]
	private void method_15()
	{
	}

	// Token: 0x06001D7A RID: 7546 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x3638AFC", Offset = "0x3638AFC", VA = "0x3638AFC")]
	[Token(Token = "0x6001D7A")]
	private void method_16()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D7B RID: 7547 RVA: 0x0003818C File Offset: 0x0003638C
	[Address(RVA = "0x3638C28", Offset = "0x3638C28", VA = "0x3638C28")]
	[Token(Token = "0x6001D7B")]
	private void method_17()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Transform transform4;
		Quaternion rotation3 = transform4.rotation;
	}

	// Token: 0x06001D7C RID: 7548 RVA: 0x00038130 File Offset: 0x00036330
	[Address(RVA = "0x3638D54", Offset = "0x3638D54", VA = "0x3638D54")]
	[Token(Token = "0x6001D7C")]
	private void method_18()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position2 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D7D RID: 7549 RVA: 0x00038068 File Offset: 0x00036268
	[Address(RVA = "0x3638E80", Offset = "0x3638E80", VA = "0x3638E80")]
	[Token(Token = "0x6001D7D")]
	private void method_19()
	{
		Transform transform = base.transform;
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_0.position;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Transform transform3 = base.transform;
		Quaternion rotation = base.transform.rotation;
		Quaternion rotation2 = this.transform_0.rotation;
		Quaternion rotation3 = base.transform.rotation;
	}

	// Token: 0x06001D7E RID: 7550 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3638FAC", Offset = "0x3638FAC", VA = "0x3638FAC")]
	[Token(Token = "0x6001D7E")]
	private void method_20()
	{
	}

	// Token: 0x06001D7F RID: 7551 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x3638FB0", Offset = "0x3638FB0", VA = "0x3638FB0")]
	[Token(Token = "0x6001D7F")]
	private void method_21()
	{
	}

	// Token: 0x040003F3 RID: 1011
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003F3")]
	public Transform transform_0;

	// Token: 0x040003F4 RID: 1012
	[Token(Token = "0x40003F4")]
	[FieldOffset(Offset = "0x20")]
	public float float_0;
}
