﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200009E RID: 158
[Token(Token = "0x200009E")]
public class RadarNetwork : MonoBehaviour
{
	// Token: 0x06001775 RID: 6005 RVA: 0x00030078 File Offset: 0x0002E278
	[Address(RVA = "0x3480098", Offset = "0x3480098", VA = "0x3480098")]
	[Token(Token = "0x6001775")]
	private void method_0()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001776 RID: 6006 RVA: 0x00030078 File Offset: 0x0002E278
	[Token(Token = "0x6001776")]
	[Address(RVA = "0x34800D4", Offset = "0x34800D4", VA = "0x34800D4")]
	private void Update()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001777 RID: 6007 RVA: 0x00030078 File Offset: 0x0002E278
	[Token(Token = "0x6001777")]
	[Address(RVA = "0x3480110", Offset = "0x3480110", VA = "0x3480110")]
	private void method_1()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001778 RID: 6008 RVA: 0x00030078 File Offset: 0x0002E278
	[Address(RVA = "0x348014C", Offset = "0x348014C", VA = "0x348014C")]
	[Token(Token = "0x6001778")]
	private void method_2()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001779 RID: 6009 RVA: 0x000300A8 File Offset: 0x0002E2A8
	[Token(Token = "0x6001779")]
	[Address(RVA = "0x3480188", Offset = "0x3480188", VA = "0x3480188")]
	private void method_3()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600177A RID: 6010 RVA: 0x000300A8 File Offset: 0x0002E2A8
	[Address(RVA = "0x34801B4", Offset = "0x34801B4", VA = "0x34801B4")]
	[Token(Token = "0x600177A")]
	private void method_4()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600177B RID: 6011 RVA: 0x00030078 File Offset: 0x0002E278
	[Token(Token = "0x600177B")]
	[Address(RVA = "0x34801E0", Offset = "0x34801E0", VA = "0x34801E0")]
	private void method_5()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600177C RID: 6012 RVA: 0x000300C8 File Offset: 0x0002E2C8
	[Address(RVA = "0x348021C", Offset = "0x348021C", VA = "0x348021C")]
	[Token(Token = "0x600177C")]
	private void method_6()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600177D RID: 6013 RVA: 0x00030078 File Offset: 0x0002E278
	[Address(RVA = "0x3480248", Offset = "0x3480248", VA = "0x3480248")]
	[Token(Token = "0x600177D")]
	private void method_7()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600177E RID: 6014 RVA: 0x000300A8 File Offset: 0x0002E2A8
	[Address(RVA = "0x3480284", Offset = "0x3480284", VA = "0x3480284")]
	[Token(Token = "0x600177E")]
	private void method_8()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x0600177F RID: 6015 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x34802B0", Offset = "0x34802B0", VA = "0x34802B0")]
	[Token(Token = "0x600177F")]
	public RadarNetwork()
	{
	}

	// Token: 0x06001780 RID: 6016 RVA: 0x00030078 File Offset: 0x0002E278
	[Token(Token = "0x6001780")]
	[Address(RVA = "0x34802B8", Offset = "0x34802B8", VA = "0x34802B8")]
	private void method_9()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001781 RID: 6017 RVA: 0x00030078 File Offset: 0x0002E278
	[Token(Token = "0x6001781")]
	[Address(RVA = "0x34802F4", Offset = "0x34802F4", VA = "0x34802F4")]
	private void method_10()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001782 RID: 6018 RVA: 0x000300C8 File Offset: 0x0002E2C8
	[Address(RVA = "0x3480330", Offset = "0x3480330", VA = "0x3480330")]
	[Token(Token = "0x6001782")]
	private void method_11()
	{
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001783 RID: 6019 RVA: 0x000300E8 File Offset: 0x0002E2E8
	[Address(RVA = "0x348035C", Offset = "0x348035C", VA = "0x348035C")]
	[Token(Token = "0x6001783")]
	private void method_12()
	{
		PhotonView photonView = this.photonView_0;
		GameObject gameObject = this.gameObject_0;
		if (photonView.<IsMine>k__BackingField)
		{
			return;
		}
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x04000305 RID: 773
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000305")]
	public GameObject gameObject_0;

	// Token: 0x04000306 RID: 774
	[Token(Token = "0x4000306")]
	[FieldOffset(Offset = "0x20")]
	public PhotonView photonView_0;
}
