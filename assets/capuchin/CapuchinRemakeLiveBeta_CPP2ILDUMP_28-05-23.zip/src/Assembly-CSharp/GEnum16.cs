﻿using System;
using Cpp2IlInjected;

// Token: 0x0200015F RID: 351
[Token(Token = "0x200015F")]
public enum GEnum16
{
	// Token: 0x04000948 RID: 2376
	[Token(Token = "0x4000948")]
	const_0,
	// Token: 0x04000949 RID: 2377
	[Token(Token = "0x4000949")]
	const_1,
	// Token: 0x0400094A RID: 2378
	[Token(Token = "0x400094A")]
	const_2,
	// Token: 0x0400094B RID: 2379
	[Token(Token = "0x400094B")]
	const_3,
	// Token: 0x0400094C RID: 2380
	[Token(Token = "0x400094C")]
	const_4
}
