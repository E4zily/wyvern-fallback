﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200002A RID: 42
[Token(Token = "0x200002A")]
public class FanRotate : MonoBehaviour
{
	// Token: 0x0600051C RID: 1308 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DA6FC", Offset = "0x10DA6FC", VA = "0x10DA6FC")]
	[Token(Token = "0x600051C")]
	private void Update()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DA764", Offset = "0x10DA764", VA = "0x10DA764")]
	[Token(Token = "0x600051D")]
	private void method_0()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x600051E")]
	[Address(RVA = "0x10DA7CC", Offset = "0x10DA7CC", VA = "0x10DA7CC")]
	private void method_1()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x600051F")]
	[Address(RVA = "0x10DA834", Offset = "0x10DA834", VA = "0x10DA834")]
	private void method_2()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DA89C", Offset = "0x10DA89C", VA = "0x10DA89C")]
	[Token(Token = "0x6000520")]
	private void method_3()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x10DA904", Offset = "0x10DA904", VA = "0x10DA904")]
	[Token(Token = "0x6000521")]
	public FanRotate()
	{
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DA90C", Offset = "0x10DA90C", VA = "0x10DA90C")]
	[Token(Token = "0x6000522")]
	private void method_4()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x6000523")]
	[Address(RVA = "0x10DA974", Offset = "0x10DA974", VA = "0x10DA974")]
	private void method_5()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x0000ED18 File Offset: 0x0000CF18
	[Token(Token = "0x6000524")]
	[Address(RVA = "0x10DA9DC", Offset = "0x10DA9DC", VA = "0x10DA9DC")]
	private void method_6()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DAA44", Offset = "0x10DAA44", VA = "0x10DAA44")]
	[Token(Token = "0x6000525")]
	private void method_7()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DAAAC", Offset = "0x10DAAAC", VA = "0x10DAAAC")]
	[Token(Token = "0x6000526")]
	private void method_8()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x6000527")]
	[Address(RVA = "0x10DAB14", Offset = "0x10DAB14", VA = "0x10DAB14")]
	private void method_9()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DAB7C", Offset = "0x10DAB7C", VA = "0x10DAB7C")]
	[Token(Token = "0x6000528")]
	private void method_10()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x6000529")]
	[Address(RVA = "0x10DABE4", Offset = "0x10DABE4", VA = "0x10DABE4")]
	private void method_11()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052A RID: 1322 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DAC4C", Offset = "0x10DAC4C", VA = "0x10DAC4C")]
	[Token(Token = "0x600052A")]
	private void method_12()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x600052B")]
	[Address(RVA = "0x10DACB4", Offset = "0x10DACB4", VA = "0x10DACB4")]
	private void method_13()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x600052C")]
	[Address(RVA = "0x10DAD1C", Offset = "0x10DAD1C", VA = "0x10DAD1C")]
	private void method_14()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052D RID: 1325 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x600052D")]
	[Address(RVA = "0x10DAD84", Offset = "0x10DAD84", VA = "0x10DAD84")]
	private void method_15()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052E RID: 1326 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x600052E")]
	[Address(RVA = "0x10DADEC", Offset = "0x10DADEC", VA = "0x10DADEC")]
	private void method_16()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x0000ED34 File Offset: 0x0000CF34
	[Token(Token = "0x600052F")]
	[Address(RVA = "0x10DAE54", Offset = "0x10DAE54", VA = "0x10DAE54")]
	private void method_17()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x0000ED34 File Offset: 0x0000CF34
	[Address(RVA = "0x10DAEBC", Offset = "0x10DAEBC", VA = "0x10DAEBC")]
	[Token(Token = "0x6000530")]
	private void method_18()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DAF24", Offset = "0x10DAF24", VA = "0x10DAF24")]
	[Token(Token = "0x6000531")]
	private void method_19()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Token(Token = "0x6000532")]
	[Address(RVA = "0x10DAF8C", Offset = "0x10DAF8C", VA = "0x10DAF8C")]
	private void method_20()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	[Address(RVA = "0x10DAFF4", Offset = "0x10DAFF4", VA = "0x10DAFF4")]
	[Token(Token = "0x6000533")]
	private void method_21()
	{
		Transform transform = base.transform;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x040000C8 RID: 200
	[Token(Token = "0x40000C8")]
	[FieldOffset(Offset = "0x18")]
	public Vector3 vector3_0;
}
