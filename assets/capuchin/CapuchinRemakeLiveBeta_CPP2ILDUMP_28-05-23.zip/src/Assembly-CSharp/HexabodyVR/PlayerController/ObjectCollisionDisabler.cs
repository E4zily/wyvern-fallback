﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x0200016E RID: 366
	[Token(Token = "0x200016E")]
	public class ObjectCollisionDisabler : MonoBehaviour
	{
		// Token: 0x060038B2 RID: 14514 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2D556F0", Offset = "0x2D556F0", VA = "0x2D556F0")]
		[Token(Token = "0x60038B2")]
		private void method_0()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060038B3 RID: 14515 RVA: 0x00071918 File Offset: 0x0006FB18
		[Address(RVA = "0x2D56098", Offset = "0x2D56098", VA = "0x2D56098")]
		[Token(Token = "0x60038B3")]
		private void method_1()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038B4 RID: 14516 RVA: 0x00071988 File Offset: 0x0006FB88
		[Address(RVA = "0x2D56A78", Offset = "0x2D56A78", VA = "0x2D56A78")]
		[Token(Token = "0x60038B4")]
		private void method_2()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038B5 RID: 14517 RVA: 0x00071988 File Offset: 0x0006FB88
		[Address(RVA = "0x2D5745C", Offset = "0x2D5745C", VA = "0x2D5745C")]
		[Token(Token = "0x60038B5")]
		private void method_3()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038B6 RID: 14518 RVA: 0x000719F8 File Offset: 0x0006FBF8
		[Address(RVA = "0x2D57E70", Offset = "0x2D57E70", VA = "0x2D57E70")]
		[Token(Token = "0x60038B6")]
		private void method_4()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			int num;
			if (ObjectCollisionDisabler.<>c.<>9__3_1 != null || num != 0)
			{
			}
		}

		// Token: 0x060038B7 RID: 14519 RVA: 0x00071A60 File Offset: 0x0006FC60
		[Address(RVA = "0x2D58888", Offset = "0x2D58888", VA = "0x2D58888")]
		[Token(Token = "0x60038B7")]
		private void method_5()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038B8 RID: 14520 RVA: 0x00071AD0 File Offset: 0x0006FCD0
		[Address(RVA = "0x2D592A0", Offset = "0x2D592A0", VA = "0x2D592A0")]
		[Token(Token = "0x60038B8")]
		private void method_6()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038B9 RID: 14521 RVA: 0x00071B40 File Offset: 0x0006FD40
		[Address(RVA = "0x2D59CB4", Offset = "0x2D59CB4", VA = "0x2D59CB4")]
		[Token(Token = "0x60038B9")]
		private void method_7()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038BA RID: 14522 RVA: 0x00071BB0 File Offset: 0x0006FDB0
		[Address(RVA = "0x2D5A698", Offset = "0x2D5A698", VA = "0x2D5A698")]
		[Token(Token = "0x60038BA")]
		public ObjectCollisionDisabler()
		{
			List<Transform> list = new List();
			this.list_0 = list;
			base..ctor();
		}

		// Token: 0x060038BB RID: 14523 RVA: 0x00071BD0 File Offset: 0x0006FDD0
		[Address(RVA = "0x2D5A71C", Offset = "0x2D5A71C", VA = "0x2D5A71C")]
		[Token(Token = "0x60038BB")]
		private void method_8()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			Func<Transform, bool> <>9__2;
			if (<>9__2 != null)
			{
			}
		}

		// Token: 0x060038BC RID: 14524 RVA: 0x00071C24 File Offset: 0x0006FE24
		[Address(RVA = "0x2D5B0FC", Offset = "0x2D5B0FC", VA = "0x2D5B0FC")]
		[Token(Token = "0x60038BC")]
		private void method_9()
		{
			List<Transform>.Enumerator enumerator = this.list_0.GetEnumerator();
			enumerator.MoveNext();
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038BD RID: 14525 RVA: 0x00071C8C File Offset: 0x0006FE8C
		[Address(RVA = "0x2D5BAE0", Offset = "0x2D5BAE0", VA = "0x2D5BAE0")]
		[Token(Token = "0x60038BD")]
		private void method_10()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038BE RID: 14526 RVA: 0x00071988 File Offset: 0x0006FB88
		[Address(RVA = "0x2D5C488", Offset = "0x2D5C488", VA = "0x2D5C488")]
		[Token(Token = "0x60038BE")]
		private void method_11()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038BF RID: 14527 RVA: 0x00071CFC File Offset: 0x0006FEFC
		[Address(RVA = "0x2D5CE64", Offset = "0x2D5CE64", VA = "0x2D5CE64")]
		[Token(Token = "0x60038BF")]
		private void method_12()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C0 RID: 14528 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2D5D844", Offset = "0x2D5D844", VA = "0x2D5D844")]
		[Token(Token = "0x60038C0")]
		private void method_13()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060038C1 RID: 14529 RVA: 0x00071D6C File Offset: 0x0006FF6C
		[Address(RVA = "0x2D5E224", Offset = "0x2D5E224", VA = "0x2D5E224")]
		[Token(Token = "0x60038C1")]
		private void method_14()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C2 RID: 14530 RVA: 0x00071DD8 File Offset: 0x0006FFD8
		[Address(RVA = "0x2D5EC00", Offset = "0x2D5EC00", VA = "0x2D5EC00")]
		[Token(Token = "0x60038C2")]
		private void method_15()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C3 RID: 14531 RVA: 0x00071E48 File Offset: 0x00070048
		[Address(RVA = "0x2D5F5A8", Offset = "0x2D5F5A8", VA = "0x2D5F5A8")]
		[Token(Token = "0x60038C3")]
		private void method_16()
		{
			bool flag = this.list_0.GetEnumerator().MoveNext();
			bool flag2;
			ObjectCollisionDisabler.<>c <>;
			if (flag2 = this.bool_0)
			{
				if (flag2)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					<> = ObjectCollisionDisabler.<>c.<>9;
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				if (<> == null)
				{
					Func<Transform, bool> value;
					flag.m_value = (value != null);
				}
				return;
			}
			bool flag3;
			if (flag3)
			{
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C4 RID: 14532 RVA: 0x00071EB4 File Offset: 0x000700B4
		[Address(RVA = "0x2D5FF50", Offset = "0x2D5FF50", VA = "0x2D5FF50")]
		[Token(Token = "0x60038C4")]
		private void method_17()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C5 RID: 14533 RVA: 0x00071A60 File Offset: 0x0006FC60
		[Address(RVA = "0x2D608F8", Offset = "0x2D608F8", VA = "0x2D608F8")]
		[Token(Token = "0x60038C5")]
		private void method_18()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C6 RID: 14534 RVA: 0x00071988 File Offset: 0x0006FB88
		[Address(RVA = "0x2D61310", Offset = "0x2D61310", VA = "0x2D61310")]
		[Token(Token = "0x60038C6")]
		private void method_19()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C7 RID: 14535 RVA: 0x00071F24 File Offset: 0x00070124
		[Address(RVA = "0x2D61CEC", Offset = "0x2D61CEC", VA = "0x2D61CEC")]
		[Token(Token = "0x60038C7")]
		private void method_20()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (!this.bool_1)
			{
				if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
				{
					int num;
					if (num != 0)
					{
					}
					Func<Collider, bool> <>9__3_2;
					ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
				}
				return;
			}
			Func<Transform, bool> <>9__2;
			if (<>9__2 == null)
			{
				return;
			}
		}

		// Token: 0x060038C8 RID: 14536 RVA: 0x00071F94 File Offset: 0x00070194
		[Token(Token = "0x60038C8")]
		[Address(RVA = "0x2D626CC", Offset = "0x2D626CC", VA = "0x2D626CC")]
		private void method_21()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038C9 RID: 14537 RVA: 0x00072004 File Offset: 0x00070204
		[Address(RVA = "0x2D630B0", Offset = "0x2D630B0", VA = "0x2D630B0")]
		[Token(Token = "0x60038C9")]
		private void method_22()
		{
			this.list_0.GetEnumerator().MoveNext();
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038CA RID: 14538 RVA: 0x00071C8C File Offset: 0x0006FE8C
		[Address(RVA = "0x2D63A58", Offset = "0x2D63A58", VA = "0x2D63A58")]
		[Token(Token = "0x60038CA")]
		private void method_23()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038CB RID: 14539 RVA: 0x00071C8C File Offset: 0x0006FE8C
		[Address(RVA = "0x2D64400", Offset = "0x2D64400", VA = "0x2D64400")]
		[Token(Token = "0x60038CB")]
		private void method_24()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038CC RID: 14540 RVA: 0x00072068 File Offset: 0x00070268
		[Address(RVA = "0x2D64DA8", Offset = "0x2D64DA8", VA = "0x2D64DA8")]
		[Token(Token = "0x60038CC")]
		private void method_25()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				Func<Collider, bool> <>9__3_ = ObjectCollisionDisabler.<>c.<>9__3_0;
				if (<>9__3_ == null)
				{
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038CD RID: 14541 RVA: 0x000720DC File Offset: 0x000702DC
		[Address(RVA = "0x2D65784", Offset = "0x2D65784", VA = "0x2D65784")]
		[Token(Token = "0x60038CD")]
		private void method_26()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038CE RID: 14542 RVA: 0x0007214C File Offset: 0x0007034C
		[Token(Token = "0x60038CE")]
		[Address(RVA = "0x2D6619C", Offset = "0x2D6619C", VA = "0x2D6619C")]
		private void method_27()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038CF RID: 14543 RVA: 0x000721BC File Offset: 0x000703BC
		[Address(RVA = "0x2D66B44", Offset = "0x2D66B44", VA = "0x2D66B44")]
		[Token(Token = "0x60038CF")]
		private void method_28()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				Func<Collider, bool> <>9__3_;
				ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038D0 RID: 14544 RVA: 0x00071988 File Offset: 0x0006FB88
		[Address(RVA = "0x2D67524", Offset = "0x2D67524", VA = "0x2D67524")]
		[Token(Token = "0x60038D0")]
		private void method_29()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038D1 RID: 14545 RVA: 0x00071CFC File Offset: 0x0006FEFC
		[Address(RVA = "0x2D67F00", Offset = "0x2D67F00", VA = "0x2D67F00")]
		[Token(Token = "0x60038D1")]
		private void method_30()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038D2 RID: 14546 RVA: 0x00072224 File Offset: 0x00070424
		[Address(RVA = "0x2D688E0", Offset = "0x2D688E0", VA = "0x2D688E0")]
		[Token(Token = "0x60038D2")]
		private void method_31()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				Func<Collider, bool> <>9__3_;
				ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			int num;
			if (num != 0)
			{
			}
			Func<Collider, bool> <>9__3_2;
			ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
		}

		// Token: 0x060038D3 RID: 14547 RVA: 0x00072284 File Offset: 0x00070484
		[Address(RVA = "0x2D692C0", Offset = "0x2D692C0", VA = "0x2D692C0")]
		[Token(Token = "0x60038D3")]
		private void method_32()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			Collider[] array;
			int num;
			if (array != null || num != 0)
			{
			}
		}

		// Token: 0x060038D4 RID: 14548 RVA: 0x000722DC File Offset: 0x000704DC
		[Token(Token = "0x60038D4")]
		[Address(RVA = "0x2D69CA0", Offset = "0x2D69CA0", VA = "0x2D69CA0")]
		private void Start()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038D5 RID: 14549 RVA: 0x0007234C File Offset: 0x0007054C
		[Address(RVA = "0x2D6A6B8", Offset = "0x2D6A6B8", VA = "0x2D6A6B8")]
		[Token(Token = "0x60038D5")]
		private void method_33()
		{
			List.Enumerator enumerator;
			enumerator.MoveNext();
			new ObjectCollisionDisabler.Class57();
			if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
			{
				Func<Collider, bool> <>9__3_;
				ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
			}
		}

		// Token: 0x060038D6 RID: 14550 RVA: 0x00072374 File Offset: 0x00070574
		[Address(RVA = "0x2D6B060", Offset = "0x2D6B060", VA = "0x2D6B060")]
		[Token(Token = "0x60038D6")]
		private void method_34()
		{
			List<Transform>.Enumerator enumerator = this.list_0.GetEnumerator();
			enumerator.MoveNext();
			new ObjectCollisionDisabler.Class57();
			bool flag;
			ObjectCollisionDisabler.<>c <>;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					<> = ObjectCollisionDisabler.<>c.<>9;
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				if (<> != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x060038D7 RID: 14551 RVA: 0x00071C8C File Offset: 0x0006FE8C
		[Token(Token = "0x60038D7")]
		[Address(RVA = "0x2D6BA3C", Offset = "0x2D6BA3C", VA = "0x2D6BA3C")]
		private void method_35()
		{
			this.list_0.GetEnumerator().MoveNext();
			long t2 = 0L;
			Transform t = t2;
			bool flag;
			if (flag = this.bool_0)
			{
				if (flag)
				{
				}
				if (ObjectCollisionDisabler.<>c.<>9__3_0 == null)
				{
					Func<Collider, bool> <>9__3_;
					ObjectCollisionDisabler.<>c.<>9__3_0 = <>9__3_;
				}
				return;
			}
			if (this.bool_1)
			{
				Func<Transform, bool> <>9__2;
				if (<>9__2 != null)
				{
				}
				return;
			}
			if (ObjectCollisionDisabler.<>c.<>9__3_1 == null)
			{
				int num;
				if (num != 0)
				{
				}
				Func<Collider, bool> <>9__3_2;
				ObjectCollisionDisabler.<>c.<>9__3_1 = <>9__3_2;
			}
		}

		// Token: 0x040009E4 RID: 2532
		[Token(Token = "0x40009E4")]
		[FieldOffset(Offset = "0x18")]
		public bool bool_0;

		// Token: 0x040009E5 RID: 2533
		[Token(Token = "0x40009E5")]
		[FieldOffset(Offset = "0x19")]
		public bool bool_1;

		// Token: 0x040009E6 RID: 2534
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40009E6")]
		public List<Transform> list_0;

		// Token: 0x0200016F RID: 367
		[CompilerGenerated]
		[Token(Token = "0x200016F")]
		private sealed class Class57
		{
			// Token: 0x060038D8 RID: 14552 RVA: 0x000020B4 File Offset: 0x000002B4
			[Address(RVA = "0x1075520", Offset = "0x1075520", VA = "0x1075520")]
			[Token(Token = "0x60038D8")]
			public Class57()
			{
			}

			// Token: 0x060038D9 RID: 14553 RVA: 0x000723E0 File Offset: 0x000705E0
			[Address(RVA = "0x1075528", Offset = "0x1075528", VA = "0x1075528")]
			[Token(Token = "0x60038D9")]
			internal bool method_0(Transform e)
			{
				Transform y = this.t;
				return e != y;
			}

			// Token: 0x040009E7 RID: 2535
			[Token(Token = "0x40009E7")]
			[FieldOffset(Offset = "0x10")]
			public Transform t;

			// Token: 0x040009E8 RID: 2536
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x40009E8")]
			public Func<Transform, bool> <>9__2;
		}
	}
}
