﻿using System;
using System.Collections;
using System.Linq;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000154 RID: 340
	[Token(Token = "0x2000154")]
	public class HexaBodyPlayer4 : MonoBehaviour
	{
		// Token: 0x060035F1 RID: 13809 RVA: 0x0006DAAC File Offset: 0x0006BCAC
		[Address(RVA = "0x32642A8", Offset = "0x32642A8", VA = "0x32642A8")]
		[Token(Token = "0x60035F1")]
		private void method_0()
		{
			long num = 1L;
			ConfigurableJoint exists = this.configurableJoint_3;
			if (num != 0L)
			{
			}
			exists;
			Rigidbody rigidbody = this.rigidbody_1;
			Transform transform = rigidbody.transform;
			Transform transform2 = this.transform_8;
			Vector3 position = transform2.position;
			ConfigurableJoint exists2 = this.configurableJoint_4;
			if (transform2 != null)
			{
			}
			exists2;
			Rigidbody rigidbody2 = this.rigidbody_1;
			Transform transform3 = rigidbody2.transform;
			Vector3 position2 = this.transform_9.position;
		}

		// Token: 0x060035F2 RID: 13810 RVA: 0x0006DB1C File Offset: 0x0006BD1C
		[Address(RVA = "0x32643F4", Offset = "0x32643F4", VA = "0x32643F4")]
		[Token(Token = "0x60035F2")]
		private void method_1()
		{
			this.method_11();
			bool flag = this.bool_2;
			this.bool_7 = flag;
		}

		// Token: 0x060035F3 RID: 13811 RVA: 0x0006DB40 File Offset: 0x0006BD40
		[Address(RVA = "0x32644F8", Offset = "0x32644F8", VA = "0x32644F8")]
		[Token(Token = "0x60035F3")]
		public void method_2(int int_2)
		{
		}

		// Token: 0x060035F4 RID: 13812 RVA: 0x0006DB50 File Offset: 0x0006BD50
		[Address(RVA = "0x3264554", Offset = "0x3264554", VA = "0x3264554")]
		[Token(Token = "0x60035F4")]
		public void method_3()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			Vector3 zero3 = Vector3.zero;
			Vector3 zero4 = Vector3.zero;
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060035F5 RID: 13813 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x170000CE")]
		public float Single_6
		{
			[Address(RVA = "0x3264664", Offset = "0x3264664", VA = "0x3264664")]
			[Token(Token = "0x60035F5")]
			get
			{
			}
		}

		// Token: 0x060035F6 RID: 13814 RVA: 0x0006DB78 File Offset: 0x0006BD78
		[Address(RVA = "0x326466C", Offset = "0x326466C", VA = "0x326466C", Slot = "4")]
		[Token(Token = "0x60035F6")]
		protected virtual Vector3 vmethod_0(Vector3 vector3_4, bool bool_17)
		{
			Vector3 forward = this.transform_17.forward;
			float time;
			this.animationCurve_4.Evaluate(time);
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			float radius = this.sphereCollider_0.radius;
			return 92;
		}

		// Token: 0x060035F7 RID: 13815 RVA: 0x0006DBBC File Offset: 0x0006BDBC
		[Address(RVA = "0x32647CC", Offset = "0x32647CC", VA = "0x32647CC", Slot = "5")]
		[Token(Token = "0x60035F7")]
		protected virtual void vmethod_1(bool bool_17)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x060035F8 RID: 13816 RVA: 0x0006DBF4 File Offset: 0x0006BDF4
		[Address(RVA = "0x3264870", Offset = "0x3264870", VA = "0x3264870")]
		[Token(Token = "0x60035F8")]
		private bool method_4()
		{
			Vector3 position = this.transform_1.transform.position;
			float magnitude = this.rigidbody_1.transform.position.magnitude;
			float x = this.quaternion_0.x;
			float y = this.quaternion_0.y;
			float z = this.quaternion_0.z;
			float fixedDeltaTime = Time.fixedDeltaTime;
			HexaCameraRig hexaCameraRig = this.hexaCameraRig_0;
			this.vector3_3.x = y;
			this.vector3_3.y = z;
			this.vector3_3.z = x;
			Vector3 localPosition = hexaCameraRig.transform.localPosition;
			Transform transform = this.rigidbody_1.transform;
			throw new NullReferenceException();
		}

		// Token: 0x060035F9 RID: 13817 RVA: 0x0006DCA0 File Offset: 0x0006BEA0
		[Address(RVA = "0x3264B14", Offset = "0x3264B14", VA = "0x3264B14")]
		[Token(Token = "0x60035F9")]
		private void method_5()
		{
			this.method_29();
			float num = this.float_42;
			long num2 = 1L;
			this.genum19_0 = (GEnum19)num2;
			this.float_45 = (float)52429;
			this.float_75 = num;
			this.float_3 = num;
			Vector3 gravity = Physics.gravity;
			Vector3 gravity2 = Physics.gravity;
			float fixedDeltaTime = Time.fixedDeltaTime;
			this.float_57 = num;
			this.float_1 = num;
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060035FA RID: 13818 RVA: 0x0006DCFC File Offset: 0x0006BEFC
		[Token(Token = "0x170000C7")]
		public Vector3 Vector3_2
		{
			[Address(RVA = "0x3264D08", Offset = "0x3264D08", VA = "0x3264D08")]
			[Token(Token = "0x60035FA")]
			get
			{
				Vector3 right = this.transform_17.right;
				Vector3 result;
				return result;
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x0600362E RID: 13870 RVA: 0x00003457 File Offset: 0x00001657
		// (set) Token: 0x060035FB RID: 13819 RVA: 0x000033FD File Offset: 0x000015FD
		[Token(Token = "0x170000D6")]
		protected GEnum20 GEnum20_0
		{
			[Address(RVA = "0x3267EBC", Offset = "0x3267EBC", VA = "0x3267EBC")]
			[Token(Token = "0x600362E")]
			get
			{
				return this._jumpStage;
			}
			[Address(RVA = "0x3264CA8", Offset = "0x3264CA8", VA = "0x3264CA8")]
			[Token(Token = "0x60035FB")]
			set
			{
				if (value == GEnum20.const_0 || this._jumpStage != GEnum20.const_0)
				{
				}
				this._jumpStage = value;
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060035FC RID: 13820 RVA: 0x0006DD18 File Offset: 0x0006BF18
		[Token(Token = "0x170000D2")]
		public float Single_7
		{
			[Address(RVA = "0x3264D24", Offset = "0x3264D24", VA = "0x3264D24")]
			[Token(Token = "0x60035FC")]
			get
			{
				float mass = this.rigidbody_2.mass;
				float mass2 = this.rigidbody_0.mass;
				throw new NullReferenceException();
			}
		}

		// Token: 0x060035FD RID: 13821 RVA: 0x0006DD44 File Offset: 0x0006BF44
		[Address(RVA = "0x3264D74", Offset = "0x3264D74", VA = "0x3264D74", Slot = "6")]
		[Token(Token = "0x60035FD")]
		protected virtual void vmethod_2()
		{
			long num = 1L;
			HexaHandsBase exists = this.hexaHandsBase_0;
			if (num != 0L)
			{
			}
			exists;
			HexaHandsBase[] componentsInChildren = base.transform.root.GetComponentsInChildren<HexaHandsBase>();
			Func<HexaHandsBase, bool> func;
			if (HexaBodyPlayer4.<>c.<>9__231_0 == null)
			{
				HexaBodyPlayer4.<>c.<>9__231_0 = func;
			}
			Enumerable.FirstOrDefault<HexaHandsBase>(componentsInChildren, func);
			this.hexaHandsBase_1;
		}

		// Token: 0x060035FE RID: 13822 RVA: 0x0006DD98 File Offset: 0x0006BF98
		[Address(RVA = "0x326508C", Offset = "0x326508C", VA = "0x326508C", Slot = "7")]
		[Token(Token = "0x60035FE")]
		protected virtual void vmethod_3(Vector3 vector3_4)
		{
			float deltaTime = Time.deltaTime;
			this.method_44(vector3_4);
		}

		// Token: 0x060035FF RID: 13823 RVA: 0x0006DDB4 File Offset: 0x0006BFB4
		[Address(RVA = "0x32651CC", Offset = "0x32651CC", VA = "0x32651CC", Slot = "8")]
		[Token(Token = "0x60035FF")]
		protected virtual bool vmethod_4()
		{
			Transform transform = this.transform_0;
			Vector3 localPosition = transform.transform.localPosition;
			Vector3 position = this.transform_1.transform.position;
			Vector3 position2 = this.rigidbody_1.transform.position;
			Vector3 position3 = this.hexaCameraRig_0.transform.position;
			if (this.bool_3)
			{
				if (!this.bool_4)
				{
				}
				this.method_31();
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003600 RID: 13824 RVA: 0x0006DE24 File Offset: 0x0006C024
		[Address(RVA = "0x32653C0", Offset = "0x32653C0", VA = "0x32653C0", Slot = "9")]
		[Token(Token = "0x6003600")]
		protected virtual void vmethod_5()
		{
			HexaBodyInputsBase hexaBodyInputsBase = this.hexaBodyInputsBase_0;
			if (hexaBodyInputsBase.playerInputState_0 == null && hexaBodyInputsBase.playerInputState_1 == null)
			{
				float num = this.float_81;
				float deltaTime = Time.deltaTime;
				float num2 = this.float_45;
				this.float_56 = num;
				this.float_56 = num2;
				return;
			}
			float num3 = this.float_81;
			this.float_56 = num3;
			if (!this.hexaBodyInputsBase_0.playerInputState_0.JustActivated)
			{
			}
			if (this.float_32 != null)
			{
				float float_;
				this.method_13(float_);
				return;
			}
		}

		// Token: 0x06003601 RID: 13825 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x32655DC", Offset = "0x32655DC", VA = "0x32655DC")]
		[Token(Token = "0x6003601")]
		protected void method_6()
		{
		}

		// Token: 0x06003602 RID: 13826 RVA: 0x0006DEA0 File Offset: 0x0006C0A0
		[Address(RVA = "0x32655E4", Offset = "0x32655E4", VA = "0x32655E4")]
		[Token(Token = "0x6003602")]
		private void method_7(float float_84)
		{
		}

		// Token: 0x06003603 RID: 13827 RVA: 0x00003411 File Offset: 0x00001611
		[Address(RVA = "0x326566C", Offset = "0x326566C", VA = "0x326566C")]
		[Token(Token = "0x6003603")]
		public void method_8(bool bool_17)
		{
			this.method_31();
		}

		// Token: 0x06003604 RID: 13828 RVA: 0x0006DBBC File Offset: 0x0006BDBC
		[Address(RVA = "0x3265688", Offset = "0x3265688", VA = "0x3265688", Slot = "10")]
		[Token(Token = "0x6003604")]
		protected virtual void vmethod_6(bool bool_17)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x06003605 RID: 13829 RVA: 0x0006DEB0 File Offset: 0x0006C0B0
		[Address(RVA = "0x326572C", Offset = "0x326572C", VA = "0x326572C", Slot = "11")]
		[Token(Token = "0x6003605")]
		protected virtual void vmethod_7()
		{
			float num = this.float_67;
			this._crouchAmount = num;
			float deltaTime = Time.deltaTime;
			Rigidbody rigidbody = this.rigidbody_1;
			this._jumpTimer = num;
			Vector3 velocity = rigidbody.velocity;
			float jumpTimer = this._jumpTimer;
			this.float_66 = jumpTimer;
			if (this._jumpStage != GEnum20.const_0)
			{
			}
			float crouchAmount = this._crouchAmount;
			this.float_67 = crouchAmount;
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x06003606 RID: 13830 RVA: 0x0006DF14 File Offset: 0x0006C114
		[Token(Token = "0x170000D4")]
		public float Single_9
		{
			[Address(RVA = "0x326581C", Offset = "0x326581C", VA = "0x326581C")]
			[Token(Token = "0x6003606")]
			get
			{
				float mass = this.rigidbody_1.mass;
				float mass2 = this.rigidbody_3.mass;
				float mass3 = this.rigidbody_4.mass;
				float mass4 = this.rigidbody_5.mass;
				throw new NullReferenceException();
			}
		}

		// Token: 0x06003607 RID: 13831 RVA: 0x0006DF58 File Offset: 0x0006C158
		[Address(RVA = "0x32658A4", Offset = "0x32658A4", VA = "0x32658A4")]
		[Token(Token = "0x6003607")]
		private void method_9()
		{
			if (this.bool_5)
			{
				this.method_29();
				float num = this.float_42;
				long num2 = 1L;
				this.bool_5 = (num2 != 0L);
				this.genum19_0 = (GEnum19)num2;
				this._jumpTimer = (float)16384;
				this.float_45 = (float)16384;
				this.float_75 = num;
				this.float_3 = num;
				Vector3 gravity = Physics.gravity;
				Vector3 gravity2 = Physics.gravity;
				float fixedDeltaTime = Time.fixedDeltaTime;
				this.float_57 = num;
				this.float_1 = num;
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06003608 RID: 13832 RVA: 0x0006DFD0 File Offset: 0x0006C1D0
		[Token(Token = "0x170000C6")]
		public Vector3 Vector3_1
		{
			[Address(RVA = "0x32647B0", Offset = "0x32647B0", VA = "0x32647B0")]
			[Token(Token = "0x6003608")]
			get
			{
				Vector3 forward = this.transform_17.forward;
				Vector3 result;
				return result;
			}
		}

		// Token: 0x06003609 RID: 13833 RVA: 0x0000E0CC File Offset: 0x0000C2CC
		[Address(RVA = "0x3265988", Offset = "0x3265988", VA = "0x3265988")]
		[Token(Token = "0x6003609")]
		public void method_10(float float_84)
		{
		}

		// Token: 0x0600360A RID: 13834 RVA: 0x0006DFEC File Offset: 0x0006C1EC
		[Address(RVA = "0x3265998", Offset = "0x3265998", VA = "0x3265998", Slot = "12")]
		[Token(Token = "0x600360A")]
		protected virtual void vmethod_8()
		{
			Transform transform = this.transform_6;
			Vector3 position = transform.position;
			Vector3 position2 = this.rigidbody_3.position;
			Vector3 position3 = this.transform_6.position;
			Rigidbody rigidbody = this.rigidbody_3;
			CapsuleCollider capsuleCollider = this.capsuleCollider_2;
			Vector3 position4 = rigidbody.position;
			Vector3 position5 = this.transform_6.position;
			float height;
			capsuleCollider.height = height;
			Vector3 position6 = this.transform_3.position;
			Vector3 up = this.transform_3.up;
			Transform transform2 = this.transform_3.transform;
			Quaternion rotation = this.transform_3.transform.rotation;
		}

		// Token: 0x0600360B RID: 13835 RVA: 0x0006E084 File Offset: 0x0006C284
		[Address(RVA = "0x326443C", Offset = "0x326443C", VA = "0x326443C")]
		[Token(Token = "0x600360B")]
		private void method_11()
		{
			GameObject gameObject = this.transform_12.gameObject;
			bool active = this.bool_2;
			gameObject.SetActive(active);
			GameObject gameObject2 = this.transform_11.gameObject;
			bool active2 = this.bool_2;
			gameObject2.SetActive(active2);
			GameObject gameObject3 = this.transform_10.gameObject;
			bool active3 = this.bool_2;
			gameObject3.SetActive(active3);
			GameObject gameObject4 = this.transform_13.gameObject;
			bool active4 = this.bool_2;
			gameObject4.SetActive(active4);
			GameObject gameObject5 = this.transform_14.gameObject;
			bool active5 = this.bool_2;
			gameObject5.SetActive(active5);
		}

		// Token: 0x0600360C RID: 13836 RVA: 0x0006E120 File Offset: 0x0006C320
		[Address(RVA = "0x3265B88", Offset = "0x3265B88", VA = "0x3265B88", Slot = "13")]
		[Token(Token = "0x600360C")]
		protected virtual void vmethod_9()
		{
			float radius = this.sphereCollider_0.radius;
			Vector3 position = this.rigidbody_0.position;
			Vector3 down = Vector3.down;
			float radius2 = this.sphereCollider_0.radius;
			Vector3 up = Vector3.up;
			float contactOffset = this.sphereCollider_0.contactOffset;
			Vector3 down2 = Vector3.down;
			LayerMask mask = this.layerMask_0;
			mask;
			Vector3 up2 = Vector3.up;
			Vector3 up3 = Vector3.up;
		}

		// Token: 0x0600360D RID: 13837 RVA: 0x0006E18C File Offset: 0x0006C38C
		[Address(RVA = "0x3265DA0", Offset = "0x3265DA0", VA = "0x3265DA0", Slot = "14")]
		[Token(Token = "0x600360D")]
		public virtual void vmethod_10()
		{
			if (!this.bool_12)
			{
				JointDrive yDrive = this.configurableJoint_0.yDrive;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x0600360E RID: 13838 RVA: 0x0003584C File Offset: 0x00033A4C
		// (set) Token: 0x0600365B RID: 13915 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000D5")]
		public float Single_10
		{
			[CompilerGenerated]
			[Address(RVA = "0x3265E4C", Offset = "0x3265E4C", VA = "0x3265E4C")]
			[Token(Token = "0x600360E")]
			get
			{
			}
			[Address(RVA = "0x3269DCC", Offset = "0x3269DCC", VA = "0x3269DCC")]
			[Token(Token = "0x600365B")]
			[CompilerGenerated]
			set
			{
			}
		}

		// Token: 0x0600360F RID: 13839 RVA: 0x0006E1B0 File Offset: 0x0006C3B0
		[Address(RVA = "0x3265E54", Offset = "0x3265E54", VA = "0x3265E54", Slot = "15")]
		[Token(Token = "0x600360F")]
		public virtual void vmethod_11()
		{
			Rigidbody rigidbody = this.rigidbody_1;
			Vector3 velocity = rigidbody.velocity;
			Rigidbody rigidbody2 = this.rigidbody_1;
			Rigidbody rigidbody3 = this.rigidbody_2;
			Vector3 velocity2 = rigidbody2.velocity;
			Vector3 velocity3 = rigidbody3.velocity;
		}

		// Token: 0x06003610 RID: 13840 RVA: 0x00003411 File Offset: 0x00001611
		[Address(RVA = "0x3265EDC", Offset = "0x3265EDC", VA = "0x3265EDC")]
		[Token(Token = "0x6003610")]
		public void method_12(bool bool_17)
		{
			this.method_31();
		}

		// Token: 0x06003611 RID: 13841 RVA: 0x0006E1EC File Offset: 0x0006C3EC
		[Address(RVA = "0x3265EFC", Offset = "0x3265EFC", VA = "0x3265EFC", Slot = "16")]
		[Token(Token = "0x6003611")]
		public virtual void vmethod_12()
		{
			if (!this.bool_11)
			{
				float mass = this.rigidbody_1.mass;
				float mass2 = this.rigidbody_3.mass;
				float mass3 = this.rigidbody_2.mass;
				float mass4 = this.rigidbody_0.mass;
				this.method_26();
				this.rigidbody_1.mass = mass4;
				this.rigidbody_3.mass = mass4;
				this.rigidbody_2.mass = mass4;
				this.rigidbody_0.mass = mass4;
				long num = 1L;
				this.bool_11 = (num != 0L);
			}
		}

		// Token: 0x06003612 RID: 13842 RVA: 0x0006E274 File Offset: 0x0006C474
		[Address(RVA = "0x3265518", Offset = "0x3265518", VA = "0x3265518")]
		[Token(Token = "0x6003612")]
		private float method_13(float float_84)
		{
			throw new NullReferenceException();
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x06003619 RID: 13849 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		// (set) Token: 0x06003613 RID: 13843 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000C3")]
		public Vector3 Vector3_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x3266BE4", Offset = "0x3266BE4", VA = "0x3266BE4")]
			[Token(Token = "0x6003619")]
			get
			{
				Vector3 result;
				return result;
			}
			[CompilerGenerated]
			[Address(RVA = "0x3266098", Offset = "0x3266098", VA = "0x3266098")]
			[Token(Token = "0x6003613")]
			private set
			{
			}
		}

		// Token: 0x06003614 RID: 13844 RVA: 0x0006E288 File Offset: 0x0006C488
		[Address(RVA = "0x32660A8", Offset = "0x32660A8", VA = "0x32660A8", Slot = "17")]
		[Token(Token = "0x6003614")]
		protected virtual void vmethod_13()
		{
			if (this.hexaBodyInputsBase_0.playerInputState_1.JustActivated)
			{
				return;
			}
			if (this._jumpStage != GEnum20.const_0)
			{
				return;
			}
			if (this.hexaBodyInputsBase_0.playerInputState_0 != null)
			{
				float num = this.float_57;
				float single_ = this.Single_4;
				float deltaTime = Time.deltaTime;
				float crouchAmount = this.float_45;
				this.float_57 = num;
				float deltaTime2 = Time.deltaTime;
				this._crouchAmount = crouchAmount;
				float deltaTime3 = Time.deltaTime;
				this.float_77 = crouchAmount;
				float crouchAmount2 = this._crouchAmount;
				this.method_13(deltaTime3);
				this.float_45 = crouchAmount2;
				this.float_56 = crouchAmount2;
				return;
			}
			if (this.genum19_0 == GEnum19.const_0 || this._jumpStage != GEnum20.const_0)
			{
				return;
			}
			if (this._jumpStage == GEnum20.const_0)
			{
				float deltaTime4 = Time.deltaTime;
				return;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06003615 RID: 13845 RVA: 0x0006797C File Offset: 0x00065B7C
		// (set) Token: 0x06003653 RID: 13907 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000C4")]
		public Quaternion Quaternion_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x3266520", Offset = "0x3266520", VA = "0x3266520")]
			[Token(Token = "0x6003615")]
			get
			{
			}
			[Token(Token = "0x6003653")]
			[CompilerGenerated]
			[Address(RVA = "0x3269B80", Offset = "0x3269B80", VA = "0x3269B80")]
			private set
			{
			}
		}

		// Token: 0x06003616 RID: 13846 RVA: 0x0006E340 File Offset: 0x0006C540
		[Token(Token = "0x6003616")]
		[Address(RVA = "0x3266534", Offset = "0x3266534", VA = "0x3266534")]
		private void FixedUpdate()
		{
			this.method_17();
			Vector3 velocity = this.rigidbody_1.velocity;
			float magnitude = this.rigidbody_1.velocity.magnitude;
			Vector3 localPosition = this.rigidbody_1.transform.localPosition;
			Vector3 localPosition2 = this.rigidbody_0.transform.localPosition;
			float standingPercent = this.float_19;
			float num = this.float_58;
			this.float_44 = standingPercent;
			this.float_43 = num;
			this._standingPercent = standingPercent;
			Mathf.Clamp01(magnitude);
			this._standingPercent = standingPercent;
			this.method_5();
			this.method_22();
			this.method_21();
			this.method_0();
			bool flag = this.bool_13;
			this.bool_16 = flag;
		}

		// Token: 0x06003617 RID: 13847 RVA: 0x00003419 File Offset: 0x00001619
		[Address(RVA = "0x3266AEC", Offset = "0x3266AEC", VA = "0x3266AEC")]
		[Token(Token = "0x6003617")]
		public void method_14(float float_84, float float_85)
		{
			this.sphereCollider_0.material.dynamicFriction = float_84;
			this.sphereCollider_0.material.staticFriction = float_85;
		}

		// Token: 0x06003618 RID: 13848 RVA: 0x0006E3F4 File Offset: 0x0006C5F4
		[Address(RVA = "0x3266B5C", Offset = "0x3266B5C", VA = "0x3266B5C", Slot = "18")]
		[Token(Token = "0x6003618")]
		protected virtual IEnumerator vmethod_14(float float_84)
		{
			HexaBodyPlayer4.Class54 @class = new HexaBodyPlayer4.Class54((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x0600361A RID: 13850 RVA: 0x0006E41C File Offset: 0x0006C61C
		[Token(Token = "0x170000D3")]
		public float Single_8
		{
			[Address(RVA = "0x3266BF4", Offset = "0x3266BF4", VA = "0x3266BF4")]
			[Token(Token = "0x600361A")]
			get
			{
				/*
An exception occurred when decompiling this method (0600361A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single HexabodyVR.PlayerController.HexaBodyPlayer4::get_Single_8()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(arg_06_0, callgetter:float32(HexaBodyPlayer4::get_Single_9, ldloc:HexaBodyPlayer4(this))); 	stloc:float32(arg_0D_0, callgetter:float32(HexaBodyPlayer4::get_Single_7, ldloc:HexaBodyPlayer4(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}
		}

		// Token: 0x0600361B RID: 13851 RVA: 0x0006E438 File Offset: 0x0006C638
		[Address(RVA = "0x3266C2C", Offset = "0x3266C2C", VA = "0x3266C2C")]
		[Token(Token = "0x600361B")]
		public void method_15(Vector3 vector3_4)
		{
			Vector3 eulerAngles = this.transform_0.rotation.eulerAngles;
			Transform transform = this.transform_0;
			Vector3 forward = transform.forward;
			Quaternion rotation = this.rigidbody_1.rotation;
		}

		// Token: 0x0600361C RID: 13852 RVA: 0x0006E474 File Offset: 0x0006C674
		[Address(RVA = "0x3266D38", Offset = "0x3266D38", VA = "0x3266D38", Slot = "19")]
		[Token(Token = "0x600361C")]
		protected virtual void vmethod_15(Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 localPosition = this.transform_7.localPosition;
			Transform transform = this.rigidbody_1.transform;
			float magnitude = this.capsuleCollider_3.center.magnitude;
			Vector3 position = this.transform_1.position;
			Vector3 up = this.transform_6.transform.up;
			Quaternion rotation = this.transform_6.transform.rotation;
			Transform transform2 = this.transform_1;
			CapsuleCollider capsuleCollider = this.capsuleCollider_1;
			Vector3 position2 = transform2.position;
			Vector3 position3 = this.transform_7.position;
			float height;
			capsuleCollider.height = height;
			Transform transform3 = this.transform_1;
			Vector3 position4 = transform3.position;
		}

		// Token: 0x0600361D RID: 13853 RVA: 0x0006E518 File Offset: 0x0006C718
		[Address(RVA = "0x3266FF0", Offset = "0x3266FF0", VA = "0x3266FF0")]
		[Token(Token = "0x600361D")]
		public float method_16()
		{
			/*
An exception occurred when decompiling this method (0600361D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single HexabodyVR.PlayerController.HexaBodyPlayer4::method_16()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Physics::get_gravity)); 	stloc:float32(arg_0C_0, callgetter:float32(HexaBodyPlayer4::get_Single_7, ldloc:HexaBodyPlayer4(this))); 	stloc:float32(arg_13_0, callgetter:float32(HexaBodyPlayer4::get_Single_9, ldloc:HexaBodyPlayer4(this))); 	stloc:Vector3(arg_19_0, callgetter:Vector3(Physics::get_gravity)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600361E RID: 13854 RVA: 0x0006E540 File Offset: 0x0006C740
		[Address(RVA = "0x3267058", Offset = "0x3267058", VA = "0x3267058", Slot = "20")]
		[Token(Token = "0x600361E")]
		protected virtual bool vmethod_16()
		{
			long num = 1L;
			HexaHandsBase exists = this.hexaHandsBase_0;
			if (num != 0L)
			{
			}
			exists;
			HexaHandsBase exists2 = this.hexaHandsBase_1;
			if (num != 0L)
			{
			}
			exists2;
			float single_ = this.Single_0;
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			float single_2 = this.Single_0;
			Vector3 zero2 = Vector3.zero;
			Vector3 up2 = Vector3.up;
			float single_3 = this.Single_0;
			throw new NullReferenceException();
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x0600361F RID: 13855 RVA: 0x0000343D File Offset: 0x0000163D
		// (set) Token: 0x0600362F RID: 13871 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000CA")]
		public bool Boolean_1
		{
			[CompilerGenerated]
			[Token(Token = "0x600361F")]
			[Address(RVA = "0x3267270", Offset = "0x3267270", VA = "0x3267270")]
			get
			{
				return this.bool_16;
			}
			[CompilerGenerated]
			[Address(RVA = "0x3267EC4", Offset = "0x3267EC4", VA = "0x3267EC4")]
			[Token(Token = "0x600362F")]
			set
			{
			}
		}

		// Token: 0x06003620 RID: 13856 RVA: 0x0006E5A4 File Offset: 0x0006C7A4
		[Address(RVA = "0x3267278", Offset = "0x3267278", VA = "0x3267278", Slot = "21")]
		[Token(Token = "0x6003620")]
		protected virtual void vmethod_17()
		{
			if (this.animationCurve_3.keys.m_OutWeight != null)
			{
			}
			if (this.animationCurve_4.keys.m_OutWeight != null)
			{
			}
			if (this.animationCurve_9.keys.m_OutWeight != null)
			{
			}
			if (this.animationCurve_8.keys.m_OutWeight != null)
			{
				return;
			}
		}

		// Token: 0x06003621 RID: 13857 RVA: 0x0006E5FC File Offset: 0x0006C7FC
		[Token(Token = "0x6003621")]
		[Address(RVA = "0x3266698", Offset = "0x3266698", VA = "0x3266698")]
		private void method_17()
		{
			if (this.bool_0)
			{
				Vector3 position = this.rigidbody_3.transform.position;
			}
			Rigidbody rigidbody = this.rigidbody_3;
			Vector3 position2 = rigidbody.transform.position;
			float num = this.float_68;
			this.float_4 = num;
		}

		// Token: 0x06003622 RID: 13858 RVA: 0x0006E648 File Offset: 0x0006C848
		[Address(RVA = "0x326744C", Offset = "0x326744C", VA = "0x326744C", Slot = "22")]
		[Token(Token = "0x6003622")]
		protected virtual void vmethod_18()
		{
			if (this._jumpStage != GEnum20.const_0)
			{
			}
			Rigidbody rigidbody = this.rigidbody_1;
			long jumpStage = 1L;
			this._jumpStage = (GEnum20)jumpStage;
			Vector3 velocity = rigidbody.velocity;
			Vector3 gravity = Physics.gravity;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 gravity2 = Physics.gravity;
			float crouchAmount = this._crouchAmount;
			this.float_67 = crouchAmount;
			this.method_19();
		}

		// Token: 0x06003623 RID: 13859 RVA: 0x0006DD44 File Offset: 0x0006BF44
		[Address(RVA = "0x32675B0", Offset = "0x32675B0", VA = "0x32675B0", Slot = "23")]
		[Token(Token = "0x6003623")]
		protected virtual void Start()
		{
			long num = 1L;
			HexaHandsBase exists = this.hexaHandsBase_0;
			if (num != 0L)
			{
			}
			exists;
			HexaHandsBase[] componentsInChildren = base.transform.root.GetComponentsInChildren<HexaHandsBase>();
			Func<HexaHandsBase, bool> func;
			if (HexaBodyPlayer4.<>c.<>9__231_0 == null)
			{
				HexaBodyPlayer4.<>c.<>9__231_0 = func;
			}
			Enumerable.FirstOrDefault<HexaHandsBase>(componentsInChildren, func);
			this.hexaHandsBase_1;
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06003651 RID: 13905 RVA: 0x00003485 File Offset: 0x00001685
		// (set) Token: 0x06003624 RID: 13860 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000C1")]
		public bool Boolean_0
		{
			[Token(Token = "0x6003651")]
			[CompilerGenerated]
			[Address(RVA = "0x3269830", Offset = "0x3269830", VA = "0x3269830")]
			get
			{
				return this.bool_15;
			}
			[CompilerGenerated]
			[Address(RVA = "0x32678C8", Offset = "0x32678C8", VA = "0x32678C8")]
			[Token(Token = "0x6003624")]
			set
			{
			}
		}

		// Token: 0x06003625 RID: 13861 RVA: 0x00003445 File Offset: 0x00001645
		[Address(RVA = "0x32678D4", Offset = "0x32678D4", VA = "0x32678D4", Slot = "24")]
		[Token(Token = "0x6003625")]
		protected virtual void vmethod_19()
		{
			this.method_19();
		}

		// Token: 0x06003626 RID: 13862 RVA: 0x0006E084 File Offset: 0x0006C284
		[Address(RVA = "0x3267940", Offset = "0x3267940", VA = "0x3267940")]
		[Token(Token = "0x6003626")]
		private void method_18()
		{
			GameObject gameObject = this.transform_12.gameObject;
			bool active = this.bool_2;
			gameObject.SetActive(active);
			GameObject gameObject2 = this.transform_11.gameObject;
			bool active2 = this.bool_2;
			gameObject2.SetActive(active2);
			GameObject gameObject3 = this.transform_10.gameObject;
			bool active3 = this.bool_2;
			gameObject3.SetActive(active3);
			GameObject gameObject4 = this.transform_13.gameObject;
			bool active4 = this.bool_2;
			gameObject4.SetActive(active4);
			GameObject gameObject5 = this.transform_14.gameObject;
			bool active5 = this.bool_2;
			gameObject5.SetActive(active5);
		}

		// Token: 0x06003627 RID: 13863 RVA: 0x0006E6A4 File Offset: 0x0006C8A4
		[Address(RVA = "0x32679FC", Offset = "0x32679FC", VA = "0x32679FC", Slot = "25")]
		[Token(Token = "0x6003627")]
		protected virtual void vmethod_20(Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 localPosition = this.transform_7.localPosition;
			Transform transform = this.rigidbody_1.transform;
			float magnitude = this.capsuleCollider_3.center.magnitude;
			Vector3 position = this.transform_1.position;
			Vector3 up = this.transform_6.transform.up;
			Transform transform2 = this.transform_6.transform;
			Quaternion rotation = this.transform_6.transform.rotation;
			Transform transform3 = this.transform_1;
			CapsuleCollider capsuleCollider = this.capsuleCollider_1;
			Vector3 position2 = transform3.position;
			Vector3 position3 = this.transform_7.position;
			float height;
			capsuleCollider.height = height;
			Transform transform4 = this.transform_1;
			Vector3 position4 = transform4.position;
		}

		// Token: 0x06003628 RID: 13864 RVA: 0x0000344D File Offset: 0x0000164D
		[Token(Token = "0x6003628")]
		[Address(RVA = "0x3267CB8", Offset = "0x3267CB8", VA = "0x3267CB8", Slot = "26")]
		protected virtual void vmethod_21()
		{
			if (!this.bool_13)
			{
			}
		}

		// Token: 0x06003629 RID: 13865 RVA: 0x0006E754 File Offset: 0x0006C954
		[Address(RVA = "0x3267CF0", Offset = "0x3267CF0", VA = "0x3267CF0", Slot = "27")]
		[Token(Token = "0x6003629")]
		protected virtual void vmethod_22()
		{
			if (!this.bool_11)
			{
			}
		}

		// Token: 0x0600362A RID: 13866 RVA: 0x0006E76C File Offset: 0x0006C96C
		[Address(RVA = "0x3267D6C", Offset = "0x3267D6C", VA = "0x3267D6C", Slot = "28")]
		[Token(Token = "0x600362A")]
		protected virtual void vmethod_23()
		{
			PlayerPrefs.HasKey("SaveHeight");
			float @float = PlayerPrefs.GetFloat("SaveHeight");
			this.method_35(@float);
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x0600362B RID: 13867 RVA: 0x0006E798 File Offset: 0x0006C998
		[Token(Token = "0x170000D1")]
		public bool Boolean_4
		{
			[Address(RVA = "0x32664FC", Offset = "0x32664FC", VA = "0x32664FC")]
			[Token(Token = "0x600362B")]
			get
			{
			}
		}

		// Token: 0x0600362C RID: 13868 RVA: 0x0006E7A8 File Offset: 0x0006C9A8
		[Address(RVA = "0x3267544", Offset = "0x3267544", VA = "0x3267544")]
		[Token(Token = "0x600362C")]
		public void method_19()
		{
		}

		// Token: 0x0600362D RID: 13869 RVA: 0x00003419 File Offset: 0x00001619
		[Address(RVA = "0x3267E4C", Offset = "0x3267E4C", VA = "0x3267E4C")]
		[Token(Token = "0x600362D")]
		public void method_20(float float_84, float float_85)
		{
			this.sphereCollider_0.material.dynamicFriction = float_84;
			this.sphereCollider_0.material.staticFriction = float_85;
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06003659 RID: 13913 RVA: 0x0003584C File Offset: 0x00033A4C
		// (set) Token: 0x06003630 RID: 13872 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000C9")]
		public float Single_2
		{
			[Address(RVA = "0x3269DC4", Offset = "0x3269DC4", VA = "0x3269DC4")]
			[Token(Token = "0x6003659")]
			get
			{
			}
			[Address(RVA = "0x3267ED0", Offset = "0x3267ED0", VA = "0x3267ED0")]
			[Token(Token = "0x6003630")]
			set
			{
			}
		}

		// Token: 0x06003631 RID: 13873 RVA: 0x0006E7B8 File Offset: 0x0006C9B8
		[Address(RVA = "0x3266790", Offset = "0x3266790", VA = "0x3266790")]
		[Token(Token = "0x6003631")]
		private void method_21()
		{
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_1.position;
			Vector3 localPosition = this.transform_1.localPosition;
			float single_ = this.Single_5;
			float crouchAmount = this._crouchAmount;
			this.float_47 = crouchAmount;
			float num = this.float_44;
			if (!this.bool_14)
			{
			}
			float deltaTime = Time.deltaTime;
			float num2 = this.float_46;
			this.float_83 = num;
			bool flag = this.bool_13;
			this.float_46 = num2;
			if (flag)
			{
				return;
			}
			SoftJointLimit linearLimit = this.configurableJoint_0.linearLimit;
			float num3;
			linearLimit.bounciness = num3;
			linearLimit.contactDistance = num3;
			linearLimit.limit = num3;
			Vector3 targetPosition = this.configurableJoint_0.targetPosition;
			Vector3 up = Vector3.up;
			GEnum20 jumpStage = this._jumpStage;
			ConfigurableJoint configurableJoint = this.configurableJoint_0;
			if (jumpStage == GEnum20.const_0)
			{
				return;
			}
			Vector3 targetPosition2 = configurableJoint.targetPosition;
			float deltaTime2 = Time.deltaTime;
		}

		// Token: 0x06003632 RID: 13874 RVA: 0x0006E898 File Offset: 0x0006CA98
		[Address(RVA = "0x3267F28", Offset = "0x3267F28", VA = "0x3267F28", Slot = "29")]
		[Token(Token = "0x6003632")]
		protected virtual void vmethod_24()
		{
			if (this.hexaBodyInputsBase_0.bool_4)
			{
				if (this.bool_6)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_15;
				HexaBodyInputsBase hexaBodyInputsBase = this.hexaBodyInputsBase_0;
				if (flag)
				{
					if (hexaBodyInputsBase == null)
					{
						return;
					}
				}
				else if (hexaBodyInputsBase.bool_5)
				{
					if (this.bool_6)
					{
						long num = 1L;
						this.bool_15 = (num != 0L);
						return;
					}
					long num2 = 1L;
					this.bool_6 = (num2 != 0L);
				}
			}
			else
			{
				bool flag2 = this.bool_15;
				HexaBodyInputsBase hexaBodyInputsBase;
				bool flag3 = hexaBodyInputsBase.bool_5;
				long num;
				if (flag2)
				{
					if (flag3)
					{
						return;
					}
				}
				else if (num != 0L)
				{
					long num3 = 1L;
					this.bool_15 = (num3 != 0L);
					return;
				}
			}
		}

		// Token: 0x06003633 RID: 13875 RVA: 0x0006E92C File Offset: 0x0006CB2C
		[Token(Token = "0x6003633")]
		[Address(RVA = "0x3266724", Offset = "0x3266724", VA = "0x3266724")]
		private void method_22()
		{
		}

		// Token: 0x06003634 RID: 13876 RVA: 0x0000345F File Offset: 0x0000165F
		[Address(RVA = "0x3268010", Offset = "0x3268010", VA = "0x3268010", Slot = "30")]
		[Token(Token = "0x6003634")]
		protected virtual void vmethod_25()
		{
			if (this.bool_1)
			{
				return;
			}
			if (this.bool_9)
			{
				return;
			}
		}

		// Token: 0x06003635 RID: 13877 RVA: 0x0006E93C File Offset: 0x0006CB3C
		[Address(RVA = "0x3268044", Offset = "0x3268044", VA = "0x3268044", Slot = "31")]
		[Token(Token = "0x6003635")]
		protected virtual void vmethod_26()
		{
			HexaBodyInputsBase hexaBodyInputsBase = this.hexaBodyInputsBase_0;
			if (hexaBodyInputsBase != null)
			{
			}
			float num = this.float_26;
			float deltaTime = Time.deltaTime;
			Rigidbody rigidbody = this.rigidbody_1;
			this.float_80 = num;
			Transform transform = rigidbody.transform;
			Vector3 position = this.rigidbody_0.transform.position;
			Vector3 up = Vector3.up;
		}

		// Token: 0x06003636 RID: 13878 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326817C", Offset = "0x326817C", VA = "0x326817C")]
		[Token(Token = "0x6003636")]
		public void method_23(bool bool_17)
		{
		}

		// Token: 0x06003637 RID: 13879 RVA: 0x0006E990 File Offset: 0x0006CB90
		[Address(RVA = "0x3268188", Offset = "0x3268188", VA = "0x3268188", Slot = "32")]
		[Token(Token = "0x6003637")]
		protected virtual void Awake()
		{
			HexaBodyInputsBase component = base.GetComponent<HexaBodyInputsBase>();
			this.hexaBodyInputsBase_0 = component;
			float radius = this.sphereCollider_0.radius;
			float radius2 = this.sphereCollider_1.radius;
			WaitForFixedUpdate waitForFixedUpdate = new WaitForFixedUpdate();
			this.waitForFixedUpdate_0 = waitForFixedUpdate;
			Transform transform = this.transform_0;
			this.transform_17 = transform;
			Vector3 localPosition = this.transform_0.localPosition;
			Rigidbody rigidbody = this.rigidbody_0;
			Vector3 position = rigidbody.position;
			this.sphereCollider_1.contactOffset = radius2;
			this.sphereCollider_0.contactOffset = radius2;
			this.configurableJoint_1.projectionDistance = radius2;
			this.configurableJoint_0.projectionDistance = radius2;
			this.configurableJoint_0.projectionAngle = radius2;
			Rigidbody rigidbody2 = this.rigidbody_1;
			int solverIterations = this.int_0;
			rigidbody2.solverIterations = solverIterations;
			Rigidbody rigidbody3 = this.rigidbody_1;
			int solverVelocityIterations = this.int_1;
			rigidbody3.solverVelocityIterations = solverVelocityIterations;
			Rigidbody rigidbody4 = this.rigidbody_2;
			int solverIterations2 = this.int_0;
			rigidbody4.solverIterations = solverIterations2;
			Rigidbody rigidbody5 = this.rigidbody_2;
			int solverVelocityIterations2 = this.int_1;
			rigidbody5.solverVelocityIterations = solverVelocityIterations2;
			Rigidbody rigidbody6 = this.rigidbody_0;
			int solverIterations3 = this.int_0;
			rigidbody6.solverIterations = solverIterations3;
			Rigidbody rigidbody7 = this.rigidbody_0;
			int solverVelocityIterations3 = this.int_1;
			rigidbody7.solverVelocityIterations = solverVelocityIterations3;
			this.method_11();
			float num = this.float_24;
			this.method_32(radius2);
			this.rigidbody_0.maxAngularVelocity = radius2;
			this.rigidbody_1.maxAngularVelocity = radius2;
			float dynamicFriction = this.sphereCollider_0.material.dynamicFriction;
			SphereCollider sphereCollider = this.sphereCollider_0;
			this.float_73 = num;
			float staticFriction = sphereCollider.material.staticFriction;
			this.float_74 = num;
			this.method_26();
			Vector3 localPosition2 = this.transform_0.localPosition;
			this.method_35(radius2);
			float single_ = this.Single_9;
			Vector3 gravity = Physics.gravity;
			float positionSpring = this.configurableJoint_0.yDrive.positionSpring;
			Rigidbody rigidbody8 = this.rigidbody_0;
			this.float_82 = num;
			GameObject gameObject = rigidbody8.gameObject;
			this.rigidbody_0.gameObject.AddComponent<LocoBallCollision>();
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x0600365C RID: 13916 RVA: 0x00003495 File Offset: 0x00001695
		// (set) Token: 0x06003638 RID: 13880 RVA: 0x00003473 File Offset: 0x00001673
		[Token(Token = "0x170000C5")]
		public HexaBodyInputsBase HexaBodyInputsBase_0 { [Token(Token = "0x600365C")] [Address(RVA = "0x3269DD4", Offset = "0x3269DD4", VA = "0x3269DD4")] get; [Address(RVA = "0x32689F0", Offset = "0x32689F0", VA = "0x32689F0")] [Token(Token = "0x6003638")] private set; }

		// Token: 0x06003639 RID: 13881 RVA: 0x0006EB94 File Offset: 0x0006CD94
		[Address(RVA = "0x3268A00", Offset = "0x3268A00", VA = "0x3268A00")]
		[Token(Token = "0x6003639")]
		public void method_24(float float_84)
		{
			this.float_40 = (float)16964;
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x0600363A RID: 13882 RVA: 0x0006EBAC File Offset: 0x0006CDAC
		[Token(Token = "0x170000D0")]
		public bool Boolean_3
		{
			[Address(RVA = "0x32655CC", Offset = "0x32655CC", VA = "0x32655CC")]
			[Token(Token = "0x600363A")]
			get
			{
			}
		}

		// Token: 0x0600363B RID: 13883 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3268A74", Offset = "0x3268A74", VA = "0x3268A74")]
		[Token(Token = "0x600363B")]
		public void method_25()
		{
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x0600363C RID: 13884 RVA: 0x0006EBBC File Offset: 0x0006CDBC
		[Token(Token = "0x170000CB")]
		public float Single_3
		{
			[Token(Token = "0x600363C")]
			[Address(RVA = "0x3264CEC", Offset = "0x3264CEC", VA = "0x3264CEC")]
			get
			{
				/*
An exception occurred when decompiling this method (0600363C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single HexabodyVR.PlayerController.HexaBodyPlayer4::get_Single_3()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Physics::get_gravity)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}
		}

		// Token: 0x0600363D RID: 13885 RVA: 0x0006EBD0 File Offset: 0x0006CDD0
		[Address(RVA = "0x3268A80", Offset = "0x3268A80", VA = "0x3268A80", Slot = "33")]
		[Token(Token = "0x600363D")]
		protected virtual void vmethod_27(Vector3 vector3_4, bool bool_17)
		{
		}

		// Token: 0x0600363E RID: 13886 RVA: 0x0006EBE0 File Offset: 0x0006CDE0
		[Address(RVA = "0x3268D80", Offset = "0x3268D80", VA = "0x3268D80", Slot = "34")]
		[Token(Token = "0x600363E")]
		protected virtual void vmethod_28()
		{
			bool flag;
			if (!(flag = this.locoBallCollision_0.collisionDetector_0.bool_2))
			{
			}
			float num = this.float_45;
			if (flag)
			{
				Rigidbody rigidbody = this.rigidbody_1;
				this.float_4 = (float)49440;
				Vector3 velocity = rigidbody.velocity;
				this.float_2 = num;
				return;
			}
			Debug.Log("liftoff failed!");
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06003655 RID: 13909 RVA: 0x0000348D File Offset: 0x0000168D
		// (set) Token: 0x0600363F RID: 13887 RVA: 0x0000347C File Offset: 0x0000167C
		[Token(Token = "0x170000C8")]
		public Transform Transform_0 { [Token(Token = "0x6003655")] [Address(RVA = "0x3269B94", Offset = "0x3269B94", VA = "0x3269B94")] get; [Address(RVA = "0x3268ED8", Offset = "0x3268ED8", VA = "0x3268ED8")] [Token(Token = "0x600363F")] set; }

		// Token: 0x06003640 RID: 13888 RVA: 0x0006EC38 File Offset: 0x0006CE38
		[Address(RVA = "0x3268EE8", Offset = "0x3268EE8", VA = "0x3268EE8")]
		[Token(Token = "0x6003640")]
		static HexaBodyPlayer4()
		{
			float[] array = new float[]
			{
				0.25f,
				0.5f,
				0.75f,
				1f
			};
			HexaBodyPlayer4.float_31 = array;
		}

		// Token: 0x06003641 RID: 13889 RVA: 0x0006EC60 File Offset: 0x0006CE60
		[Address(RVA = "0x3268F7C", Offset = "0x3268F7C", VA = "0x3268F7C", Slot = "35")]
		[Token(Token = "0x6003641")]
		protected virtual void vmethod_29()
		{
			float single_ = this.Single_0;
			if (!this.bool_14)
			{
			}
		}

		// Token: 0x06003642 RID: 13890 RVA: 0x0006EC7C File Offset: 0x0006CE7C
		[Address(RVA = "0x3266028", Offset = "0x3266028", VA = "0x3266028")]
		[Token(Token = "0x6003642")]
		private void method_26()
		{
			float mass = this.rigidbody_3.mass;
			float mass2 = this.rigidbody_1.mass;
			float mass3 = this.rigidbody_2.mass;
			float mass4 = this.rigidbody_0.mass;
		}

		// Token: 0x06003643 RID: 13891 RVA: 0x0006E5A4 File Offset: 0x0006C7A4
		[Address(RVA = "0x3269098", Offset = "0x3269098", VA = "0x3269098", Slot = "36")]
		[Token(Token = "0x6003643")]
		protected virtual void vmethod_30()
		{
			if (this.animationCurve_3.keys.m_OutWeight != null)
			{
			}
			if (this.animationCurve_4.keys.m_OutWeight != null)
			{
			}
			if (this.animationCurve_9.keys.m_OutWeight != null)
			{
			}
			if (this.animationCurve_8.keys.m_OutWeight != null)
			{
				return;
			}
		}

		// Token: 0x06003644 RID: 13892 RVA: 0x0006ECBC File Offset: 0x0006CEBC
		[Address(RVA = "0x3269220", Offset = "0x3269220", VA = "0x3269220")]
		[Token(Token = "0x6003644")]
		public void method_27()
		{
			long num = 1L;
			Vector3 localPosition = this.transform_0.localPosition;
			if (num != 0L)
			{
				Vector3 localPosition2 = this.transform_0.localPosition;
				PlayerPrefs.Save();
				return;
			}
		}

		// Token: 0x06003645 RID: 13893 RVA: 0x0006DB40 File Offset: 0x0006BD40
		[Address(RVA = "0x32692BC", Offset = "0x32692BC", VA = "0x32692BC")]
		[Token(Token = "0x6003645")]
		public void method_28(int int_2)
		{
		}

		// Token: 0x06003646 RID: 13894 RVA: 0x0006ECEC File Offset: 0x0006CEEC
		[Address(RVA = "0x3264BEC", Offset = "0x3264BEC", VA = "0x3264BEC")]
		[Token(Token = "0x6003646")]
		public void method_29()
		{
			float drag = this.rigidbody_1.drag;
			float drag2 = this.rigidbody_2.drag;
			float drag3 = this.rigidbody_0.drag;
			this.rigidbody_1.drag = drag3;
			this.rigidbody_3.drag = drag3;
			this.rigidbody_2.drag = drag3;
			this.rigidbody_0.drag = drag3;
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06003647 RID: 13895 RVA: 0x0006EBAC File Offset: 0x0006CDAC
		[Token(Token = "0x170000CF")]
		public bool Boolean_2
		{
			[Address(RVA = "0x32664EC", Offset = "0x32664EC", VA = "0x32664EC")]
			[Token(Token = "0x6003647")]
			get
			{
			}
		}

		// Token: 0x06003648 RID: 13896 RVA: 0x0006ED50 File Offset: 0x0006CF50
		[Token(Token = "0x6003648")]
		[Address(RVA = "0x326930C", Offset = "0x326930C", VA = "0x326930C")]
		private void method_30()
		{
			if (this.hexaBodyInputsBase_0.bool_6)
			{
				this.method_27();
			}
			if (this.hexaBodyInputsBase_0.playerInputState_0.JustDeactivated)
			{
				GEnum19 genum = this.genum19_0;
				long num;
				if (genum != GEnum19.const_0)
				{
					num = 1L;
					this.bool_5 = (num != 0L);
					return;
				}
				long num2 = 1L;
				this.bool_5 = (num2 != 0L);
				if (num != 0L)
				{
				}
				long jumpStage = 1L;
				this._jumpStage = (GEnum20)jumpStage;
			}
		}

		// Token: 0x06003649 RID: 13897 RVA: 0x0006EDB0 File Offset: 0x0006CFB0
		[Token(Token = "0x6003649")]
		[Address(RVA = "0x32693BC", Offset = "0x32693BC", VA = "0x32693BC", Slot = "37")]
		protected virtual void vmethod_31()
		{
			float num = this.float_19;
			float num2 = this.float_48;
			this.float_50 = num;
			this.float_51 = num2;
			float single_ = this.Single_5;
			float single_2 = this.Single_5;
		}

		// Token: 0x0600364A RID: 13898 RVA: 0x0006EDE8 File Offset: 0x0006CFE8
		[Address(RVA = "0x3265324", Offset = "0x3265324", VA = "0x3265324")]
		[Token(Token = "0x600364A")]
		public void method_31()
		{
			Vector3 localPosition = this.transform_0.localPosition;
			if (this.bool_4)
			{
				Vector3 localPosition2 = this.transform_0.localPosition;
				PlayerPrefs.Save();
				return;
			}
		}

		// Token: 0x0600364B RID: 13899 RVA: 0x0006EE1C File Offset: 0x0006D01C
		[Address(RVA = "0x32694B4", Offset = "0x32694B4", VA = "0x32694B4", Slot = "38")]
		[Token(Token = "0x600364B")]
		protected virtual void vmethod_32()
		{
			Vector3 forward = this.transform_17.forward;
			Vector3 right = this.transform_17.right;
			if (this.bool_13)
			{
			}
			this.method_4();
		}

		// Token: 0x0600364C RID: 13900 RVA: 0x0006EE50 File Offset: 0x0006D050
		[Address(RVA = "0x32685D8", Offset = "0x32685D8", VA = "0x32685D8")]
		[Token(Token = "0x600364C")]
		public void method_32(float float_84)
		{
			long num = 1L;
			if (num != 0L)
			{
			}
			Rigidbody exists = this.rigidbody_4;
			if (num != 0L)
			{
			}
			exists;
			ConfigurableJoint exists2 = this.configurableJoint_3;
			if (num != 0L)
			{
			}
			exists2;
			this.rigidbody_1.gameObject.AddComponent<ConfigurableJoint>();
			Vector3 zero = Vector3.zero;
			Rigidbody rigidbody = this.rigidbody_1;
			Transform transform = rigidbody.transform;
			Transform transform2 = this.transform_8;
			Vector3 position = transform2.position;
			SoftJointLimit softJointLimit;
			softJointLimit.limit = float_84;
			Transform exists3 = this.transform_9;
			if (transform2 != null)
			{
			}
			exists3;
			Rigidbody exists4 = this.rigidbody_5;
			if (transform2 != null)
			{
			}
			exists4;
			ConfigurableJoint exists5 = this.configurableJoint_4;
			if (transform2 != null)
			{
			}
			exists5;
			this.rigidbody_1.gameObject.AddComponent<ConfigurableJoint>();
			Vector3 zero2 = Vector3.zero;
			Rigidbody rigidbody2 = this.rigidbody_1;
			Transform transform3 = rigidbody2.transform;
			Vector3 position2 = this.transform_9.position;
			SoftJointLimit softJointLimit2;
			softJointLimit2.limit = float_84;
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600364D RID: 13901 RVA: 0x0003584C File Offset: 0x00033A4C
		// (set) Token: 0x06003665 RID: 13925 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000C2")]
		public float Single_1
		{
			[CompilerGenerated]
			[Address(RVA = "0x32695D8", Offset = "0x32695D8", VA = "0x32695D8")]
			[Token(Token = "0x600364D")]
			get
			{
			}
			[Token(Token = "0x6003665")]
			[CompilerGenerated]
			[Address(RVA = "0x326A1D8", Offset = "0x326A1D8", VA = "0x326A1D8")]
			private set
			{
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x0600364E RID: 13902 RVA: 0x0006EF3C File Offset: 0x0006D13C
		[Token(Token = "0x170000CD")]
		public float Single_5
		{
			[Address(RVA = "0x3267ED8", Offset = "0x3267ED8", VA = "0x3267ED8")]
			[Token(Token = "0x600364E")]
			get
			{
				Transform transform = this.transform_0;
				Vector3 localPosition = transform.localPosition;
				throw new NullReferenceException();
			}
		}

		// Token: 0x0600364F RID: 13903 RVA: 0x0006EF5C File Offset: 0x0006D15C
		[Address(RVA = "0x32695E0", Offset = "0x32695E0", VA = "0x32695E0")]
		[Token(Token = "0x600364F")]
		private void method_33()
		{
			this.method_11();
			bool flag = this.bool_2;
			this.bool_7 = flag;
			if (flag)
			{
				Transform transform = this.rigidbody_1.transform;
				Vector3 center = this.capsuleCollider_3.center;
				Vector3 localPosition = this.transform_11.localPosition;
				Vector3 localScale = this.transform_10.localScale;
				float height = this.capsuleCollider_1.height;
				float radius = this.capsuleCollider_1.radius;
				Vector3 localScale2 = this.transform_11.localScale;
				float height2 = this.capsuleCollider_0.height;
				float radius2 = this.capsuleCollider_0.radius;
				Vector3 localScale3 = this.transform_12.localScale;
				CapsuleCollider capsuleCollider = this.capsuleCollider_3;
				float height3 = capsuleCollider.height;
				float radius3 = capsuleCollider.radius;
				Vector3 localScale4 = this.transform_14.localScale;
				float radius4 = this.sphereCollider_1.radius;
				Vector3 localScale5 = this.transform_13.localScale;
				float radius5 = this.sphereCollider_0.radius;
				return;
			}
		}

		// Token: 0x06003650 RID: 13904 RVA: 0x0006F044 File Offset: 0x0006D244
		[Address(RVA = "0x32649E8", Offset = "0x32649E8", VA = "0x32649E8")]
		[Token(Token = "0x6003650")]
		public Vector3 method_34(Vector3 vector3_4)
		{
			Vector3 position = this.rigidbody_1.position;
			Vector3 position2 = this.rigidbody_0.position;
			Vector3 position3 = this.rigidbody_2.position;
			Vector3 position4 = this.rigidbody_3.position;
			Vector3 position5 = this.rigidbody_1.position;
			Vector3 position6 = this.rigidbody_1.position;
			Vector3 result;
			return result;
		}

		// Token: 0x06003652 RID: 13906 RVA: 0x0006F09C File Offset: 0x0006D29C
		[Token(Token = "0x6003652")]
		[Address(RVA = "0x3269838", Offset = "0x3269838", VA = "0x3269838", Slot = "39")]
		protected virtual void vmethod_33()
		{
			this.transform_0.forward.Normalize();
			Transform transform = this.rigidbody_1.transform;
			Transform transform2 = this.rigidbody_1.transform;
			Vector3 position = this.rigidbody_0.position;
			Vector3 position2 = this.rigidbody_1.position;
			Vector3 center = this.capsuleCollider_3.center;
			float deltaTime = Time.deltaTime;
			this.method_40();
		}

		// Token: 0x06003654 RID: 13908 RVA: 0x0006F104 File Offset: 0x0006D304
		[Address(RVA = "0x3267DE0", Offset = "0x3267DE0", VA = "0x3267DE0")]
		[Token(Token = "0x6003654")]
		public void method_35(float float_84)
		{
		}

		// Token: 0x06003656 RID: 13910 RVA: 0x0006F114 File Offset: 0x0006D314
		[Token(Token = "0x6003656")]
		[Address(RVA = "0x3269B9C", Offset = "0x3269B9C", VA = "0x3269B9C", Slot = "40")]
		protected virtual float vmethod_34()
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003657 RID: 13911 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x3264548", Offset = "0x3264548", VA = "0x3264548")]
		[Token(Token = "0x6003657")]
		public float method_36(float float_84)
		{
		}

		// Token: 0x06003658 RID: 13912 RVA: 0x0006F128 File Offset: 0x0006D328
		[Address(RVA = "0x3269BD8", Offset = "0x3269BD8", VA = "0x3269BD8", Slot = "41")]
		[Token(Token = "0x6003658")]
		protected virtual void vmethod_35()
		{
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = this.transform_5.transform.up;
			Transform transform = this.transform_5.transform;
			Quaternion rotation = this.transform_5.transform.rotation;
			Rigidbody rigidbody = this.rigidbody_0;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			Vector3 position2 = rigidbody.position;
			float height;
			capsuleCollider.height = height;
			Transform transform2 = this.transform_5.transform;
			Vector3 position3 = this.rigidbody_0.position;
			Vector3 position4 = this.rigidbody_0.position;
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x0600365A RID: 13914 RVA: 0x0006E518 File Offset: 0x0006C718
		[Token(Token = "0x170000CC")]
		public float Single_4
		{
			[Address(RVA = "0x3266484", Offset = "0x3266484", VA = "0x3266484")]
			[Token(Token = "0x600365A")]
			get
			{
				/*
An exception occurred when decompiling this method (0600365A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single HexabodyVR.PlayerController.HexaBodyPlayer4::get_Single_4()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Physics::get_gravity)); 	stloc:float32(arg_0C_0, callgetter:float32(HexaBodyPlayer4::get_Single_7, ldloc:HexaBodyPlayer4(this))); 	stloc:float32(arg_13_0, callgetter:float32(HexaBodyPlayer4::get_Single_9, ldloc:HexaBodyPlayer4(this))); 	stloc:Vector3(arg_19_0, callgetter:Vector3(Physics::get_gravity)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x0600365D RID: 13917 RVA: 0x0006F1B4 File Offset: 0x0006D3B4
		[Token(Token = "0x170000C0")]
		public float Single_0
		{
			[Address(RVA = "0x3267224", Offset = "0x3267224", VA = "0x3267224")]
			[Token(Token = "0x600365D")]
			get
			{
				/*
An exception occurred when decompiling this method (0600365D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single HexabodyVR.PlayerController.HexaBodyPlayer4::get_Single_0()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Physics::get_gravity)); 	stloc:float32(arg_0C_0, callgetter:float32(HexaBodyPlayer4::get_Single_9, ldloc:HexaBodyPlayer4(this))); 	stloc:float32(arg_13_0, callgetter:float32(HexaBodyPlayer4::get_Single_7, ldloc:HexaBodyPlayer4(this))); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}
		}

		// Token: 0x0600365E RID: 13918 RVA: 0x0006F1D4 File Offset: 0x0006D3D4
		[Token(Token = "0x600365E")]
		[Address(RVA = "0x3269DDC", Offset = "0x3269DDC", VA = "0x3269DDC")]
		public void method_37(float float_84, float float_85)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			long num = 1L;
			this.bool_8 = (num != 0L);
			sphereCollider.material.dynamicFriction = float_84;
			this.sphereCollider_0.material.staticFriction = float_85;
		}

		// Token: 0x0600365F RID: 13919 RVA: 0x0006E7A8 File Offset: 0x0006C9A8
		[Address(RVA = "0x3269E50", Offset = "0x3269E50", VA = "0x3269E50")]
		[Token(Token = "0x600365F")]
		public void method_38()
		{
		}

		// Token: 0x06003660 RID: 13920 RVA: 0x0006F210 File Offset: 0x0006D410
		[Token(Token = "0x6003660")]
		[Address(RVA = "0x3269EBC", Offset = "0x3269EBC", VA = "0x3269EBC", Slot = "42")]
		protected virtual void vmethod_36()
		{
			HexaBodyInputsBase hexaBodyInputsBase = this.hexaBodyInputsBase_0;
			float x = hexaBodyInputsBase.vector2_1.x;
			if (hexaBodyInputsBase != null)
			{
			}
			this.float_76 = x;
		}

		// Token: 0x06003661 RID: 13921 RVA: 0x0006F23C File Offset: 0x0006D43C
		[Address(RVA = "0x3269F84", Offset = "0x3269F84", VA = "0x3269F84", Slot = "43")]
		[Token(Token = "0x6003661")]
		public virtual void vmethod_37()
		{
		}

		// Token: 0x06003662 RID: 13922 RVA: 0x0006F24C File Offset: 0x0006D44C
		[Address(RVA = "0x3269FB4", Offset = "0x3269FB4", VA = "0x3269FB4", Slot = "44")]
		[Token(Token = "0x6003662")]
		protected virtual void vmethod_38()
		{
			long jumpStage = 4L;
			this._jumpStage = (GEnum20)jumpStage;
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003663 RID: 13923 RVA: 0x0006F268 File Offset: 0x0006D468
		[Token(Token = "0x6003663")]
		[Address(RVA = "0x326A0F0", Offset = "0x326A0F0", VA = "0x326A0F0")]
		private void method_39()
		{
			if (this.hexaBodyInputsBase_0.bool_6)
			{
				this.method_31();
			}
			if (this.hexaBodyInputsBase_0.playerInputState_0.JustDeactivated && (this.genum19_0 == GEnum19.const_0 || this.bool_13))
			{
				long num = 1L;
				this.bool_5 = (num != 0L);
				this.genum19_0 = (GEnum19)num;
			}
		}

		// Token: 0x06003664 RID: 13924 RVA: 0x0006F2BC File Offset: 0x0006D4BC
		[Token(Token = "0x6003664")]
		[Address(RVA = "0x326A178", Offset = "0x326A178", VA = "0x326A178")]
		private void OnValidate()
		{
			Transform transform = this.rigidbody_2.transform;
			Vector3 position = this.rigidbody_0.transform.position;
		}

		// Token: 0x06003666 RID: 13926 RVA: 0x0006F2E8 File Offset: 0x0006D4E8
		[Address(RVA = "0x326A1E0", Offset = "0x326A1E0", VA = "0x326A1E0", Slot = "45")]
		[Token(Token = "0x6003666")]
		protected virtual Vector3 vmethod_39()
		{
			Transform transform = this.rigidbody_1.transform;
			Vector3 center = this.capsuleCollider_3.center;
			throw new NullReferenceException();
		}

		// Token: 0x06003667 RID: 13927 RVA: 0x0006F314 File Offset: 0x0006D514
		[Token(Token = "0x6003667")]
		[Address(RVA = "0x3269A1C", Offset = "0x3269A1C", VA = "0x3269A1C")]
		private void method_40()
		{
			float num = this.float_18;
			Transform transform = this.transform_0;
			this.float_54 = num;
			Vector3 position = transform.position;
			this.rigidbody_1.transform.position.Normalize();
			Transform transform2 = this.rigidbody_1.transform;
			Transform transform3 = this.transform_1;
			Vector3 localPosition = transform3.localPosition;
			Rigidbody rigidbody = this.rigidbody_1;
			Transform transform4 = rigidbody.transform;
		}

		// Token: 0x06003668 RID: 13928 RVA: 0x0006F380 File Offset: 0x0006D580
		[Token(Token = "0x6003668")]
		[Address(RVA = "0x326A234", Offset = "0x326A234", VA = "0x326A234")]
		public void method_41(Vector3 vector3_4)
		{
			Vector3 velocity = this.rigidbody_3.velocity;
			Vector3 velocity2 = this.rigidbody_1.velocity;
			Vector3 velocity3 = this.rigidbody_2.velocity;
			Vector3 velocity4 = this.rigidbody_0.velocity;
		}

		// Token: 0x06003669 RID: 13929 RVA: 0x0006F3C0 File Offset: 0x0006D5C0
		[Address(RVA = "0x326A31C", Offset = "0x326A31C", VA = "0x326A31C")]
		[Token(Token = "0x6003669")]
		public void method_42(Vector3 vector3_4)
		{
			Vector3 position = this.rigidbody_3.transform.position;
			Vector3 position2 = this.rigidbody_0.transform.position;
			Vector3 position3 = this.rigidbody_1.transform.position;
			Vector3 position4 = this.rigidbody_0.transform.position;
			Vector3 position5 = this.rigidbody_2.transform.position;
			Vector3 position6 = this.rigidbody_0.transform.position;
			Vector3 position7 = this.rigidbody_4.transform.position;
			Vector3 position8 = this.rigidbody_0.transform.position;
			Vector3 position9 = this.rigidbody_5.transform.position;
			Vector3 position10 = this.rigidbody_0.transform.position;
			Transform transform = this.rigidbody_0.transform;
			float radius = this.sphereCollider_0.radius;
			Vector3 position11 = this.rigidbody_0.transform.position;
			Transform transform2 = this.rigidbody_3.transform;
			Rigidbody rigidbody = this.rigidbody_0;
			Vector3 position12 = rigidbody.transform.position;
			Transform transform3 = this.rigidbody_1.transform;
			Rigidbody rigidbody2 = this.rigidbody_0;
			Vector3 position13 = rigidbody2.transform.position;
			Transform transform4 = this.rigidbody_2.transform;
			Rigidbody rigidbody3 = this.rigidbody_0;
			Vector3 position14 = rigidbody3.transform.position;
			Transform transform5 = this.rigidbody_4.transform;
			Rigidbody rigidbody4 = this.rigidbody_0;
			Vector3 position15 = rigidbody4.transform.position;
			Transform transform6 = this.rigidbody_5.transform;
			Rigidbody rigidbody5 = this.rigidbody_0;
			Vector3 position16 = rigidbody5.transform.position;
			this.method_3();
		}

		// Token: 0x0600366A RID: 13930 RVA: 0x0006F54C File Offset: 0x0006D74C
		[Address(RVA = "0x326A85C", Offset = "0x326A85C", VA = "0x326A85C", Slot = "46")]
		[Token(Token = "0x600366A")]
		public virtual void vmethod_40()
		{
			if (!this.bool_11)
			{
				float mass = this.rigidbody_1.mass;
				float mass2 = this.rigidbody_3.mass;
				float mass3 = this.rigidbody_2.mass;
				float mass4 = this.rigidbody_0.mass;
				this.method_26();
				this.rigidbody_1.mass = mass4;
				this.rigidbody_3.mass = mass4;
				this.rigidbody_2.mass = mass;
				this.rigidbody_0.mass = mass;
				long num = 1L;
				this.bool_11 = (num != 0L);
			}
		}

		// Token: 0x0600366B RID: 13931 RVA: 0x0006F5D4 File Offset: 0x0006D7D4
		[Token(Token = "0x600366B")]
		[Address(RVA = "0x326A980", Offset = "0x326A980", VA = "0x326A980")]
		private void Update()
		{
			if (!this.bool_10)
			{
			}
			this.method_39();
			this.method_33();
			float magnitude = this.rigidbody_0.angularVelocity.magnitude;
		}

		// Token: 0x0600366C RID: 13932 RVA: 0x0006E7A8 File Offset: 0x0006C9A8
		[Address(RVA = "0x326AA50", Offset = "0x326AA50", VA = "0x326AA50")]
		[Token(Token = "0x600366C")]
		public void method_43()
		{
		}

		// Token: 0x0600366D RID: 13933 RVA: 0x0006DBBC File Offset: 0x0006BDBC
		[Address(RVA = "0x326AABC", Offset = "0x326AABC", VA = "0x326AABC", Slot = "47")]
		[Token(Token = "0x600366D")]
		protected virtual void vmethod_41(bool bool_17)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x0600366E RID: 13934 RVA: 0x0006F608 File Offset: 0x0006D808
		[Token(Token = "0x600366E")]
		[Address(RVA = "0x326AB60", Offset = "0x326AB60", VA = "0x326AB60")]
		public HexaBodyPlayer4()
		{
			long num = 23593L;
			this.float_20 = (float)num;
			this.float_23 = (float)39322;
			long num2 = 16192L;
			long num3 = 1L;
			this.float_10 = (float)16192;
			this.float_24 = (float)16192;
			this.bool_1 = (num3 != 0L);
			this.float_29 = (float)num2;
			float[] array = HexaBodyPlayer4.float_31;
			this.float_32 = array;
			this.float_55 = (float)39322;
			long num4 = 1069547520L;
			this.float_39 = (float)31457;
			long num5 = 1065353216L;
			this.float_57 = (float)num4;
			this.float_56 = (float)num5;
			this.float_64 = (float)num5;
			this.bool_10 = (num3 != 0L);
			base..ctor();
		}

		// Token: 0x0600366F RID: 13935 RVA: 0x0006F380 File Offset: 0x0006D580
		[Address(RVA = "0x32650E4", Offset = "0x32650E4", VA = "0x32650E4")]
		[Token(Token = "0x600366F")]
		public void method_44(Vector3 vector3_4)
		{
			Vector3 velocity = this.rigidbody_3.velocity;
			Vector3 velocity2 = this.rigidbody_1.velocity;
			Vector3 velocity3 = this.rigidbody_2.velocity;
			Vector3 velocity4 = this.rigidbody_0.velocity;
		}

		// Token: 0x0400084C RID: 2124
		[Token(Token = "0x400084C")]
		public const string string_0 = "SaveHeight";

		// Token: 0x0400084D RID: 2125
		[Token(Token = "0x400084D")]
		[FieldOffset(Offset = "0x18")]
		public float float_0 = (float)32768;

		// Token: 0x0400084E RID: 2126
		[Token(Token = "0x400084E")]
		[FieldOffset(Offset = "0x1C")]
		private float float_1;

		// Token: 0x0400084F RID: 2127
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400084F")]
		private float float_2;

		// Token: 0x04000850 RID: 2128
		[Token(Token = "0x4000850")]
		[FieldOffset(Offset = "0x24")]
		private float float_3;

		// Token: 0x04000851 RID: 2129
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000851")]
		private float float_4;

		// Token: 0x04000852 RID: 2130
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000852")]
		private bool bool_0;

		// Token: 0x04000853 RID: 2131
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000853")]
		public float float_5 = (float)16000;

		// Token: 0x04000854 RID: 2132
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000854")]
		public AnimationCurve animationCurve_0;

		// Token: 0x04000855 RID: 2133
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000855")]
		public AnimationCurve animationCurve_1;

		// Token: 0x04000856 RID: 2134
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000856")]
		public AnimationCurve animationCurve_2;

		// Token: 0x04000857 RID: 2135
		[Token(Token = "0x4000857")]
		[FieldOffset(Offset = "0x50")]
		public float float_6;

		// Token: 0x04000858 RID: 2136
		[Token(Token = "0x4000858")]
		[FieldOffset(Offset = "0x54")]
		public float float_7;

		// Token: 0x04000859 RID: 2137
		[Token(Token = "0x4000859")]
		[FieldOffset(Offset = "0x58")]
		public float float_8;

		// Token: 0x0400085A RID: 2138
		[FieldOffset(Offset = "0x5C")]
		[Token(Token = "0x400085A")]
		public float float_9;

		// Token: 0x0400085B RID: 2139
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x400085B")]
		public float float_10;

		// Token: 0x0400085C RID: 2140
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x400085C")]
		public AnimationCurve animationCurve_3;

		// Token: 0x0400085D RID: 2141
		[Token(Token = "0x400085D")]
		[FieldOffset(Offset = "0x70")]
		public AnimationCurve animationCurve_4;

		// Token: 0x0400085E RID: 2142
		[Token(Token = "0x400085E")]
		[FieldOffset(Offset = "0x78")]
		public float float_11;

		// Token: 0x0400085F RID: 2143
		[Token(Token = "0x400085F")]
		[FieldOffset(Offset = "0x7C")]
		public float float_12;

		// Token: 0x04000860 RID: 2144
		[Token(Token = "0x4000860")]
		[FieldOffset(Offset = "0x80")]
		public float float_13;

		// Token: 0x04000861 RID: 2145
		[FieldOffset(Offset = "0x84")]
		[Token(Token = "0x4000861")]
		public float float_14;

		// Token: 0x04000862 RID: 2146
		[Token(Token = "0x4000862")]
		[FieldOffset(Offset = "0x88")]
		public float float_15 = (float)16656;

		// Token: 0x04000863 RID: 2147
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000863")]
		public AnimationCurve animationCurve_5;

		// Token: 0x04000864 RID: 2148
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x4000864")]
		public AnimationCurve animationCurve_6;

		// Token: 0x04000865 RID: 2149
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x4000865")]
		public AnimationCurve animationCurve_7;

		// Token: 0x04000866 RID: 2150
		[Token(Token = "0x4000866")]
		[FieldOffset(Offset = "0xA8")]
		public AnimationCurve animationCurve_8;

		// Token: 0x04000867 RID: 2151
		[Token(Token = "0x4000867")]
		[FieldOffset(Offset = "0xB0")]
		public float float_16;

		// Token: 0x04000868 RID: 2152
		[FieldOffset(Offset = "0xB4")]
		[Token(Token = "0x4000868")]
		public float float_17;

		// Token: 0x04000869 RID: 2153
		[Token(Token = "0x4000869")]
		[FieldOffset(Offset = "0xB8")]
		public float float_18;

		// Token: 0x0400086A RID: 2154
		[Token(Token = "0x400086A")]
		[FieldOffset(Offset = "0xBC")]
		public float float_19;

		// Token: 0x0400086B RID: 2155
		[Token(Token = "0x400086B")]
		[FieldOffset(Offset = "0xC0")]
		public float float_20;

		// Token: 0x0400086C RID: 2156
		[Token(Token = "0x400086C")]
		[FieldOffset(Offset = "0xC4")]
		public GEnum18 genum18_0;

		// Token: 0x0400086D RID: 2157
		[Token(Token = "0x400086D")]
		[FieldOffset(Offset = "0xC8")]
		public float float_21;

		// Token: 0x0400086E RID: 2158
		[FieldOffset(Offset = "0xCC")]
		[Token(Token = "0x400086E")]
		public float float_22;

		// Token: 0x0400086F RID: 2159
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x400086F")]
		public float float_23;

		// Token: 0x04000870 RID: 2160
		[FieldOffset(Offset = "0xD8")]
		[Token(Token = "0x4000870")]
		public AnimationCurve animationCurve_9;

		// Token: 0x04000871 RID: 2161
		[Token(Token = "0x4000871")]
		[FieldOffset(Offset = "0xE0")]
		public float float_24;

		// Token: 0x04000872 RID: 2162
		[FieldOffset(Offset = "0xE4")]
		[Token(Token = "0x4000872")]
		public bool bool_1;

		// Token: 0x04000873 RID: 2163
		[FieldOffset(Offset = "0xE8")]
		[Token(Token = "0x4000873")]
		public float float_25;

		// Token: 0x04000874 RID: 2164
		[Token(Token = "0x4000874")]
		[FieldOffset(Offset = "0xEC")]
		public float float_26;

		// Token: 0x04000875 RID: 2165
		[FieldOffset(Offset = "0xF0")]
		[Token(Token = "0x4000875")]
		public float float_27;

		// Token: 0x04000876 RID: 2166
		[Token(Token = "0x4000876")]
		[FieldOffset(Offset = "0xF4")]
		public float float_28;

		// Token: 0x04000877 RID: 2167
		[FieldOffset(Offset = "0xF8")]
		[Token(Token = "0x4000877")]
		public float float_29;

		// Token: 0x04000878 RID: 2168
		[Token(Token = "0x4000878")]
		[FieldOffset(Offset = "0xFC")]
		public float float_30;

		// Token: 0x04000879 RID: 2169
		[FieldOffset(Offset = "0x100")]
		[Token(Token = "0x4000879")]
		public LayerMask layerMask_0;

		// Token: 0x0400087A RID: 2170
		[Token(Token = "0x400087A")]
		private static readonly float[] float_31;

		// Token: 0x0400087B RID: 2171
		[FieldOffset(Offset = "0x108")]
		[Token(Token = "0x400087B")]
		public float[] float_32;

		// Token: 0x0400087C RID: 2172
		[FieldOffset(Offset = "0x110")]
		[Token(Token = "0x400087C")]
		public float float_33;

		// Token: 0x0400087D RID: 2173
		[Token(Token = "0x400087D")]
		[FieldOffset(Offset = "0x114")]
		public float float_34;

		// Token: 0x0400087E RID: 2174
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x400087E")]
		public float float_35;

		// Token: 0x0400087F RID: 2175
		[Token(Token = "0x400087F")]
		[FieldOffset(Offset = "0x11C")]
		public float float_36;

		// Token: 0x04000880 RID: 2176
		[Token(Token = "0x4000880")]
		[FieldOffset(Offset = "0x120")]
		public float float_37;

		// Token: 0x04000881 RID: 2177
		[FieldOffset(Offset = "0x124")]
		[Token(Token = "0x4000881")]
		public float float_38;

		// Token: 0x04000882 RID: 2178
		[FieldOffset(Offset = "0x128")]
		[Token(Token = "0x4000882")]
		public int int_0;

		// Token: 0x04000883 RID: 2179
		[FieldOffset(Offset = "0x12C")]
		[Token(Token = "0x4000883")]
		public int int_1;

		// Token: 0x04000884 RID: 2180
		[Token(Token = "0x4000884")]
		[FieldOffset(Offset = "0x130")]
		public HexaCameraRig hexaCameraRig_0;

		// Token: 0x04000885 RID: 2181
		[Token(Token = "0x4000885")]
		[FieldOffset(Offset = "0x138")]
		public Transform transform_0;

		// Token: 0x04000886 RID: 2182
		[FieldOffset(Offset = "0x140")]
		[Token(Token = "0x4000886")]
		public Transform transform_1;

		// Token: 0x04000887 RID: 2183
		[Token(Token = "0x4000887")]
		[FieldOffset(Offset = "0x148")]
		public Transform transform_2;

		// Token: 0x04000888 RID: 2184
		[FieldOffset(Offset = "0x150")]
		[Token(Token = "0x4000888")]
		public Transform transform_3;

		// Token: 0x04000889 RID: 2185
		[FieldOffset(Offset = "0x158")]
		[Token(Token = "0x4000889")]
		public Transform transform_4;

		// Token: 0x0400088A RID: 2186
		[Token(Token = "0x400088A")]
		[FieldOffset(Offset = "0x160")]
		public Transform transform_5;

		// Token: 0x0400088B RID: 2187
		[FieldOffset(Offset = "0x168")]
		[Token(Token = "0x400088B")]
		public Transform transform_6;

		// Token: 0x0400088C RID: 2188
		[FieldOffset(Offset = "0x170")]
		[Token(Token = "0x400088C")]
		public Transform transform_7;

		// Token: 0x0400088D RID: 2189
		[Token(Token = "0x400088D")]
		[FieldOffset(Offset = "0x178")]
		public Transform transform_8;

		// Token: 0x0400088E RID: 2190
		[Token(Token = "0x400088E")]
		[FieldOffset(Offset = "0x180")]
		public Transform transform_9;

		// Token: 0x0400088F RID: 2191
		[FieldOffset(Offset = "0x188")]
		[Token(Token = "0x400088F")]
		public bool bool_2;

		// Token: 0x04000890 RID: 2192
		[FieldOffset(Offset = "0x190")]
		[Token(Token = "0x4000890")]
		public Transform transform_10;

		// Token: 0x04000891 RID: 2193
		[Token(Token = "0x4000891")]
		[FieldOffset(Offset = "0x198")]
		public Transform transform_11;

		// Token: 0x04000892 RID: 2194
		[FieldOffset(Offset = "0x1A0")]
		[Token(Token = "0x4000892")]
		public Transform transform_12;

		// Token: 0x04000893 RID: 2195
		[Token(Token = "0x4000893")]
		[FieldOffset(Offset = "0x1A8")]
		public Transform transform_13;

		// Token: 0x04000894 RID: 2196
		[FieldOffset(Offset = "0x1B0")]
		[Token(Token = "0x4000894")]
		public Transform transform_14;

		// Token: 0x04000895 RID: 2197
		[Token(Token = "0x4000895")]
		[FieldOffset(Offset = "0x1B8")]
		public Rigidbody rigidbody_0;

		// Token: 0x04000896 RID: 2198
		[Token(Token = "0x4000896")]
		[FieldOffset(Offset = "0x1C0")]
		public Rigidbody rigidbody_1;

		// Token: 0x04000897 RID: 2199
		[Token(Token = "0x4000897")]
		[FieldOffset(Offset = "0x1C8")]
		public Rigidbody rigidbody_2;

		// Token: 0x04000898 RID: 2200
		[FieldOffset(Offset = "0x1D0")]
		[Token(Token = "0x4000898")]
		public Rigidbody rigidbody_3;

		// Token: 0x04000899 RID: 2201
		[FieldOffset(Offset = "0x1D8")]
		[Token(Token = "0x4000899")]
		public Rigidbody rigidbody_4;

		// Token: 0x0400089A RID: 2202
		[Token(Token = "0x400089A")]
		[FieldOffset(Offset = "0x1E0")]
		public Rigidbody rigidbody_5;

		// Token: 0x0400089B RID: 2203
		[Token(Token = "0x400089B")]
		[FieldOffset(Offset = "0x1E8")]
		public CapsuleCollider capsuleCollider_0;

		// Token: 0x0400089C RID: 2204
		[Token(Token = "0x400089C")]
		[FieldOffset(Offset = "0x1F0")]
		public CapsuleCollider capsuleCollider_1;

		// Token: 0x0400089D RID: 2205
		[FieldOffset(Offset = "0x1F8")]
		[Token(Token = "0x400089D")]
		public SphereCollider sphereCollider_0;

		// Token: 0x0400089E RID: 2206
		[Token(Token = "0x400089E")]
		[FieldOffset(Offset = "0x200")]
		public SphereCollider sphereCollider_1;

		// Token: 0x0400089F RID: 2207
		[FieldOffset(Offset = "0x208")]
		[Token(Token = "0x400089F")]
		public CapsuleCollider capsuleCollider_2;

		// Token: 0x040008A0 RID: 2208
		[Token(Token = "0x40008A0")]
		[FieldOffset(Offset = "0x210")]
		public CapsuleCollider capsuleCollider_3;

		// Token: 0x040008A1 RID: 2209
		[FieldOffset(Offset = "0x218")]
		[Token(Token = "0x40008A1")]
		public HexaHandsBase hexaHandsBase_0;

		// Token: 0x040008A2 RID: 2210
		[FieldOffset(Offset = "0x220")]
		[Token(Token = "0x40008A2")]
		public HexaHandsBase hexaHandsBase_1;

		// Token: 0x040008A3 RID: 2211
		[FieldOffset(Offset = "0x228")]
		[Token(Token = "0x40008A3")]
		public ConfigurableJoint configurableJoint_0;

		// Token: 0x040008A4 RID: 2212
		[FieldOffset(Offset = "0x230")]
		[Token(Token = "0x40008A4")]
		public ConfigurableJoint configurableJoint_1;

		// Token: 0x040008A5 RID: 2213
		[FieldOffset(Offset = "0x238")]
		[Token(Token = "0x40008A5")]
		public ConfigurableJoint configurableJoint_2;

		// Token: 0x040008A6 RID: 2214
		[FieldOffset(Offset = "0x240")]
		[Token(Token = "0x40008A6")]
		public Transform transform_15;

		// Token: 0x040008A7 RID: 2215
		[FieldOffset(Offset = "0x248")]
		[Token(Token = "0x40008A7")]
		public Transform transform_16;

		// Token: 0x040008A8 RID: 2216
		[Token(Token = "0x40008A8")]
		[FieldOffset(Offset = "0x250")]
		public bool bool_3;

		// Token: 0x040008A9 RID: 2217
		[FieldOffset(Offset = "0x251")]
		[Token(Token = "0x40008A9")]
		public bool bool_4;

		// Token: 0x040008AA RID: 2218
		[Token(Token = "0x40008AA")]
		[FieldOffset(Offset = "0x254")]
		private float float_39;

		// Token: 0x040008AB RID: 2219
		[FieldOffset(Offset = "0x258")]
		[Token(Token = "0x40008AB")]
		private float float_40;

		// Token: 0x040008AC RID: 2220
		[FieldOffset(Offset = "0x25C")]
		[Token(Token = "0x40008AC")]
		public float float_41;

		// Token: 0x040008AD RID: 2221
		[FieldOffset(Offset = "0x260")]
		[Token(Token = "0x40008AD")]
		public float float_42;

		// Token: 0x040008AE RID: 2222
		[Token(Token = "0x40008AE")]
		[FieldOffset(Offset = "0x264")]
		public float float_43;

		// Token: 0x040008AF RID: 2223
		[FieldOffset(Offset = "0x268")]
		[Token(Token = "0x40008AF")]
		public float float_44;

		// Token: 0x040008B0 RID: 2224
		[Token(Token = "0x40008B0")]
		[FieldOffset(Offset = "0x26C")]
		public float float_45;

		// Token: 0x040008B1 RID: 2225
		[SerializeField]
		[FieldOffset(Offset = "0x270")]
		[Token(Token = "0x40008B1")]
		private float _crouchAmount;

		// Token: 0x040008B2 RID: 2226
		[FieldOffset(Offset = "0x274")]
		[Token(Token = "0x40008B2")]
		private float float_46;

		// Token: 0x040008B3 RID: 2227
		[Token(Token = "0x40008B3")]
		[FieldOffset(Offset = "0x278")]
		private float float_47;

		// Token: 0x040008B4 RID: 2228
		[Token(Token = "0x40008B4")]
		[FieldOffset(Offset = "0x27C")]
		private float float_48;

		// Token: 0x040008B5 RID: 2229
		[Token(Token = "0x40008B5")]
		[FieldOffset(Offset = "0x280")]
		private float float_49;

		// Token: 0x040008B6 RID: 2230
		[FieldOffset(Offset = "0x284")]
		[Token(Token = "0x40008B6")]
		private float float_50;

		// Token: 0x040008B7 RID: 2231
		[Token(Token = "0x40008B7")]
		[FieldOffset(Offset = "0x288")]
		private float float_51;

		// Token: 0x040008B8 RID: 2232
		[Token(Token = "0x40008B8")]
		[FieldOffset(Offset = "0x28C")]
		private float float_52;

		// Token: 0x040008B9 RID: 2233
		[FieldOffset(Offset = "0x290")]
		[Token(Token = "0x40008B9")]
		private float float_53;

		// Token: 0x040008BA RID: 2234
		[Token(Token = "0x40008BA")]
		[FieldOffset(Offset = "0x294")]
		private float float_54;

		// Token: 0x040008BB RID: 2235
		[FieldOffset(Offset = "0x298")]
		[Token(Token = "0x40008BB")]
		private float float_55;

		// Token: 0x040008BC RID: 2236
		[FieldOffset(Offset = "0x29C")]
		[Token(Token = "0x40008BC")]
		[Header("Misc")]
		[SerializeField]
		private float _groundAngle;

		// Token: 0x040008BD RID: 2237
		[Token(Token = "0x40008BD")]
		[FieldOffset(Offset = "0x2A0")]
		[SerializeField]
		private float _jumpTime;

		// Token: 0x040008BE RID: 2238
		[SerializeField]
		[Token(Token = "0x40008BE")]
		[FieldOffset(Offset = "0x2A4")]
		private float _actualSpeed;

		// Token: 0x040008BF RID: 2239
		[Token(Token = "0x40008BF")]
		[FieldOffset(Offset = "0x2A8")]
		[SerializeField]
		private float _standingPercent;

		// Token: 0x040008C0 RID: 2240
		[FieldOffset(Offset = "0x2AC")]
		[Token(Token = "0x40008C0")]
		private float float_56;

		// Token: 0x040008C1 RID: 2241
		[SerializeField]
		[Header("Velocities")]
		[FieldOffset(Offset = "0x2B0")]
		[Token(Token = "0x40008C1")]
		private float _verticalSpeed;

		// Token: 0x040008C2 RID: 2242
		[FieldOffset(Offset = "0x2B4")]
		[SerializeField]
		[Token(Token = "0x40008C2")]
		private float _locoAngularVelocity;

		// Token: 0x040008C3 RID: 2243
		[FieldOffset(Offset = "0x2B8")]
		[Token(Token = "0x40008C3")]
		[SerializeField]
		private float _targetAngularVelocity;

		// Token: 0x040008C4 RID: 2244
		[FieldOffset(Offset = "0x2BC")]
		[Token(Token = "0x40008C4")]
		public float float_57;

		// Token: 0x040008C5 RID: 2245
		[Token(Token = "0x40008C5")]
		[FieldOffset(Offset = "0x2C0")]
		private float float_58;

		// Token: 0x040008C6 RID: 2246
		[FieldOffset(Offset = "0x2C4")]
		[Token(Token = "0x40008C6")]
		private float float_59;

		// Token: 0x040008C7 RID: 2247
		[FieldOffset(Offset = "0x2C8")]
		[Token(Token = "0x40008C7")]
		private float float_60;

		// Token: 0x040008C8 RID: 2248
		[FieldOffset(Offset = "0x2CC")]
		[Token(Token = "0x40008C8")]
		private float float_61;

		// Token: 0x040008C9 RID: 2249
		[FieldOffset(Offset = "0x2D0")]
		[Token(Token = "0x40008C9")]
		private float float_62;

		// Token: 0x040008CA RID: 2250
		[FieldOffset(Offset = "0x2D4")]
		[Token(Token = "0x40008CA")]
		private float float_63;

		// Token: 0x040008CB RID: 2251
		[FieldOffset(Offset = "0x2D8")]
		[Token(Token = "0x40008CB")]
		private bool bool_5;

		// Token: 0x040008CC RID: 2252
		[Token(Token = "0x40008CC")]
		[FieldOffset(Offset = "0x2DC")]
		private float float_64;

		// Token: 0x040008CD RID: 2253
		[Token(Token = "0x40008CD")]
		[FieldOffset(Offset = "0x2E0")]
		private float float_65;

		// Token: 0x040008CE RID: 2254
		[Token(Token = "0x40008CE")]
		[FieldOffset(Offset = "0x2E4")]
		private bool bool_6;

		// Token: 0x040008CF RID: 2255
		[Token(Token = "0x40008CF")]
		[FieldOffset(Offset = "0x2E5")]
		private bool bool_7;

		// Token: 0x040008D0 RID: 2256
		[FieldOffset(Offset = "0x2E8")]
		[Token(Token = "0x40008D0")]
		protected GEnum19 genum19_0;

		// Token: 0x040008D1 RID: 2257
		[Token(Token = "0x40008D1")]
		[FieldOffset(Offset = "0x2EC")]
		protected Vector3 vector3_0;

		// Token: 0x040008D2 RID: 2258
		[Token(Token = "0x40008D2")]
		[FieldOffset(Offset = "0x2F8")]
		private Vector3 vector3_1;

		// Token: 0x040008D3 RID: 2259
		[FieldOffset(Offset = "0x304")]
		[Token(Token = "0x40008D3")]
		private Vector3 vector3_2;

		// Token: 0x040008D4 RID: 2260
		[FieldOffset(Offset = "0x310")]
		[Token(Token = "0x40008D4")]
		private float float_66;

		// Token: 0x040008D5 RID: 2261
		[Token(Token = "0x40008D5")]
		[FieldOffset(Offset = "0x314")]
		private float float_67;

		// Token: 0x040008D6 RID: 2262
		[Token(Token = "0x40008D6")]
		[FieldOffset(Offset = "0x318")]
		private float float_68;

		// Token: 0x040008D7 RID: 2263
		[FieldOffset(Offset = "0x320")]
		[Token(Token = "0x40008D7")]
		private WaitForFixedUpdate waitForFixedUpdate_0;

		// Token: 0x040008D8 RID: 2264
		[FieldOffset(Offset = "0x328")]
		[Token(Token = "0x40008D8")]
		private float float_69;

		// Token: 0x040008D9 RID: 2265
		[Token(Token = "0x40008D9")]
		[FieldOffset(Offset = "0x32C")]
		private float float_70;

		// Token: 0x040008DA RID: 2266
		[Token(Token = "0x40008DA")]
		[FieldOffset(Offset = "0x330")]
		private float float_71;

		// Token: 0x040008DB RID: 2267
		[Token(Token = "0x40008DB")]
		[FieldOffset(Offset = "0x334")]
		private float float_72;

		// Token: 0x040008DC RID: 2268
		[Token(Token = "0x40008DC")]
		[FieldOffset(Offset = "0x338")]
		private float float_73;

		// Token: 0x040008DD RID: 2269
		[Token(Token = "0x40008DD")]
		[FieldOffset(Offset = "0x33C")]
		private float float_74;

		// Token: 0x040008DE RID: 2270
		[FieldOffset(Offset = "0x340")]
		[Token(Token = "0x40008DE")]
		private bool bool_8;

		// Token: 0x040008DF RID: 2271
		[FieldOffset(Offset = "0x344")]
		[Token(Token = "0x40008DF")]
		protected float float_75;

		// Token: 0x040008E0 RID: 2272
		[FieldOffset(Offset = "0x348")]
		[SerializeField]
		[Token(Token = "0x40008E0")]
		private float _jumpTimer;

		// Token: 0x040008E1 RID: 2273
		[Token(Token = "0x40008E1")]
		[FieldOffset(Offset = "0x34C")]
		private float float_76;

		// Token: 0x040008E2 RID: 2274
		[FieldOffset(Offset = "0x350")]
		[Token(Token = "0x40008E2")]
		private bool bool_9;

		// Token: 0x040008E3 RID: 2275
		[Token(Token = "0x40008E3")]
		[FieldOffset(Offset = "0x358")]
		private ConfigurableJoint configurableJoint_3;

		// Token: 0x040008E4 RID: 2276
		[Token(Token = "0x40008E4")]
		[FieldOffset(Offset = "0x360")]
		private ConfigurableJoint configurableJoint_4;

		// Token: 0x040008E5 RID: 2277
		[Token(Token = "0x40008E5")]
		[FieldOffset(Offset = "0x368")]
		private LocoBallCollision locoBallCollision_0;

		// Token: 0x040008E6 RID: 2278
		[FieldOffset(Offset = "0x370")]
		[Token(Token = "0x40008E6")]
		private float float_77;

		// Token: 0x040008E7 RID: 2279
		[FieldOffset(Offset = "0x374")]
		[SerializeField]
		[Token(Token = "0x40008E7")]
		private GEnum20 _jumpStage;

		// Token: 0x040008E8 RID: 2280
		[FieldOffset(Offset = "0x378")]
		[Token(Token = "0x40008E8")]
		private bool bool_10;

		// Token: 0x040008E9 RID: 2281
		[FieldOffset(Offset = "0x37C")]
		[Token(Token = "0x40008E9")]
		private JointDrive jointDrive_0;

		// Token: 0x040008EA RID: 2282
		[Token(Token = "0x40008EA")]
		[FieldOffset(Offset = "0x388")]
		private bool bool_11;

		// Token: 0x040008EB RID: 2283
		[Token(Token = "0x40008EB")]
		[FieldOffset(Offset = "0x389")]
		private bool bool_12;

		// Token: 0x040008EC RID: 2284
		[Token(Token = "0x40008EC")]
		[FieldOffset(Offset = "0x38A")]
		public bool bool_13;

		// Token: 0x040008ED RID: 2285
		[FieldOffset(Offset = "0x38B")]
		[Token(Token = "0x40008ED")]
		private bool bool_14;

		// Token: 0x040008EE RID: 2286
		[Token(Token = "0x40008EE")]
		[FieldOffset(Offset = "0x38C")]
		private float float_78;

		// Token: 0x040008EF RID: 2287
		[FieldOffset(Offset = "0x390")]
		[Token(Token = "0x40008EF")]
		private float float_79;

		// Token: 0x040008F0 RID: 2288
		[CompilerGenerated]
		[Token(Token = "0x40008F0")]
		[FieldOffset(Offset = "0x394")]
		private bool bool_15;

		// Token: 0x040008F1 RID: 2289
		[Token(Token = "0x40008F1")]
		[CompilerGenerated]
		[FieldOffset(Offset = "0x398")]
		private float float_80;

		// Token: 0x040008F2 RID: 2290
		[CompilerGenerated]
		[Token(Token = "0x40008F2")]
		[FieldOffset(Offset = "0x39C")]
		private Vector3 vector3_3;

		// Token: 0x040008F3 RID: 2291
		[FieldOffset(Offset = "0x3A8")]
		[Token(Token = "0x40008F3")]
		[CompilerGenerated]
		private Quaternion quaternion_0;

		// Token: 0x040008F4 RID: 2292
		[FieldOffset(Offset = "0x3B8")]
		[CompilerGenerated]
		[Token(Token = "0x40008F4")]
		private HexaBodyInputsBase hexaBodyInputsBase_0;

		// Token: 0x040008F5 RID: 2293
		[CompilerGenerated]
		[Token(Token = "0x40008F5")]
		[FieldOffset(Offset = "0x3C0")]
		private Transform transform_17;

		// Token: 0x040008F6 RID: 2294
		[FieldOffset(Offset = "0x3C8")]
		[Token(Token = "0x40008F6")]
		[CompilerGenerated]
		private bool bool_16;

		// Token: 0x040008F7 RID: 2295
		[Token(Token = "0x40008F7")]
		[FieldOffset(Offset = "0x3CC")]
		public float float_81;

		// Token: 0x040008F8 RID: 2296
		[Token(Token = "0x40008F8")]
		[FieldOffset(Offset = "0x3D0")]
		[CompilerGenerated]
		private float float_82;

		// Token: 0x040008F9 RID: 2297
		[Token(Token = "0x40008F9")]
		[FieldOffset(Offset = "0x3D4")]
		private float float_83;
	}
}
