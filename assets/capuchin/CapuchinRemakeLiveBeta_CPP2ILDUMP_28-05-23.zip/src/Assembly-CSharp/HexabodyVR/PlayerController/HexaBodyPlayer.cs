﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000141 RID: 321
	[Token(Token = "0x2000141")]
	public class HexaBodyPlayer : MonoBehaviour
	{
		// Token: 0x06003445 RID: 13381 RVA: 0x00067934 File Offset: 0x00065B34
		[Address(RVA = "0x3397D3C", Offset = "0x3397D3C", VA = "0x3397D3C")]
		[Token(Token = "0x6003445")]
		public float method_0()
		{
		}

		// Token: 0x06003446 RID: 13382 RVA: 0x0000320A File Offset: 0x0000140A
		[Address(RVA = "0x3397D4C", Offset = "0x3397D4C", VA = "0x3397D4C")]
		[Token(Token = "0x6003446")]
		public HexaBodyPlayerInputs method_1()
		{
			return this.hexaBodyPlayerInputs_0;
		}

		// Token: 0x06003447 RID: 13383 RVA: 0x00067944 File Offset: 0x00065B44
		[Address(RVA = "0x3397D54", Offset = "0x3397D54", VA = "0x3397D54")]
		[Token(Token = "0x6003447")]
		private void method_2(bool bool_5)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x06003448 RID: 13384 RVA: 0x0006797C File Offset: 0x00065B7C
		[Address(RVA = "0x3397DEC", Offset = "0x3397DEC", VA = "0x3397DEC")]
		[Token(Token = "0x6003448")]
		public Quaternion method_3()
		{
		}

		// Token: 0x06003449 RID: 13385 RVA: 0x0000320A File Offset: 0x0000140A
		[Address(RVA = "0x3397E00", Offset = "0x3397E00", VA = "0x3397E00")]
		[Token(Token = "0x6003449")]
		public HexaBodyPlayerInputs method_4()
		{
			return this.hexaBodyPlayerInputs_0;
		}

		// Token: 0x0600344A RID: 13386 RVA: 0x0006798C File Offset: 0x00065B8C
		[Address(RVA = "0x3397E08", Offset = "0x3397E08", VA = "0x3397E08")]
		[Token(Token = "0x600344A")]
		private Vector2 method_5()
		{
		}

		// Token: 0x0600344B RID: 13387 RVA: 0x0006799C File Offset: 0x00065B9C
		[Address(RVA = "0x3397EAC", Offset = "0x3397EAC", VA = "0x3397EAC")]
		[Token(Token = "0x600344B")]
		private void method_6()
		{
			while (this.hexaBodyPlayerInputs_0.playerInputState_1.JustActivated)
			{
				float deltaTime = Time.deltaTime;
				if (this.bool_4 && this.hexaBodyPlayerInputs_0.playerInputState_0.JustActivated)
				{
					return;
				}
				if (this.hexaBodyPlayerInputs_0.playerInputState_1 != null)
				{
					return;
				}
			}
			if (this.hexaBodyPlayerInputs_0.playerInputState_2.JustActivated)
			{
				throw new MissingMethodException();
			}
			throw new MissingMethodException();
		}

		// Token: 0x0600344C RID: 13388 RVA: 0x00003212 File Offset: 0x00001412
		[Address(RVA = "0x33982C8", Offset = "0x33982C8", VA = "0x33982C8")]
		[Token(Token = "0x600344C")]
		public void method_7(bool bool_5)
		{
			this.method_41();
		}

		// Token: 0x0600344D RID: 13389 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		[Address(RVA = "0x3398320", Offset = "0x3398320", VA = "0x3398320")]
		[Token(Token = "0x600344D")]
		public Vector3 method_8()
		{
			Vector3 result;
			return result;
		}

		// Token: 0x0600344E RID: 13390 RVA: 0x00067A0C File Offset: 0x00065C0C
		[Address(RVA = "0x3398330", Offset = "0x3398330", VA = "0x3398330")]
		[Token(Token = "0x600344E")]
		public void method_9()
		{
			float num = this.float_35;
			float num2 = this.float_42;
			this.float_43 = num;
			this.float_44 = num2;
			this.float_45 = num2;
			float single_ = this.Single_0;
			float single_2 = this.Single_0;
		}

		// Token: 0x0600344F RID: 13391 RVA: 0x00067A4C File Offset: 0x00065C4C
		[Address(RVA = "0x33984AC", Offset = "0x33984AC", VA = "0x33984AC")]
		[Token(Token = "0x600344F")]
		private void FixedUpdate()
		{
			Rigidbody rigidbody = this.rigidbody_0;
			Vector3 position = rigidbody.position;
			Vector3 up = Vector3.up;
			HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs != null)
			{
			}
			float x = this.float_12;
			Vector3 up2 = Vector3.up;
			bool flag = this.bool_4;
			ConfigurableJoint configurableJoint = this.configurableJoint_1;
			if (flag)
			{
				Vector3 anchor = configurableJoint.anchor;
				float fixedDeltaTime = Time.fixedDeltaTime;
				return;
			}
			Vector3 zero = Vector3.zero;
			Vector3 anchor2 = this.configurableJoint_1.anchor;
			Rigidbody rigidbody2 = this.rigidbody_1;
			this.vector3_5.x = x;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			Vector3 position2 = rigidbody2.position;
			Vector3 position3 = this.rigidbody_0.position;
			float height;
			capsuleCollider.height = height;
			float height2 = this.capsuleCollider_0.height;
			this.method_44();
			this.method_17();
			this.method_48();
			Quaternion rotation = this.transform_0.rotation;
			Rigidbody rigidbody3 = this.rigidbody_1;
			this.vector3_2.x = x;
			Vector3 position4 = rigidbody3.position;
			Vector3 position5 = this.rigidbody_1.position;
			Color red = Color.red;
			float num = this.float_7;
			this.float_48 = num;
			Transform transform = base.transform;
			JointDrive yDrive = this.configurableJoint_1.yDrive;
			if (this._legStage == GEnum17.const_0)
			{
				yDrive.positionSpring = height2;
				yDrive.positionDamper = height2;
				yDrive.maximumForce = height2;
			}
		}

		// Token: 0x06003450 RID: 13392 RVA: 0x00067B98 File Offset: 0x00065D98
		[Address(RVA = "0x3398EB8", Offset = "0x3398EB8", VA = "0x3398EB8")]
		[Token(Token = "0x6003450")]
		public void method_10()
		{
			float num = this.float_35;
			float num2 = this.float_42;
			this.float_43 = num;
			this.float_44 = num2;
			this.float_45 = num2;
			float single_ = this.Single_0;
			this.method_53();
		}

		// Token: 0x06003451 RID: 13393 RVA: 0x00067BD8 File Offset: 0x00065DD8
		[Address(RVA = "0x3399030", Offset = "0x3399030", VA = "0x3399030")]
		[Token(Token = "0x6003451")]
		private void method_11(GEnum16 genum16_0)
		{
			this._crouchLevel = genum16_0;
		}

		// Token: 0x06003452 RID: 13394 RVA: 0x00067BEC File Offset: 0x00065DEC
		[Address(RVA = "0x33990AC", Offset = "0x33990AC", VA = "0x33990AC")]
		[Token(Token = "0x6003452")]
		private void method_12()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 right = this.transform_0.right;
			if (this.hexaBodyPlayerInputs_0.playerInputState_0.JustDeactivated && this.bool_4)
			{
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06003453 RID: 13395 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		// (set) Token: 0x06003468 RID: 13416 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x17000094")]
		public Vector3 Vector3_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x3399140", Offset = "0x3399140", VA = "0x3399140")]
			[Token(Token = "0x6003453")]
			get
			{
				Vector3 result;
				return result;
			}
			[CompilerGenerated]
			[Address(RVA = "0x3399FEC", Offset = "0x3399FEC", VA = "0x3399FEC")]
			[Token(Token = "0x6003468")]
			private set
			{
			}
		}

		// Token: 0x06003454 RID: 13396 RVA: 0x00067C38 File Offset: 0x00065E38
		[Address(RVA = "0x3399150", Offset = "0x3399150", VA = "0x3399150")]
		[Token(Token = "0x6003454")]
		private Vector2 method_13()
		{
			/*
An exception occurred when decompiling this method (06003454)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyPlayer::method_13()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(84)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(83)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003455 RID: 13397 RVA: 0x00067C54 File Offset: 0x00065E54
		[Address(RVA = "0x33991F4", Offset = "0x33991F4", VA = "0x33991F4")]
		[Token(Token = "0x6003455")]
		private void method_14()
		{
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = Vector3.up;
			float defaultContactOffset = Physics.defaultContactOffset;
			float radius = this.sphereCollider_0.radius;
			float defaultContactOffset2 = Physics.defaultContactOffset;
			Vector3 down = Vector3.down;
			Vector3 up2 = Vector3.up;
			Vector3 up3 = Vector3.up;
		}

		// Token: 0x06003456 RID: 13398 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x33993B8", Offset = "0x33993B8", VA = "0x33993B8")]
		[Token(Token = "0x6003456")]
		private void method_15(Vector3 vector3_6)
		{
		}

		// Token: 0x06003457 RID: 13399 RVA: 0x00067CA0 File Offset: 0x00065EA0
		[Address(RVA = "0x33993C8", Offset = "0x33993C8", VA = "0x33993C8")]
		[Token(Token = "0x6003457")]
		private void method_16()
		{
			float magnitude = this.method_5().magnitude;
			Rigidbody rigidbody = this.rigidbody_0;
			long freezeRotation = 0L;
			rigidbody.freezeRotation = (freezeRotation != 0L);
			AnimationCurve animationCurve = this.animationCurve_0;
			animationCurve.Evaluate(magnitude);
			float radius = this.sphereCollider_0.radius;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			Vector3 angularVelocity = this.rigidbody_0.angularVelocity;
			if (this.bool_4)
			{
				Vector3 velocity = this.rigidbody_0.velocity;
			}
			float time2;
			float time = this.animationCurve_2.Evaluate(time2);
			AnimationCurve animationCurve2 = this.animationCurve_1;
			animationCurve2.Evaluate(time);
			this.method_24();
			float groundAngle;
			if (this.bool_4)
			{
				groundAngle = this._groundAngle;
				Vector3 angularVelocity2 = this.rigidbody_0.angularVelocity;
				float magnitude2 = this.rigidbody_0.angularVelocity.magnitude;
				Rigidbody rigidbody2 = this.rigidbody_0;
				long freezeRotation2 = 0L;
				rigidbody2.freezeRotation = (freezeRotation2 != 0L);
				Vector3 zero = Vector3.zero;
			}
			Vector3 position = this.rigidbody_1.position;
			float fixedDeltaTime = Time.fixedDeltaTime;
			Vector3 position2 = this.rigidbody_1.position;
			this._previousPosition.x = groundAngle;
			float magnitude3 = position2.magnitude;
			this._actualSpeed = groundAngle;
		}

		// Token: 0x06003458 RID: 13400 RVA: 0x00067DC4 File Offset: 0x00065FC4
		[Address(RVA = "0x3398AA0", Offset = "0x3398AA0", VA = "0x3398AA0")]
		[Token(Token = "0x6003458")]
		private void method_17()
		{
			if (this.bool_1 && this.bool_4)
			{
				IEnumerator routine = this.method_39();
				Coroutine coroutine = base.StartCoroutine(routine);
				this.coroutine_1 = coroutine;
				return;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06003459 RID: 13401 RVA: 0x0000321A File Offset: 0x0000141A
		// (set) Token: 0x06003461 RID: 13409 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x17000096")]
		public bool Boolean_1
		{
			[CompilerGenerated]
			[Address(RVA = "0x3399C44", Offset = "0x3399C44", VA = "0x3399C44")]
			[Token(Token = "0x6003459")]
			get
			{
				return this.bool_4;
			}
			[CompilerGenerated]
			[Address(RVA = "0x3399DA4", Offset = "0x3399DA4", VA = "0x3399DA4")]
			[Token(Token = "0x6003461")]
			set
			{
			}
		}

		// Token: 0x0600345A RID: 13402 RVA: 0x00067DF8 File Offset: 0x00065FF8
		[Address(RVA = "0x3399C4C", Offset = "0x3399C4C", VA = "0x3399C4C")]
		[Token(Token = "0x600345A")]
		private Vector2 method_18()
		{
			Input.GetKey(KeyCode.W);
			Input.GetKey(KeyCode.S);
			Input.GetKey(KeyCode.A);
			Input.GetKey(KeyCode.D);
			Vector2 result;
			return result;
		}

		// Token: 0x0600345B RID: 13403 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		[Address(RVA = "0x3399CD4", Offset = "0x3399CD4", VA = "0x3399CD4")]
		[Token(Token = "0x600345B")]
		public Vector3 method_19()
		{
			Vector3 result;
			return result;
		}

		// Token: 0x0600345C RID: 13404 RVA: 0x00067E28 File Offset: 0x00066028
		[Address(RVA = "0x3399CE4", Offset = "0x3399CE4", VA = "0x3399CE4")]
		[Token(Token = "0x600345C")]
		public void method_20(float float_57)
		{
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x0600345D RID: 13405 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		// (set) Token: 0x06003497 RID: 13463 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x17000095")]
		public Vector3 Vector3_1
		{
			[CompilerGenerated]
			[Address(RVA = "0x3399D48", Offset = "0x3399D48", VA = "0x3399D48")]
			[Token(Token = "0x600345D")]
			get
			{
				Vector3 result;
				return result;
			}
			[CompilerGenerated]
			[Address(RVA = "0x339BBD8", Offset = "0x339BBD8", VA = "0x339BBD8")]
			[Token(Token = "0x6003497")]
			private set
			{
			}
		}

		// Token: 0x0600345E RID: 13406 RVA: 0x00067E38 File Offset: 0x00066038
		[Address(RVA = "0x3399D58", Offset = "0x3399D58", VA = "0x3399D58")]
		[Token(Token = "0x600345E")]
		private void method_21(GEnum16 genum16_0)
		{
			this.method_11(genum16_0);
		}

		// Token: 0x0600345F RID: 13407 RVA: 0x0006797C File Offset: 0x00065B7C
		[Address(RVA = "0x3399D80", Offset = "0x3399D80", VA = "0x3399D80")]
		[Token(Token = "0x600345F")]
		public Quaternion method_22()
		{
		}

		// Token: 0x06003460 RID: 13408 RVA: 0x00003222 File Offset: 0x00001422
		[Address(RVA = "0x3399D94", Offset = "0x3399D94", VA = "0x3399D94")]
		[Token(Token = "0x6003460")]
		private void method_23(HexaBodyPlayerInputs hexaBodyPlayerInputs_1)
		{
			this.hexaBodyPlayerInputs_0 = hexaBodyPlayerInputs_1;
		}

		// Token: 0x06003462 RID: 13410 RVA: 0x00067E4C File Offset: 0x0006604C
		[Address(RVA = "0x33997A0", Offset = "0x33997A0", VA = "0x33997A0")]
		[Token(Token = "0x6003462")]
		private bool method_24()
		{
			this.method_35();
			float z = this.vector3_0.z;
			Transform transform = this.transform_0;
			this.vector3_1.z = z;
			Vector3 position = transform.transform.position;
			float magnitude = this.rigidbody_1.transform.position.normalized.magnitude;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float x = this.quaternion_0.x;
			float y = this.quaternion_0.y;
			float z2 = this.quaternion_0.z;
			Vector3 position2 = this.rigidbody_0.position;
			Vector3 position3 = this.rigidbody_2.position;
			Vector3 position4 = this.rigidbody_3.position;
			Vector3 position5 = this.rigidbody_1.position;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			HexaCameraRig hexaCameraRig = this.hexaCameraRig_0;
			this._lastCameraDirection.x = x;
			this._lastCameraDirection.y = y;
			this._lastCameraDirection.z = z2;
			Vector3 localPosition = hexaCameraRig.transform.localPosition;
			Transform transform2 = this.rigidbody_1.transform;
			Color blue = Color.blue;
			throw new NullReferenceException();
		}

		// Token: 0x06003463 RID: 13411 RVA: 0x00067F68 File Offset: 0x00066168
		[Address(RVA = "0x3399EC0", Offset = "0x3399EC0", VA = "0x3399EC0")]
		[Token(Token = "0x6003463")]
		private void method_25()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 right = this.transform_0.right;
			Input.GetKeyUp(KeyCode.Alpha2);
			if (this.hexaBodyPlayerInputs_0.playerInputState_0.JustDeactivated && this.bool_4)
			{
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06003464 RID: 13412 RVA: 0x00067FB8 File Offset: 0x000661B8
		[Address(RVA = "0x3399F54", Offset = "0x3399F54", VA = "0x3399F54")]
		[Token(Token = "0x6003464")]
		public void method_26(float float_57)
		{
			GEnum18 genum = this.genum18_0;
			if (genum != GEnum18.const_0)
			{
				return;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06003465 RID: 13413 RVA: 0x00067FD0 File Offset: 0x000661D0
		[Token(Token = "0x17000097")]
		public float Single_0
		{
			[Address(RVA = "0x339844C", Offset = "0x339844C", VA = "0x339844C")]
			[Token(Token = "0x6003465")]
			get
			{
				Transform transform = this.transform_0;
				Vector3 localPosition = transform.localPosition;
				throw new NullReferenceException();
			}
		}

		// Token: 0x06003466 RID: 13414 RVA: 0x00067FF0 File Offset: 0x000661F0
		[Address(RVA = "0x3399FB4", Offset = "0x3399FB4", VA = "0x3399FB4")]
		[Token(Token = "0x6003466")]
		private void method_27(GEnum16 genum16_0)
		{
			this.method_59(genum16_0);
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06003481 RID: 13441 RVA: 0x0000320A File Offset: 0x0000140A
		// (set) Token: 0x06003467 RID: 13415 RVA: 0x00003222 File Offset: 0x00001422
		[Token(Token = "0x17000093")]
		public HexaBodyPlayerInputs HexaBodyPlayerInputs_0 { [Address(RVA = "0x339AAF8", Offset = "0x339AAF8", VA = "0x339AAF8")] [Token(Token = "0x6003481")] get; [Address(RVA = "0x3399FDC", Offset = "0x3399FDC", VA = "0x3399FDC")] [Token(Token = "0x6003467")] private set; }

		// Token: 0x06003469 RID: 13417 RVA: 0x00068004 File Offset: 0x00066204
		[Address(RVA = "0x3399FFC", Offset = "0x3399FFC", VA = "0x3399FFC")]
		[Token(Token = "0x6003469")]
		private IEnumerator method_28()
		{
			HexaBodyPlayer.Class44 @class = new HexaBodyPlayer.Class44((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x0600346A RID: 13418 RVA: 0x00067E28 File Offset: 0x00066028
		[Address(RVA = "0x339A074", Offset = "0x339A074", VA = "0x339A074")]
		[Token(Token = "0x600346A")]
		public void method_29(float float_57)
		{
		}

		// Token: 0x0600346B RID: 13419 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x339A0D4", Offset = "0x339A0D4", VA = "0x339A0D4")]
		[Token(Token = "0x600346B")]
		private void method_30(Quaternion quaternion_1)
		{
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x0600348B RID: 13451 RVA: 0x0000322B File Offset: 0x0000142B
		// (set) Token: 0x0600346C RID: 13420 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x17000091")]
		public bool Boolean_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x339B4B8", Offset = "0x339B4B8", VA = "0x339B4B8")]
			[Token(Token = "0x600348B")]
			get
			{
				return this.bool_3;
			}
			[CompilerGenerated]
			[Address(RVA = "0x339A0E8", Offset = "0x339A0E8", VA = "0x339A0E8")]
			[Token(Token = "0x600346C")]
			set
			{
			}
		}

		// Token: 0x0600346D RID: 13421 RVA: 0x0006802C File Offset: 0x0006622C
		[Address(RVA = "0x339A0F4", Offset = "0x339A0F4", VA = "0x339A0F4", Slot = "4")]
		[Token(Token = "0x600346D")]
		protected virtual void vmethod_0()
		{
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_2)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					if (hexaBodyPlayerInputs == null)
					{
						return;
					}
				}
				else if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_2)
					{
						long num = 1L;
						this.bool_3 = (num != 0L);
						return;
					}
					long num2 = 1L;
					this.bool_2 = (num2 != 0L);
				}
			}
			else
			{
				bool flag2 = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs;
				bool flag3 = hexaBodyPlayerInputs.bool_2;
				long num;
				if (flag2)
				{
					if (flag3)
					{
						return;
					}
				}
				else if (num != 0L)
				{
					long num3 = 1L;
					this.bool_3 = (num3 != 0L);
					return;
				}
			}
		}

		// Token: 0x0600346E RID: 13422 RVA: 0x000680C0 File Offset: 0x000662C0
		[Address(RVA = "0x339A1E4", Offset = "0x339A1E4", VA = "0x339A1E4")]
		[Token(Token = "0x600346E")]
		private void method_31()
		{
			if (this.hexaBodyPlayerInputs_0.bool_3)
			{
				this.method_41();
			}
			float num = this.float_7;
			float radius = this.sphereCollider_0.radius;
			Rigidbody rigidbody = this.rigidbody_2;
			this.float_36 = num;
			Vector3 position = rigidbody.position;
			Vector3 position2 = this.rigidbody_0.position;
			float num2 = this.float_36;
			this.float_54 = num2;
			Mathf.Clamp01(radius);
			Rigidbody rigidbody2 = this.rigidbody_1;
			this.float_54 = num2;
			Vector3 position3 = rigidbody2.position;
			Vector3 position4 = this.rigidbody_0.position;
			this.float_34 = num2;
			this.method_6();
			this.method_45();
			this.method_12();
			Transform transform = this.transform_4;
			Vector3 position5 = transform.position;
			Vector3 position6 = this.rigidbody_3.position;
			Vector3 position7 = this.transform_4.position;
			Rigidbody rigidbody3 = this.rigidbody_3;
			CapsuleCollider capsuleCollider = this.capsuleCollider_2;
			Vector3 position8 = rigidbody3.position;
			Vector3 position9 = this.transform_4.position;
			float height;
			capsuleCollider.height = height;
			Vector3 position10 = this.rigidbody_3.position;
			Vector3 position11 = this.transform_2.position;
			Vector3 up = this.transform_2.up;
			Transform transform2 = this.transform_2.transform;
			Quaternion rotation = this.transform_2.transform.rotation;
		}

		// Token: 0x0600346F RID: 13423 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x339A608", Offset = "0x339A608", VA = "0x339A608")]
		[Token(Token = "0x600346F")]
		private void method_32(Vector3 vector3_6)
		{
		}

		// Token: 0x06003470 RID: 13424 RVA: 0x00068200 File Offset: 0x00066400
		[Address(RVA = "0x339A618", Offset = "0x339A618", VA = "0x339A618")]
		[Token(Token = "0x6003470")]
		public HexaBodyPlayer()
		{
			long num = 2L;
			this.forceMode_0 = (ForceMode)num;
			long num2 = 1L;
			this.genum18_0 = (GEnum18)num2;
			this.bool_0 = (num2 != 0L);
			this.float_17 = (float)16384;
			this.float_31 = (float)31457;
			this.float_49 = (float)39322;
			base..ctor();
		}

		// Token: 0x06003471 RID: 13425 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x339A6E8", Offset = "0x339A6E8", VA = "0x339A6E8")]
		[Token(Token = "0x6003471")]
		private void method_33(Quaternion quaternion_1)
		{
		}

		// Token: 0x06003472 RID: 13426 RVA: 0x00068250 File Offset: 0x00066450
		[Address(RVA = "0x339A6FC", Offset = "0x339A6FC", VA = "0x339A6FC")]
		[Token(Token = "0x6003472")]
		private void method_34()
		{
			if (this.bool_1 && this.bool_4)
			{
				IEnumerator routine = this.method_28();
				Coroutine coroutine = base.StartCoroutine(routine);
				this.coroutine_1 = coroutine;
				return;
			}
		}

		// Token: 0x06003473 RID: 13427 RVA: 0x00068284 File Offset: 0x00066484
		[Address(RVA = "0x3399DB0", Offset = "0x3399DB0", VA = "0x3399DB0")]
		[Token(Token = "0x6003473")]
		private void method_35()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 up = Vector3.up;
			Quaternion quaternion;
			Vector3 eulerAngles = quaternion.eulerAngles;
			Vector3 eulerAngles2 = this.transform_3.transform.eulerAngles;
			Vector3 eulerAngles3 = this.transform_3.transform.eulerAngles;
			Transform transform = this.transform_3.transform;
		}

		// Token: 0x06003474 RID: 13428 RVA: 0x000682DC File Offset: 0x000664DC
		[Address(RVA = "0x339A75C", Offset = "0x339A75C", VA = "0x339A75C")]
		[Token(Token = "0x6003474")]
		private void method_36()
		{
			Vector3 zero = Vector3.zero;
		}

		// Token: 0x06003475 RID: 13429 RVA: 0x000682F0 File Offset: 0x000664F0
		[Address(RVA = "0x339A7B4", Offset = "0x339A7B4", VA = "0x339A7B4")]
		[Token(Token = "0x6003475")]
		private IEnumerator method_37(float float_57)
		{
			HexaBodyPlayer.Class45 @class = new HexaBodyPlayer.Class45((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003476 RID: 13430 RVA: 0x0006797C File Offset: 0x00065B7C
		[Address(RVA = "0x339A83C", Offset = "0x339A83C", VA = "0x339A83C")]
		[Token(Token = "0x6003476")]
		public Quaternion method_38()
		{
		}

		// Token: 0x06003477 RID: 13431 RVA: 0x00068004 File Offset: 0x00066204
		[Address(RVA = "0x3399BCC", Offset = "0x3399BCC", VA = "0x3399BCC")]
		[Token(Token = "0x6003477")]
		private IEnumerator method_39()
		{
			HexaBodyPlayer.Class44 @class = new HexaBodyPlayer.Class44((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003478 RID: 13432 RVA: 0x00068318 File Offset: 0x00066518
		[Address(RVA = "0x339A850", Offset = "0x339A850", VA = "0x339A850")]
		[Token(Token = "0x6003478")]
		public void method_40(bool bool_5)
		{
			long num = 1L;
			this.genum18_0 = (GEnum18)num;
			this.method_41();
		}

		// Token: 0x06003479 RID: 13433 RVA: 0x00068334 File Offset: 0x00066534
		[Address(RVA = "0x339A86C", Offset = "0x339A86C", VA = "0x339A86C")]
		[Token(Token = "0x6003479")]
		private void Start()
		{
		}

		// Token: 0x0600347A RID: 13434 RVA: 0x00068344 File Offset: 0x00066544
		[Address(RVA = "0x33982E8", Offset = "0x33982E8", VA = "0x33982E8")]
		[Token(Token = "0x600347A")]
		public void method_41()
		{
			Vector3 localPosition = this.transform_0.localPosition;
		}

		// Token: 0x0600347B RID: 13435 RVA: 0x00068360 File Offset: 0x00066560
		[Address(RVA = "0x3399B8C", Offset = "0x3399B8C", VA = "0x3399B8C")]
		[Token(Token = "0x600347B")]
		private void method_42(Rigidbody rigidbody_4)
		{
			Vector3 velocity = rigidbody_4.velocity;
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x0600347C RID: 13436 RVA: 0x00067934 File Offset: 0x00065B34
		[Token(Token = "0x17000098")]
		public float Single_1
		{
			[Address(RVA = "0x339849C", Offset = "0x339849C", VA = "0x339849C")]
			[Token(Token = "0x600347C")]
			get
			{
			}
		}

		// Token: 0x0600347D RID: 13437 RVA: 0x00068374 File Offset: 0x00066574
		[Address(RVA = "0x339A970", Offset = "0x339A970", VA = "0x339A970", Slot = "5")]
		[Token(Token = "0x600347D")]
		protected virtual void vmethod_1()
		{
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_2)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					if (hexaBodyPlayerInputs == null)
					{
						return;
					}
				}
				else if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_2)
					{
						long num = 1L;
						this.bool_3 = (num != 0L);
						return;
					}
					this.float_56 = (float)16384;
				}
			}
			else
			{
				bool flag2 = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs;
				bool flag3 = hexaBodyPlayerInputs.bool_2;
				long num;
				if (flag2)
				{
					if (flag3)
					{
						return;
					}
				}
				else if (num != 0L)
				{
					long num2 = 1L;
					this.bool_3 = (num2 != 0L);
					return;
				}
			}
		}

		// Token: 0x0600347E RID: 13438 RVA: 0x00067944 File Offset: 0x00065B44
		[Address(RVA = "0x339AA60", Offset = "0x339AA60", VA = "0x339AA60")]
		[Token(Token = "0x600347E")]
		private void method_43(bool bool_5)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x0600347F RID: 13439 RVA: 0x00068408 File Offset: 0x00066608
		[Address(RVA = "0x33988DC", Offset = "0x33988DC", VA = "0x33988DC")]
		[Token(Token = "0x600347F")]
		private void method_44()
		{
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = Vector3.up;
			float defaultContactOffset = Physics.defaultContactOffset;
			float radius = this.sphereCollider_0.radius;
			float defaultContactOffset2 = Physics.defaultContactOffset;
			Vector3 down = Vector3.down;
			LayerMask mask = this.layerMask_0;
			mask;
			Vector3 up2 = Vector3.up;
			Vector3 up3 = Vector3.up;
		}

		// Token: 0x06003480 RID: 13440 RVA: 0x00068464 File Offset: 0x00066664
		[Address(RVA = "0x339A4E0", Offset = "0x339A4E0", VA = "0x339A4E0")]
		[Token(Token = "0x6003480")]
		public void method_45()
		{
			float num = this.float_35;
			float num2 = this.float_42;
			this.float_43 = num;
			this.float_44 = num2;
			this.float_45 = num2;
			this.method_53();
			this.method_53();
		}

		// Token: 0x06003482 RID: 13442 RVA: 0x00067BEC File Offset: 0x00065DEC
		[Address(RVA = "0x339AB00", Offset = "0x339AB00", VA = "0x339AB00")]
		[Token(Token = "0x6003482")]
		private void method_46()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 right = this.transform_0.right;
			if (this.hexaBodyPlayerInputs_0.playerInputState_0.JustDeactivated && this.bool_4)
			{
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x06003483 RID: 13443 RVA: 0x000684A4 File Offset: 0x000666A4
		[Address(RVA = "0x3398220", Offset = "0x3398220", VA = "0x3398220")]
		[Token(Token = "0x6003483")]
		private void method_47(float float_57)
		{
			float num = this.float_7;
			float single_ = this.Single_0;
			this.float_42 = num;
			this.float_42 = num;
			this.float_41 = num;
			this.float_39 = num;
			this.float_39 = num;
			this.float_40 = num;
		}

		// Token: 0x06003484 RID: 13444 RVA: 0x000684EC File Offset: 0x000666EC
		[Address(RVA = "0x339AB94", Offset = "0x339AB94", VA = "0x339AB94", Slot = "6")]
		[Token(Token = "0x6003484")]
		protected virtual void vmethod_2()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_2)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_3;
				hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					return;
				}
				if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_2)
					{
						long num = 1L;
						this.bool_3 = (num != 0L);
						this.bool_2 = (num != 0L);
						return;
					}
					this.float_56 = (float)40960;
				}
			}
			else if (hexaBodyPlayerInputs.bool_2)
			{
				long num2 = 1L;
				this.bool_3 = (num2 != 0L);
				return;
			}
		}

		// Token: 0x06003485 RID: 13445 RVA: 0x00068570 File Offset: 0x00066770
		[Address(RVA = "0x3398B00", Offset = "0x3398B00", VA = "0x3398B00")]
		[Token(Token = "0x6003485")]
		private void method_48()
		{
			float magnitude = this.method_18().magnitude;
			Rigidbody rigidbody = this.rigidbody_0;
			long freezeRotation = 0L;
			rigidbody.freezeRotation = (freezeRotation != 0L);
			float radius = this.sphereCollider_0.radius;
			float z = this.vector3_4.z;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			Rigidbody rigidbody2 = this.rigidbody_0;
			Vector3 angularVelocity = rigidbody2.angularVelocity;
			if (this.bool_4)
			{
				Vector3 velocity = rigidbody2.velocity;
			}
			float time2;
			float time = this.animationCurve_2.Evaluate(time2);
			AnimationCurve animationCurve = this.animationCurve_1;
			animationCurve.Evaluate(time);
			this.method_24();
			float groundAngle;
			float y;
			if (this.bool_4)
			{
				groundAngle = this._groundAngle;
				y = this.float_13;
				Vector3 angularVelocity2 = this.rigidbody_0.angularVelocity;
				float magnitude2 = this.rigidbody_0.angularVelocity.magnitude;
				Rigidbody rigidbody3 = this.rigidbody_0;
				long freezeRotation2 = 1L;
				rigidbody3.freezeRotation = (freezeRotation2 != 0L);
				Vector3 zero = Vector3.zero;
			}
			Vector3 position = this.rigidbody_1.position;
			float fixedDeltaTime = Time.fixedDeltaTime;
			Vector3 position2 = this.rigidbody_1.position;
			this._previousPosition.x = groundAngle;
			this._previousPosition.y = y;
			this._previousPosition.z = z;
			float magnitude3 = position2.magnitude;
			this._actualSpeed = groundAngle;
		}

		// Token: 0x06003486 RID: 13446 RVA: 0x000686B4 File Offset: 0x000668B4
		[Address(RVA = "0x339AC88", Offset = "0x339AC88", VA = "0x339AC88")]
		[Token(Token = "0x6003486")]
		private void method_49()
		{
			HexaBodyPlayerInputs component = base.GetComponent<HexaBodyPlayerInputs>();
			this.hexaBodyPlayerInputs_0 = component;
			float radius = this.sphereCollider_0.radius;
			float radius2 = this.sphereCollider_1.radius;
			float mass = this.rigidbody_0.mass;
		}

		// Token: 0x06003487 RID: 13447 RVA: 0x000686F4 File Offset: 0x000668F4
		[Address(RVA = "0x339AD34", Offset = "0x339AD34", VA = "0x339AD34")]
		[Token(Token = "0x6003487")]
		private Vector2 method_50()
		{
			/*
An exception occurred when decompiling this method (06003487)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyPlayer::method_50()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(51)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(80)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(13)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003488 RID: 13448 RVA: 0x00068718 File Offset: 0x00066918
		[SerializeField]
		[Address(RVA = "0x339ADD8", Offset = "0x339ADD8", VA = "0x339ADD8")]
		[Token(Token = "0x6003488")]
		private void Update()
		{
			if (this.hexaBodyPlayerInputs_0.bool_3)
			{
				this.method_41();
			}
			float num = this.float_7;
			float radius = this.sphereCollider_0.radius;
			Rigidbody rigidbody = this.rigidbody_2;
			this.float_36 = num;
			Vector3 position = rigidbody.position;
			Vector3 position2 = this.rigidbody_0.position;
			float num2 = this.float_36;
			this.float_54 = num2;
			Mathf.Clamp01(radius);
			Rigidbody rigidbody2 = this.rigidbody_1;
			this.float_54 = num2;
			Vector3 position3 = rigidbody2.position;
			Vector3 position4 = this.rigidbody_0.position;
			this.float_34 = num2;
			this.method_6();
			this.method_9();
			this.method_46();
			Transform transform = this.transform_4;
			Vector3 position5 = transform.position;
			Vector3 position6 = this.rigidbody_3.position;
			Vector3 position7 = this.transform_4.position;
			Rigidbody rigidbody3 = this.rigidbody_3;
			CapsuleCollider capsuleCollider = this.capsuleCollider_2;
			Vector3 position8 = rigidbody3.position;
			Vector3 position9 = this.transform_4.position;
			float height;
			capsuleCollider.height = height;
			Vector3 position10 = this.rigidbody_3.position;
			Vector3 position11 = this.transform_2.position;
			Vector3 up = this.transform_2.up;
			Transform transform2 = this.transform_2.transform;
			Quaternion rotation = this.transform_2.transform.rotation;
		}

		// Token: 0x06003489 RID: 13449 RVA: 0x00003222 File Offset: 0x00001422
		[Address(RVA = "0x339B0D0", Offset = "0x339B0D0", VA = "0x339B0D0")]
		[Token(Token = "0x6003489")]
		private void method_51(HexaBodyPlayerInputs hexaBodyPlayerInputs_1)
		{
			this.hexaBodyPlayerInputs_0 = hexaBodyPlayerInputs_1;
		}

		// Token: 0x0600348A RID: 13450 RVA: 0x00068858 File Offset: 0x00066A58
		[Address(RVA = "0x339B0E0", Offset = "0x339B0E0", VA = "0x339B0E0")]
		[Token(Token = "0x600348A")]
		private void method_52()
		{
			float magnitude = this.method_13().magnitude;
			Rigidbody rigidbody = this.rigidbody_0;
			long freezeRotation = 0L;
			rigidbody.freezeRotation = (freezeRotation != 0L);
			AnimationCurve animationCurve = this.animationCurve_0;
			animationCurve.Evaluate(magnitude);
			float radius = this.sphereCollider_0.radius;
			float z = this.vector3_4.z;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			Vector3 angularVelocity = this.rigidbody_0.angularVelocity;
			if (this.bool_4)
			{
				Vector3 velocity = this.rigidbody_0.velocity;
			}
			float time2;
			float time = this.animationCurve_2.Evaluate(time2);
			AnimationCurve animationCurve2 = this.animationCurve_1;
			animationCurve2.Evaluate(time);
			this.method_24();
			float groundAngle;
			if (this.bool_4)
			{
				groundAngle = this._groundAngle;
				Vector3 angularVelocity2 = this.rigidbody_0.angularVelocity;
				float magnitude2 = this.rigidbody_0.angularVelocity.magnitude;
				Rigidbody rigidbody2 = this.rigidbody_0;
				long freezeRotation2 = 1L;
				rigidbody2.freezeRotation = (freezeRotation2 != 0L);
				Vector3 zero = Vector3.zero;
			}
			Vector3 position = this.rigidbody_1.position;
			float fixedDeltaTime = Time.fixedDeltaTime;
			Vector3 position2 = this.rigidbody_1.position;
			this._previousPosition.x = groundAngle;
			this._previousPosition.z = z;
			float magnitude3 = position2.magnitude;
			this._actualSpeed = groundAngle;
		}

		// Token: 0x0600348C RID: 13452 RVA: 0x00068994 File Offset: 0x00066B94
		[Address(RVA = "0x339B4C0", Offset = "0x339B4C0", VA = "0x339B4C0", Slot = "7")]
		[Token(Token = "0x600348C")]
		protected virtual void vmethod_3()
		{
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_2)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					if (hexaBodyPlayerInputs == null)
					{
						return;
					}
				}
				else if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_2)
					{
						long num = 1L;
						this.bool_2 = (num != 0L);
						return;
					}
					long num2 = 1L;
					this.float_56 = (float)57344;
					this.bool_2 = (num2 != 0L);
				}
			}
			else
			{
				bool flag2 = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs;
				bool flag3 = hexaBodyPlayerInputs.bool_2;
				long num;
				if (flag2)
				{
					if (flag3)
					{
						return;
					}
				}
				else if (num != 0L)
				{
					long num3 = 1L;
					this.bool_3 = (num3 != 0L);
					return;
				}
			}
			long num4 = 1L;
			this.bool_3 = (num4 != 0L);
		}

		// Token: 0x0600348D RID: 13453 RVA: 0x00067FD0 File Offset: 0x000661D0
		[Address(RVA = "0x3398FE0", Offset = "0x3398FE0", VA = "0x3398FE0")]
		[Token(Token = "0x600348D")]
		public float method_53()
		{
			Transform transform = this.transform_0;
			Vector3 localPosition = transform.localPosition;
			throw new NullReferenceException();
		}

		// Token: 0x0600348E RID: 13454 RVA: 0x000684A4 File Offset: 0x000666A4
		[Address(RVA = "0x339B5BC", Offset = "0x339B5BC", VA = "0x339B5BC")]
		[Token(Token = "0x600348E")]
		private void method_54(float float_57)
		{
			float num = this.float_7;
			float single_ = this.Single_0;
			this.float_42 = num;
			this.float_42 = num;
			this.float_41 = num;
			this.float_39 = num;
			this.float_39 = num;
			this.float_40 = num;
		}

		// Token: 0x0600348F RID: 13455 RVA: 0x00068A40 File Offset: 0x00066C40
		[Address(RVA = "0x339B670", Offset = "0x339B670", VA = "0x339B670")]
		[Token(Token = "0x600348F")]
		private void method_55()
		{
			float magnitude = this.method_50().magnitude;
			Rigidbody rigidbody = this.rigidbody_0;
			long freezeRotation = 0L;
			rigidbody.freezeRotation = (freezeRotation != 0L);
			AnimationCurve animationCurve = this.animationCurve_0;
			animationCurve.Evaluate(magnitude);
			float radius = this.sphereCollider_0.radius;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			Vector3 angularVelocity = this.rigidbody_0.angularVelocity;
			if (this.bool_4)
			{
				Vector3 velocity = this.rigidbody_0.velocity;
			}
			float time2;
			float time = this.animationCurve_2.Evaluate(time2);
			AnimationCurve animationCurve2 = this.animationCurve_1;
			animationCurve2.Evaluate(time);
			this.method_24();
			float groundAngle;
			if (this.bool_4)
			{
				groundAngle = this._groundAngle;
				Vector3 angularVelocity2 = this.rigidbody_0.angularVelocity;
				float magnitude2 = this.rigidbody_0.angularVelocity.magnitude;
				Rigidbody rigidbody2 = this.rigidbody_0;
				long freezeRotation2 = 0L;
				rigidbody2.freezeRotation = (freezeRotation2 != 0L);
				Vector3 zero = Vector3.zero;
			}
			Vector3 position = this.rigidbody_1.position;
			float fixedDeltaTime = Time.fixedDeltaTime;
			Vector3 position2 = this.rigidbody_1.position;
			this._previousPosition.x = groundAngle;
			float magnitude3 = position2.magnitude;
			this._actualSpeed = groundAngle;
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06003493 RID: 13459 RVA: 0x0006797C File Offset: 0x00065B7C
		// (set) Token: 0x06003490 RID: 13456 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x17000092")]
		public Quaternion Quaternion_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x339BB14", Offset = "0x339BB14", VA = "0x339BB14")]
			[Token(Token = "0x6003493")]
			get
			{
			}
			[CompilerGenerated]
			[Address(RVA = "0x339BA4C", Offset = "0x339BA4C", VA = "0x339BA4C")]
			[Token(Token = "0x6003490")]
			private set
			{
			}
		}

		// Token: 0x06003491 RID: 13457 RVA: 0x000684A4 File Offset: 0x000666A4
		[Address(RVA = "0x339BA60", Offset = "0x339BA60", VA = "0x339BA60")]
		[Token(Token = "0x6003491")]
		private void method_56(float float_57)
		{
			float num = this.float_7;
			float single_ = this.Single_0;
			this.float_42 = num;
			this.float_42 = num;
			this.float_41 = num;
			this.float_39 = num;
			this.float_39 = num;
			this.float_40 = num;
		}

		// Token: 0x06003492 RID: 13458 RVA: 0x00067E28 File Offset: 0x00066028
		[Address(RVA = "0x339A918", Offset = "0x339A918", VA = "0x339A918")]
		[Token(Token = "0x6003492")]
		public void method_57(float float_57)
		{
		}

		// Token: 0x06003494 RID: 13460 RVA: 0x00067944 File Offset: 0x00065B44
		[Address(RVA = "0x339BB28", Offset = "0x339BB28", VA = "0x339BB28")]
		[Token(Token = "0x6003494")]
		private void method_58(bool bool_5)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x06003495 RID: 13461 RVA: 0x00067BD8 File Offset: 0x00065DD8
		[Address(RVA = "0x33981BC", Offset = "0x33981BC", VA = "0x33981BC")]
		[Token(Token = "0x6003495")]
		private void method_59(GEnum16 genum16_0)
		{
			this._crouchLevel = genum16_0;
		}

		// Token: 0x06003496 RID: 13462 RVA: 0x00003212 File Offset: 0x00001412
		[Address(RVA = "0x339BBC0", Offset = "0x339BBC0", VA = "0x339BBC0")]
		[Token(Token = "0x6003496")]
		public void method_60(bool bool_5)
		{
			this.method_41();
		}

		// Token: 0x06003498 RID: 13464 RVA: 0x00067DC4 File Offset: 0x00065FC4
		[Address(RVA = "0x339BBE8", Offset = "0x339BBE8", VA = "0x339BBE8")]
		[Token(Token = "0x6003498")]
		private void method_61()
		{
			if (this.bool_1 && this.bool_4)
			{
				IEnumerator routine = this.method_39();
				Coroutine coroutine = base.StartCoroutine(routine);
				this.coroutine_1 = coroutine;
				return;
			}
		}

		// Token: 0x0400066C RID: 1644
		[Token(Token = "0x400066C")]
		[FieldOffset(Offset = "0x18")]
		public float float_0;

		// Token: 0x0400066D RID: 1645
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x400066D")]
		public float float_1;

		// Token: 0x0400066E RID: 1646
		[Token(Token = "0x400066E")]
		[FieldOffset(Offset = "0x20")]
		public float float_2;

		// Token: 0x0400066F RID: 1647
		[Token(Token = "0x400066F")]
		[FieldOffset(Offset = "0x24")]
		public ForceMode forceMode_0;

		// Token: 0x04000670 RID: 1648
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000670")]
		public float float_3;

		// Token: 0x04000671 RID: 1649
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000671")]
		public float float_4;

		// Token: 0x04000672 RID: 1650
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000672")]
		public AnimationCurve animationCurve_0;

		// Token: 0x04000673 RID: 1651
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000673")]
		public AnimationCurve animationCurve_1;

		// Token: 0x04000674 RID: 1652
		[Token(Token = "0x4000674")]
		[FieldOffset(Offset = "0x40")]
		public AnimationCurve animationCurve_2;

		// Token: 0x04000675 RID: 1653
		[Token(Token = "0x4000675")]
		[FieldOffset(Offset = "0x48")]
		public float float_5;

		// Token: 0x04000676 RID: 1654
		[Token(Token = "0x4000676")]
		[FieldOffset(Offset = "0x4C")]
		public float float_6;

		// Token: 0x04000677 RID: 1655
		[Token(Token = "0x4000677")]
		[FieldOffset(Offset = "0x50")]
		public float float_7;

		// Token: 0x04000678 RID: 1656
		[Token(Token = "0x4000678")]
		[FieldOffset(Offset = "0x54")]
		public float float_8;

		// Token: 0x04000679 RID: 1657
		[Token(Token = "0x4000679")]
		[FieldOffset(Offset = "0x58")]
		public float float_9;

		// Token: 0x0400067A RID: 1658
		[Token(Token = "0x400067A")]
		[FieldOffset(Offset = "0x5C")]
		public float float_10;

		// Token: 0x0400067B RID: 1659
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x400067B")]
		public GEnum18 genum18_0;

		// Token: 0x0400067C RID: 1660
		[Token(Token = "0x400067C")]
		[FieldOffset(Offset = "0x64")]
		public bool bool_0;

		// Token: 0x0400067D RID: 1661
		[Token(Token = "0x400067D")]
		[FieldOffset(Offset = "0x68")]
		public float float_11;

		// Token: 0x0400067E RID: 1662
		[FieldOffset(Offset = "0x6C")]
		[Token(Token = "0x400067E")]
		public float float_12;

		// Token: 0x0400067F RID: 1663
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x400067F")]
		public float float_13;

		// Token: 0x04000680 RID: 1664
		[FieldOffset(Offset = "0x74")]
		[Token(Token = "0x4000680")]
		public float float_14;

		// Token: 0x04000681 RID: 1665
		[Token(Token = "0x4000681")]
		[FieldOffset(Offset = "0x78")]
		public LayerMask layerMask_0;

		// Token: 0x04000682 RID: 1666
		[FieldOffset(Offset = "0x7C")]
		[Token(Token = "0x4000682")]
		public float float_15;

		// Token: 0x04000683 RID: 1667
		[Token(Token = "0x4000683")]
		[FieldOffset(Offset = "0x80")]
		public float float_16;

		// Token: 0x04000684 RID: 1668
		[Token(Token = "0x4000684")]
		[FieldOffset(Offset = "0x84")]
		public float float_17;

		// Token: 0x04000685 RID: 1669
		[Token(Token = "0x4000685")]
		[FieldOffset(Offset = "0x88")]
		public AnimationCurve animationCurve_3;

		// Token: 0x04000686 RID: 1670
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000686")]
		public AnimationCurve animationCurve_4;

		// Token: 0x04000687 RID: 1671
		[Token(Token = "0x4000687")]
		[FieldOffset(Offset = "0x98")]
		public float float_18;

		// Token: 0x04000688 RID: 1672
		[Token(Token = "0x4000688")]
		[FieldOffset(Offset = "0x9C")]
		public float float_19;

		// Token: 0x04000689 RID: 1673
		[Token(Token = "0x4000689")]
		[FieldOffset(Offset = "0xA0")]
		public float float_20;

		// Token: 0x0400068A RID: 1674
		[FieldOffset(Offset = "0xA4")]
		[Token(Token = "0x400068A")]
		public float float_21;

		// Token: 0x0400068B RID: 1675
		[FieldOffset(Offset = "0xA8")]
		[Token(Token = "0x400068B")]
		public float float_22;

		// Token: 0x0400068C RID: 1676
		[Token(Token = "0x400068C")]
		[FieldOffset(Offset = "0xAC")]
		public float float_23;

		// Token: 0x0400068D RID: 1677
		[Token(Token = "0x400068D")]
		[FieldOffset(Offset = "0xB0")]
		public float float_24;

		// Token: 0x0400068E RID: 1678
		[FieldOffset(Offset = "0xB4")]
		[Token(Token = "0x400068E")]
		public float float_25;

		// Token: 0x0400068F RID: 1679
		[FieldOffset(Offset = "0xB8")]
		[Token(Token = "0x400068F")]
		public float float_26;

		// Token: 0x04000690 RID: 1680
		[Token(Token = "0x4000690")]
		[FieldOffset(Offset = "0xBC")]
		public float float_27;

		// Token: 0x04000691 RID: 1681
		[FieldOffset(Offset = "0xC0")]
		[Token(Token = "0x4000691")]
		public float float_28;

		// Token: 0x04000692 RID: 1682
		[Token(Token = "0x4000692")]
		[FieldOffset(Offset = "0xC4")]
		public float float_29;

		// Token: 0x04000693 RID: 1683
		[Token(Token = "0x4000693")]
		[FieldOffset(Offset = "0xC8")]
		public float float_30;

		// Token: 0x04000694 RID: 1684
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x4000694")]
		public HexaCameraRig hexaCameraRig_0;

		// Token: 0x04000695 RID: 1685
		[Token(Token = "0x4000695")]
		[FieldOffset(Offset = "0xD8")]
		public Transform transform_0;

		// Token: 0x04000696 RID: 1686
		[Token(Token = "0x4000696")]
		[FieldOffset(Offset = "0xE0")]
		public Transform transform_1;

		// Token: 0x04000697 RID: 1687
		[Token(Token = "0x4000697")]
		[FieldOffset(Offset = "0xE8")]
		public Transform transform_2;

		// Token: 0x04000698 RID: 1688
		[Token(Token = "0x4000698")]
		[FieldOffset(Offset = "0xF0")]
		public Transform transform_3;

		// Token: 0x04000699 RID: 1689
		[Token(Token = "0x4000699")]
		[FieldOffset(Offset = "0xF8")]
		public Transform transform_4;

		// Token: 0x0400069A RID: 1690
		[Token(Token = "0x400069A")]
		[FieldOffset(Offset = "0x100")]
		public Transform transform_5;

		// Token: 0x0400069B RID: 1691
		[FieldOffset(Offset = "0x108")]
		[Token(Token = "0x400069B")]
		public Transform transform_6;

		// Token: 0x0400069C RID: 1692
		[Token(Token = "0x400069C")]
		[FieldOffset(Offset = "0x110")]
		public Rigidbody rigidbody_0;

		// Token: 0x0400069D RID: 1693
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x400069D")]
		public Rigidbody rigidbody_1;

		// Token: 0x0400069E RID: 1694
		[FieldOffset(Offset = "0x120")]
		[Token(Token = "0x400069E")]
		public Rigidbody rigidbody_2;

		// Token: 0x0400069F RID: 1695
		[FieldOffset(Offset = "0x128")]
		[Token(Token = "0x400069F")]
		public Rigidbody rigidbody_3;

		// Token: 0x040006A0 RID: 1696
		[FieldOffset(Offset = "0x130")]
		[Token(Token = "0x40006A0")]
		public CapsuleCollider capsuleCollider_0;

		// Token: 0x040006A1 RID: 1697
		[Token(Token = "0x40006A1")]
		[FieldOffset(Offset = "0x138")]
		public CapsuleCollider capsuleCollider_1;

		// Token: 0x040006A2 RID: 1698
		[FieldOffset(Offset = "0x140")]
		[Token(Token = "0x40006A2")]
		public SphereCollider sphereCollider_0;

		// Token: 0x040006A3 RID: 1699
		[FieldOffset(Offset = "0x148")]
		[Token(Token = "0x40006A3")]
		public SphereCollider sphereCollider_1;

		// Token: 0x040006A4 RID: 1700
		[FieldOffset(Offset = "0x150")]
		[Token(Token = "0x40006A4")]
		public CapsuleCollider capsuleCollider_2;

		// Token: 0x040006A5 RID: 1701
		[Token(Token = "0x40006A5")]
		[FieldOffset(Offset = "0x158")]
		public ConfigurableJoint configurableJoint_0;

		// Token: 0x040006A6 RID: 1702
		[FieldOffset(Offset = "0x160")]
		[Token(Token = "0x40006A6")]
		public ConfigurableJoint configurableJoint_1;

		// Token: 0x040006A7 RID: 1703
		[FieldOffset(Offset = "0x168")]
		[Token(Token = "0x40006A7")]
		public ConfigurableJoint configurableJoint_2;

		// Token: 0x040006A8 RID: 1704
		[FieldOffset(Offset = "0x170")]
		[Token(Token = "0x40006A8")]
		public Transform transform_7;

		// Token: 0x040006A9 RID: 1705
		[Token(Token = "0x40006A9")]
		[FieldOffset(Offset = "0x178")]
		public Transform transform_8;

		// Token: 0x040006AA RID: 1706
		[Space]
		[Token(Token = "0x40006AA")]
		[FieldOffset(Offset = "0x180")]
		public float float_31;

		// Token: 0x040006AB RID: 1707
		[FieldOffset(Offset = "0x184")]
		[Token(Token = "0x40006AB")]
		public float float_32;

		// Token: 0x040006AC RID: 1708
		[Token(Token = "0x40006AC")]
		[FieldOffset(Offset = "0x188")]
		public float float_33;

		// Token: 0x040006AD RID: 1709
		[Token(Token = "0x40006AD")]
		[FieldOffset(Offset = "0x18C")]
		public float float_34;

		// Token: 0x040006AE RID: 1710
		[FieldOffset(Offset = "0x190")]
		[Token(Token = "0x40006AE")]
		public float float_35;

		// Token: 0x040006AF RID: 1711
		[FieldOffset(Offset = "0x194")]
		[Token(Token = "0x40006AF")]
		public float float_36;

		// Token: 0x040006B0 RID: 1712
		[Token(Token = "0x40006B0")]
		[FieldOffset(Offset = "0x198")]
		public float float_37;

		// Token: 0x040006B1 RID: 1713
		[Token(Token = "0x40006B1")]
		[FieldOffset(Offset = "0x19C")]
		public float float_38;

		// Token: 0x040006B2 RID: 1714
		[Token(Token = "0x40006B2")]
		[FieldOffset(Offset = "0x1A0")]
		public float float_39;

		// Token: 0x040006B3 RID: 1715
		[FieldOffset(Offset = "0x1A4")]
		[Token(Token = "0x40006B3")]
		public float float_40;

		// Token: 0x040006B4 RID: 1716
		[FieldOffset(Offset = "0x1A8")]
		[Token(Token = "0x40006B4")]
		public float float_41;

		// Token: 0x040006B5 RID: 1717
		[Token(Token = "0x40006B5")]
		[FieldOffset(Offset = "0x1AC")]
		public float float_42;

		// Token: 0x040006B6 RID: 1718
		[FieldOffset(Offset = "0x1B0")]
		[Token(Token = "0x40006B6")]
		public float float_43;

		// Token: 0x040006B7 RID: 1719
		[Token(Token = "0x40006B7")]
		[FieldOffset(Offset = "0x1B4")]
		public float float_44;

		// Token: 0x040006B8 RID: 1720
		[Token(Token = "0x40006B8")]
		[FieldOffset(Offset = "0x1B8")]
		public float float_45;

		// Token: 0x040006B9 RID: 1721
		[Token(Token = "0x40006B9")]
		[FieldOffset(Offset = "0x1BC")]
		public float float_46;

		// Token: 0x040006BA RID: 1722
		[Token(Token = "0x40006BA")]
		[FieldOffset(Offset = "0x1C0")]
		public float float_47;

		// Token: 0x040006BB RID: 1723
		[FieldOffset(Offset = "0x1C4")]
		[Token(Token = "0x40006BB")]
		public float float_48;

		// Token: 0x040006BC RID: 1724
		[Token(Token = "0x40006BC")]
		[FieldOffset(Offset = "0x1C8")]
		public float float_49;

		// Token: 0x040006BD RID: 1725
		[FieldOffset(Offset = "0x1CC")]
		[Token(Token = "0x40006BD")]
		public Vector3 vector3_0;

		// Token: 0x040006BE RID: 1726
		[FieldOffset(Offset = "0x1D8")]
		[Token(Token = "0x40006BE")]
		public Vector3 vector3_1;

		// Token: 0x040006BF RID: 1727
		[FieldOffset(Offset = "0x1E4")]
		[Token(Token = "0x40006BF")]
		[SerializeField]
		private float _jumpSpring;

		// Token: 0x040006C0 RID: 1728
		[FieldOffset(Offset = "0x1E8")]
		[Token(Token = "0x40006C0")]
		[SerializeField]
		private float _groundAngle;

		// Token: 0x040006C1 RID: 1729
		[SerializeField]
		[Token(Token = "0x40006C1")]
		[FieldOffset(Offset = "0x1EC")]
		private GEnum16 _crouchLevel;

		// Token: 0x040006C2 RID: 1730
		[Token(Token = "0x40006C2")]
		[SerializeField]
		[FieldOffset(Offset = "0x1F0")]
		private float _jumpTime;

		// Token: 0x040006C3 RID: 1731
		[Token(Token = "0x40006C3")]
		[FieldOffset(Offset = "0x1F4")]
		[SerializeField]
		private GEnum17 _legStage;

		// Token: 0x040006C4 RID: 1732
		[FieldOffset(Offset = "0x1F8")]
		[SerializeField]
		[Token(Token = "0x40006C4")]
		private Vector3 _lastCameraDirection;

		// Token: 0x040006C5 RID: 1733
		[Token(Token = "0x40006C5")]
		[FieldOffset(Offset = "0x204")]
		[SerializeField]
		private Vector3 _previousPosition;

		// Token: 0x040006C6 RID: 1734
		[SerializeField]
		[Token(Token = "0x40006C6")]
		[FieldOffset(Offset = "0x210")]
		private float _actualSpeed;

		// Token: 0x040006C7 RID: 1735
		[Token(Token = "0x40006C7")]
		[FieldOffset(Offset = "0x214")]
		private float float_50;

		// Token: 0x040006C8 RID: 1736
		[FieldOffset(Offset = "0x218")]
		[Token(Token = "0x40006C8")]
		private float float_51;

		// Token: 0x040006C9 RID: 1737
		[FieldOffset(Offset = "0x21C")]
		[Token(Token = "0x40006C9")]
		private float float_52;

		// Token: 0x040006CA RID: 1738
		[Token(Token = "0x40006CA")]
		[FieldOffset(Offset = "0x220")]
		private bool bool_1;

		// Token: 0x040006CB RID: 1739
		[Token(Token = "0x40006CB")]
		[FieldOffset(Offset = "0x224")]
		private float float_53;

		// Token: 0x040006CC RID: 1740
		[FieldOffset(Offset = "0x228")]
		[Token(Token = "0x40006CC")]
		private float float_54;

		// Token: 0x040006CD RID: 1741
		[Token(Token = "0x40006CD")]
		[FieldOffset(Offset = "0x22C")]
		private float float_55;

		// Token: 0x040006CE RID: 1742
		[FieldOffset(Offset = "0x230")]
		[Token(Token = "0x40006CE")]
		private Vector3 vector3_2;

		// Token: 0x040006CF RID: 1743
		[FieldOffset(Offset = "0x23C")]
		[Token(Token = "0x40006CF")]
		private float float_56;

		// Token: 0x040006D0 RID: 1744
		[Token(Token = "0x40006D0")]
		[FieldOffset(Offset = "0x240")]
		private bool bool_2;

		// Token: 0x040006D1 RID: 1745
		[Token(Token = "0x40006D1")]
		[FieldOffset(Offset = "0x248")]
		private Coroutine coroutine_0;

		// Token: 0x040006D2 RID: 1746
		[FieldOffset(Offset = "0x250")]
		[Token(Token = "0x40006D2")]
		private Coroutine coroutine_1;

		// Token: 0x040006D3 RID: 1747
		[FieldOffset(Offset = "0x258")]
		[CompilerGenerated]
		[Token(Token = "0x40006D3")]
		private bool bool_3;

		// Token: 0x040006D4 RID: 1748
		[FieldOffset(Offset = "0x25C")]
		[Token(Token = "0x40006D4")]
		[CompilerGenerated]
		private Quaternion quaternion_0;

		// Token: 0x040006D5 RID: 1749
		[FieldOffset(Offset = "0x270")]
		[Token(Token = "0x40006D5")]
		[CompilerGenerated]
		private HexaBodyPlayerInputs hexaBodyPlayerInputs_0;

		// Token: 0x040006D6 RID: 1750
		[FieldOffset(Offset = "0x278")]
		[Token(Token = "0x40006D6")]
		[CompilerGenerated]
		private Vector3 vector3_3;

		// Token: 0x040006D7 RID: 1751
		[FieldOffset(Offset = "0x284")]
		[CompilerGenerated]
		[Token(Token = "0x40006D7")]
		private Vector3 vector3_4;

		// Token: 0x040006D8 RID: 1752
		[FieldOffset(Offset = "0x290")]
		[Token(Token = "0x40006D8")]
		[CompilerGenerated]
		private bool bool_4;

		// Token: 0x040006D9 RID: 1753
		[FieldOffset(Offset = "0x294")]
		[Token(Token = "0x40006D9")]
		private Vector3 vector3_5;
	}
}
