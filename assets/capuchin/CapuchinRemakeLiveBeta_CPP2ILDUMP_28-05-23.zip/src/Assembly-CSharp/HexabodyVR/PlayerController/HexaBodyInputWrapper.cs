﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000140 RID: 320
	[Token(Token = "0x2000140")]
	public class HexaBodyInputWrapper : MonoBehaviour
	{
		// Token: 0x060033B5 RID: 13237 RVA: 0x00065EB0 File Offset: 0x000640B0
		[Token(Token = "0x60033B5")]
		[Address(RVA = "0x363DC04", Offset = "0x363DC04", VA = "0x363DC04")]
		protected bool method_0()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033B6 RID: 13238 RVA: 0x00065EDC File Offset: 0x000640DC
		[Token(Token = "0x60033B6")]
		[Address(RVA = "0x363DC50", Offset = "0x363DC50", VA = "0x363DC50")]
		protected bool method_1()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x060033B7 RID: 13239 RVA: 0x00065F00 File Offset: 0x00064100
		[Address(RVA = "0x363DCC4", Offset = "0x363DCC4", VA = "0x363DCC4")]
		[Token(Token = "0x60033B7")]
		protected void Update()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			if (hexaBodyPlayerInputs == null)
			{
			}
			if (hexaBodyPlayerInputs == null || hexaBodyPlayerInputs == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs2 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs2 != null)
			{
				if (hexaBodyPlayerInputs3 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs4 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs4.vector2_1.x = x;
				hexaBodyPlayerInputs4.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
				this.method_7();
				hexaBodyPlayerInputs5.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_10();
				hexaBodyPlayerInputs6.bool_6 = (hexaXRInputs2 != null);
				this.method_59();
				return;
			}
			hexaBodyPlayerInputs4.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033B8 RID: 13240 RVA: 0x00066008 File Offset: 0x00064208
		[Address(RVA = "0x363DFAC", Offset = "0x363DFAC", VA = "0x363DFAC")]
		[Token(Token = "0x60033B8")]
		protected bool method_2()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033B9 RID: 13241 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033B9")]
		[Address(RVA = "0x363DFF8", Offset = "0x363DFF8", VA = "0x363DFF8")]
		protected bool method_3()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033BA RID: 13242 RVA: 0x00066058 File Offset: 0x00064258
		[Address(RVA = "0x363E048", Offset = "0x363E048", VA = "0x363E048", Slot = "4")]
		[Token(Token = "0x60033BA")]
		protected virtual bool vmethod_0()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_82();
		}

		// Token: 0x060033BB RID: 13243 RVA: 0x00066080 File Offset: 0x00064280
		[Address(RVA = "0x363E0B4", Offset = "0x363E0B4", VA = "0x363E0B4")]
		[Token(Token = "0x60033BB")]
		protected bool method_4()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_20();
		}

		// Token: 0x060033BC RID: 13244 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x363E128", Offset = "0x363E128", VA = "0x363E128")]
		[Token(Token = "0x60033BC")]
		protected bool method_5()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x060033BD RID: 13245 RVA: 0x000660C8 File Offset: 0x000642C8
		[Token(Token = "0x60033BD")]
		[Address(RVA = "0x363E19C", Offset = "0x363E19C", VA = "0x363E19C")]
		protected void method_6()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_110();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_18();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_32();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033BE RID: 13246 RVA: 0x000661EC File Offset: 0x000643EC
		[Token(Token = "0x60033BE")]
		[Address(RVA = "0x363E484", Offset = "0x363E484", VA = "0x363E484", Slot = "5")]
		protected virtual bool vmethod_1()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_29();
		}

		// Token: 0x060033BF RID: 13247 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363DE9C", Offset = "0x363DE9C", VA = "0x363DE9C")]
		[Token(Token = "0x60033BF")]
		protected bool method_7()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C0 RID: 13248 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363E4F0", Offset = "0x363E4F0", VA = "0x363E4F0")]
		[Token(Token = "0x60033C0")]
		protected bool method_8()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C1 RID: 13249 RVA: 0x00066214 File Offset: 0x00064414
		[Address(RVA = "0x363E53C", Offset = "0x363E53C", VA = "0x363E53C")]
		[Token(Token = "0x60033C1")]
		protected void method_9()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_97();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_87();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_65();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033C2 RID: 13250 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033C2")]
		[Address(RVA = "0x363DEEC", Offset = "0x363DEEC", VA = "0x363DEEC")]
		protected bool method_10()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C3 RID: 13251 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033C3")]
		[Address(RVA = "0x363E824", Offset = "0x363E824", VA = "0x363E824")]
		protected bool method_11()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C4 RID: 13252 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363E874", Offset = "0x363E874", VA = "0x363E874")]
		[Token(Token = "0x60033C4")]
		protected bool method_12()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C5 RID: 13253 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033C5")]
		[Address(RVA = "0x363E8C4", Offset = "0x363E8C4", VA = "0x363E8C4")]
		protected bool method_13()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C6 RID: 13254 RVA: 0x00066338 File Offset: 0x00064538
		[Address(RVA = "0x363E910", Offset = "0x363E910", VA = "0x363E910")]
		[Token(Token = "0x60033C6")]
		protected bool method_14()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_16();
		}

		// Token: 0x060033C7 RID: 13255 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033C7")]
		[Address(RVA = "0x363E984", Offset = "0x363E984", VA = "0x363E984")]
		protected bool method_15()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C8 RID: 13256 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033C8")]
		[Address(RVA = "0x363E9D4", Offset = "0x363E9D4", VA = "0x363E9D4")]
		protected bool method_16()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033C9 RID: 13257 RVA: 0x0006635C File Offset: 0x0006455C
		[Token(Token = "0x60033C9")]
		[Address(RVA = "0x363EA24", Offset = "0x363EA24", VA = "0x363EA24")]
		protected void method_17()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (hexaXRInputs != null && hexaXRInputs == null)
			{
				hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				return;
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_7();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_81();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_65();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033CA RID: 13258 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363E3C4", Offset = "0x363E3C4", VA = "0x363E3C4")]
		[Token(Token = "0x60033CA")]
		protected bool method_18()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033CB RID: 13259 RVA: 0x00066478 File Offset: 0x00064678
		[Address(RVA = "0x363EC48", Offset = "0x363EC48", VA = "0x363EC48", Slot = "6")]
		[Token(Token = "0x60033CB")]
		protected virtual bool vmethod_2()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_41();
		}

		// Token: 0x060033CC RID: 13260 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033CC")]
		[Address(RVA = "0x363ECB4", Offset = "0x363ECB4", VA = "0x363ECB4")]
		protected bool method_19()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033CD RID: 13261 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363ED00", Offset = "0x363ED00", VA = "0x363ED00")]
		[Token(Token = "0x60033CD")]
		protected bool method_20()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033CE RID: 13262 RVA: 0x00066080 File Offset: 0x00064280
		[Token(Token = "0x60033CE")]
		[Address(RVA = "0x363ED4C", Offset = "0x363ED4C", VA = "0x363ED4C")]
		protected bool method_21()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_20();
		}

		// Token: 0x060033CF RID: 13263 RVA: 0x00066080 File Offset: 0x00064280
		[Address(RVA = "0x363EDC0", Offset = "0x363EDC0", VA = "0x363EDC0")]
		[Token(Token = "0x60033CF")]
		protected bool method_22()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_20();
		}

		// Token: 0x060033D0 RID: 13264 RVA: 0x00066338 File Offset: 0x00064538
		[Token(Token = "0x60033D0")]
		[Address(RVA = "0x363EE34", Offset = "0x363EE34", VA = "0x363EE34")]
		protected bool method_23()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_16();
		}

		// Token: 0x060033D1 RID: 13265 RVA: 0x00065EDC File Offset: 0x000640DC
		[Token(Token = "0x60033D1")]
		[Address(RVA = "0x363EEA8", Offset = "0x363EEA8", VA = "0x363EEA8")]
		protected bool method_24()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x060033D2 RID: 13266 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x363EF1C", Offset = "0x363EF1C", VA = "0x363EF1C")]
		[Token(Token = "0x60033D2")]
		protected bool method_25()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x060033D3 RID: 13267 RVA: 0x000660A4 File Offset: 0x000642A4
		[Token(Token = "0x60033D3")]
		[Address(RVA = "0x363EF90", Offset = "0x363EF90", VA = "0x363EF90")]
		protected bool method_26()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x060033D4 RID: 13268 RVA: 0x000661EC File Offset: 0x000643EC
		[Address(RVA = "0x363F004", Offset = "0x363F004", VA = "0x363F004", Slot = "7")]
		[Token(Token = "0x60033D4")]
		protected virtual bool vmethod_3()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_29();
		}

		// Token: 0x060033D5 RID: 13269 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033D5")]
		[Address(RVA = "0x363F070", Offset = "0x363F070", VA = "0x363F070")]
		protected bool method_27()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033D6 RID: 13270 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363F0BC", Offset = "0x363F0BC", VA = "0x363F0BC")]
		[Token(Token = "0x60033D6")]
		protected bool method_28()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033D7 RID: 13271 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363F108", Offset = "0x363F108", VA = "0x363F108")]
		[Token(Token = "0x60033D7")]
		protected bool method_29()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033D8 RID: 13272 RVA: 0x000664A0 File Offset: 0x000646A0
		[Token(Token = "0x60033D8")]
		[Address(RVA = "0x363F158", Offset = "0x363F158", VA = "0x363F158")]
		protected void method_30()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				this.method_16();
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_98();
				hexaBodyPlayerInputs6.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_70();
				hexaBodyPlayerInputs7.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033D9 RID: 13273 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033D9")]
		[Address(RVA = "0x363F3F0", Offset = "0x363F3F0", VA = "0x363F3F0")]
		protected bool method_31()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033DA RID: 13274 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x60033DA")]
		[Address(RVA = "0x363F440", Offset = "0x363F440", VA = "0x363F440")]
		public HexaBodyInputWrapper()
		{
		}

		// Token: 0x060033DB RID: 13275 RVA: 0x000665B4 File Offset: 0x000647B4
		[Token(Token = "0x60033DB")]
		[Address(RVA = "0x363E410", Offset = "0x363E410", VA = "0x363E410")]
		protected bool method_32()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_106();
		}

		// Token: 0x060033DC RID: 13276 RVA: 0x00066058 File Offset: 0x00064258
		[Address(RVA = "0x363F458", Offset = "0x363F458", VA = "0x363F458", Slot = "8")]
		[Token(Token = "0x60033DC")]
		protected virtual bool vmethod_4()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_82();
		}

		// Token: 0x060033DD RID: 13277 RVA: 0x000665D8 File Offset: 0x000647D8
		[Token(Token = "0x60033DD")]
		[Address(RVA = "0x363F4C4", Offset = "0x363F4C4", VA = "0x363F4C4", Slot = "9")]
		protected virtual bool vmethod_5()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_16();
		}

		// Token: 0x060033DE RID: 13278 RVA: 0x00066600 File Offset: 0x00064800
		[Token(Token = "0x60033DE")]
		[Address(RVA = "0x363F530", Offset = "0x363F530", VA = "0x363F530")]
		protected void method_33()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_108();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_42();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_61();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033DF RID: 13279 RVA: 0x000665B4 File Offset: 0x000647B4
		[Address(RVA = "0x363F818", Offset = "0x363F818", VA = "0x363F818")]
		[Token(Token = "0x60033DF")]
		protected bool method_34()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_106();
		}

		// Token: 0x060033E0 RID: 13280 RVA: 0x00066724 File Offset: 0x00064924
		[Token(Token = "0x60033E0")]
		[Address(RVA = "0x363F88C", Offset = "0x363F88C", VA = "0x363F88C", Slot = "10")]
		protected virtual bool vmethod_6()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.Boolean_1;
		}

		// Token: 0x060033E1 RID: 13281 RVA: 0x0006674C File Offset: 0x0006494C
		[Token(Token = "0x60033E1")]
		[Address(RVA = "0x363F8F8", Offset = "0x363F8F8", VA = "0x363F8F8")]
		protected void method_35()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_110();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_72();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_1();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033E2 RID: 13282 RVA: 0x00066870 File Offset: 0x00064A70
		[Address(RVA = "0x363FB1C", Offset = "0x363FB1C", VA = "0x363FB1C")]
		[Token(Token = "0x60033E2")]
		protected bool method_36()
		{
			throw new NullReferenceException();
		}

		// Token: 0x060033E3 RID: 13283 RVA: 0x000665B4 File Offset: 0x000647B4
		[Token(Token = "0x60033E3")]
		[Address(RVA = "0x363FB68", Offset = "0x363FB68", VA = "0x363FB68")]
		protected bool method_37()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_106();
		}

		// Token: 0x060033E4 RID: 13284 RVA: 0x00066884 File Offset: 0x00064A84
		[Token(Token = "0x60033E4")]
		[Address(RVA = "0x363FBDC", Offset = "0x363FBDC", VA = "0x363FBDC")]
		protected bool method_38()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.Boolean_1;
		}

		// Token: 0x060033E5 RID: 13285 RVA: 0x000668A8 File Offset: 0x00064AA8
		[Address(RVA = "0x363FC50", Offset = "0x363FC50", VA = "0x363FC50")]
		[Token(Token = "0x60033E5")]
		protected void method_39()
		{
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs == null || hexaBodyPlayerInputs == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs2 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs2 != null)
			{
				if (hexaBodyPlayerInputs3 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs4 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs4.vector2_1.x = x;
				hexaBodyPlayerInputs4.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
				this.method_15();
				hexaBodyPlayerInputs5.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_72();
				hexaBodyPlayerInputs6.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_61();
				hexaBodyPlayerInputs7.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs4.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033E6 RID: 13286 RVA: 0x000669C0 File Offset: 0x00064BC0
		[Token(Token = "0x60033E6")]
		[Address(RVA = "0x363FE28", Offset = "0x363FE28", VA = "0x363FE28")]
		protected void method_40()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_95();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_81();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_4();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033E7 RID: 13287 RVA: 0x00066724 File Offset: 0x00064924
		[Token(Token = "0x60033E7")]
		[Address(RVA = "0x364004C", Offset = "0x364004C", VA = "0x364004C", Slot = "11")]
		protected virtual bool vmethod_7()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.Boolean_1;
		}

		// Token: 0x060033E8 RID: 13288 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x36400B8", Offset = "0x36400B8", VA = "0x36400B8")]
		[Token(Token = "0x60033E8")]
		protected bool method_41()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033E9 RID: 13289 RVA: 0x00066870 File Offset: 0x00064A70
		[Token(Token = "0x60033E9")]
		[Address(RVA = "0x363F758", Offset = "0x363F758", VA = "0x363F758")]
		protected bool method_42()
		{
			throw new NullReferenceException();
		}

		// Token: 0x060033EA RID: 13290 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033EA")]
		[Address(RVA = "0x3640108", Offset = "0x3640108", VA = "0x3640108")]
		protected bool method_43()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033EB RID: 13291 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x3640154", Offset = "0x3640154", VA = "0x3640154")]
		[Token(Token = "0x60033EB")]
		protected bool method_44()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x060033EC RID: 13292 RVA: 0x0006602C File Offset: 0x0006422C
		[Token(Token = "0x60033EC")]
		[Address(RVA = "0x36401C8", Offset = "0x36401C8", VA = "0x36401C8")]
		protected bool method_45()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033ED RID: 13293 RVA: 0x00066AE4 File Offset: 0x00064CE4
		[Address(RVA = "0x3640214", Offset = "0x3640214", VA = "0x3640214", Slot = "12")]
		[Token(Token = "0x60033ED")]
		protected virtual bool vmethod_8()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_20();
		}

		// Token: 0x060033EE RID: 13294 RVA: 0x000031BC File Offset: 0x000013BC
		[Token(Token = "0x60033EE")]
		[Address(RVA = "0x3640280", Offset = "0x3640280", VA = "0x3640280", Slot = "13")]
		protected virtual bool vmethod_9()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_20();
		}

		// Token: 0x060033EF RID: 13295 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x36402EC", Offset = "0x36402EC", VA = "0x36402EC")]
		[Token(Token = "0x60033EF")]
		protected bool method_46()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033F0 RID: 13296 RVA: 0x00066884 File Offset: 0x00064A84
		[Token(Token = "0x60033F0")]
		[Address(RVA = "0x364033C", Offset = "0x364033C", VA = "0x364033C")]
		protected bool method_47()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.Boolean_1;
		}

		// Token: 0x060033F1 RID: 13297 RVA: 0x000031D6 File Offset: 0x000013D6
		[Address(RVA = "0x36403B0", Offset = "0x36403B0", VA = "0x36403B0", Slot = "14")]
		[Token(Token = "0x60033F1")]
		protected virtual bool vmethod_10()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_29();
		}

		// Token: 0x060033F2 RID: 13298 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x364041C", Offset = "0x364041C", VA = "0x364041C")]
		[Token(Token = "0x60033F2")]
		protected bool method_48()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033F3 RID: 13299 RVA: 0x00066B0C File Offset: 0x00064D0C
		[Address(RVA = "0x364046C", Offset = "0x364046C", VA = "0x364046C")]
		[Token(Token = "0x60033F3")]
		protected void method_49()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_84();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_73();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_71();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033F4 RID: 13300 RVA: 0x00066C30 File Offset: 0x00064E30
		[Address(RVA = "0x3640754", Offset = "0x3640754", VA = "0x3640754")]
		[Token(Token = "0x60033F4")]
		protected void method_50()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_108();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_20();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_101();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x060033F5 RID: 13301 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x36409A0", Offset = "0x36409A0", VA = "0x36409A0")]
		[Token(Token = "0x60033F5")]
		protected bool method_51()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033F6 RID: 13302 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x36409EC", Offset = "0x36409EC", VA = "0x36409EC")]
		[Token(Token = "0x60033F6")]
		protected bool method_52()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033F7 RID: 13303 RVA: 0x00066080 File Offset: 0x00064280
		[Address(RVA = "0x3640A38", Offset = "0x3640A38", VA = "0x3640A38")]
		[Token(Token = "0x60033F7")]
		protected bool method_53()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_20();
		}

		// Token: 0x060033F8 RID: 13304 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640AAC", Offset = "0x3640AAC", VA = "0x3640AAC")]
		[Token(Token = "0x60033F8")]
		protected bool method_54()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033F9 RID: 13305 RVA: 0x00065EDC File Offset: 0x000640DC
		[Address(RVA = "0x3640AFC", Offset = "0x3640AFC", VA = "0x3640AFC")]
		[Token(Token = "0x60033F9")]
		protected bool method_55()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x060033FA RID: 13306 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640B70", Offset = "0x3640B70", VA = "0x3640B70")]
		[Token(Token = "0x60033FA")]
		protected bool method_56()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033FB RID: 13307 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640BBC", Offset = "0x3640BBC", VA = "0x3640BBC")]
		[Token(Token = "0x60033FB")]
		protected bool method_57()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033FC RID: 13308 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640C08", Offset = "0x3640C08", VA = "0x3640C08")]
		[Token(Token = "0x60033FC")]
		protected bool method_58()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060033FD RID: 13309 RVA: 0x00066724 File Offset: 0x00064924
		[Address(RVA = "0x3640C58", Offset = "0x3640C58", VA = "0x3640C58", Slot = "15")]
		[Token(Token = "0x60033FD")]
		protected virtual bool vmethod_11()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.Boolean_1;
		}

		// Token: 0x060033FE RID: 13310 RVA: 0x00066884 File Offset: 0x00064A84
		[Address(RVA = "0x363DF38", Offset = "0x363DF38", VA = "0x363DF38")]
		[Token(Token = "0x60033FE")]
		protected bool method_59()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.Boolean_1;
		}

		// Token: 0x060033FF RID: 13311 RVA: 0x00065EDC File Offset: 0x000640DC
		[Address(RVA = "0x3640CC4", Offset = "0x3640CC4", VA = "0x3640CC4")]
		[Token(Token = "0x60033FF")]
		protected bool method_60()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x06003400 RID: 13312 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x363F7A4", Offset = "0x363F7A4", VA = "0x363F7A4")]
		[Token(Token = "0x6003400")]
		protected bool method_61()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x06003401 RID: 13313 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640D38", Offset = "0x3640D38", VA = "0x3640D38")]
		[Token(Token = "0x6003401")]
		protected bool method_62()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003402 RID: 13314 RVA: 0x00066008 File Offset: 0x00064208
		[Address(RVA = "0x3640D88", Offset = "0x3640D88", VA = "0x3640D88")]
		[Token(Token = "0x6003402")]
		protected bool method_63()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003403 RID: 13315 RVA: 0x00066D50 File Offset: 0x00064F50
		[Address(RVA = "0x3640DD8", Offset = "0x3640DD8", VA = "0x3640DD8")]
		[Token(Token = "0x6003403")]
		protected void method_64()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3;
			if (hexaBodyPlayerInputs2 != null && hexaBodyPlayerInputs2 != null)
			{
				hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_68();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_13();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_101();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x06003404 RID: 13316 RVA: 0x00066338 File Offset: 0x00064538
		[Address(RVA = "0x363E7B0", Offset = "0x363E7B0", VA = "0x363E7B0")]
		[Token(Token = "0x6003404")]
		protected bool method_65()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_16();
		}

		// Token: 0x06003405 RID: 13317 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3641000", Offset = "0x3641000", VA = "0x3641000")]
		[Token(Token = "0x6003405")]
		protected bool method_66()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003406 RID: 13318 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x364104C", Offset = "0x364104C", VA = "0x364104C")]
		[Token(Token = "0x6003406")]
		protected bool method_67()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003407 RID: 13319 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640FB0", Offset = "0x3640FB0", VA = "0x3640FB0")]
		[Token(Token = "0x6003407")]
		protected bool method_68()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003408 RID: 13320 RVA: 0x00066E74 File Offset: 0x00065074
		[Address(RVA = "0x364109C", Offset = "0x364109C", VA = "0x364109C")]
		[Token(Token = "0x6003408")]
		protected bool method_69()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x06003409 RID: 13321 RVA: 0x00066080 File Offset: 0x00064280
		[Address(RVA = "0x363F37C", Offset = "0x363F37C", VA = "0x363F37C")]
		[Token(Token = "0x6003409")]
		protected bool method_70()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_20();
		}

		// Token: 0x0600340A RID: 13322 RVA: 0x00065EDC File Offset: 0x000640DC
		[Address(RVA = "0x36406E0", Offset = "0x36406E0", VA = "0x36406E0")]
		[Token(Token = "0x600340A")]
		protected bool method_71()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x0600340B RID: 13323 RVA: 0x000031F0 File Offset: 0x000013F0
		[Address(RVA = "0x3641110", Offset = "0x3641110", VA = "0x3641110", Slot = "16")]
		[Token(Token = "0x600340B")]
		protected virtual bool vmethod_12()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_82();
		}

		// Token: 0x0600340C RID: 13324 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363FAD0", Offset = "0x363FAD0", VA = "0x363FAD0")]
		[Token(Token = "0x600340C")]
		protected bool method_72()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600340D RID: 13325 RVA: 0x00066058 File Offset: 0x00064258
		[Address(RVA = "0x364117C", Offset = "0x364117C", VA = "0x364117C", Slot = "17")]
		[Token(Token = "0x600340D")]
		protected virtual bool vmethod_13()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_82();
		}

		// Token: 0x0600340E RID: 13326 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640694", Offset = "0x3640694", VA = "0x3640694")]
		[Token(Token = "0x600340E")]
		protected bool method_73()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600340F RID: 13327 RVA: 0x00066E98 File Offset: 0x00065098
		[Address(RVA = "0x36411E8", Offset = "0x36411E8", VA = "0x36411E8")]
		[Token(Token = "0x600340F")]
		protected bool method_74()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003410 RID: 13328 RVA: 0x00066EBC File Offset: 0x000650BC
		[Address(RVA = "0x3641234", Offset = "0x3641234", VA = "0x3641234")]
		[Token(Token = "0x6003410")]
		protected void method_75()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			do
			{
				if (this.bool_0)
				{
					HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
					if (hexaXRInputs != null && hexaXRInputs == null)
					{
						goto Block_2;
					}
				}
			}
			while (hexaBodyPlayerInputs == null);
			if (this.hexaBodyPlayerInputs_0 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs2 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs2 != null)
			{
				if (hexaBodyPlayerInputs3 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs4 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs4.vector2_1.x = x;
				hexaBodyPlayerInputs4.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
				this.method_62();
				hexaBodyPlayerInputs5.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_87();
				hexaBodyPlayerInputs6.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_101();
				hexaBodyPlayerInputs7.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs4.vector2_1 = hexaXRInputs2;
			return;
			Block_2:
			hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
		}

		// Token: 0x06003411 RID: 13329 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3641408", Offset = "0x3641408", VA = "0x3641408")]
		[Token(Token = "0x6003411")]
		protected bool method_76()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003412 RID: 13330 RVA: 0x00066FD8 File Offset: 0x000651D8
		[Address(RVA = "0x3641458", Offset = "0x3641458", VA = "0x3641458", Slot = "18")]
		[Token(Token = "0x6003412")]
		protected virtual bool vmethod_14()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_106();
		}

		// Token: 0x06003413 RID: 13331 RVA: 0x00067000 File Offset: 0x00065200
		[Address(RVA = "0x36414C4", Offset = "0x36414C4", VA = "0x36414C4")]
		[Token(Token = "0x6003413")]
		protected void method_77()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_46();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_73();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_53();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x06003414 RID: 13332 RVA: 0x00066724 File Offset: 0x00064924
		[Address(RVA = "0x364169C", Offset = "0x364169C", VA = "0x364169C", Slot = "19")]
		[Token(Token = "0x6003414")]
		protected virtual bool vmethod_15()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.Boolean_1;
		}

		// Token: 0x06003415 RID: 13333 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3641708", Offset = "0x3641708", VA = "0x3641708")]
		[Token(Token = "0x6003415")]
		protected bool method_78()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003416 RID: 13334 RVA: 0x00065EDC File Offset: 0x000640DC
		[Address(RVA = "0x3641754", Offset = "0x3641754", VA = "0x3641754")]
		[Token(Token = "0x6003416")]
		protected bool method_79()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x06003417 RID: 13335 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x36417C8", Offset = "0x36417C8", VA = "0x36417C8")]
		[Token(Token = "0x6003417")]
		protected bool method_80()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003418 RID: 13336 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363EBFC", Offset = "0x363EBFC", VA = "0x363EBFC")]
		[Token(Token = "0x6003418")]
		protected bool method_81()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003419 RID: 13337 RVA: 0x00066724 File Offset: 0x00064924
		[Address(RVA = "0x3641814", Offset = "0x3641814", VA = "0x3641814", Slot = "20")]
		[Token(Token = "0x6003419")]
		protected virtual bool vmethod_16()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.Boolean_1;
		}

		// Token: 0x0600341A RID: 13338 RVA: 0x00065EDC File Offset: 0x000640DC
		[Address(RVA = "0x3641880", Offset = "0x3641880", VA = "0x3641880")]
		[Token(Token = "0x600341A")]
		protected bool method_82()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_29();
		}

		// Token: 0x0600341B RID: 13339 RVA: 0x00066724 File Offset: 0x00064924
		[Address(RVA = "0x36418F4", Offset = "0x36418F4", VA = "0x36418F4", Slot = "21")]
		[Token(Token = "0x600341B")]
		protected virtual bool vmethod_17()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.Boolean_1;
		}

		// Token: 0x0600341C RID: 13340 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3641960", Offset = "0x3641960", VA = "0x3641960")]
		[Token(Token = "0x600341C")]
		protected bool method_83()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600341D RID: 13341 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3640644", Offset = "0x3640644", VA = "0x3640644")]
		[Token(Token = "0x600341D")]
		protected bool method_84()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600341E RID: 13342 RVA: 0x00067124 File Offset: 0x00065324
		[Address(RVA = "0x36419B0", Offset = "0x36419B0", VA = "0x36419B0")]
		[Token(Token = "0x600341E")]
		protected bool method_85()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_82();
		}

		// Token: 0x0600341F RID: 13343 RVA: 0x000661EC File Offset: 0x000643EC
		[Address(RVA = "0x3641A24", Offset = "0x3641A24", VA = "0x3641A24", Slot = "22")]
		[Token(Token = "0x600341F")]
		protected virtual bool vmethod_18()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_29();
		}

		// Token: 0x06003420 RID: 13344 RVA: 0x00067148 File Offset: 0x00065348
		[Address(RVA = "0x3641A90", Offset = "0x3641A90", VA = "0x3641A90")]
		[Token(Token = "0x6003420")]
		protected void method_86()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_62();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_57();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_34();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x06003421 RID: 13345 RVA: 0x00066AE4 File Offset: 0x00064CE4
		[Address(RVA = "0x3641C68", Offset = "0x3641C68", VA = "0x3641C68", Slot = "23")]
		[Token(Token = "0x6003421")]
		protected virtual bool vmethod_19()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_20();
		}

		// Token: 0x06003422 RID: 13346 RVA: 0x00066478 File Offset: 0x00064678
		[Address(RVA = "0x3641CD4", Offset = "0x3641CD4", VA = "0x3641CD4", Slot = "24")]
		[Token(Token = "0x6003422")]
		protected virtual bool vmethod_20()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_41();
		}

		// Token: 0x06003423 RID: 13347 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363E764", Offset = "0x363E764", VA = "0x363E764")]
		[Token(Token = "0x6003423")]
		protected bool method_87()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003424 RID: 13348 RVA: 0x000661EC File Offset: 0x000643EC
		[Address(RVA = "0x3641D40", Offset = "0x3641D40", VA = "0x3641D40", Slot = "25")]
		[Token(Token = "0x6003424")]
		protected virtual bool vmethod_21()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_29();
		}

		// Token: 0x06003425 RID: 13349 RVA: 0x000665D8 File Offset: 0x000647D8
		[Address(RVA = "0x3641DAC", Offset = "0x3641DAC", VA = "0x3641DAC", Slot = "26")]
		[Token(Token = "0x6003425")]
		protected virtual bool vmethod_22()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_16();
		}

		// Token: 0x06003426 RID: 13350 RVA: 0x0006726C File Offset: 0x0006546C
		[Address(RVA = "0x3641E18", Offset = "0x3641E18", VA = "0x3641E18")]
		[Token(Token = "0x6003426")]
		protected void method_88()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_7();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_8();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_1();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x06003427 RID: 13351 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3641FF0", Offset = "0x3641FF0", VA = "0x3641FF0")]
		[Token(Token = "0x6003427")]
		protected bool method_89()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003428 RID: 13352 RVA: 0x00066FD8 File Offset: 0x000651D8
		[Address(RVA = "0x364203C", Offset = "0x364203C", VA = "0x364203C", Slot = "27")]
		[Token(Token = "0x6003428")]
		protected virtual bool vmethod_23()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_106();
		}

		// Token: 0x06003429 RID: 13353 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x36420A8", Offset = "0x36420A8", VA = "0x36420A8")]
		[Token(Token = "0x6003429")]
		protected bool method_90()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600342A RID: 13354 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x36420F8", Offset = "0x36420F8", VA = "0x36420F8")]
		[Token(Token = "0x600342A")]
		protected bool method_91()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x0600342B RID: 13355 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x364216C", Offset = "0x364216C", VA = "0x364216C")]
		[Token(Token = "0x600342B")]
		protected bool method_92()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600342C RID: 13356 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x36421BC", Offset = "0x36421BC", VA = "0x36421BC")]
		[Token(Token = "0x600342C")]
		protected bool method_93()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600342D RID: 13357 RVA: 0x000665D8 File Offset: 0x000647D8
		[Address(RVA = "0x3642208", Offset = "0x3642208", VA = "0x3642208", Slot = "28")]
		[Token(Token = "0x600342D")]
		protected virtual bool vmethod_24()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_16();
		}

		// Token: 0x0600342E RID: 13358 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3642274", Offset = "0x3642274", VA = "0x3642274")]
		[Token(Token = "0x600342E")]
		protected bool method_94()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600342F RID: 13359 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363FFFC", Offset = "0x363FFFC", VA = "0x363FFFC")]
		[Token(Token = "0x600342F")]
		protected bool method_95()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003430 RID: 13360 RVA: 0x00067390 File Offset: 0x00065590
		[Address(RVA = "0x36422C4", Offset = "0x36422C4", VA = "0x36422C4")]
		[Token(Token = "0x6003430")]
		protected void method_96()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_3();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_78();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_99();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x06003431 RID: 13361 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363E714", Offset = "0x363E714", VA = "0x363E714")]
		[Token(Token = "0x6003431")]
		protected bool method_97()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003432 RID: 13362 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363F330", Offset = "0x363F330", VA = "0x363F330")]
		[Token(Token = "0x6003432")]
		protected bool method_98()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003433 RID: 13363 RVA: 0x00067124 File Offset: 0x00065324
		[Address(RVA = "0x3642498", Offset = "0x3642498", VA = "0x3642498")]
		[Token(Token = "0x6003433")]
		protected bool method_99()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_82();
		}

		// Token: 0x06003434 RID: 13364 RVA: 0x000665D8 File Offset: 0x000647D8
		[Address(RVA = "0x364250C", Offset = "0x364250C", VA = "0x364250C", Slot = "29")]
		[Token(Token = "0x6003434")]
		protected virtual bool vmethod_25()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_16();
		}

		// Token: 0x06003435 RID: 13365 RVA: 0x000674B4 File Offset: 0x000656B4
		[Address(RVA = "0x3642578", Offset = "0x3642578", VA = "0x3642578")]
		[Token(Token = "0x6003435")]
		protected void method_100()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_58();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_80();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_53();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x06003436 RID: 13366 RVA: 0x000665D8 File Offset: 0x000647D8
		[Address(RVA = "0x364274C", Offset = "0x364274C", VA = "0x364274C", Slot = "30")]
		[Token(Token = "0x6003436")]
		protected virtual bool vmethod_26()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_16();
		}

		// Token: 0x06003437 RID: 13367 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x364092C", Offset = "0x364092C", VA = "0x364092C")]
		[Token(Token = "0x6003437")]
		protected bool method_101()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x06003438 RID: 13368 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x36427B8", Offset = "0x36427B8", VA = "0x36427B8")]
		[Token(Token = "0x6003438")]
		protected bool method_102()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x06003439 RID: 13369 RVA: 0x00066884 File Offset: 0x00064A84
		[Address(RVA = "0x364282C", Offset = "0x364282C", VA = "0x364282C")]
		[Token(Token = "0x6003439")]
		protected bool method_103()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.Boolean_1;
		}

		// Token: 0x0600343A RID: 13370 RVA: 0x00066058 File Offset: 0x00064258
		[Address(RVA = "0x36428A0", Offset = "0x36428A0", VA = "0x36428A0", Slot = "31")]
		[Token(Token = "0x600343A")]
		protected virtual bool vmethod_27()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_82();
		}

		// Token: 0x0600343B RID: 13371 RVA: 0x000675D8 File Offset: 0x000657D8
		[Address(RVA = "0x364290C", Offset = "0x364290C", VA = "0x364290C")]
		[Token(Token = "0x600343B")]
		protected void method_104()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_110();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_2();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_111();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x0600343C RID: 13372 RVA: 0x000660A4 File Offset: 0x000642A4
		[Address(RVA = "0x3642B54", Offset = "0x3642B54", VA = "0x3642B54")]
		[Token(Token = "0x600343C")]
		protected bool method_105()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_41();
		}

		// Token: 0x0600343D RID: 13373 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3642BC8", Offset = "0x3642BC8", VA = "0x3642BC8")]
		[Token(Token = "0x600343D")]
		protected bool method_106()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x0600343E RID: 13374 RVA: 0x000676FC File Offset: 0x000658FC
		[Address(RVA = "0x3642C14", Offset = "0x3642C14", VA = "0x3642C14")]
		[Token(Token = "0x600343E")]
		protected void method_107()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0 && this.hexaXRInputs_0 == null)
			{
				hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				return;
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs.playerInputState_6 != null)
				{
					x = hexaXRInputs.vector2_2.x;
					y = hexaXRInputs.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				this.hexaBodyPlayerInputs_0.bool_5 = (hexaXRInputs != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_36();
				hexaBodyPlayerInputs6.bool_6 = (hexaXRInputs != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_44();
				hexaBodyPlayerInputs7.bool_4 = (hexaXRInputs != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs;
		}

		// Token: 0x0600343F RID: 13375 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363F708", Offset = "0x363F708", VA = "0x363F708")]
		[Token(Token = "0x600343F")]
		protected bool method_108()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003440 RID: 13376 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x3642DEC", Offset = "0x3642DEC", VA = "0x3642DEC")]
		[Token(Token = "0x6003440")]
		protected bool method_109()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003441 RID: 13377 RVA: 0x0006602C File Offset: 0x0006422C
		[Address(RVA = "0x363E374", Offset = "0x363E374", VA = "0x363E374")]
		[Token(Token = "0x6003441")]
		protected bool method_110()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x06003442 RID: 13378 RVA: 0x000661EC File Offset: 0x000643EC
		[Address(RVA = "0x3642E3C", Offset = "0x3642E3C", VA = "0x3642E3C", Slot = "32")]
		[Token(Token = "0x6003442")]
		protected virtual bool vmethod_28()
		{
			if (!this.hexaXRInputs_0.bool_10)
			{
			}
			return this.hexaXRInputs_1.method_29();
		}

		// Token: 0x06003443 RID: 13379 RVA: 0x00066080 File Offset: 0x00064280
		[Address(RVA = "0x3642AE0", Offset = "0x3642AE0", VA = "0x3642AE0")]
		[Token(Token = "0x6003443")]
		protected bool method_111()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			return hexaXRInputs.method_20();
		}

		// Token: 0x06003444 RID: 13380 RVA: 0x00067810 File Offset: 0x00065A10
		[Address(RVA = "0x3642EA8", Offset = "0x3642EA8", VA = "0x3642EA8")]
		[Token(Token = "0x6003444")]
		protected void method_112()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.bool_0)
			{
				HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
				if (hexaXRInputs != null && hexaXRInputs == null)
				{
					hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
					return;
				}
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs2;
			if (hexaBodyPlayerInputs != null)
			{
				hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
			}
			if (hexaBodyPlayerInputs2 == null || hexaBodyPlayerInputs2 == null)
			{
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs3 = this.hexaBodyPlayerInputs_0;
			HexaBodyPlayerInputs hexaBodyPlayerInputs4 = this.hexaBodyPlayerInputs_0;
			if (hexaBodyPlayerInputs3 == null)
			{
				return;
			}
			if (hexaBodyPlayerInputs3 != null)
			{
				if (hexaBodyPlayerInputs4 == null)
				{
					return;
				}
			}
			else
			{
				Vector2 zero = Vector2.zero;
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			bool bool_ = hexaXRInputs2.bool_10;
			HexaBodyPlayerInputs hexaBodyPlayerInputs5 = this.hexaBodyPlayerInputs_0;
			if (bool_)
			{
				float x;
				float y;
				if (hexaXRInputs2.playerInputState_6 != null)
				{
					x = hexaXRInputs2.vector2_2.x;
					y = hexaXRInputs2.vector2_2.y;
					if (hexaBodyPlayerInputs5 == null)
					{
						return;
					}
				}
				else
				{
					Vector2 zero2 = Vector2.zero;
				}
				hexaBodyPlayerInputs5.vector2_1.x = x;
				hexaBodyPlayerInputs5.vector2_1.y = y;
				HexaBodyPlayerInputs hexaBodyPlayerInputs6 = this.hexaBodyPlayerInputs_0;
				this.method_83();
				hexaBodyPlayerInputs6.bool_5 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs7 = this.hexaBodyPlayerInputs_0;
				this.method_13();
				hexaBodyPlayerInputs7.bool_6 = (hexaXRInputs2 != null);
				HexaBodyPlayerInputs hexaBodyPlayerInputs8 = this.hexaBodyPlayerInputs_0;
				this.method_61();
				hexaBodyPlayerInputs8.bool_4 = (hexaXRInputs2 != null);
				return;
			}
			hexaBodyPlayerInputs5.vector2_1 = hexaXRInputs2;
		}

		// Token: 0x04000666 RID: 1638
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000666")]
		public HexaXRInputs hexaXRInputs_0;

		// Token: 0x04000667 RID: 1639
		[Token(Token = "0x4000667")]
		[FieldOffset(Offset = "0x20")]
		public HexaXRInputs hexaXRInputs_1;

		// Token: 0x04000668 RID: 1640
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000668")]
		public float float_0;

		// Token: 0x04000669 RID: 1641
		[Token(Token = "0x4000669")]
		[FieldOffset(Offset = "0x2C")]
		public float float_1;

		// Token: 0x0400066A RID: 1642
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400066A")]
		public HexaBodyPlayerInputs hexaBodyPlayerInputs_0;

		// Token: 0x0400066B RID: 1643
		[Token(Token = "0x400066B")]
		[FieldOffset(Offset = "0x38")]
		public bool bool_0;
	}
}
