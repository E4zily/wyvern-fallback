﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000172 RID: 370
	[Token(Token = "0x2000172")]
	public class TimeManager : MonoBehaviour
	{
		// Token: 0x06003903 RID: 14595 RVA: 0x00072434 File Offset: 0x00070634
		[Address(RVA = "0x25D2B58", Offset = "0x25D2B58", VA = "0x25D2B58")]
		[Token(Token = "0x6003903")]
		private void method_0()
		{
			float refreshRate = XRDevice.refreshRate;
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003904 RID: 14596 RVA: 0x00072450 File Offset: 0x00070650
		[Address(RVA = "0x25D2BE4", Offset = "0x25D2BE4", VA = "0x25D2BE4")]
		[Token(Token = "0x6003904")]
		private void Start()
		{
			this.method_0();
			Class42<float> @class;
			this.class42_0 = @class;
			this.method_25();
			float num = this.float_0;
			this.float_1 = num;
		}

		// Token: 0x06003905 RID: 14597 RVA: 0x00072434 File Offset: 0x00070634
		[Address(RVA = "0x25D2D14", Offset = "0x25D2D14", VA = "0x25D2D14")]
		[Token(Token = "0x6003905")]
		private void method_1()
		{
			float refreshRate = XRDevice.refreshRate;
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003906 RID: 14598 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x25D2DA4", Offset = "0x25D2DA4", VA = "0x25D2DA4")]
		[Token(Token = "0x6003906")]
		private void method_2(float float_3)
		{
		}

		// Token: 0x06003907 RID: 14599 RVA: 0x00072480 File Offset: 0x00070680
		[Token(Token = "0x6003907")]
		[Address(RVA = "0x25D2DAC", Offset = "0x25D2DAC", VA = "0x25D2DAC")]
		private void method_3()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06003923 RID: 14627 RVA: 0x00003632 File Offset: 0x00001832
		// (set) Token: 0x06003908 RID: 14600 RVA: 0x0000362A File Offset: 0x0000182A
		[Token(Token = "0x170000EA")]
		public static TimeManager TimeManager_0 { [Token(Token = "0x6003923")] [Address(RVA = "0x25D3CD8", Offset = "0x25D3CD8", VA = "0x25D3CD8")] get; [Address(RVA = "0x25D2E38", Offset = "0x25D2E38", VA = "0x25D2E38")] [Token(Token = "0x6003908")] private set; }

		// Token: 0x06003909 RID: 14601 RVA: 0x00072494 File Offset: 0x00070694
		[Address(RVA = "0x25D2E8C", Offset = "0x25D2E8C", VA = "0x25D2E8C")]
		[Token(Token = "0x6003909")]
		public void method_4(float float_3)
		{
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = float_3;
		}

		// Token: 0x0600390A RID: 14602 RVA: 0x00072494 File Offset: 0x00070694
		[Address(RVA = "0x25D2EB0", Offset = "0x25D2EB0", VA = "0x25D2EB0")]
		[Token(Token = "0x600390A")]
		public void method_5(float float_3)
		{
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = float_3;
		}

		// Token: 0x0600390B RID: 14603 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x25D2ED4", Offset = "0x25D2ED4", VA = "0x25D2ED4")]
		[Token(Token = "0x600390B")]
		public float method_6()
		{
		}

		// Token: 0x0600390C RID: 14604 RVA: 0x000724B0 File Offset: 0x000706B0
		[Token(Token = "0x600390C")]
		[Address(RVA = "0x25D2EDC", Offset = "0x25D2EDC", VA = "0x25D2EDC")]
		private void method_7()
		{
			TimeManager.timeManager_0;
			UnityEngine.Object.Destroy(this);
		}

		// Token: 0x0600390D RID: 14605 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x25D301C", Offset = "0x25D301C", VA = "0x25D301C")]
		[Token(Token = "0x600390D")]
		public float method_8()
		{
		}

		// Token: 0x0600390E RID: 14606 RVA: 0x0000362A File Offset: 0x0000182A
		[Address(RVA = "0x25D3024", Offset = "0x25D3024", VA = "0x25D3024")]
		[Token(Token = "0x600390E")]
		private static void smethod_0(TimeManager timeManager_1)
		{
			TimeManager.timeManager_0 = timeManager_1;
		}

		// Token: 0x0600390F RID: 14607 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x600390F")]
		[Address(RVA = "0x25D3078", Offset = "0x25D3078", VA = "0x25D3078")]
		public float method_9()
		{
		}

		// Token: 0x06003910 RID: 14608 RVA: 0x00072480 File Offset: 0x00070680
		[Token(Token = "0x6003910")]
		[Address(RVA = "0x25D3080", Offset = "0x25D3080", VA = "0x25D3080")]
		private void method_10()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x06003911 RID: 14609 RVA: 0x000724D0 File Offset: 0x000706D0
		[Token(Token = "0x6003911")]
		[Address(RVA = "0x25D310C", Offset = "0x25D310C", VA = "0x25D310C")]
		private void method_11()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003912 RID: 14610 RVA: 0x000724FC File Offset: 0x000706FC
		[Address(RVA = "0x25D3334", Offset = "0x25D3334", VA = "0x25D3334")]
		[Token(Token = "0x6003912")]
		private void method_12()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003913 RID: 14611 RVA: 0x000724B0 File Offset: 0x000706B0
		[Address(RVA = "0x25D34B4", Offset = "0x25D34B4", VA = "0x25D34B4")]
		[Token(Token = "0x6003913")]
		private void method_13()
		{
			TimeManager.timeManager_0;
			UnityEngine.Object.Destroy(this);
		}

		// Token: 0x06003914 RID: 14612 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x6003914")]
		[Address(RVA = "0x25D35F4", Offset = "0x25D35F4", VA = "0x25D35F4")]
		public float method_14()
		{
		}

		// Token: 0x06003915 RID: 14613 RVA: 0x0000362A File Offset: 0x0000182A
		[Address(RVA = "0x25D35FC", Offset = "0x25D35FC", VA = "0x25D35FC")]
		[Token(Token = "0x6003915")]
		private static void smethod_1(TimeManager timeManager_1)
		{
			TimeManager.timeManager_0 = timeManager_1;
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06003935 RID: 14645 RVA: 0x0003584C File Offset: 0x00033A4C
		// (set) Token: 0x06003916 RID: 14614 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000E9")]
		public float Single_0
		{
			[Token(Token = "0x6003935")]
			[CompilerGenerated]
			[Address(RVA = "0x25D4544", Offset = "0x25D4544", VA = "0x25D4544")]
			get
			{
			}
			[CompilerGenerated]
			[Address(RVA = "0x25D3650", Offset = "0x25D3650", VA = "0x25D3650")]
			[Token(Token = "0x6003916")]
			private set
			{
			}
		}

		// Token: 0x06003917 RID: 14615 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x25D3658", Offset = "0x25D3658", VA = "0x25D3658")]
		[Token(Token = "0x6003917")]
		public float method_15()
		{
		}

		// Token: 0x06003918 RID: 14616 RVA: 0x00003632 File Offset: 0x00001832
		[Token(Token = "0x6003918")]
		[Address(RVA = "0x25D3660", Offset = "0x25D3660", VA = "0x25D3660")]
		public static TimeManager smethod_2()
		{
			return TimeManager.timeManager_0;
		}

		// Token: 0x06003919 RID: 14617 RVA: 0x00003632 File Offset: 0x00001832
		[Token(Token = "0x6003919")]
		[Address(RVA = "0x25D36AC", Offset = "0x25D36AC", VA = "0x25D36AC")]
		public static TimeManager smethod_3()
		{
			return TimeManager.timeManager_0;
		}

		// Token: 0x0600391A RID: 14618 RVA: 0x00003632 File Offset: 0x00001832
		[Token(Token = "0x600391A")]
		[Address(RVA = "0x25D36F8", Offset = "0x25D36F8", VA = "0x25D36F8")]
		public static TimeManager smethod_4()
		{
			return TimeManager.timeManager_0;
		}

		// Token: 0x0600391B RID: 14619 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600391B")]
		[Address(RVA = "0x25D3744", Offset = "0x25D3744", VA = "0x25D3744")]
		private void method_16(float float_3)
		{
		}

		// Token: 0x0600391C RID: 14620 RVA: 0x00003632 File Offset: 0x00001832
		[Token(Token = "0x600391C")]
		[Address(RVA = "0x25D374C", Offset = "0x25D374C", VA = "0x25D374C")]
		public static TimeManager smethod_5()
		{
			return TimeManager.timeManager_0;
		}

		// Token: 0x0600391D RID: 14621 RVA: 0x00072528 File Offset: 0x00070728
		[Address(RVA = "0x25D3798", Offset = "0x25D3798", VA = "0x25D3798")]
		[Token(Token = "0x600391D")]
		private void method_17()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x0600391E RID: 14622 RVA: 0x00072554 File Offset: 0x00070754
		[Token(Token = "0x600391E")]
		[Address(RVA = "0x25D39C8", Offset = "0x25D39C8", VA = "0x25D39C8")]
		public void method_18()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600391F RID: 14623 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x600391F")]
		[Address(RVA = "0x25D3A54", Offset = "0x25D3A54", VA = "0x25D3A54")]
		public float method_19()
		{
		}

		// Token: 0x06003920 RID: 14624 RVA: 0x000724D0 File Offset: 0x000706D0
		[Token(Token = "0x6003920")]
		[Address(RVA = "0x25D3A5C", Offset = "0x25D3A5C", VA = "0x25D3A5C")]
		private void method_20()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003921 RID: 14625 RVA: 0x0000362A File Offset: 0x0000182A
		[Address(RVA = "0x25D3BF4", Offset = "0x25D3BF4", VA = "0x25D3BF4")]
		[Token(Token = "0x6003921")]
		private static void smethod_6(TimeManager timeManager_1)
		{
			TimeManager.timeManager_0 = timeManager_1;
		}

		// Token: 0x06003922 RID: 14626 RVA: 0x00072434 File Offset: 0x00070634
		[Token(Token = "0x6003922")]
		[Address(RVA = "0x25D3C48", Offset = "0x25D3C48", VA = "0x25D3C48")]
		private void method_21()
		{
			float refreshRate = XRDevice.refreshRate;
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003924 RID: 14628 RVA: 0x00072434 File Offset: 0x00070634
		[Address(RVA = "0x25D3D24", Offset = "0x25D3D24", VA = "0x25D3D24")]
		[Token(Token = "0x6003924")]
		private void method_22()
		{
			float refreshRate = XRDevice.refreshRate;
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003925 RID: 14629 RVA: 0x000724B0 File Offset: 0x000706B0
		[Token(Token = "0x6003925")]
		[Address(RVA = "0x25D3DB4", Offset = "0x25D3DB4", VA = "0x25D3DB4")]
		private void method_23()
		{
			TimeManager.timeManager_0;
			UnityEngine.Object.Destroy(this);
		}

		// Token: 0x06003926 RID: 14630 RVA: 0x00072434 File Offset: 0x00070634
		[Token(Token = "0x6003926")]
		[Address(RVA = "0x25D3938", Offset = "0x25D3938", VA = "0x25D3938")]
		private void method_24()
		{
			float refreshRate = XRDevice.refreshRate;
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003927 RID: 14631 RVA: 0x00072480 File Offset: 0x00070680
		[Address(RVA = "0x25D2C88", Offset = "0x25D2C88", VA = "0x25D2C88")]
		[Token(Token = "0x6003927")]
		private void method_25()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x06003928 RID: 14632 RVA: 0x00072554 File Offset: 0x00070754
		[Token(Token = "0x6003928")]
		[Address(RVA = "0x25D3EF4", Offset = "0x25D3EF4", VA = "0x25D3EF4")]
		public void method_26()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003929 RID: 14633 RVA: 0x00072494 File Offset: 0x00070694
		[Address(RVA = "0x25D3F80", Offset = "0x25D3F80", VA = "0x25D3F80")]
		[Token(Token = "0x6003929")]
		public void method_27(float float_3)
		{
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = float_3;
		}

		// Token: 0x0600392A RID: 14634 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600392A")]
		[Address(RVA = "0x25D3FA0", Offset = "0x25D3FA0", VA = "0x25D3FA0")]
		private void method_28(float float_3)
		{
		}

		// Token: 0x0600392B RID: 14635 RVA: 0x00072578 File Offset: 0x00070778
		[Token(Token = "0x600392B")]
		[Address(RVA = "0x25D3FA8", Offset = "0x25D3FA8", VA = "0x25D3FA8")]
		private void method_29()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x0600392C RID: 14636 RVA: 0x000725A4 File Offset: 0x000707A4
		[Address(RVA = "0x25D4128", Offset = "0x25D4128", VA = "0x25D4128")]
		[Token(Token = "0x600392C")]
		private void method_30()
		{
			this.method_21();
			Class42<float> @class;
			this.class42_0 = @class;
			this.method_10();
			float num = this.float_0;
			this.float_1 = num;
		}

		// Token: 0x0600392D RID: 14637 RVA: 0x00072434 File Offset: 0x00070634
		[Address(RVA = "0x25D41CC", Offset = "0x25D41CC", VA = "0x25D41CC")]
		[Token(Token = "0x600392D")]
		private void method_31()
		{
			float refreshRate = XRDevice.refreshRate;
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600392E RID: 14638 RVA: 0x0000362A File Offset: 0x0000182A
		[Token(Token = "0x600392E")]
		[Address(RVA = "0x25D425C", Offset = "0x25D425C", VA = "0x25D425C")]
		private static void smethod_7(TimeManager timeManager_1)
		{
			TimeManager.timeManager_0 = timeManager_1;
		}

		// Token: 0x0600392F RID: 14639 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600392F")]
		[Address(RVA = "0x25D42B0", Offset = "0x25D42B0", VA = "0x25D42B0")]
		private void method_32(float float_3)
		{
		}

		// Token: 0x06003930 RID: 14640 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x25D42B8", Offset = "0x25D42B8", VA = "0x25D42B8")]
		[Token(Token = "0x6003930")]
		public float method_33()
		{
		}

		// Token: 0x06003931 RID: 14641 RVA: 0x0000362A File Offset: 0x0000182A
		[Token(Token = "0x6003931")]
		[Address(RVA = "0x25D42C0", Offset = "0x25D42C0", VA = "0x25D42C0")]
		private static void smethod_8(TimeManager timeManager_1)
		{
			TimeManager.timeManager_0 = timeManager_1;
		}

		// Token: 0x06003932 RID: 14642 RVA: 0x000725D4 File Offset: 0x000707D4
		[Address(RVA = "0x25D4314", Offset = "0x25D4314", VA = "0x25D4314")]
		[Token(Token = "0x6003932")]
		private void method_34()
		{
			this.method_50();
			Class42<float> @class;
			this.class42_0 = @class;
			this.method_25();
			float num = this.float_0;
			this.float_1 = num;
		}

		// Token: 0x06003933 RID: 14643 RVA: 0x000724B0 File Offset: 0x000706B0
		[Token(Token = "0x6003933")]
		[Address(RVA = "0x25D43B8", Offset = "0x25D43B8", VA = "0x25D43B8")]
		private void Awake()
		{
			TimeManager.timeManager_0;
			UnityEngine.Object.Destroy(this);
		}

		// Token: 0x06003934 RID: 14644 RVA: 0x00003632 File Offset: 0x00001832
		[Address(RVA = "0x25D44F8", Offset = "0x25D44F8", VA = "0x25D44F8")]
		[Token(Token = "0x6003934")]
		public static TimeManager smethod_9()
		{
			return TimeManager.timeManager_0;
		}

		// Token: 0x06003936 RID: 14646 RVA: 0x00072554 File Offset: 0x00070754
		[Address(RVA = "0x25D454C", Offset = "0x25D454C", VA = "0x25D454C")]
		[Token(Token = "0x6003936")]
		public void method_35()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003937 RID: 14647 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x25D45D8", Offset = "0x25D45D8", VA = "0x25D45D8")]
		[Token(Token = "0x6003937")]
		public float method_36()
		{
		}

		// Token: 0x06003938 RID: 14648 RVA: 0x000724D0 File Offset: 0x000706D0
		[Address(RVA = "0x25D45E0", Offset = "0x25D45E0", VA = "0x25D45E0")]
		[Token(Token = "0x6003938")]
		private void method_37()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003939 RID: 14649 RVA: 0x00072494 File Offset: 0x00070694
		[Token(Token = "0x6003939")]
		[Address(RVA = "0x25D4780", Offset = "0x25D4780", VA = "0x25D4780")]
		public void method_38(float float_3)
		{
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = float_3;
		}

		// Token: 0x0600393A RID: 14650 RVA: 0x00072554 File Offset: 0x00070754
		[Address(RVA = "0x25D47A4", Offset = "0x25D47A4", VA = "0x25D47A4")]
		[Token(Token = "0x600393A")]
		public void method_39()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600393B RID: 14651 RVA: 0x00072554 File Offset: 0x00070754
		[Address(RVA = "0x25D4830", Offset = "0x25D4830", VA = "0x25D4830")]
		[Token(Token = "0x600393B")]
		public void method_40()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600393C RID: 14652 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600393C")]
		[Address(RVA = "0x25D48BC", Offset = "0x25D48BC", VA = "0x25D48BC")]
		private void method_41(float float_3)
		{
		}

		// Token: 0x0600393D RID: 14653 RVA: 0x0000362A File Offset: 0x0000182A
		[Token(Token = "0x600393D")]
		[Address(RVA = "0x25D48C4", Offset = "0x25D48C4", VA = "0x25D48C4")]
		private static void smethod_10(TimeManager timeManager_1)
		{
			TimeManager.timeManager_0 = timeManager_1;
		}

		// Token: 0x0600393E RID: 14654 RVA: 0x000724D0 File Offset: 0x000706D0
		[Token(Token = "0x600393E")]
		[Address(RVA = "0x25D4918", Offset = "0x25D4918", VA = "0x25D4918")]
		private void Update()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x0600393F RID: 14655 RVA: 0x00072604 File Offset: 0x00070804
		[Address(RVA = "0x25D4AA4", Offset = "0x25D4AA4", VA = "0x25D4AA4")]
		[Token(Token = "0x600393F")]
		private void method_42()
		{
			this.method_0();
			Class42<float> @class;
			this.class42_0 = @class;
			this.method_49();
			float num = this.float_0;
			this.float_1 = num;
		}

		// Token: 0x06003940 RID: 14656 RVA: 0x00072554 File Offset: 0x00070754
		[Token(Token = "0x6003940")]
		[Address(RVA = "0x25D4BCC", Offset = "0x25D4BCC", VA = "0x25D4BCC")]
		public void method_43()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x06003941 RID: 14657 RVA: 0x00003632 File Offset: 0x00001832
		[Address(RVA = "0x25D4C54", Offset = "0x25D4C54", VA = "0x25D4C54")]
		[Token(Token = "0x6003941")]
		public static TimeManager smethod_11()
		{
			return TimeManager.timeManager_0;
		}

		// Token: 0x06003942 RID: 14658 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003942")]
		[Address(RVA = "0x25D4CA0", Offset = "0x25D4CA0", VA = "0x25D4CA0")]
		private static void smethod_12(TimeManager timeManager_1)
		{
		}

		// Token: 0x06003943 RID: 14659 RVA: 0x0000362A File Offset: 0x0000182A
		[Address(RVA = "0x25D4CF4", Offset = "0x25D4CF4", VA = "0x25D4CF4")]
		[Token(Token = "0x6003943")]
		private static void smethod_13(TimeManager timeManager_1)
		{
			TimeManager.timeManager_0 = timeManager_1;
		}

		// Token: 0x06003944 RID: 14660 RVA: 0x00072634 File Offset: 0x00070834
		[Token(Token = "0x6003944")]
		[Address(RVA = "0x25D4D48", Offset = "0x25D4D48", VA = "0x25D4D48")]
		private void method_44()
		{
			this.method_1();
			Class42<float> @class;
			this.class42_0 = @class;
			this.method_47();
			float num = this.float_0;
			this.float_1 = num;
		}

		// Token: 0x06003945 RID: 14661 RVA: 0x00072664 File Offset: 0x00070864
		[Address(RVA = "0x25D4E70", Offset = "0x25D4E70", VA = "0x25D4E70")]
		[Token(Token = "0x6003945")]
		private void method_45()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x06003946 RID: 14662 RVA: 0x00072494 File Offset: 0x00070694
		[Token(Token = "0x6003946")]
		[Address(RVA = "0x25D4EF4", Offset = "0x25D4EF4", VA = "0x25D4EF4")]
		public void method_46(float float_3)
		{
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = float_3;
		}

		// Token: 0x06003947 RID: 14663 RVA: 0x00072678 File Offset: 0x00070878
		[Address(RVA = "0x25D4DEC", Offset = "0x25D4DEC", VA = "0x25D4DEC")]
		[Token(Token = "0x6003947")]
		private void method_47()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x06003948 RID: 14664 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003948")]
		[Address(RVA = "0x25D4F18", Offset = "0x25D4F18", VA = "0x25D4F18")]
		private void method_48(float float_3)
		{
		}

		// Token: 0x06003949 RID: 14665 RVA: 0x00072664 File Offset: 0x00070864
		[Address(RVA = "0x25D4B48", Offset = "0x25D4B48", VA = "0x25D4B48")]
		[Token(Token = "0x6003949")]
		private void method_49()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x0600394A RID: 14666 RVA: 0x00072434 File Offset: 0x00070634
		[Token(Token = "0x600394A")]
		[Address(RVA = "0x25D32A4", Offset = "0x25D32A4", VA = "0x25D32A4")]
		private void method_50()
		{
			float refreshRate = XRDevice.refreshRate;
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600394B RID: 14667 RVA: 0x00072554 File Offset: 0x00070754
		[Token(Token = "0x600394B")]
		[Address(RVA = "0x25D4F20", Offset = "0x25D4F20", VA = "0x25D4F20")]
		public void method_51()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600394C RID: 14668 RVA: 0x00072554 File Offset: 0x00070754
		[Token(Token = "0x600394C")]
		[Address(RVA = "0x25D4FAC", Offset = "0x25D4FAC", VA = "0x25D4FAC")]
		public void method_52()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600394D RID: 14669 RVA: 0x00072554 File Offset: 0x00070754
		[Token(Token = "0x600394D")]
		[Address(RVA = "0x25D5038", Offset = "0x25D5038", VA = "0x25D5038")]
		public void method_53()
		{
			float refreshRate = XRDevice.refreshRate;
			if (this.bool_0)
			{
				return;
			}
			Time.fixedDeltaTime = refreshRate;
		}

		// Token: 0x0600394E RID: 14670 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x25D50C4", Offset = "0x25D50C4", VA = "0x25D50C4")]
		[Token(Token = "0x600394E")]
		private static void smethod_14(TimeManager timeManager_1)
		{
		}

		// Token: 0x0600394F RID: 14671 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600394F")]
		[Address(RVA = "0x25D5118", Offset = "0x25D5118", VA = "0x25D5118")]
		private void method_54(float float_3)
		{
		}

		// Token: 0x06003950 RID: 14672 RVA: 0x000724B0 File Offset: 0x000706B0
		[Token(Token = "0x6003950")]
		[Address(RVA = "0x25D5120", Offset = "0x25D5120", VA = "0x25D5120")]
		private void method_55()
		{
			TimeManager.timeManager_0;
			UnityEngine.Object.Destroy(this);
		}

		// Token: 0x06003951 RID: 14673 RVA: 0x0007268C File Offset: 0x0007088C
		[Token(Token = "0x6003951")]
		[Address(RVA = "0x25D5260", Offset = "0x25D5260", VA = "0x25D5260")]
		public TimeManager()
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
			this.int_2 = 144;
			base..ctor();
		}

		// Token: 0x06003952 RID: 14674 RVA: 0x00072578 File Offset: 0x00070778
		[Address(RVA = "0x25D5284", Offset = "0x25D5284", VA = "0x25D5284")]
		[Token(Token = "0x6003952")]
		private void method_56()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x06003953 RID: 14675 RVA: 0x00072480 File Offset: 0x00070680
		[Token(Token = "0x6003953")]
		[Address(RVA = "0x25D5404", Offset = "0x25D5404", VA = "0x25D5404")]
		private void method_57()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x06003954 RID: 14676 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x6003954")]
		[Address(RVA = "0x25D5490", Offset = "0x25D5490", VA = "0x25D5490")]
		public float method_58()
		{
		}

		// Token: 0x06003955 RID: 14677 RVA: 0x00072528 File Offset: 0x00070728
		[Token(Token = "0x6003955")]
		[Address(RVA = "0x25D5498", Offset = "0x25D5498", VA = "0x25D5498")]
		private void method_59()
		{
			if (this.bool_1)
			{
				float num = this.float_0;
				this.float_1 = num;
			}
			float deltaTime = Time.deltaTime;
		}

		// Token: 0x040009EF RID: 2543
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40009EF")]
		public bool bool_0;

		// Token: 0x040009F0 RID: 2544
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x40009F0")]
		public int int_0;

		// Token: 0x040009F1 RID: 2545
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40009F1")]
		public int int_1;

		// Token: 0x040009F2 RID: 2546
		[Token(Token = "0x40009F2")]
		[FieldOffset(Offset = "0x24")]
		public int int_2;

		// Token: 0x040009F3 RID: 2547
		[Token(Token = "0x40009F3")]
		[CompilerGenerated]
		[FieldOffset(Offset = "0x28")]
		private float float_0;

		// Token: 0x040009F4 RID: 2548
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x40009F4")]
		public bool bool_1;

		// Token: 0x040009F5 RID: 2549
		[Token(Token = "0x40009F5")]
		[FieldOffset(Offset = "0x30")]
		public float float_1;

		// Token: 0x040009F6 RID: 2550
		[Token(Token = "0x40009F6")]
		[FieldOffset(Offset = "0x38")]
		private Class42<float> class42_0;

		// Token: 0x040009F7 RID: 2551
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40009F7")]
		private float float_2;

		// Token: 0x040009F8 RID: 2552
		[CompilerGenerated]
		[Token(Token = "0x40009F8")]
		private static TimeManager timeManager_0;
	}
}
