﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x0200014F RID: 335
	[Token(Token = "0x200014F")]
	public class CollisionDetector : MonoBehaviour
	{
		// Token: 0x0600359A RID: 13722 RVA: 0x0006D26C File Offset: 0x0006B46C
		[Address(RVA = "0x2AF541C", Offset = "0x2AF541C", VA = "0x2AF541C")]
		[Token(Token = "0x600359A")]
		private void method_0()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			bool flag;
			if (this.bool_1)
			{
				flag = this.bool_0;
			}
			bool flag2 = this.bool_0;
			this.bool_2 = flag;
			this.bool_1 = flag2;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x0600359B RID: 13723 RVA: 0x0006D2B4 File Offset: 0x0006B4B4
		[Address(RVA = "0x2AF54E8", Offset = "0x2AF54E8", VA = "0x2AF54E8", Slot = "4")]
		[Token(Token = "0x600359B")]
		protected virtual void vmethod_0(Collision collision_0)
		{
			float sqrMagnitude = collision_0.impulse.sqrMagnitude;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long index = 0L;
			Vector3 normal = collision_0.GetContact((int)index).normal;
			float y = this.vector3_3.y;
			this.vector3_3.y = y;
			float z = this.vector3_3.z;
			this.vector3_3.z = z;
		}

		// Token: 0x0600359C RID: 13724 RVA: 0x0006D31C File Offset: 0x0006B51C
		[Address(RVA = "0x2AF5654", Offset = "0x2AF5654", VA = "0x2AF5654", Slot = "5")]
		[Token(Token = "0x600359C")]
		protected virtual void vmethod_1()
		{
			Component[] array = this.component_0;
			if (array != null && array != null)
			{
				List<GInterface4> list = new List();
				if (list != null)
				{
				}
				this.ginterface4_0 = list;
				return;
			}
			GInterface4[] components = base.GetComponents<GInterface4>();
			this.ginterface4_0 = components;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x0600359D RID: 13725 RVA: 0x0006D31C File Offset: 0x0006B51C
		[Address(RVA = "0x2AF584C", Offset = "0x2AF584C", VA = "0x2AF584C", Slot = "6")]
		[Token(Token = "0x600359D")]
		protected virtual void Awake()
		{
			Component[] array = this.component_0;
			if (array != null && array != null)
			{
				List<GInterface4> list = new List();
				if (list != null)
				{
				}
				this.ginterface4_0 = list;
				return;
			}
			GInterface4[] components = base.GetComponents<GInterface4>();
			this.ginterface4_0 = components;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x0600359E RID: 13726 RVA: 0x0006D364 File Offset: 0x0006B564
		[Address(RVA = "0x2AF5A44", Offset = "0x2AF5A44", VA = "0x2AF5A44", Slot = "7")]
		[Token(Token = "0x600359E")]
		protected virtual void vmethod_2(Collision collision_0)
		{
		}

		// Token: 0x0600359F RID: 13727 RVA: 0x0006D374 File Offset: 0x0006B574
		[Address(RVA = "0x2AF5B3C", Offset = "0x2AF5B3C", VA = "0x2AF5B3C")]
		[Token(Token = "0x600359F")]
		public float method_1(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035A0 RID: 13728 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF5D04", Offset = "0x2AF5D04", VA = "0x2AF5D04")]
		[Token(Token = "0x60035A0")]
		public float method_2(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035A1 RID: 13729 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2AF5EBC", Offset = "0x2AF5EBC", VA = "0x2AF5EBC", Slot = "8")]
		[Token(Token = "0x60035A1")]
		protected virtual void vmethod_3()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060035A2 RID: 13730 RVA: 0x0006D3BC File Offset: 0x0006B5BC
		[Address(RVA = "0x2AF6080", Offset = "0x2AF6080", VA = "0x2AF6080")]
		[Token(Token = "0x60035A2")]
		private void method_3()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			if (this.bool_1)
			{
				return;
			}
			long num = 1L;
			bool flag = this.bool_0;
			this.bool_2 = (num != 0L);
			this.bool_1 = flag;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x060035A3 RID: 13731 RVA: 0x0006D364 File Offset: 0x0006B564
		[Address(RVA = "0x2AF6158", Offset = "0x2AF6158", VA = "0x2AF6158", Slot = "9")]
		[Token(Token = "0x60035A3")]
		protected virtual void vmethod_4(Collision collision_0)
		{
		}

		// Token: 0x060035A4 RID: 13732 RVA: 0x0006D400 File Offset: 0x0006B600
		[Address(RVA = "0x2AF6254", Offset = "0x2AF6254", VA = "0x2AF6254", Slot = "10")]
		[Token(Token = "0x60035A4")]
		protected virtual void OnCollisionEnter(Collision collision_0)
		{
		}

		// Token: 0x060035A5 RID: 13733 RVA: 0x0006D410 File Offset: 0x0006B610
		[Address(RVA = "0x2AF6374", Offset = "0x2AF6374", VA = "0x2AF6374")]
		[Token(Token = "0x60035A5")]
		private void method_4()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			bool flag;
			if (this.bool_1)
			{
				flag = this.bool_0;
			}
			bool flag2 = this.bool_0;
			this.bool_2 = flag;
			long num = 1L;
			this.bool_1 = flag2;
			this.bool_0 = (num != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x060035A6 RID: 13734 RVA: 0x0006D464 File Offset: 0x0006B664
		[Address(RVA = "0x2AF6448", Offset = "0x2AF6448", VA = "0x2AF6448", Slot = "11")]
		[Token(Token = "0x60035A6")]
		protected virtual void vmethod_5(Collision collision_0)
		{
			float sqrMagnitude = collision_0.impulse.sqrMagnitude;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long index = 1L;
			Vector3 normal = collision_0.GetContact((int)index).normal;
			float y = this.vector3_3.y;
			this.vector3_3.y = y;
			float z = this.vector3_3.z;
			this.vector3_3.z = z;
		}

		// Token: 0x060035A7 RID: 13735 RVA: 0x0006D2B4 File Offset: 0x0006B4B4
		[Address(RVA = "0x2AF65B4", Offset = "0x2AF65B4", VA = "0x2AF65B4", Slot = "12")]
		[Token(Token = "0x60035A7")]
		protected virtual void vmethod_6(Collision collision_0)
		{
			float sqrMagnitude = collision_0.impulse.sqrMagnitude;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long index = 0L;
			Vector3 normal = collision_0.GetContact((int)index).normal;
			float y = this.vector3_3.y;
			this.vector3_3.y = y;
			float z = this.vector3_3.z;
			this.vector3_3.z = z;
		}

		// Token: 0x060035A8 RID: 13736 RVA: 0x0006D400 File Offset: 0x0006B600
		[Address(RVA = "0x2AF6704", Offset = "0x2AF6704", VA = "0x2AF6704", Slot = "13")]
		[Token(Token = "0x60035A8")]
		protected virtual void vmethod_7(Collision collision_0)
		{
		}

		// Token: 0x060035A9 RID: 13737 RVA: 0x0006D374 File Offset: 0x0006B574
		[Address(RVA = "0x2AF6828", Offset = "0x2AF6828", VA = "0x2AF6828")]
		[Token(Token = "0x60035A9")]
		public float method_5(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035AA RID: 13738 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF69CC", Offset = "0x2AF69CC", VA = "0x2AF69CC")]
		[Token(Token = "0x60035AA")]
		public float method_6(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035AB RID: 13739 RVA: 0x0006D400 File Offset: 0x0006B600
		[Address(RVA = "0x2AF6B80", Offset = "0x2AF6B80", VA = "0x2AF6B80", Slot = "14")]
		[Token(Token = "0x60035AB")]
		protected virtual void vmethod_8(Collision collision_0)
		{
		}

		// Token: 0x060035AC RID: 13740 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF6CA4", Offset = "0x2AF6CA4", VA = "0x2AF6CA4")]
		[Token(Token = "0x60035AC")]
		public float method_7(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035AD RID: 13741 RVA: 0x0006D4CC File Offset: 0x0006B6CC
		[Address(RVA = "0x2AF6E5C", Offset = "0x2AF6E5C", VA = "0x2AF6E5C")]
		[Token(Token = "0x60035AD")]
		public float method_8(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035AE RID: 13742 RVA: 0x0006D2B4 File Offset: 0x0006B4B4
		[Address(RVA = "0x2AF7014", Offset = "0x2AF7014", VA = "0x2AF7014", Slot = "15")]
		[Token(Token = "0x60035AE")]
		protected virtual void vmethod_9(Collision collision_0)
		{
			float sqrMagnitude = collision_0.impulse.sqrMagnitude;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long index = 0L;
			Vector3 normal = collision_0.GetContact((int)index).normal;
			float y = this.vector3_3.y;
			this.vector3_3.y = y;
			float z = this.vector3_3.z;
			this.vector3_3.z = z;
		}

		// Token: 0x060035AF RID: 13743 RVA: 0x0006D31C File Offset: 0x0006B51C
		[Address(RVA = "0x2AF7180", Offset = "0x2AF7180", VA = "0x2AF7180", Slot = "16")]
		[Token(Token = "0x60035AF")]
		protected virtual void vmethod_10()
		{
			Component[] array = this.component_0;
			if (array != null && array != null)
			{
				List<GInterface4> list = new List();
				if (list != null)
				{
				}
				this.ginterface4_0 = list;
				return;
			}
			GInterface4[] components = base.GetComponents<GInterface4>();
			this.ginterface4_0 = components;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060035B0 RID: 13744 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF7370", Offset = "0x2AF7370", VA = "0x2AF7370")]
		[Token(Token = "0x60035B0")]
		public float method_9(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035B1 RID: 13745 RVA: 0x0006D4F0 File Offset: 0x0006B6F0
		[Address(RVA = "0x2AF7528", Offset = "0x2AF7528", VA = "0x2AF7528", Slot = "17")]
		[Token(Token = "0x60035B1")]
		protected virtual void vmethod_11(Collision collision_0)
		{
			float sqrMagnitude = collision_0.impulse.sqrMagnitude;
			long index = 0L;
			Vector3 normal = collision_0.GetContact((int)index).normal;
			float y = this.vector3_3.y;
			this.vector3_3.y = y;
			float z = this.vector3_3.z;
			this.vector3_3.z = z;
		}

		// Token: 0x060035B2 RID: 13746 RVA: 0x0006D364 File Offset: 0x0006B564
		[Address(RVA = "0x2AF7690", Offset = "0x2AF7690", VA = "0x2AF7690", Slot = "18")]
		[Token(Token = "0x60035B2")]
		protected virtual void vmethod_12(Collision collision_0)
		{
		}

		// Token: 0x060035B3 RID: 13747 RVA: 0x0006D364 File Offset: 0x0006B564
		[Address(RVA = "0x2AF7788", Offset = "0x2AF7788", VA = "0x2AF7788", Slot = "19")]
		[Token(Token = "0x60035B3")]
		protected virtual void vmethod_13(Collision collision_0)
		{
		}

		// Token: 0x060035B4 RID: 13748 RVA: 0x0006D374 File Offset: 0x0006B574
		[Address(RVA = "0x2AF7884", Offset = "0x2AF7884", VA = "0x2AF7884")]
		[Token(Token = "0x60035B4")]
		public float method_10(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035B5 RID: 13749 RVA: 0x0006D26C File Offset: 0x0006B46C
		[Address(RVA = "0x2AF7A48", Offset = "0x2AF7A48", VA = "0x2AF7A48")]
		[Token(Token = "0x60035B5")]
		private void FixedUpdate()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			bool flag;
			if (this.bool_1)
			{
				flag = this.bool_0;
			}
			bool flag2 = this.bool_0;
			this.bool_2 = flag;
			this.bool_1 = flag2;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x060035B6 RID: 13750 RVA: 0x0006D400 File Offset: 0x0006B600
		[Address(RVA = "0x2AF7B18", Offset = "0x2AF7B18", VA = "0x2AF7B18", Slot = "20")]
		[Token(Token = "0x60035B6")]
		protected virtual void OnCollisionStay(Collision collision_0)
		{
		}

		// Token: 0x060035B7 RID: 13751 RVA: 0x0006D364 File Offset: 0x0006B564
		[Address(RVA = "0x2AF7C38", Offset = "0x2AF7C38", VA = "0x2AF7C38", Slot = "21")]
		[Token(Token = "0x60035B7")]
		protected virtual void vmethod_14(Collision collision_0)
		{
		}

		// Token: 0x060035B8 RID: 13752 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF7D34", Offset = "0x2AF7D34", VA = "0x2AF7D34")]
		[Token(Token = "0x60035B8")]
		public float method_11(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035B9 RID: 13753 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF7EE8", Offset = "0x2AF7EE8", VA = "0x2AF7EE8")]
		[Token(Token = "0x60035B9")]
		public float method_12(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035BA RID: 13754 RVA: 0x0006D54C File Offset: 0x0006B74C
		[Address(RVA = "0x2AF809C", Offset = "0x2AF809C", VA = "0x2AF809C", Slot = "22")]
		[Token(Token = "0x60035BA")]
		protected virtual void vmethod_15()
		{
			Component[] array = this.component_0;
			if (array != null && array != null)
			{
				List<GInterface4> list = new List();
				if (list != null)
				{
				}
				this.ginterface4_0 = list;
				return;
			}
			GInterface4[] components = base.GetComponents<GInterface4>();
			this.ginterface4_0 = components;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060035BB RID: 13755 RVA: 0x0006D594 File Offset: 0x0006B794
		[Address(RVA = "0x2AF8268", Offset = "0x2AF8268", VA = "0x2AF8268")]
		[Token(Token = "0x60035BB")]
		private void method_13()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			if (this.bool_1)
			{
				return;
			}
			long num = 1L;
			bool flag = this.bool_0;
			this.bool_2 = (num != 0L);
			this.bool_1 = flag;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x060035BC RID: 13756 RVA: 0x0006D54C File Offset: 0x0006B74C
		[Address(RVA = "0x2AF833C", Offset = "0x2AF833C", VA = "0x2AF833C", Slot = "23")]
		[Token(Token = "0x60035BC")]
		protected virtual void vmethod_16()
		{
			Component[] array = this.component_0;
			if (array != null && array != null)
			{
				List<GInterface4> list = new List();
				if (list != null)
				{
				}
				this.ginterface4_0 = list;
				return;
			}
			GInterface4[] components = base.GetComponents<GInterface4>();
			this.ginterface4_0 = components;
			Vector3 zero = Vector3.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060035BD RID: 13757 RVA: 0x0006D2B4 File Offset: 0x0006B4B4
		[Address(RVA = "0x2AF8500", Offset = "0x2AF8500", VA = "0x2AF8500", Slot = "24")]
		[Token(Token = "0x60035BD")]
		protected virtual void vmethod_17(Collision collision_0)
		{
			float sqrMagnitude = collision_0.impulse.sqrMagnitude;
			long num = 1L;
			this.bool_0 = (num != 0L);
			long index = 0L;
			Vector3 normal = collision_0.GetContact((int)index).normal;
			float y = this.vector3_3.y;
			this.vector3_3.y = y;
			float z = this.vector3_3.z;
			this.vector3_3.z = z;
		}

		// Token: 0x060035BE RID: 13758 RVA: 0x0006D5D8 File Offset: 0x0006B7D8
		[Address(RVA = "0x2AF866C", Offset = "0x2AF866C", VA = "0x2AF866C")]
		[Token(Token = "0x60035BE")]
		private void method_14()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			bool flag = this.bool_1;
			long num = 1L;
			if (flag)
			{
				return;
			}
			bool flag2 = this.bool_0;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x060035BF RID: 13759 RVA: 0x0006D400 File Offset: 0x0006B600
		[Address(RVA = "0x2AF8748", Offset = "0x2AF8748", VA = "0x2AF8748", Slot = "25")]
		[Token(Token = "0x60035BF")]
		protected virtual void vmethod_18(Collision collision_0)
		{
		}

		// Token: 0x060035C0 RID: 13760 RVA: 0x0006D364 File Offset: 0x0006B564
		[Address(RVA = "0x2AF886C", Offset = "0x2AF886C", VA = "0x2AF886C", Slot = "26")]
		[Token(Token = "0x60035C0")]
		protected virtual void vmethod_19(Collision collision_0)
		{
		}

		// Token: 0x060035C1 RID: 13761 RVA: 0x0006D620 File Offset: 0x0006B820
		[Address(RVA = "0x2AF8964", Offset = "0x2AF8964", VA = "0x2AF8964")]
		[Token(Token = "0x60035C1")]
		private void method_15()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060035C2 RID: 13762 RVA: 0x0006D374 File Offset: 0x0006B574
		[Address(RVA = "0x2AF8A38", Offset = "0x2AF8A38", VA = "0x2AF8A38")]
		[Token(Token = "0x60035C2")]
		public float method_16(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035C3 RID: 13763 RVA: 0x0006D634 File Offset: 0x0006B834
		[Address(RVA = "0x2AF8C00", Offset = "0x2AF8C00", VA = "0x2AF8C00")]
		[Token(Token = "0x60035C3")]
		public CollisionDetector()
		{
			Class42<Vector3> @class;
			this.class42_0 = @class;
			base..ctor();
		}

		// Token: 0x060035C4 RID: 13764 RVA: 0x0006D364 File Offset: 0x0006B564
		[Address(RVA = "0x2AF8C88", Offset = "0x2AF8C88", VA = "0x2AF8C88", Slot = "27")]
		[Token(Token = "0x60035C4")]
		protected virtual void vmethod_20(Collision collision_0)
		{
		}

		// Token: 0x060035C5 RID: 13765 RVA: 0x0006D650 File Offset: 0x0006B850
		[Address(RVA = "0x2AF8D80", Offset = "0x2AF8D80", VA = "0x2AF8D80", Slot = "28")]
		[Token(Token = "0x60035C5")]
		protected virtual void vmethod_21(Collision collision_0)
		{
			float sqrMagnitude = collision_0.impulse.sqrMagnitude;
			long index = 1L;
			Vector3 normal = collision_0.GetContact((int)index).normal;
			float y = this.vector3_3.y;
			this.vector3_3.y = y;
			float z = this.vector3_3.z;
			this.vector3_3.z = z;
		}

		// Token: 0x060035C6 RID: 13766 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF8EE8", Offset = "0x2AF8EE8", VA = "0x2AF8EE8")]
		[Token(Token = "0x60035C6")]
		public float method_17(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035C7 RID: 13767 RVA: 0x0006D398 File Offset: 0x0006B598
		[Address(RVA = "0x2AF909C", Offset = "0x2AF909C", VA = "0x2AF909C")]
		[Token(Token = "0x60035C7")]
		public float method_18(float float_0, Vector3 vector3_4, Vector3 vector3_5)
		{
			Vector3 zero = Vector3.zero;
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			throw new NullReferenceException();
		}

		// Token: 0x060035C8 RID: 13768 RVA: 0x0006D26C File Offset: 0x0006B46C
		[Address(RVA = "0x2AF9254", Offset = "0x2AF9254", VA = "0x2AF9254")]
		[Token(Token = "0x60035C8")]
		private void method_19()
		{
			float fixedDeltaTime = Time.fixedDeltaTime;
			bool flag;
			if (this.bool_1)
			{
				flag = this.bool_0;
			}
			bool flag2 = this.bool_0;
			this.bool_2 = flag;
			this.bool_1 = flag2;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x060035C9 RID: 13769 RVA: 0x0006D400 File Offset: 0x0006B600
		[Address(RVA = "0x2AF9324", Offset = "0x2AF9324", VA = "0x2AF9324", Slot = "29")]
		[Token(Token = "0x60035C9")]
		protected virtual void vmethod_22(Collision collision_0)
		{
		}

		// Token: 0x04000825 RID: 2085
		[Token(Token = "0x4000825")]
		[FieldOffset(Offset = "0x18")]
		public bool bool_0;

		// Token: 0x04000826 RID: 2086
		[Token(Token = "0x4000826")]
		[FieldOffset(Offset = "0x19")]
		public bool bool_1;

		// Token: 0x04000827 RID: 2087
		[Token(Token = "0x4000827")]
		[FieldOffset(Offset = "0x1A")]
		public bool bool_2;

		// Token: 0x04000828 RID: 2088
		[Token(Token = "0x4000828")]
		[FieldOffset(Offset = "0x1C")]
		public Vector3 vector3_0;

		// Token: 0x04000829 RID: 2089
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000829")]
		public Vector3 vector3_1;

		// Token: 0x0400082A RID: 2090
		[Token(Token = "0x400082A")]
		[FieldOffset(Offset = "0x34")]
		public Vector3 vector3_2;

		// Token: 0x0400082B RID: 2091
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400082B")]
		public Vector3 vector3_3;

		// Token: 0x0400082C RID: 2092
		[Token(Token = "0x400082C")]
		[FieldOffset(Offset = "0x50")]
		public Component[] component_0;

		// Token: 0x0400082D RID: 2093
		[Token(Token = "0x400082D")]
		[FieldOffset(Offset = "0x58")]
		private GInterface4[] ginterface4_0;

		// Token: 0x0400082E RID: 2094
		[Token(Token = "0x400082E")]
		[FieldOffset(Offset = "0x60")]
		private readonly Class42<Vector3> class42_0;
	}
}
