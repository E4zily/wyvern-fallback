﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x0200015A RID: 346
	[Token(Token = "0x200015A")]
	public class HexaHands : HexaHandsBase
	{
		// Token: 0x0600373E RID: 14142 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600373E")]
		[Address(RVA = "0x326DA64", Offset = "0x326DA64", VA = "0x326DA64")]
		private void method_6()
		{
		}

		// Token: 0x0600373F RID: 14143 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DA78", Offset = "0x326DA78", VA = "0x326DA78")]
		[Token(Token = "0x600373F")]
		private void method_7()
		{
		}

		// Token: 0x06003740 RID: 14144 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DA88", Offset = "0x326DA88", VA = "0x326DA88")]
		[Token(Token = "0x6003740")]
		private void method_8()
		{
		}

		// Token: 0x06003741 RID: 14145 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DA98", Offset = "0x326DA98", VA = "0x326DA98")]
		[Token(Token = "0x6003741")]
		private void method_9()
		{
		}

		// Token: 0x06003742 RID: 14146 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003742")]
		[Address(RVA = "0x326DAA8", Offset = "0x326DAA8", VA = "0x326DAA8")]
		private void method_10()
		{
		}

		// Token: 0x06003743 RID: 14147 RVA: 0x0006FCF8 File Offset: 0x0006DEF8
		[Token(Token = "0x6003743")]
		[Address(RVA = "0x326DABC", Offset = "0x326DABC", VA = "0x326DABC", Slot = "15")]
		protected override GEnum21 vmethod_7()
		{
			long num = 1L;
			BasicGrabber exists = this.basicGrabber_0;
			if (num != 0L)
			{
			}
			exists;
			BasicGrabber basicGrabber = this.basicGrabber_0;
			ConfigurableJoint configurableJoint_ = basicGrabber.configurableJoint_0;
			if (basicGrabber != null)
			{
			}
			configurableJoint_;
			BasicGrabber basicGrabber2 = this.basicGrabber_0;
			Rigidbody rigidbody_ = basicGrabber2.rigidbody_0;
			if (basicGrabber2 != null)
			{
			}
			rigidbody_;
			bool isKinematic = this.basicGrabber_0.rigidbody_0.isKinematic;
			throw new NullReferenceException();
		}

		// Token: 0x06003744 RID: 14148 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003744")]
		[Address(RVA = "0x326DBD4", Offset = "0x326DBD4", VA = "0x326DBD4")]
		private void method_11()
		{
		}

		// Token: 0x06003745 RID: 14149 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DBE8", Offset = "0x326DBE8", VA = "0x326DBE8")]
		[Token(Token = "0x6003745")]
		private void method_12()
		{
		}

		// Token: 0x06003746 RID: 14150 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DBF8", Offset = "0x326DBF8", VA = "0x326DBF8")]
		[Token(Token = "0x6003746")]
		private void method_13()
		{
		}

		// Token: 0x06003747 RID: 14151 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003747")]
		[Address(RVA = "0x326DC08", Offset = "0x326DC08", VA = "0x326DC08")]
		private void method_14()
		{
		}

		// Token: 0x06003748 RID: 14152 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003748")]
		[Address(RVA = "0x326DC1C", Offset = "0x326DC1C", VA = "0x326DC1C")]
		private void method_15()
		{
		}

		// Token: 0x06003749 RID: 14153 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DC2C", Offset = "0x326DC2C", VA = "0x326DC2C")]
		[Token(Token = "0x6003749")]
		private void method_16()
		{
		}

		// Token: 0x0600374A RID: 14154 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600374A")]
		[Address(RVA = "0x326DC3C", Offset = "0x326DC3C", VA = "0x326DC3C")]
		private void method_17()
		{
		}

		// Token: 0x0600374B RID: 14155 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600374B")]
		[Address(RVA = "0x326DC50", Offset = "0x326DC50", VA = "0x326DC50")]
		private void method_18()
		{
		}

		// Token: 0x0600374C RID: 14156 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DC64", Offset = "0x326DC64", VA = "0x326DC64")]
		[Token(Token = "0x600374C")]
		private void method_19()
		{
		}

		// Token: 0x0600374D RID: 14157 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DC74", Offset = "0x326DC74", VA = "0x326DC74")]
		[Token(Token = "0x600374D")]
		private void method_20()
		{
		}

		// Token: 0x0600374E RID: 14158 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600374E")]
		[Address(RVA = "0x326DC84", Offset = "0x326DC84", VA = "0x326DC84")]
		private void method_21()
		{
		}

		// Token: 0x0600374F RID: 14159 RVA: 0x0000351F File Offset: 0x0000171F
		[Address(RVA = "0x326DC98", Offset = "0x326DC98", VA = "0x326DC98")]
		[Token(Token = "0x600374F")]
		public HexaHands()
		{
		}

		// Token: 0x06003750 RID: 14160 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003750")]
		[Address(RVA = "0x326DE08", Offset = "0x326DE08", VA = "0x326DE08")]
		private void method_22()
		{
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06003751 RID: 14161 RVA: 0x0006FD68 File Offset: 0x0006DF68
		[Token(Token = "0x170000DD")]
		public override bool Boolean_0
		{
			[Address(RVA = "0x326DE1C", Offset = "0x326DE1C", VA = "0x326DE1C", Slot = "4")]
			[Token(Token = "0x6003751")]
			get
			{
				long num = 1L;
				BasicGrabber exists = this.basicGrabber_0;
				if (num != 0L)
				{
				}
				exists;
				BasicGrabber basicGrabber = this.basicGrabber_0;
				HexaXRInputs hexaXRInputs_ = basicGrabber.hexaXRInputs_0;
				if (basicGrabber != null)
				{
				}
				return hexaXRInputs_;
			}
		}

		// Token: 0x06003752 RID: 14162 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DEF0", Offset = "0x326DEF0", VA = "0x326DEF0")]
		[Token(Token = "0x6003752")]
		private void method_23()
		{
		}

		// Token: 0x06003753 RID: 14163 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DF04", Offset = "0x326DF04", VA = "0x326DF04")]
		[Token(Token = "0x6003753")]
		private void method_24()
		{
		}

		// Token: 0x06003754 RID: 14164 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DF18", Offset = "0x326DF18", VA = "0x326DF18")]
		[Token(Token = "0x6003754")]
		private void method_25()
		{
		}

		// Token: 0x06003755 RID: 14165 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DF2C", Offset = "0x326DF2C", VA = "0x326DF2C")]
		[Token(Token = "0x6003755")]
		private void method_26()
		{
		}

		// Token: 0x06003756 RID: 14166 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003756")]
		[Address(RVA = "0x326DF40", Offset = "0x326DF40", VA = "0x326DF40")]
		private void method_27()
		{
		}

		// Token: 0x06003757 RID: 14167 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DF54", Offset = "0x326DF54", VA = "0x326DF54")]
		[Token(Token = "0x6003757")]
		private void method_28()
		{
		}

		// Token: 0x06003758 RID: 14168 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DF64", Offset = "0x326DF64", VA = "0x326DF64")]
		[Token(Token = "0x6003758")]
		private void method_29()
		{
		}

		// Token: 0x06003759 RID: 14169 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003759")]
		[Address(RVA = "0x326DF78", Offset = "0x326DF78", VA = "0x326DF78")]
		private void method_30()
		{
		}

		// Token: 0x0600375A RID: 14170 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DF8C", Offset = "0x326DF8C", VA = "0x326DF8C")]
		[Token(Token = "0x600375A")]
		private void method_31()
		{
		}

		// Token: 0x0600375B RID: 14171 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DF9C", Offset = "0x326DF9C", VA = "0x326DF9C")]
		[Token(Token = "0x600375B")]
		private void method_32()
		{
		}

		// Token: 0x0600375C RID: 14172 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DFAC", Offset = "0x326DFAC", VA = "0x326DFAC")]
		[Token(Token = "0x600375C")]
		private void method_33()
		{
		}

		// Token: 0x0600375D RID: 14173 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326DFBC", Offset = "0x326DFBC", VA = "0x326DFBC")]
		[Token(Token = "0x600375D")]
		private void method_34()
		{
		}

		// Token: 0x0600375E RID: 14174 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600375E")]
		[Address(RVA = "0x326DFD0", Offset = "0x326DFD0", VA = "0x326DFD0")]
		private void method_35()
		{
		}

		// Token: 0x0600375F RID: 14175 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600375F")]
		[Address(RVA = "0x326DFE4", Offset = "0x326DFE4", VA = "0x326DFE4")]
		private void method_36()
		{
		}

		// Token: 0x06003760 RID: 14176 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003760")]
		[Address(RVA = "0x326DFF4", Offset = "0x326DFF4", VA = "0x326DFF4")]
		private void method_37()
		{
		}

		// Token: 0x06003761 RID: 14177 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003761")]
		[Address(RVA = "0x326E004", Offset = "0x326E004", VA = "0x326E004")]
		private void method_38()
		{
		}

		// Token: 0x06003762 RID: 14178 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326E014", Offset = "0x326E014", VA = "0x326E014")]
		[Token(Token = "0x6003762")]
		private void method_39()
		{
		}

		// Token: 0x06003763 RID: 14179 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326E028", Offset = "0x326E028", VA = "0x326E028")]
		[Token(Token = "0x6003763")]
		private void method_40()
		{
		}

		// Token: 0x06003764 RID: 14180 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003764")]
		[Address(RVA = "0x326E038", Offset = "0x326E038", VA = "0x326E038")]
		private void method_41()
		{
		}

		// Token: 0x06003765 RID: 14181 RVA: 0x0006FDA4 File Offset: 0x0006DFA4
		[Address(RVA = "0x326E048", Offset = "0x326E048", VA = "0x326E048", Slot = "10")]
		[Token(Token = "0x6003765")]
		protected override bool vmethod_2()
		{
			long num = 1L;
			BasicGrabber exists = this.basicGrabber_0;
			if (num != 0L)
			{
			}
			exists;
			BasicGrabber basicGrabber = this.basicGrabber_0;
			ConfigurableJoint configurableJoint_ = basicGrabber.configurableJoint_0;
			if (basicGrabber != null)
			{
			}
			return configurableJoint_;
		}

		// Token: 0x06003766 RID: 14182 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003766")]
		[Address(RVA = "0x326E104", Offset = "0x326E104", VA = "0x326E104")]
		private void method_42()
		{
		}

		// Token: 0x06003767 RID: 14183 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326E118", Offset = "0x326E118", VA = "0x326E118")]
		[Token(Token = "0x6003767")]
		private void method_43()
		{
		}

		// Token: 0x06003768 RID: 14184 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003768")]
		[Address(RVA = "0x326E128", Offset = "0x326E128", VA = "0x326E128")]
		private void method_44()
		{
		}

		// Token: 0x06003769 RID: 14185 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003769")]
		[Address(RVA = "0x326E13C", Offset = "0x326E13C", VA = "0x326E13C")]
		private void method_45()
		{
		}

		// Token: 0x0600376A RID: 14186 RVA: 0x0006FDE0 File Offset: 0x0006DFE0
		[Token(Token = "0x600376A")]
		[Address(RVA = "0x326E150", Offset = "0x326E150", VA = "0x326E150", Slot = "6")]
		protected override void Awake()
		{
			base.Awake();
			this.basicGrabber_0;
		}

		// Token: 0x0600376B RID: 14187 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600376B")]
		[Address(RVA = "0x326EADC", Offset = "0x326EADC", VA = "0x326EADC")]
		private void method_46()
		{
		}

		// Token: 0x0600376C RID: 14188 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600376C")]
		[Address(RVA = "0x326EAEC", Offset = "0x326EAEC", VA = "0x326EAEC")]
		private void method_47()
		{
		}

		// Token: 0x0600376D RID: 14189 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600376D")]
		[Address(RVA = "0x326EB00", Offset = "0x326EB00", VA = "0x326EB00")]
		private void method_48()
		{
		}

		// Token: 0x0600376E RID: 14190 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600376E")]
		[Address(RVA = "0x326EB10", Offset = "0x326EB10", VA = "0x326EB10")]
		private void method_49()
		{
		}

		// Token: 0x0600376F RID: 14191 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326EB24", Offset = "0x326EB24", VA = "0x326EB24")]
		[Token(Token = "0x600376F")]
		private void method_50()
		{
		}

		// Token: 0x06003770 RID: 14192 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326EB34", Offset = "0x326EB34", VA = "0x326EB34")]
		[Token(Token = "0x6003770")]
		private void method_51()
		{
		}

		// Token: 0x06003771 RID: 14193 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003771")]
		[Address(RVA = "0x326EB48", Offset = "0x326EB48", VA = "0x326EB48")]
		private void method_52()
		{
		}

		// Token: 0x06003772 RID: 14194 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003772")]
		[Address(RVA = "0x326EB5C", Offset = "0x326EB5C", VA = "0x326EB5C")]
		private void method_53()
		{
		}

		// Token: 0x06003773 RID: 14195 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003773")]
		[Address(RVA = "0x326EB70", Offset = "0x326EB70", VA = "0x326EB70")]
		private void method_54()
		{
		}

		// Token: 0x06003774 RID: 14196 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326EB80", Offset = "0x326EB80", VA = "0x326EB80")]
		[Token(Token = "0x6003774")]
		private void method_55()
		{
		}

		// Token: 0x06003775 RID: 14197 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003775")]
		[Address(RVA = "0x326EB94", Offset = "0x326EB94", VA = "0x326EB94")]
		private void method_56()
		{
		}

		// Token: 0x06003776 RID: 14198 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003776")]
		[Address(RVA = "0x326EBA8", Offset = "0x326EBA8", VA = "0x326EBA8")]
		private void method_57()
		{
		}

		// Token: 0x06003777 RID: 14199 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326EBBC", Offset = "0x326EBBC", VA = "0x326EBBC")]
		[Token(Token = "0x6003777")]
		private void method_58()
		{
		}

		// Token: 0x06003778 RID: 14200 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326EBD0", Offset = "0x326EBD0", VA = "0x326EBD0")]
		[Token(Token = "0x6003778")]
		private void method_59()
		{
		}

		// Token: 0x06003779 RID: 14201 RVA: 0x0006FE00 File Offset: 0x0006E000
		[Token(Token = "0x6003779")]
		[Address(RVA = "0x326EBE4", Offset = "0x326EBE4", VA = "0x326EBE4", Slot = "21")]
		protected override void vmethod_13(GEnum22 genum22_1)
		{
		}

		// Token: 0x04000912 RID: 2322
		[Token(Token = "0x4000912")]
		[FieldOffset(Offset = "0x110")]
		public float float_15;

		// Token: 0x04000913 RID: 2323
		[Token(Token = "0x4000913")]
		[FieldOffset(Offset = "0x114")]
		public float float_16;

		// Token: 0x04000914 RID: 2324
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x4000914")]
		public float float_17;

		// Token: 0x04000915 RID: 2325
		[Token(Token = "0x4000915")]
		[FieldOffset(Offset = "0x11C")]
		public float float_18;

		// Token: 0x04000916 RID: 2326
		[FieldOffset(Offset = "0x120")]
		[Token(Token = "0x4000916")]
		public float float_19;

		// Token: 0x04000917 RID: 2327
		[Token(Token = "0x4000917")]
		[FieldOffset(Offset = "0x124")]
		public float float_20;

		// Token: 0x04000918 RID: 2328
		[FieldOffset(Offset = "0x128")]
		[Token(Token = "0x4000918")]
		public BasicGrabber basicGrabber_0;
	}
}
