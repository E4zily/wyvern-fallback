﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000168 RID: 360
	[Token(Token = "0x2000168")]
	[Serializable]
	public class HexaAngularJointDrive
	{
		// Token: 0x060037F5 RID: 14325 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037F5")]
		[Address(RVA = "0x363C66C", Offset = "0x363C66C", VA = "0x363C66C")]
		public JointDrive method_0()
		{
		}

		// Token: 0x060037F6 RID: 14326 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363C6D0", Offset = "0x363C6D0", VA = "0x363C6D0")]
		[Token(Token = "0x60037F6")]
		public JointDrive method_1()
		{
		}

		// Token: 0x060037F7 RID: 14327 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037F7")]
		[Address(RVA = "0x363C734", Offset = "0x363C734", VA = "0x363C734")]
		public JointDrive method_2()
		{
		}

		// Token: 0x060037F8 RID: 14328 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363C798", Offset = "0x363C798", VA = "0x363C798")]
		[Token(Token = "0x60037F8")]
		public JointDrive method_3()
		{
		}

		// Token: 0x060037F9 RID: 14329 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037F9")]
		[Address(RVA = "0x363C7FC", Offset = "0x363C7FC", VA = "0x363C7FC")]
		public JointDrive method_4()
		{
		}

		// Token: 0x060037FA RID: 14330 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037FA")]
		[Address(RVA = "0x363C860", Offset = "0x363C860", VA = "0x363C860")]
		public JointDrive method_5()
		{
		}

		// Token: 0x060037FB RID: 14331 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037FB")]
		[Address(RVA = "0x363C8C4", Offset = "0x363C8C4", VA = "0x363C8C4")]
		public JointDrive method_6()
		{
		}

		// Token: 0x060037FC RID: 14332 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037FC")]
		[Address(RVA = "0x363C928", Offset = "0x363C928", VA = "0x363C928")]
		public JointDrive method_7()
		{
		}

		// Token: 0x060037FD RID: 14333 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363C98C", Offset = "0x363C98C", VA = "0x363C98C")]
		[Token(Token = "0x60037FD")]
		public JointDrive method_8()
		{
		}

		// Token: 0x060037FE RID: 14334 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363C9F0", Offset = "0x363C9F0", VA = "0x363C9F0")]
		[Token(Token = "0x60037FE")]
		public JointDrive method_9()
		{
		}

		// Token: 0x060037FF RID: 14335 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037FF")]
		[Address(RVA = "0x363CA54", Offset = "0x363CA54", VA = "0x363CA54")]
		public JointDrive method_10()
		{
		}

		// Token: 0x06003800 RID: 14336 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003800")]
		[Address(RVA = "0x363CAB8", Offset = "0x363CAB8", VA = "0x363CAB8")]
		public JointDrive method_11()
		{
		}

		// Token: 0x06003801 RID: 14337 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003801")]
		[Address(RVA = "0x363CB1C", Offset = "0x363CB1C", VA = "0x363CB1C")]
		public JointDrive method_12()
		{
		}

		// Token: 0x06003802 RID: 14338 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003802")]
		[Address(RVA = "0x363CB80", Offset = "0x363CB80", VA = "0x363CB80")]
		public JointDrive method_13()
		{
		}

		// Token: 0x06003803 RID: 14339 RVA: 0x00067934 File Offset: 0x00065B34
		[Address(RVA = "0x363CBE4", Offset = "0x363CBE4", VA = "0x363CBE4")]
		[Token(Token = "0x6003803")]
		public JointDrive method_14()
		{
		}

		// Token: 0x06003804 RID: 14340 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003804")]
		[Address(RVA = "0x363CC48", Offset = "0x363CC48", VA = "0x363CC48")]
		public JointDrive method_15()
		{
		}

		// Token: 0x06003805 RID: 14341 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363CCAC", Offset = "0x363CCAC", VA = "0x363CCAC")]
		[Token(Token = "0x6003805")]
		public JointDrive method_16()
		{
		}

		// Token: 0x06003806 RID: 14342 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003806")]
		[Address(RVA = "0x363CD10", Offset = "0x363CD10", VA = "0x363CD10")]
		public JointDrive method_17()
		{
		}

		// Token: 0x06003807 RID: 14343 RVA: 0x000035A4 File Offset: 0x000017A4
		[Token(Token = "0x6003807")]
		[Address(RVA = "0x363CD74", Offset = "0x363CD74", VA = "0x363CD74")]
		public HexaAngularJointDrive()
		{
		}

		// Token: 0x06003808 RID: 14344 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003808")]
		[Address(RVA = "0x363CD90", Offset = "0x363CD90", VA = "0x363CD90")]
		public JointDrive method_18()
		{
		}

		// Token: 0x06003809 RID: 14345 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363CDF4", Offset = "0x363CDF4", VA = "0x363CDF4")]
		[Token(Token = "0x6003809")]
		public JointDrive method_19()
		{
		}

		// Token: 0x0600380A RID: 14346 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363CE58", Offset = "0x363CE58", VA = "0x363CE58")]
		[Token(Token = "0x600380A")]
		public JointDrive method_20()
		{
		}

		// Token: 0x0600380B RID: 14347 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600380B")]
		[Address(RVA = "0x363CEBC", Offset = "0x363CEBC", VA = "0x363CEBC")]
		public JointDrive method_21()
		{
		}

		// Token: 0x0600380C RID: 14348 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363CF20", Offset = "0x363CF20", VA = "0x363CF20")]
		[Token(Token = "0x600380C")]
		public JointDrive method_22()
		{
		}

		// Token: 0x0600380D RID: 14349 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600380D")]
		[Address(RVA = "0x363CF84", Offset = "0x363CF84", VA = "0x363CF84")]
		public JointDrive method_23()
		{
		}

		// Token: 0x0600380E RID: 14350 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600380E")]
		[Address(RVA = "0x363CFE8", Offset = "0x363CFE8", VA = "0x363CFE8")]
		public JointDrive method_24()
		{
		}

		// Token: 0x0600380F RID: 14351 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D04C", Offset = "0x363D04C", VA = "0x363D04C")]
		[Token(Token = "0x600380F")]
		public JointDrive method_25()
		{
		}

		// Token: 0x06003810 RID: 14352 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D0B0", Offset = "0x363D0B0", VA = "0x363D0B0")]
		[Token(Token = "0x6003810")]
		public JointDrive method_26()
		{
		}

		// Token: 0x06003811 RID: 14353 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D114", Offset = "0x363D114", VA = "0x363D114")]
		[Token(Token = "0x6003811")]
		public JointDrive method_27()
		{
		}

		// Token: 0x06003812 RID: 14354 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D178", Offset = "0x363D178", VA = "0x363D178")]
		[Token(Token = "0x6003812")]
		public JointDrive method_28()
		{
		}

		// Token: 0x06003813 RID: 14355 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D1DC", Offset = "0x363D1DC", VA = "0x363D1DC")]
		[Token(Token = "0x6003813")]
		public JointDrive method_29()
		{
		}

		// Token: 0x06003814 RID: 14356 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003814")]
		[Address(RVA = "0x363D240", Offset = "0x363D240", VA = "0x363D240")]
		public JointDrive method_30()
		{
		}

		// Token: 0x06003815 RID: 14357 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003815")]
		[Address(RVA = "0x363D2A4", Offset = "0x363D2A4", VA = "0x363D2A4")]
		public JointDrive method_31()
		{
		}

		// Token: 0x06003816 RID: 14358 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D308", Offset = "0x363D308", VA = "0x363D308")]
		[Token(Token = "0x6003816")]
		public JointDrive method_32()
		{
		}

		// Token: 0x06003817 RID: 14359 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003817")]
		[Address(RVA = "0x363D36C", Offset = "0x363D36C", VA = "0x363D36C")]
		public JointDrive method_33()
		{
		}

		// Token: 0x06003818 RID: 14360 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003818")]
		[Address(RVA = "0x363D3D0", Offset = "0x363D3D0", VA = "0x363D3D0")]
		public JointDrive method_34()
		{
		}

		// Token: 0x06003819 RID: 14361 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003819")]
		[Address(RVA = "0x363D434", Offset = "0x363D434", VA = "0x363D434")]
		public JointDrive method_35()
		{
		}

		// Token: 0x0600381A RID: 14362 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D498", Offset = "0x363D498", VA = "0x363D498")]
		[Token(Token = "0x600381A")]
		public JointDrive method_36()
		{
		}

		// Token: 0x0600381B RID: 14363 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600381B")]
		[Address(RVA = "0x363D4FC", Offset = "0x363D4FC", VA = "0x363D4FC")]
		public JointDrive method_37()
		{
		}

		// Token: 0x0600381C RID: 14364 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D560", Offset = "0x363D560", VA = "0x363D560")]
		[Token(Token = "0x600381C")]
		public JointDrive method_38()
		{
		}

		// Token: 0x0600381D RID: 14365 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600381D")]
		[Address(RVA = "0x363D5C4", Offset = "0x363D5C4", VA = "0x363D5C4")]
		public JointDrive method_39()
		{
		}

		// Token: 0x0600381E RID: 14366 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600381E")]
		[Address(RVA = "0x363D628", Offset = "0x363D628", VA = "0x363D628")]
		public JointDrive method_40()
		{
		}

		// Token: 0x0600381F RID: 14367 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600381F")]
		[Address(RVA = "0x363D68C", Offset = "0x363D68C", VA = "0x363D68C")]
		public JointDrive method_41()
		{
		}

		// Token: 0x06003820 RID: 14368 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003820")]
		[Address(RVA = "0x363D6F0", Offset = "0x363D6F0", VA = "0x363D6F0")]
		public JointDrive method_42()
		{
		}

		// Token: 0x06003821 RID: 14369 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D754", Offset = "0x363D754", VA = "0x363D754")]
		[Token(Token = "0x6003821")]
		public JointDrive method_43()
		{
		}

		// Token: 0x06003822 RID: 14370 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003822")]
		[Address(RVA = "0x363D7B8", Offset = "0x363D7B8", VA = "0x363D7B8")]
		public JointDrive method_44()
		{
		}

		// Token: 0x06003823 RID: 14371 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003823")]
		[Address(RVA = "0x363D81C", Offset = "0x363D81C", VA = "0x363D81C")]
		public JointDrive method_45()
		{
		}

		// Token: 0x06003824 RID: 14372 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D880", Offset = "0x363D880", VA = "0x363D880")]
		[Token(Token = "0x6003824")]
		public JointDrive method_46()
		{
		}

		// Token: 0x06003825 RID: 14373 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003825")]
		[Address(RVA = "0x363D8E4", Offset = "0x363D8E4", VA = "0x363D8E4")]
		public JointDrive method_47()
		{
		}

		// Token: 0x06003826 RID: 14374 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003826")]
		[Address(RVA = "0x363D948", Offset = "0x363D948", VA = "0x363D948")]
		public JointDrive method_48()
		{
		}

		// Token: 0x06003827 RID: 14375 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363D9AC", Offset = "0x363D9AC", VA = "0x363D9AC")]
		[Token(Token = "0x6003827")]
		public JointDrive method_49()
		{
		}

		// Token: 0x06003828 RID: 14376 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003828")]
		[Address(RVA = "0x363DA10", Offset = "0x363DA10", VA = "0x363DA10")]
		public JointDrive method_50()
		{
		}

		// Token: 0x06003829 RID: 14377 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x6003829")]
		[Address(RVA = "0x363DA74", Offset = "0x363DA74", VA = "0x363DA74")]
		public JointDrive method_51()
		{
		}

		// Token: 0x0600382A RID: 14378 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x363DAD8", Offset = "0x363DAD8", VA = "0x363DAD8")]
		[Token(Token = "0x600382A")]
		public JointDrive method_52()
		{
		}

		// Token: 0x0600382B RID: 14379 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x600382B")]
		[Address(RVA = "0x363DB3C", Offset = "0x363DB3C", VA = "0x363DB3C")]
		public JointDrive method_53()
		{
		}

		// Token: 0x0600382C RID: 14380 RVA: 0x00067934 File Offset: 0x00065B34
		[Token(Token = "0x600382C")]
		[Address(RVA = "0x363DBA0", Offset = "0x363DBA0", VA = "0x363DBA0")]
		public JointDrive method_54()
		{
		}

		// Token: 0x04000972 RID: 2418
		[Token(Token = "0x4000972")]
		[FieldOffset(Offset = "0x10")]
		public float Spring;

		// Token: 0x04000973 RID: 2419
		[Token(Token = "0x4000973")]
		[FieldOffset(Offset = "0x14")]
		public float Damper;

		// Token: 0x04000974 RID: 2420
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000974")]
		public float MaxForce = (float)16968;
	}
}
