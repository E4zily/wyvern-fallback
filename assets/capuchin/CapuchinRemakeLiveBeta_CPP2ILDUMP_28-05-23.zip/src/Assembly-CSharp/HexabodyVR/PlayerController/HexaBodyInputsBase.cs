﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000153 RID: 339
	[Token(Token = "0x2000153")]
	public abstract class HexaBodyInputsBase : MonoBehaviour
	{
		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060035E2 RID: 13794 RVA: 0x0003584C File Offset: 0x00033A4C
		// (set) Token: 0x060035E3 RID: 13795 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000BF")]
		public float Single_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x3397B24", Offset = "0x3397B24", VA = "0x3397B24")]
			[Token(Token = "0x60035E2")]
			get
			{
			}
			[CompilerGenerated]
			[Address(RVA = "0x3397B2C", Offset = "0x3397B2C", VA = "0x3397B2C")]
			[Token(Token = "0x60035E3")]
			private set
			{
			}
		}

		// Token: 0x060035E4 RID: 13796 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3397B34", Offset = "0x3397B34", VA = "0x3397B34", Slot = "4")]
		[Token(Token = "0x60035E4")]
		protected virtual void Update()
		{
		}

		// Token: 0x060035E5 RID: 13797 RVA: 0x0006D9EC File Offset: 0x0006BBEC
		[Address(RVA = "0x3397B68", Offset = "0x3397B68", VA = "0x3397B68", Slot = "5")]
		[Token(Token = "0x60035E5")]
		protected virtual void vmethod_0()
		{
			bool flag = this.bool_7;
			PlayerInputState playerInputState = this.playerInputState_0;
			if (flag)
			{
				if (playerInputState == null)
				{
					this.playerInputState_0 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated = 1L;
				this.playerInputState_0.JustDeactivated = (justDeactivated != 0L);
			}
			if (this.playerInputState_1 == null)
			{
				this.playerInputState_1 = 257;
				return;
			}
		}

		// Token: 0x060035E6 RID: 13798 RVA: 0x0006DA3C File Offset: 0x0006BC3C
		[Address(RVA = "0x3397C1C", Offset = "0x3397C1C", VA = "0x3397C1C", Slot = "6")]
		[Token(Token = "0x60035E6")]
		protected virtual void vmethod_1()
		{
			this.method_0();
			if (!this.bool_3)
			{
			}
			if (!this.bool_2)
			{
			}
			if (!this.bool_1)
			{
			}
			if (!this.bool_0)
			{
			}
		}

		// Token: 0x060035E7 RID: 13799 RVA: 0x0006DA70 File Offset: 0x0006BC70
		[Address(RVA = "0x3397D00", Offset = "0x3397D00", VA = "0x3397D00")]
		[Token(Token = "0x60035E7")]
		protected void method_0()
		{
			Vector2 zero = Vector2.zero;
			Vector2 zero2 = Vector2.zero;
		}

		// Token: 0x060035E8 RID: 13800
		[Address(Slot = "7")]
		[Token(Token = "0x60035E8")]
		protected abstract bool vmethod_2();

		// Token: 0x060035E9 RID: 13801
		[Address(Slot = "8")]
		[Token(Token = "0x60035E9")]
		protected abstract float vmethod_3();

		// Token: 0x060035EA RID: 13802
		[Address(Slot = "9")]
		[Token(Token = "0x60035EA")]
		protected abstract Vector2 vmethod_4();

		// Token: 0x060035EB RID: 13803
		[Address(Slot = "10")]
		[Token(Token = "0x60035EB")]
		protected abstract Vector2 vmethod_5();

		// Token: 0x060035EC RID: 13804
		[Address(Slot = "11")]
		[Token(Token = "0x60035EC")]
		protected abstract bool vmethod_6();

		// Token: 0x060035ED RID: 13805
		[Address(Slot = "12")]
		[Token(Token = "0x60035ED")]
		protected abstract bool vmethod_7();

		// Token: 0x060035EE RID: 13806 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3397BE4", Offset = "0x3397BE4", VA = "0x3397BE4")]
		[Token(Token = "0x60035EE")]
		protected void method_1(ref PlayerInputState playerInputState_2)
		{
		}

		// Token: 0x060035EF RID: 13807 RVA: 0x0006BB9C File Offset: 0x00069D9C
		[Address(RVA = "0x3397BF0", Offset = "0x3397BF0", VA = "0x3397BF0")]
		[Token(Token = "0x60035EF")]
		protected void method_2(ref PlayerInputState playerInputState_2, bool bool_8)
		{
			playerInputState_2.Active = (257 != 0);
		}

		// Token: 0x060035F0 RID: 13808 RVA: 0x0006DA8C File Offset: 0x0006BC8C
		[Address(RVA = "0x3396E2C", Offset = "0x3396E2C", VA = "0x3396E2C")]
		[Token(Token = "0x60035F0")]
		protected HexaBodyInputsBase()
		{
			long num = 16843009L;
			this.bool_0 = (num != 0L);
			base..ctor();
		}

		// Token: 0x0400083E RID: 2110
		[Token(Token = "0x400083E")]
		[FieldOffset(Offset = "0x18")]
		public bool bool_0;

		// Token: 0x0400083F RID: 2111
		[FieldOffset(Offset = "0x19")]
		[Token(Token = "0x400083F")]
		public bool bool_1;

		// Token: 0x04000840 RID: 2112
		[Token(Token = "0x4000840")]
		[FieldOffset(Offset = "0x1A")]
		public bool bool_2;

		// Token: 0x04000841 RID: 2113
		[Token(Token = "0x4000841")]
		[FieldOffset(Offset = "0x1B")]
		public bool bool_3;

		// Token: 0x04000842 RID: 2114
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000842")]
		public Vector2 vector2_0;

		// Token: 0x04000843 RID: 2115
		[Token(Token = "0x4000843")]
		[FieldOffset(Offset = "0x24")]
		public Vector2 vector2_1;

		// Token: 0x04000844 RID: 2116
		[Token(Token = "0x4000844")]
		[FieldOffset(Offset = "0x2C")]
		public bool bool_4;

		// Token: 0x04000845 RID: 2117
		[FieldOffset(Offset = "0x2D")]
		[Token(Token = "0x4000845")]
		public bool bool_5;

		// Token: 0x04000846 RID: 2118
		[FieldOffset(Offset = "0x2E")]
		[Token(Token = "0x4000846")]
		public bool bool_6;

		// Token: 0x04000847 RID: 2119
		[FieldOffset(Offset = "0x2F")]
		[Token(Token = "0x4000847")]
		public bool bool_7;

		// Token: 0x04000848 RID: 2120
		[Token(Token = "0x4000848")]
		[FieldOffset(Offset = "0x30")]
		public float float_0;

		// Token: 0x04000849 RID: 2121
		[Token(Token = "0x4000849")]
		[CompilerGenerated]
		[FieldOffset(Offset = "0x34")]
		private float float_1;

		// Token: 0x0400084A RID: 2122
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400084A")]
		internal PlayerInputState playerInputState_0;

		// Token: 0x0400084B RID: 2123
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400084B")]
		internal PlayerInputState playerInputState_1;
	}
}
