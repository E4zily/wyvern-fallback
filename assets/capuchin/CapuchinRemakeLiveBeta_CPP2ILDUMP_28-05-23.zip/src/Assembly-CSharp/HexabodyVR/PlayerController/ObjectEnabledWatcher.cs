﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Events;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000171 RID: 369
	[Token(Token = "0x2000171")]
	public class ObjectEnabledWatcher : MonoBehaviour
	{
		// Token: 0x060038E0 RID: 14560 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C3F4", Offset = "0x2D6C3F4", VA = "0x2D6C3F4")]
		[Token(Token = "0x60038E0")]
		private void method_0()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E1 RID: 14561 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C410", Offset = "0x2D6C410", VA = "0x2D6C410")]
		[Token(Token = "0x60038E1")]
		private void method_1()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E2 RID: 14562 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038E2")]
		[Address(RVA = "0x2D6C42C", Offset = "0x2D6C42C", VA = "0x2D6C42C")]
		private void method_2()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E3 RID: 14563 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038E3")]
		[Address(RVA = "0x2D6C448", Offset = "0x2D6C448", VA = "0x2D6C448")]
		private void method_3()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E4 RID: 14564 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C464", Offset = "0x2D6C464", VA = "0x2D6C464")]
		[Token(Token = "0x60038E4")]
		private void method_4()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E5 RID: 14565 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038E5")]
		[Address(RVA = "0x2D6C480", Offset = "0x2D6C480", VA = "0x2D6C480")]
		private void method_5()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E6 RID: 14566 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038E6")]
		[Address(RVA = "0x2D6C49C", Offset = "0x2D6C49C", VA = "0x2D6C49C")]
		private void method_6()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E7 RID: 14567 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038E7")]
		[Address(RVA = "0x2D6C4B8", Offset = "0x2D6C4B8", VA = "0x2D6C4B8")]
		private void method_7()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E8 RID: 14568 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038E8")]
		[Address(RVA = "0x2D6C4D4", Offset = "0x2D6C4D4", VA = "0x2D6C4D4")]
		private void method_8()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038E9 RID: 14569 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C4F0", Offset = "0x2D6C4F0", VA = "0x2D6C4F0")]
		[Token(Token = "0x60038E9")]
		private void method_9()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038EA RID: 14570 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C50C", Offset = "0x2D6C50C", VA = "0x2D6C50C")]
		[Token(Token = "0x60038EA")]
		private void method_10()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038EB RID: 14571 RVA: 0x000723FC File Offset: 0x000705FC
		[Token(Token = "0x60038EB")]
		[Address(RVA = "0x2D6C528", Offset = "0x2D6C528", VA = "0x2D6C528")]
		public ObjectEnabledWatcher()
		{
			UnityEvent unityEvent = new UnityEvent();
			this.unityEvent_0 = unityEvent;
			base..ctor();
		}

		// Token: 0x060038EC RID: 14572 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038EC")]
		[Address(RVA = "0x2D6C598", Offset = "0x2D6C598", VA = "0x2D6C598")]
		private void method_11()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038ED RID: 14573 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038ED")]
		[Address(RVA = "0x2D6C5B4", Offset = "0x2D6C5B4", VA = "0x2D6C5B4")]
		private void method_12()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038EE RID: 14574 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C5D0", Offset = "0x2D6C5D0", VA = "0x2D6C5D0")]
		[Token(Token = "0x60038EE")]
		private void method_13()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038EF RID: 14575 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038EF")]
		[Address(RVA = "0x2D6C5EC", Offset = "0x2D6C5EC", VA = "0x2D6C5EC")]
		private void method_14()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F0 RID: 14576 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C608", Offset = "0x2D6C608", VA = "0x2D6C608")]
		[Token(Token = "0x60038F0")]
		private void method_15()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F1 RID: 14577 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038F1")]
		[Address(RVA = "0x2D6C624", Offset = "0x2D6C624", VA = "0x2D6C624")]
		private void method_16()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F2 RID: 14578 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C640", Offset = "0x2D6C640", VA = "0x2D6C640")]
		[Token(Token = "0x60038F2")]
		private void method_17()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F3 RID: 14579 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038F3")]
		[Address(RVA = "0x2D6C65C", Offset = "0x2D6C65C", VA = "0x2D6C65C")]
		private void method_18()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F4 RID: 14580 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038F4")]
		[Address(RVA = "0x2D6C678", Offset = "0x2D6C678", VA = "0x2D6C678")]
		private void method_19()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F5 RID: 14581 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C694", Offset = "0x2D6C694", VA = "0x2D6C694")]
		[Token(Token = "0x60038F5")]
		private void method_20()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F6 RID: 14582 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038F6")]
		[Address(RVA = "0x2D6C6B0", Offset = "0x2D6C6B0", VA = "0x2D6C6B0")]
		private void method_21()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F7 RID: 14583 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x60038F7")]
		[Address(RVA = "0x2D6C6CC", Offset = "0x2D6C6CC", VA = "0x2D6C6CC")]
		private void method_22()
		{
		}

		// Token: 0x060038F8 RID: 14584 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038F8")]
		[Address(RVA = "0x2D6C6E8", Offset = "0x2D6C6E8", VA = "0x2D6C6E8")]
		private void method_23()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038F9 RID: 14585 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C704", Offset = "0x2D6C704", VA = "0x2D6C704")]
		[Token(Token = "0x60038F9")]
		private void method_24()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038FA RID: 14586 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038FA")]
		[Address(RVA = "0x2D6C720", Offset = "0x2D6C720", VA = "0x2D6C720")]
		private void method_25()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038FB RID: 14587 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038FB")]
		[Address(RVA = "0x2D6C73C", Offset = "0x2D6C73C", VA = "0x2D6C73C")]
		private void method_26()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038FC RID: 14588 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x60038FC")]
		[Address(RVA = "0x2D6C758", Offset = "0x2D6C758", VA = "0x2D6C758")]
		private void method_27()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038FD RID: 14589 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C774", Offset = "0x2D6C774", VA = "0x2D6C774")]
		[Token(Token = "0x60038FD")]
		private void OnEnable()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038FE RID: 14590 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C790", Offset = "0x2D6C790", VA = "0x2D6C790")]
		[Token(Token = "0x60038FE")]
		private void method_28()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x060038FF RID: 14591 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C7AC", Offset = "0x2D6C7AC", VA = "0x2D6C7AC")]
		[Token(Token = "0x60038FF")]
		private void method_29()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x06003900 RID: 14592 RVA: 0x0000361D File Offset: 0x0000181D
		[Address(RVA = "0x2D6C7C8", Offset = "0x2D6C7C8", VA = "0x2D6C7C8")]
		[Token(Token = "0x6003900")]
		private void method_30()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x06003901 RID: 14593 RVA: 0x0000361D File Offset: 0x0000181D
		[Token(Token = "0x6003901")]
		[Address(RVA = "0x2D6C7E4", Offset = "0x2D6C7E4", VA = "0x2D6C7E4")]
		private void method_31()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x06003902 RID: 14594 RVA: 0x0007241C File Offset: 0x0007061C
		[Address(RVA = "0x2D6C800", Offset = "0x2D6C800", VA = "0x2D6C800")]
		[Token(Token = "0x6003902")]
		private void method_32()
		{
			this.unityEvent_0.Invoke();
		}

		// Token: 0x040009EE RID: 2542
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40009EE")]
		public UnityEvent unityEvent_0;
	}
}
