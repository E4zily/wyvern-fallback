﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000167 RID: 359
	[Token(Token = "0x2000167")]
	[Serializable]
	public class HexaJointDrive
	{
		// Token: 0x060037AE RID: 14254 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037AE")]
		[Address(RVA = "0x327022C", Offset = "0x327022C", VA = "0x327022C")]
		public JointDrive method_0()
		{
		}

		// Token: 0x060037AF RID: 14255 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037AF")]
		[Address(RVA = "0x3270290", Offset = "0x3270290", VA = "0x3270290")]
		public JointDrive method_1()
		{
		}

		// Token: 0x060037B0 RID: 14256 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037B0")]
		[Address(RVA = "0x32702F4", Offset = "0x32702F4", VA = "0x32702F4")]
		public JointDrive method_2()
		{
		}

		// Token: 0x060037B1 RID: 14257 RVA: 0x00070374 File Offset: 0x0006E574
		[Address(RVA = "0x3270358", Offset = "0x3270358", VA = "0x3270358")]
		[Token(Token = "0x60037B1")]
		public void method_3(ConfigurableJoint configurableJoint_0)
		{
			this.method_9();
		}

		// Token: 0x060037B2 RID: 14258 RVA: 0x00070388 File Offset: 0x0006E588
		[Token(Token = "0x60037B2")]
		[Address(RVA = "0x3270438", Offset = "0x3270438", VA = "0x3270438")]
		public void method_4(ConfigurableJoint configurableJoint_0)
		{
			this.method_34();
		}

		// Token: 0x060037B3 RID: 14259 RVA: 0x0007039C File Offset: 0x0006E59C
		[Token(Token = "0x60037B3")]
		[Address(RVA = "0x3270518", Offset = "0x3270518", VA = "0x3270518")]
		public void method_5(ConfigurableJoint configurableJoint_0)
		{
			this.method_38();
		}

		// Token: 0x060037B4 RID: 14260 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32705F8", Offset = "0x32705F8", VA = "0x32705F8")]
		[Token(Token = "0x60037B4")]
		public JointDrive method_6()
		{
		}

		// Token: 0x060037B5 RID: 14261 RVA: 0x000703B0 File Offset: 0x0006E5B0
		[Address(RVA = "0x327065C", Offset = "0x327065C", VA = "0x327065C")]
		[Token(Token = "0x60037B5")]
		public void method_7(ConfigurableJoint configurableJoint_0)
		{
			this.method_24();
		}

		// Token: 0x060037B6 RID: 14262 RVA: 0x000703C4 File Offset: 0x0006E5C4
		[Token(Token = "0x60037B6")]
		[Address(RVA = "0x327073C", Offset = "0x327073C", VA = "0x327073C")]
		public void method_8(ConfigurableJoint configurableJoint_0)
		{
			this.method_49();
		}

		// Token: 0x060037B7 RID: 14263 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32703D4", Offset = "0x32703D4", VA = "0x32703D4")]
		[Token(Token = "0x60037B7")]
		public JointDrive method_9()
		{
		}

		// Token: 0x060037B8 RID: 14264 RVA: 0x000703D8 File Offset: 0x0006E5D8
		[Address(RVA = "0x327081C", Offset = "0x327081C", VA = "0x327081C")]
		[Token(Token = "0x60037B8")]
		public void method_10(ConfigurableJoint configurableJoint_0)
		{
			this.method_59();
		}

		// Token: 0x060037B9 RID: 14265 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32708FC", Offset = "0x32708FC", VA = "0x32708FC")]
		[Token(Token = "0x60037B9")]
		public JointDrive method_11()
		{
		}

		// Token: 0x060037BA RID: 14266 RVA: 0x000703EC File Offset: 0x0006E5EC
		[Token(Token = "0x60037BA")]
		[Address(RVA = "0x3270960", Offset = "0x3270960", VA = "0x3270960")]
		public void method_12(ConfigurableJoint configurableJoint_0)
		{
			this.method_11();
		}

		// Token: 0x060037BB RID: 14267 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037BB")]
		[Address(RVA = "0x32709DC", Offset = "0x32709DC", VA = "0x32709DC")]
		public JointDrive method_13()
		{
		}

		// Token: 0x060037BC RID: 14268 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3270A40", Offset = "0x3270A40", VA = "0x3270A40")]
		[Token(Token = "0x60037BC")]
		public JointDrive method_14()
		{
		}

		// Token: 0x060037BD RID: 14269 RVA: 0x000703C4 File Offset: 0x0006E5C4
		[Address(RVA = "0x3270AA4", Offset = "0x3270AA4", VA = "0x3270AA4")]
		[Token(Token = "0x60037BD")]
		public void method_15(ConfigurableJoint configurableJoint_0)
		{
			this.method_49();
		}

		// Token: 0x060037BE RID: 14270 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3270B20", Offset = "0x3270B20", VA = "0x3270B20")]
		[Token(Token = "0x60037BE")]
		public JointDrive method_16()
		{
		}

		// Token: 0x060037BF RID: 14271 RVA: 0x00070388 File Offset: 0x0006E588
		[Token(Token = "0x60037BF")]
		[Address(RVA = "0x3270B84", Offset = "0x3270B84", VA = "0x3270B84")]
		public void method_17(ConfigurableJoint configurableJoint_0)
		{
			this.method_34();
		}

		// Token: 0x060037C0 RID: 14272 RVA: 0x00070400 File Offset: 0x0006E600
		[Address(RVA = "0x3270C00", Offset = "0x3270C00", VA = "0x3270C00")]
		[Token(Token = "0x60037C0")]
		public void method_18(ConfigurableJoint configurableJoint_0)
		{
			this.method_1();
		}

		// Token: 0x060037C1 RID: 14273 RVA: 0x00070414 File Offset: 0x0006E614
		[Token(Token = "0x60037C1")]
		[Address(RVA = "0x3270C7C", Offset = "0x3270C7C", VA = "0x3270C7C")]
		public void method_19(ConfigurableJoint configurableJoint_0)
		{
			this.method_0();
		}

		// Token: 0x060037C2 RID: 14274 RVA: 0x00070428 File Offset: 0x0006E628
		[Token(Token = "0x60037C2")]
		[Address(RVA = "0x3270CF8", Offset = "0x3270CF8", VA = "0x3270CF8")]
		public void method_20(ConfigurableJoint configurableJoint_0)
		{
			this.method_60();
		}

		// Token: 0x060037C3 RID: 14275 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037C3")]
		[Address(RVA = "0x3270DD8", Offset = "0x3270DD8", VA = "0x3270DD8")]
		public JointDrive method_21()
		{
		}

		// Token: 0x060037C4 RID: 14276 RVA: 0x0007043C File Offset: 0x0006E63C
		[Address(RVA = "0x3270E3C", Offset = "0x3270E3C", VA = "0x3270E3C")]
		[Token(Token = "0x60037C4")]
		public void method_22(ConfigurableJoint configurableJoint_0)
		{
			this.method_41();
		}

		// Token: 0x060037C5 RID: 14277 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037C5")]
		[Address(RVA = "0x3270F1C", Offset = "0x3270F1C", VA = "0x3270F1C")]
		public JointDrive method_23()
		{
		}

		// Token: 0x060037C6 RID: 14278 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32706D8", Offset = "0x32706D8", VA = "0x32706D8")]
		[Token(Token = "0x60037C6")]
		public JointDrive method_24()
		{
		}

		// Token: 0x060037C7 RID: 14279 RVA: 0x00070400 File Offset: 0x0006E600
		[Address(RVA = "0x3270F80", Offset = "0x3270F80", VA = "0x3270F80")]
		[Token(Token = "0x60037C7")]
		public void method_25(ConfigurableJoint configurableJoint_0)
		{
			this.method_1();
		}

		// Token: 0x060037C8 RID: 14280 RVA: 0x00070450 File Offset: 0x0006E650
		[Token(Token = "0x60037C8")]
		[Address(RVA = "0x3270FFC", Offset = "0x3270FFC", VA = "0x3270FFC")]
		public void method_26(ConfigurableJoint configurableJoint_0)
		{
			this.method_33();
		}

		// Token: 0x060037C9 RID: 14281 RVA: 0x00070464 File Offset: 0x0006E664
		[Address(RVA = "0x32710DC", Offset = "0x32710DC", VA = "0x32710DC")]
		[Token(Token = "0x60037C9")]
		public void method_27(ConfigurableJoint configurableJoint_0)
		{
			this.method_52();
		}

		// Token: 0x060037CA RID: 14282 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32711BC", Offset = "0x32711BC", VA = "0x32711BC")]
		[Token(Token = "0x60037CA")]
		public JointDrive method_28()
		{
		}

		// Token: 0x060037CB RID: 14283 RVA: 0x00070374 File Offset: 0x0006E574
		[Address(RVA = "0x3271220", Offset = "0x3271220", VA = "0x3271220")]
		[Token(Token = "0x60037CB")]
		public void method_29(ConfigurableJoint configurableJoint_0)
		{
			this.method_9();
		}

		// Token: 0x060037CC RID: 14284 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x327129C", Offset = "0x327129C", VA = "0x327129C")]
		[Token(Token = "0x60037CC")]
		public JointDrive method_30()
		{
		}

		// Token: 0x060037CD RID: 14285 RVA: 0x00070478 File Offset: 0x0006E678
		[Address(RVA = "0x3271300", Offset = "0x3271300", VA = "0x3271300")]
		[Token(Token = "0x60037CD")]
		public void method_31(ConfigurableJoint configurableJoint_0)
		{
			this.method_44();
		}

		// Token: 0x060037CE RID: 14286 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037CE")]
		[Address(RVA = "0x32713E0", Offset = "0x32713E0", VA = "0x32713E0")]
		public JointDrive method_32()
		{
		}

		// Token: 0x060037CF RID: 14287 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037CF")]
		[Address(RVA = "0x3271078", Offset = "0x3271078", VA = "0x3271078")]
		public JointDrive method_33()
		{
		}

		// Token: 0x060037D0 RID: 14288 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32704B4", Offset = "0x32704B4", VA = "0x32704B4")]
		[Token(Token = "0x60037D0")]
		public JointDrive method_34()
		{
		}

		// Token: 0x060037D1 RID: 14289 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3271444", Offset = "0x3271444", VA = "0x3271444")]
		[Token(Token = "0x60037D1")]
		public JointDrive method_35()
		{
		}

		// Token: 0x060037D2 RID: 14290 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037D2")]
		[Address(RVA = "0x32714A8", Offset = "0x32714A8", VA = "0x32714A8")]
		public JointDrive method_36()
		{
		}

		// Token: 0x060037D3 RID: 14291 RVA: 0x00070400 File Offset: 0x0006E600
		[Address(RVA = "0x327150C", Offset = "0x327150C", VA = "0x327150C")]
		[Token(Token = "0x60037D3")]
		public void method_37(ConfigurableJoint configurableJoint_0)
		{
			this.method_1();
		}

		// Token: 0x060037D4 RID: 14292 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3270594", Offset = "0x3270594", VA = "0x3270594")]
		[Token(Token = "0x60037D4")]
		public JointDrive method_38()
		{
		}

		// Token: 0x060037D5 RID: 14293 RVA: 0x000020B4 File Offset: 0x000002B4
		[Address(RVA = "0x3271588", Offset = "0x3271588", VA = "0x3271588")]
		[Token(Token = "0x60037D5")]
		public HexaJointDrive(float float_0, float float_1, float float_2)
		{
		}

		// Token: 0x060037D6 RID: 14294 RVA: 0x0007048C File Offset: 0x0006E68C
		[Token(Token = "0x60037D6")]
		[Address(RVA = "0x32715D0", Offset = "0x32715D0", VA = "0x32715D0")]
		public void method_39(ConfigurableJoint configurableJoint_0)
		{
			this.method_40();
		}

		// Token: 0x060037D7 RID: 14295 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037D7")]
		[Address(RVA = "0x327164C", Offset = "0x327164C", VA = "0x327164C")]
		public JointDrive method_40()
		{
		}

		// Token: 0x060037D8 RID: 14296 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037D8")]
		[Address(RVA = "0x3270EB8", Offset = "0x3270EB8", VA = "0x3270EB8")]
		public JointDrive method_41()
		{
		}

		// Token: 0x060037D9 RID: 14297 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32716B0", Offset = "0x32716B0", VA = "0x32716B0")]
		[Token(Token = "0x60037D9")]
		public JointDrive method_42()
		{
		}

		// Token: 0x060037DA RID: 14298 RVA: 0x00070478 File Offset: 0x0006E678
		[Token(Token = "0x60037DA")]
		[Address(RVA = "0x3271714", Offset = "0x3271714", VA = "0x3271714")]
		public void method_43(ConfigurableJoint configurableJoint_0)
		{
			this.method_44();
		}

		// Token: 0x060037DB RID: 14299 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037DB")]
		[Address(RVA = "0x327137C", Offset = "0x327137C", VA = "0x327137C")]
		public JointDrive method_44()
		{
		}

		// Token: 0x060037DC RID: 14300 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037DC")]
		[Address(RVA = "0x3271790", Offset = "0x3271790", VA = "0x3271790")]
		public JointDrive method_45()
		{
		}

		// Token: 0x060037DD RID: 14301 RVA: 0x000704A0 File Offset: 0x0006E6A0
		[Token(Token = "0x60037DD")]
		[Address(RVA = "0x32717F4", Offset = "0x32717F4", VA = "0x32717F4")]
		public void method_46(ConfigurableJoint configurableJoint_0)
		{
			this.method_14();
		}

		// Token: 0x060037DE RID: 14302 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3271870", Offset = "0x3271870", VA = "0x3271870")]
		[Token(Token = "0x60037DE")]
		public JointDrive method_47()
		{
		}

		// Token: 0x060037DF RID: 14303 RVA: 0x000704B4 File Offset: 0x0006E6B4
		[Token(Token = "0x60037DF")]
		[Address(RVA = "0x32718D4", Offset = "0x32718D4", VA = "0x32718D4")]
		public void method_48(ConfigurableJoint configurableJoint_0)
		{
			this.method_6();
		}

		// Token: 0x060037E0 RID: 14304 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x32707B8", Offset = "0x32707B8", VA = "0x32707B8")]
		[Token(Token = "0x60037E0")]
		public JointDrive method_49()
		{
		}

		// Token: 0x060037E1 RID: 14305 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037E1")]
		[Address(RVA = "0x3271950", Offset = "0x3271950", VA = "0x3271950")]
		public JointDrive method_50()
		{
		}

		// Token: 0x060037E2 RID: 14306 RVA: 0x000704C8 File Offset: 0x0006E6C8
		[Token(Token = "0x60037E2")]
		[Address(RVA = "0x32719B4", Offset = "0x32719B4", VA = "0x32719B4")]
		public void method_51(ConfigurableJoint configurableJoint_0)
		{
			this.method_35();
		}

		// Token: 0x060037E3 RID: 14307 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037E3")]
		[Address(RVA = "0x3271158", Offset = "0x3271158", VA = "0x3271158")]
		public JointDrive method_52()
		{
		}

		// Token: 0x060037E4 RID: 14308 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3271A30", Offset = "0x3271A30", VA = "0x3271A30")]
		[Token(Token = "0x60037E4")]
		public JointDrive method_53()
		{
		}

		// Token: 0x060037E5 RID: 14309 RVA: 0x000704DC File Offset: 0x0006E6DC
		[Address(RVA = "0x3271A94", Offset = "0x3271A94", VA = "0x3271A94")]
		[Token(Token = "0x60037E5")]
		public void method_54(ConfigurableJoint configurableJoint_0)
		{
			this.method_45();
		}

		// Token: 0x060037E6 RID: 14310 RVA: 0x000704F0 File Offset: 0x0006E6F0
		[Address(RVA = "0x3271B10", Offset = "0x3271B10", VA = "0x3271B10")]
		[Token(Token = "0x60037E6")]
		public void method_55(ConfigurableJoint configurableJoint_0)
		{
			this.method_47();
		}

		// Token: 0x060037E7 RID: 14311 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037E7")]
		[Address(RVA = "0x3271B8C", Offset = "0x3271B8C", VA = "0x3271B8C")]
		public JointDrive method_56()
		{
		}

		// Token: 0x060037E8 RID: 14312 RVA: 0x000704DC File Offset: 0x0006E6DC
		[Token(Token = "0x60037E8")]
		[Address(RVA = "0x3271BF0", Offset = "0x3271BF0", VA = "0x3271BF0")]
		public void method_57(ConfigurableJoint configurableJoint_0)
		{
			this.method_45();
		}

		// Token: 0x060037E9 RID: 14313 RVA: 0x000704A0 File Offset: 0x0006E6A0
		[Token(Token = "0x60037E9")]
		[Address(RVA = "0x3271C6C", Offset = "0x3271C6C", VA = "0x3271C6C")]
		public void method_58(ConfigurableJoint configurableJoint_0)
		{
			this.method_14();
		}

		// Token: 0x060037EA RID: 14314 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037EA")]
		[Address(RVA = "0x3270898", Offset = "0x3270898", VA = "0x3270898")]
		public JointDrive method_59()
		{
		}

		// Token: 0x060037EB RID: 14315 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3270D74", Offset = "0x3270D74", VA = "0x3270D74")]
		[Token(Token = "0x60037EB")]
		public JointDrive method_60()
		{
		}

		// Token: 0x060037EC RID: 14316 RVA: 0x000704A0 File Offset: 0x0006E6A0
		[Token(Token = "0x60037EC")]
		[Address(RVA = "0x3271CE8", Offset = "0x3271CE8", VA = "0x3271CE8")]
		public void method_61(ConfigurableJoint configurableJoint_0)
		{
			this.method_14();
		}

		// Token: 0x060037ED RID: 14317 RVA: 0x000703C4 File Offset: 0x0006E5C4
		[Token(Token = "0x60037ED")]
		[Address(RVA = "0x3271D64", Offset = "0x3271D64", VA = "0x3271D64")]
		public void method_62(ConfigurableJoint configurableJoint_0)
		{
			this.method_49();
		}

		// Token: 0x060037EE RID: 14318 RVA: 0x00070504 File Offset: 0x0006E704
		[Address(RVA = "0x3271DE0", Offset = "0x3271DE0", VA = "0x3271DE0")]
		[Token(Token = "0x60037EE")]
		public void method_63(ConfigurableJoint configurableJoint_0)
		{
			this.method_21();
		}

		// Token: 0x060037EF RID: 14319 RVA: 0x000704DC File Offset: 0x0006E6DC
		[Token(Token = "0x60037EF")]
		[Address(RVA = "0x3271E5C", Offset = "0x3271E5C", VA = "0x3271E5C")]
		public void method_64(ConfigurableJoint configurableJoint_0)
		{
			this.method_45();
		}

		// Token: 0x060037F0 RID: 14320 RVA: 0x0007048C File Offset: 0x0006E68C
		[Token(Token = "0x60037F0")]
		[Address(RVA = "0x3271ED8", Offset = "0x3271ED8", VA = "0x3271ED8")]
		public void method_65(ConfigurableJoint configurableJoint_0)
		{
			this.method_40();
		}

		// Token: 0x060037F1 RID: 14321 RVA: 0x00070450 File Offset: 0x0006E650
		[Token(Token = "0x60037F1")]
		[Address(RVA = "0x3271F54", Offset = "0x3271F54", VA = "0x3271F54")]
		public void method_66(ConfigurableJoint configurableJoint_0)
		{
			this.method_33();
		}

		// Token: 0x060037F2 RID: 14322 RVA: 0x00070364 File Offset: 0x0006E564
		[Address(RVA = "0x3271FD0", Offset = "0x3271FD0", VA = "0x3271FD0")]
		[Token(Token = "0x60037F2")]
		public JointDrive method_67()
		{
		}

		// Token: 0x060037F3 RID: 14323 RVA: 0x00070364 File Offset: 0x0006E564
		[Token(Token = "0x60037F3")]
		[Address(RVA = "0x3272034", Offset = "0x3272034", VA = "0x3272034")]
		public JointDrive method_68()
		{
		}

		// Token: 0x060037F4 RID: 14324 RVA: 0x00070518 File Offset: 0x0006E718
		[Address(RVA = "0x3272098", Offset = "0x3272098", VA = "0x3272098")]
		[Token(Token = "0x60037F4")]
		public void method_69(ConfigurableJoint configurableJoint_0)
		{
			this.method_68();
		}

		// Token: 0x0400096F RID: 2415
		[Token(Token = "0x400096F")]
		[FieldOffset(Offset = "0x10")]
		public float Spring;

		// Token: 0x04000970 RID: 2416
		[Token(Token = "0x4000970")]
		[FieldOffset(Offset = "0x14")]
		public float Damper;

		// Token: 0x04000971 RID: 2417
		[Token(Token = "0x4000971")]
		[FieldOffset(Offset = "0x18")]
		public float MaxForce;
	}
}
