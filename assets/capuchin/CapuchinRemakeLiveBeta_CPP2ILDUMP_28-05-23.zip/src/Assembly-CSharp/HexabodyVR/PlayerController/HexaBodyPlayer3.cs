﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000148 RID: 328
	[Token(Token = "0x2000148")]
	public class HexaBodyPlayer3 : MonoBehaviour
	{
		// Token: 0x060034F5 RID: 13557 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x339EC94", Offset = "0x339EC94", VA = "0x339EC94")]
		[Token(Token = "0x60034F5")]
		private void method_0(Vector3 vector3_8)
		{
		}

		// Token: 0x060034F6 RID: 13558 RVA: 0x0006A094 File Offset: 0x00068294
		[Token(Token = "0x60034F6")]
		[Address(RVA = "0x339ECA4", Offset = "0x339ECA4", VA = "0x339ECA4")]
		private void method_1()
		{
			do
			{
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (hexaBodyPlayerInputs.playerInputState_1.JustActivated)
				{
					return;
				}
				if (!hexaBodyPlayerInputs.playerInputState_2.JustActivated)
				{
					goto IL_37;
				}
				float deltaTime = Time.deltaTime;
			}
			while (this.hexaBodyPlayerInputs_0.playerInputState_1 == null);
			return;
			IL_37:
			throw new MissingMethodException();
		}

		// Token: 0x060034F7 RID: 13559 RVA: 0x0006A0E0 File Offset: 0x000682E0
		[Token(Token = "0x60034F7")]
		[Address(RVA = "0x339F010", Offset = "0x339F010", VA = "0x339F010")]
		public void method_2(Vector3 vector3_8)
		{
			Vector3 eulerAngles = this.transform_0.rotation.eulerAngles;
			Vector3 forward = this.transform_0.forward;
			Quaternion quaternion;
			Vector3 eulerAngles2 = quaternion.eulerAngles;
			Quaternion rotation = this.rigidbody_1.rotation;
		}

		// Token: 0x060034F8 RID: 13560 RVA: 0x0006A120 File Offset: 0x00068320
		[Address(RVA = "0x339F138", Offset = "0x339F138", VA = "0x339F138")]
		[Token(Token = "0x60034F8")]
		public HexaBodyPlayer3()
		{
			this.float_6 = (float)4719;
			long num = 1L;
			this.genum18_0 = (GEnum18)num;
			this.bool_0 = (num != 0L);
			this.float_20 = (float)23593;
			this.genum16_0 = (GEnum16)23593;
			this.float_29 = (float)16000;
			long num2 = 1073741824L;
			this.float_33 = (float)num2;
			this.float_34 = (float)31457;
			long num3 = 1065353216L;
			this.float_50 = (float)39322;
			this.float_58 = (float)num3;
			this.float_61 = (float)num3;
			base..ctor();
		}

		// Token: 0x060034F9 RID: 13561 RVA: 0x0006A1B4 File Offset: 0x000683B4
		[Address(RVA = "0x339F228", Offset = "0x339F228", VA = "0x339F228")]
		[Token(Token = "0x60034F9")]
		private void method_3()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 right = this.transform_0.right;
			if (!this.hexaBodyPlayerInputs_0.playerInputState_0.JustDeactivated || !this.bool_8)
			{
			}
		}

		// Token: 0x060034FA RID: 13562 RVA: 0x000032CF File Offset: 0x000014CF
		[Address(RVA = "0x339F2A8", Offset = "0x339F2A8", VA = "0x339F2A8")]
		[Token(Token = "0x60034FA")]
		private void method_4(HexaBodyPlayerInputs hexaBodyPlayerInputs_1)
		{
			this.hexaBodyPlayerInputs_0 = hexaBodyPlayerInputs_1;
		}

		// Token: 0x060034FB RID: 13563 RVA: 0x0006A1F4 File Offset: 0x000683F4
		[Token(Token = "0x60034FB")]
		[Address(RVA = "0x339F2B8", Offset = "0x339F2B8", VA = "0x339F2B8")]
		private void method_5()
		{
			this.method_53();
			bool flag = this.bool_1;
			this.bool_5 = flag;
		}

		// Token: 0x060034FC RID: 13564 RVA: 0x0006A218 File Offset: 0x00068418
		[Address(RVA = "0x339F3BC", Offset = "0x339F3BC", VA = "0x339F3BC")]
		[Token(Token = "0x60034FC")]
		public void method_6()
		{
			float num = this.float_37;
			float num2 = this.float_43;
			this.float_45 = num;
			this.float_46 = num2;
			float num3;
			this.float_47 = num3;
			float single_ = this.Single_0;
			float single_2 = this.Single_0;
			this.float_47 = num2;
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060034FD RID: 13565 RVA: 0x0006797C File Offset: 0x00065B7C
		// (set) Token: 0x0600352B RID: 13611 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000AD")]
		public Quaternion Quaternion_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x339F4F8", Offset = "0x339F4F8", VA = "0x339F4F8")]
			[Token(Token = "0x60034FD")]
			get
			{
			}
			[CompilerGenerated]
			[Token(Token = "0x600352B")]
			[Address(RVA = "0x33A2924", Offset = "0x33A2924", VA = "0x33A2924")]
			private set
			{
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06003513 RID: 13587 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		// (set) Token: 0x060034FE RID: 13566 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000AF")]
		public Vector3 Vector3_0
		{
			[Address(RVA = "0x33A1CFC", Offset = "0x33A1CFC", VA = "0x33A1CFC")]
			[Token(Token = "0x6003513")]
			[CompilerGenerated]
			get
			{
				Vector3 result;
				return result;
			}
			[Token(Token = "0x60034FE")]
			[Address(RVA = "0x339F50C", Offset = "0x339F50C", VA = "0x339F50C")]
			[CompilerGenerated]
			private set
			{
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060034FF RID: 13567 RVA: 0x000032D8 File Offset: 0x000014D8
		// (set) Token: 0x06003533 RID: 13619 RVA: 0x000032CF File Offset: 0x000014CF
		[Token(Token = "0x170000AE")]
		public HexaBodyPlayerInputs HexaBodyPlayerInputs_0 { [Token(Token = "0x60034FF")] [Address(RVA = "0x339F51C", Offset = "0x339F51C", VA = "0x339F51C")] get; [Address(RVA = "0x33A2A54", Offset = "0x33A2A54", VA = "0x33A2A54")] [Token(Token = "0x6003533")] private set; }

		// Token: 0x06003500 RID: 13568 RVA: 0x0006A260 File Offset: 0x00068460
		[Address(RVA = "0x339F524", Offset = "0x339F524", VA = "0x339F524")]
		[Token(Token = "0x6003500")]
		private void method_7()
		{
			int num;
			while (!this.hexaBodyPlayerInputs_0.playerInputState_1.JustActivated)
			{
				if (num == 0)
				{
					throw new MissingMethodException();
				}
				this.float_57 = (float)17322;
				float deltaTime = Time.deltaTime;
				if (this.hexaBodyPlayerInputs_0.playerInputState_1 != null)
				{
					return;
				}
			}
			num = 40960;
		}

		// Token: 0x06003501 RID: 13569 RVA: 0x0006A2B0 File Offset: 0x000684B0
		[Address(RVA = "0x339F77C", Offset = "0x339F77C", VA = "0x339F77C")]
		[Token(Token = "0x6003501")]
		private void method_8()
		{
			GameObject gameObject = this.transform_12.gameObject;
			bool active = this.bool_1;
			gameObject.SetActive(active);
			GameObject gameObject2 = this.transform_11.gameObject;
			bool active2 = this.bool_1;
			gameObject2.SetActive(active2);
			GameObject gameObject3 = this.transform_10.gameObject;
			bool active3 = this.bool_1;
			gameObject3.SetActive(active3);
			GameObject gameObject4 = this.transform_13.gameObject;
			bool active4 = this.bool_1;
			gameObject4.SetActive(active4);
			GameObject gameObject5 = this.transform_14.gameObject;
			bool active5 = this.bool_1;
			gameObject5.SetActive(active5);
		}

		// Token: 0x06003502 RID: 13570 RVA: 0x00068F24 File Offset: 0x00067124
		[Token(Token = "0x6003502")]
		[Address(RVA = "0x339F838", Offset = "0x339F838", VA = "0x339F838")]
		private void method_9(Vector3 vector3_8)
		{
		}

		// Token: 0x06003503 RID: 13571 RVA: 0x0006A34C File Offset: 0x0006854C
		[Token(Token = "0x6003503")]
		[Address(RVA = "0x339F958", Offset = "0x339F958", VA = "0x339F958")]
		private void method_10()
		{
			HexaBodyPlayerInputs component = base.GetComponent<HexaBodyPlayerInputs>();
			this.hexaBodyPlayerInputs_0 = component;
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = sphereCollider.radius;
			float radius2 = sphereCollider.radius;
			this.method_42();
			bool flag = this.bool_2;
			long crouchLevel = 1L;
			this._crouchLevel = (GEnum16)crouchLevel;
			if (flag)
			{
				IEnumerator routine = this.method_37();
				base.StartCoroutine(routine);
			}
			this.method_53();
			this.method_32(radius2);
			this.rigidbody_0.maxAngularVelocity = radius2;
		}

		// Token: 0x06003504 RID: 13572 RVA: 0x0006A3C4 File Offset: 0x000685C4
		[Token(Token = "0x6003504")]
		[Address(RVA = "0x339FF14", Offset = "0x339FF14", VA = "0x339FF14")]
		public void method_11(Vector3 vector3_8)
		{
			Vector3 position = this.rigidbody_3.transform.position;
			Vector3 position2 = this.rigidbody_0.transform.position;
			Vector3 position3 = this.rigidbody_1.transform.position;
			Vector3 position4 = this.rigidbody_0.transform.position;
			Vector3 position5 = this.rigidbody_2.transform.position;
			Vector3 position6 = this.rigidbody_0.transform.position;
			Vector3 position7 = this.rigidbody_4.transform.position;
			Vector3 position8 = this.rigidbody_0.transform.position;
			Vector3 position9 = this.rigidbody_5.transform.position;
			Vector3 position10 = this.rigidbody_0.transform.position;
			Transform transform = this.rigidbody_0.transform;
			float radius = this.sphereCollider_0.radius;
			Transform transform2 = this.rigidbody_3.transform;
			Vector3 position11 = this.rigidbody_0.transform.position;
			Transform transform3 = this.rigidbody_1.transform;
			Vector3 position12 = this.rigidbody_0.transform.position;
			Transform transform4 = this.rigidbody_2.transform;
			Vector3 position13 = this.rigidbody_0.transform.position;
			Transform transform5 = this.rigidbody_4.transform;
			Vector3 position14 = this.rigidbody_0.transform.position;
			Transform transform6 = this.rigidbody_5.transform;
			Vector3 position15 = this.rigidbody_0.transform.position;
			this.method_43();
		}

		// Token: 0x06003505 RID: 13573 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003505")]
		[Address(RVA = "0x33A041C", Offset = "0x33A041C", VA = "0x33A041C")]
		private void method_12(Vector3 vector3_8)
		{
		}

		// Token: 0x06003506 RID: 13574 RVA: 0x0006A52C File Offset: 0x0006872C
		[Address(RVA = "0x33A042C", Offset = "0x33A042C", VA = "0x33A042C")]
		[Token(Token = "0x6003506")]
		public void method_13()
		{
			if (this.bool_6)
			{
				return;
			}
			SphereCollider sphereCollider = this.sphereCollider_0;
			long num = 1L;
			this.bool_6 = (num != 0L);
			this.float_19 = (float)17076;
			PhysicMaterial material = sphereCollider.material;
			this.physicMaterial_1 = material;
			SphereCollider sphereCollider2 = this.sphereCollider_0;
			PhysicMaterial material2 = this.physicMaterial_0;
			sphereCollider2.material = material2;
		}

		// Token: 0x06003507 RID: 13575 RVA: 0x0006A584 File Offset: 0x00068784
		[Token(Token = "0x6003507")]
		[Address(RVA = "0x33A04A8", Offset = "0x33A04A8", VA = "0x33A04A8")]
		private IEnumerator method_14(float float_63)
		{
			HexaBodyPlayer3.Class50 @class = new HexaBodyPlayer3.Class50((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003508 RID: 13576 RVA: 0x0006A5AC File Offset: 0x000687AC
		[Token(Token = "0x6003508")]
		[Address(RVA = "0x33A0530", Offset = "0x33A0530", VA = "0x33A0530")]
		private IEnumerator method_15()
		{
			HexaBodyPlayer3.Class53 @class = new HexaBodyPlayer3.Class53((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003509 RID: 13577 RVA: 0x0006797C File Offset: 0x00065B7C
		[Token(Token = "0x6003509")]
		[Address(RVA = "0x33A05A8", Offset = "0x33A05A8", VA = "0x33A05A8")]
		public Quaternion method_16()
		{
		}

		// Token: 0x0600350A RID: 13578 RVA: 0x0006A5D4 File Offset: 0x000687D4
		[Address(RVA = "0x33A05BC", Offset = "0x33A05BC", VA = "0x33A05BC")]
		[Token(Token = "0x600350A")]
		private IEnumerator method_17()
		{
			HexaBodyPlayer3.Class51 @class = new HexaBodyPlayer3.Class51((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x0600350B RID: 13579 RVA: 0x0006A5FC File Offset: 0x000687FC
		[Token(Token = "0x600350B")]
		[Address(RVA = "0x33A0634", Offset = "0x33A0634", VA = "0x33A0634")]
		private void method_18()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 right = this.transform_0.right;
			if (this.hexaBodyPlayerInputs_0.playerInputState_0.JustDeactivated && this.bool_8)
			{
				long num = 1L;
				this.bool_3 = (num != 0L);
			}
		}

		// Token: 0x0600350C RID: 13580 RVA: 0x0006A644 File Offset: 0x00068844
		[Token(Token = "0x600350C")]
		[Address(RVA = "0x33A06B8", Offset = "0x33A06B8", VA = "0x33A06B8")]
		private void FixedUpdate()
		{
			Vector3 velocity = this.rigidbody_1.velocity;
			float magnitude = this.rigidbody_1.velocity.magnitude;
			this.method_21();
			this.method_51();
			this.method_52();
			this.method_28();
			this.method_27();
			this.method_45();
			this.method_34();
			this.method_31();
		}

		// Token: 0x0600350D RID: 13581 RVA: 0x00067DF8 File Offset: 0x00065FF8
		[Address(RVA = "0x33A1C08", Offset = "0x33A1C08", VA = "0x33A1C08")]
		[Token(Token = "0x600350D")]
		private Vector2 method_19()
		{
			Input.GetKey(KeyCode.W);
			Input.GetKey(KeyCode.S);
			Input.GetKey(KeyCode.A);
			Input.GetKey(KeyCode.D);
			Vector2 result;
			return result;
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x0600350E RID: 13582 RVA: 0x0006A6A0 File Offset: 0x000688A0
		[Token(Token = "0x170000B2")]
		public float Single_0
		{
			[Address(RVA = "0x339F4A8", Offset = "0x339F4A8", VA = "0x339F4A8")]
			[Token(Token = "0x600350E")]
			get
			{
				Transform transform = this.transform_0;
				Vector3 localPosition = transform.localPosition;
				throw new NullReferenceException();
			}
		}

		// Token: 0x0600350F RID: 13583 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x33A1C90", Offset = "0x33A1C90", VA = "0x33A1C90")]
		[Token(Token = "0x600350F")]
		public void method_20(bool bool_10)
		{
		}

		// Token: 0x06003510 RID: 13584 RVA: 0x0006A6C0 File Offset: 0x000688C0
		[Token(Token = "0x6003510")]
		[Address(RVA = "0x33A0764", Offset = "0x33A0764", VA = "0x33A0764")]
		private void method_21()
		{
			Vector3 localPosition = this.transform_0.localPosition;
			float fixedDeltaTime = Time.fixedDeltaTime;
			Vector3 localPosition2 = this.transform_0.localPosition;
			Rigidbody rigidbody = this.rigidbody_0;
			Vector3 position = rigidbody.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			if (this._legStage != GEnum17.const_0)
			{
				JointDrive yDrive = this.configurableJoint_0.yDrive;
				yDrive.positionSpring = fixedDeltaTime;
				yDrive.positionDamper = fixedDeltaTime;
				yDrive.maximumForce = fixedDeltaTime;
				return;
			}
			HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
			float y;
			if (hexaBodyPlayerInputs.playerInputState_0 != null)
			{
				y = this.float_33;
				return;
			}
			this.vector3_4.y = y;
			float y2 = this.float_31;
			this.vector3_3.y = y2;
		}

		// Token: 0x06003511 RID: 13585 RVA: 0x0006A774 File Offset: 0x00068974
		[Address(RVA = "0x339EEFC", Offset = "0x339EEFC", VA = "0x339EEFC")]
		[Token(Token = "0x6003511")]
		private void method_22(GEnum16 genum16_1)
		{
			this._crouchLevel = genum16_1;
			this.method_23(genum16_1);
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06003512 RID: 13586 RVA: 0x000032E0 File Offset: 0x000014E0
		// (set) Token: 0x06003543 RID: 13635 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000B1")]
		public bool Boolean_1
		{
			[CompilerGenerated]
			[Address(RVA = "0x33A1CF4", Offset = "0x33A1CF4", VA = "0x33A1CF4")]
			[Token(Token = "0x6003512")]
			get
			{
				return this.bool_8;
			}
			[CompilerGenerated]
			[Address(RVA = "0x33A385C", Offset = "0x33A385C", VA = "0x33A385C")]
			[Token(Token = "0x6003543")]
			set
			{
			}
		}

		// Token: 0x06003514 RID: 13588 RVA: 0x0006A790 File Offset: 0x00068990
		[Address(RVA = "0x33A1C9C", Offset = "0x33A1C9C", VA = "0x33A1C9C")]
		[Token(Token = "0x6003514")]
		private float method_23(GEnum16 genum16_1)
		{
		}

		// Token: 0x06003515 RID: 13589 RVA: 0x0006A7A0 File Offset: 0x000689A0
		[SerializeField]
		[Address(RVA = "0x33A1D0C", Offset = "0x33A1D0C", VA = "0x33A1D0C")]
		[Token(Token = "0x6003515")]
		private void Update()
		{
			if (this.hexaBodyPlayerInputs_0.bool_3)
			{
				this.method_60();
			}
			float num = this.float_8;
			float radius = this.sphereCollider_0.radius;
			Rigidbody rigidbody = this.rigidbody_1;
			this.float_38 = num;
			Vector3 position = rigidbody.position;
			Vector3 position2 = this.rigidbody_0.position;
			float num2 = this.float_38;
			Mathf.Clamp01(radius);
			this._standingPercent = num2;
			this.method_1();
			this.method_6();
			this.method_18();
			this.method_50();
			float magnitude = this.rigidbody_0.angularVelocity.magnitude;
			this._locoAngularVelocity = num2;
		}

		// Token: 0x06003516 RID: 13590 RVA: 0x0006A83C File Offset: 0x00068A3C
		[Token(Token = "0x6003516")]
		[Address(RVA = "0x33A2090", Offset = "0x33A2090", VA = "0x33A2090")]
		private IEnumerator method_24()
		{
			HexaBodyPlayer3.Class49 @class = new HexaBodyPlayer3.Class49((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003517 RID: 13591 RVA: 0x0006A864 File Offset: 0x00068A64
		[Token(Token = "0x6003517")]
		[Address(RVA = "0x33A2108", Offset = "0x33A2108", VA = "0x33A2108")]
		private void method_25()
		{
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = Vector3.up;
			float defaultContactOffset = Physics.defaultContactOffset;
			float radius = this.sphereCollider_0.radius;
			float defaultContactOffset2 = Physics.defaultContactOffset;
			Vector3 down = Vector3.down;
			LayerMask mask = this.layerMask_0;
			mask;
			Vector3 up2 = Vector3.up;
			Vector3 up3 = Vector3.up;
		}

		// Token: 0x06003518 RID: 13592 RVA: 0x00067E28 File Offset: 0x00066028
		[Address(RVA = "0x33A22CC", Offset = "0x33A22CC", VA = "0x33A22CC")]
		[Token(Token = "0x6003518")]
		public void method_26(float float_63)
		{
		}

		// Token: 0x06003519 RID: 13593 RVA: 0x0006A8C0 File Offset: 0x00068AC0
		[Token(Token = "0x6003519")]
		[Address(RVA = "0x33A1090", Offset = "0x33A1090", VA = "0x33A1090")]
		private void method_27()
		{
			if (this.bool_0)
			{
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (hexaBodyPlayerInputs != null)
				{
				}
				Vector3 up = Vector3.up;
				return;
			}
			if (!this.bool_9)
			{
				HexaBodyPlayerInputs hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
				float x = hexaBodyPlayerInputs2.vector2_1.x;
				if (hexaBodyPlayerInputs2 != null)
				{
				}
				float float_;
				IEnumerator routine = this.method_35(float_);
				base.StartCoroutine(routine);
				this.float_62 = x;
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06003523 RID: 13603 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		// (set) Token: 0x0600351A RID: 13594 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000B0")]
		public Vector3 Vector3_1
		{
			[CompilerGenerated]
			[Address(RVA = "0x33A268C", Offset = "0x33A268C", VA = "0x33A268C")]
			[Token(Token = "0x6003523")]
			get
			{
				Vector3 result;
				return result;
			}
			[CompilerGenerated]
			[Address(RVA = "0x33A23AC", Offset = "0x33A23AC", VA = "0x33A23AC")]
			[Token(Token = "0x600351A")]
			private set
			{
			}
		}

		// Token: 0x0600351B RID: 13595 RVA: 0x0006A924 File Offset: 0x00068B24
		[Address(RVA = "0x33A0BEC", Offset = "0x33A0BEC", VA = "0x33A0BEC")]
		[Token(Token = "0x600351B")]
		private void method_28()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
			float y = hexaBodyPlayerInputs.vector2_0.y;
			float magnitude = this.method_19().magnitude;
			if (this.bool_8)
			{
			}
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			AnimationCurve animationCurve = this.animationCurve_0;
			float time;
			animationCurve.Evaluate(time);
			if (this.bool_7)
			{
				return;
			}
			float time2;
			this.animationCurve_3.Evaluate(time2);
			float radius = this.sphereCollider_0.radius;
			float time3 = this.animationCurve_2.Evaluate(radius);
			AnimationCurve animationCurve2 = this.animationCurve_1;
			animationCurve2.Evaluate(time3);
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius2 = sphereCollider.radius;
			Vector3 angularVelocity = this.rigidbody_0.angularVelocity;
			if (this.bool_8)
			{
				Vector3 angularVelocity2 = this.rigidbody_0.angularVelocity;
				return;
			}
			Rigidbody rigidbody = this.rigidbody_0;
			Vector3 angularVelocity3 = rigidbody.angularVelocity;
			float radius3 = this.sphereCollider_0.radius;
			this.method_54();
			Rigidbody rigidbody2 = this.rigidbody_0;
			long freezeRotation = 0L;
			rigidbody2.freezeRotation = (freezeRotation != 0L);
			bool flag = this.bool_8;
			float groundAngle;
			if (rigidbody != null && flag)
			{
				groundAngle = this._groundAngle;
			}
			Vector3 angularVelocity4 = this.rigidbody_0.angularVelocity;
			float time4 = this.animationCurve_3.Evaluate(radius2);
			AnimationCurve animationCurve3 = this.animationCurve_2;
			this._modifiedTargetSpeed = groundAngle;
			float time5 = animationCurve3.Evaluate(time4);
			AnimationCurve animationCurve4 = this.animationCurve_1;
			float standingPercent = this._standingPercent;
			animationCurve4.Evaluate(time5);
			this._targetAngularVelocity = y;
			this._modifiedTargetAcceleration = standingPercent;
		}

		// Token: 0x0600351C RID: 13596 RVA: 0x00069508 File Offset: 0x00067708
		[Token(Token = "0x600351C")]
		[Address(RVA = "0x339F8BC", Offset = "0x339F8BC", VA = "0x339F8BC")]
		private void method_29(Rigidbody rigidbody_6, Vector3 vector3_8)
		{
			Vector3 velocity = rigidbody_6.velocity;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x0600351D RID: 13597 RVA: 0x0006AAA0 File Offset: 0x00068CA0
		[Address(RVA = "0x33A2630", Offset = "0x33A2630", VA = "0x33A2630")]
		[Token(Token = "0x600351D")]
		public void method_30()
		{
			if (this.bool_6)
			{
				float num = this.float_60;
				SphereCollider sphereCollider = this.sphereCollider_0;
				this.float_19 = num;
				PhysicMaterial material = this.physicMaterial_1;
				sphereCollider.material = material;
				return;
			}
		}

		// Token: 0x0600351E RID: 13598 RVA: 0x0006AADC File Offset: 0x00068CDC
		[Address(RVA = "0x33A1ABC", Offset = "0x33A1ABC", VA = "0x33A1ABC")]
		[Token(Token = "0x600351E")]
		private void method_31()
		{
			this.configurableJoint_3;
			Rigidbody rigidbody = this.rigidbody_1;
			Transform transform = rigidbody.transform;
			Vector3 position = this.transform_8.position;
			this.configurableJoint_4;
			Rigidbody rigidbody2 = this.rigidbody_1;
			Transform transform2 = rigidbody2.transform;
			Vector3 position2 = this.transform_9.position;
		}

		// Token: 0x0600351F RID: 13599 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x339FAFC", Offset = "0x339FAFC", VA = "0x339FAFC")]
		[Token(Token = "0x600351F")]
		public void method_32(float float_63)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003520 RID: 13600 RVA: 0x000032E8 File Offset: 0x000014E8
		[Address(RVA = "0x33A266C", Offset = "0x33A266C", VA = "0x33A266C")]
		[Token(Token = "0x6003520")]
		public void method_33(bool bool_10)
		{
			this.method_60();
		}

		// Token: 0x06003521 RID: 13601 RVA: 0x0006AB38 File Offset: 0x00068D38
		[Address(RVA = "0x33A1358", Offset = "0x33A1358", VA = "0x33A1358")]
		[Token(Token = "0x6003521")]
		private void method_34()
		{
			this.transform_0.forward.Normalize();
			Transform transform = this.rigidbody_1.transform;
			Vector3 center = this.capsuleCollider_3.center;
			Transform transform2 = this.rigidbody_1.transform;
			float deltaTime = Time.deltaTime;
			Transform transform3 = this.rigidbody_1.transform;
			Vector3 center2 = this.capsuleCollider_3.center;
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = this.transform_5.transform.up;
			Transform transform4 = this.transform_5.transform;
			Quaternion rotation = this.transform_5.transform.rotation;
			Rigidbody rigidbody = this.rigidbody_0;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			Vector3 position2 = rigidbody.position;
			float height;
			capsuleCollider.height = height;
			Transform transform5 = this.transform_5.transform;
			Vector3 position3 = this.rigidbody_0.position;
			Vector3 position4 = this.rigidbody_0.position;
			Vector3 localPosition = this.transform_7.localPosition;
			Transform transform6 = this.rigidbody_1.transform;
			float magnitude = this.capsuleCollider_3.center.magnitude;
			Vector3 position5 = this.transform_1.position;
			Vector3 up2 = this.transform_6.transform.up;
			Transform transform7 = this.transform_6.transform;
			Quaternion rotation2 = this.transform_6.transform.rotation;
			Transform transform8 = this.transform_1;
			CapsuleCollider capsuleCollider2 = this.capsuleCollider_1;
			Vector3 position6 = transform8.position;
			Vector3 position7 = this.transform_7.position;
			float height2;
			capsuleCollider2.height = height2;
			Transform transform9 = this.transform_1;
			Vector3 position8 = transform9.position;
			Transform transform10 = this.transform_6;
			Vector3 position9 = transform10.position;
			Vector3 position10 = this.rigidbody_3.position;
			Vector3 position11 = this.transform_6.position;
			Rigidbody rigidbody2 = this.rigidbody_3;
			Vector3 position12 = rigidbody2.position;
			Vector3 position13 = this.transform_6.position;
			Vector3 position14 = this.rigidbody_3.position;
			Vector3 position15 = this.transform_3.position;
			Vector3 up3 = this.transform_3.up;
			Transform transform11 = this.transform_3.transform;
			Quaternion rotation3 = this.transform_3.transform.rotation;
		}

		// Token: 0x06003522 RID: 13602 RVA: 0x0006A584 File Offset: 0x00068784
		[Address(RVA = "0x33A2324", Offset = "0x33A2324", VA = "0x33A2324")]
		[Token(Token = "0x6003522")]
		private IEnumerator method_35(float float_63)
		{
			HexaBodyPlayer3.Class50 @class = new HexaBodyPlayer3.Class50((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003524 RID: 13604 RVA: 0x0006AD3C File Offset: 0x00068F3C
		[Address(RVA = "0x33A269C", Offset = "0x33A269C", VA = "0x33A269C")]
		[Token(Token = "0x6003524")]
		private void method_36()
		{
			if (this.bool_3 && this.bool_8)
			{
				IEnumerator routine = this.method_17();
				base.StartCoroutine(routine);
				return;
			}
		}

		// Token: 0x06003525 RID: 13605 RVA: 0x0006A83C File Offset: 0x00068A3C
		[Address(RVA = "0x339FA84", Offset = "0x339FA84", VA = "0x339FA84")]
		[Token(Token = "0x6003525")]
		private IEnumerator method_37()
		{
			HexaBodyPlayer3.Class49 @class = new HexaBodyPlayer3.Class49((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003526 RID: 13606 RVA: 0x0006AD6C File Offset: 0x00068F6C
		[Token(Token = "0x6003526")]
		[Address(RVA = "0x33A26EC", Offset = "0x33A26EC", VA = "0x33A26EC", Slot = "4")]
		public virtual void vmethod_0()
		{
			this.method_42();
		}

		// Token: 0x06003527 RID: 13607 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x33A2734", Offset = "0x33A2734", VA = "0x33A2734")]
		[Token(Token = "0x6003527")]
		public float method_38()
		{
		}

		// Token: 0x06003528 RID: 13608 RVA: 0x0006AD80 File Offset: 0x00068F80
		[Address(RVA = "0x33A273C", Offset = "0x33A273C", VA = "0x33A273C")]
		[Token(Token = "0x6003528")]
		private void method_39(float float_63)
		{
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_1.position;
			Vector3 localPosition = this.transform_1.localPosition;
			float single_ = this.Single_0;
		}

		// Token: 0x06003529 RID: 13609 RVA: 0x0006ADB8 File Offset: 0x00068FB8
		[Address(RVA = "0x33A2834", Offset = "0x33A2834", VA = "0x33A2834")]
		[Token(Token = "0x6003529")]
		private IEnumerator method_40()
		{
			HexaBodyPlayer3.Class52 @class = new HexaBodyPlayer3.Class52((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x0600352A RID: 13610 RVA: 0x0006ADE0 File Offset: 0x00068FE0
		[Address(RVA = "0x33A28AC", Offset = "0x33A28AC", VA = "0x33A28AC")]
		[Token(Token = "0x600352A")]
		private IEnumerator method_41()
		{
			new HexaBodyPlayer3.Class53((int)0L);
			throw new NullReferenceException();
		}

		// Token: 0x0600352C RID: 13612 RVA: 0x0006AE04 File Offset: 0x00069004
		[Address(RVA = "0x339FA3C", Offset = "0x339FA3C", VA = "0x339FA3C")]
		[Token(Token = "0x600352C")]
		private void method_42()
		{
			float mass = this.rigidbody_2.mass;
			float mass2 = this.rigidbody_0.mass;
		}

		// Token: 0x0600352D RID: 13613 RVA: 0x0006AE2C File Offset: 0x0006902C
		[Address(RVA = "0x33A0344", Offset = "0x33A0344", VA = "0x33A0344")]
		[Token(Token = "0x600352D")]
		public void method_43()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600352E RID: 13614 RVA: 0x0006AE48 File Offset: 0x00069048
		[Token(Token = "0x170000B4")]
		private float Single_2
		{
			[Address(RVA = "0x33A2938", Offset = "0x33A2938", VA = "0x33A2938")]
			[Token(Token = "0x600352E")]
			get
			{
				float mass = this.rigidbody_1.mass;
				float mass2 = this.rigidbody_0.mass;
				float mass3 = this.rigidbody_3.mass;
				float mass4 = this.rigidbody_2.mass;
				throw new NullReferenceException();
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06003531 RID: 13617 RVA: 0x000032F0 File Offset: 0x000014F0
		// (set) Token: 0x0600352F RID: 13615 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000AC")]
		public bool Boolean_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x33A2A4C", Offset = "0x33A2A4C", VA = "0x33A2A4C")]
			[Token(Token = "0x6003531")]
			get
			{
				return this.bool_7;
			}
			[CompilerGenerated]
			[Address(RVA = "0x33A29C8", Offset = "0x33A29C8", VA = "0x33A29C8")]
			[Token(Token = "0x600352F")]
			set
			{
			}
		}

		// Token: 0x06003530 RID: 13616 RVA: 0x0006ADB8 File Offset: 0x00068FB8
		[Address(RVA = "0x33A29D4", Offset = "0x33A29D4", VA = "0x33A29D4")]
		[Token(Token = "0x6003530")]
		private IEnumerator method_44()
		{
			HexaBodyPlayer3.Class52 @class = new HexaBodyPlayer3.Class52((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003532 RID: 13618 RVA: 0x0006AE8C File Offset: 0x0006908C
		[Address(RVA = "0x33A11F0", Offset = "0x33A11F0", VA = "0x33A11F0")]
		[Token(Token = "0x6003532")]
		private void method_45()
		{
			float num = this.float_8;
			Transform transform = this.transform_0;
			this.float_49 = num;
			Vector3 position = transform.position;
			this.rigidbody_1.transform.position.Normalize();
			Transform transform2 = this.rigidbody_1.transform;
			Transform transform3 = this.transform_1;
			Vector3 localPosition = transform3.localPosition;
			Rigidbody rigidbody = this.rigidbody_1;
			Transform transform4 = rigidbody.transform;
		}

		// Token: 0x06003534 RID: 13620 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x33A2A64", Offset = "0x33A2A64", VA = "0x33A2A64")]
		[Token(Token = "0x6003534")]
		private void method_46(Quaternion quaternion_1)
		{
		}

		// Token: 0x06003535 RID: 13621 RVA: 0x0006AEF8 File Offset: 0x000690F8
		[Address(RVA = "0x33A2A78", Offset = "0x33A2A78", VA = "0x33A2A78")]
		[Token(Token = "0x6003535")]
		public void method_47()
		{
			Vector3 localPosition = this.transform_0.localPosition;
		}

		// Token: 0x06003536 RID: 13622 RVA: 0x00067E28 File Offset: 0x00066028
		[Address(RVA = "0x33A2AB0", Offset = "0x33A2AB0", VA = "0x33A2AB0")]
		[Token(Token = "0x6003536")]
		public void method_48(float float_63)
		{
		}

		// Token: 0x06003537 RID: 13623 RVA: 0x0006AF14 File Offset: 0x00069114
		[Address(RVA = "0x33A2B14", Offset = "0x33A2B14", VA = "0x33A2B14", Slot = "5")]
		[Token(Token = "0x6003537")]
		protected virtual void vmethod_1()
		{
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_4)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_7;
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					if (hexaBodyPlayerInputs == null)
					{
						return;
					}
				}
				else if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_4)
					{
						long num = 1L;
						this.bool_7 = (num != 0L);
						return;
					}
					long num2 = 1L;
					this.bool_4 = (num2 != 0L);
				}
			}
			else
			{
				bool flag2 = this.bool_7;
				HexaBodyPlayerInputs hexaBodyPlayerInputs;
				bool flag3 = hexaBodyPlayerInputs.bool_2;
				long num;
				if (flag2)
				{
					if (flag3)
					{
						return;
					}
				}
				else if (num != 0L)
				{
					long num3 = 1L;
					this.bool_7 = (num3 != 0L);
					return;
				}
			}
		}

		// Token: 0x06003538 RID: 13624 RVA: 0x0006AFA8 File Offset: 0x000691A8
		[Address(RVA = "0x33A2C04", Offset = "0x33A2C04", VA = "0x33A2C04")]
		[Token(Token = "0x6003538")]
		private void method_49()
		{
			if (this._legStage != GEnum17.const_0)
			{
				return;
			}
			this.transform_0.forward.Normalize();
			Transform transform = this.rigidbody_1.transform;
			Vector3 center = this.capsuleCollider_3.center;
			Transform transform2 = this.rigidbody_1.transform;
			float deltaTime = Time.deltaTime;
			Transform transform3 = this.rigidbody_1.transform;
			Vector3 center2 = this.capsuleCollider_3.center;
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = this.transform_5.transform.up;
			Transform transform4 = this.transform_5.transform;
			Quaternion rotation = this.transform_5.transform.rotation;
			Rigidbody rigidbody = this.rigidbody_0;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			Vector3 position2 = rigidbody.position;
			float height;
			capsuleCollider.height = height;
			Transform transform5 = capsuleCollider.transform;
			Vector3 position3 = this.rigidbody_0.position;
			Vector3 position4 = this.rigidbody_0.position;
			Vector3 localPosition = this.transform_7.localPosition;
			Transform transform6 = this.rigidbody_1.transform;
			float magnitude = this.capsuleCollider_3.center.magnitude;
			Vector3 position5 = this.transform_1.position;
			Vector3 up2 = this.transform_6.transform.up;
			Transform transform7 = this.transform_6.transform;
			Quaternion rotation2 = this.transform_6.transform.rotation;
			Transform transform8 = this.transform_1;
			CapsuleCollider capsuleCollider2 = this.capsuleCollider_1;
			Vector3 position6 = transform8.position;
			Vector3 position7 = this.transform_7.position;
			float height2;
			capsuleCollider2.height = height2;
			Transform transform9 = this.transform_1;
			Vector3 position8 = transform9.position;
			Transform transform10 = this.transform_6;
			Vector3 position9 = transform10.position;
			Vector3 position10 = this.rigidbody_3.position;
			Vector3 position11 = this.transform_6.position;
			Rigidbody rigidbody2 = this.rigidbody_3;
			CapsuleCollider capsuleCollider3 = this.capsuleCollider_2;
			Vector3 position12 = rigidbody2.position;
			Vector3 position13 = this.transform_6.position;
			float height3;
			capsuleCollider3.height = height3;
			Vector3 position14 = this.rigidbody_3.position;
			Vector3 position15 = this.transform_3.position;
			Vector3 up3 = this.transform_3.up;
			Transform transform11 = this.transform_3.transform;
			Quaternion rotation3 = this.transform_3.transform.rotation;
		}

		// Token: 0x06003539 RID: 13625 RVA: 0x0006B1C4 File Offset: 0x000693C4
		[Address(RVA = "0x33A1E40", Offset = "0x33A1E40", VA = "0x33A1E40")]
		[Token(Token = "0x6003539")]
		private void method_50()
		{
			this.method_53();
			bool flag = this.bool_1;
			this.bool_5 = flag;
			if (flag)
			{
				Transform transform = this.rigidbody_1.transform;
				Vector3 center = this.capsuleCollider_3.center;
				Vector3 localPosition = this.transform_11.localPosition;
				Vector3 localScale = this.transform_10.localScale;
				float height = this.capsuleCollider_1.height;
				float radius = this.capsuleCollider_1.radius;
				Vector3 localScale2 = this.transform_11.localScale;
				float height2 = this.capsuleCollider_0.height;
				float radius2 = this.capsuleCollider_0.radius;
				Vector3 localScale3 = this.transform_12.localScale;
				float height3 = this.capsuleCollider_3.height;
				float radius3 = this.capsuleCollider_3.radius;
				Vector3 localScale4 = this.transform_14.localScale;
				float radius4 = this.sphereCollider_1.radius;
				Vector3 localScale5 = this.transform_13.localScale;
				float radius5 = this.sphereCollider_0.radius;
				return;
			}
		}

		// Token: 0x0600353A RID: 13626 RVA: 0x0006B2AC File Offset: 0x000694AC
		[Address(RVA = "0x33A09D8", Offset = "0x33A09D8", VA = "0x33A09D8")]
		[Token(Token = "0x600353A")]
		private void method_51()
		{
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = Vector3.up;
			float defaultContactOffset = Physics.defaultContactOffset;
			float radius = this.sphereCollider_0.radius;
			float defaultContactOffset2 = Physics.defaultContactOffset;
			Vector3 down = Vector3.down;
			LayerMask mask = this.layerMask_0;
			mask;
			Vector3 up2 = Vector3.up;
			Vector3 up3 = Vector3.up;
		}

		// Token: 0x0600353B RID: 13627 RVA: 0x0006AD3C File Offset: 0x00068F3C
		[Address(RVA = "0x33A0B9C", Offset = "0x33A0B9C", VA = "0x33A0B9C")]
		[Token(Token = "0x600353B")]
		private void method_52()
		{
			if (this.bool_3 && this.bool_8)
			{
				IEnumerator routine = this.method_17();
				base.StartCoroutine(routine);
				return;
			}
		}

		// Token: 0x0600353C RID: 13628 RVA: 0x0006B308 File Offset: 0x00069508
		[Address(RVA = "0x339F300", Offset = "0x339F300", VA = "0x339F300")]
		[Token(Token = "0x600353C")]
		private void method_53()
		{
			GameObject gameObject = this.transform_12.gameObject;
			bool active = this.bool_1;
			gameObject.SetActive(active);
			GameObject gameObject2 = this.transform_11.gameObject;
			bool active2 = this.bool_1;
			gameObject2.SetActive(active2);
			Transform transform = this.transform_10;
			long active3 = 0L;
			transform.gameObject.SetActive(active3 != 0L);
			GameObject gameObject3 = this.transform_13.gameObject;
			bool active4 = this.bool_1;
			gameObject3.SetActive(active4);
			GameObject gameObject4 = this.transform_14.gameObject;
			bool active5 = this.bool_1;
			gameObject4.SetActive(active5);
		}

		// Token: 0x0600353D RID: 13629 RVA: 0x0006B3A0 File Offset: 0x000695A0
		[Address(RVA = "0x33A23BC", Offset = "0x33A23BC", VA = "0x33A23BC")]
		[Token(Token = "0x600353D")]
		private bool method_54()
		{
			float z = this.vector3_0.z;
			Transform transform = this.transform_1;
			this.vector3_1.z = z;
			Vector3 position = transform.transform.position;
			float magnitude = this.rigidbody_1.transform.position.normalized.magnitude;
			Vector3 position2 = this.rigidbody_0.position;
			Vector3 position3 = this.rigidbody_2.position;
			Vector3 position4 = this.rigidbody_3.position;
			Vector3 position5 = this.rigidbody_1.position;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			Vector3 localPosition = this.hexaCameraRig_0.transform.localPosition;
			Transform transform2 = this.rigidbody_1.transform;
			throw new NullReferenceException();
		}

		// Token: 0x0600353E RID: 13630 RVA: 0x0006B454 File Offset: 0x00069654
		[Address(RVA = "0x33A3380", Offset = "0x33A3380", VA = "0x33A3380")]
		[Token(Token = "0x600353E")]
		private void Start()
		{
			HexaBodyPlayerInputs component = base.GetComponent<HexaBodyPlayerInputs>();
			this.hexaBodyPlayerInputs_0 = component;
			float radius = this.sphereCollider_0.radius;
			float radius2 = this.sphereCollider_1.radius;
			this.method_42();
			if (this.bool_2)
			{
				IEnumerator routine = this.method_37();
				base.StartCoroutine(routine);
			}
			this.method_53();
			this.method_32(radius2);
			this.rigidbody_0.maxAngularVelocity = radius2;
		}

		// Token: 0x0600353F RID: 13631 RVA: 0x0006B4C0 File Offset: 0x000696C0
		[Address(RVA = "0x33A3460", Offset = "0x33A3460", VA = "0x33A3460")]
		[Token(Token = "0x600353F")]
		private void method_55(bool bool_10)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x06003540 RID: 13632 RVA: 0x00069730 File Offset: 0x00067930
		[Address(RVA = "0x33A34F8", Offset = "0x33A34F8", VA = "0x33A34F8", Slot = "6")]
		[Token(Token = "0x6003540")]
		public virtual void vmethod_2()
		{
		}

		// Token: 0x06003541 RID: 13633 RVA: 0x0006B4F8 File Offset: 0x000696F8
		[Address(RVA = "0x33A353C", Offset = "0x33A353C", VA = "0x33A353C")]
		[Token(Token = "0x6003541")]
		private Vector2 method_56()
		{
			/*
An exception occurred when decompiling this method (06003541)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyPlayer3::method_56()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(97)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(118)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003542 RID: 13634 RVA: 0x0006B3A0 File Offset: 0x000695A0
		[Address(RVA = "0x33A35E0", Offset = "0x33A35E0", VA = "0x33A35E0")]
		[Token(Token = "0x6003542")]
		private bool method_57()
		{
			float z = this.vector3_0.z;
			Transform transform = this.transform_1;
			this.vector3_1.z = z;
			Vector3 position = transform.transform.position;
			float magnitude = this.rigidbody_1.transform.position.normalized.magnitude;
			Vector3 position2 = this.rigidbody_0.position;
			Vector3 position3 = this.rigidbody_2.position;
			Vector3 position4 = this.rigidbody_3.position;
			Vector3 position5 = this.rigidbody_1.position;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			Vector3 localPosition = this.hexaCameraRig_0.transform.localPosition;
			Transform transform2 = this.rigidbody_1.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003544 RID: 13636 RVA: 0x0006B514 File Offset: 0x00069714
		[Address(RVA = "0x33A3868", Offset = "0x33A3868", VA = "0x33A3868")]
		[Token(Token = "0x6003544")]
		private void method_58(GEnum16 genum16_1)
		{
			this._crouchLevel = genum16_1;
			float float_ = this.method_23(genum16_1);
			this.method_59(float_);
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06003545 RID: 13637 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x170000B3")]
		public float Single_1
		{
			[Address(RVA = "0x33A3894", Offset = "0x33A3894", VA = "0x33A3894")]
			[Token(Token = "0x6003545")]
			get
			{
			}
		}

		// Token: 0x06003546 RID: 13638 RVA: 0x0006AD80 File Offset: 0x00068F80
		[Address(RVA = "0x339EF24", Offset = "0x339EF24", VA = "0x339EF24")]
		[Token(Token = "0x6003546")]
		private void method_59(float float_63)
		{
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_1.position;
			Vector3 localPosition = this.transform_1.localPosition;
			float single_ = this.Single_0;
		}

		// Token: 0x06003547 RID: 13639 RVA: 0x0006AEF8 File Offset: 0x000690F8
		[Address(RVA = "0x33A1E08", Offset = "0x33A1E08", VA = "0x33A1E08")]
		[Token(Token = "0x6003547")]
		public void method_60()
		{
			Vector3 localPosition = this.transform_0.localPosition;
		}

		// Token: 0x06003548 RID: 13640 RVA: 0x0006B538 File Offset: 0x00069738
		[Address(RVA = "0x33A389C", Offset = "0x33A389C", VA = "0x33A389C")]
		[Token(Token = "0x6003548")]
		private void method_61()
		{
			HexaBodyPlayerInputs component = base.GetComponent<HexaBodyPlayerInputs>();
			this.hexaBodyPlayerInputs_0 = component;
			float radius = this.sphereCollider_0.radius;
			float radius2 = this.sphereCollider_1.radius;
			this.method_42();
			if (this.bool_2)
			{
				IEnumerator routine = this.method_24();
				base.StartCoroutine(routine);
			}
			this.method_53();
			this.method_32(radius2);
			this.rigidbody_0.maxAngularVelocity = radius2;
		}

		// Token: 0x0400076E RID: 1902
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400076E")]
		public float float_0;

		// Token: 0x0400076F RID: 1903
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x400076F")]
		public float float_1;

		// Token: 0x04000770 RID: 1904
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000770")]
		public float float_2;

		// Token: 0x04000771 RID: 1905
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000771")]
		public float float_3;

		// Token: 0x04000772 RID: 1906
		[Token(Token = "0x4000772")]
		[FieldOffset(Offset = "0x28")]
		public float float_4;

		// Token: 0x04000773 RID: 1907
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000773")]
		public float float_5;

		// Token: 0x04000774 RID: 1908
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000774")]
		public AnimationCurve animationCurve_0;

		// Token: 0x04000775 RID: 1909
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000775")]
		public AnimationCurve animationCurve_1;

		// Token: 0x04000776 RID: 1910
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000776")]
		public AnimationCurve animationCurve_2;

		// Token: 0x04000777 RID: 1911
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000777")]
		public AnimationCurve animationCurve_3;

		// Token: 0x04000778 RID: 1912
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000778")]
		public float float_6;

		// Token: 0x04000779 RID: 1913
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000779")]
		public PhysicMaterial physicMaterial_0;

		// Token: 0x0400077A RID: 1914
		[Token(Token = "0x400077A")]
		[FieldOffset(Offset = "0x60")]
		public float float_7;

		// Token: 0x0400077B RID: 1915
		[Token(Token = "0x400077B")]
		[FieldOffset(Offset = "0x64")]
		public float float_8;

		// Token: 0x0400077C RID: 1916
		[Token(Token = "0x400077C")]
		[FieldOffset(Offset = "0x68")]
		public float float_9;

		// Token: 0x0400077D RID: 1917
		[Token(Token = "0x400077D")]
		[FieldOffset(Offset = "0x6C")]
		public float float_10;

		// Token: 0x0400077E RID: 1918
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x400077E")]
		public GEnum18 genum18_0;

		// Token: 0x0400077F RID: 1919
		[FieldOffset(Offset = "0x74")]
		[Token(Token = "0x400077F")]
		public float float_11;

		// Token: 0x04000780 RID: 1920
		[Token(Token = "0x4000780")]
		[FieldOffset(Offset = "0x78")]
		public float float_12;

		// Token: 0x04000781 RID: 1921
		[Token(Token = "0x4000781")]
		[FieldOffset(Offset = "0x80")]
		public AnimationCurve animationCurve_4;

		// Token: 0x04000782 RID: 1922
		[Token(Token = "0x4000782")]
		[FieldOffset(Offset = "0x88")]
		public float float_13 = (float)39322;

		// Token: 0x04000783 RID: 1923
		[Token(Token = "0x4000783")]
		[FieldOffset(Offset = "0x8C")]
		public bool bool_0;

		// Token: 0x04000784 RID: 1924
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000784")]
		public float float_14;

		// Token: 0x04000785 RID: 1925
		[FieldOffset(Offset = "0x94")]
		[Token(Token = "0x4000785")]
		public float float_15;

		// Token: 0x04000786 RID: 1926
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x4000786")]
		public float float_16;

		// Token: 0x04000787 RID: 1927
		[Token(Token = "0x4000787")]
		[FieldOffset(Offset = "0x9C")]
		public float float_17;

		// Token: 0x04000788 RID: 1928
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x4000788")]
		public float float_18;

		// Token: 0x04000789 RID: 1929
		[FieldOffset(Offset = "0xA4")]
		[Token(Token = "0x4000789")]
		public float float_19;

		// Token: 0x0400078A RID: 1930
		[FieldOffset(Offset = "0xA8")]
		[Token(Token = "0x400078A")]
		public float float_20;

		// Token: 0x0400078B RID: 1931
		[FieldOffset(Offset = "0xAC")]
		[Token(Token = "0x400078B")]
		public LayerMask layerMask_0;

		// Token: 0x0400078C RID: 1932
		[Token(Token = "0x400078C")]
		[FieldOffset(Offset = "0xB0")]
		public float float_21;

		// Token: 0x0400078D RID: 1933
		[Token(Token = "0x400078D")]
		[FieldOffset(Offset = "0xB4")]
		public float float_22;

		// Token: 0x0400078E RID: 1934
		[Token(Token = "0x400078E")]
		[FieldOffset(Offset = "0xB8")]
		public float float_23;

		// Token: 0x0400078F RID: 1935
		[Token(Token = "0x400078F")]
		[FieldOffset(Offset = "0xBC")]
		public float float_24;

		// Token: 0x04000790 RID: 1936
		[FieldOffset(Offset = "0xC0")]
		[Token(Token = "0x4000790")]
		public AnimationCurve animationCurve_5;

		// Token: 0x04000791 RID: 1937
		[FieldOffset(Offset = "0xC8")]
		[Token(Token = "0x4000791")]
		public float float_25;

		// Token: 0x04000792 RID: 1938
		[Token(Token = "0x4000792")]
		[FieldOffset(Offset = "0xCC")]
		public float float_26;

		// Token: 0x04000793 RID: 1939
		[Token(Token = "0x4000793")]
		[FieldOffset(Offset = "0xD0")]
		public GEnum16 genum16_0;

		// Token: 0x04000794 RID: 1940
		[FieldOffset(Offset = "0xD4")]
		[Token(Token = "0x4000794")]
		public float float_27;

		// Token: 0x04000795 RID: 1941
		[FieldOffset(Offset = "0xD8")]
		[Token(Token = "0x4000795")]
		public float float_28;

		// Token: 0x04000796 RID: 1942
		[Token(Token = "0x4000796")]
		[FieldOffset(Offset = "0xDC")]
		public float float_29;

		// Token: 0x04000797 RID: 1943
		[Token(Token = "0x4000797")]
		[FieldOffset(Offset = "0xE0")]
		public float float_30;

		// Token: 0x04000798 RID: 1944
		[FieldOffset(Offset = "0xE4")]
		[Token(Token = "0x4000798")]
		public float float_31;

		// Token: 0x04000799 RID: 1945
		[Token(Token = "0x4000799")]
		[FieldOffset(Offset = "0xE8")]
		public float float_32;

		// Token: 0x0400079A RID: 1946
		[Token(Token = "0x400079A")]
		[FieldOffset(Offset = "0xEC")]
		public float float_33;

		// Token: 0x0400079B RID: 1947
		[Token(Token = "0x400079B")]
		[FieldOffset(Offset = "0xF0")]
		public HexaCameraRig hexaCameraRig_0;

		// Token: 0x0400079C RID: 1948
		[Token(Token = "0x400079C")]
		[FieldOffset(Offset = "0xF8")]
		public Transform transform_0;

		// Token: 0x0400079D RID: 1949
		[Token(Token = "0x400079D")]
		[FieldOffset(Offset = "0x100")]
		public Transform transform_1;

		// Token: 0x0400079E RID: 1950
		[FieldOffset(Offset = "0x108")]
		[Token(Token = "0x400079E")]
		public Transform transform_2;

		// Token: 0x0400079F RID: 1951
		[Token(Token = "0x400079F")]
		[FieldOffset(Offset = "0x110")]
		public Transform transform_3;

		// Token: 0x040007A0 RID: 1952
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x40007A0")]
		public Transform transform_4;

		// Token: 0x040007A1 RID: 1953
		[Token(Token = "0x40007A1")]
		[FieldOffset(Offset = "0x120")]
		public Transform transform_5;

		// Token: 0x040007A2 RID: 1954
		[FieldOffset(Offset = "0x128")]
		[Token(Token = "0x40007A2")]
		public Transform transform_6;

		// Token: 0x040007A3 RID: 1955
		[Token(Token = "0x40007A3")]
		[FieldOffset(Offset = "0x130")]
		public Transform transform_7;

		// Token: 0x040007A4 RID: 1956
		[FieldOffset(Offset = "0x138")]
		[Token(Token = "0x40007A4")]
		public Transform transform_8;

		// Token: 0x040007A5 RID: 1957
		[FieldOffset(Offset = "0x140")]
		[Token(Token = "0x40007A5")]
		public Transform transform_9;

		// Token: 0x040007A6 RID: 1958
		[FieldOffset(Offset = "0x148")]
		[Token(Token = "0x40007A6")]
		public bool bool_1;

		// Token: 0x040007A7 RID: 1959
		[Token(Token = "0x40007A7")]
		[FieldOffset(Offset = "0x150")]
		public Transform transform_10;

		// Token: 0x040007A8 RID: 1960
		[FieldOffset(Offset = "0x158")]
		[Token(Token = "0x40007A8")]
		public Transform transform_11;

		// Token: 0x040007A9 RID: 1961
		[Token(Token = "0x40007A9")]
		[FieldOffset(Offset = "0x160")]
		public Transform transform_12;

		// Token: 0x040007AA RID: 1962
		[FieldOffset(Offset = "0x168")]
		[Token(Token = "0x40007AA")]
		public Transform transform_13;

		// Token: 0x040007AB RID: 1963
		[FieldOffset(Offset = "0x170")]
		[Token(Token = "0x40007AB")]
		public Transform transform_14;

		// Token: 0x040007AC RID: 1964
		[FieldOffset(Offset = "0x178")]
		[Token(Token = "0x40007AC")]
		public Rigidbody rigidbody_0;

		// Token: 0x040007AD RID: 1965
		[Token(Token = "0x40007AD")]
		[FieldOffset(Offset = "0x180")]
		public Rigidbody rigidbody_1;

		// Token: 0x040007AE RID: 1966
		[FieldOffset(Offset = "0x188")]
		[Token(Token = "0x40007AE")]
		public Rigidbody rigidbody_2;

		// Token: 0x040007AF RID: 1967
		[Token(Token = "0x40007AF")]
		[FieldOffset(Offset = "0x190")]
		public Rigidbody rigidbody_3;

		// Token: 0x040007B0 RID: 1968
		[FieldOffset(Offset = "0x198")]
		[Token(Token = "0x40007B0")]
		public Rigidbody rigidbody_4;

		// Token: 0x040007B1 RID: 1969
		[FieldOffset(Offset = "0x1A0")]
		[Token(Token = "0x40007B1")]
		public Rigidbody rigidbody_5;

		// Token: 0x040007B2 RID: 1970
		[Token(Token = "0x40007B2")]
		[FieldOffset(Offset = "0x1A8")]
		public CapsuleCollider capsuleCollider_0;

		// Token: 0x040007B3 RID: 1971
		[FieldOffset(Offset = "0x1B0")]
		[Token(Token = "0x40007B3")]
		public CapsuleCollider capsuleCollider_1;

		// Token: 0x040007B4 RID: 1972
		[FieldOffset(Offset = "0x1B8")]
		[Token(Token = "0x40007B4")]
		public SphereCollider sphereCollider_0;

		// Token: 0x040007B5 RID: 1973
		[Token(Token = "0x40007B5")]
		[FieldOffset(Offset = "0x1C0")]
		public SphereCollider sphereCollider_1;

		// Token: 0x040007B6 RID: 1974
		[Token(Token = "0x40007B6")]
		[FieldOffset(Offset = "0x1C8")]
		public CapsuleCollider capsuleCollider_2;

		// Token: 0x040007B7 RID: 1975
		[Token(Token = "0x40007B7")]
		[FieldOffset(Offset = "0x1D0")]
		public CapsuleCollider capsuleCollider_3;

		// Token: 0x040007B8 RID: 1976
		[Token(Token = "0x40007B8")]
		[FieldOffset(Offset = "0x1D8")]
		public ConfigurableJoint configurableJoint_0;

		// Token: 0x040007B9 RID: 1977
		[FieldOffset(Offset = "0x1E0")]
		[Token(Token = "0x40007B9")]
		public ConfigurableJoint configurableJoint_1;

		// Token: 0x040007BA RID: 1978
		[Token(Token = "0x40007BA")]
		[FieldOffset(Offset = "0x1E8")]
		public ConfigurableJoint configurableJoint_2;

		// Token: 0x040007BB RID: 1979
		[Token(Token = "0x40007BB")]
		[FieldOffset(Offset = "0x1F0")]
		public Transform transform_15;

		// Token: 0x040007BC RID: 1980
		[Token(Token = "0x40007BC")]
		[FieldOffset(Offset = "0x1F8")]
		public Transform transform_16;

		// Token: 0x040007BD RID: 1981
		[Token(Token = "0x40007BD")]
		[FieldOffset(Offset = "0x200")]
		public bool bool_2;

		// Token: 0x040007BE RID: 1982
		[FieldOffset(Offset = "0x204")]
		[Space]
		[Token(Token = "0x40007BE")]
		public float float_34;

		// Token: 0x040007BF RID: 1983
		[Token(Token = "0x40007BF")]
		[FieldOffset(Offset = "0x208")]
		public float float_35;

		// Token: 0x040007C0 RID: 1984
		[FieldOffset(Offset = "0x20C")]
		[Token(Token = "0x40007C0")]
		public float float_36;

		// Token: 0x040007C1 RID: 1985
		[Token(Token = "0x40007C1")]
		[FieldOffset(Offset = "0x210")]
		public float float_37;

		// Token: 0x040007C2 RID: 1986
		[FieldOffset(Offset = "0x214")]
		[Token(Token = "0x40007C2")]
		public float float_38;

		// Token: 0x040007C3 RID: 1987
		[Token(Token = "0x40007C3")]
		[FieldOffset(Offset = "0x218")]
		public float float_39;

		// Token: 0x040007C4 RID: 1988
		[FieldOffset(Offset = "0x21C")]
		[Token(Token = "0x40007C4")]
		public float float_40;

		// Token: 0x040007C5 RID: 1989
		[FieldOffset(Offset = "0x220")]
		[Token(Token = "0x40007C5")]
		public float float_41;

		// Token: 0x040007C6 RID: 1990
		[FieldOffset(Offset = "0x224")]
		[Token(Token = "0x40007C6")]
		public float float_42;

		// Token: 0x040007C7 RID: 1991
		[FieldOffset(Offset = "0x228")]
		[Token(Token = "0x40007C7")]
		public float float_43;

		// Token: 0x040007C8 RID: 1992
		[FieldOffset(Offset = "0x22C")]
		[Token(Token = "0x40007C8")]
		public float float_44;

		// Token: 0x040007C9 RID: 1993
		[FieldOffset(Offset = "0x230")]
		[Token(Token = "0x40007C9")]
		public float float_45;

		// Token: 0x040007CA RID: 1994
		[Token(Token = "0x40007CA")]
		[FieldOffset(Offset = "0x234")]
		public float float_46;

		// Token: 0x040007CB RID: 1995
		[Token(Token = "0x40007CB")]
		[FieldOffset(Offset = "0x238")]
		public float float_47;

		// Token: 0x040007CC RID: 1996
		[Token(Token = "0x40007CC")]
		[FieldOffset(Offset = "0x23C")]
		public float float_48;

		// Token: 0x040007CD RID: 1997
		[FieldOffset(Offset = "0x240")]
		[Token(Token = "0x40007CD")]
		public float float_49;

		// Token: 0x040007CE RID: 1998
		[FieldOffset(Offset = "0x244")]
		[Token(Token = "0x40007CE")]
		public float float_50;

		// Token: 0x040007CF RID: 1999
		[Token(Token = "0x40007CF")]
		[FieldOffset(Offset = "0x248")]
		public Vector3 vector3_0;

		// Token: 0x040007D0 RID: 2000
		[Token(Token = "0x40007D0")]
		[FieldOffset(Offset = "0x254")]
		public Vector3 vector3_1;

		// Token: 0x040007D1 RID: 2001
		[FieldOffset(Offset = "0x260")]
		[Header("Misc")]
		[SerializeField]
		[Token(Token = "0x40007D1")]
		private float _jumpForce;

		// Token: 0x040007D2 RID: 2002
		[SerializeField]
		[Token(Token = "0x40007D2")]
		[FieldOffset(Offset = "0x264")]
		private float _groundAngle;

		// Token: 0x040007D3 RID: 2003
		[SerializeField]
		[FieldOffset(Offset = "0x268")]
		[Token(Token = "0x40007D3")]
		private GEnum16 _crouchLevel;

		// Token: 0x040007D4 RID: 2004
		[SerializeField]
		[Token(Token = "0x40007D4")]
		[FieldOffset(Offset = "0x26C")]
		private float _jumpTime;

		// Token: 0x040007D5 RID: 2005
		[FieldOffset(Offset = "0x270")]
		[Token(Token = "0x40007D5")]
		[SerializeField]
		private GEnum17 _legStage;

		// Token: 0x040007D6 RID: 2006
		[FieldOffset(Offset = "0x274")]
		[Token(Token = "0x40007D6")]
		[SerializeField]
		private float _actualSpeed;

		// Token: 0x040007D7 RID: 2007
		[Token(Token = "0x40007D7")]
		[SerializeField]
		[FieldOffset(Offset = "0x278")]
		private float _standingPercent;

		// Token: 0x040007D8 RID: 2008
		[FieldOffset(Offset = "0x27C")]
		[Token(Token = "0x40007D8")]
		[Header("Velocities")]
		[SerializeField]
		private float _verticalSpeed;

		// Token: 0x040007D9 RID: 2009
		[FieldOffset(Offset = "0x280")]
		[SerializeField]
		[Token(Token = "0x40007D9")]
		private float _locoAngularVelocity;

		// Token: 0x040007DA RID: 2010
		[Token(Token = "0x40007DA")]
		[FieldOffset(Offset = "0x284")]
		[SerializeField]
		private float _targetAngularVelocity;

		// Token: 0x040007DB RID: 2011
		[SerializeField]
		[Token(Token = "0x40007DB")]
		[FieldOffset(Offset = "0x288")]
		private float _modifiedTargetSpeed;

		// Token: 0x040007DC RID: 2012
		[Token(Token = "0x40007DC")]
		[SerializeField]
		[FieldOffset(Offset = "0x28C")]
		private float _modifiedTargetAcceleration;

		// Token: 0x040007DD RID: 2013
		[Token(Token = "0x40007DD")]
		[FieldOffset(Offset = "0x290")]
		private float float_51;

		// Token: 0x040007DE RID: 2014
		[FieldOffset(Offset = "0x294")]
		[Token(Token = "0x40007DE")]
		private float float_52;

		// Token: 0x040007DF RID: 2015
		[Token(Token = "0x40007DF")]
		[FieldOffset(Offset = "0x298")]
		private float float_53;

		// Token: 0x040007E0 RID: 2016
		[Token(Token = "0x40007E0")]
		[FieldOffset(Offset = "0x29C")]
		private float float_54;

		// Token: 0x040007E1 RID: 2017
		[FieldOffset(Offset = "0x2A0")]
		[Token(Token = "0x40007E1")]
		private float float_55;

		// Token: 0x040007E2 RID: 2018
		[FieldOffset(Offset = "0x2A4")]
		[Token(Token = "0x40007E2")]
		private float float_56;

		// Token: 0x040007E3 RID: 2019
		[FieldOffset(Offset = "0x2A8")]
		[Token(Token = "0x40007E3")]
		private bool bool_3;

		// Token: 0x040007E4 RID: 2020
		[FieldOffset(Offset = "0x2AC")]
		[Token(Token = "0x40007E4")]
		private float float_57;

		// Token: 0x040007E5 RID: 2021
		[FieldOffset(Offset = "0x2B0")]
		[Token(Token = "0x40007E5")]
		private float float_58;

		// Token: 0x040007E6 RID: 2022
		[Token(Token = "0x40007E6")]
		[FieldOffset(Offset = "0x2B4")]
		private float float_59;

		// Token: 0x040007E7 RID: 2023
		[Token(Token = "0x40007E7")]
		[FieldOffset(Offset = "0x2B8")]
		private bool bool_4;

		// Token: 0x040007E8 RID: 2024
		[Token(Token = "0x40007E8")]
		[FieldOffset(Offset = "0x2BC")]
		private Vector3 vector3_2;

		// Token: 0x040007E9 RID: 2025
		[Token(Token = "0x40007E9")]
		[FieldOffset(Offset = "0x2C8")]
		private Vector3 vector3_3;

		// Token: 0x040007EA RID: 2026
		[Token(Token = "0x40007EA")]
		[FieldOffset(Offset = "0x2D4")]
		private Vector3 vector3_4;

		// Token: 0x040007EB RID: 2027
		[Token(Token = "0x40007EB")]
		[FieldOffset(Offset = "0x2E0")]
		private bool bool_5;

		// Token: 0x040007EC RID: 2028
		[Token(Token = "0x40007EC")]
		[FieldOffset(Offset = "0x2E4")]
		private float float_60;

		// Token: 0x040007ED RID: 2029
		[FieldOffset(Offset = "0x2E8")]
		[Token(Token = "0x40007ED")]
		private PhysicMaterial physicMaterial_1;

		// Token: 0x040007EE RID: 2030
		[FieldOffset(Offset = "0x2F0")]
		[Token(Token = "0x40007EE")]
		private bool bool_6;

		// Token: 0x040007EF RID: 2031
		[Token(Token = "0x40007EF")]
		[FieldOffset(Offset = "0x2F8")]
		private ConfigurableJoint configurableJoint_3;

		// Token: 0x040007F0 RID: 2032
		[Token(Token = "0x40007F0")]
		[FieldOffset(Offset = "0x300")]
		private ConfigurableJoint configurableJoint_4;

		// Token: 0x040007F1 RID: 2033
		[Token(Token = "0x40007F1")]
		[FieldOffset(Offset = "0x308")]
		private Vector3 vector3_5;

		// Token: 0x040007F2 RID: 2034
		[CompilerGenerated]
		[FieldOffset(Offset = "0x314")]
		[Token(Token = "0x40007F2")]
		private bool bool_7;

		// Token: 0x040007F3 RID: 2035
		[Token(Token = "0x40007F3")]
		[CompilerGenerated]
		[FieldOffset(Offset = "0x318")]
		private Quaternion quaternion_0;

		// Token: 0x040007F4 RID: 2036
		[FieldOffset(Offset = "0x328")]
		[Token(Token = "0x40007F4")]
		[CompilerGenerated]
		private HexaBodyPlayerInputs hexaBodyPlayerInputs_0;

		// Token: 0x040007F5 RID: 2037
		[CompilerGenerated]
		[Token(Token = "0x40007F5")]
		[FieldOffset(Offset = "0x330")]
		private Vector3 vector3_6;

		// Token: 0x040007F6 RID: 2038
		[Token(Token = "0x40007F6")]
		[FieldOffset(Offset = "0x33C")]
		[CompilerGenerated]
		private Vector3 vector3_7;

		// Token: 0x040007F7 RID: 2039
		[CompilerGenerated]
		[Token(Token = "0x40007F7")]
		[FieldOffset(Offset = "0x348")]
		private bool bool_8;

		// Token: 0x040007F8 RID: 2040
		[Token(Token = "0x40007F8")]
		[FieldOffset(Offset = "0x34C")]
		public float float_61;

		// Token: 0x040007F9 RID: 2041
		[Token(Token = "0x40007F9")]
		[FieldOffset(Offset = "0x350")]
		private float float_62;

		// Token: 0x040007FA RID: 2042
		[Token(Token = "0x40007FA")]
		[FieldOffset(Offset = "0x354")]
		private bool bool_9;
	}
}
