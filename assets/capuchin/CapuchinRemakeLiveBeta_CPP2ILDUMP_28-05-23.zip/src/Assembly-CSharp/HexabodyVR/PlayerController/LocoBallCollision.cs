﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000157 RID: 343
	[Token(Token = "0x2000157")]
	public class LocoBallCollision : MonoBehaviour
	{
		// Token: 0x0600367A RID: 13946 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D99C80", Offset = "0x2D99C80", VA = "0x2D99C80", Slot = "4")]
		[Token(Token = "0x600367A")]
		protected virtual void vmethod_0()
		{
		}

		// Token: 0x0600367B RID: 13947 RVA: 0x0006F7D0 File Offset: 0x0006D9D0
		[Address(RVA = "0x2D99DAC", Offset = "0x2D99DAC", VA = "0x2D99DAC", Slot = "5")]
		[Token(Token = "0x600367B")]
		protected virtual void vmethod_1()
		{
		}

		// Token: 0x0600367C RID: 13948 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D99ED8", Offset = "0x2D99ED8", VA = "0x2D99ED8")]
		[Token(Token = "0x600367C")]
		public CollisionDetector method_0()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x0600367D RID: 13949 RVA: 0x0006F7E0 File Offset: 0x0006D9E0
		[Address(RVA = "0x2D99EE0", Offset = "0x2D99EE0", VA = "0x2D99EE0")]
		[Token(Token = "0x600367D")]
		public LocoBallCollision()
		{
			Class42<float> @class;
			this.class42_0 = @class;
			base..ctor();
		}

		// Token: 0x0600367E RID: 13950 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D99F70", Offset = "0x2D99F70", VA = "0x2D99F70", Slot = "6")]
		[Token(Token = "0x600367E")]
		protected virtual void vmethod_2()
		{
		}

		// Token: 0x0600367F RID: 13951 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9A094", Offset = "0x2D9A094", VA = "0x2D9A094")]
		[Token(Token = "0x600367F")]
		public CollisionDetector method_1()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x06003680 RID: 13952 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9A09C", Offset = "0x2D9A09C", VA = "0x2D9A09C")]
		[Token(Token = "0x6003680")]
		private void method_2(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x06003681 RID: 13953 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9A1EC", Offset = "0x2D9A1EC", VA = "0x2D9A1EC")]
		[Token(Token = "0x6003681")]
		public CollisionDetector method_3()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x06003682 RID: 13954 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9A1F4", Offset = "0x2D9A1F4", VA = "0x2D9A1F4", Slot = "7")]
		[Token(Token = "0x6003682")]
		protected virtual void Awake()
		{
		}

		// Token: 0x06003683 RID: 13955 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9A30C", Offset = "0x2D9A30C", VA = "0x2D9A30C")]
		[Token(Token = "0x6003683")]
		public CollisionDetector method_4()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x06003684 RID: 13956 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x6003684")]
		[Address(RVA = "0x2D9A314", Offset = "0x2D9A314", VA = "0x2D9A314")]
		private void method_5()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x06003685 RID: 13957 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x6003685")]
		[Address(RVA = "0x2D9A518", Offset = "0x2D9A518", VA = "0x2D9A518")]
		private void method_6()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x06003686 RID: 13958 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9A5EC", Offset = "0x2D9A5EC", VA = "0x2D9A5EC")]
		[Token(Token = "0x6003686")]
		public CollisionDetector method_7()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x06003687 RID: 13959 RVA: 0x0006F848 File Offset: 0x0006DA48
		[Token(Token = "0x6003687")]
		[Address(RVA = "0x2D9A5F4", Offset = "0x2D9A5F4", VA = "0x2D9A5F4")]
		private void method_8()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x06003688 RID: 13960 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2D9A7F8", Offset = "0x2D9A7F8", VA = "0x2D9A7F8")]
		[Token(Token = "0x6003688")]
		public CollisionDetector method_9()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003689 RID: 13961 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Address(RVA = "0x2D9A800", Offset = "0x2D9A800", VA = "0x2D9A800")]
		[Token(Token = "0x6003689")]
		private void method_10(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x0600368A RID: 13962 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x600368A")]
		[Address(RVA = "0x2D9A930", Offset = "0x2D9A930", VA = "0x2D9A930", Slot = "8")]
		protected virtual void vmethod_3()
		{
		}

		// Token: 0x0600368B RID: 13963 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9AA54", Offset = "0x2D9AA54", VA = "0x2D9AA54")]
		[Token(Token = "0x600368B")]
		public CollisionDetector method_11()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x0600368C RID: 13964 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x600368C")]
		[Address(RVA = "0x2D9AA5C", Offset = "0x2D9AA5C", VA = "0x2D9AA5C")]
		private void method_12()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x0600368D RID: 13965 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Token(Token = "0x600368D")]
		[Address(RVA = "0x2D9AC64", Offset = "0x2D9AC64", VA = "0x2D9AC64")]
		private void method_13(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x0600368E RID: 13966 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Token(Token = "0x600368E")]
		[Address(RVA = "0x2D9AD94", Offset = "0x2D9AD94", VA = "0x2D9AD94")]
		private void method_14(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x0600368F RID: 13967 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Token(Token = "0x600368F")]
		[Address(RVA = "0x2D9AEE8", Offset = "0x2D9AEE8", VA = "0x2D9AEE8")]
		private void method_15(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x06003690 RID: 13968 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Address(RVA = "0x2D9B038", Offset = "0x2D9B038", VA = "0x2D9B038")]
		[Token(Token = "0x6003690")]
		private void method_16()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x06003691 RID: 13969 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Token(Token = "0x6003691")]
		[Address(RVA = "0x2D9B260", Offset = "0x2D9B260", VA = "0x2D9B260")]
		private void method_17(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x06003692 RID: 13970 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x6003692")]
		[Address(RVA = "0x2D9B3B4", Offset = "0x2D9B3B4", VA = "0x2D9B3B4", Slot = "9")]
		protected virtual void vmethod_4()
		{
		}

		// Token: 0x06003693 RID: 13971 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Token(Token = "0x6003693")]
		[Address(RVA = "0x2D9B4D8", Offset = "0x2D9B4D8", VA = "0x2D9B4D8")]
		private void method_18(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x06003694 RID: 13972 RVA: 0x0006F888 File Offset: 0x0006DA88
		[Token(Token = "0x6003694")]
		[Address(RVA = "0x2D9B628", Offset = "0x2D9B628", VA = "0x2D9B628", Slot = "10")]
		protected virtual void vmethod_5()
		{
		}

		// Token: 0x06003695 RID: 13973 RVA: 0x0006F898 File Offset: 0x0006DA98
		[Address(RVA = "0x2D9B754", Offset = "0x2D9B754", VA = "0x2D9B754")]
		[Token(Token = "0x6003695")]
		private void method_19()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x06003696 RID: 13974 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9B978", Offset = "0x2D9B978", VA = "0x2D9B978", Slot = "11")]
		[Token(Token = "0x6003696")]
		protected virtual void vmethod_6()
		{
		}

		// Token: 0x06003697 RID: 13975 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9BAA4", Offset = "0x2D9BAA4", VA = "0x2D9BAA4")]
		[Token(Token = "0x6003697")]
		private void method_20(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x06003698 RID: 13976 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9BBF8", Offset = "0x2D9BBF8", VA = "0x2D9BBF8", Slot = "12")]
		[Token(Token = "0x6003698")]
		protected virtual void vmethod_7()
		{
		}

		// Token: 0x06003699 RID: 13977 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9BD1C", Offset = "0x2D9BD1C", VA = "0x2D9BD1C", Slot = "13")]
		[Token(Token = "0x6003699")]
		protected virtual void vmethod_8()
		{
		}

		// Token: 0x0600369A RID: 13978 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600369A")]
		[Address(RVA = "0x2D9BE40", Offset = "0x2D9BE40", VA = "0x2D9BE40", Slot = "14")]
		protected virtual void vmethod_9()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600369B RID: 13979 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x600369B")]
		[Address(RVA = "0x2D9BF64", Offset = "0x2D9BF64", VA = "0x2D9BF64")]
		private void method_21()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x0600369C RID: 13980 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x600369C")]
		[Address(RVA = "0x2D9C038", Offset = "0x2D9C038", VA = "0x2D9C038", Slot = "15")]
		protected virtual void vmethod_10()
		{
		}

		// Token: 0x0600369D RID: 13981 RVA: 0x0006F8B4 File Offset: 0x0006DAB4
		[Token(Token = "0x600369D")]
		[Address(RVA = "0x2D9C15C", Offset = "0x2D9C15C", VA = "0x2D9C15C")]
		private void FixedUpdate()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x0600369E RID: 13982 RVA: 0x0006F7D0 File Offset: 0x0006D9D0
		[Token(Token = "0x600369E")]
		[Address(RVA = "0x2D9C378", Offset = "0x2D9C378", VA = "0x2D9C378", Slot = "16")]
		protected virtual void vmethod_11()
		{
		}

		// Token: 0x0600369F RID: 13983 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Address(RVA = "0x2D9C4A4", Offset = "0x2D9C4A4", VA = "0x2D9C4A4")]
		[Token(Token = "0x600369F")]
		private void method_22()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036A0 RID: 13984 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Address(RVA = "0x2D9A3E8", Offset = "0x2D9A3E8", VA = "0x2D9A3E8")]
		[Token(Token = "0x60036A0")]
		private void method_23(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036A1 RID: 13985 RVA: 0x000034C0 File Offset: 0x000016C0
		[Token(Token = "0x60036A1")]
		[Address(RVA = "0x2D9C578", Offset = "0x2D9C578", VA = "0x2D9C578")]
		public CollisionDetector method_24()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036A2 RID: 13986 RVA: 0x0006F7D0 File Offset: 0x0006D9D0
		[Token(Token = "0x60036A2")]
		[Address(RVA = "0x2D9C580", Offset = "0x2D9C580", VA = "0x2D9C580", Slot = "17")]
		protected virtual void vmethod_12()
		{
		}

		// Token: 0x060036A3 RID: 13987 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9C6AC", Offset = "0x2D9C6AC", VA = "0x2D9C6AC")]
		[Token(Token = "0x60036A3")]
		public CollisionDetector method_25()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036A4 RID: 13988 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x60036A4")]
		[Address(RVA = "0x2D9C6B4", Offset = "0x2D9C6B4", VA = "0x2D9C6B4")]
		private void method_26()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036A5 RID: 13989 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9C8D8", Offset = "0x2D9C8D8", VA = "0x2D9C8D8")]
		[Token(Token = "0x60036A5")]
		public CollisionDetector method_27()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036A6 RID: 13990 RVA: 0x0006F8D0 File Offset: 0x0006DAD0
		[Token(Token = "0x60036A6")]
		[Address(RVA = "0x2D9C8E0", Offset = "0x2D9C8E0", VA = "0x2D9C8E0")]
		private void method_28()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036A7 RID: 13991 RVA: 0x000034C0 File Offset: 0x000016C0
		[Token(Token = "0x60036A7")]
		[Address(RVA = "0x2D9C9B4", Offset = "0x2D9C9B4", VA = "0x2D9C9B4")]
		public CollisionDetector method_29()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036A8 RID: 13992 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9B828", Offset = "0x2D9B828", VA = "0x2D9B828")]
		[Token(Token = "0x60036A8")]
		private void method_30(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036A9 RID: 13993 RVA: 0x000034C0 File Offset: 0x000016C0
		[Token(Token = "0x60036A9")]
		[Address(RVA = "0x2D9C9BC", Offset = "0x2D9C9BC", VA = "0x2D9C9BC")]
		public CollisionDetector method_31()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036AA RID: 13994 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x60036AA")]
		[Address(RVA = "0x2D9C9C4", Offset = "0x2D9C9C4", VA = "0x2D9C9C4", Slot = "18")]
		protected virtual void vmethod_13()
		{
		}

		// Token: 0x060036AB RID: 13995 RVA: 0x000034C0 File Offset: 0x000016C0
		[Token(Token = "0x60036AB")]
		[Address(RVA = "0x2D9CAF0", Offset = "0x2D9CAF0", VA = "0x2D9CAF0")]
		public CollisionDetector method_32()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036AC RID: 13996 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9CAF8", Offset = "0x2D9CAF8", VA = "0x2D9CAF8", Slot = "19")]
		[Token(Token = "0x60036AC")]
		protected virtual void vmethod_14()
		{
		}

		// Token: 0x060036AD RID: 13997 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Address(RVA = "0x2D9CC1C", Offset = "0x2D9CC1C", VA = "0x2D9CC1C")]
		[Token(Token = "0x60036AD")]
		private void method_33()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036AE RID: 13998 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Address(RVA = "0x2D9CCF0", Offset = "0x2D9CCF0", VA = "0x2D9CCF0")]
		[Token(Token = "0x60036AE")]
		private void method_34(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036AF RID: 13999 RVA: 0x0006F8EC File Offset: 0x0006DAEC
		[Address(RVA = "0x2D9CE20", Offset = "0x2D9CE20", VA = "0x2D9CE20", Slot = "20")]
		[Token(Token = "0x60036AF")]
		protected virtual void vmethod_15()
		{
		}

		// Token: 0x060036B0 RID: 14000 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Address(RVA = "0x2D9CF4C", Offset = "0x2D9CF4C", VA = "0x2D9CF4C")]
		[Token(Token = "0x60036B0")]
		private void method_35(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036B1 RID: 14001 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9C22C", Offset = "0x2D9C22C", VA = "0x2D9C22C")]
		[Token(Token = "0x60036B1")]
		private void method_36(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036B2 RID: 14002 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9D080", Offset = "0x2D9D080", VA = "0x2D9D080")]
		[Token(Token = "0x60036B2")]
		public CollisionDetector method_37()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036B3 RID: 14003 RVA: 0x0006F7D0 File Offset: 0x0006D9D0
		[Address(RVA = "0x2D9D088", Offset = "0x2D9D088", VA = "0x2D9D088", Slot = "21")]
		[Token(Token = "0x60036B3")]
		protected virtual void vmethod_16()
		{
		}

		// Token: 0x060036B4 RID: 14004 RVA: 0x0006F8FC File Offset: 0x0006DAFC
		[Address(RVA = "0x2D9D1B4", Offset = "0x2D9D1B4", VA = "0x2D9D1B4")]
		[Token(Token = "0x60036B4")]
		private void method_38()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036B5 RID: 14005 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Address(RVA = "0x2D9D288", Offset = "0x2D9D288", VA = "0x2D9D288")]
		[Token(Token = "0x60036B5")]
		private void method_39()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036B6 RID: 14006 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9D35C", Offset = "0x2D9D35C", VA = "0x2D9D35C")]
		[Token(Token = "0x60036B6")]
		public CollisionDetector method_40()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036B7 RID: 14007 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9D364", Offset = "0x2D9D364", VA = "0x2D9D364")]
		[Token(Token = "0x60036B7")]
		public CollisionDetector method_41()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036B8 RID: 14008 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9D36C", Offset = "0x2D9D36C", VA = "0x2D9D36C")]
		[Token(Token = "0x60036B8")]
		public CollisionDetector method_42()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036B9 RID: 14009 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9D374", Offset = "0x2D9D374", VA = "0x2D9D374", Slot = "22")]
		[Token(Token = "0x60036B9")]
		protected virtual void vmethod_17()
		{
		}

		// Token: 0x060036BA RID: 14010 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x60036BA")]
		[Address(RVA = "0x2D9D4A0", Offset = "0x2D9D4A0", VA = "0x2D9D4A0", Slot = "23")]
		protected virtual void vmethod_18()
		{
		}

		// Token: 0x060036BB RID: 14011 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9D5CC", Offset = "0x2D9D5CC", VA = "0x2D9D5CC", Slot = "24")]
		[Token(Token = "0x60036BB")]
		protected virtual void vmethod_19()
		{
		}

		// Token: 0x060036BC RID: 14012 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Address(RVA = "0x2D9D6F0", Offset = "0x2D9D6F0", VA = "0x2D9D6F0")]
		[Token(Token = "0x60036BC")]
		private void method_43()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036BD RID: 14013 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9D7C4", Offset = "0x2D9D7C4", VA = "0x2D9D7C4")]
		[Token(Token = "0x60036BD")]
		public CollisionDetector method_44()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036BE RID: 14014 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9D7CC", Offset = "0x2D9D7CC", VA = "0x2D9D7CC", Slot = "25")]
		[Token(Token = "0x60036BE")]
		protected virtual void vmethod_20()
		{
		}

		// Token: 0x060036BF RID: 14015 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x60036BF")]
		[Address(RVA = "0x2D9D8F0", Offset = "0x2D9D8F0", VA = "0x2D9D8F0", Slot = "26")]
		protected virtual void vmethod_21()
		{
		}

		// Token: 0x060036C0 RID: 14016 RVA: 0x000034C0 File Offset: 0x000016C0
		[Token(Token = "0x60036C0")]
		[Address(RVA = "0x2D9DA14", Offset = "0x2D9DA14", VA = "0x2D9DA14")]
		public CollisionDetector method_45()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036C1 RID: 14017 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Address(RVA = "0x2D9A6C8", Offset = "0x2D9A6C8", VA = "0x2D9A6C8")]
		[Token(Token = "0x60036C1")]
		private void method_46(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036C2 RID: 14018 RVA: 0x000034C0 File Offset: 0x000016C0
		[Token(Token = "0x60036C2")]
		[Address(RVA = "0x2D9DA1C", Offset = "0x2D9DA1C", VA = "0x2D9DA1C")]
		public CollisionDetector method_47()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036C3 RID: 14019 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9DA24", Offset = "0x2D9DA24", VA = "0x2D9DA24", Slot = "27")]
		[Token(Token = "0x60036C3")]
		protected virtual void vmethod_22()
		{
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060036C4 RID: 14020 RVA: 0x000034C0 File Offset: 0x000016C0
		[Token(Token = "0x170000D9")]
		public CollisionDetector CollisionDetector_0
		{
			[Address(RVA = "0x2D9DB48", Offset = "0x2D9DB48", VA = "0x2D9DB48")]
			[Token(Token = "0x60036C4")]
			get
			{
				return this.collisionDetector_0;
			}
		}

		// Token: 0x060036C5 RID: 14021 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9DB50", Offset = "0x2D9DB50", VA = "0x2D9DB50", Slot = "28")]
		[Token(Token = "0x60036C5")]
		protected virtual void vmethod_23()
		{
		}

		// Token: 0x060036C6 RID: 14022 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Token(Token = "0x60036C6")]
		[Address(RVA = "0x2D9DC7C", Offset = "0x2D9DC7C", VA = "0x2D9DC7C")]
		private void method_48(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036C7 RID: 14023 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Token(Token = "0x60036C7")]
		[Address(RVA = "0x2D9B10C", Offset = "0x2D9B10C", VA = "0x2D9B10C")]
		private void method_49(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036C8 RID: 14024 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x60036C8")]
		[Address(RVA = "0x2D9DDB0", Offset = "0x2D9DDB0", VA = "0x2D9DDB0")]
		private void method_50()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036C9 RID: 14025 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x60036C9")]
		[Address(RVA = "0x2D9DE84", Offset = "0x2D9DE84", VA = "0x2D9DE84", Slot = "29")]
		protected virtual void vmethod_24()
		{
		}

		// Token: 0x060036CA RID: 14026 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x60036CA")]
		[Address(RVA = "0x2D9DFA8", Offset = "0x2D9DFA8", VA = "0x2D9DFA8", Slot = "30")]
		protected virtual void vmethod_25()
		{
		}

		// Token: 0x060036CB RID: 14027 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Address(RVA = "0x2D9E0CC", Offset = "0x2D9E0CC", VA = "0x2D9E0CC")]
		[Token(Token = "0x60036CB")]
		private void method_51(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036CC RID: 14028 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9E200", Offset = "0x2D9E200", VA = "0x2D9E200", Slot = "31")]
		[Token(Token = "0x60036CC")]
		protected virtual void vmethod_26()
		{
		}

		// Token: 0x060036CD RID: 14029 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9E324", Offset = "0x2D9E324", VA = "0x2D9E324", Slot = "32")]
		[Token(Token = "0x60036CD")]
		protected virtual void vmethod_27()
		{
		}

		// Token: 0x060036CE RID: 14030 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9E450", Offset = "0x2D9E450", VA = "0x2D9E450")]
		[Token(Token = "0x60036CE")]
		private void method_52(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036CF RID: 14031 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9E5A0", Offset = "0x2D9E5A0", VA = "0x2D9E5A0")]
		[Token(Token = "0x60036CF")]
		public CollisionDetector method_53()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036D0 RID: 14032 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x60036D0")]
		[Address(RVA = "0x2D9E5A8", Offset = "0x2D9E5A8", VA = "0x2D9E5A8", Slot = "33")]
		protected virtual void vmethod_28()
		{
		}

		// Token: 0x060036D1 RID: 14033 RVA: 0x0006F7D0 File Offset: 0x0006D9D0
		[Address(RVA = "0x2D9E6CC", Offset = "0x2D9E6CC", VA = "0x2D9E6CC", Slot = "34")]
		[Token(Token = "0x60036D1")]
		protected virtual void vmethod_29()
		{
		}

		// Token: 0x060036D2 RID: 14034 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x60036D2")]
		[Address(RVA = "0x2D9E7F8", Offset = "0x2D9E7F8", VA = "0x2D9E7F8")]
		private void method_54()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036D3 RID: 14035 RVA: 0x0006F848 File Offset: 0x0006DA48
		[Token(Token = "0x60036D3")]
		[Address(RVA = "0x2D9E8CC", Offset = "0x2D9E8CC", VA = "0x2D9E8CC")]
		private void method_55()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036D4 RID: 14036 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Address(RVA = "0x2D9EAD4", Offset = "0x2D9EAD4", VA = "0x2D9EAD4", Slot = "35")]
		[Token(Token = "0x60036D4")]
		protected virtual void vmethod_30()
		{
		}

		// Token: 0x060036D5 RID: 14037 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9EC00", Offset = "0x2D9EC00", VA = "0x2D9EC00")]
		[Token(Token = "0x60036D5")]
		private void method_56(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036D6 RID: 14038 RVA: 0x000034C0 File Offset: 0x000016C0
		[Address(RVA = "0x2D9ED54", Offset = "0x2D9ED54", VA = "0x2D9ED54")]
		[Token(Token = "0x60036D6")]
		public CollisionDetector method_57()
		{
			return this.collisionDetector_0;
		}

		// Token: 0x060036D7 RID: 14039 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x60036D7")]
		[Address(RVA = "0x2D9ED5C", Offset = "0x2D9ED5C", VA = "0x2D9ED5C")]
		private void method_58()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036D8 RID: 14040 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Token(Token = "0x60036D8")]
		[Address(RVA = "0x2D9EE30", Offset = "0x2D9EE30", VA = "0x2D9EE30")]
		private void method_59(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036D9 RID: 14041 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2D9EF80", Offset = "0x2D9EF80", VA = "0x2D9EF80", Slot = "36")]
		[Token(Token = "0x60036D9")]
		protected virtual void vmethod_31()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060036DA RID: 14042 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Token(Token = "0x60036DA")]
		[Address(RVA = "0x2D9F0AC", Offset = "0x2D9F0AC", VA = "0x2D9F0AC")]
		private void method_60()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036DB RID: 14043 RVA: 0x0006F7C0 File Offset: 0x0006D9C0
		[Token(Token = "0x60036DB")]
		[Address(RVA = "0x2D9F180", Offset = "0x2D9F180", VA = "0x2D9F180", Slot = "37")]
		protected virtual void vmethod_32()
		{
		}

		// Token: 0x060036DC RID: 14044 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9C788", Offset = "0x2D9C788", VA = "0x2D9C788")]
		[Token(Token = "0x60036DC")]
		private void method_61(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036DD RID: 14045 RVA: 0x0006F82C File Offset: 0x0006DA2C
		[Address(RVA = "0x2D9F2A4", Offset = "0x2D9F2A4", VA = "0x2D9F2A4")]
		[Token(Token = "0x60036DD")]
		private void method_62()
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
		}

		// Token: 0x060036DE RID: 14046 RVA: 0x0006F7D0 File Offset: 0x0006D9D0
		[Token(Token = "0x60036DE")]
		[Address(RVA = "0x2D9F374", Offset = "0x2D9F374", VA = "0x2D9F374", Slot = "38")]
		protected virtual void vmethod_33()
		{
		}

		// Token: 0x060036DF RID: 14047 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Token(Token = "0x60036DF")]
		[Address(RVA = "0x2D9E9A0", Offset = "0x2D9E9A0", VA = "0x2D9E9A0")]
		private void method_63(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036E0 RID: 14048 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Address(RVA = "0x2D9F4A0", Offset = "0x2D9F4A0", VA = "0x2D9F4A0")]
		[Token(Token = "0x60036E0")]
		private void method_64(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036E1 RID: 14049 RVA: 0x0006F864 File Offset: 0x0006DA64
		[Address(RVA = "0x2D9AB30", Offset = "0x2D9AB30", VA = "0x2D9AB30")]
		[Token(Token = "0x60036E1")]
		private void method_65(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x060036E2 RID: 14050 RVA: 0x0006F808 File Offset: 0x0006DA08
		[Token(Token = "0x60036E2")]
		[Address(RVA = "0x2D9F5F0", Offset = "0x2D9F5F0", VA = "0x2D9F5F0")]
		private void method_66(Class42<float> class42_1, float float_4, float float_5, float float_6, float float_7, ref float float_8)
		{
			Mathf.Min(float_7, float_4);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x04000904 RID: 2308
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000904")]
		public float float_0 = (float)16000;

		// Token: 0x04000905 RID: 2309
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000905")]
		public float float_1;

		// Token: 0x04000906 RID: 2310
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000906")]
		public float float_2;

		// Token: 0x04000907 RID: 2311
		[Token(Token = "0x4000907")]
		[FieldOffset(Offset = "0x24")]
		public float float_3;

		// Token: 0x04000908 RID: 2312
		[Token(Token = "0x4000908")]
		[FieldOffset(Offset = "0x28")]
		private readonly Class42<float> class42_0;

		// Token: 0x04000909 RID: 2313
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000909")]
		private CollisionDetector collisionDetector_0;
	}
}
