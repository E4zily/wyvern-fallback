﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using HexabodyVR.SampleScene;
using UnityEngine;
using UnityEngine.Events;

namespace HexabodyVR.PlayerController
{
	// Token: 0x0200013D RID: 317
	[Token(Token = "0x200013D")]
	public class BasicGrabber : MonoBehaviour
	{
		// Token: 0x060032E8 RID: 13032 RVA: 0x0000315C File Offset: 0x0000135C
		[Address(RVA = "0x2C00BE8", Offset = "0x2C00BE8", VA = "0x2C00BE8")]
		[Token(Token = "0x60032E8")]
		public Rigidbody method_0()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060032E9 RID: 13033 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x60032E9")]
		[Address(RVA = "0x2C00BF0", Offset = "0x2C00BF0", VA = "0x2C00BF0")]
		public Rigidbody method_1()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060032EA RID: 13034 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x60032EA")]
		[Address(RVA = "0x2C00BF8", Offset = "0x2C00BF8", VA = "0x2C00BF8")]
		public Rigidbody method_2()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060032EB RID: 13035 RVA: 0x0006563C File Offset: 0x0006383C
		[Token(Token = "0x60032EB")]
		[Address(RVA = "0x2C00C00", Offset = "0x2C00C00", VA = "0x2C00C00")]
		private void method_3()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (this.bool_0 || (flag = this.spiderHands_0.bool_0))
			{
				return;
			}
			Vector3 position = this.transform_0.position;
			ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
			this.configurableJoint_0 = configurableJoint;
			Transform transform = base.transform;
			Vector3 position2 = this.transform_0.position;
			if (flag)
			{
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				exists;
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				if (flag)
				{
				}
				Rigidbody exists3;
				exists3;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				Vector3 position3 = this.transform_0.position;
				return;
			}
			throw new IndexOutOfRangeException();
		}

		// Token: 0x060032EC RID: 13036 RVA: 0x00003164 File Offset: 0x00001364
		[Token(Token = "0x60032EC")]
		[Address(RVA = "0x2C010C0", Offset = "0x2C010C0", VA = "0x2C010C0")]
		private void method_4(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060032ED RID: 13037 RVA: 0x00003164 File Offset: 0x00001364
		[Token(Token = "0x60032ED")]
		[Address(RVA = "0x2C010C8", Offset = "0x2C010C8", VA = "0x2C010C8")]
		private void method_5(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060032EE RID: 13038 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x60032EE")]
		[Address(RVA = "0x2C010D0", Offset = "0x2C010D0", VA = "0x2C010D0")]
		private void method_6(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x060032EF RID: 13039 RVA: 0x0000316D File Offset: 0x0000136D
		[Address(RVA = "0x2C010D8", Offset = "0x2C010D8", VA = "0x2C010D8")]
		[Token(Token = "0x60032EF")]
		private void method_7(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x060032F0 RID: 13040 RVA: 0x00065700 File Offset: 0x00063900
		[Address(RVA = "0x2C010E0", Offset = "0x2C010E0", VA = "0x2C010E0")]
		[Token(Token = "0x60032F0")]
		private void method_8()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (!this.bool_0 && !(flag = this.spiderHands_0.bool_0))
			{
				LayerMask mask = this.layerMask_0;
				mask;
				ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position = this.transform_0.position;
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				return;
			}
		}

		// Token: 0x060032F1 RID: 13041 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x60032F1")]
		[Address(RVA = "0x2C0159C", Offset = "0x2C0159C", VA = "0x2C0159C")]
		public Rigidbody method_9()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060032F2 RID: 13042 RVA: 0x00065794 File Offset: 0x00063994
		[Address(RVA = "0x2C015A4", Offset = "0x2C015A4", VA = "0x2C015A4")]
		[Token(Token = "0x60032F2")]
		private void method_10()
		{
			SpiderHands component = base.GetComponent<SpiderHands>();
			this.spiderHands_0 = component;
		}

		// Token: 0x060032F3 RID: 13043 RVA: 0x00003176 File Offset: 0x00001376
		[Token(Token = "0x60032F3")]
		[Address(RVA = "0x2C01600", Offset = "0x2C01600", VA = "0x2C01600")]
		public ConfigurableJoint method_11()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x060032F4 RID: 13044 RVA: 0x0000315C File Offset: 0x0000135C
		[Address(RVA = "0x2C01608", Offset = "0x2C01608", VA = "0x2C01608")]
		[Token(Token = "0x60032F4")]
		public Rigidbody method_12()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060032F5 RID: 13045 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x60032F5")]
		[Address(RVA = "0x2C01610", Offset = "0x2C01610", VA = "0x2C01610")]
		public Rigidbody method_13()
		{
			return this.rigidbody_0;
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x0600332D RID: 13101 RVA: 0x0000315C File Offset: 0x0000135C
		// (set) Token: 0x060032F6 RID: 13046 RVA: 0x00003164 File Offset: 0x00001364
		[Token(Token = "0x17000089")]
		public Rigidbody Rigidbody_0 { [Address(RVA = "0x2C04500", Offset = "0x2C04500", VA = "0x2C04500")] [Token(Token = "0x600332D")] get; [Address(RVA = "0x2C01618", Offset = "0x2C01618", VA = "0x2C01618")] [Token(Token = "0x60032F6")] private set; }

		// Token: 0x060032F7 RID: 13047 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x60032F7")]
		[Address(RVA = "0x2C01620", Offset = "0x2C01620", VA = "0x2C01620")]
		public Rigidbody method_14()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060032F8 RID: 13048 RVA: 0x00003176 File Offset: 0x00001376
		[Address(RVA = "0x2C01628", Offset = "0x2C01628", VA = "0x2C01628")]
		[Token(Token = "0x60032F8")]
		public ConfigurableJoint method_15()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x060032F9 RID: 13049 RVA: 0x00003164 File Offset: 0x00001364
		[Address(RVA = "0x2C01630", Offset = "0x2C01630", VA = "0x2C01630")]
		[Token(Token = "0x60032F9")]
		private void method_16(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060032FA RID: 13050 RVA: 0x000657B0 File Offset: 0x000639B0
		[Address(RVA = "0x2C01638", Offset = "0x2C01638", VA = "0x2C01638")]
		[Token(Token = "0x60032FA")]
		private void method_17()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (!this.bool_0 && !(flag = this.spiderHands_0.bool_0))
			{
				Vector3 position = this.transform_0.position;
				LayerMask mask = this.layerMask_0;
				mask;
				ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				exists;
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				if (flag)
				{
				}
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				Vector3 position3 = this.transform_0.position;
				return;
			}
		}

		// Token: 0x060032FB RID: 13051 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x60032FB")]
		[Address(RVA = "0x2C01AFC", Offset = "0x2C01AFC", VA = "0x2C01AFC")]
		public Rigidbody method_18()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060032FC RID: 13052 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x60032FC")]
		[Address(RVA = "0x2C01B04", Offset = "0x2C01B04", VA = "0x2C01B04")]
		private void method_19(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x060032FD RID: 13053 RVA: 0x00065874 File Offset: 0x00063A74
		[Token(Token = "0x60032FD")]
		[Address(RVA = "0x2C01B0C", Offset = "0x2C01B0C", VA = "0x2C01B0C")]
		private void method_20()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (!this.bool_0 && !(flag = this.spiderHands_0.bool_0))
			{
				Vector3 position = this.transform_0.position;
				LayerMask mask = this.layerMask_0;
				mask;
				ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				exists;
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				if (flag)
				{
				}
				Rigidbody exists3;
				exists3;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				Vector3 position3 = this.transform_0.position;
				return;
			}
		}

		// Token: 0x060032FE RID: 13054 RVA: 0x0000316D File Offset: 0x0000136D
		[Address(RVA = "0x2C01FD4", Offset = "0x2C01FD4", VA = "0x2C01FD4")]
		[Token(Token = "0x60032FE")]
		private void method_21(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060032FF RID: 13055 RVA: 0x00003176 File Offset: 0x00001376
		// (set) Token: 0x0600330B RID: 13067 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x17000088")]
		public ConfigurableJoint ConfigurableJoint_0 { [Address(RVA = "0x2C01FDC", Offset = "0x2C01FDC", VA = "0x2C01FDC")] [Token(Token = "0x60032FF")] get; [Token(Token = "0x600330B")] [Address(RVA = "0x2C02A48", Offset = "0x2C02A48", VA = "0x2C02A48")] private set; }

		// Token: 0x06003300 RID: 13056 RVA: 0x00065940 File Offset: 0x00063B40
		[Address(RVA = "0x2C01FE4", Offset = "0x2C01FE4", VA = "0x2C01FE4")]
		[Token(Token = "0x6003300")]
		private void method_22()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (!this.bool_0)
			{
				SpiderHands spiderHands = this.spiderHands_0;
				if (spiderHands == null)
				{
					Vector3 position = this.transform_0.position;
					LayerMask mask = this.layerMask_0;
					mask;
					ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
					this.configurableJoint_0 = configurableJoint;
					Transform transform = base.transform;
					Vector3 position2 = this.transform_0.position;
					if (spiderHands != null)
					{
					}
					Rigidbody exists;
					exists;
					if (this.collider_0 != null)
					{
					}
					if (spiderHands != null)
					{
					}
					Rigidbody exists2;
					exists2;
					return;
				}
			}
		}

		// Token: 0x06003301 RID: 13057 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x6003301")]
		[Address(RVA = "0x2C02498", Offset = "0x2C02498", VA = "0x2C02498")]
		private void method_23(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x06003302 RID: 13058 RVA: 0x00003164 File Offset: 0x00001364
		[Token(Token = "0x6003302")]
		[Address(RVA = "0x2C024A0", Offset = "0x2C024A0", VA = "0x2C024A0")]
		private void method_24(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003303 RID: 13059 RVA: 0x0000316D File Offset: 0x0000136D
		[Address(RVA = "0x2C024A8", Offset = "0x2C024A8", VA = "0x2C024A8")]
		[Token(Token = "0x6003303")]
		private void method_25(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x06003304 RID: 13060 RVA: 0x000659DC File Offset: 0x00063BDC
		[Token(Token = "0x6003304")]
		[Address(RVA = "0x2C024B0", Offset = "0x2C024B0", VA = "0x2C024B0")]
		private void FixedUpdate()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (hexaXRInputs != null || (flag = this.spiderHands_0.bool_0))
			{
				return;
			}
			Vector3 position = this.transform_0.position;
			LayerMask mask = this.layerMask_0;
			mask;
			ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
			this.configurableJoint_0 = configurableJoint;
			Transform transform = base.transform;
			Vector3 position2 = this.transform_0.position;
			if (flag)
			{
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				exists;
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				if (flag)
				{
				}
				Rigidbody exists3;
				exists3;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				Vector3 position3 = this.transform_0.position;
				return;
			}
			throw new IndexOutOfRangeException();
		}

		// Token: 0x06003305 RID: 13061 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x6003305")]
		[Address(RVA = "0x2C02970", Offset = "0x2C02970", VA = "0x2C02970")]
		public Rigidbody method_26()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003306 RID: 13062 RVA: 0x0000315C File Offset: 0x0000135C
		[Address(RVA = "0x2C02978", Offset = "0x2C02978", VA = "0x2C02978")]
		[Token(Token = "0x6003306")]
		public Rigidbody method_27()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003307 RID: 13063 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2C02980", Offset = "0x2C02980", VA = "0x2C02980")]
		[Token(Token = "0x6003307")]
		private void method_28()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003308 RID: 13064 RVA: 0x00003176 File Offset: 0x00001376
		[Address(RVA = "0x2C029DC", Offset = "0x2C029DC", VA = "0x2C029DC")]
		[Token(Token = "0x6003308")]
		public ConfigurableJoint method_29()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x06003309 RID: 13065 RVA: 0x00065794 File Offset: 0x00063994
		[Token(Token = "0x6003309")]
		[Address(RVA = "0x2C029E4", Offset = "0x2C029E4", VA = "0x2C029E4")]
		private void method_30()
		{
			SpiderHands component = base.GetComponent<SpiderHands>();
			this.spiderHands_0 = component;
		}

		// Token: 0x0600330A RID: 13066 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x600330A")]
		[Address(RVA = "0x2C02A40", Offset = "0x2C02A40", VA = "0x2C02A40")]
		private void method_31(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x0600330C RID: 13068 RVA: 0x00065AAC File Offset: 0x00063CAC
		[Address(RVA = "0x2C02A50", Offset = "0x2C02A50", VA = "0x2C02A50")]
		[Token(Token = "0x600330C")]
		private void method_32()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (!this.bool_0 && !(flag = this.spiderHands_0.bool_0))
			{
				Vector3 position = this.transform_0.position;
				LayerMask mask = this.layerMask_0;
				mask;
				ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				ConfigurableJoint configurableJoint2 = this.configurableJoint_0;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				long autoConfigureConnectedAnchor = 1L;
				configurableJoint2.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				return;
			}
		}

		// Token: 0x0600330D RID: 13069 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600330D")]
		[Address(RVA = "0x2C02F0C", Offset = "0x2C02F0C", VA = "0x2C02F0C")]
		private void method_33()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600330E RID: 13070 RVA: 0x0000315C File Offset: 0x0000135C
		[Address(RVA = "0x2C02F68", Offset = "0x2C02F68", VA = "0x2C02F68")]
		[Token(Token = "0x600330E")]
		public Rigidbody method_34()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600330F RID: 13071 RVA: 0x00003176 File Offset: 0x00001376
		[Token(Token = "0x600330F")]
		[Address(RVA = "0x2C02F70", Offset = "0x2C02F70", VA = "0x2C02F70")]
		public ConfigurableJoint method_35()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x06003310 RID: 13072 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x6003310")]
		[Address(RVA = "0x2C02F78", Offset = "0x2C02F78", VA = "0x2C02F78")]
		public Rigidbody method_36()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003311 RID: 13073 RVA: 0x0000315C File Offset: 0x0000135C
		[Address(RVA = "0x2C02F80", Offset = "0x2C02F80", VA = "0x2C02F80")]
		[Token(Token = "0x6003311")]
		public Rigidbody method_37()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003312 RID: 13074 RVA: 0x00003176 File Offset: 0x00001376
		[Token(Token = "0x6003312")]
		[Address(RVA = "0x2C02F88", Offset = "0x2C02F88", VA = "0x2C02F88")]
		public ConfigurableJoint method_38()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x06003313 RID: 13075 RVA: 0x0000316D File Offset: 0x0000136D
		[Address(RVA = "0x2C02F90", Offset = "0x2C02F90", VA = "0x2C02F90")]
		[Token(Token = "0x6003313")]
		private void method_39(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x06003314 RID: 13076 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x6003314")]
		[Address(RVA = "0x2C02F98", Offset = "0x2C02F98", VA = "0x2C02F98")]
		public Rigidbody method_40()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003315 RID: 13077 RVA: 0x00003176 File Offset: 0x00001376
		[Token(Token = "0x6003315")]
		[Address(RVA = "0x2C02FA0", Offset = "0x2C02FA0", VA = "0x2C02FA0")]
		public ConfigurableJoint method_41()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x06003316 RID: 13078 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003316")]
		[Address(RVA = "0x2C02FA8", Offset = "0x2C02FA8", VA = "0x2C02FA8")]
		private void method_42()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003317 RID: 13079 RVA: 0x00065794 File Offset: 0x00063994
		[Address(RVA = "0x2C0344C", Offset = "0x2C0344C", VA = "0x2C0344C")]
		[Token(Token = "0x6003317")]
		private void Awake()
		{
			SpiderHands component = base.GetComponent<SpiderHands>();
			this.spiderHands_0 = component;
		}

		// Token: 0x06003318 RID: 13080 RVA: 0x00065B64 File Offset: 0x00063D64
		[Token(Token = "0x6003318")]
		[Address(RVA = "0x2C034A8", Offset = "0x2C034A8", VA = "0x2C034A8")]
		private void method_43()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (this.bool_0 || (flag = this.spiderHands_0.bool_0))
			{
				return;
			}
			Vector3 position = this.transform_0.position;
			LayerMask mask = this.layerMask_0;
			mask;
			base.gameObject.AddComponent<ConfigurableJoint>();
			Transform transform = base.transform;
			Vector3 position2 = this.transform_0.position;
			if (flag)
			{
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				exists;
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				if (flag)
				{
				}
				Rigidbody exists3;
				exists3;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				Vector3 position3 = this.transform_0.position;
				return;
			}
			throw new IndexOutOfRangeException();
		}

		// Token: 0x06003319 RID: 13081 RVA: 0x00065C30 File Offset: 0x00063E30
		[Token(Token = "0x6003319")]
		[Address(RVA = "0x2C03968", Offset = "0x2C03968", VA = "0x2C03968")]
		private void method_44()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			bool flag;
			if (!this.bool_0 && !(flag = this.spiderHands_0.bool_0))
			{
				Vector3 position = this.transform_0.position;
				LayerMask mask = this.layerMask_0;
				mask;
				ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				if (flag)
				{
				}
				Rigidbody exists;
				exists;
				if (this.collider_0 != null)
				{
				}
				exists;
				if (flag)
				{
				}
				Rigidbody exists2;
				exists2;
				if (flag)
				{
				}
				Rigidbody exists3;
				exists3;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				Vector3 position3 = this.transform_0.position;
				return;
			}
		}

		// Token: 0x0600331A RID: 13082 RVA: 0x00065794 File Offset: 0x00063994
		[Token(Token = "0x600331A")]
		[Address(RVA = "0x2C03E28", Offset = "0x2C03E28", VA = "0x2C03E28")]
		private void method_45()
		{
			SpiderHands component = base.GetComponent<SpiderHands>();
			this.spiderHands_0 = component;
		}

		// Token: 0x0600331B RID: 13083 RVA: 0x00003176 File Offset: 0x00001376
		[Token(Token = "0x600331B")]
		[Address(RVA = "0x2C03E84", Offset = "0x2C03E84", VA = "0x2C03E84")]
		public ConfigurableJoint method_46()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x0600331C RID: 13084 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x600331C")]
		[Address(RVA = "0x2C03E8C", Offset = "0x2C03E8C", VA = "0x2C03E8C")]
		public Rigidbody method_47()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600331D RID: 13085 RVA: 0x00065794 File Offset: 0x00063994
		[Address(RVA = "0x2C03E94", Offset = "0x2C03E94", VA = "0x2C03E94")]
		[Token(Token = "0x600331D")]
		private void method_48()
		{
			SpiderHands component = base.GetComponent<SpiderHands>();
			this.spiderHands_0 = component;
		}

		// Token: 0x0600331E RID: 13086 RVA: 0x00003176 File Offset: 0x00001376
		[Token(Token = "0x600331E")]
		[Address(RVA = "0x2C03EF0", Offset = "0x2C03EF0", VA = "0x2C03EF0")]
		public ConfigurableJoint method_49()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x0600331F RID: 13087 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x600331F")]
		[Address(RVA = "0x2C03EF8", Offset = "0x2C03EF8", VA = "0x2C03EF8")]
		public Rigidbody method_50()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003320 RID: 13088 RVA: 0x00003176 File Offset: 0x00001376
		[Token(Token = "0x6003320")]
		[Address(RVA = "0x2C03F00", Offset = "0x2C03F00", VA = "0x2C03F00")]
		public ConfigurableJoint method_51()
		{
			return this.configurableJoint_0;
		}

		// Token: 0x06003321 RID: 13089 RVA: 0x0000316D File Offset: 0x0000136D
		[Address(RVA = "0x2C03F08", Offset = "0x2C03F08", VA = "0x2C03F08")]
		[Token(Token = "0x6003321")]
		private void method_52(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x06003322 RID: 13090 RVA: 0x00065794 File Offset: 0x00063994
		[Token(Token = "0x6003322")]
		[Address(RVA = "0x2C03F10", Offset = "0x2C03F10", VA = "0x2C03F10")]
		private void method_53()
		{
			SpiderHands component = base.GetComponent<SpiderHands>();
			this.spiderHands_0 = component;
		}

		// Token: 0x06003323 RID: 13091 RVA: 0x00065794 File Offset: 0x00063994
		[Token(Token = "0x6003323")]
		[Address(RVA = "0x2C03F6C", Offset = "0x2C03F6C", VA = "0x2C03F6C")]
		private void method_54()
		{
			SpiderHands component = base.GetComponent<SpiderHands>();
			this.spiderHands_0 = component;
		}

		// Token: 0x06003324 RID: 13092 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003324")]
		[Address(RVA = "0x2C03FC8", Offset = "0x2C03FC8", VA = "0x2C03FC8")]
		private void method_55()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003325 RID: 13093 RVA: 0x0000315C File Offset: 0x0000135C
		[Address(RVA = "0x2C04024", Offset = "0x2C04024", VA = "0x2C04024")]
		[Token(Token = "0x6003325")]
		public Rigidbody method_56()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003326 RID: 13094 RVA: 0x00003164 File Offset: 0x00001364
		[Token(Token = "0x6003326")]
		[Address(RVA = "0x2C0402C", Offset = "0x2C0402C", VA = "0x2C0402C")]
		private void method_57(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003327 RID: 13095 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x6003327")]
		[Address(RVA = "0x2C04034", Offset = "0x2C04034", VA = "0x2C04034")]
		private void method_58(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x06003328 RID: 13096 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x6003328")]
		[Address(RVA = "0x2C0403C", Offset = "0x2C0403C", VA = "0x2C0403C")]
		private void method_59(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x06003329 RID: 13097 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x6003329")]
		[Address(RVA = "0x2C04044", Offset = "0x2C04044", VA = "0x2C04044")]
		public Rigidbody method_60()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600332A RID: 13098 RVA: 0x0000315C File Offset: 0x0000135C
		[Token(Token = "0x600332A")]
		[Address(RVA = "0x2C0404C", Offset = "0x2C0404C", VA = "0x2C0404C")]
		public Rigidbody method_61()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600332B RID: 13099 RVA: 0x0000315C File Offset: 0x0000135C
		[Address(RVA = "0x2C04054", Offset = "0x2C04054", VA = "0x2C04054")]
		[Token(Token = "0x600332B")]
		public Rigidbody method_62()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600332C RID: 13100 RVA: 0x00065CFC File Offset: 0x00063EFC
		[Token(Token = "0x600332C")]
		[Address(RVA = "0x2C0405C", Offset = "0x2C0405C", VA = "0x2C0405C")]
		private void method_63()
		{
			if (!this.bool_0)
			{
				SpiderHands spiderHands = this.spiderHands_0;
				if (spiderHands == null)
				{
					Vector3 position = this.transform_0.position;
					LayerMask mask = this.layerMask_0;
					mask;
					ConfigurableJoint configurableJoint = base.gameObject.AddComponent<ConfigurableJoint>();
					this.configurableJoint_0 = configurableJoint;
					Transform transform = base.transform;
					Vector3 position2 = this.transform_0.position;
					if (spiderHands != null)
					{
						if (spiderHands != null)
						{
						}
						Rigidbody exists;
						exists;
						Collider[] array = this.collider_0;
						if (spiderHands != null)
						{
							if (array != null)
							{
							}
							exists;
							if (spiderHands != null)
							{
							}
							Rigidbody exists2;
							exists2;
							return;
						}
					}
					throw new IndexOutOfRangeException();
				}
			}
		}

		// Token: 0x0600332E RID: 13102 RVA: 0x00065D9C File Offset: 0x00063F9C
		[Token(Token = "0x600332E")]
		[Address(RVA = "0x2C04508", Offset = "0x2C04508", VA = "0x2C04508")]
		public BasicGrabber()
		{
			Collider[] array = new Collider[100];
			this.collider_0 = array;
			UnityEvent unityEvent = new UnityEvent();
			this.unityEvent_0 = unityEvent;
			UnityEvent unityEvent2 = new UnityEvent();
			this.unityEvent_1 = unityEvent2;
			base..ctor();
		}

		// Token: 0x0600332F RID: 13103 RVA: 0x0000316D File Offset: 0x0000136D
		[Token(Token = "0x600332F")]
		[Address(RVA = "0x2C045E0", Offset = "0x2C045E0", VA = "0x2C045E0")]
		private void method_64(ConfigurableJoint configurableJoint_1)
		{
			this.configurableJoint_0 = configurableJoint_1;
		}

		// Token: 0x04000650 RID: 1616
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000650")]
		public float float_0 = (float)52429;

		// Token: 0x04000651 RID: 1617
		[Token(Token = "0x4000651")]
		[FieldOffset(Offset = "0x1C")]
		public LayerMask layerMask_0;

		// Token: 0x04000652 RID: 1618
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000652")]
		public HexaXRInputs hexaXRInputs_0;

		// Token: 0x04000653 RID: 1619
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000653")]
		public bool bool_0;

		// Token: 0x04000654 RID: 1620
		[Token(Token = "0x4000654")]
		[FieldOffset(Offset = "0x30")]
		public Transform transform_0;

		// Token: 0x04000655 RID: 1621
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000655")]
		private readonly Collider[] collider_0;

		// Token: 0x04000656 RID: 1622
		[Token(Token = "0x4000656")]
		[FieldOffset(Offset = "0x40")]
		public SpiderHands spiderHands_0;

		// Token: 0x04000657 RID: 1623
		[Token(Token = "0x4000657")]
		[FieldOffset(Offset = "0x48")]
		[CompilerGenerated]
		private ConfigurableJoint configurableJoint_0;

		// Token: 0x04000658 RID: 1624
		[FieldOffset(Offset = "0x50")]
		[CompilerGenerated]
		[Token(Token = "0x4000658")]
		private Rigidbody rigidbody_0;

		// Token: 0x04000659 RID: 1625
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000659")]
		public UnityEvent unityEvent_0;

		// Token: 0x0400065A RID: 1626
		[Token(Token = "0x400065A")]
		[FieldOffset(Offset = "0x60")]
		public UnityEvent unityEvent_1;
	}
}
