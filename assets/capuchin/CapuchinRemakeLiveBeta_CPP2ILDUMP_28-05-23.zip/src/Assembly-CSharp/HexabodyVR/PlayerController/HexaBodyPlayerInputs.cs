﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x0200014E RID: 334
	[Token(Token = "0x200014E")]
	public class HexaBodyPlayerInputs : MonoBehaviour
	{
		// Token: 0x06003567 RID: 13671 RVA: 0x0006B9CC File Offset: 0x00069BCC
		[Address(RVA = "0x326ACE0", Offset = "0x326ACE0", VA = "0x326ACE0")]
		[Token(Token = "0x6003567")]
		private void method_0()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)49152;
			this.playerInputState_2.Value = (float)32768;
			this.playerInputState_0.Value = (float)17439;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			long num6;
			if (flag6)
			{
				if (playerInputState == null)
				{
					num6 = 256L;
					this.playerInputState_1 = num6;
					return;
				}
			}
			else if (num6 != 0L)
			{
				long justDeactivated = 1L;
				this.playerInputState_1 = justDeactivated;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7 && playerInputState2 == null)
			{
				this.playerInputState_2 = 257;
				return;
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8 && playerInputState3 == null)
			{
				this.playerInputState_0 = 257;
				return;
			}
		}

		// Token: 0x06003568 RID: 13672 RVA: 0x0000336B File Offset: 0x0000156B
		[Address(RVA = "0x326AF04", Offset = "0x326AF04", VA = "0x326AF04")]
		[Token(Token = "0x6003568")]
		protected void method_1(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)57344;
		}

		// Token: 0x06003569 RID: 13673 RVA: 0x0006BB50 File Offset: 0x00069D50
		[Address(RVA = "0x326AF18", Offset = "0x326AF18", VA = "0x326AF18")]
		[Token(Token = "0x6003569")]
		private void method_2()
		{
			this.playerInputState_2.Value = (float)49152;
			this.playerInputState_0.Value = (float)49152;
		}

		// Token: 0x0600356A RID: 13674 RVA: 0x00003378 File Offset: 0x00001578
		[Address(RVA = "0x326B0BC", Offset = "0x326B0BC", VA = "0x326B0BC")]
		[Token(Token = "0x600356A")]
		protected void method_3(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)49152;
		}

		// Token: 0x0600356B RID: 13675 RVA: 0x0006BB80 File Offset: 0x00069D80
		[Address(RVA = "0x326B0D0", Offset = "0x326B0D0", VA = "0x326B0D0")]
		[Token(Token = "0x600356B")]
		protected void method_4(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			long active = 256L;
			playerInputState_3.Active = (active != 0L);
		}

		// Token: 0x0600356C RID: 13676 RVA: 0x00003385 File Offset: 0x00001585
		[Address(RVA = "0x326B124", Offset = "0x326B124", VA = "0x326B124")]
		[Token(Token = "0x600356C")]
		protected void method_5(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)24576;
		}

		// Token: 0x0600356D RID: 13677 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326B13C", Offset = "0x326B13C", VA = "0x326B13C")]
		[Token(Token = "0x600356D")]
		protected void method_6(ref PlayerInputState playerInputState_3, bool bool_7)
		{
		}

		// Token: 0x0600356E RID: 13678 RVA: 0x0006BB9C File Offset: 0x00069D9C
		[Address(RVA = "0x326B160", Offset = "0x326B160", VA = "0x326B160")]
		[Token(Token = "0x600356E")]
		protected void method_7(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			playerInputState_3.Active = (257 != 0);
		}

		// Token: 0x0600356F RID: 13679 RVA: 0x00003385 File Offset: 0x00001585
		[Address(RVA = "0x326B18C", Offset = "0x326B18C", VA = "0x326B18C")]
		[Token(Token = "0x600356F")]
		protected void method_8(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)24576;
		}

		// Token: 0x06003570 RID: 13680 RVA: 0x0006BBB4 File Offset: 0x00069DB4
		[Address(RVA = "0x326B1A4", Offset = "0x326B1A4", VA = "0x326B1A4")]
		[Token(Token = "0x6003570")]
		private void method_9()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)32768;
			this.playerInputState_2.Value = (float)32768;
			this.playerInputState_0.Value = (float)17401;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6 && playerInputState == null)
			{
				this.playerInputState_1 = 257;
				return;
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					return;
				}
			}
			else if (playerInputState2 != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_2 = justDeactivated;
				this.playerInputState_2.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			long num6;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					num6 = 256L;
					this.playerInputState_0 = num6;
					return;
				}
			}
			else if (num6 != 0L)
			{
				long justDeactivated2 = 1L;
				this.playerInputState_0.JustDeactivated = (justDeactivated2 != 0L);
			}
		}

		// Token: 0x06003571 RID: 13681 RVA: 0x0006BD40 File Offset: 0x00069F40
		[Address(RVA = "0x326B3A0", Offset = "0x326B3A0", VA = "0x326B3A0")]
		[Token(Token = "0x6003571")]
		private void method_10()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)32768;
			this.playerInputState_0.Value = (float)49152;
			if (flag)
			{
				if (this.bool_5)
				{
					return;
				}
				Input.GetKey(this.keyCode_0);
				long num;
				if (this.bool_6)
				{
					num = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag2 = this.bool_4;
				this.bool_6 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag3 = this.bool_2;
				this.bool_4 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag4 = this.bool_3;
				this.bool_2 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num4 != 0L);
			}
			bool flag5 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag5 && playerInputState == null)
			{
				this.playerInputState_1 = 257;
				return;
			}
			bool flag6 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			long num5;
			if (flag6)
			{
				if (playerInputState2 == null)
				{
					num5 = 256L;
					this.playerInputState_2 = num5;
					return;
				}
			}
			else if (num5 != 0L)
			{
				long justDeactivated = 1L;
				this.playerInputState_2.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag7)
			{
				if (playerInputState3 == null)
				{
					return;
				}
			}
			else if (playerInputState3 != null)
			{
				long justDeactivated2 = 1L;
				this.playerInputState_0.JustDeactivated = (justDeactivated2 != 0L);
			}
		}

		// Token: 0x06003572 RID: 13682 RVA: 0x00003392 File Offset: 0x00001592
		[Address(RVA = "0x326AEDC", Offset = "0x326AEDC", VA = "0x326AEDC")]
		[Token(Token = "0x6003572")]
		protected void method_11(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			playerInputState_3.Active = (257 != 0);
		}

		// Token: 0x06003573 RID: 13683 RVA: 0x0006BEA8 File Offset: 0x0006A0A8
		[Address(RVA = "0x326B58C", Offset = "0x326B58C", VA = "0x326B58C")]
		[Token(Token = "0x6003573")]
		private void Update()
		{
			if (this.bool_0)
			{
				long num;
				if (this.bool_5)
				{
					num = 1L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag2 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag2)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag3 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag3)
				{
					num4 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag4 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag4)
				{
					num5 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag5 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag5)
			{
				if (playerInputState == null)
				{
					this.playerInputState_1 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated = 1L;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag6 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag6)
			{
				if (playerInputState2 == null)
				{
					this.playerInputState_2 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated2 = 1L;
				this.playerInputState_2.JustDeactivated = (justDeactivated2 != 0L);
			}
			bool flag7 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag7)
			{
				if (playerInputState3 == null)
				{
					this.playerInputState_0 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated3 = 1L;
				this.playerInputState_0.JustDeactivated = (justDeactivated3 != 0L);
			}
		}

		// Token: 0x06003574 RID: 13684 RVA: 0x0000339F File Offset: 0x0000159F
		[Address(RVA = "0x326B33C", Offset = "0x326B33C", VA = "0x326B33C")]
		[Token(Token = "0x6003574")]
		protected void method_12(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)17401;
		}

		// Token: 0x06003575 RID: 13685 RVA: 0x0006BB9C File Offset: 0x00069D9C
		[Address(RVA = "0x326B72C", Offset = "0x326B72C", VA = "0x326B72C")]
		[Token(Token = "0x6003575")]
		protected void method_13(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			playerInputState_3.Active = (257 != 0);
		}

		// Token: 0x06003576 RID: 13686 RVA: 0x0006C008 File Offset: 0x0006A208
		[Address(RVA = "0x326B758", Offset = "0x326B758", VA = "0x326B758")]
		[Token(Token = "0x6003576")]
		private void method_14()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)57344;
			this.playerInputState_2.Value = (float)32768;
			this.playerInputState_0.Value = (float)17439;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			long num6;
			if (flag6)
			{
				if (playerInputState == null)
				{
					num6 = 1L;
					this.playerInputState_1 = num6;
					return;
				}
			}
			else if (num6 == 0L)
			{
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					return;
				}
			}
			else if (playerInputState2 != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_2 = justDeactivated;
				this.playerInputState_2.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			long num7;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					num7 = 1L;
					return;
				}
			}
			else if (num7 == 0L)
			{
			}
		}

		// Token: 0x06003577 RID: 13687 RVA: 0x00003392 File Offset: 0x00001592
		[Address(RVA = "0x326B350", Offset = "0x326B350", VA = "0x326B350")]
		[Token(Token = "0x6003577")]
		protected void method_15(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			playerInputState_3.Active = (257 != 0);
		}

		// Token: 0x06003578 RID: 13688 RVA: 0x000033AC File Offset: 0x000015AC
		[Token(Token = "0x6003578")]
		[Address(RVA = "0x326B914", Offset = "0x326B914", VA = "0x326B914")]
		protected void method_16(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)8192;
		}

		// Token: 0x06003579 RID: 13689 RVA: 0x0006BB9C File Offset: 0x00069D9C
		[Address(RVA = "0x326B92C", Offset = "0x326B92C", VA = "0x326B92C")]
		[Token(Token = "0x6003579")]
		protected void method_17(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			playerInputState_3.Active = (257 != 0);
		}

		// Token: 0x0600357A RID: 13690 RVA: 0x00024CB4 File Offset: 0x00022EB4
		[Address(RVA = "0x326B564", Offset = "0x326B564", VA = "0x326B564")]
		[Token(Token = "0x600357A")]
		protected void method_18(ref PlayerInputState playerInputState_3, bool bool_7)
		{
		}

		// Token: 0x0600357B RID: 13691 RVA: 0x00024CB4 File Offset: 0x00022EB4
		[Address(RVA = "0x326B958", Offset = "0x326B958", VA = "0x326B958")]
		[Token(Token = "0x600357B")]
		protected void method_19(ref PlayerInputState playerInputState_3, bool bool_7)
		{
		}

		// Token: 0x0600357C RID: 13692 RVA: 0x0006C17C File Offset: 0x0006A37C
		[Address(RVA = "0x326B980", Offset = "0x326B980", VA = "0x326B980")]
		[Token(Token = "0x600357C")]
		private void method_20()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)24576;
			this.playerInputState_2.Value = (float)17401;
			this.playerInputState_0.Value = (float)17439;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 1L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			long num6;
			if (flag6)
			{
				if (playerInputState == null)
				{
					num6 = 256L;
					this.playerInputState_1 = num6;
					return;
				}
			}
			else if (num6 != 0L)
			{
				long justDeactivated = 1L;
				this.playerInputState_1 = justDeactivated;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					this.playerInputState_2 = 257;
					return;
				}
			}
			else
			{
				long num7 = 1L;
				this.playerInputState_2 = num7;
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8 && playerInputState3 == null)
			{
				this.playerInputState_0 = 257;
				return;
			}
		}

		// Token: 0x0600357D RID: 13693 RVA: 0x0006C30C File Offset: 0x0006A50C
		[Address(RVA = "0x326BB08", Offset = "0x326BB08", VA = "0x326BB08")]
		[Token(Token = "0x600357D")]
		private void method_21()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)17070;
			this.playerInputState_2.Value = (float)49152;
			this.playerInputState_0.Value = (float)8192;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 1L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					return;
				}
			}
			else if (playerInputState == null)
			{
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					this.playerInputState_2 = 257;
					return;
				}
			}
			else
			{
				long num6 = 1L;
				this.playerInputState_2 = num6;
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					this.playerInputState_0 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated = 1L;
				this.playerInputState_0.JustDeactivated = (justDeactivated != 0L);
			}
		}

		// Token: 0x0600357E RID: 13694 RVA: 0x00024CB4 File Offset: 0x00022EB4
		[Address(RVA = "0x326B378", Offset = "0x326B378", VA = "0x326B378")]
		[Token(Token = "0x600357E")]
		protected void method_22(ref PlayerInputState playerInputState_3, bool bool_7)
		{
		}

		// Token: 0x0600357F RID: 13695 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326B098", Offset = "0x326B098", VA = "0x326B098")]
		[Token(Token = "0x600357F")]
		protected void method_23(ref PlayerInputState playerInputState_3)
		{
		}

		// Token: 0x06003580 RID: 13696 RVA: 0x0006C484 File Offset: 0x0006A684
		[Address(RVA = "0x326BCA4", Offset = "0x326BCA4", VA = "0x326BCA4")]
		[Token(Token = "0x6003580")]
		private void method_24()
		{
			bool flag = this.bool_0;
			this.playerInputState_2.Value = (float)32768;
			this.playerInputState_0.Value = (float)8192;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 0L;
					return;
				}
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					this.playerInputState_1 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated = 1L;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					return;
				}
			}
			else if (playerInputState2 != null)
			{
				long justDeactivated2 = 1L;
				this.playerInputState_2 = justDeactivated2;
				this.playerInputState_2.JustDeactivated = (justDeactivated2 != 0L);
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					this.playerInputState_0 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated3 = 1L;
				this.playerInputState_0.JustDeactivated = (justDeactivated3 != 0L);
			}
		}

		// Token: 0x06003581 RID: 13697 RVA: 0x00003392 File Offset: 0x00001592
		[Address(RVA = "0x326B53C", Offset = "0x326B53C", VA = "0x326B53C")]
		[Token(Token = "0x6003581")]
		protected void method_25(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			playerInputState_3.Active = (257 != 0);
		}

		// Token: 0x06003582 RID: 13698 RVA: 0x0006C5FC File Offset: 0x0006A7FC
		[Address(RVA = "0x326BE30", Offset = "0x326BE30", VA = "0x326BE30")]
		[Token(Token = "0x6003582")]
		private void method_26()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)24576;
			this.playerInputState_2.Value = (float)17070;
			this.playerInputState_0.Value = (float)32768;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 1L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6 && playerInputState == null)
			{
				this.playerInputState_1 = 257;
				return;
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					return;
				}
			}
			else if (playerInputState2 != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_2 = justDeactivated;
				this.playerInputState_2.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8 && playerInputState3 == null)
			{
				this.playerInputState_0 = 257;
				return;
			}
		}

		// Token: 0x06003583 RID: 13699 RVA: 0x000033B9 File Offset: 0x000015B9
		[Address(RVA = "0x326AE84", Offset = "0x326AE84", VA = "0x326AE84")]
		[Token(Token = "0x6003583")]
		protected void method_27(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)32768;
		}

		// Token: 0x06003584 RID: 13700 RVA: 0x0006BB9C File Offset: 0x00069D9C
		[Address(RVA = "0x326B700", Offset = "0x326B700", VA = "0x326B700")]
		[Token(Token = "0x6003584")]
		protected void method_28(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			playerInputState_3.Active = (257 != 0);
		}

		// Token: 0x06003585 RID: 13701 RVA: 0x000033C6 File Offset: 0x000015C6
		[Address(RVA = "0x326BFCC", Offset = "0x326BFCC", VA = "0x326BFCC")]
		[Token(Token = "0x6003585")]
		public HexaBodyPlayerInputs()
		{
		}

		// Token: 0x06003586 RID: 13702 RVA: 0x000033D6 File Offset: 0x000015D6
		[Address(RVA = "0x326BC90", Offset = "0x326BC90", VA = "0x326BC90")]
		[Token(Token = "0x6003586")]
		protected void method_29(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)17070;
		}

		// Token: 0x06003587 RID: 13703 RVA: 0x0006C770 File Offset: 0x0006A970
		[Address(RVA = "0x326BFE8", Offset = "0x326BFE8", VA = "0x326BFE8")]
		[Token(Token = "0x6003587")]
		private void method_30()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)32768;
			this.playerInputState_2.Value = (float)49152;
			this.playerInputState_0.Value = (float)8192;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				if (flag2)
				{
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num != 0L);
				long num2;
				if (flag3)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num2 != 0L);
				long num3;
				if (flag4)
				{
					num3 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num3 != 0L);
				if (flag5)
				{
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num3 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					this.playerInputState_1 = 257;
					return;
				}
			}
			else
			{
				long num4 = 1L;
				this.playerInputState_1 = num4;
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					this.playerInputState_2 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated = 1L;
				this.playerInputState_2.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8 && playerInputState3 == null)
			{
				this.playerInputState_0 = 257;
				return;
			}
		}

		// Token: 0x06003588 RID: 13704 RVA: 0x0006C8E8 File Offset: 0x0006AAE8
		[Address(RVA = "0x326C174", Offset = "0x326C174", VA = "0x326C174")]
		[Token(Token = "0x6003588")]
		private void method_31()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)24576;
			this.playerInputState_2.Value = (float)32768;
			this.playerInputState_0.Value = (float)8192;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 0L;
					return;
				}
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					return;
				}
			}
			else if (playerInputState != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_1 = justDeactivated;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7 && playerInputState2 == null)
			{
				this.playerInputState_2 = 257;
				return;
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					return;
				}
			}
			else if (playerInputState3 == null)
			{
			}
		}

		// Token: 0x06003589 RID: 13705 RVA: 0x0006CA48 File Offset: 0x0006AC48
		[Token(Token = "0x6003589")]
		[Address(RVA = "0x326C2F8", Offset = "0x326C2F8", VA = "0x326C2F8")]
		private void method_32()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)32768;
			this.playerInputState_2.Value = (float)24576;
			this.playerInputState_0.Value = (float)24576;
			if (flag)
			{
				bool flag2;
				if (flag2 = this.bool_5)
				{
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag3 = this.bool_6;
				this.bool_5 = flag2;
				long num;
				if (flag3)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag4 = this.bool_4;
				this.bool_6 = (num != 0L);
				long num2;
				if (flag4)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag5 = this.bool_2;
				this.bool_4 = (num2 != 0L);
				long num3;
				if (flag5)
				{
					num3 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag6 = this.bool_3;
				this.bool_2 = (num3 != 0L);
				long num4;
				if (flag6)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num4 != 0L);
			}
			bool flag7 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag7 && playerInputState == null)
			{
				this.playerInputState_1 = 257;
				return;
			}
			bool flag8 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag8)
			{
				if (playerInputState2 == null)
				{
					this.playerInputState_2 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated = 1L;
				this.playerInputState_2.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag9 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag9 && playerInputState3 == null)
			{
				this.playerInputState_0 = 257;
				return;
			}
		}

		// Token: 0x0600358A RID: 13706 RVA: 0x00003378 File Offset: 0x00001578
		[Address(RVA = "0x326B524", Offset = "0x326B524", VA = "0x326B524")]
		[Token(Token = "0x600358A")]
		protected void method_33(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)49152;
		}

		// Token: 0x0600358B RID: 13707 RVA: 0x00003378 File Offset: 0x00001578
		[Address(RVA = "0x326B0A4", Offset = "0x326B0A4", VA = "0x326B0A4")]
		[Token(Token = "0x600358B")]
		protected void method_34(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)49152;
		}

		// Token: 0x0600358C RID: 13708 RVA: 0x0006CBBC File Offset: 0x0006ADBC
		[Address(RVA = "0x326C488", Offset = "0x326C488", VA = "0x326C488")]
		[Token(Token = "0x600358C")]
		private void method_35()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)49152;
			this.playerInputState_2.Value = (float)49152;
			this.playerInputState_0.Value = (float)17439;
			if (flag)
			{
				return;
			}
			bool flag2 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag2)
			{
				if (playerInputState == null)
				{
					return;
				}
			}
			else if (playerInputState != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag3 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag3)
			{
				if (playerInputState2 == null)
				{
					return;
				}
			}
			else if (playerInputState2 != null)
			{
				long justDeactivated2 = 1L;
				this.playerInputState_2.JustDeactivated = (justDeactivated2 != 0L);
			}
			bool flag4 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag4)
			{
				if (playerInputState3 == null)
				{
					return;
				}
			}
			else if (playerInputState3 != null)
			{
				long justDeactivated3 = 1L;
				this.playerInputState_0 = justDeactivated3;
				this.playerInputState_0.JustDeactivated = (justDeactivated3 != 0L);
			}
		}

		// Token: 0x0600358D RID: 13709 RVA: 0x00003378 File Offset: 0x00001578
		[Address(RVA = "0x326AE6C", Offset = "0x326AE6C", VA = "0x326AE6C")]
		[Token(Token = "0x600358D")]
		protected void method_36(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)49152;
		}

		// Token: 0x0600358E RID: 13710 RVA: 0x0006BB80 File Offset: 0x00069D80
		[Address(RVA = "0x326AEB0", Offset = "0x326AEB0", VA = "0x326AEB0")]
		[Token(Token = "0x600358E")]
		protected void method_37(ref PlayerInputState playerInputState_3, bool bool_7)
		{
			long active = 256L;
			playerInputState_3.Active = (active != 0L);
		}

		// Token: 0x0600358F RID: 13711 RVA: 0x0006CC94 File Offset: 0x0006AE94
		[Address(RVA = "0x326C608", Offset = "0x326C608", VA = "0x326C608")]
		[Token(Token = "0x600358F")]
		private void method_38()
		{
			bool flag = this.bool_0;
			this.playerInputState_2.Value = (float)49152;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 1L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					return;
				}
			}
			else if (playerInputState != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7 && playerInputState2 == null)
			{
				this.playerInputState_2 = 257;
				return;
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					this.playerInputState_0 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated2 = 1L;
				this.playerInputState_0.JustDeactivated = (justDeactivated2 != 0L);
			}
		}

		// Token: 0x06003590 RID: 13712 RVA: 0x000033B9 File Offset: 0x000015B9
		[Address(RVA = "0x326B324", Offset = "0x326B324", VA = "0x326B324")]
		[Token(Token = "0x6003590")]
		protected void method_39(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)32768;
		}

		// Token: 0x06003591 RID: 13713 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326B0FC", Offset = "0x326B0FC", VA = "0x326B0FC")]
		[Token(Token = "0x6003591")]
		protected void method_40(ref PlayerInputState playerInputState_3, bool bool_7)
		{
		}

		// Token: 0x06003592 RID: 13714 RVA: 0x0000336B File Offset: 0x0000156B
		[Address(RVA = "0x326B8D8", Offset = "0x326B8D8", VA = "0x326B8D8")]
		[Token(Token = "0x6003592")]
		protected void method_41(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)57344;
		}

		// Token: 0x06003593 RID: 13715 RVA: 0x0006CDF0 File Offset: 0x0006AFF0
		[Address(RVA = "0x326C788", Offset = "0x326C788", VA = "0x326C788")]
		[Token(Token = "0x6003593")]
		private void method_42()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)32768;
			this.playerInputState_2.Value = (float)57344;
			this.playerInputState_0.Value = (float)24576;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 1L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					return;
				}
			}
			else if (playerInputState != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					return;
				}
			}
			else if (playerInputState2 != null)
			{
				long justDeactivated2 = 1L;
				this.playerInputState_2.JustDeactivated = (justDeactivated2 != 0L);
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					return;
				}
			}
			else if (playerInputState3 != null)
			{
				long justDeactivated3 = 1L;
				this.playerInputState_0 = justDeactivated3;
				this.playerInputState_0.JustDeactivated = (justDeactivated3 != 0L);
			}
		}

		// Token: 0x06003594 RID: 13716 RVA: 0x000033E3 File Offset: 0x000015E3
		[Address(RVA = "0x326AE9C", Offset = "0x326AE9C", VA = "0x326AE9C")]
		[Token(Token = "0x6003594")]
		protected void method_43(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)17439;
		}

		// Token: 0x06003595 RID: 13717 RVA: 0x00024CB4 File Offset: 0x00022EB4
		[Address(RVA = "0x326B8EC", Offset = "0x326B8EC", VA = "0x326B8EC")]
		[Token(Token = "0x6003595")]
		protected void method_44(ref PlayerInputState playerInputState_3, bool bool_7)
		{
		}

		// Token: 0x06003596 RID: 13718 RVA: 0x000033B9 File Offset: 0x000015B9
		[Address(RVA = "0x326BFB4", Offset = "0x326BFB4", VA = "0x326BFB4")]
		[Token(Token = "0x6003596")]
		protected void method_45(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)32768;
		}

		// Token: 0x06003597 RID: 13719 RVA: 0x0006CF78 File Offset: 0x0006B178
		[Address(RVA = "0x326C90C", Offset = "0x326C90C", VA = "0x326C90C")]
		[Token(Token = "0x6003597")]
		private void method_46()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)24576;
			this.playerInputState_2.Value = (float)24576;
			this.playerInputState_0.Value = (float)49152;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					return;
				}
			}
			else if (playerInputState != null)
			{
				long justDeactivated = 1L;
				this.playerInputState_1 = justDeactivated;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			long num6;
			if (flag7)
			{
				if (playerInputState2 == null)
				{
					num6 = 1L;
					this.playerInputState_2 = num6;
					return;
				}
			}
			else if (num6 == 0L)
			{
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			long num7;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					num7 = 1L;
					this.playerInputState_0 = num7;
					return;
				}
			}
			else if (num7 == 0L)
			{
			}
		}

		// Token: 0x06003598 RID: 13720 RVA: 0x0006D0F4 File Offset: 0x0006B2F4
		[Address(RVA = "0x326CA8C", Offset = "0x326CA8C", VA = "0x326CA8C")]
		[Token(Token = "0x6003598")]
		private void method_47()
		{
			bool flag = this.bool_0;
			this.playerInputState_1.Value = (float)24576;
			this.playerInputState_2.Value = (float)32768;
			this.playerInputState_0.Value = (float)32768;
			if (flag)
			{
				long num;
				if (this.bool_5)
				{
					num = 0L;
					return;
				}
				Input.GetKey(this.keyCode_0);
				bool flag2 = this.bool_6;
				this.bool_5 = (num != 0L);
				long num2;
				if (flag2)
				{
					num2 = 1L;
					return;
				}
				Input.GetKey(this.keyCode_1);
				bool flag3 = this.bool_4;
				this.bool_6 = (num2 != 0L);
				long num3;
				if (flag3)
				{
					num3 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_2);
				bool flag4 = this.bool_2;
				this.bool_4 = (num3 != 0L);
				long num4;
				if (flag4)
				{
					num4 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_3);
				bool flag5 = this.bool_3;
				this.bool_2 = (num4 != 0L);
				long num5;
				if (flag5)
				{
					num5 = 0L;
					return;
				}
				Input.GetKey(this.keyCode_4);
				this.bool_3 = (num5 != 0L);
			}
			bool flag6 = this.bool_5;
			PlayerInputState playerInputState = this.playerInputState_1;
			if (flag6)
			{
				if (playerInputState == null)
				{
					this.playerInputState_1 = 257;
					return;
				}
			}
			else
			{
				long justDeactivated = 1L;
				this.playerInputState_1.JustDeactivated = (justDeactivated != 0L);
			}
			bool flag7 = this.bool_6;
			PlayerInputState playerInputState2 = this.playerInputState_2;
			if (flag7 && playerInputState2 == null)
			{
				this.playerInputState_2 = 257;
				return;
			}
			bool flag8 = this.bool_4;
			PlayerInputState playerInputState3 = this.playerInputState_0;
			long num6;
			if (flag8)
			{
				if (playerInputState3 == null)
				{
					num6 = 1L;
					this.playerInputState_0 = num6;
					return;
				}
			}
			else if (num6 == 0L)
			{
			}
		}

		// Token: 0x06003599 RID: 13721 RVA: 0x000033F0 File Offset: 0x000015F0
		[Address(RVA = "0x326CC1C", Offset = "0x326CC1C", VA = "0x326CC1C")]
		[Token(Token = "0x6003599")]
		protected void method_48(ref PlayerInputState playerInputState_3)
		{
			playerInputState_3.Value = (float)40960;
		}

		// Token: 0x04000814 RID: 2068
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000814")]
		public bool bool_0;

		// Token: 0x04000815 RID: 2069
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000815")]
		public KeyCode keyCode_0;

		// Token: 0x04000816 RID: 2070
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000816")]
		public KeyCode keyCode_1;

		// Token: 0x04000817 RID: 2071
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000817")]
		public KeyCode keyCode_2;

		// Token: 0x04000818 RID: 2072
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000818")]
		public KeyCode keyCode_3;

		// Token: 0x04000819 RID: 2073
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000819")]
		public KeyCode keyCode_4 = KeyCode.R;

		// Token: 0x0400081A RID: 2074
		[Token(Token = "0x400081A")]
		[FieldOffset(Offset = "0x30")]
		public Vector2 vector2_0;

		// Token: 0x0400081B RID: 2075
		[Token(Token = "0x400081B")]
		[FieldOffset(Offset = "0x38")]
		public Vector2 vector2_1;

		// Token: 0x0400081C RID: 2076
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400081C")]
		public bool bool_1;

		// Token: 0x0400081D RID: 2077
		[Token(Token = "0x400081D")]
		[FieldOffset(Offset = "0x41")]
		public bool bool_2;

		// Token: 0x0400081E RID: 2078
		[FieldOffset(Offset = "0x42")]
		[Token(Token = "0x400081E")]
		public bool bool_3;

		// Token: 0x0400081F RID: 2079
		[Token(Token = "0x400081F")]
		[FieldOffset(Offset = "0x43")]
		public bool bool_4;

		// Token: 0x04000820 RID: 2080
		[Token(Token = "0x4000820")]
		[FieldOffset(Offset = "0x44")]
		public bool bool_5;

		// Token: 0x04000821 RID: 2081
		[Token(Token = "0x4000821")]
		[FieldOffset(Offset = "0x45")]
		public bool bool_6;

		// Token: 0x04000822 RID: 2082
		[Token(Token = "0x4000822")]
		[FieldOffset(Offset = "0x48")]
		internal PlayerInputState playerInputState_0;

		// Token: 0x04000823 RID: 2083
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000823")]
		internal PlayerInputState playerInputState_1;

		// Token: 0x04000824 RID: 2084
		[Token(Token = "0x4000824")]
		[FieldOffset(Offset = "0x58")]
		internal PlayerInputState playerInputState_2;
	}
}
