﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.InputSystem;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000152 RID: 338
	[Token(Token = "0x2000152")]
	public class HexaBodyInputs : HexaBodyInputsBase
	{
		// Token: 0x060035CB RID: 13771 RVA: 0x0006D6AC File Offset: 0x0006B8AC
		[Address(RVA = "0x3396D50", Offset = "0x3396D50", VA = "0x3396D50", Slot = "13")]
		[Token(Token = "0x60035CB")]
		protected virtual Vector2 vmethod_8()
		{
			/*
An exception occurred when decompiling this method (060035CB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_8()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(44)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(74)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035CC RID: 13772 RVA: 0x0006D6C8 File Offset: 0x0006B8C8
		[Address(RVA = "0x3396DF4", Offset = "0x3396DF4", VA = "0x3396DF4")]
		[Token(Token = "0x60035CC")]
		public HexaBodyInputs()
		{
			long num = 1065353216L;
			long bool_ = 16843009L;
			this.float_4 = (float)num;
			this.keyCode_4 = KeyCode.R;
			this.bool_0 = (bool_ != 0L);
			base..ctor();
		}

		// Token: 0x060035CD RID: 13773 RVA: 0x0006D700 File Offset: 0x0006B900
		[Address(RVA = "0x3396E3C", Offset = "0x3396E3C", VA = "0x3396E3C", Slot = "14")]
		[Token(Token = "0x60035CD")]
		protected virtual Vector2 vmethod_9()
		{
			/*
An exception occurred when decompiling this method (060035CD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_9()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(23)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(18)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(113)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035CE RID: 13774 RVA: 0x0006D724 File Offset: 0x0006B924
		[Address(RVA = "0x3396EE0", Offset = "0x3396EE0", VA = "0x3396EE0", Slot = "15")]
		[Token(Token = "0x60035CE")]
		protected virtual Vector2 vmethod_10()
		{
			/*
An exception occurred when decompiling this method (060035CE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_10()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(17)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035CF RID: 13775 RVA: 0x0006D738 File Offset: 0x0006B938
		[Address(RVA = "0x3396F84", Offset = "0x3396F84", VA = "0x3396F84", Slot = "12")]
		[Token(Token = "0x60035CF")]
		protected override bool vmethod_7()
		{
			if (this.bool_9)
			{
				Input.GetKeyDown(this.keyCode_4);
			}
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_15)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060035D0 RID: 13776 RVA: 0x0006D770 File Offset: 0x0006B970
		[Address(RVA = "0x3397000", Offset = "0x3397000", VA = "0x3397000", Slot = "9")]
		[Token(Token = "0x60035D0")]
		protected override Vector2 vmethod_4()
		{
			if (!this.bool_9)
			{
			}
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (hexaXRInputs.playerInputState_6 == null)
			{
			}
			Vector2 zero = Vector2.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060035D1 RID: 13777 RVA: 0x0006D7A0 File Offset: 0x0006B9A0
		[Address(RVA = "0x3397090", Offset = "0x3397090", VA = "0x3397090", Slot = "7")]
		[Token(Token = "0x60035D1")]
		protected override bool vmethod_2()
		{
			if (this.bool_9)
			{
				Input.GetKey(this.keyCode_2);
			}
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10)
			{
			}
			if (!hexaXRInputs.bool_8)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060035D2 RID: 13778 RVA: 0x0006D7E0 File Offset: 0x0006B9E0
		[Address(RVA = "0x3397108", Offset = "0x3397108", VA = "0x3397108", Slot = "16")]
		[Token(Token = "0x60035D2")]
		protected virtual Vector2 vmethod_11()
		{
			/*
An exception occurred when decompiling this method (060035D2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_11()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(9)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(74)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035D3 RID: 13779 RVA: 0x0006D7FC File Offset: 0x0006B9FC
		[Address(RVA = "0x33971AC", Offset = "0x33971AC", VA = "0x33971AC", Slot = "17")]
		[Token(Token = "0x60035D3")]
		protected virtual Vector2 vmethod_12()
		{
		}

		// Token: 0x060035D4 RID: 13780 RVA: 0x0006D80C File Offset: 0x0006BA0C
		[Address(RVA = "0x3397250", Offset = "0x3397250", VA = "0x3397250", Slot = "18")]
		[Token(Token = "0x60035D4")]
		protected virtual Vector2 vmethod_13()
		{
			/*
An exception occurred when decompiling this method (060035D4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_13()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(41)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(108)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035D5 RID: 13781 RVA: 0x0006D828 File Offset: 0x0006BA28
		[Token(Token = "0x60035D5")]
		[Address(RVA = "0x33972F0", Offset = "0x33972F0", VA = "0x33972F0", Slot = "19")]
		protected virtual Vector2 vmethod_14()
		{
		}

		// Token: 0x060035D6 RID: 13782 RVA: 0x0006D838 File Offset: 0x0006BA38
		[Address(RVA = "0x3397394", Offset = "0x3397394", VA = "0x3397394", Slot = "20")]
		[Token(Token = "0x60035D6")]
		protected virtual Vector2 vmethod_15()
		{
			/*
An exception occurred when decompiling this method (060035D6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_15()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(69)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035D7 RID: 13783 RVA: 0x0006D84C File Offset: 0x0006BA4C
		[Address(RVA = "0x3397438", Offset = "0x3397438", VA = "0x3397438", Slot = "11")]
		[Token(Token = "0x60035D7")]
		protected override bool vmethod_6()
		{
			if (this.bool_9)
			{
				Input.GetKeyDown(KeyCode.LeftShift);
				if (this.bool_9)
				{
					bool wasPressedThisFrame = Keyboard.<current>k__BackingField[Key.LeftShift].wasPressedThisFrame;
				}
			}
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_10)
			{
			}
			HexaXRInputs hexaXRInputs2 = this.hexaXRInputs_1;
			if (!hexaXRInputs2.bool_8)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060035D8 RID: 13784 RVA: 0x0006D8AC File Offset: 0x0006BAAC
		[Address(RVA = "0x3397510", Offset = "0x3397510", VA = "0x3397510", Slot = "21")]
		[Token(Token = "0x60035D8")]
		protected virtual Vector2 vmethod_16()
		{
			/*
An exception occurred when decompiling this method (060035D8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_16()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(76)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035D9 RID: 13785 RVA: 0x0006D8C0 File Offset: 0x0006BAC0
		[Address(RVA = "0x33975B4", Offset = "0x33975B4", VA = "0x33975B4", Slot = "8")]
		[Token(Token = "0x60035D9")]
		protected override float vmethod_3()
		{
			if (this.bool_9)
			{
				Input.GetKey(this.keyCode_0);
				if (this.bool_9)
				{
					Input.GetKey(this.keyCode_1);
				}
			}
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (!hexaXRInputs.bool_10 || hexaXRInputs.playerInputState_6 == null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x060035DA RID: 13786 RVA: 0x0006D914 File Offset: 0x0006BB14
		[Address(RVA = "0x3397680", Offset = "0x3397680", VA = "0x3397680", Slot = "22")]
		[Token(Token = "0x60035DA")]
		protected virtual Vector2 vmethod_17()
		{
			/*
An exception occurred when decompiling this method (060035DA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_17()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(85)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035DB RID: 13787 RVA: 0x0006D928 File Offset: 0x0006BB28
		[Address(RVA = "0x3397724", Offset = "0x3397724", VA = "0x3397724", Slot = "10")]
		[Token(Token = "0x60035DB")]
		protected override Vector2 vmethod_5()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_1;
			if (hexaXRInputs.playerInputState_6 == null)
			{
			}
			Vector2 zero = Vector2.zero;
			throw new NullReferenceException();
		}

		// Token: 0x060035DC RID: 13788 RVA: 0x0006D950 File Offset: 0x0006BB50
		[Address(RVA = "0x3397768", Offset = "0x3397768", VA = "0x3397768", Slot = "23")]
		[Token(Token = "0x60035DC")]
		protected virtual Vector2 vmethod_18()
		{
			/*
An exception occurred when decompiling this method (060035DC)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_18()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(111)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(93)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035DD RID: 13789 RVA: 0x0006D96C File Offset: 0x0006BB6C
		[Address(RVA = "0x339780C", Offset = "0x339780C", VA = "0x339780C", Slot = "24")]
		[Token(Token = "0x60035DD")]
		protected virtual Vector2 vmethod_19()
		{
			/*
An exception occurred when decompiling this method (060035DD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_19()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(68)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(89)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(22)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035DE RID: 13790 RVA: 0x0006D990 File Offset: 0x0006BB90
		[Address(RVA = "0x33978B0", Offset = "0x33978B0", VA = "0x33978B0", Slot = "25")]
		[Token(Token = "0x60035DE")]
		protected virtual Vector2 vmethod_20()
		{
			/*
An exception occurred when decompiling this method (060035DE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_20()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(92)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(53)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035DF RID: 13791 RVA: 0x0006D9AC File Offset: 0x0006BBAC
		[Address(RVA = "0x3397954", Offset = "0x3397954", VA = "0x3397954", Slot = "26")]
		[Token(Token = "0x60035DF")]
		protected virtual Vector2 vmethod_21()
		{
			/*
An exception occurred when decompiling this method (060035DF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_21()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(74)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(98)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060035E0 RID: 13792 RVA: 0x00067DF8 File Offset: 0x00065FF8
		[Address(RVA = "0x33979F8", Offset = "0x33979F8", VA = "0x33979F8", Slot = "27")]
		[Token(Token = "0x60035E0")]
		protected virtual Vector2 vmethod_22()
		{
			Input.GetKey(KeyCode.W);
			Input.GetKey(KeyCode.S);
			Input.GetKey(KeyCode.A);
			Input.GetKey(KeyCode.D);
			Vector2 result;
			return result;
		}

		// Token: 0x060035E1 RID: 13793 RVA: 0x0006D9C8 File Offset: 0x0006BBC8
		[Address(RVA = "0x3397A80", Offset = "0x3397A80", VA = "0x3397A80", Slot = "28")]
		[Token(Token = "0x60035E1")]
		protected virtual Vector2 vmethod_23()
		{
			/*
An exception occurred when decompiling this method (060035E1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector2 HexabodyVR.PlayerController.HexaBodyInputs::vmethod_23()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	call:bool(Input::GetKey, ldc.i4:KeyCode(13)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(67)); 	call:bool(Input::GetKey, ldc.i4:KeyCode(74)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x04000832 RID: 2098
		[Token(Token = "0x4000832")]
		[FieldOffset(Offset = "0x48")]
		public HexaXRInputs hexaXRInputs_0;

		// Token: 0x04000833 RID: 2099
		[Token(Token = "0x4000833")]
		[FieldOffset(Offset = "0x50")]
		public HexaXRInputs hexaXRInputs_1;

		// Token: 0x04000834 RID: 2100
		[Token(Token = "0x4000834")]
		[FieldOffset(Offset = "0x58")]
		public float float_2;

		// Token: 0x04000835 RID: 2101
		[Token(Token = "0x4000835")]
		[FieldOffset(Offset = "0x5C")]
		public float float_3;

		// Token: 0x04000836 RID: 2102
		[Token(Token = "0x4000836")]
		[FieldOffset(Offset = "0x60")]
		public bool bool_8;

		// Token: 0x04000837 RID: 2103
		[FieldOffset(Offset = "0x61")]
		[Token(Token = "0x4000837")]
		public bool bool_9;

		// Token: 0x04000838 RID: 2104
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x4000838")]
		public float float_4;

		// Token: 0x04000839 RID: 2105
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x4000839")]
		public KeyCode keyCode_0;

		// Token: 0x0400083A RID: 2106
		[FieldOffset(Offset = "0x6C")]
		[Token(Token = "0x400083A")]
		public KeyCode keyCode_1;

		// Token: 0x0400083B RID: 2107
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x400083B")]
		public KeyCode keyCode_2;

		// Token: 0x0400083C RID: 2108
		[Token(Token = "0x400083C")]
		[FieldOffset(Offset = "0x74")]
		public KeyCode keyCode_3;

		// Token: 0x0400083D RID: 2109
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x400083D")]
		public KeyCode keyCode_4;
	}
}
