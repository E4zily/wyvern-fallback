﻿using System;
using Cpp2IlInjected;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000164 RID: 356
	[Token(Token = "0x2000164")]
	[Serializable]
	public struct PlayerInputState
	{
		// Token: 0x0400095E RID: 2398
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400095E")]
		public bool Active;

		// Token: 0x0400095F RID: 2399
		[FieldOffset(Offset = "0x1")]
		[Token(Token = "0x400095F")]
		public bool JustActivated;

		// Token: 0x04000960 RID: 2400
		[Token(Token = "0x4000960")]
		[FieldOffset(Offset = "0x2")]
		public bool JustDeactivated;

		// Token: 0x04000961 RID: 2401
		[FieldOffset(Offset = "0x4")]
		[Token(Token = "0x4000961")]
		public float Value;
	}
}
