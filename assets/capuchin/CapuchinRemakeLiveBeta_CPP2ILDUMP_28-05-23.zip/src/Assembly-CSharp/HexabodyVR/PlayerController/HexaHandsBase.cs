﻿using System;
using System.Collections;
using System.Linq;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x0200015B RID: 347
	[Token(Token = "0x200015B")]
	public abstract class HexaHandsBase : MonoBehaviour
	{
		// Token: 0x170000DE RID: 222
		// (get) Token: 0x0600377A RID: 14202
		[Token(Token = "0x170000DE")]
		public abstract bool Boolean_0 { [Address(Slot = "4")] [Token(Token = "0x600377A")] get; }

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x0600377B RID: 14203 RVA: 0x0006FE10 File Offset: 0x0006E010
		[Token(Token = "0x170000DF")]
		public virtual float Single_1
		{
			[Address(RVA = "0x326ED04", Offset = "0x326ED04", VA = "0x326ED04", Slot = "5")]
			[Token(Token = "0x600377B")]
			get
			{
				HexaBodyPlayer4 exists = this.hexaBodyPlayer4_0;
				exists;
				HexaBodyPlayer4 hexaBodyPlayer = this.hexaBodyPlayer4_0;
				float single_ = hexaBodyPlayer.Single_9;
				float single_2 = hexaBodyPlayer.Single_7;
				throw new NullReferenceException();
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x0600377C RID: 14204 RVA: 0x0006EBBC File Offset: 0x0006CDBC
		[Token(Token = "0x170000E0")]
		public float Single_0
		{
			[Address(RVA = "0x326EDAC", Offset = "0x326EDAC", VA = "0x326EDAC")]
			[Token(Token = "0x600377C")]
			get
			{
				/*
An exception occurred when decompiling this method (0600377C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single HexabodyVR.PlayerController.HexaHandsBase::get_Single_0()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:Vector3(arg_05_0, callgetter:Vector3(Physics::get_gravity)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x0600377D RID: 14205 RVA: 0x00003527 File Offset: 0x00001727
		// (set) Token: 0x0600377E RID: 14206 RVA: 0x0000352F File Offset: 0x0000172F
		[Token(Token = "0x170000E1")]
		public Rigidbody Rigidbody_0 { [Address(RVA = "0x326EDF0", Offset = "0x326EDF0", VA = "0x326EDF0")] [Token(Token = "0x600377D")] get; [Address(RVA = "0x326EDF8", Offset = "0x326EDF8", VA = "0x326EDF8")] [Token(Token = "0x600377E")] private set; }

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x0600377F RID: 14207 RVA: 0x00003538 File Offset: 0x00001738
		// (set) Token: 0x06003780 RID: 14208 RVA: 0x00003540 File Offset: 0x00001740
		[Token(Token = "0x170000E2")]
		public ConfigurableJoint ConfigurableJoint_0 { [Token(Token = "0x600377F")] [Address(RVA = "0x326EE00", Offset = "0x326EE00", VA = "0x326EE00")] get; [Token(Token = "0x6003780")] [Address(RVA = "0x326EE08", Offset = "0x326EE08", VA = "0x326EE08")] protected set; }

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06003781 RID: 14209 RVA: 0x00003549 File Offset: 0x00001749
		[Token(Token = "0x170000E3")]
		public CollisionDetector CollisionDetector_0
		{
			[Token(Token = "0x6003781")]
			[Address(RVA = "0x326EE18", Offset = "0x326EE18", VA = "0x326EE18")]
			get
			{
				return this.collisionDetector_0;
			}
		}

		// Token: 0x06003782 RID: 14210 RVA: 0x0006FE48 File Offset: 0x0006E048
		[Token(Token = "0x6003782")]
		[Address(RVA = "0x326E374", Offset = "0x326E374", VA = "0x326E374", Slot = "6")]
		protected virtual void Awake()
		{
			bool flag;
			do
			{
				Rigidbody component = base.GetComponent<Rigidbody>();
				this.rigidbody_1 = component;
				this.method_1();
				Quaternion identity = Quaternion.identity;
				Rigidbody rigidbody = this.rigidbody_1;
				int solverVelocityIterations = this.int_1;
				rigidbody.solverVelocityIterations = solverVelocityIterations;
				this.hexaBodyPlayer4_0;
				base.transform.root.GetComponentInChildren<HexaBodyPlayer4>();
				this.hexaHandsBase_0;
				Func<HexaHandsBase, bool> func;
				HexaHandsBase hexaHandsBase = Enumerable.FirstOrDefault<HexaHandsBase>(base.transform.root.GetComponentsInChildren<HexaHandsBase>(), func);
				this.hexaHandsBase_0 = hexaHandsBase;
				flag = this.transform_2;
				if (!this.bool_2)
				{
					goto IL_9A;
				}
			}
			while (flag);
			return;
			IL_9A:
			HexaBodyPlayer3 componentInChildren = base.transform.root.GetComponentInChildren<HexaBodyPlayer3>();
			componentInChildren;
			Transform transform = componentInChildren.rigidbody_1.transform;
			Debug.LogWarning(base.name + " needs Pelvis transform assigned.");
			float num = this.float_2;
			Vector3 gravity = Physics.gravity;
			this.float_2 = num;
		}

		// Token: 0x06003783 RID: 14211 RVA: 0x0006FF44 File Offset: 0x0006E144
		[Address(RVA = "0x326EEC8", Offset = "0x326EEC8", VA = "0x326EEC8")]
		[Token(Token = "0x6003783")]
		private IEnumerator method_0()
		{
			HexaHandsBase.Class56 @class = new HexaHandsBase.Class56((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003784 RID: 14212 RVA: 0x0006FF6C File Offset: 0x0006E16C
		[Address(RVA = "0x326EE20", Offset = "0x326EE20", VA = "0x326EE20")]
		[Token(Token = "0x6003784")]
		public void method_1()
		{
			Quaternion rotation = this.rigidbody_0.rotation;
			Quaternion rotation2 = base.transform.rotation;
		}

		// Token: 0x06003785 RID: 14213 RVA: 0x0006FF94 File Offset: 0x0006E194
		[Token(Token = "0x6003785")]
		[Address(RVA = "0x326EF40", Offset = "0x326EF40", VA = "0x326EF40", Slot = "7")]
		protected virtual void vmethod_0()
		{
			ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
			this.configurableJoint_0 = configurableJoint;
			ConfigurableJoint configurableJoint2 = this.configurableJoint_0;
			Rigidbody connectedBody = this.rigidbody_1;
			configurableJoint2.connectedBody = connectedBody;
			ConfigurableJoint configurableJoint3 = this.configurableJoint_0;
			long autoConfigureConnectedAnchor = 0L;
			configurableJoint3.autoConfigureConnectedAnchor = (autoConfigureConnectedAnchor != 0L);
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
		}

		// Token: 0x06003786 RID: 14214 RVA: 0x00003551 File Offset: 0x00001751
		[Address(RVA = "0x326F034", Offset = "0x326F034", VA = "0x326F034", Slot = "8")]
		[Token(Token = "0x6003786")]
		protected virtual void FixedUpdate()
		{
			this.method_4();
			if (!this.bool_0 && !this.bool_1)
			{
				return;
			}
			this.method_2();
		}

		// Token: 0x06003787 RID: 14215 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003787")]
		[Address(RVA = "0x326F43C", Offset = "0x326F43C", VA = "0x326F43C", Slot = "9")]
		protected virtual void vmethod_1()
		{
		}

		// Token: 0x06003788 RID: 14216 RVA: 0x00035BFC File Offset: 0x00033DFC
		[Token(Token = "0x6003788")]
		[Address(RVA = "0x326F440", Offset = "0x326F440", VA = "0x326F440", Slot = "10")]
		protected virtual bool vmethod_2()
		{
		}

		// Token: 0x06003789 RID: 14217 RVA: 0x0006FFF4 File Offset: 0x0006E1F4
		[Address(RVA = "0x326F208", Offset = "0x326F208", VA = "0x326F208")]
		[Token(Token = "0x6003789")]
		private void method_2()
		{
			Vector3 position = base.transform.position;
			Vector3 normalized = this.transform_0.position.normalized;
			Vector3 position2 = base.transform.position;
			Vector3 position3 = this.transform_0.position;
			if (!this.bool_0)
			{
			}
		}

		// Token: 0x0600378A RID: 14218 RVA: 0x00070040 File Offset: 0x0006E240
		[Token(Token = "0x600378A")]
		[Address(RVA = "0x326F448", Offset = "0x326F448", VA = "0x326F448")]
		private void method_3(Class42<float> class42_4, float float_15, float float_16, float float_17, float float_18, ref float float_19, ref float float_20)
		{
			Mathf.Max(float_15, float_16);
			Mathf.Min(float_18, float_15);
			float fixedDeltaTime = Time.fixedDeltaTime;
			float fixedDeltaTime2 = Time.fixedDeltaTime;
		}

		// Token: 0x0600378B RID: 14219 RVA: 0x0007006C File Offset: 0x0006E26C
		[Address(RVA = "0x326F5AC", Offset = "0x326F5AC", VA = "0x326F5AC", Slot = "11")]
		[Token(Token = "0x600378B")]
		protected virtual bool vmethod_3(Vector3 vector3_1, float float_15)
		{
			Transform transform;
			Vector3 position = transform.position;
			throw new NullReferenceException();
		}

		// Token: 0x0600378C RID: 14220 RVA: 0x00070088 File Offset: 0x0006E288
		[Address(RVA = "0x326F738", Offset = "0x326F738", VA = "0x326F738", Slot = "12")]
		[Token(Token = "0x600378C")]
		protected virtual bool vmethod_4(Vector3 vector3_1, float float_15)
		{
			Vector3 gravity = Physics.gravity;
			throw new NullReferenceException();
		}

		// Token: 0x0600378D RID: 14221 RVA: 0x000700A0 File Offset: 0x0006E2A0
		[Address(RVA = "0x326F880", Offset = "0x326F880", VA = "0x326F880", Slot = "13")]
		[Token(Token = "0x600378D")]
		protected virtual void vmethod_5()
		{
			Vector3 position = this.rigidbody_1.position;
			Transform transform = this.transform_2;
			Vector3 normalized = transform.position.normalized;
			Vector3 position2 = transform.position;
			Vector3 position3 = transform.position;
			HexaHandsBase.smethod_1(this.collider_0);
			float[] values = new float[0];
			Mathf.Max(values);
			Vector3 position4 = this.rigidbody_1.position;
			Quaternion identity = Quaternion.identity;
			Vector3 position5 = this.rigidbody_1.position;
		}

		// Token: 0x0600378E RID: 14222 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326FD10", Offset = "0x326FD10", VA = "0x326FD10", Slot = "14")]
		[Token(Token = "0x600378E")]
		protected virtual void vmethod_6()
		{
		}

		// Token: 0x0600378F RID: 14223 RVA: 0x00035BFC File Offset: 0x00033DFC
		[Address(RVA = "0x326FD50", Offset = "0x326FD50", VA = "0x326FD50", Slot = "15")]
		[Token(Token = "0x600378F")]
		protected virtual GEnum21 vmethod_7()
		{
		}

		// Token: 0x06003790 RID: 14224 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326FD58", Offset = "0x326FD58", VA = "0x326FD58", Slot = "16")]
		[Token(Token = "0x6003790")]
		protected virtual void vmethod_8(GEnum21 genum21_1)
		{
		}

		// Token: 0x06003791 RID: 14225 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x326FD7C", Offset = "0x326FD7C", VA = "0x326FD7C", Slot = "17")]
		[Token(Token = "0x6003791")]
		protected virtual void vmethod_9(GEnum21 genum21_1, GEnum21 genum21_2)
		{
		}

		// Token: 0x06003792 RID: 14226 RVA: 0x00070114 File Offset: 0x0006E314
		[Address(RVA = "0x326FD80", Offset = "0x326FD80", VA = "0x326FD80", Slot = "18")]
		[Token(Token = "0x6003792")]
		protected virtual void vmethod_10()
		{
			Rigidbody rigidbody = this.rigidbody_0;
			Quaternion.Inverse(rigidbody.rotation);
			Quaternion rotation = this.transform_0.rotation;
		}

		// Token: 0x06003793 RID: 14227 RVA: 0x00070140 File Offset: 0x0006E340
		[Token(Token = "0x6003793")]
		[Address(RVA = "0x326F0AC", Offset = "0x326F0AC", VA = "0x326F0AC")]
		protected void method_4()
		{
			Transform transform = this.rigidbody_0.transform;
			Vector3 position = this.transform_0.position;
			Transform exists = this.transform_1;
			exists;
			Transform transform2 = this.rigidbody_0.transform;
			Vector3 position2 = this.transform_1.position;
		}

		// Token: 0x06003794 RID: 14228 RVA: 0x0007018C File Offset: 0x0006E38C
		[Address(RVA = "0x326FE30", Offset = "0x326FE30", VA = "0x326FE30", Slot = "19")]
		[Token(Token = "0x6003794")]
		protected virtual void vmethod_11()
		{
			Transform transform = base.transform;
			Vector3 position = this.transform_0.position;
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			float x;
			float y;
			float z;
			if (this.bool_2)
			{
				Vector3 up = Vector3.up;
				float fixedDeltaTime = Time.fixedDeltaTime;
				HexaBodyPlayer4 hexaBodyPlayer = this.hexaBodyPlayer4_0;
				x = hexaBodyPlayer.vector3_3.x;
				y = hexaBodyPlayer.vector3_3.y;
				z = hexaBodyPlayer.vector3_3.z;
				return;
			}
			float fixedDeltaTime2 = Time.fixedDeltaTime;
			Quaternion rotation = this.transform_0.rotation;
			Quaternion rotation2 = this.rigidbody_0.transform.rotation;
			Quaternion rotation3 = this.transform_0.rotation;
			this.quaternion_0.x = x;
			this.quaternion_0.y = y;
			this.quaternion_0.z = z;
		}

		// Token: 0x06003795 RID: 14229 RVA: 0x00070258 File Offset: 0x0006E458
		[Token(Token = "0x6003795")]
		[Address(RVA = "0x3270194", Offset = "0x3270194", VA = "0x3270194", Slot = "20")]
		protected virtual void vmethod_12(GEnum22 genum22_1)
		{
		}

		// Token: 0x06003796 RID: 14230
		[Address(Slot = "21")]
		[Token(Token = "0x6003796")]
		protected abstract void vmethod_13(GEnum22 genum22_1);

		// Token: 0x06003797 RID: 14231 RVA: 0x00070268 File Offset: 0x0006E468
		[Address(RVA = "0x32700B4", Offset = "0x32700B4", VA = "0x32700B4")]
		[Token(Token = "0x6003797")]
		public static Vector3 smethod_0(Quaternion quaternion_2, Quaternion quaternion_3)
		{
			/*
An exception occurred when decompiling this method (06003797)

ICSharpCode.Decompiler.DecompilerException: Error decompiling UnityEngine.Vector3 HexabodyVR.PlayerController.HexaHandsBase::smethod_0(UnityEngine.Quaternion,UnityEngine.Quaternion)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(arg_05_0, callgetter:float32(Time::get_fixedDeltaTime)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003798 RID: 14232 RVA: 0x0007027C File Offset: 0x0006E47C
		[Address(RVA = "0x326FC38", Offset = "0x326FC38", VA = "0x326FC38")]
		[Token(Token = "0x6003798")]
		public static Bounds smethod_1(Collider[] collider_1)
		{
			Bounds result;
			return result;
		}

		// Token: 0x06003799 RID: 14233 RVA: 0x0007028C File Offset: 0x0006E48C
		[Address(RVA = "0x326DCB4", Offset = "0x326DCB4", VA = "0x326DCB4")]
		[Token(Token = "0x6003799")]
		protected HexaHandsBase()
		{
			long intVal = 256L;
			this.float_0 = (float)16192;
			this.float_1 = (float)55050;
			this.float_10 = (float)17558;
			LayerMask layerMask = (int)intVal;
			this.layerMask_0 = layerMask;
			Class42<float> @class;
			this.class42_0 = @class;
			this.class42_1 = @class;
			Class42<float> class2;
			this.class42_2 = class2;
			Class42<float> class3;
			this.class42_3 = class3;
			base..ctor();
		}

		// Token: 0x0600379A RID: 14234 RVA: 0x00003570 File Offset: 0x00001770
		[CompilerGenerated]
		[Address(RVA = "0x32701B8", Offset = "0x32701B8", VA = "0x32701B8")]
		[Token(Token = "0x600379A")]
		private bool method_5(HexaHandsBase hexaHandsBase_1)
		{
			return hexaHandsBase_1 != this;
		}

		// Token: 0x04000919 RID: 2329
		[Token(Token = "0x4000919")]
		[FieldOffset(Offset = "0x18")]
		public Rigidbody rigidbody_0;

		// Token: 0x0400091A RID: 2330
		[Token(Token = "0x400091A")]
		[FieldOffset(Offset = "0x20")]
		public Transform transform_0;

		// Token: 0x0400091B RID: 2331
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400091B")]
		public Transform transform_1;

		// Token: 0x0400091C RID: 2332
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400091C")]
		public HexaHandsBase hexaHandsBase_0;

		// Token: 0x0400091D RID: 2333
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400091D")]
		public HexaBodyPlayer4 hexaBodyPlayer4_0;

		// Token: 0x0400091E RID: 2334
		[Token(Token = "0x400091E")]
		[FieldOffset(Offset = "0x40")]
		public Transform transform_2;

		// Token: 0x0400091F RID: 2335
		[Token(Token = "0x400091F")]
		[FieldOffset(Offset = "0x48")]
		public float float_0;

		// Token: 0x04000920 RID: 2336
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x4000920")]
		public int int_0;

		// Token: 0x04000921 RID: 2337
		[Token(Token = "0x4000921")]
		[FieldOffset(Offset = "0x50")]
		public int int_1;

		// Token: 0x04000922 RID: 2338
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x4000922")]
		public float float_1;

		// Token: 0x04000923 RID: 2339
		[Token(Token = "0x4000923")]
		[FieldOffset(Offset = "0x58")]
		public bool bool_0;

		// Token: 0x04000924 RID: 2340
		[Token(Token = "0x4000924")]
		[FieldOffset(Offset = "0x5C")]
		public float float_2;

		// Token: 0x04000925 RID: 2341
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x4000925")]
		public float float_3;

		// Token: 0x04000926 RID: 2342
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x4000926")]
		public float float_4;

		// Token: 0x04000927 RID: 2343
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x4000927")]
		public float float_5;

		// Token: 0x04000928 RID: 2344
		[Token(Token = "0x4000928")]
		[FieldOffset(Offset = "0x6C")]
		public bool bool_1;

		// Token: 0x04000929 RID: 2345
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4000929")]
		public float float_6;

		// Token: 0x0400092A RID: 2346
		[FieldOffset(Offset = "0x74")]
		[Token(Token = "0x400092A")]
		public float float_7;

		// Token: 0x0400092B RID: 2347
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x400092B")]
		public float float_8;

		// Token: 0x0400092C RID: 2348
		[FieldOffset(Offset = "0x7C")]
		[Token(Token = "0x400092C")]
		public float float_9;

		// Token: 0x0400092D RID: 2349
		[Token(Token = "0x400092D")]
		[FieldOffset(Offset = "0x80")]
		public float float_10;

		// Token: 0x0400092E RID: 2350
		[FieldOffset(Offset = "0x84")]
		[Token(Token = "0x400092E")]
		public LayerMask layerMask_0;

		// Token: 0x0400092F RID: 2351
		[Token(Token = "0x400092F")]
		[FieldOffset(Offset = "0x88")]
		public Collider[] collider_0;

		// Token: 0x04000930 RID: 2352
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000930")]
		public GEnum21 genum21_0;

		// Token: 0x04000931 RID: 2353
		[Token(Token = "0x4000931")]
		[FieldOffset(Offset = "0x94")]
		public GEnum22 genum22_0;

		// Token: 0x04000932 RID: 2354
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x4000932")]
		public float float_11;

		// Token: 0x04000933 RID: 2355
		[FieldOffset(Offset = "0x9C")]
		[Token(Token = "0x4000933")]
		public float float_12;

		// Token: 0x04000934 RID: 2356
		[Token(Token = "0x4000934")]
		[FieldOffset(Offset = "0xA0")]
		public float float_13;

		// Token: 0x04000935 RID: 2357
		[Token(Token = "0x4000935")]
		[FieldOffset(Offset = "0xA4")]
		public float float_14;

		// Token: 0x04000936 RID: 2358
		[Token(Token = "0x4000936")]
		[FieldOffset(Offset = "0xA8")]
		private Vector3 vector3_0;

		// Token: 0x04000937 RID: 2359
		[FieldOffset(Offset = "0xB4")]
		[Token(Token = "0x4000937")]
		private Quaternion quaternion_0;

		// Token: 0x04000938 RID: 2360
		[FieldOffset(Offset = "0xC4")]
		[Token(Token = "0x4000938")]
		private Quaternion quaternion_1;

		// Token: 0x04000939 RID: 2361
		[Token(Token = "0x4000939")]
		[FieldOffset(Offset = "0xD4")]
		private bool bool_2;

		// Token: 0x0400093A RID: 2362
		[Token(Token = "0x400093A")]
		[FieldOffset(Offset = "0xD8")]
		private readonly Class42<float> class42_0;

		// Token: 0x0400093B RID: 2363
		[Token(Token = "0x400093B")]
		[FieldOffset(Offset = "0xE0")]
		private readonly Class42<float> class42_1;

		// Token: 0x0400093C RID: 2364
		[Token(Token = "0x400093C")]
		[FieldOffset(Offset = "0xE8")]
		private readonly Class42<float> class42_2;

		// Token: 0x0400093D RID: 2365
		[FieldOffset(Offset = "0xF0")]
		[Token(Token = "0x400093D")]
		private readonly Class42<float> class42_3;

		// Token: 0x0400093E RID: 2366
		[CompilerGenerated]
		[Token(Token = "0x400093E")]
		[FieldOffset(Offset = "0xF8")]
		private Rigidbody rigidbody_1;

		// Token: 0x0400093F RID: 2367
		[CompilerGenerated]
		[Token(Token = "0x400093F")]
		[FieldOffset(Offset = "0x100")]
		private ConfigurableJoint configurableJoint_0;

		// Token: 0x04000940 RID: 2368
		[Token(Token = "0x4000940")]
		[FieldOffset(Offset = "0x108")]
		private CollisionDetector collisionDetector_0;
	}
}
