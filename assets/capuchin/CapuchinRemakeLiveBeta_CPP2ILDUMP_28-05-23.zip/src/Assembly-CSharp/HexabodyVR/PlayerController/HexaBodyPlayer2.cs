﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000144 RID: 324
	[Token(Token = "0x2000144")]
	public class HexaBodyPlayer2 : MonoBehaviour
	{
		// Token: 0x060034A5 RID: 13477 RVA: 0x00068E70 File Offset: 0x00067070
		[Address(RVA = "0x339BC48", Offset = "0x339BC48", VA = "0x339BC48")]
		[Token(Token = "0x60034A5")]
		private void method_0()
		{
			float num = this.float_8;
			this.float_49 = num;
			this.rigidbody_1.transform.position.Normalize();
			Transform transform = this.rigidbody_1.transform;
			Transform transform2 = this.transform_1;
			Vector3 localPosition = transform2.localPosition;
			Rigidbody rigidbody = this.rigidbody_1;
			Transform transform3 = rigidbody.transform;
		}

		// Token: 0x060034A6 RID: 13478 RVA: 0x00003261 File Offset: 0x00001461
		[Address(RVA = "0x339BDB0", Offset = "0x339BDB0", VA = "0x339BDB0")]
		[Token(Token = "0x60034A6")]
		public void method_1(bool bool_6)
		{
			this.method_3();
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060034D1 RID: 13521 RVA: 0x00003282 File Offset: 0x00001482
		// (set) Token: 0x060034A7 RID: 13479 RVA: 0x00003269 File Offset: 0x00001469
		[Token(Token = "0x1700009F")]
		public HexaBodyPlayerInputs HexaBodyPlayerInputs_0 { [Token(Token = "0x60034D1")] [Address(RVA = "0x339E37C", Offset = "0x339E37C", VA = "0x339E37C")] get; [Address(RVA = "0x339BE08", Offset = "0x339BE08", VA = "0x339BE08")] [Token(Token = "0x60034A7")] private set; }

		// Token: 0x060034A8 RID: 13480 RVA: 0x00068ECC File Offset: 0x000670CC
		[Token(Token = "0x60034A8")]
		[Address(RVA = "0x339BE18", Offset = "0x339BE18", VA = "0x339BE18")]
		public HexaBodyPlayer2()
		{
			long num = 2L;
			this.genum16_0 = (GEnum16)num;
			this.float_28 = (float)16000;
			long num2 = 1073741824L;
			this.float_32 = (float)num2;
			this.float_33 = (float)31457;
			this.float_50 = (float)39322;
			base..ctor();
		}

		// Token: 0x060034A9 RID: 13481 RVA: 0x00068F24 File Offset: 0x00067124
		[Address(RVA = "0x339BEF0", Offset = "0x339BEF0", VA = "0x339BEF0")]
		[Token(Token = "0x60034A9")]
		private void method_2(Vector3 vector3_7)
		{
		}

		// Token: 0x060034AA RID: 13482 RVA: 0x00068F34 File Offset: 0x00067134
		[Token(Token = "0x60034AA")]
		[Address(RVA = "0x339BDD0", Offset = "0x339BDD0", VA = "0x339BDD0")]
		public void method_3()
		{
			Vector3 localPosition = this.transform_0.localPosition;
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060034AB RID: 13483 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		// (set) Token: 0x060034B4 RID: 13492 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000A0")]
		public Vector3 Vector3_0
		{
			[Address(RVA = "0x339C068", Offset = "0x339C068", VA = "0x339C068")]
			[CompilerGenerated]
			[Token(Token = "0x60034AB")]
			get
			{
				Vector3 result;
				return result;
			}
			[CompilerGenerated]
			[Address(RVA = "0x339C498", Offset = "0x339C498", VA = "0x339C498")]
			[Token(Token = "0x60034B4")]
			private set
			{
			}
		}

		// Token: 0x060034AC RID: 13484 RVA: 0x00068F50 File Offset: 0x00067150
		[Address(RVA = "0x339C078", Offset = "0x339C078", VA = "0x339C078")]
		[Token(Token = "0x60034AC")]
		private void method_4(bool bool_6)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius;
			sphereCollider.radius = radius;
		}

		// Token: 0x060034AD RID: 13485 RVA: 0x00068F6C File Offset: 0x0006716C
		[Address(RVA = "0x339C110", Offset = "0x339C110", VA = "0x339C110")]
		[Token(Token = "0x60034AD")]
		private IEnumerator method_5()
		{
			HexaBodyPlayer2.Class47 @class = new HexaBodyPlayer2.Class47((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060034AE RID: 13486 RVA: 0x00068F94 File Offset: 0x00067194
		[Address(RVA = "0x339C188", Offset = "0x339C188", VA = "0x339C188")]
		[Token(Token = "0x60034AE")]
		private void method_6(bool bool_6)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x060034AF RID: 13487 RVA: 0x00068FCC File Offset: 0x000671CC
		[Address(RVA = "0x339C220", Offset = "0x339C220", VA = "0x339C220")]
		[Token(Token = "0x60034AF")]
		private void method_7(GEnum16 genum16_1)
		{
			this._crouchLevel = genum16_1;
			float float_ = this.method_38(genum16_1);
			this.method_33(float_);
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060034B0 RID: 13488 RVA: 0x00068FF0 File Offset: 0x000671F0
		[Token(Token = "0x170000A3")]
		public float Single_0
		{
			[Address(RVA = "0x339C358", Offset = "0x339C358", VA = "0x339C358")]
			[Token(Token = "0x60034B0")]
			get
			{
				Transform transform = this.transform_0;
				Vector3 localPosition = transform.localPosition;
				throw new NullReferenceException();
			}
		}

		// Token: 0x060034B1 RID: 13489 RVA: 0x00069010 File Offset: 0x00067210
		[Address(RVA = "0x339C24C", Offset = "0x339C24C", VA = "0x339C24C")]
		[Token(Token = "0x60034B1")]
		private void method_8(GEnum16 genum16_1)
		{
			this._crouchLevel = genum16_1;
			this.method_38(genum16_1);
		}

		// Token: 0x060034B2 RID: 13490 RVA: 0x00067DF8 File Offset: 0x00065FF8
		[Address(RVA = "0x339C400", Offset = "0x339C400", VA = "0x339C400")]
		[Token(Token = "0x60034B2")]
		private Vector2 method_9()
		{
			Input.GetKey(KeyCode.W);
			Input.GetKey(KeyCode.S);
			Input.GetKey(KeyCode.A);
			Input.GetKey(KeyCode.D);
			Vector2 result;
			return result;
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060034B3 RID: 13491 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		// (set) Token: 0x060034CA RID: 13514 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000A1")]
		public Vector3 Vector3_1
		{
			[CompilerGenerated]
			[Address(RVA = "0x339C488", Offset = "0x339C488", VA = "0x339C488")]
			[Token(Token = "0x60034B3")]
			get
			{
				Vector3 result;
				return result;
			}
			[Address(RVA = "0x339E0F0", Offset = "0x339E0F0", VA = "0x339E0F0")]
			[CompilerGenerated]
			[Token(Token = "0x60034CA")]
			private set
			{
			}
		}

		// Token: 0x060034B5 RID: 13493 RVA: 0x0006902C File Offset: 0x0006722C
		[Address(RVA = "0x339C4A8", Offset = "0x339C4A8", VA = "0x339C4A8")]
		[Token(Token = "0x60034B5")]
		public void method_10(float float_59)
		{
			GEnum18 genum = this.genum18_0;
			if (genum != GEnum18.const_0)
			{
				return;
			}
		}

		// Token: 0x060034B6 RID: 13494 RVA: 0x00069044 File Offset: 0x00067244
		[Address(RVA = "0x339C508", Offset = "0x339C508", VA = "0x339C508", Slot = "4")]
		[Token(Token = "0x60034B6")]
		protected virtual void vmethod_0()
		{
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_2)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					if (hexaBodyPlayerInputs == null)
					{
						return;
					}
				}
				else if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_2)
					{
						long num = 1L;
						this.bool_3 = (num != 0L);
						return;
					}
					long num2 = 1L;
					this.bool_2 = (num2 != 0L);
				}
			}
			else
			{
				bool flag2 = this.bool_3;
				HexaBodyPlayerInputs hexaBodyPlayerInputs;
				bool flag3 = hexaBodyPlayerInputs.bool_2;
				long num;
				if (flag2)
				{
					if (flag3)
					{
						return;
					}
				}
				else if (num != 0L)
				{
					long num3 = 1L;
					this.bool_3 = (num3 != 0L);
					return;
				}
			}
		}

		// Token: 0x060034B7 RID: 13495 RVA: 0x000690D8 File Offset: 0x000672D8
		[Address(RVA = "0x339C5F8", Offset = "0x339C5F8", VA = "0x339C5F8")]
		[Token(Token = "0x60034B7")]
		private void method_11()
		{
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = Vector3.up;
			float defaultContactOffset = Physics.defaultContactOffset;
			float radius = this.sphereCollider_0.radius;
			float defaultContactOffset2 = Physics.defaultContactOffset;
			Vector3 down = Vector3.down;
			LayerMask mask = this.layerMask_0;
			mask;
			Vector3 up2 = Vector3.up;
			Vector3 up3 = Vector3.up;
		}

		// Token: 0x060034B8 RID: 13496 RVA: 0x00069134 File Offset: 0x00067334
		[Address(RVA = "0x339C7BC", Offset = "0x339C7BC", VA = "0x339C7BC")]
		[Token(Token = "0x60034B8")]
		private void FixedUpdate()
		{
			Vector3 velocity = this.rigidbody_1.velocity;
			float magnitude = this.rigidbody_1.velocity.magnitude;
			this.method_16();
			this.method_11();
			this.method_21();
			this.method_28();
			this.method_31();
			this.method_0();
		}

		// Token: 0x060034B9 RID: 13497 RVA: 0x00069184 File Offset: 0x00067384
		[Address(RVA = "0x339D0E8", Offset = "0x339D0E8", VA = "0x339D0E8")]
		[Token(Token = "0x60034B9")]
		private IEnumerator method_12(float float_59)
		{
			HexaBodyPlayer2.Class46 @class = new HexaBodyPlayer2.Class46((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060034BA RID: 13498 RVA: 0x000691AC File Offset: 0x000673AC
		[Address(RVA = "0x339D170", Offset = "0x339D170", VA = "0x339D170")]
		[Token(Token = "0x60034BA")]
		private bool method_13()
		{
			this.method_35();
			float z = this.vector3_0.z;
			Transform transform = this.transform_1;
			this.vector3_1.z = z;
			Vector3 position = transform.transform.position;
			float magnitude = this.rigidbody_1.transform.position.normalized.magnitude;
			Vector3 position2 = this.rigidbody_0.position;
			Vector3 position3 = this.rigidbody_2.position;
			Vector3 position4 = this.rigidbody_3.position;
			Vector3 position5 = this.rigidbody_1.position;
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			Vector3 localPosition = this.hexaCameraRig_0.transform.localPosition;
			Transform transform2 = this.rigidbody_1.transform;
			throw new NullReferenceException();
		}

		// Token: 0x060034BB RID: 13499 RVA: 0x00069268 File Offset: 0x00067468
		[Token(Token = "0x60034BB")]
		[Address(RVA = "0x339D4F8", Offset = "0x339D4F8", VA = "0x339D4F8")]
		private void method_14()
		{
			if (this.hexaBodyPlayerInputs_0.bool_3)
			{
				this.method_3();
			}
			float num = this.float_8;
			float radius = this.sphereCollider_0.radius;
			Rigidbody rigidbody = this.rigidbody_1;
			this.float_38 = num;
			Vector3 position = rigidbody.position;
			Vector3 position2 = this.rigidbody_0.position;
			float num2 = this.float_38;
			this._crouchPercent = num2;
			Mathf.Clamp01(radius);
			Rigidbody rigidbody2 = this.rigidbody_1;
			this._crouchPercent = num2;
			Vector3 position3 = rigidbody2.position;
			Vector3 position4 = this.rigidbody_0.position;
			this.float_36 = num2;
			this.method_39();
			this.method_32();
			this.method_22();
			Transform transform = this.transform_5;
			Vector3 position5 = transform.position;
			Vector3 position6 = this.rigidbody_3.position;
			Vector3 position7 = this.transform_5.position;
			Rigidbody rigidbody3 = this.rigidbody_3;
			CapsuleCollider capsuleCollider = this.capsuleCollider_2;
			Vector3 position8 = rigidbody3.position;
			Vector3 position9 = this.transform_5.position;
			float height;
			capsuleCollider.height = height;
			Vector3 position10 = this.rigidbody_3.position;
			Vector3 position11 = this.transform_3.position;
			Vector3 up = this.transform_3.up;
			Transform transform2 = this.transform_3.transform;
			Quaternion rotation = this.transform_3.transform.rotation;
			float magnitude = this.rigidbody_0.angularVelocity.magnitude;
			this._locoAngularVelocity = num2;
		}

		// Token: 0x060034BC RID: 13500 RVA: 0x00068F24 File Offset: 0x00067124
		[Address(RVA = "0x339DBAC", Offset = "0x339DBAC", VA = "0x339DBAC")]
		[Token(Token = "0x60034BC")]
		private void method_15(Vector3 vector3_7)
		{
		}

		// Token: 0x060034BD RID: 13501 RVA: 0x000693C0 File Offset: 0x000675C0
		[Address(RVA = "0x339C858", Offset = "0x339C858", VA = "0x339C858")]
		[Token(Token = "0x60034BD")]
		private void method_16()
		{
			Vector3 localPosition = this.transform_0.localPosition;
			float fixedDeltaTime = Time.fixedDeltaTime;
			Vector3 localPosition2 = this.transform_0.localPosition;
			Rigidbody rigidbody = this.rigidbody_0;
			Vector3 position = rigidbody.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			if (this._legStage == GEnum17.const_0)
			{
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				float y;
				if (hexaBodyPlayerInputs.playerInputState_0 != null)
				{
					y = this.float_32;
					return;
				}
				this.vector3_4.y = y;
				if (hexaBodyPlayerInputs.playerInputState_1 != null)
				{
					float y2 = this.float_30;
					this.vector3_3.y = y2;
					return;
				}
				if (hexaBodyPlayerInputs.playerInputState_2 != null)
				{
					float y3 = this.float_30;
					this.vector3_3.y = y3;
					return;
				}
				if (hexaBodyPlayerInputs.playerInputState_0 == null)
				{
				}
			}
			Rigidbody rigidbody2 = this.rigidbody_1;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			Vector3 position2 = rigidbody2.position;
			Vector3 position3 = this.rigidbody_0.position;
			float height;
			capsuleCollider.height = height;
			float height2 = this.capsuleCollider_0.height;
			JointDrive yDrive = this.configurableJoint_0.yDrive;
			yDrive.positionSpring = height2;
			yDrive.positionDamper = height2;
			yDrive.maximumForce = height2;
		}

		// Token: 0x060034BE RID: 13502 RVA: 0x00003272 File Offset: 0x00001472
		[Token(Token = "0x60034BE")]
		[Address(RVA = "0x339DC30", Offset = "0x339DC30", VA = "0x339DC30")]
		public bool method_17()
		{
			return this.bool_4;
		}

		// Token: 0x060034BF RID: 13503 RVA: 0x000694E0 File Offset: 0x000676E0
		[Address(RVA = "0x339DC38", Offset = "0x339DC38", VA = "0x339DC38")]
		[Token(Token = "0x60034BF")]
		private IEnumerator method_18()
		{
			HexaBodyPlayer2.Class48 @class = new HexaBodyPlayer2.Class48((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060034C0 RID: 13504 RVA: 0x00069508 File Offset: 0x00067708
		[Address(RVA = "0x339BF74", Offset = "0x339BF74", VA = "0x339BF74")]
		[Token(Token = "0x60034C0")]
		private void method_19(Rigidbody rigidbody_4, Vector3 vector3_7)
		{
			Vector3 velocity = rigidbody_4.velocity;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060034C1 RID: 13505 RVA: 0x00069524 File Offset: 0x00067724
		[Address(RVA = "0x339DCB0", Offset = "0x339DCB0", VA = "0x339DCB0", Slot = "5")]
		[Token(Token = "0x60034C1")]
		protected virtual void vmethod_1()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_2)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_3;
				hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					if (hexaBodyPlayerInputs == null)
					{
						return;
					}
				}
				else if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_2)
					{
						long num = 1L;
						this.bool_3 = (num != 0L);
						return;
					}
					long num2 = 1L;
					this.float_57 = (float)16384;
					this.bool_2 = (num2 != 0L);
				}
			}
			else if (hexaBodyPlayerInputs.bool_2)
			{
				long num3 = 1L;
				this.bool_3 = (num3 != 0L);
				return;
			}
		}

		// Token: 0x060034C2 RID: 13506 RVA: 0x000695B0 File Offset: 0x000677B0
		[Token(Token = "0x60034C2")]
		[Address(RVA = "0x339DD98", Offset = "0x339DD98", VA = "0x339DD98")]
		private void method_20()
		{
			if (this.bool_1 && this.bool_4)
			{
				IEnumerator routine = this.method_5();
				base.StartCoroutine(routine);
				return;
			}
		}

		// Token: 0x060034C3 RID: 13507 RVA: 0x000695E0 File Offset: 0x000677E0
		[Address(RVA = "0x339CB48", Offset = "0x339CB48", VA = "0x339CB48")]
		[Token(Token = "0x60034C3")]
		private void method_21()
		{
			if (this.bool_1 && this.bool_4)
			{
				this.method_5();
				return;
			}
		}

		// Token: 0x060034C4 RID: 13508 RVA: 0x00069608 File Offset: 0x00067808
		[Address(RVA = "0x339DB28", Offset = "0x339DB28", VA = "0x339DB28")]
		[Token(Token = "0x60034C4")]
		private void method_22()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 right = this.transform_0.right;
			if (this.hexaBodyPlayerInputs_0.playerInputState_0.JustDeactivated && this.bool_4)
			{
				long num = 1L;
				this.bool_1 = (num != 0L);
			}
		}

		// Token: 0x060034C5 RID: 13509 RVA: 0x00069184 File Offset: 0x00067384
		[Address(RVA = "0x339DDE8", Offset = "0x339DDE8", VA = "0x339DDE8")]
		[Token(Token = "0x60034C5")]
		private IEnumerator method_23(float float_59)
		{
			HexaBodyPlayer2.Class46 @class = new HexaBodyPlayer2.Class46((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x060034C6 RID: 13510 RVA: 0x00069650 File Offset: 0x00067850
		[Address(RVA = "0x339DE70", Offset = "0x339DE70", VA = "0x339DE70")]
		[Token(Token = "0x60034C6")]
		private void method_24()
		{
			Vector3 position = this.rigidbody_0.position;
			Vector3 up = Vector3.up;
			float defaultContactOffset = Physics.defaultContactOffset;
			float radius = this.sphereCollider_0.radius;
			float defaultContactOffset2 = Physics.defaultContactOffset;
			Vector3 down = Vector3.down;
			this.layerMask_0;
			Vector3 up2 = Vector3.up;
			Vector3 up3 = Vector3.up;
		}

		// Token: 0x060034C7 RID: 13511 RVA: 0x00068F94 File Offset: 0x00067194
		[Address(RVA = "0x339E034", Offset = "0x339E034", VA = "0x339E034")]
		[Token(Token = "0x60034C7")]
		private void method_25(bool bool_6)
		{
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius = this.capsuleCollider_0.radius;
			sphereCollider.radius = radius;
			CapsuleCollider capsuleCollider = this.capsuleCollider_0;
			float radius2 = capsuleCollider.radius;
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060034C8 RID: 13512 RVA: 0x0006797C File Offset: 0x00065B7C
		// (set) Token: 0x060034D8 RID: 13528 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x1700009E")]
		public Quaternion Quaternion_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x339E0CC", Offset = "0x339E0CC", VA = "0x339E0CC")]
			[Token(Token = "0x60034C8")]
			get
			{
			}
			[CompilerGenerated]
			[Token(Token = "0x60034D8")]
			[Address(RVA = "0x339E594", Offset = "0x339E594", VA = "0x339E594")]
			private set
			{
			}
		}

		// Token: 0x060034C9 RID: 13513 RVA: 0x00003269 File Offset: 0x00001469
		[Address(RVA = "0x339E0E0", Offset = "0x339E0E0", VA = "0x339E0E0")]
		[Token(Token = "0x60034C9")]
		private void method_26(HexaBodyPlayerInputs hexaBodyPlayerInputs_1)
		{
			this.hexaBodyPlayerInputs_0 = hexaBodyPlayerInputs_1;
		}

		// Token: 0x060034CB RID: 13515 RVA: 0x000696A8 File Offset: 0x000678A8
		[Token(Token = "0x60034CB")]
		[Address(RVA = "0x339E100", Offset = "0x339E100", VA = "0x339E100", Slot = "6")]
		protected virtual void vmethod_2()
		{
			HexaBodyPlayerInputs hexaBodyPlayerInputs;
			if (this.hexaBodyPlayerInputs_0.bool_1)
			{
				if (this.bool_2)
				{
					float deltaTime = Time.deltaTime;
				}
				bool flag = this.bool_3;
				hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (flag)
				{
					if (hexaBodyPlayerInputs == null)
					{
						return;
					}
				}
				else if (hexaBodyPlayerInputs.bool_2)
				{
					if (this.bool_2)
					{
						long num = 1L;
						this.bool_3 = (num != 0L);
						this.bool_2 = (num != 0L);
						return;
					}
					this.float_57 = (float)40960;
				}
			}
			else if (hexaBodyPlayerInputs.bool_2)
			{
				long num2 = 1L;
				this.bool_3 = (num2 != 0L);
				return;
			}
		}

		// Token: 0x060034CC RID: 13516 RVA: 0x00069730 File Offset: 0x00067930
		[Address(RVA = "0x339E1E8", Offset = "0x339E1E8", VA = "0x339E1E8")]
		[Token(Token = "0x60034CC")]
		private void method_27()
		{
		}

		// Token: 0x060034CD RID: 13517 RVA: 0x00069740 File Offset: 0x00067940
		[Address(RVA = "0x339CB98", Offset = "0x339CB98", VA = "0x339CB98")]
		[Token(Token = "0x60034CD")]
		private void method_28()
		{
			float magnitude = this.method_9().magnitude;
			if (this.bool_4)
			{
			}
			Vector3 up = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized;
			AnimationCurve animationCurve = this.animationCurve_0;
			float time;
			animationCurve.Evaluate(time);
			float time2 = this.animationCurve_3.Evaluate(time);
			float radius = this.sphereCollider_0.radius;
			float time3 = this.animationCurve_2.Evaluate(time);
			AnimationCurve animationCurve2 = this.animationCurve_1;
			animationCurve2.Evaluate(time3);
			SphereCollider sphereCollider = this.sphereCollider_0;
			float radius2 = sphereCollider.radius;
			Vector3 angularVelocity = this.rigidbody_0.angularVelocity;
			if (this.bool_4)
			{
				Vector3 angularVelocity2 = this.rigidbody_0.angularVelocity;
			}
			this.method_13();
			Rigidbody rigidbody = this.rigidbody_0;
			long freezeRotation = 0L;
			rigidbody.freezeRotation = (freezeRotation != 0L);
			if (this.bool_4)
			{
				Vector3 angularVelocity3 = this.rigidbody_0.angularVelocity;
				float magnitude2 = this.rigidbody_0.angularVelocity.magnitude;
				Rigidbody rigidbody2 = this.rigidbody_0;
				long freezeRotation2 = 1L;
				rigidbody2.freezeRotation = (freezeRotation2 != 0L);
			}
			this.animationCurve_3.Evaluate(time2);
			float time4 = this.animationCurve_2.Evaluate(time2);
			AnimationCurve animationCurve3 = this.animationCurve_1;
			float crouchPercent = this._crouchPercent;
			animationCurve3.Evaluate(time4);
			this._modifiedTargetAcceleration = crouchPercent;
		}

		// Token: 0x060034CE RID: 13518 RVA: 0x00069880 File Offset: 0x00067A80
		[Token(Token = "0x60034CE")]
		[Address(RVA = "0x339E22C", Offset = "0x339E22C", VA = "0x339E22C")]
		private void method_29()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 right = this.transform_0.right;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060034CF RID: 13519 RVA: 0x0000327A File Offset: 0x0000147A
		// (set) Token: 0x060034D2 RID: 13522 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x1700009D")]
		public bool Boolean_0
		{
			[CompilerGenerated]
			[Token(Token = "0x60034CF")]
			[Address(RVA = "0x339E2B0", Offset = "0x339E2B0", VA = "0x339E2B0")]
			get
			{
				return this.bool_3;
			}
			[Address(RVA = "0x339E384", Offset = "0x339E384", VA = "0x339E384")]
			[Token(Token = "0x60034D2")]
			[CompilerGenerated]
			set
			{
			}
		}

		// Token: 0x060034D0 RID: 13520 RVA: 0x000698B0 File Offset: 0x00067AB0
		[Token(Token = "0x60034D0")]
		[Address(RVA = "0x339E2B8", Offset = "0x339E2B8", VA = "0x339E2B8")]
		private void Start()
		{
			HexaBodyPlayerInputs component = base.GetComponent<HexaBodyPlayerInputs>();
			this.hexaBodyPlayerInputs_0 = component;
			float radius = this.sphereCollider_0.radius;
			float radius2 = this.sphereCollider_1.radius;
			float mass = this.rigidbody_0.mass;
			float mass2 = this.rigidbody_2.mass;
			this.method_37(mass2);
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060034D3 RID: 13523 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x170000A4")]
		public float Single_1
		{
			[Address(RVA = "0x339E390", Offset = "0x339E390", VA = "0x339E390")]
			[Token(Token = "0x60034D3")]
			get
			{
			}
		}

		// Token: 0x060034D4 RID: 13524 RVA: 0x00069904 File Offset: 0x00067B04
		[Token(Token = "0x60034D4")]
		[Address(RVA = "0x339E398", Offset = "0x339E398", VA = "0x339E398")]
		private void method_30()
		{
			float num = this.float_8;
			Transform transform = this.transform_0;
			this.float_49 = num;
			Vector3 position = transform.position;
			this.rigidbody_1.transform.position.Normalize();
			Transform transform2 = this.rigidbody_1.transform;
			Transform transform3 = this.transform_1;
			Vector3 localPosition = transform3.localPosition;
			Rigidbody rigidbody = this.rigidbody_1;
			Transform transform4 = rigidbody.transform;
		}

		// Token: 0x060034D5 RID: 13525 RVA: 0x00069970 File Offset: 0x00067B70
		[Token(Token = "0x60034D5")]
		[Address(RVA = "0x339CF88", Offset = "0x339CF88", VA = "0x339CF88")]
		private void method_31()
		{
			if (this.bool_0)
			{
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (hexaBodyPlayerInputs != null)
				{
				}
				Vector3 up = Vector3.up;
				return;
			}
			if (!this.bool_5)
			{
				HexaBodyPlayerInputs hexaBodyPlayerInputs2 = this.hexaBodyPlayerInputs_0;
				float x = hexaBodyPlayerInputs2.vector2_1.x;
				if (hexaBodyPlayerInputs2 != null)
				{
				}
				float float_;
				IEnumerator routine = this.method_12(float_);
				base.StartCoroutine(routine);
				this.float_58 = x;
			}
		}

		// Token: 0x060034D6 RID: 13526 RVA: 0x000699D4 File Offset: 0x00067BD4
		[Token(Token = "0x60034D6")]
		[Address(RVA = "0x339DA40", Offset = "0x339DA40", VA = "0x339DA40")]
		public void method_32()
		{
			float num = this.float_37;
			float num2 = this.float_43;
			this.float_45 = num;
			this.float_46 = num2;
			float single_ = this.Single_0;
			float single_2 = this.Single_0;
			this.float_47 = num2;
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060034D7 RID: 13527 RVA: 0x00069A14 File Offset: 0x00067C14
		[Token(Token = "0x170000A5")]
		private float Single_2
		{
			[Token(Token = "0x60034D7")]
			[Address(RVA = "0x339E504", Offset = "0x339E504", VA = "0x339E504")]
			get
			{
				float mass = this.rigidbody_1.mass;
				float mass2 = this.rigidbody_0.mass;
				float mass3 = this.rigidbody_3.mass;
				float mass4 = this.rigidbody_2.mass;
				throw new NullReferenceException();
			}
		}

		// Token: 0x060034D9 RID: 13529 RVA: 0x00069A58 File Offset: 0x00067C58
		[Token(Token = "0x60034D9")]
		[Address(RVA = "0x339C274", Offset = "0x339C274", VA = "0x339C274")]
		private void method_33(float float_59)
		{
			Quaternion rotation = this.transform_0.rotation;
		}

		// Token: 0x060034DA RID: 13530 RVA: 0x00069A74 File Offset: 0x00067C74
		[Address(RVA = "0x339E5A8", Offset = "0x339E5A8", VA = "0x339E5A8")]
		[SerializeField]
		[Token(Token = "0x60034DA")]
		private void Update()
		{
			if (this.hexaBodyPlayerInputs_0.bool_3)
			{
				this.method_3();
			}
			float num = this.float_8;
			float radius = this.sphereCollider_0.radius;
			Rigidbody rigidbody = this.rigidbody_1;
			this.float_38 = num;
			Vector3 position = rigidbody.position;
			Vector3 position2 = this.rigidbody_0.position;
			float num2 = this.float_38;
			this._crouchPercent = num2;
			Mathf.Clamp01(radius);
			Rigidbody rigidbody2 = this.rigidbody_1;
			this._crouchPercent = num2;
			Vector3 position3 = rigidbody2.position;
			Vector3 position4 = this.rigidbody_0.position;
			this.float_36 = num2;
			this.method_39();
			this.method_32();
			this.method_29();
			Transform transform = this.transform_5;
			Vector3 position5 = transform.position;
			Vector3 position6 = this.rigidbody_3.position;
			Vector3 position7 = this.transform_5.position;
			Rigidbody rigidbody3 = this.rigidbody_3;
			CapsuleCollider capsuleCollider = this.capsuleCollider_2;
			Vector3 position8 = rigidbody3.position;
			Vector3 position9 = this.transform_5.position;
			float height;
			capsuleCollider.height = height;
			Vector3 position10 = this.rigidbody_3.position;
			Vector3 position11 = this.transform_3.position;
			Vector3 up = this.transform_3.up;
			Transform transform2 = this.transform_3.transform;
			Quaternion rotation = this.transform_3.transform.rotation;
			float magnitude = this.rigidbody_0.angularVelocity.magnitude;
			this._locoAngularVelocity = num2;
		}

		// Token: 0x060034DB RID: 13531 RVA: 0x00069BCC File Offset: 0x00067DCC
		[Token(Token = "0x60034DB")]
		[Address(RVA = "0x339E894", Offset = "0x339E894", VA = "0x339E894")]
		private void method_34(float float_59)
		{
			Quaternion rotation = this.transform_0.rotation;
			float single_ = this.Single_0;
		}

		// Token: 0x060034DC RID: 13532 RVA: 0x00069BEC File Offset: 0x00067DEC
		[Address(RVA = "0x339D3E8", Offset = "0x339D3E8", VA = "0x339D3E8")]
		[Token(Token = "0x60034DC")]
		private void method_35()
		{
			Vector3 forward = this.transform_0.forward;
			Vector3 up = Vector3.up;
			Quaternion quaternion;
			Vector3 eulerAngles = quaternion.eulerAngles;
			Vector3 eulerAngles2 = this.transform_4.transform.eulerAngles;
			Vector3 eulerAngles3 = this.transform_4.transform.eulerAngles;
			Transform transform = this.transform_4.transform;
		}

		// Token: 0x060034DD RID: 13533 RVA: 0x00069C44 File Offset: 0x00067E44
		[Address(RVA = "0x339E990", Offset = "0x339E990", VA = "0x339E990")]
		[Token(Token = "0x60034DD")]
		private void method_36()
		{
			if (this.hexaBodyPlayerInputs_0.bool_3)
			{
				this.method_3();
			}
			float num = this.float_8;
			float radius = this.sphereCollider_0.radius;
			Rigidbody rigidbody = this.rigidbody_1;
			this.float_38 = num;
			Vector3 position = rigidbody.position;
			Vector3 position2 = this.rigidbody_0.position;
			float num2 = this.float_38;
			this._crouchPercent = num2;
			Mathf.Clamp01(radius);
			Rigidbody rigidbody2 = this.rigidbody_1;
			this._crouchPercent = num2;
			Vector3 position3 = rigidbody2.position;
			Vector3 position4 = this.rigidbody_0.position;
			this.float_36 = num2;
			this.method_39();
			this.method_32();
			this.method_29();
			Transform transform = this.transform_5;
			Vector3 position5 = transform.position;
			Vector3 position6 = this.rigidbody_3.position;
			Vector3 position7 = this.transform_5.position;
			Rigidbody rigidbody3 = this.rigidbody_3;
			Vector3 position8 = rigidbody3.position;
			Vector3 position9 = this.transform_5.position;
			Vector3 position10 = this.rigidbody_3.position;
			Vector3 position11 = this.transform_3.position;
			Vector3 up = this.transform_3.up;
			Transform transform2 = this.transform_3.transform;
			Quaternion rotation = this.transform_3.transform.rotation;
			float magnitude = this.rigidbody_0.angularVelocity.magnitude;
			this._locoAngularVelocity = num2;
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060034DE RID: 13534 RVA: 0x00002068 File Offset: 0x00000268
		// (set) Token: 0x060034E1 RID: 13537 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000A2")]
		public bool Boolean_1
		{
			[Token(Token = "0x60034DE")]
			[CompilerGenerated]
			[Address(RVA = "0x339EC80", Offset = "0x339EC80", VA = "0x339EC80")]
			get
			{
				throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
			}
			[Address(RVA = "0x339EC88", Offset = "0x339EC88", VA = "0x339EC88")]
			[CompilerGenerated]
			[Token(Token = "0x60034E1")]
			set
			{
			}
		}

		// Token: 0x060034DF RID: 13535 RVA: 0x00067E28 File Offset: 0x00066028
		[Token(Token = "0x60034DF")]
		[Address(RVA = "0x339C010", Offset = "0x339C010", VA = "0x339C010")]
		public void method_37(float float_59)
		{
		}

		// Token: 0x060034E0 RID: 13536 RVA: 0x0006797C File Offset: 0x00065B7C
		[Address(RVA = "0x339C3A8", Offset = "0x339C3A8", VA = "0x339C3A8")]
		[Token(Token = "0x60034E0")]
		private float method_38(GEnum16 genum16_1)
		{
		}

		// Token: 0x060034E2 RID: 13538 RVA: 0x00069D8C File Offset: 0x00067F8C
		[Token(Token = "0x60034E2")]
		[Address(RVA = "0x339D7E8", Offset = "0x339D7E8", VA = "0x339D7E8")]
		private void method_39()
		{
			do
			{
				HexaBodyPlayerInputs hexaBodyPlayerInputs = this.hexaBodyPlayerInputs_0;
				if (hexaBodyPlayerInputs.playerInputState_1.JustActivated)
				{
					return;
				}
				if (!hexaBodyPlayerInputs.playerInputState_2.JustActivated)
				{
					goto IL_37;
				}
				float deltaTime = Time.deltaTime;
			}
			while (this.hexaBodyPlayerInputs_0.playerInputState_1 == null);
			return;
			IL_37:
			throw new MissingMethodException();
		}

		// Token: 0x040006E6 RID: 1766
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40006E6")]
		public float float_0;

		// Token: 0x040006E7 RID: 1767
		[Token(Token = "0x40006E7")]
		[FieldOffset(Offset = "0x1C")]
		public float float_1;

		// Token: 0x040006E8 RID: 1768
		[Token(Token = "0x40006E8")]
		[FieldOffset(Offset = "0x20")]
		public float float_2;

		// Token: 0x040006E9 RID: 1769
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x40006E9")]
		public float float_3;

		// Token: 0x040006EA RID: 1770
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40006EA")]
		public float float_4;

		// Token: 0x040006EB RID: 1771
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x40006EB")]
		public float float_5;

		// Token: 0x040006EC RID: 1772
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40006EC")]
		public AnimationCurve animationCurve_0;

		// Token: 0x040006ED RID: 1773
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40006ED")]
		public AnimationCurve animationCurve_1;

		// Token: 0x040006EE RID: 1774
		[Token(Token = "0x40006EE")]
		[FieldOffset(Offset = "0x40")]
		public AnimationCurve animationCurve_2;

		// Token: 0x040006EF RID: 1775
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40006EF")]
		public AnimationCurve animationCurve_3;

		// Token: 0x040006F0 RID: 1776
		[Token(Token = "0x40006F0")]
		[FieldOffset(Offset = "0x50")]
		public float float_6;

		// Token: 0x040006F1 RID: 1777
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x40006F1")]
		public float float_7;

		// Token: 0x040006F2 RID: 1778
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40006F2")]
		public float float_8;

		// Token: 0x040006F3 RID: 1779
		[FieldOffset(Offset = "0x5C")]
		[Token(Token = "0x40006F3")]
		public float float_9;

		// Token: 0x040006F4 RID: 1780
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40006F4")]
		public float float_10;

		// Token: 0x040006F5 RID: 1781
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x40006F5")]
		public float float_11;

		// Token: 0x040006F6 RID: 1782
		[Token(Token = "0x40006F6")]
		[FieldOffset(Offset = "0x68")]
		public GEnum18 genum18_0;

		// Token: 0x040006F7 RID: 1783
		[Token(Token = "0x40006F7")]
		[FieldOffset(Offset = "0x6C")]
		public float float_12;

		// Token: 0x040006F8 RID: 1784
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x40006F8")]
		public bool bool_0;

		// Token: 0x040006F9 RID: 1785
		[FieldOffset(Offset = "0x74")]
		[Token(Token = "0x40006F9")]
		public float float_13 = (float)17076;

		// Token: 0x040006FA RID: 1786
		[Token(Token = "0x40006FA")]
		[FieldOffset(Offset = "0x78")]
		public float float_14;

		// Token: 0x040006FB RID: 1787
		[FieldOffset(Offset = "0x7C")]
		[Token(Token = "0x40006FB")]
		public float float_15;

		// Token: 0x040006FC RID: 1788
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x40006FC")]
		public float float_16;

		// Token: 0x040006FD RID: 1789
		[Token(Token = "0x40006FD")]
		[FieldOffset(Offset = "0x84")]
		public float float_17;

		// Token: 0x040006FE RID: 1790
		[Token(Token = "0x40006FE")]
		[FieldOffset(Offset = "0x88")]
		public float float_18;

		// Token: 0x040006FF RID: 1791
		[FieldOffset(Offset = "0x8C")]
		[Token(Token = "0x40006FF")]
		public float float_19;

		// Token: 0x04000700 RID: 1792
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000700")]
		public LayerMask layerMask_0;

		// Token: 0x04000701 RID: 1793
		[FieldOffset(Offset = "0x94")]
		[Token(Token = "0x4000701")]
		public float float_20;

		// Token: 0x04000702 RID: 1794
		[FieldOffset(Offset = "0x98")]
		[Token(Token = "0x4000702")]
		public float float_21;

		// Token: 0x04000703 RID: 1795
		[Token(Token = "0x4000703")]
		[FieldOffset(Offset = "0x9C")]
		public float float_22;

		// Token: 0x04000704 RID: 1796
		[FieldOffset(Offset = "0xA0")]
		[Token(Token = "0x4000704")]
		public float float_23;

		// Token: 0x04000705 RID: 1797
		[Token(Token = "0x4000705")]
		[FieldOffset(Offset = "0xA8")]
		public AnimationCurve animationCurve_4;

		// Token: 0x04000706 RID: 1798
		[Token(Token = "0x4000706")]
		[FieldOffset(Offset = "0xB0")]
		public float float_24;

		// Token: 0x04000707 RID: 1799
		[FieldOffset(Offset = "0xB4")]
		[Token(Token = "0x4000707")]
		public float float_25;

		// Token: 0x04000708 RID: 1800
		[FieldOffset(Offset = "0xB8")]
		[Token(Token = "0x4000708")]
		public GEnum16 genum16_0;

		// Token: 0x04000709 RID: 1801
		[FieldOffset(Offset = "0xBC")]
		[Token(Token = "0x4000709")]
		public float float_26;

		// Token: 0x0400070A RID: 1802
		[FieldOffset(Offset = "0xC0")]
		[Token(Token = "0x400070A")]
		public float float_27;

		// Token: 0x0400070B RID: 1803
		[Token(Token = "0x400070B")]
		[FieldOffset(Offset = "0xC4")]
		public float float_28;

		// Token: 0x0400070C RID: 1804
		[FieldOffset(Offset = "0xC8")]
		[Token(Token = "0x400070C")]
		public float float_29;

		// Token: 0x0400070D RID: 1805
		[FieldOffset(Offset = "0xCC")]
		[Token(Token = "0x400070D")]
		public float float_30;

		// Token: 0x0400070E RID: 1806
		[Token(Token = "0x400070E")]
		[FieldOffset(Offset = "0xD0")]
		public float float_31;

		// Token: 0x0400070F RID: 1807
		[Token(Token = "0x400070F")]
		[FieldOffset(Offset = "0xD4")]
		public float float_32;

		// Token: 0x04000710 RID: 1808
		[Token(Token = "0x4000710")]
		[FieldOffset(Offset = "0xD8")]
		public HexaCameraRig hexaCameraRig_0;

		// Token: 0x04000711 RID: 1809
		[Token(Token = "0x4000711")]
		[FieldOffset(Offset = "0xE0")]
		public Transform transform_0;

		// Token: 0x04000712 RID: 1810
		[FieldOffset(Offset = "0xE8")]
		[Token(Token = "0x4000712")]
		public Transform transform_1;

		// Token: 0x04000713 RID: 1811
		[FieldOffset(Offset = "0xF0")]
		[Token(Token = "0x4000713")]
		public Transform transform_2;

		// Token: 0x04000714 RID: 1812
		[FieldOffset(Offset = "0xF8")]
		[Token(Token = "0x4000714")]
		public Transform transform_3;

		// Token: 0x04000715 RID: 1813
		[Token(Token = "0x4000715")]
		[FieldOffset(Offset = "0x100")]
		public Transform transform_4;

		// Token: 0x04000716 RID: 1814
		[Token(Token = "0x4000716")]
		[FieldOffset(Offset = "0x108")]
		public Transform transform_5;

		// Token: 0x04000717 RID: 1815
		[FieldOffset(Offset = "0x110")]
		[Token(Token = "0x4000717")]
		public Transform transform_6;

		// Token: 0x04000718 RID: 1816
		[FieldOffset(Offset = "0x118")]
		[Token(Token = "0x4000718")]
		public Transform transform_7;

		// Token: 0x04000719 RID: 1817
		[FieldOffset(Offset = "0x120")]
		[Token(Token = "0x4000719")]
		public Rigidbody rigidbody_0;

		// Token: 0x0400071A RID: 1818
		[Token(Token = "0x400071A")]
		[FieldOffset(Offset = "0x128")]
		public Rigidbody rigidbody_1;

		// Token: 0x0400071B RID: 1819
		[Token(Token = "0x400071B")]
		[FieldOffset(Offset = "0x130")]
		public Rigidbody rigidbody_2;

		// Token: 0x0400071C RID: 1820
		[Token(Token = "0x400071C")]
		[FieldOffset(Offset = "0x138")]
		public Rigidbody rigidbody_3;

		// Token: 0x0400071D RID: 1821
		[Token(Token = "0x400071D")]
		[FieldOffset(Offset = "0x140")]
		public CapsuleCollider capsuleCollider_0;

		// Token: 0x0400071E RID: 1822
		[Token(Token = "0x400071E")]
		[FieldOffset(Offset = "0x148")]
		public CapsuleCollider capsuleCollider_1;

		// Token: 0x0400071F RID: 1823
		[FieldOffset(Offset = "0x150")]
		[Token(Token = "0x400071F")]
		public SphereCollider sphereCollider_0;

		// Token: 0x04000720 RID: 1824
		[FieldOffset(Offset = "0x158")]
		[Token(Token = "0x4000720")]
		public SphereCollider sphereCollider_1;

		// Token: 0x04000721 RID: 1825
		[Token(Token = "0x4000721")]
		[FieldOffset(Offset = "0x160")]
		public CapsuleCollider capsuleCollider_2;

		// Token: 0x04000722 RID: 1826
		[FieldOffset(Offset = "0x168")]
		[Token(Token = "0x4000722")]
		public ConfigurableJoint configurableJoint_0;

		// Token: 0x04000723 RID: 1827
		[Token(Token = "0x4000723")]
		[FieldOffset(Offset = "0x170")]
		public ConfigurableJoint configurableJoint_1;

		// Token: 0x04000724 RID: 1828
		[Token(Token = "0x4000724")]
		[FieldOffset(Offset = "0x178")]
		public ConfigurableJoint configurableJoint_2;

		// Token: 0x04000725 RID: 1829
		[FieldOffset(Offset = "0x180")]
		[Token(Token = "0x4000725")]
		public Transform transform_8;

		// Token: 0x04000726 RID: 1830
		[FieldOffset(Offset = "0x188")]
		[Token(Token = "0x4000726")]
		public Transform transform_9;

		// Token: 0x04000727 RID: 1831
		[FieldOffset(Offset = "0x190")]
		[Space]
		[Token(Token = "0x4000727")]
		public float float_33;

		// Token: 0x04000728 RID: 1832
		[FieldOffset(Offset = "0x194")]
		[Token(Token = "0x4000728")]
		public float float_34;

		// Token: 0x04000729 RID: 1833
		[FieldOffset(Offset = "0x198")]
		[Token(Token = "0x4000729")]
		public float float_35;

		// Token: 0x0400072A RID: 1834
		[Token(Token = "0x400072A")]
		[FieldOffset(Offset = "0x19C")]
		public float float_36;

		// Token: 0x0400072B RID: 1835
		[FieldOffset(Offset = "0x1A0")]
		[Token(Token = "0x400072B")]
		public float float_37;

		// Token: 0x0400072C RID: 1836
		[FieldOffset(Offset = "0x1A4")]
		[Token(Token = "0x400072C")]
		public float float_38;

		// Token: 0x0400072D RID: 1837
		[Token(Token = "0x400072D")]
		[FieldOffset(Offset = "0x1A8")]
		public float float_39;

		// Token: 0x0400072E RID: 1838
		[FieldOffset(Offset = "0x1AC")]
		[Token(Token = "0x400072E")]
		public float float_40;

		// Token: 0x0400072F RID: 1839
		[FieldOffset(Offset = "0x1B0")]
		[Token(Token = "0x400072F")]
		public float float_41;

		// Token: 0x04000730 RID: 1840
		[FieldOffset(Offset = "0x1B4")]
		[Token(Token = "0x4000730")]
		public float float_42;

		// Token: 0x04000731 RID: 1841
		[FieldOffset(Offset = "0x1B8")]
		[Token(Token = "0x4000731")]
		public float float_43;

		// Token: 0x04000732 RID: 1842
		[Token(Token = "0x4000732")]
		[FieldOffset(Offset = "0x1BC")]
		public float float_44;

		// Token: 0x04000733 RID: 1843
		[Token(Token = "0x4000733")]
		[FieldOffset(Offset = "0x1C0")]
		public float float_45;

		// Token: 0x04000734 RID: 1844
		[Token(Token = "0x4000734")]
		[FieldOffset(Offset = "0x1C4")]
		public float float_46;

		// Token: 0x04000735 RID: 1845
		[Token(Token = "0x4000735")]
		[FieldOffset(Offset = "0x1C8")]
		public float float_47;

		// Token: 0x04000736 RID: 1846
		[FieldOffset(Offset = "0x1CC")]
		[Token(Token = "0x4000736")]
		public float float_48;

		// Token: 0x04000737 RID: 1847
		[FieldOffset(Offset = "0x1D0")]
		[Token(Token = "0x4000737")]
		public float float_49;

		// Token: 0x04000738 RID: 1848
		[Token(Token = "0x4000738")]
		[FieldOffset(Offset = "0x1D4")]
		public float float_50;

		// Token: 0x04000739 RID: 1849
		[Token(Token = "0x4000739")]
		[FieldOffset(Offset = "0x1D8")]
		public Vector3 vector3_0;

		// Token: 0x0400073A RID: 1850
		[Token(Token = "0x400073A")]
		[FieldOffset(Offset = "0x1E4")]
		public Vector3 vector3_1;

		// Token: 0x0400073B RID: 1851
		[Token(Token = "0x400073B")]
		[SerializeField]
		[Header("Misc")]
		[FieldOffset(Offset = "0x1F0")]
		private float _jumpForce;

		// Token: 0x0400073C RID: 1852
		[SerializeField]
		[Token(Token = "0x400073C")]
		[FieldOffset(Offset = "0x1F4")]
		private float _groundAngle;

		// Token: 0x0400073D RID: 1853
		[SerializeField]
		[FieldOffset(Offset = "0x1F8")]
		[Token(Token = "0x400073D")]
		private GEnum16 _crouchLevel;

		// Token: 0x0400073E RID: 1854
		[FieldOffset(Offset = "0x1FC")]
		[Token(Token = "0x400073E")]
		[SerializeField]
		private float _jumpTime;

		// Token: 0x0400073F RID: 1855
		[FieldOffset(Offset = "0x200")]
		[Token(Token = "0x400073F")]
		[SerializeField]
		private GEnum17 _legStage;

		// Token: 0x04000740 RID: 1856
		[FieldOffset(Offset = "0x204")]
		[Token(Token = "0x4000740")]
		[SerializeField]
		private float _actualSpeed;

		// Token: 0x04000741 RID: 1857
		[Token(Token = "0x4000741")]
		[SerializeField]
		[FieldOffset(Offset = "0x208")]
		private float _crouchPercent;

		// Token: 0x04000742 RID: 1858
		[Header("Velocities")]
		[SerializeField]
		[FieldOffset(Offset = "0x20C")]
		[Token(Token = "0x4000742")]
		private float _verticalSpeed;

		// Token: 0x04000743 RID: 1859
		[SerializeField]
		[Token(Token = "0x4000743")]
		[FieldOffset(Offset = "0x210")]
		private float _locoAngularVelocity;

		// Token: 0x04000744 RID: 1860
		[FieldOffset(Offset = "0x214")]
		[SerializeField]
		[Token(Token = "0x4000744")]
		private float _targetAngularVelocity;

		// Token: 0x04000745 RID: 1861
		[Token(Token = "0x4000745")]
		[FieldOffset(Offset = "0x218")]
		[SerializeField]
		private float _modifiedTargetSpeed;

		// Token: 0x04000746 RID: 1862
		[SerializeField]
		[FieldOffset(Offset = "0x21C")]
		[Token(Token = "0x4000746")]
		private float _modifiedTargetAcceleration;

		// Token: 0x04000747 RID: 1863
		[Token(Token = "0x4000747")]
		[FieldOffset(Offset = "0x220")]
		private float float_51;

		// Token: 0x04000748 RID: 1864
		[FieldOffset(Offset = "0x224")]
		[Token(Token = "0x4000748")]
		private float float_52;

		// Token: 0x04000749 RID: 1865
		[FieldOffset(Offset = "0x228")]
		[Token(Token = "0x4000749")]
		private float float_53;

		// Token: 0x0400074A RID: 1866
		[FieldOffset(Offset = "0x22C")]
		[Token(Token = "0x400074A")]
		private float float_54;

		// Token: 0x0400074B RID: 1867
		[Token(Token = "0x400074B")]
		[FieldOffset(Offset = "0x230")]
		private bool bool_1;

		// Token: 0x0400074C RID: 1868
		[FieldOffset(Offset = "0x234")]
		[Token(Token = "0x400074C")]
		private float float_55;

		// Token: 0x0400074D RID: 1869
		[Token(Token = "0x400074D")]
		[FieldOffset(Offset = "0x238")]
		private float float_56;

		// Token: 0x0400074E RID: 1870
		[Token(Token = "0x400074E")]
		[FieldOffset(Offset = "0x23C")]
		private float float_57;

		// Token: 0x0400074F RID: 1871
		[Token(Token = "0x400074F")]
		[FieldOffset(Offset = "0x240")]
		private bool bool_2;

		// Token: 0x04000750 RID: 1872
		[Token(Token = "0x4000750")]
		[FieldOffset(Offset = "0x244")]
		private Vector3 vector3_2;

		// Token: 0x04000751 RID: 1873
		[Token(Token = "0x4000751")]
		[FieldOffset(Offset = "0x250")]
		private Vector3 vector3_3;

		// Token: 0x04000752 RID: 1874
		[FieldOffset(Offset = "0x25C")]
		[Token(Token = "0x4000752")]
		private Vector3 vector3_4;

		// Token: 0x04000753 RID: 1875
		[Token(Token = "0x4000753")]
		[CompilerGenerated]
		[FieldOffset(Offset = "0x268")]
		private bool bool_3;

		// Token: 0x04000754 RID: 1876
		[Token(Token = "0x4000754")]
		[FieldOffset(Offset = "0x26C")]
		[CompilerGenerated]
		private Quaternion quaternion_0;

		// Token: 0x04000755 RID: 1877
		[CompilerGenerated]
		[Token(Token = "0x4000755")]
		[FieldOffset(Offset = "0x280")]
		private HexaBodyPlayerInputs hexaBodyPlayerInputs_0;

		// Token: 0x04000756 RID: 1878
		[Token(Token = "0x4000756")]
		[FieldOffset(Offset = "0x288")]
		[CompilerGenerated]
		private Vector3 vector3_5;

		// Token: 0x04000757 RID: 1879
		[Token(Token = "0x4000757")]
		[CompilerGenerated]
		[FieldOffset(Offset = "0x294")]
		private Vector3 vector3_6;

		// Token: 0x04000758 RID: 1880
		[FieldOffset(Offset = "0x2A0")]
		[Token(Token = "0x4000758")]
		[CompilerGenerated]
		private bool bool_4;

		// Token: 0x04000759 RID: 1881
		[Token(Token = "0x4000759")]
		[FieldOffset(Offset = "0x2A4")]
		private float float_58;

		// Token: 0x0400075A RID: 1882
		[Token(Token = "0x400075A")]
		[FieldOffset(Offset = "0x2A8")]
		private bool bool_5;
	}
}
