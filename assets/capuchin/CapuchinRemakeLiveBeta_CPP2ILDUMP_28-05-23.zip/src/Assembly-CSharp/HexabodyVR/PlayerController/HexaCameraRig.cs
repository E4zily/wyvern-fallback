﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000158 RID: 344
	[Token(Token = "0x2000158")]
	public class HexaCameraRig : MonoBehaviour
	{
		// Token: 0x060036E3 RID: 14051 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x60036E3")]
		[Address(RVA = "0x326CC34", Offset = "0x326CC34", VA = "0x326CC34")]
		public float method_0()
		{
		}

		// Token: 0x060036E4 RID: 14052 RVA: 0x0006F918 File Offset: 0x0006DB18
		[Address(RVA = "0x326CC3C", Offset = "0x326CC3C", VA = "0x326CC3C")]
		[Token(Token = "0x60036E4")]
		private void method_1()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_52();
		}

		// Token: 0x060036E5 RID: 14053 RVA: 0x000034C8 File Offset: 0x000016C8
		[Token(Token = "0x60036E5")]
		[Address(RVA = "0x326CD08", Offset = "0x326CD08", VA = "0x326CD08")]
		public void method_2(float float_1)
		{
			this.method_14();
		}

		// Token: 0x060036E6 RID: 14054 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x60036E6")]
		[Address(RVA = "0x326CD48", Offset = "0x326CD48", VA = "0x326CD48")]
		public float method_3()
		{
		}

		// Token: 0x060036E7 RID: 14055 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x60036E7")]
		[Address(RVA = "0x326CD50", Offset = "0x326CD50", VA = "0x326CD50")]
		public float method_4()
		{
		}

		// Token: 0x060036E8 RID: 14056 RVA: 0x0006F934 File Offset: 0x0006DB34
		[Token(Token = "0x60036E8")]
		[Address(RVA = "0x326CD58", Offset = "0x326CD58", VA = "0x326CD58")]
		private void method_5()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_40();
		}

		// Token: 0x060036E9 RID: 14057 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x60036E9")]
		[Address(RVA = "0x326CE1C", Offset = "0x326CE1C", VA = "0x326CE1C")]
		private IEnumerator method_6(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (060036E9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_6(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060036EA RID: 14058 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Address(RVA = "0x326CE78", Offset = "0x326CE78", VA = "0x326CE78")]
		[Token(Token = "0x60036EA")]
		private IEnumerator method_7(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (060036EA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_7(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060036EB RID: 14059 RVA: 0x0006F96C File Offset: 0x0006DB6C
		[Token(Token = "0x60036EB")]
		[Address(RVA = "0x326CED4", Offset = "0x326CED4", VA = "0x326CED4")]
		private void Update()
		{
			this.method_65();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x060036EC RID: 14060 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x60036EC")]
		[Address(RVA = "0x326CF3C", Offset = "0x326CF3C", VA = "0x326CF3C")]
		private IEnumerator method_8(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (060036EC)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_8(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060036ED RID: 14061 RVA: 0x0006F990 File Offset: 0x0006DB90
		[Address(RVA = "0x326CF98", Offset = "0x326CF98", VA = "0x326CF98")]
		[Token(Token = "0x60036ED")]
		private void method_9()
		{
			this.method_13();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x060036EE RID: 14062 RVA: 0x0006F9B4 File Offset: 0x0006DBB4
		[Address(RVA = "0x326D000", Offset = "0x326D000", VA = "0x326D000")]
		[Token(Token = "0x60036EE")]
		private void method_10()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_72();
		}

		// Token: 0x060036EF RID: 14063 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x60036EF")]
		[Address(RVA = "0x326CD8C", Offset = "0x326CD8C", VA = "0x326CD8C")]
		private IEnumerator method_11(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (060036EF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_11(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060036F0 RID: 14064 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x60036F0")]
		[Address(RVA = "0x326D0CC", Offset = "0x326D0CC", VA = "0x326D0CC")]
		private IEnumerator method_12(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (060036F0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_12(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060036F1 RID: 14065 RVA: 0x0006F9D0 File Offset: 0x0006DBD0
		[Address(RVA = "0x326CFCC", Offset = "0x326CFCC", VA = "0x326CFCC")]
		[Token(Token = "0x60036F1")]
		private void method_13()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_76();
		}

		// Token: 0x060036F2 RID: 14066 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Token(Token = "0x60036F2")]
		[Address(RVA = "0x326CD10", Offset = "0x326CD10", VA = "0x326CD10")]
		public void method_14()
		{
		}

		// Token: 0x060036F3 RID: 14067 RVA: 0x0006F9FC File Offset: 0x0006DBFC
		[Token(Token = "0x60036F3")]
		[Address(RVA = "0x326D1C0", Offset = "0x326D1C0", VA = "0x326D1C0")]
		private void method_15()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_14();
		}

		// Token: 0x060036F4 RID: 14068 RVA: 0x0006FA18 File Offset: 0x0006DC18
		[Address(RVA = "0x326D1F4", Offset = "0x326D1F4", VA = "0x326D1F4")]
		[Token(Token = "0x60036F4")]
		private void method_16()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_27();
		}

		// Token: 0x060036F5 RID: 14069 RVA: 0x000034D0 File Offset: 0x000016D0
		[Address(RVA = "0x326D2C0", Offset = "0x326D2C0", VA = "0x326D2C0")]
		[Token(Token = "0x60036F5")]
		public void method_17(float float_1)
		{
			this.method_53();
		}

		// Token: 0x060036F6 RID: 14070 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x60036F6")]
		[Address(RVA = "0x326D034", Offset = "0x326D034", VA = "0x326D034")]
		private IEnumerator method_18(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (060036F6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_18(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060036F7 RID: 14071 RVA: 0x0006FA34 File Offset: 0x0006DC34
		[Address(RVA = "0x326D304", Offset = "0x326D304", VA = "0x326D304")]
		[Token(Token = "0x60036F7")]
		private void method_19()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_1();
		}

		// Token: 0x060036F8 RID: 14072 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x60036F8")]
		[Address(RVA = "0x326D310", Offset = "0x326D310", VA = "0x326D310")]
		private IEnumerator method_20(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (060036F8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_20(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060036F9 RID: 14073 RVA: 0x0006FA58 File Offset: 0x0006DC58
		[Token(Token = "0x60036F9")]
		[Address(RVA = "0x326D36C", Offset = "0x326D36C", VA = "0x326D36C")]
		private void method_21()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_65();
		}

		// Token: 0x060036FA RID: 14074 RVA: 0x0006FA7C File Offset: 0x0006DC7C
		[Token(Token = "0x60036FA")]
		[Address(RVA = "0x326D378", Offset = "0x326D378", VA = "0x326D378")]
		private void method_22()
		{
			this.method_1();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x060036FB RID: 14075 RVA: 0x0006FAA0 File Offset: 0x0006DCA0
		[Token(Token = "0x60036FB")]
		[Address(RVA = "0x326D3AC", Offset = "0x326D3AC", VA = "0x326D3AC")]
		private void method_23()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_35();
		}

		// Token: 0x060036FC RID: 14076 RVA: 0x0006FAC4 File Offset: 0x0006DCC4
		[Token(Token = "0x60036FC")]
		[Address(RVA = "0x326D3EC", Offset = "0x326D3EC", VA = "0x326D3EC")]
		private void method_24()
		{
			this.method_10();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x060036FD RID: 14077 RVA: 0x0006FAE8 File Offset: 0x0006DCE8
		[Token(Token = "0x60036FD")]
		[Address(RVA = "0x326D420", Offset = "0x326D420", VA = "0x326D420")]
		private void method_25()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_41();
		}

		// Token: 0x060036FE RID: 14078 RVA: 0x000034D8 File Offset: 0x000016D8
		[Address(RVA = "0x326D490", Offset = "0x326D490", VA = "0x326D490")]
		[Token(Token = "0x60036FE")]
		public void method_26(float float_1)
		{
			this.method_27();
		}

		// Token: 0x060036FF RID: 14079 RVA: 0x0006FA58 File Offset: 0x0006DC58
		[Token(Token = "0x60036FF")]
		[Address(RVA = "0x326D498", Offset = "0x326D498", VA = "0x326D498")]
		private void Start()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_65();
		}

		// Token: 0x06003700 RID: 14080 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Token(Token = "0x6003700")]
		[Address(RVA = "0x326D284", Offset = "0x326D284", VA = "0x326D284")]
		public void method_27()
		{
		}

		// Token: 0x06003701 RID: 14081 RVA: 0x0006F9B4 File Offset: 0x0006DBB4
		[Address(RVA = "0x326D4A4", Offset = "0x326D4A4", VA = "0x326D4A4")]
		[Token(Token = "0x6003701")]
		private void method_28()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_72();
		}

		// Token: 0x06003702 RID: 14082 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Token(Token = "0x6003702")]
		[Address(RVA = "0x326D4D8", Offset = "0x326D4D8", VA = "0x326D4D8")]
		public void method_29()
		{
		}

		// Token: 0x06003703 RID: 14083 RVA: 0x0006FB04 File Offset: 0x0006DD04
		[Address(RVA = "0x326D514", Offset = "0x326D514", VA = "0x326D514")]
		[Token(Token = "0x6003703")]
		private void method_30()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_13();
		}

		// Token: 0x06003704 RID: 14084 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x6003704")]
		[Address(RVA = "0x326D520", Offset = "0x326D520", VA = "0x326D520")]
		public float method_31()
		{
		}

		// Token: 0x06003705 RID: 14085 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Address(RVA = "0x326D528", Offset = "0x326D528", VA = "0x326D528")]
		[Token(Token = "0x6003705")]
		private IEnumerator method_32(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (06003705)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_32(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003706 RID: 14086 RVA: 0x0006FB28 File Offset: 0x0006DD28
		[Address(RVA = "0x326D584", Offset = "0x326D584", VA = "0x326D584")]
		[Token(Token = "0x6003706")]
		private void method_33()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_10();
		}

		// Token: 0x06003707 RID: 14087 RVA: 0x0006FB4C File Offset: 0x0006DD4C
		[Address(RVA = "0x326D590", Offset = "0x326D590", VA = "0x326D590")]
		[Token(Token = "0x6003707")]
		private void method_34()
		{
			this.method_59();
		}

		// Token: 0x06003708 RID: 14088 RVA: 0x0006FB60 File Offset: 0x0006DD60
		[Token(Token = "0x6003708")]
		[Address(RVA = "0x326D3B8", Offset = "0x326D3B8", VA = "0x326D3B8")]
		private void method_35()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_29();
		}

		// Token: 0x06003709 RID: 14089 RVA: 0x0006FB7C File Offset: 0x0006DD7C
		[Address(RVA = "0x326D5F8", Offset = "0x326D5F8", VA = "0x326D5F8")]
		[Token(Token = "0x6003709")]
		private void method_36()
		{
			this.method_47();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x0600370A RID: 14090 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x600370A")]
		[Address(RVA = "0x326CC70", Offset = "0x326CC70", VA = "0x326CC70")]
		private IEnumerator method_37(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (0600370A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_37(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600370B RID: 14091 RVA: 0x0006FBA0 File Offset: 0x0006DDA0
		[Token(Token = "0x600370B")]
		[Address(RVA = "0x326D660", Offset = "0x326D660", VA = "0x326D660")]
		private void method_38()
		{
			this.method_25();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x0600370C RID: 14092 RVA: 0x000034E0 File Offset: 0x000016E0
		[Address(RVA = "0x326D694", Offset = "0x326D694", VA = "0x326D694")]
		[Token(Token = "0x600370C")]
		public void method_39(float float_1)
		{
			this.method_67();
		}

		// Token: 0x0600370D RID: 14093 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Token(Token = "0x600370D")]
		[Address(RVA = "0x326CDE8", Offset = "0x326CDE8", VA = "0x326CDE8")]
		public void method_40()
		{
		}

		// Token: 0x0600370E RID: 14094 RVA: 0x0006FBC4 File Offset: 0x0006DDC4
		[Token(Token = "0x600370E")]
		[Address(RVA = "0x326D454", Offset = "0x326D454", VA = "0x326D454")]
		public void method_41()
		{
		}

		// Token: 0x0600370F RID: 14095 RVA: 0x0006FBD4 File Offset: 0x0006DDD4
		[Address(RVA = "0x326D6D8", Offset = "0x326D6D8", VA = "0x326D6D8")]
		[Token(Token = "0x600370F")]
		private void method_42()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_47();
		}

		// Token: 0x06003710 RID: 14096 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x6003710")]
		[Address(RVA = "0x326D6E4", Offset = "0x326D6E4", VA = "0x326D6E4")]
		private IEnumerator method_43(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (06003710)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_43(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003711 RID: 14097 RVA: 0x0006F990 File Offset: 0x0006DB90
		[Address(RVA = "0x326D740", Offset = "0x326D740", VA = "0x326D740")]
		[Token(Token = "0x6003711")]
		private void method_44()
		{
			this.method_13();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x06003712 RID: 14098 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x326D774", Offset = "0x326D774", VA = "0x326D774")]
		[Token(Token = "0x6003712")]
		public float method_45()
		{
		}

		// Token: 0x06003713 RID: 14099 RVA: 0x0006FAC4 File Offset: 0x0006DCC4
		[Address(RVA = "0x326D77C", Offset = "0x326D77C", VA = "0x326D77C")]
		[Token(Token = "0x6003713")]
		private void method_46()
		{
			this.method_10();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x06003714 RID: 14100 RVA: 0x0003584C File Offset: 0x00033A4C
		// (set) Token: 0x0600371C RID: 14108 RVA: 0x000034E8 File Offset: 0x000016E8
		[Token(Token = "0x170000DA")]
		public float Single_0
		{
			[Address(RVA = "0x326D7B0", Offset = "0x326D7B0", VA = "0x326D7B0")]
			[Token(Token = "0x6003714")]
			get
			{
			}
			[Address(RVA = "0x32694AC", Offset = "0x32694AC", VA = "0x32694AC")]
			[Token(Token = "0x600371C")]
			set
			{
				this.method_40();
			}
		}

		// Token: 0x06003715 RID: 14101 RVA: 0x0006F934 File Offset: 0x0006DB34
		[Token(Token = "0x6003715")]
		[Address(RVA = "0x326D62C", Offset = "0x326D62C", VA = "0x326D62C")]
		private void method_47()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_40();
		}

		// Token: 0x06003716 RID: 14102 RVA: 0x0006FBF8 File Offset: 0x0006DDF8
		[Address(RVA = "0x326D7B8", Offset = "0x326D7B8", VA = "0x326D7B8")]
		[Token(Token = "0x6003716")]
		private void method_48()
		{
			this.method_15();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x06003717 RID: 14103 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003717")]
		[Address(RVA = "0x326D7EC", Offset = "0x326D7EC", VA = "0x326D7EC")]
		public HexaCameraRig()
		{
		}

		// Token: 0x06003718 RID: 14104 RVA: 0x0006FC1C File Offset: 0x0006DE1C
		[Address(RVA = "0x326D7F4", Offset = "0x326D7F4", VA = "0x326D7F4")]
		[Token(Token = "0x6003718")]
		private void method_49()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_5();
		}

		// Token: 0x06003719 RID: 14105 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x326D800", Offset = "0x326D800", VA = "0x326D800")]
		[Token(Token = "0x6003719")]
		public float method_50()
		{
		}

		// Token: 0x0600371A RID: 14106 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x600371A")]
		[Address(RVA = "0x326D228", Offset = "0x326D228", VA = "0x326D228")]
		private IEnumerator method_51(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (0600371A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_51(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600371B RID: 14107 RVA: 0x0006FC40 File Offset: 0x0006DE40
		[Token(Token = "0x600371B")]
		[Address(RVA = "0x326CCCC", Offset = "0x326CCCC", VA = "0x326CCCC")]
		public void method_52()
		{
		}

		// Token: 0x0600371D RID: 14109 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Address(RVA = "0x326D2C8", Offset = "0x326D2C8", VA = "0x326D2C8")]
		[Token(Token = "0x600371D")]
		public void method_53()
		{
		}

		// Token: 0x0600371E RID: 14110 RVA: 0x000034F0 File Offset: 0x000016F0
		[Address(RVA = "0x326D808", Offset = "0x326D808", VA = "0x326D808")]
		[Token(Token = "0x600371E")]
		public void method_54(float float_1)
		{
			this.method_77();
		}

		// Token: 0x0600371F RID: 14111 RVA: 0x0006FC50 File Offset: 0x0006DE50
		[Address(RVA = "0x326D84C", Offset = "0x326D84C", VA = "0x326D84C")]
		[Token(Token = "0x600371F")]
		private void method_55()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_25();
		}

		// Token: 0x06003720 RID: 14112 RVA: 0x0006FAC4 File Offset: 0x0006DCC4
		[Address(RVA = "0x326D858", Offset = "0x326D858", VA = "0x326D858")]
		[Token(Token = "0x6003720")]
		private void method_56()
		{
			this.method_10();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x06003721 RID: 14113 RVA: 0x000034F8 File Offset: 0x000016F8
		[Token(Token = "0x6003721")]
		[Address(RVA = "0x326D88C", Offset = "0x326D88C", VA = "0x326D88C")]
		public void method_57(float float_1)
		{
			this.method_41();
		}

		// Token: 0x06003722 RID: 14114 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Address(RVA = "0x326D128", Offset = "0x326D128", VA = "0x326D128")]
		[Token(Token = "0x6003722")]
		private IEnumerator method_58(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (06003722)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_58(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003723 RID: 14115 RVA: 0x0006FC74 File Offset: 0x0006DE74
		[Token(Token = "0x6003723")]
		[Address(RVA = "0x326D5C4", Offset = "0x326D5C4", VA = "0x326D5C4")]
		private void method_59()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_60();
		}

		// Token: 0x06003724 RID: 14116 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Address(RVA = "0x326D894", Offset = "0x326D894", VA = "0x326D894")]
		[Token(Token = "0x6003724")]
		public void method_60()
		{
		}

		// Token: 0x06003725 RID: 14117 RVA: 0x000034F8 File Offset: 0x000016F8
		[Address(RVA = "0x326D8D0", Offset = "0x326D8D0", VA = "0x326D8D0")]
		[Token(Token = "0x6003725")]
		public void method_61(float float_1)
		{
			this.method_41();
		}

		// Token: 0x06003726 RID: 14118 RVA: 0x00003500 File Offset: 0x00001700
		[Address(RVA = "0x326D8D8", Offset = "0x326D8D8", VA = "0x326D8D8")]
		[Token(Token = "0x6003726")]
		public void method_62(float float_1)
		{
			this.method_76();
		}

		// Token: 0x06003727 RID: 14119 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x326D8E0", Offset = "0x326D8E0", VA = "0x326D8E0")]
		[Token(Token = "0x6003727")]
		public float method_63()
		{
		}

		// Token: 0x06003728 RID: 14120 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Address(RVA = "0x326D8E8", Offset = "0x326D8E8", VA = "0x326D8E8")]
		[Token(Token = "0x6003728")]
		public void method_64()
		{
		}

		// Token: 0x06003729 RID: 14121 RVA: 0x0006F934 File Offset: 0x0006DB34
		[Address(RVA = "0x326CF08", Offset = "0x326CF08", VA = "0x326CF08")]
		[Token(Token = "0x6003729")]
		private void method_65()
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			this.method_40();
		}

		// Token: 0x0600372A RID: 14122 RVA: 0x0006F990 File Offset: 0x0006DB90
		[Token(Token = "0x600372A")]
		[Address(RVA = "0x326D924", Offset = "0x326D924", VA = "0x326D924")]
		private void method_66()
		{
			this.method_13();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x0600372B RID: 14123 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Token(Token = "0x600372B")]
		[Address(RVA = "0x326D69C", Offset = "0x326D69C", VA = "0x326D69C")]
		public void method_67()
		{
		}

		// Token: 0x0600372C RID: 14124 RVA: 0x0006FB7C File Offset: 0x0006DD7C
		[Token(Token = "0x600372C")]
		[Address(RVA = "0x326D958", Offset = "0x326D958", VA = "0x326D958")]
		private void method_68()
		{
			this.method_47();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x0600372D RID: 14125 RVA: 0x0003584C File Offset: 0x00033A4C
		[Token(Token = "0x600372D")]
		[Address(RVA = "0x326D98C", Offset = "0x326D98C", VA = "0x326D98C")]
		public float method_69()
		{
		}

		// Token: 0x0600372E RID: 14126 RVA: 0x0006FC90 File Offset: 0x0006DE90
		[Address(RVA = "0x326D994", Offset = "0x326D994", VA = "0x326D994")]
		[Token(Token = "0x600372E")]
		private void method_70()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_28();
		}

		// Token: 0x0600372F RID: 14127 RVA: 0x0006FAC4 File Offset: 0x0006DCC4
		[Address(RVA = "0x326D9A0", Offset = "0x326D9A0", VA = "0x326D9A0")]
		[Token(Token = "0x600372F")]
		private void method_71()
		{
			this.method_10();
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
		}

		// Token: 0x06003730 RID: 14128 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Address(RVA = "0x326D090", Offset = "0x326D090", VA = "0x326D090")]
		[Token(Token = "0x6003730")]
		public void method_72()
		{
		}

		// Token: 0x06003731 RID: 14129 RVA: 0x0006FC1C File Offset: 0x0006DE1C
		[Token(Token = "0x6003731")]
		[Address(RVA = "0x326D9D4", Offset = "0x326D9D4", VA = "0x326D9D4")]
		private void method_73()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_5();
		}

		// Token: 0x06003732 RID: 14130 RVA: 0x0006FCB4 File Offset: 0x0006DEB4
		[Address(RVA = "0x326D9E0", Offset = "0x326D9E0", VA = "0x326D9E0")]
		[Token(Token = "0x6003732")]
		private void method_74()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_15();
		}

		// Token: 0x06003733 RID: 14131 RVA: 0x0003584C File Offset: 0x00033A4C
		[Address(RVA = "0x326D9EC", Offset = "0x326D9EC", VA = "0x326D9EC")]
		[Token(Token = "0x6003733")]
		public float method_75()
		{
		}

		// Token: 0x06003734 RID: 14132 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Address(RVA = "0x326D184", Offset = "0x326D184", VA = "0x326D184")]
		[Token(Token = "0x6003734")]
		public void method_76()
		{
		}

		// Token: 0x06003735 RID: 14133 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		[Token(Token = "0x6003735")]
		[Address(RVA = "0x326D810", Offset = "0x326D810", VA = "0x326D810")]
		public void method_77()
		{
		}

		// Token: 0x06003736 RID: 14134 RVA: 0x0006FC1C File Offset: 0x0006DE1C
		[Address(RVA = "0x326D9F4", Offset = "0x326D9F4", VA = "0x326D9F4")]
		[Token(Token = "0x6003736")]
		private void method_78()
		{
			TrackingOriginModeFlags trackingOriginModeFlags = this.trackingOriginModeFlags_0;
			this.trackingOriginModeFlags_1 = trackingOriginModeFlags;
			this.method_5();
		}

		// Token: 0x06003737 RID: 14135 RVA: 0x0006F950 File Offset: 0x0006DB50
		[Token(Token = "0x6003737")]
		[Address(RVA = "0x326DA00", Offset = "0x326DA00", VA = "0x326DA00")]
		private IEnumerator method_79(TrackingOriginModeFlags trackingOriginModeFlags_2)
		{
			/*
An exception occurred when decompiling this method (06003737)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Collections.IEnumerator HexabodyVR.PlayerController.HexaCameraRig::method_79(UnityEngine.XR.TrackingOriginModeFlags)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	newobj:Class55(Class55::.ctor, ldc.i8:int64[exp:int32](0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0400090A RID: 2314
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400090A")]
		public Transform transform_0;

		// Token: 0x0400090B RID: 2315
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400090B")]
		public Transform transform_1;

		// Token: 0x0400090C RID: 2316
		[Token(Token = "0x400090C")]
		[FieldOffset(Offset = "0x28")]
		public float float_0;

		// Token: 0x0400090D RID: 2317
		[Token(Token = "0x400090D")]
		[FieldOffset(Offset = "0x2C")]
		public TrackingOriginModeFlags trackingOriginModeFlags_0;

		// Token: 0x0400090E RID: 2318
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400090E")]
		private TrackingOriginModeFlags trackingOriginModeFlags_1;

		// Token: 0x0400090F RID: 2319
		[Token(Token = "0x400090F")]
		[FieldOffset(Offset = "0x34")]
		[SerializeField]
		private float _floorOffset;
	}
}
