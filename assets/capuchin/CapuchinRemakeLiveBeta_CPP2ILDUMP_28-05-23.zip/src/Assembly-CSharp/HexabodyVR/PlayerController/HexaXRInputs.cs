﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

namespace HexabodyVR.PlayerController
{
	// Token: 0x02000169 RID: 361
	[Token(Token = "0x2000169")]
	public class HexaXRInputs : MonoBehaviour
	{
		// Token: 0x0600382D RID: 14381 RVA: 0x0007052C File Offset: 0x0006E72C
		[Address(RVA = "0x337EF5C", Offset = "0x337EF5C", VA = "0x337EF5C")]
		[Token(Token = "0x600382D")]
		private void method_0(string string_8, string string_9)
		{
			long num = 1L;
			this.bool_8 = (num != 0L);
			string.IsNullOrWhiteSpace(string_8);
			string text2;
			string text = text2.ToLower();
			text2.Contains("FingerTip");
			text.Contains("NormalWeather");
			long num2 = 1L;
			this.bool_13 = (num2 != 0L);
			text2.Contains("User is on an outdated version of Capuchin. Your version is ");
			text.Contains("run");
			this.bool_10 = ("run" != null);
			text2.Contains("Regular");
			text.Contains(" hour. You were banned because of ");
			text.Contains("Collided");
		}

		// Token: 0x0600382E RID: 14382 RVA: 0x000705C0 File Offset: 0x0006E7C0
		[Address(RVA = "0x337F170", Offset = "0x337F170", VA = "0x337F170")]
		[Token(Token = "0x600382E")]
		protected void method_1(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)32768;
		}

		// Token: 0x0600382F RID: 14383 RVA: 0x000705D8 File Offset: 0x0006E7D8
		[Address(RVA = "0x337FF58", Offset = "0x337FF58", VA = "0x337FF58")]
		[Token(Token = "0x600382F")]
		protected void method_2()
		{
			InputDevice inputDevice = this.InputDevice_0;
			InputDevice inputDevice2 = this.InputDevice_0;
		}

		// Token: 0x06003830 RID: 14384 RVA: 0x000705F4 File Offset: 0x0006E7F4
		[Token(Token = "0x6003830")]
		[Address(RVA = "0x337FFB8", Offset = "0x337FFB8", VA = "0x337FFB8")]
		private void method_3(string string_8, string string_9)
		{
			long num = 1L;
			this.bool_8 = (num != 0L);
			string.IsNullOrWhiteSpace(string_8);
			string.IsNullOrWhiteSpace(string_9);
			string text = string_9.ToLower();
			string text2;
			text2.Contains("Vector1_d371bd24217449349bd747533d51af6b");
			text.Contains("Starting to bake textures on frame ");
			this.bool_13 = ("Starting to bake textures on frame " != null);
			text2.Contains("liftoff failed!");
			text.Contains("ChangeToTagged");
			text2.Contains("TurnAmount");
			text.Contains("Player");
			long num2 = 1L;
			this.bool_8 = (num2 != 0L);
			text.Contains("ChangeToRegular");
			long num3 = 1L;
			this.bool_11 = (num3 != 0L);
		}

		// Token: 0x06003831 RID: 14385 RVA: 0x0000336B File Offset: 0x0000156B
		[Address(RVA = "0x33801BC", Offset = "0x33801BC", VA = "0x33801BC")]
		[Token(Token = "0x6003831")]
		protected void method_4(ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)57344;
		}

		// Token: 0x06003832 RID: 14386 RVA: 0x0007069C File Offset: 0x0006E89C
		[Token(Token = "0x6003832")]
		[Address(RVA = "0x33801D4", Offset = "0x33801D4", VA = "0x33801D4")]
		public bool method_5(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x06003833 RID: 14387 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Token(Token = "0x6003833")]
		[Address(RVA = "0x337FA1C", Offset = "0x337FA1C", VA = "0x337FA1C")]
		public InputDevice method_6()
		{
			return this.inputDevice_0;
		}

		// Token: 0x06003834 RID: 14388 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3380348", Offset = "0x3380348", VA = "0x3380348")]
		[Token(Token = "0x6003834")]
		public void method_7(bool bool_17)
		{
		}

		// Token: 0x06003835 RID: 14389 RVA: 0x000706C4 File Offset: 0x0006E8C4
		[Token(Token = "0x6003835")]
		[Address(RVA = "0x3380354", Offset = "0x3380354", VA = "0x3380354")]
		private void method_8()
		{
			this.method_103();
			this.method_112();
			this.playerInputState_7.Value = (float)32768;
			this.playerInputState_8.Value = (float)32768;
			this.playerInputState_10.Value = (float)17254;
		}

		// Token: 0x06003836 RID: 14390 RVA: 0x00070710 File Offset: 0x0006E910
		[Token(Token = "0x6003836")]
		[Address(RVA = "0x3381D74", Offset = "0x3381D74", VA = "0x3381D74")]
		private void method_9()
		{
			this.method_55();
			this.method_86();
			this.playerInputState_5.Value = (float)17254;
			this.playerInputState_3.Value = (float)32768;
			this.playerInputState_7.Value = (float)40960;
			this.playerInputState_8.Value = (float)17254;
			this.playerInputState_9.Value = (float)17254;
			this.playerInputState_10.Value = (float)17254;
		}

		// Token: 0x06003837 RID: 14391 RVA: 0x000035B7 File Offset: 0x000017B7
		[Address(RVA = "0x3382EAC", Offset = "0x3382EAC", VA = "0x3382EAC")]
		[Token(Token = "0x6003837")]
		private void method_10()
		{
			this.method_79();
		}

		// Token: 0x06003838 RID: 14392 RVA: 0x0007078C File Offset: 0x0006E98C
		[Token(Token = "0x6003838")]
		[Address(RVA = "0x3383060", Offset = "0x3383060", VA = "0x3383060")]
		private void method_11()
		{
			this.method_21();
			this.method_2();
			this.vector2_1 = 17462;
			this.vector2_1.y = (float)16384;
			this.playerInputState_5.Value = (float)32768;
			this.playerInputState_7.Value = (float)40960;
			this.playerInputState_8.Value = (float)17254;
		}

		// Token: 0x06003839 RID: 14393 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x6003839")]
		[Address(RVA = "0x33838EC", Offset = "0x33838EC", VA = "0x33838EC")]
		private void method_12()
		{
		}

		// Token: 0x0600383A RID: 14394 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600383A")]
		[Address(RVA = "0x33838F0", Offset = "0x33838F0", VA = "0x33838F0")]
		public void method_13(bool bool_17)
		{
		}

		// Token: 0x0600383B RID: 14395 RVA: 0x000707F0 File Offset: 0x0006E9F0
		[Token(Token = "0x600383B")]
		[Address(RVA = "0x3381900", Offset = "0x3381900", VA = "0x3381900")]
		protected void method_14(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)17254;
		}

		// Token: 0x0600383C RID: 14396 RVA: 0x000033B9 File Offset: 0x000015B9
		[Token(Token = "0x600383C")]
		[Address(RVA = "0x337F5B8", Offset = "0x337F5B8", VA = "0x337F5B8")]
		protected void method_15(ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)32768;
		}

		// Token: 0x0600383D RID: 14397 RVA: 0x00070808 File Offset: 0x0006EA08
		[Address(RVA = "0x3384040", Offset = "0x3384040", VA = "0x3384040")]
		[Token(Token = "0x600383D")]
		public bool method_16()
		{
			if (!this.bool_8)
			{
				return;
			}
		}

		// Token: 0x0600383E RID: 14398 RVA: 0x00070820 File Offset: 0x0006EA20
		[Token(Token = "0x600383E")]
		[Address(RVA = "0x3384060", Offset = "0x3384060", VA = "0x3384060")]
		private void method_17()
		{
			string manufacturer = this.method_38().manufacturer;
			string name = this.method_64().name;
			this.method_105(manufacturer, name);
			string manufacturer2 = this.InputDevice_0.manufacturer;
			this.method_26().name.ToLower();
			manufacturer2.ToLower().Contains("True");
			this.bool_9 = ("True" != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			int num;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				InputFeatureUsage<Vector2> primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				num = 107;
				this.genum24_1 = (GEnum24)107;
			}
			this.method_91();
			this.method_72();
			this.bool_14 = (num != 0);
		}

		// Token: 0x0600383F RID: 14399 RVA: 0x0006BB9C File Offset: 0x00069D9C
		[Token(Token = "0x600383F")]
		[Address(RVA = "0x337FC00", Offset = "0x337FC00", VA = "0x337FC00")]
		protected void method_18(ref PlayerInputState playerInputState_11, bool bool_17)
		{
			playerInputState_11.Active = (257 != 0);
		}

		// Token: 0x06003840 RID: 14400 RVA: 0x000708F4 File Offset: 0x0006EAF4
		[Address(RVA = "0x3384624", Offset = "0x3384624", VA = "0x3384624")]
		[Token(Token = "0x6003840")]
		private void method_19()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06003841 RID: 14401 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Token(Token = "0x170000E8")]
		public InputDevice InputDevice_0
		{
			[Token(Token = "0x6003841")]
			[Address(RVA = "0x337F860", Offset = "0x337F860", VA = "0x337F860")]
			get
			{
				return this.inputDevice_0;
			}
		}

		// Token: 0x06003842 RID: 14402 RVA: 0x00070808 File Offset: 0x0006EA08
		[Address(RVA = "0x3384730", Offset = "0x3384730", VA = "0x3384730")]
		[Token(Token = "0x6003842")]
		public bool method_20()
		{
			if (!this.bool_8)
			{
				return;
			}
		}

		// Token: 0x06003843 RID: 14403 RVA: 0x0007092C File Offset: 0x0006EB2C
		[Token(Token = "0x6003843")]
		[Address(RVA = "0x338320C", Offset = "0x338320C", VA = "0x338320C")]
		private void method_21()
		{
			string manufacturer = this.method_26().manufacturer;
			string name = this.method_38().name;
			string manufacturer2 = this.method_22().manufacturer;
			this.method_115().name.ToLower();
			manufacturer2.ToLower().Contains("Vector1_d371bd24217449349bd747533d51af6b");
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			InputFeatureUsage<Vector2> primary2DAxis2;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				this.genum24_1 = primary2DAxis2;
			}
			this.method_116();
			this.method_50();
			this.bool_14 = (primary2DAxis2 != null);
		}

		// Token: 0x06003844 RID: 14404 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Token(Token = "0x6003844")]
		[Address(RVA = "0x338390C", Offset = "0x338390C", VA = "0x338390C")]
		public InputDevice method_22()
		{
			return this.inputDevice_0;
		}

		// Token: 0x06003845 RID: 14405 RVA: 0x000709E8 File Offset: 0x0006EBE8
		[Token(Token = "0x6003845")]
		[Address(RVA = "0x3384A8C", Offset = "0x3384A8C", VA = "0x3384A8C")]
		private void method_23()
		{
			this.method_104();
			this.method_112();
			this.playerInputState_3.Value = (float)40960;
			this.playerInputState_7.Value = (float)17254;
			this.playerInputState_9.Value = (float)32768;
		}

		// Token: 0x06003846 RID: 14406 RVA: 0x00070A34 File Offset: 0x0006EC34
		[Address(RVA = "0x3384E8C", Offset = "0x3384E8C", VA = "0x3384E8C")]
		[Token(Token = "0x6003846")]
		private void method_24()
		{
			this.vector2_1 = 17550;
			this.vector2_1.y = (float)49152;
		}

		// Token: 0x06003847 RID: 14407 RVA: 0x00003392 File Offset: 0x00001592
		[Address(RVA = "0x337FA60", Offset = "0x337FA60", VA = "0x337FA60")]
		[Token(Token = "0x6003847")]
		protected void method_25(ref PlayerInputState playerInputState_11, bool bool_17)
		{
			playerInputState_11.Active = (257 != 0);
		}

		// Token: 0x06003848 RID: 14408 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Token(Token = "0x6003848")]
		[Address(RVA = "0x3383FFC", Offset = "0x3383FFC", VA = "0x3383FFC")]
		public InputDevice method_26()
		{
			return this.inputDevice_0;
		}

		// Token: 0x06003849 RID: 14409 RVA: 0x00070A5C File Offset: 0x0006EC5C
		[Token(Token = "0x6003849")]
		[Address(RVA = "0x3384ECC", Offset = "0x3384ECC", VA = "0x3384ECC")]
		private void method_27()
		{
			this.vector2_1 = 32768;
			this.vector2_1.y = (float)17189;
		}

		// Token: 0x0600384A RID: 14410 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3384F0C", Offset = "0x3384F0C", VA = "0x3384F0C")]
		[Token(Token = "0x600384A")]
		public void method_28(bool bool_17)
		{
		}

		// Token: 0x0600384B RID: 14411 RVA: 0x00070808 File Offset: 0x0006EA08
		[Token(Token = "0x600384B")]
		[Address(RVA = "0x3384F18", Offset = "0x3384F18", VA = "0x3384F18")]
		public bool method_29()
		{
			if (!this.bool_8)
			{
				return;
			}
		}

		// Token: 0x0600384C RID: 14412 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x600384C")]
		[Address(RVA = "0x3384F38", Offset = "0x3384F38", VA = "0x3384F38")]
		public HexaXRInputs()
		{
		}

		// Token: 0x0600384D RID: 14413 RVA: 0x0007069C File Offset: 0x0006E89C
		[Token(Token = "0x600384D")]
		[Address(RVA = "0x337F8A4", Offset = "0x337F8A4", VA = "0x337F8A4")]
		public bool method_30(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x0600384E RID: 14414 RVA: 0x0007069C File Offset: 0x0006E89C
		[Token(Token = "0x600384E")]
		[Address(RVA = "0x3383E84", Offset = "0x3383E84", VA = "0x3383E84")]
		public bool method_31(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x0600384F RID: 14415 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Address(RVA = "0x3384F6C", Offset = "0x3384F6C", VA = "0x3384F6C")]
		[Token(Token = "0x600384F")]
		public InputDevice method_32()
		{
			return this.inputDevice_0;
		}

		// Token: 0x06003850 RID: 14416 RVA: 0x00070A84 File Offset: 0x0006EC84
		[Address(RVA = "0x338345C", Offset = "0x338345C", VA = "0x338345C")]
		[Token(Token = "0x6003850")]
		private void method_33()
		{
			this.vector2_1 = 17462;
			this.vector2_1.y = (float)16384;
		}

		// Token: 0x06003851 RID: 14417 RVA: 0x000035BF File Offset: 0x000017BF
		[Token(Token = "0x6003851")]
		[Address(RVA = "0x3384FB0", Offset = "0x3384FB0", VA = "0x3384FB0")]
		public bool method_34()
		{
			return this.bool_7;
		}

		// Token: 0x06003852 RID: 14418 RVA: 0x00070AAC File Offset: 0x0006ECAC
		[Token(Token = "0x6003852")]
		[Address(RVA = "0x3384FB8", Offset = "0x3384FB8", VA = "0x3384FB8")]
		private void method_35()
		{
			this.method_21();
			this.method_112();
			this.vector2_1 = 17550;
			this.vector2_1.y = (float)49152;
			this.playerInputState_3.Value = (float)17254;
			this.playerInputState_10.Value = (float)17254;
		}

		// Token: 0x06003853 RID: 14419 RVA: 0x0007069C File Offset: 0x0006E89C
		[Address(RVA = "0x337FA88", Offset = "0x337FA88", VA = "0x337FA88")]
		[Token(Token = "0x6003853")]
		public bool method_36(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x06003854 RID: 14420 RVA: 0x0007069C File Offset: 0x0006E89C
		[Token(Token = "0x6003854")]
		[Address(RVA = "0x338514C", Offset = "0x338514C", VA = "0x338514C")]
		public bool method_37(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x06003855 RID: 14421 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Token(Token = "0x6003855")]
		[Address(RVA = "0x3383E40", Offset = "0x3383E40", VA = "0x3383E40")]
		public InputDevice method_38()
		{
			return this.inputDevice_0;
		}

		// Token: 0x06003856 RID: 14422 RVA: 0x00070B00 File Offset: 0x0006ED00
		[Token(Token = "0x6003856")]
		[Address(RVA = "0x33852C4", Offset = "0x33852C4", VA = "0x33852C4")]
		private void method_39()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x06003857 RID: 14423 RVA: 0x0007069C File Offset: 0x0006E89C
		[Address(RVA = "0x337F6C8", Offset = "0x337F6C8", VA = "0x337F6C8")]
		[Token(Token = "0x6003857")]
		public bool method_40(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x06003858 RID: 14424 RVA: 0x00070B38 File Offset: 0x0006ED38
		[Token(Token = "0x6003858")]
		[Address(RVA = "0x33853E4", Offset = "0x33853E4", VA = "0x33853E4")]
		public bool method_41()
		{
		}

		// Token: 0x06003859 RID: 14425 RVA: 0x0000336B File Offset: 0x0000156B
		[Token(Token = "0x6003859")]
		[Address(RVA = "0x3385404", Offset = "0x3385404", VA = "0x3385404")]
		protected void method_42(ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)57344;
		}

		// Token: 0x0600385A RID: 14426 RVA: 0x0007069C File Offset: 0x0006E89C
		[Address(RVA = "0x337FC2C", Offset = "0x337FC2C", VA = "0x337FC2C")]
		[Token(Token = "0x600385A")]
		public bool method_43(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x0600385B RID: 14427 RVA: 0x00070B48 File Offset: 0x0006ED48
		[Token(Token = "0x600385B")]
		[Address(RVA = "0x338349C", Offset = "0x338349C", VA = "0x338349C")]
		protected void method_44(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)32768;
		}

		// Token: 0x0600385C RID: 14428 RVA: 0x00070B60 File Offset: 0x0006ED60
		[Token(Token = "0x600385C")]
		[Address(RVA = "0x338541C", Offset = "0x338541C", VA = "0x338541C")]
		private void method_45()
		{
			this.vector2_1 = 49152;
			this.vector2_1.y = (float)24576;
		}

		// Token: 0x0600385D RID: 14429 RVA: 0x00070B88 File Offset: 0x0006ED88
		[Address(RVA = "0x3385460", Offset = "0x3385460", VA = "0x3385460")]
		[Token(Token = "0x600385D")]
		private void method_46()
		{
			this.method_103();
			this.method_88();
			this.vector2_1 = 32768;
			this.vector2_1.y = (float)17189;
			this.playerInputState_7.Value = (float)32768;
		}

		// Token: 0x0600385E RID: 14430 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x600385E")]
		[Address(RVA = "0x338566C", Offset = "0x338566C", VA = "0x338566C")]
		public bool method_47()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x0600385F RID: 14431 RVA: 0x000708F4 File Offset: 0x0006EAF4
		[Token(Token = "0x600385F")]
		[Address(RVA = "0x3385674", Offset = "0x3385674", VA = "0x3385674")]
		private void method_48()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x06003860 RID: 14432 RVA: 0x000708F4 File Offset: 0x0006EAF4
		[Address(RVA = "0x3385798", Offset = "0x3385798", VA = "0x3385798")]
		[Token(Token = "0x6003860")]
		private void method_49()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06003861 RID: 14433 RVA: 0x00070808 File Offset: 0x0006EA08
		[Token(Token = "0x170000E7")]
		public bool Boolean_1
		{
			[Token(Token = "0x6003861")]
			[Address(RVA = "0x33858BC", Offset = "0x33858BC", VA = "0x33858BC")]
			get
			{
				if (!this.bool_8)
				{
					return;
				}
			}
		}

		// Token: 0x06003862 RID: 14434 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Token(Token = "0x6003862")]
		[Address(RVA = "0x337F684", Offset = "0x337F684", VA = "0x337F684")]
		public InputDevice method_50()
		{
			return this.inputDevice_0;
		}

		// Token: 0x06003863 RID: 14435 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x337F83C", Offset = "0x337F83C", VA = "0x337F83C")]
		[Token(Token = "0x6003863")]
		protected void method_51(ref PlayerInputState playerInputState_11, bool bool_17)
		{
		}

		// Token: 0x06003864 RID: 14436 RVA: 0x00070BCC File Offset: 0x0006EDCC
		[Token(Token = "0x6003864")]
		[Address(RVA = "0x33858DC", Offset = "0x33858DC", VA = "0x33858DC")]
		private void method_52()
		{
			this.method_92();
			this.method_2();
		}

		// Token: 0x06003865 RID: 14437 RVA: 0x00070BE8 File Offset: 0x0006EDE8
		[Token(Token = "0x6003865")]
		[Address(RVA = "0x3385C18", Offset = "0x3385C18", VA = "0x3385C18")]
		private void method_53()
		{
			string manufacturer = this.method_122().manufacturer;
			string name = this.method_26().name;
			this.method_3(manufacturer, name);
			string manufacturer2 = this.method_118().manufacturer;
			this.InputDevice_0.name.ToLower();
			manufacturer2.ToLower().Contains("back");
			this.bool_9 = ("back" != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			long num;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				InputFeatureUsage<Vector2> primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				num = -7L;
				this.genum24_1 = (GEnum24)num;
			}
			this.method_39();
			this.method_115();
			this.bool_14 = (num != 0L);
		}

		// Token: 0x06003866 RID: 14438 RVA: 0x00070CBC File Offset: 0x0006EEBC
		[Address(RVA = "0x3385E68", Offset = "0x3385E68", VA = "0x3385E68")]
		[Token(Token = "0x6003866")]
		private void method_54()
		{
			this.method_53();
			this.method_86();
			this.playerInputState_2.Value = (float)40960;
			this.playerInputState_8.Value = (float)40960;
			this.playerInputState_9.Value = (float)40960;
		}

		// Token: 0x06003867 RID: 14439 RVA: 0x00070D08 File Offset: 0x0006EF08
		// Note: this type is marked as 'beforefieldinit'.
		[Token(Token = "0x6003867")]
		[Address(RVA = "0x3385FE4", Offset = "0x3385FE4", VA = "0x3385FE4")]
		static HexaXRInputs()
		{
			HexaXRInputs.Struct1[] array = new HexaXRInputs.Struct1[22];
			HexaXRInputs.struct1_0 = array;
		}

		// Token: 0x06003868 RID: 14440 RVA: 0x00070D24 File Offset: 0x0006EF24
		[Token(Token = "0x6003868")]
		[Address(RVA = "0x3381F28", Offset = "0x3381F28", VA = "0x3381F28")]
		private void method_55()
		{
			string manufacturer = this.method_64().manufacturer;
			string name = this.method_6().name;
			this.method_3(manufacturer, name);
			string manufacturer2 = this.method_26().manufacturer;
			this.method_32().name.ToLower();
			manufacturer2.ToLower().Contains("retract broken");
			this.bool_9 = ("retract broken" != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			InputFeatureUsage<Vector2> primary2DAxis2;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				this.genum24_1 = primary2DAxis2;
			}
			this.method_65();
			this.method_50();
			this.bool_14 = (primary2DAxis2 != null);
		}

		// Token: 0x06003869 RID: 14441 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x33867E8", Offset = "0x33867E8", VA = "0x33867E8")]
		[Token(Token = "0x6003869")]
		private void method_56()
		{
		}

		// Token: 0x0600386A RID: 14442 RVA: 0x00070DF4 File Offset: 0x0006EFF4
		[Token(Token = "0x600386A")]
		[Address(RVA = "0x33867EC", Offset = "0x33867EC", VA = "0x33867EC")]
		private void method_57()
		{
			this.method_73();
			this.method_86();
			this.vector2_1 = 17462;
			this.vector2_1.y = (float)16384;
			this.playerInputState_8.Value = (float)17254;
			this.playerInputState_10.Value = (float)17254;
		}

		// Token: 0x0600386B RID: 14443 RVA: 0x00070E48 File Offset: 0x0006F048
		[Address(RVA = "0x3386BB8", Offset = "0x3386BB8", VA = "0x3386BB8")]
		[Token(Token = "0x600386B")]
		private void method_58()
		{
			string manufacturer = this.method_22().manufacturer;
			string name = this.method_6().name;
			this.method_0(manufacturer, name);
			string manufacturer2 = this.method_50().manufacturer;
			this.method_50().name.ToLower();
			manufacturer2.ToLower().Contains("");
			this.bool_9 = ("" != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			InputFeatureUsage<Vector2> primary2DAxis2 = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_1 = primary2DAxis2;
			this.genum24_1 = primary2DAxis2;
			this.method_39();
			this.method_122();
			this.bool_14 = (primary2DAxis2 != null);
		}

		// Token: 0x0600386C RID: 14444 RVA: 0x000035BF File Offset: 0x000017BF
		[Token(Token = "0x600386C")]
		[Address(RVA = "0x3386E08", Offset = "0x3386E08", VA = "0x3386E08")]
		public bool method_59()
		{
			return this.bool_7;
		}

		// Token: 0x0600386D RID: 14445 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3386E10", Offset = "0x3386E10", VA = "0x3386E10")]
		[Token(Token = "0x600386D")]
		private void method_60()
		{
		}

		// Token: 0x0600386E RID: 14446 RVA: 0x00070F08 File Offset: 0x0006F108
		[Address(RVA = "0x3381488", Offset = "0x3381488", VA = "0x3381488")]
		[Token(Token = "0x600386E")]
		protected void method_61(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)17254;
		}

		// Token: 0x0600386F RID: 14447 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600386F")]
		[Address(RVA = "0x3386F8C", Offset = "0x3386F8C", VA = "0x3386F8C")]
		public void method_62(bool bool_17)
		{
		}

		// Token: 0x06003870 RID: 14448 RVA: 0x00070F20 File Offset: 0x0006F120
		[Address(RVA = "0x33807B4", Offset = "0x33807B4", VA = "0x33807B4")]
		[Token(Token = "0x6003870")]
		protected void method_63(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
		}

		// Token: 0x06003871 RID: 14449 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Address(RVA = "0x3383C84", Offset = "0x3383C84", VA = "0x3383C84")]
		[Token(Token = "0x6003871")]
		public InputDevice method_64()
		{
			return this.inputDevice_0;
		}

		// Token: 0x06003872 RID: 14450 RVA: 0x00070F30 File Offset: 0x0006F130
		[Address(RVA = "0x3387110", Offset = "0x3387110", VA = "0x3387110")]
		[Token(Token = "0x6003872")]
		private void Start()
		{
			long num = 1L;
			this.bool_15 = (num != 0L);
		}

		// Token: 0x06003873 RID: 14451 RVA: 0x000708F4 File Offset: 0x0006EAF4
		[Address(RVA = "0x33866C4", Offset = "0x33866C4", VA = "0x33866C4")]
		[Token(Token = "0x6003873")]
		private void method_65()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x06003874 RID: 14452 RVA: 0x0006BB80 File Offset: 0x00069D80
		[Address(RVA = "0x337F614", Offset = "0x337F614", VA = "0x337F614")]
		[Token(Token = "0x6003874")]
		protected void method_66(ref PlayerInputState playerInputState_11, bool bool_17)
		{
			long active = 256L;
			playerInputState_11.Active = (active != 0L);
		}

		// Token: 0x06003875 RID: 14453 RVA: 0x000035BF File Offset: 0x000017BF
		[Address(RVA = "0x338711C", Offset = "0x338711C", VA = "0x338711C")]
		[Token(Token = "0x6003875")]
		public bool method_67()
		{
			return this.bool_7;
		}

		// Token: 0x06003876 RID: 14454 RVA: 0x00070F48 File Offset: 0x0006F148
		[Address(RVA = "0x3387124", Offset = "0x3387124", VA = "0x3387124")]
		[Token(Token = "0x6003876")]
		private void method_68()
		{
			this.method_92();
			this.method_86();
			this.vector2_1 = 17462;
			this.vector2_1.y = (float)16384;
			this.playerInputState_4.Value = (float)32768;
			this.playerInputState_7.Value = (float)32768;
			this.playerInputState_9.Value = (float)17254;
			this.playerInputState_10.Value = (float)17254;
		}

		// Token: 0x06003877 RID: 14455 RVA: 0x000035C7 File Offset: 0x000017C7
		[Address(RVA = "0x338726C", Offset = "0x338726C", VA = "0x338726C")]
		[Token(Token = "0x6003877")]
		protected void method_69(ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)16384;
		}

		// Token: 0x06003878 RID: 14456 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3387280", Offset = "0x3387280", VA = "0x3387280")]
		[Token(Token = "0x6003878")]
		private void FixedUpdate()
		{
		}

		// Token: 0x06003879 RID: 14457 RVA: 0x00070FBC File Offset: 0x0006F1BC
		[Token(Token = "0x6003879")]
		[Address(RVA = "0x33821D8", Offset = "0x33821D8", VA = "0x33821D8")]
		protected void method_70(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
		}

		// Token: 0x0600387A RID: 14458 RVA: 0x00070FCC File Offset: 0x0006F1CC
		[Address(RVA = "0x3381030", Offset = "0x3381030", VA = "0x3381030")]
		[Token(Token = "0x600387A")]
		protected void method_71(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
		}

		// Token: 0x0600387B RID: 14459 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Address(RVA = "0x33845E0", Offset = "0x33845E0", VA = "0x33845E0")]
		[Token(Token = "0x600387B")]
		public InputDevice method_72()
		{
			return this.inputDevice_0;
		}

		// Token: 0x0600387C RID: 14460 RVA: 0x00070FDC File Offset: 0x0006F1DC
		[Address(RVA = "0x3386968", Offset = "0x3386968", VA = "0x3386968")]
		[Token(Token = "0x600387C")]
		private void method_73()
		{
			string manufacturer = this.method_122().manufacturer;
			string name = this.method_72().name;
			this.method_81(manufacturer, name);
			string manufacturer2 = this.method_77().manufacturer;
			this.method_77().name.ToLower();
			manufacturer2.ToLower().Contains("username");
			this.bool_9 = ("username" != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			InputFeatureUsage<Vector2> primary2DAxis2;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				this.genum24_1 = primary2DAxis2;
			}
			this.method_117();
			this.method_118();
			this.bool_14 = (primary2DAxis2 != null);
		}

		// Token: 0x0600387D RID: 14461 RVA: 0x000035D4 File Offset: 0x000017D4
		[Address(RVA = "0x33875E0", Offset = "0x33875E0", VA = "0x33875E0")]
		[Token(Token = "0x600387D")]
		private void method_74()
		{
			this.method_8();
		}

		// Token: 0x0600387E RID: 14462 RVA: 0x000710AC File Offset: 0x0006F2AC
		[Token(Token = "0x600387E")]
		[Address(RVA = "0x3382A64", Offset = "0x3382A64", VA = "0x3382A64")]
		protected void method_75(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)17254;
		}

		// Token: 0x0600387F RID: 14463 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x600387F")]
		[Address(RVA = "0x33875E4", Offset = "0x33875E4", VA = "0x33875E4")]
		public void method_76(bool bool_17)
		{
		}

		// Token: 0x06003880 RID: 14464 RVA: 0x000710C4 File Offset: 0x0006F2C4
		[Token(Token = "0x6003880")]
		[Address(RVA = "0x3383AC8", Offset = "0x3383AC8", VA = "0x3383AC8")]
		public InputDevice method_77()
		{
			InputDevice result;
			return result;
		}

		// Token: 0x06003881 RID: 14465 RVA: 0x0007069C File Offset: 0x0006E89C
		[Token(Token = "0x6003881")]
		[Address(RVA = "0x3386E14", Offset = "0x3386E14", VA = "0x3386E14")]
		public bool method_78(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x06003882 RID: 14466 RVA: 0x000710D4 File Offset: 0x0006F2D4
		[Token(Token = "0x6003882")]
		[Address(RVA = "0x3382EB0", Offset = "0x3382EB0", VA = "0x3382EB0")]
		private void method_79()
		{
			this.method_53();
			this.method_86();
			this.vector2_1 = 32768;
			this.vector2_1.y = (float)17189;
			this.playerInputState_3.Value = (float)32768;
			this.playerInputState_7.Value = (float)17254;
			this.playerInputState_8.Value = (float)17254;
			this.playerInputState_9.Value = (float)40960;
			this.playerInputState_10.Value = (float)17254;
		}

		// Token: 0x06003883 RID: 14467 RVA: 0x00071158 File Offset: 0x0006F358
		[Address(RVA = "0x3380780", Offset = "0x3380780", VA = "0x3380780")]
		[Token(Token = "0x6003883")]
		private void method_80()
		{
		}

		// Token: 0x06003884 RID: 14468 RVA: 0x00071168 File Offset: 0x0006F368
		[Token(Token = "0x6003884")]
		[Address(RVA = "0x33872A8", Offset = "0x33872A8", VA = "0x33872A8")]
		private void method_81(string string_8, string string_9)
		{
			long num = 1L;
			this.bool_8 = (num != 0L);
			string.IsNullOrWhiteSpace(string_8);
			string.IsNullOrWhiteSpace(string_9);
			string text = string_9.ToLower();
			string text2;
			text2.Contains("PRESS AGAIN TO CONFIRM");
			long num2 = 1L;
			this.bool_12 = (num2 != 0L);
			text.Contains("This is the 2500 Bananas button, and it was just clicked");
			long num3 = 1L;
			this.bool_13 = (num3 != 0L);
			text2.Contains("_Tint");
			text.Contains("Right Hand");
			text2.Contains("ChangeToTagged");
			text.Contains("lava");
			text.Contains("Cannot access index {0}. Buffer is empty");
		}

		// Token: 0x06003885 RID: 14469 RVA: 0x00070B38 File Offset: 0x0006ED38
		[Address(RVA = "0x33875F0", Offset = "0x33875F0", VA = "0x33875F0")]
		[Token(Token = "0x6003885")]
		public bool method_82()
		{
		}

		// Token: 0x06003886 RID: 14470 RVA: 0x00071204 File Offset: 0x0006F404
		[Token(Token = "0x6003886")]
		[Address(RVA = "0x3387610", Offset = "0x3387610", VA = "0x3387610")]
		private void method_83(string string_8, string string_9)
		{
			string.IsNullOrWhiteSpace(string_8);
			string.IsNullOrWhiteSpace(string_9);
			string text = string_9.ToLower();
			string text2;
			text2.Contains("Are you sure you would like to buy 2500 Bananas for $4.99? You will be spending REAL money and getting the currency you want, as it is what you will be paying for. -Joe.");
			long num = 1L;
			this.bool_12 = (num != 0L);
			text.Contains("Queue");
			long num2 = 1L;
			this.bool_13 = (num2 != 0L);
			text2.Contains("A Player has left the Room.");
			text.Contains("Holdable");
			text2.Contains("Round end");
			text.Contains("Add/Remove Sword");
			text.Contains("HorrorAgreement");
			long num3 = 1L;
			this.bool_11 = (num3 != 0L);
		}

		// Token: 0x06003887 RID: 14471 RVA: 0x0007129C File Offset: 0x0006F49C
		[Address(RVA = "0x338263C", Offset = "0x338263C", VA = "0x338263C")]
		[Token(Token = "0x6003887")]
		protected void method_84(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
		}

		// Token: 0x06003888 RID: 14472 RVA: 0x000033F0 File Offset: 0x000015F0
		[Token(Token = "0x6003888")]
		[Address(RVA = "0x3387820", Offset = "0x3387820", VA = "0x3387820")]
		protected void method_85(ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)40960;
		}

		// Token: 0x06003889 RID: 14473 RVA: 0x000712AC File Offset: 0x0006F4AC
		[Token(Token = "0x6003889")]
		[Address(RVA = "0x3382178", Offset = "0x3382178", VA = "0x3382178")]
		protected void method_86()
		{
			this.method_38();
			this.method_64();
		}

		// Token: 0x0600388A RID: 14474 RVA: 0x000035BF File Offset: 0x000017BF
		[Token(Token = "0x600388A")]
		[Address(RVA = "0x3387834", Offset = "0x3387834", VA = "0x3387834")]
		public bool method_87()
		{
			return this.bool_7;
		}

		// Token: 0x0600388B RID: 14475 RVA: 0x000712C8 File Offset: 0x0006F4C8
		[Token(Token = "0x600388B")]
		[Address(RVA = "0x338560C", Offset = "0x338560C", VA = "0x338560C")]
		protected void method_88()
		{
			this.method_122();
			InputDevice inputDevice = this.InputDevice_0;
		}

		// Token: 0x0600388C RID: 14476 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3387284", Offset = "0x3387284", VA = "0x3387284")]
		[Token(Token = "0x600388C")]
		protected void method_89(ref PlayerInputState playerInputState_11)
		{
		}

		// Token: 0x0600388D RID: 14477 RVA: 0x000035BF File Offset: 0x000017BF
		[Address(RVA = "0x338783C", Offset = "0x338783C", VA = "0x338783C")]
		[Token(Token = "0x600388D")]
		public bool method_90()
		{
			return this.bool_7;
		}

		// Token: 0x0600388E RID: 14478 RVA: 0x000712E4 File Offset: 0x0006F4E4
		[Token(Token = "0x600388E")]
		[Address(RVA = "0x33844BC", Offset = "0x33844BC", VA = "0x33844BC")]
		private void method_91()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x0600388F RID: 14479 RVA: 0x0007131C File Offset: 0x0006F51C
		[Token(Token = "0x600388F")]
		[Address(RVA = "0x33859E0", Offset = "0x33859E0", VA = "0x33859E0")]
		private void method_92()
		{
			string manufacturer = this.InputDevice_0.manufacturer;
			string name = this.InputDevice_0.name;
			this.method_107(manufacturer, name);
			string manufacturer2 = this.InputDevice_0.manufacturer;
			this.InputDevice_0.name.ToLower();
			manufacturer2.ToLower().Contains("openvr");
			this.bool_9 = ("openvr" != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			this.inputFeatureUsage_1 = primary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			int num;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				this.inputFeatureUsage_1 = flag;
				num = 11;
				this.genum24_1 = GEnum24.const_11;
			}
			this.method_19();
			InputDevice inputDevice = this.InputDevice_0;
			this.bool_14 = (num != 0);
		}

		// Token: 0x06003890 RID: 14480 RVA: 0x0007069C File Offset: 0x0006E89C
		[Address(RVA = "0x3383B0C", Offset = "0x3383B0C", VA = "0x3383B0C")]
		[Token(Token = "0x6003890")]
		public bool method_93(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x06003891 RID: 14481 RVA: 0x000713E4 File Offset: 0x0006F5E4
		[Token(Token = "0x6003891")]
		[Address(RVA = "0x3387A44", Offset = "0x3387A44", VA = "0x3387A44")]
		private void method_94()
		{
			string manufacturer = this.method_77().manufacturer;
			string name = this.method_22().name;
			this.method_105(manufacturer, name);
			string manufacturer2 = this.method_77().manufacturer;
			this.method_32().name.ToLower();
			manufacturer2.ToLower().Contains("A new Player joined a Room.");
			this.bool_9 = ("A new Player joined a Room." != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			int num;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				InputFeatureUsage<Vector2> primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				num = 109;
				this.genum24_1 = (GEnum24)109;
			}
			this.method_117();
			this.method_64();
			this.bool_14 = (num != 0);
		}

		// Token: 0x06003892 RID: 14482 RVA: 0x000035DC File Offset: 0x000017DC
		[Address(RVA = "0x3387C94", Offset = "0x3387C94", VA = "0x3387C94")]
		[Token(Token = "0x6003892")]
		private void Update()
		{
			this.method_52();
		}

		// Token: 0x06003893 RID: 14483 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3387C98", Offset = "0x3387C98", VA = "0x3387C98")]
		[Token(Token = "0x6003893")]
		private void method_95()
		{
		}

		// Token: 0x06003894 RID: 14484 RVA: 0x000714B8 File Offset: 0x0006F6B8
		[Token(Token = "0x6003894")]
		[Address(RVA = "0x3384750", Offset = "0x3384750", VA = "0x3384750")]
		private void method_96(string string_8, string string_9)
		{
			string.IsNullOrWhiteSpace(string_8);
			string.IsNullOrWhiteSpace(string_9);
			string text = string_9.ToLower();
			string text2;
			text2.Contains("Pause");
			long num = 1L;
			this.bool_12 = (num != 0L);
			text.Contains("HandR");
			long num2 = 1L;
			this.bool_13 = (num2 != 0L);
			text2.Contains("Failed to login, please restart");
			text.Contains("\n Time: ");
			long num3 = 1L;
			this.bool_10 = (num3 != 0L);
			text2.Contains("DisableCosmetic");
			text.Contains("INSIGNIFICANT CURRENCY");
			long num4 = 1L;
			this.bool_8 = (num4 != 0L);
			text.Contains("_Tint");
			long num5 = 1L;
			this.bool_11 = (num5 != 0L);
		}

		// Token: 0x06003895 RID: 14485 RVA: 0x000035E4 File Offset: 0x000017E4
		[Address(RVA = "0x3387C9C", Offset = "0x3387C9C", VA = "0x3387C9C")]
		[Token(Token = "0x6003895")]
		private void method_97()
		{
			this.method_101();
		}

		// Token: 0x06003896 RID: 14486 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3387E50", Offset = "0x3387E50", VA = "0x3387E50")]
		[Token(Token = "0x6003896")]
		public void method_98(bool bool_17)
		{
		}

		// Token: 0x06003897 RID: 14487 RVA: 0x00071568 File Offset: 0x0006F768
		[Address(RVA = "0x3380C0C", Offset = "0x3380C0C", VA = "0x3380C0C")]
		[Token(Token = "0x6003897")]
		protected void method_99(GEnum23 genum23_0, ref PlayerInputState playerInputState_11)
		{
		}

		// Token: 0x06003898 RID: 14488 RVA: 0x00002083 File Offset: 0x00000283
		[Address(RVA = "0x3387E5C", Offset = "0x3387E5C", VA = "0x3387E5C")]
		[Token(Token = "0x6003898")]
		private void method_100()
		{
		}

		// Token: 0x06003899 RID: 14489 RVA: 0x00071578 File Offset: 0x0006F778
		[Address(RVA = "0x3387CA0", Offset = "0x3387CA0", VA = "0x3387CA0")]
		[Token(Token = "0x6003899")]
		private void method_101()
		{
			this.method_103();
			this.method_88();
			this.vector2_1 = 32768;
			this.vector2_1.y = (float)17189;
			this.playerInputState_3.Value = (float)17254;
			this.playerInputState_7.Value = (float)32768;
			this.playerInputState_8.Value = (float)17254;
			this.playerInputState_10.Value = (float)32768;
		}

		// Token: 0x0600389A RID: 14490 RVA: 0x00070F30 File Offset: 0x0006F130
		[Token(Token = "0x600389A")]
		[Address(RVA = "0x3387E64", Offset = "0x3387E64", VA = "0x3387E64")]
		private void method_102()
		{
			long num = 1L;
			this.bool_15 = (num != 0L);
		}

		// Token: 0x0600389B RID: 14491 RVA: 0x000715EC File Offset: 0x0006F7EC
		[Address(RVA = "0x33804D0", Offset = "0x33804D0", VA = "0x33804D0")]
		[Token(Token = "0x600389B")]
		private void method_103()
		{
			string manufacturer = this.method_118().manufacturer;
			string name = this.method_26().name;
			this.method_96(manufacturer, name);
			string manufacturer2 = this.method_122().manufacturer;
			this.method_50().name.ToLower();
			manufacturer2.ToLower().Contains("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
			this.bool_9 = ("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n" != null);
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8 || !this.bool_9)
			{
			}
			bool flag;
			InputFeatureUsage<Vector2> primary2DAxis2;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				this.genum24_1 = primary2DAxis2;
			}
			this.method_49();
			this.method_26();
			this.bool_14 = (primary2DAxis2 != null);
		}

		// Token: 0x0600389C RID: 14492 RVA: 0x000716BC File Offset: 0x0006F8BC
		[Address(RVA = "0x3384C3C", Offset = "0x3384C3C", VA = "0x3384C3C")]
		[Token(Token = "0x600389C")]
		private void method_104()
		{
			string manufacturer = this.method_122().manufacturer;
			string name = this.method_26().name;
			this.method_107(manufacturer, name);
			string manufacturer2 = this.InputDevice_0.manufacturer;
			this.method_26().name.ToLower();
			manufacturer2.ToLower();
			InputFeatureUsage<Vector2> primary2DAxis = CommonUsages.primary2DAxis;
			this.inputFeatureUsage_0 = primary2DAxis;
			InputFeatureUsage<Vector2> secondary2DAxis = CommonUsages.secondary2DAxis;
			this.inputFeatureUsage_1 = secondary2DAxis;
			if (!this.bool_8)
			{
			}
			bool flag;
			InputFeatureUsage<Vector2> primary2DAxis2;
			if (flag = this.bool_10)
			{
				if (flag)
				{
				}
				primary2DAxis2 = CommonUsages.primary2DAxis;
				this.inputFeatureUsage_1 = primary2DAxis2;
				this.genum24_1 = primary2DAxis2;
			}
			this.method_91();
			InputDevice inputDevice = this.InputDevice_0;
			this.bool_14 = (primary2DAxis2 != null);
		}

		// Token: 0x0600389D RID: 14493 RVA: 0x00071770 File Offset: 0x0006F970
		[Token(Token = "0x600389D")]
		[Address(RVA = "0x33842B0", Offset = "0x33842B0", VA = "0x33842B0")]
		private void method_105(string string_8, string string_9)
		{
			long num = 1L;
			this.bool_8 = (num != 0L);
			string.IsNullOrWhiteSpace(string_8);
			string.IsNullOrWhiteSpace(string_9);
			string text = string_9.ToLower();
			string text2;
			text2.Contains("Damaged Arm");
			long num2 = 1L;
			this.bool_12 = (num2 != 0L);
			text.Contains("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
			long num3 = 1L;
			this.bool_13 = (num3 != 0L);
			text2.Contains("username");
			text.Contains("true");
			long num4 = 1L;
			this.bool_10 = (num4 != 0L);
			text2.Contains("PRESS AGAIN TO CONFIRM");
			text.Contains("jump char false");
			long num5 = 1L;
			this.bool_8 = (num5 != 0L);
			text.Contains("TurnAmount");
			long num6 = 1L;
			this.bool_11 = (num6 != 0L);
		}

		// Token: 0x0600389E RID: 14494 RVA: 0x00070808 File Offset: 0x0006EA08
		[Address(RVA = "0x3387E70", Offset = "0x3387E70", VA = "0x3387E70")]
		[Token(Token = "0x600389E")]
		public bool method_106()
		{
			if (!this.bool_8)
			{
				return;
			}
		}

		// Token: 0x0600389F RID: 14495 RVA: 0x0007182C File Offset: 0x0006FA2C
		[Address(RVA = "0x3387844", Offset = "0x3387844", VA = "0x3387844")]
		[Token(Token = "0x600389F")]
		private void method_107(string string_8, string string_9)
		{
			string.IsNullOrWhiteSpace(string_8);
			string.IsNullOrWhiteSpace(string_9);
			string text = string_9.ToLower();
			string text2;
			text2.Contains("oculus");
			long num = 1L;
			this.bool_12 = (num != 0L);
			text.Contains("cosmos");
			long num2 = 1L;
			this.bool_13 = (num2 != 0L);
			text2.Contains("htc");
			text.Contains("vive");
			long num3 = 1L;
			this.bool_10 = (num3 != 0L);
			text2.Contains("windowsmr");
			text.Contains("spatial");
			long num4 = 1L;
			this.bool_8 = (num4 != 0L);
			text.Contains("knuckles");
			long num5 = 1L;
			this.bool_11 = (num5 != 0L);
		}

		// Token: 0x060038A0 RID: 14496 RVA: 0x000035BF File Offset: 0x000017BF
		[Address(RVA = "0x3387E90", Offset = "0x3387E90", VA = "0x3387E90")]
		[Token(Token = "0x60038A0")]
		public bool method_108()
		{
			return this.bool_7;
		}

		// Token: 0x060038A1 RID: 14497 RVA: 0x000718DC File Offset: 0x0006FADC
		[Token(Token = "0x60038A1")]
		[Address(RVA = "0x3383CC8", Offset = "0x3383CC8", VA = "0x3383CC8")]
		public bool method_109(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x060038A2 RID: 14498 RVA: 0x000035EC File Offset: 0x000017EC
		[Token(Token = "0x60038A2")]
		[Address(RVA = "0x33838FC", Offset = "0x33838FC", VA = "0x33838FC")]
		protected void method_110(ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)17254;
		}

		// Token: 0x060038A3 RID: 14499 RVA: 0x000033F0 File Offset: 0x000015F0
		[Address(RVA = "0x3387290", Offset = "0x3387290", VA = "0x3387290")]
		[Token(Token = "0x60038A3")]
		protected void method_111(ref PlayerInputState playerInputState_11)
		{
			playerInputState_11.Value = (float)40960;
		}

		// Token: 0x060038A4 RID: 14500 RVA: 0x000718EC File Offset: 0x0006FAEC
		[Address(RVA = "0x3380720", Offset = "0x3380720", VA = "0x3380720")]
		[Token(Token = "0x60038A4")]
		protected void method_112()
		{
			this.method_22();
			this.method_122();
		}

		// Token: 0x060038A5 RID: 14501 RVA: 0x0007069C File Offset: 0x0006E89C
		[Token(Token = "0x60038A5")]
		[Address(RVA = "0x337FDE4", Offset = "0x337FDE4", VA = "0x337FDE4")]
		public bool method_113(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x060038A6 RID: 14502 RVA: 0x00002068 File Offset: 0x00000268
		// (set) Token: 0x060038AE RID: 14510 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x170000E6")]
		public bool Boolean_0
		{
			[CompilerGenerated]
			[Address(RVA = "0x3387E98", Offset = "0x3387E98", VA = "0x3387E98")]
			[Token(Token = "0x60038A6")]
			get
			{
				throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
			}
			[CompilerGenerated]
			[Address(RVA = "0x3387EAC", Offset = "0x3387EAC", VA = "0x3387EAC")]
			[Token(Token = "0x60038AE")]
			set
			{
			}
		}

		// Token: 0x060038A7 RID: 14503 RVA: 0x00002083 File Offset: 0x00000283
		[Token(Token = "0x60038A7")]
		[Address(RVA = "0x3387EA0", Offset = "0x3387EA0", VA = "0x3387EA0")]
		private void method_114()
		{
		}

		// Token: 0x060038A8 RID: 14504 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Address(RVA = "0x337F640", Offset = "0x337F640", VA = "0x337F640")]
		[Token(Token = "0x60038A8")]
		public InputDevice method_115()
		{
			return this.inputDevice_0;
		}

		// Token: 0x060038A9 RID: 14505 RVA: 0x000708F4 File Offset: 0x0006EAF4
		[Address(RVA = "0x3384968", Offset = "0x3384968", VA = "0x3384968")]
		[Token(Token = "0x60038A9")]
		private void method_116()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x060038AA RID: 14506 RVA: 0x000708F4 File Offset: 0x0006EAF4
		[Address(RVA = "0x33874BC", Offset = "0x33874BC", VA = "0x33874BC")]
		[Token(Token = "0x60038AA")]
		private void method_117()
		{
			Vector3 zero = Vector3.zero;
			Vector3 zero2 = Vector3.zero;
			if (this.bool_9)
			{
				return;
			}
			if (this.bool_0)
			{
				Vector3 localPosition = this.transform_0.localPosition;
				return;
			}
		}

		// Token: 0x060038AB RID: 14507 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Token(Token = "0x60038AB")]
		[Address(RVA = "0x337F5D0", Offset = "0x337F5D0", VA = "0x337F5D0")]
		public InputDevice method_118()
		{
			return this.inputDevice_0;
		}

		// Token: 0x060038AC RID: 14508 RVA: 0x000035F9 File Offset: 0x000017F9
		[Address(RVA = "0x3387EA8", Offset = "0x3387EA8", VA = "0x3387EA8")]
		[Token(Token = "0x60038AC")]
		private void method_119()
		{
			this.method_68();
		}

		// Token: 0x060038AD RID: 14509 RVA: 0x0007069C File Offset: 0x0006E89C
		[Address(RVA = "0x3386F98", Offset = "0x3386F98", VA = "0x3386F98")]
		[Token(Token = "0x60038AD")]
		public bool method_120(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x060038AF RID: 14511 RVA: 0x00071908 File Offset: 0x0006FB08
		[Address(RVA = "0x3383950", Offset = "0x3383950", VA = "0x3383950")]
		[Token(Token = "0x60038AF")]
		public bool method_121(InputDevice inputDevice_1, GEnum24 genum24_2, float float_8 = 0f)
		{
			return false;
		}

		// Token: 0x060038B0 RID: 14512 RVA: 0x000706AC File Offset: 0x0006E8AC
		[Address(RVA = "0x337FDA0", Offset = "0x337FDA0", VA = "0x337FDA0")]
		[Token(Token = "0x60038B0")]
		public InputDevice method_122()
		{
			return this.inputDevice_0;
		}

		// Token: 0x04000975 RID: 2421
		[Token(Token = "0x4000975")]
		public const string string_0 = "openvr";

		// Token: 0x04000976 RID: 2422
		[Token(Token = "0x4000976")]
		public const string string_1 = "windowsmr";

		// Token: 0x04000977 RID: 2423
		[Token(Token = "0x4000977")]
		public const string string_2 = "vive";

		// Token: 0x04000978 RID: 2424
		[Token(Token = "0x4000978")]
		public const string string_3 = "cosmos";

		// Token: 0x04000979 RID: 2425
		[Token(Token = "0x4000979")]
		public const string string_4 = "oculus";

		// Token: 0x0400097A RID: 2426
		[Token(Token = "0x400097A")]
		public const string string_5 = "knuckles";

		// Token: 0x0400097B RID: 2427
		[Token(Token = "0x400097B")]
		public const string string_6 = "spatial";

		// Token: 0x0400097C RID: 2428
		[Token(Token = "0x400097C")]
		public const string string_7 = "htc";

		// Token: 0x0400097D RID: 2429
		[Token(Token = "0x400097D")]
		[FieldOffset(Offset = "0x18")]
		public Transform transform_0;

		// Token: 0x0400097E RID: 2430
		[Token(Token = "0x400097E")]
		[FieldOffset(Offset = "0x20")]
		public bool bool_0;

		// Token: 0x0400097F RID: 2431
		[Token(Token = "0x400097F")]
		[FieldOffset(Offset = "0x24")]
		public Vector2 vector2_0;

		// Token: 0x04000980 RID: 2432
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000980")]
		public float float_0;

		// Token: 0x04000981 RID: 2433
		[Token(Token = "0x4000981")]
		[FieldOffset(Offset = "0x30")]
		public float float_1;

		// Token: 0x04000982 RID: 2434
		[Token(Token = "0x4000982")]
		[FieldOffset(Offset = "0x34")]
		public float float_2;

		// Token: 0x04000983 RID: 2435
		[Token(Token = "0x4000983")]
		[FieldOffset(Offset = "0x38")]
		public float float_3;

		// Token: 0x04000984 RID: 2436
		[FieldOffset(Offset = "0x3C")]
		[Token(Token = "0x4000984")]
		public float float_4;

		// Token: 0x04000985 RID: 2437
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000985")]
		public float float_5;

		// Token: 0x04000986 RID: 2438
		[FieldOffset(Offset = "0x44")]
		[Token(Token = "0x4000986")]
		public Vector3 vector3_0;

		// Token: 0x04000987 RID: 2439
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000987")]
		public Vector3 vector3_1;

		// Token: 0x04000988 RID: 2440
		[Token(Token = "0x4000988")]
		[FieldOffset(Offset = "0x5C")]
		public PlayerInputState playerInputState_0;

		// Token: 0x04000989 RID: 2441
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x4000989")]
		public PlayerInputState playerInputState_1;

		// Token: 0x0400098A RID: 2442
		[FieldOffset(Offset = "0x6C")]
		[Token(Token = "0x400098A")]
		public PlayerInputState playerInputState_2;

		// Token: 0x0400098B RID: 2443
		[FieldOffset(Offset = "0x74")]
		[Token(Token = "0x400098B")]
		public PlayerInputState playerInputState_3;

		// Token: 0x0400098C RID: 2444
		[FieldOffset(Offset = "0x7C")]
		[Token(Token = "0x400098C")]
		public PlayerInputState playerInputState_4;

		// Token: 0x0400098D RID: 2445
		[FieldOffset(Offset = "0x84")]
		[Token(Token = "0x400098D")]
		public PlayerInputState playerInputState_5;

		// Token: 0x0400098E RID: 2446
		[FieldOffset(Offset = "0x8C")]
		[Token(Token = "0x400098E")]
		public PlayerInputState playerInputState_6;

		// Token: 0x0400098F RID: 2447
		[FieldOffset(Offset = "0x94")]
		[Token(Token = "0x400098F")]
		public PlayerInputState playerInputState_7;

		// Token: 0x04000990 RID: 2448
		[FieldOffset(Offset = "0x9C")]
		[Token(Token = "0x4000990")]
		public PlayerInputState playerInputState_8;

		// Token: 0x04000991 RID: 2449
		[Token(Token = "0x4000991")]
		[FieldOffset(Offset = "0xA4")]
		public PlayerInputState playerInputState_9;

		// Token: 0x04000992 RID: 2450
		[FieldOffset(Offset = "0xAC")]
		[Token(Token = "0x4000992")]
		public PlayerInputState playerInputState_10;

		// Token: 0x04000993 RID: 2451
		[FieldOffset(Offset = "0xB4")]
		[Token(Token = "0x4000993")]
		public Vector2 vector2_1;

		// Token: 0x04000994 RID: 2452
		[Token(Token = "0x4000994")]
		[FieldOffset(Offset = "0xBC")]
		public Vector2 vector2_2;

		// Token: 0x04000995 RID: 2453
		[Token(Token = "0x4000995")]
		[FieldOffset(Offset = "0xC4")]
		public bool bool_1;

		// Token: 0x04000996 RID: 2454
		[FieldOffset(Offset = "0xC5")]
		[Token(Token = "0x4000996")]
		public bool bool_2;

		// Token: 0x04000997 RID: 2455
		[Token(Token = "0x4000997")]
		[FieldOffset(Offset = "0xC6")]
		public bool bool_3;

		// Token: 0x04000998 RID: 2456
		[FieldOffset(Offset = "0xC7")]
		[Token(Token = "0x4000998")]
		public bool bool_4;

		// Token: 0x04000999 RID: 2457
		[Token(Token = "0x4000999")]
		[FieldOffset(Offset = "0xC8")]
		public bool bool_5;

		// Token: 0x0400099A RID: 2458
		[Token(Token = "0x400099A")]
		[FieldOffset(Offset = "0xCC")]
		public float float_6;

		// Token: 0x0400099B RID: 2459
		[Token(Token = "0x400099B")]
		[FieldOffset(Offset = "0xD0")]
		public bool bool_6;

		// Token: 0x0400099C RID: 2460
		[FieldOffset(Offset = "0xD4")]
		[Token(Token = "0x400099C")]
		public float float_7;

		// Token: 0x0400099D RID: 2461
		[FieldOffset(Offset = "0xD8")]
		[Token(Token = "0x400099D")]
		public Vector3 vector3_2;

		// Token: 0x0400099E RID: 2462
		[Token(Token = "0x400099E")]
		[FieldOffset(Offset = "0xE4")]
		public Vector3 vector3_3;

		// Token: 0x0400099F RID: 2463
		[Token(Token = "0x400099F")]
		[FieldOffset(Offset = "0xF0")]
		[CompilerGenerated]
		private bool bool_7;

		// Token: 0x040009A0 RID: 2464
		[Token(Token = "0x40009A0")]
		[FieldOffset(Offset = "0xF4")]
		public XRNode xrnode_0;

		// Token: 0x040009A1 RID: 2465
		[Token(Token = "0x40009A1")]
		[FieldOffset(Offset = "0xF8")]
		public bool bool_8;

		// Token: 0x040009A2 RID: 2466
		[Token(Token = "0x40009A2")]
		[FieldOffset(Offset = "0xF9")]
		public bool bool_9;

		// Token: 0x040009A3 RID: 2467
		[Token(Token = "0x40009A3")]
		[FieldOffset(Offset = "0xFA")]
		public bool bool_10;

		// Token: 0x040009A4 RID: 2468
		[Token(Token = "0x40009A4")]
		[FieldOffset(Offset = "0xFB")]
		public bool bool_11;

		// Token: 0x040009A5 RID: 2469
		[Token(Token = "0x40009A5")]
		[FieldOffset(Offset = "0xFC")]
		public bool bool_12;

		// Token: 0x040009A6 RID: 2470
		[FieldOffset(Offset = "0xFD")]
		[Token(Token = "0x40009A6")]
		public bool bool_13;

		// Token: 0x040009A7 RID: 2471
		[Token(Token = "0x40009A7")]
		[FieldOffset(Offset = "0xFE")]
		public bool bool_14;

		// Token: 0x040009A8 RID: 2472
		[Token(Token = "0x40009A8")]
		[FieldOffset(Offset = "0xFF")]
		public bool bool_15;

		// Token: 0x040009A9 RID: 2473
		[FieldOffset(Offset = "0x100")]
		[Token(Token = "0x40009A9")]
		private InputDevice inputDevice_0;

		// Token: 0x040009AA RID: 2474
		[Token(Token = "0x40009AA")]
		private static bool bool_16;

		// Token: 0x040009AB RID: 2475
		[Token(Token = "0x40009AB")]
		[FieldOffset(Offset = "0x110")]
		protected InputFeatureUsage<Vector2> inputFeatureUsage_0;

		// Token: 0x040009AC RID: 2476
		[Token(Token = "0x40009AC")]
		[FieldOffset(Offset = "0x118")]
		protected InputFeatureUsage<Vector2> inputFeatureUsage_1;

		// Token: 0x040009AD RID: 2477
		[Token(Token = "0x40009AD")]
		[FieldOffset(Offset = "0x120")]
		public GEnum24 genum24_0;

		// Token: 0x040009AE RID: 2478
		[FieldOffset(Offset = "0x124")]
		[Token(Token = "0x40009AE")]
		public GEnum24 genum24_1;

		// Token: 0x040009AF RID: 2479
		[Token(Token = "0x40009AF")]
		private static HexaXRInputs.Struct1[] struct1_0;

		// Token: 0x0200016A RID: 362
		[Token(Token = "0x200016A")]
		private enum Enum0
		{
			// Token: 0x040009B1 RID: 2481
			[Token(Token = "0x40009B1")]
			const_0,
			// Token: 0x040009B2 RID: 2482
			[Token(Token = "0x40009B2")]
			const_1,
			// Token: 0x040009B3 RID: 2483
			[Token(Token = "0x40009B3")]
			const_2,
			// Token: 0x040009B4 RID: 2484
			[Token(Token = "0x40009B4")]
			const_3,
			// Token: 0x040009B5 RID: 2485
			[Token(Token = "0x40009B5")]
			const_4,
			// Token: 0x040009B6 RID: 2486
			[Token(Token = "0x40009B6")]
			const_5,
			// Token: 0x040009B7 RID: 2487
			[Token(Token = "0x40009B7")]
			const_6
		}

		// Token: 0x0200016B RID: 363
		[Token(Token = "0x200016B")]
		private struct Struct1
		{
			// Token: 0x060038B1 RID: 14513 RVA: 0x00003601 File Offset: 0x00001801
			[Address(RVA = "0x1073D80", Offset = "0x1073D80", VA = "0x1073D80")]
			[Token(Token = "0x60038B1")]
			public Struct1(string string_1, HexaXRInputs.Enum0 enum0_1)
			{
				this.string_0 = string_1;
				this.enum0_0 = enum0_1;
			}

			// Token: 0x040009B8 RID: 2488
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x40009B8")]
			public string string_0;

			// Token: 0x040009B9 RID: 2489
			[FieldOffset(Offset = "0x8")]
			[Token(Token = "0x40009B9")]
			public HexaXRInputs.Enum0 enum0_0;
		}
	}
}
