﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.SampleScene
{
	// Token: 0x0200013A RID: 314
	[Token(Token = "0x200013A")]
	public class MovingPlatform : MonoBehaviour
	{
		// Token: 0x06003196 RID: 12694 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E69D88", Offset = "0x2E69D88", VA = "0x2E69D88")]
		[Token(Token = "0x6003196")]
		public Rigidbody method_0()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003197 RID: 12695 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x6003197")]
		[Address(RVA = "0x2E69D90", Offset = "0x2E69D90", VA = "0x2E69D90")]
		public void method_1(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003198 RID: 12696 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x6003198")]
		[Address(RVA = "0x2E69D98", Offset = "0x2E69D98", VA = "0x2E69D98")]
		public void method_2(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003199 RID: 12697 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E69DA0", Offset = "0x2E69DA0", VA = "0x2E69DA0")]
		[Token(Token = "0x6003199")]
		public Rigidbody method_3()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600319A RID: 12698 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E69DA8", Offset = "0x2E69DA8", VA = "0x2E69DA8")]
		[Token(Token = "0x600319A")]
		public void method_4(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x0600319B RID: 12699 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x600319B")]
		[Address(RVA = "0x2E69DB0", Offset = "0x2E69DB0", VA = "0x2E69DB0")]
		public void method_5(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x0600319C RID: 12700 RVA: 0x00061F4C File Offset: 0x0006014C
		[Token(Token = "0x600319C")]
		[Address(RVA = "0x2E69DB8", Offset = "0x2E69DB8", VA = "0x2E69DB8")]
		private void method_6()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)32768;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				this.float_4 = (float)16816;
				this.float_5 = (float)17527;
			}
		}

		// Token: 0x0600319D RID: 12701 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E69F84", Offset = "0x2E69F84", VA = "0x2E69F84")]
		[Token(Token = "0x600319D")]
		private void method_7()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600319E RID: 12702 RVA: 0x00062068 File Offset: 0x00060268
		[Address(RVA = "0x2E6A024", Offset = "0x2E6A024", VA = "0x2E6A024")]
		[Token(Token = "0x600319E")]
		private void method_8()
		{
			if (this.bool_0)
			{
				return;
			}
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
		}

		// Token: 0x0600319F RID: 12703 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x600319F")]
		[Address(RVA = "0x2E6A1F8", Offset = "0x2E6A1F8", VA = "0x2E6A1F8")]
		public void method_9(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031A0 RID: 12704 RVA: 0x0006208C File Offset: 0x0006028C
		[Token(Token = "0x60031A0")]
		[Address(RVA = "0x2E6A200", Offset = "0x2E6A200", VA = "0x2E6A200")]
		private void method_10()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)17453;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)16384;
				this.float_5 = (float)40960;
			}
		}

		// Token: 0x060031A1 RID: 12705 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031A1")]
		[Address(RVA = "0x2E6A3D8", Offset = "0x2E6A3D8", VA = "0x2E6A3D8")]
		public Rigidbody method_11()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031A2 RID: 12706 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031A2")]
		[Address(RVA = "0x2E6A3E0", Offset = "0x2E6A3E0", VA = "0x2E6A3E0")]
		public Rigidbody method_12()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031A3 RID: 12707 RVA: 0x00062178 File Offset: 0x00060378
		[Address(RVA = "0x2E6A3E8", Offset = "0x2E6A3E8", VA = "0x2E6A3E8")]
		[Token(Token = "0x60031A3")]
		private void method_13()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031A4 RID: 12708 RVA: 0x000621B4 File Offset: 0x000603B4
		[Address(RVA = "0x2E6A48C", Offset = "0x2E6A48C", VA = "0x2E6A48C")]
		[Token(Token = "0x60031A4")]
		private void method_14()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)16384;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				this.float_4 = (float)16384;
				this.float_5 = (float)17080;
			}
		}

		// Token: 0x060031A5 RID: 12709 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031A5")]
		[Address(RVA = "0x2E6A668", Offset = "0x2E6A668", VA = "0x2E6A668")]
		public void method_15(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031A6 RID: 12710 RVA: 0x000622AC File Offset: 0x000604AC
		[Token(Token = "0x60031A6")]
		[Address(RVA = "0x2E6A670", Offset = "0x2E6A670", VA = "0x2E6A670")]
		private void method_16()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)16384;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num2 = 1L;
				this.bool_0 = (num2 != 0L);
				this.float_4 = (float)24576;
				this.float_5 = (float)17062;
			}
		}

		// Token: 0x060031A7 RID: 12711 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031A7")]
		[Address(RVA = "0x2E6A844", Offset = "0x2E6A844", VA = "0x2E6A844")]
		private void method_17()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031A8 RID: 12712 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6A8E4", Offset = "0x2E6A8E4", VA = "0x2E6A8E4")]
		[Token(Token = "0x60031A8")]
		public Rigidbody method_18()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031A9 RID: 12713 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6A8EC", Offset = "0x2E6A8EC", VA = "0x2E6A8EC")]
		[Token(Token = "0x60031A9")]
		public Rigidbody method_19()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031AA RID: 12714 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6A8F4", Offset = "0x2E6A8F4", VA = "0x2E6A8F4")]
		[Token(Token = "0x60031AA")]
		public Rigidbody method_20()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031AB RID: 12715 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x60031AB")]
		[Address(RVA = "0x2E6A8FC", Offset = "0x2E6A8FC", VA = "0x2E6A8FC")]
		private void method_21()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031AC RID: 12716 RVA: 0x00062178 File Offset: 0x00060378
		[Address(RVA = "0x2E6A9A0", Offset = "0x2E6A9A0", VA = "0x2E6A9A0")]
		[Token(Token = "0x60031AC")]
		private void method_22()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031AD RID: 12717 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031AD")]
		[Address(RVA = "0x2E6AA44", Offset = "0x2E6AA44", VA = "0x2E6AA44")]
		public void method_23(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031AE RID: 12718 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031AE")]
		[Address(RVA = "0x2E6AA4C", Offset = "0x2E6AA4C", VA = "0x2E6AA4C")]
		private void method_24()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060031AF RID: 12719 RVA: 0x00003125 File Offset: 0x00001325
		// (set) Token: 0x060031D8 RID: 12760 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x17000087")]
		public Rigidbody Rigidbody_0 { [Address(RVA = "0x2E6AAEC", Offset = "0x2E6AAEC", VA = "0x2E6AAEC")] [Token(Token = "0x60031AF")] get; [Token(Token = "0x60031D8")] [Address(RVA = "0x2E6C000", Offset = "0x2E6C000", VA = "0x2E6C000")] set; }

		// Token: 0x060031B0 RID: 12720 RVA: 0x000623A0 File Offset: 0x000605A0
		[Token(Token = "0x60031B0")]
		[Address(RVA = "0x2E6AAF4", Offset = "0x2E6AAF4", VA = "0x2E6AAF4")]
		private void method_25()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)16384;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				this.float_4 = (float)16384;
				this.float_5 = (float)49152;
			}
		}

		// Token: 0x060031B1 RID: 12721 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6ACC8", Offset = "0x2E6ACC8", VA = "0x2E6ACC8")]
		[Token(Token = "0x60031B1")]
		public Rigidbody method_26()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031B2 RID: 12722 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031B2")]
		[Address(RVA = "0x2E6ACD0", Offset = "0x2E6ACD0", VA = "0x2E6ACD0")]
		public void method_27(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031B3 RID: 12723 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031B3")]
		[Address(RVA = "0x2E6ACD8", Offset = "0x2E6ACD8", VA = "0x2E6ACD8")]
		public void method_28(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031B4 RID: 12724 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031B4")]
		[Address(RVA = "0x2E6ACE0", Offset = "0x2E6ACE0", VA = "0x2E6ACE0")]
		public Rigidbody method_29()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031B5 RID: 12725 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6ACE8", Offset = "0x2E6ACE8", VA = "0x2E6ACE8")]
		[Token(Token = "0x60031B5")]
		public void method_30(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031B6 RID: 12726 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E6ACF0", Offset = "0x2E6ACF0", VA = "0x2E6ACF0")]
		[Token(Token = "0x60031B6")]
		private void method_31()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031B7 RID: 12727 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x60031B7")]
		[Address(RVA = "0x2E6AD90", Offset = "0x2E6AD90", VA = "0x2E6AD90")]
		private void method_32()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031B8 RID: 12728 RVA: 0x00062178 File Offset: 0x00060378
		[Address(RVA = "0x2E6AE34", Offset = "0x2E6AE34", VA = "0x2E6AE34")]
		[Token(Token = "0x60031B8")]
		private void method_33()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031B9 RID: 12729 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E6AED8", Offset = "0x2E6AED8", VA = "0x2E6AED8")]
		[Token(Token = "0x60031B9")]
		private void method_34()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031BA RID: 12730 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x60031BA")]
		[Address(RVA = "0x2E6AF78", Offset = "0x2E6AF78", VA = "0x2E6AF78")]
		private void method_35()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060031BB RID: 12731 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6B01C", Offset = "0x2E6B01C", VA = "0x2E6B01C")]
		[Token(Token = "0x60031BB")]
		public Rigidbody method_36()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031BC RID: 12732 RVA: 0x00062488 File Offset: 0x00060688
		[Token(Token = "0x60031BC")]
		[Address(RVA = "0x2E6B024", Offset = "0x2E6B024", VA = "0x2E6B024")]
		private void method_37()
		{
			if (this.bool_0)
			{
				return;
			}
			float num = this.float_5;
			Rigidbody rigidbody = this.rigidbody_0;
			this.float_0 = num;
			Vector3 position = rigidbody.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)32768;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num2 = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num2 != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)57344;
				this.float_5 = (float)57344;
			}
		}

		// Token: 0x060031BD RID: 12733 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031BD")]
		[Address(RVA = "0x2E6B204", Offset = "0x2E6B204", VA = "0x2E6B204")]
		public Rigidbody method_38()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031BE RID: 12734 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031BE")]
		[Address(RVA = "0x2E6B20C", Offset = "0x2E6B20C", VA = "0x2E6B20C")]
		public void method_39(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031BF RID: 12735 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031BF")]
		[Address(RVA = "0x2E6B214", Offset = "0x2E6B214", VA = "0x2E6B214")]
		public Rigidbody method_40()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031C0 RID: 12736 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031C0")]
		[Address(RVA = "0x2E6B21C", Offset = "0x2E6B21C", VA = "0x2E6B21C")]
		private void method_41()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031C1 RID: 12737 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6B2BC", Offset = "0x2E6B2BC", VA = "0x2E6B2BC")]
		[Token(Token = "0x60031C1")]
		public Rigidbody method_42()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031C2 RID: 12738 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031C2")]
		[Address(RVA = "0x2E6B2C4", Offset = "0x2E6B2C4", VA = "0x2E6B2C4")]
		public void method_43(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031C3 RID: 12739 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031C3")]
		[Address(RVA = "0x2E6B2CC", Offset = "0x2E6B2CC", VA = "0x2E6B2CC")]
		public Rigidbody method_44()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031C4 RID: 12740 RVA: 0x00062594 File Offset: 0x00060794
		[Token(Token = "0x60031C4")]
		[Address(RVA = "0x2E6B2D4", Offset = "0x2E6B2D4", VA = "0x2E6B2D4")]
		private void method_45()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Transform transform;
			Vector3 position2 = transform.position;
		}

		// Token: 0x060031C5 RID: 12741 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6B374", Offset = "0x2E6B374", VA = "0x2E6B374")]
		[Token(Token = "0x60031C5")]
		public void method_46(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031C6 RID: 12742 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031C6")]
		[Address(RVA = "0x2E6B37C", Offset = "0x2E6B37C", VA = "0x2E6B37C")]
		private void method_47()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031C7 RID: 12743 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x60031C7")]
		[Address(RVA = "0x2E6B41C", Offset = "0x2E6B41C", VA = "0x2E6B41C")]
		private void method_48()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031C8 RID: 12744 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E6B4C0", Offset = "0x2E6B4C0", VA = "0x2E6B4C0")]
		[Token(Token = "0x60031C8")]
		private void method_49()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031C9 RID: 12745 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031C9")]
		[Address(RVA = "0x2E6B560", Offset = "0x2E6B560", VA = "0x2E6B560")]
		private void method_50()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031CA RID: 12746 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031CA")]
		[Address(RVA = "0x2E6B600", Offset = "0x2E6B600", VA = "0x2E6B600")]
		public Rigidbody method_51()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031CB RID: 12747 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6B608", Offset = "0x2E6B608", VA = "0x2E6B608")]
		[Token(Token = "0x60031CB")]
		public Rigidbody method_52()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031CC RID: 12748 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031CC")]
		[Address(RVA = "0x2E6B610", Offset = "0x2E6B610", VA = "0x2E6B610")]
		public void method_53(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031CD RID: 12749 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6B618", Offset = "0x2E6B618", VA = "0x2E6B618")]
		[Token(Token = "0x60031CD")]
		public void method_54(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031CE RID: 12750 RVA: 0x000625C4 File Offset: 0x000607C4
		[Token(Token = "0x60031CE")]
		[Address(RVA = "0x2E6B620", Offset = "0x2E6B620", VA = "0x2E6B620")]
		private void method_55()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)16384;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)17613;
				this.float_5 = (float)17203;
			}
		}

		// Token: 0x060031CF RID: 12751 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031CF")]
		[Address(RVA = "0x2E6B7E8", Offset = "0x2E6B7E8", VA = "0x2E6B7E8")]
		public Rigidbody method_56()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031D0 RID: 12752 RVA: 0x000626A0 File Offset: 0x000608A0
		[Token(Token = "0x60031D0")]
		[Address(RVA = "0x2E6B7F0", Offset = "0x2E6B7F0", VA = "0x2E6B7F0")]
		private void method_57()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)32768;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)32768;
				this.float_5 = (float)16384;
			}
		}

		// Token: 0x060031D1 RID: 12753 RVA: 0x00062798 File Offset: 0x00060998
		[Address(RVA = "0x2E6B9D0", Offset = "0x2E6B9D0", VA = "0x2E6B9D0")]
		[Token(Token = "0x60031D1")]
		private void method_58()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)32768;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num = 1L;
				this.bool_0 = (num != 0L);
				this.float_5 = (float)32768;
			}
		}

		// Token: 0x060031D2 RID: 12754 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031D2")]
		[Address(RVA = "0x2E6BBB0", Offset = "0x2E6BBB0", VA = "0x2E6BBB0")]
		private void method_59()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031D3 RID: 12755 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031D3")]
		[Address(RVA = "0x2E6BC50", Offset = "0x2E6BC50", VA = "0x2E6BC50")]
		public void method_60(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031D4 RID: 12756 RVA: 0x00062874 File Offset: 0x00060A74
		[Token(Token = "0x60031D4")]
		[Address(RVA = "0x2E6BC58", Offset = "0x2E6BC58", VA = "0x2E6BC58")]
		private void method_61()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)49152;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)24576;
				this.float_5 = (float)17372;
			}
		}

		// Token: 0x060031D5 RID: 12757 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6BE28", Offset = "0x2E6BE28", VA = "0x2E6BE28")]
		[Token(Token = "0x60031D5")]
		public Rigidbody method_62()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031D6 RID: 12758 RVA: 0x0006295C File Offset: 0x00060B5C
		[Token(Token = "0x60031D6")]
		[Address(RVA = "0x2E6BE30", Offset = "0x2E6BE30", VA = "0x2E6BE30")]
		private void FixedUpdate()
		{
			if (this.bool_0)
			{
				return;
			}
			float num = this.float_5;
			Rigidbody rigidbody = this.rigidbody_0;
			this.float_0 = num;
			Vector3 position = rigidbody.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float x;
			float y;
			float z;
			if (this.bool_1)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag = this.bool_1;
			long num2 = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num2 != 0L);
			this.bool_1 = flag;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (!this.bool_0)
			{
			}
		}

		// Token: 0x060031D7 RID: 12759 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6BFF8", Offset = "0x2E6BFF8", VA = "0x2E6BFF8")]
		[Token(Token = "0x60031D7")]
		public Rigidbody method_63()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031D9 RID: 12761 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6C008", Offset = "0x2E6C008", VA = "0x2E6C008")]
		[Token(Token = "0x60031D9")]
		public Rigidbody method_64()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031DA RID: 12762 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031DA")]
		[Address(RVA = "0x2E6C010", Offset = "0x2E6C010", VA = "0x2E6C010")]
		private void method_65()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031DB RID: 12763 RVA: 0x00062A40 File Offset: 0x00060C40
		[Address(RVA = "0x2E6C0B0", Offset = "0x2E6C0B0", VA = "0x2E6C0B0")]
		[Token(Token = "0x60031DB")]
		private void method_66()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)24576;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)49152;
				this.float_5 = (float)24576;
			}
		}

		// Token: 0x060031DC RID: 12764 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031DC")]
		[Address(RVA = "0x2E6C290", Offset = "0x2E6C290", VA = "0x2E6C290")]
		public Rigidbody method_67()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031DD RID: 12765 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x60031DD")]
		[Address(RVA = "0x2E6C298", Offset = "0x2E6C298", VA = "0x2E6C298")]
		private void method_68()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031DE RID: 12766 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6C33C", Offset = "0x2E6C33C", VA = "0x2E6C33C")]
		[Token(Token = "0x60031DE")]
		public void method_69(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031DF RID: 12767 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031DF")]
		[Address(RVA = "0x2E6C344", Offset = "0x2E6C344", VA = "0x2E6C344")]
		private void method_70()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031E0 RID: 12768 RVA: 0x00062B38 File Offset: 0x00060D38
		[Address(RVA = "0x2E6C3E4", Offset = "0x2E6C3E4", VA = "0x2E6C3E4")]
		[Token(Token = "0x60031E0")]
		private void method_71()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)32768;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num2 = 1L;
				this.bool_0 = (num2 != 0L);
				this.float_4 = (float)49152;
				this.float_5 = (float)17444;
			}
		}

		// Token: 0x060031E1 RID: 12769 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031E1")]
		[Address(RVA = "0x2E6C5C4", Offset = "0x2E6C5C4", VA = "0x2E6C5C4")]
		public void method_72(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031E2 RID: 12770 RVA: 0x00062C3C File Offset: 0x00060E3C
		[Address(RVA = "0x2E6C5CC", Offset = "0x2E6C5CC", VA = "0x2E6C5CC")]
		[Token(Token = "0x60031E2")]
		private void method_73()
		{
		}

		// Token: 0x060031E3 RID: 12771 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031E3")]
		[Address(RVA = "0x2E6C798", Offset = "0x2E6C798", VA = "0x2E6C798")]
		public Rigidbody method_74()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031E4 RID: 12772 RVA: 0x00062C4C File Offset: 0x00060E4C
		[Token(Token = "0x60031E4")]
		[Address(RVA = "0x2E6C7A0", Offset = "0x2E6C7A0", VA = "0x2E6C7A0")]
		private void method_75()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)24576;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)49152;
				this.float_5 = (float)8192;
			}
		}

		// Token: 0x060031E5 RID: 12773 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6C980", Offset = "0x2E6C980", VA = "0x2E6C980")]
		[Token(Token = "0x60031E5")]
		public void method_76(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031E6 RID: 12774 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031E6")]
		[Address(RVA = "0x2E6C988", Offset = "0x2E6C988", VA = "0x2E6C988")]
		private void method_77()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031E7 RID: 12775 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x60031E7")]
		[Address(RVA = "0x2E6CA28", Offset = "0x2E6CA28", VA = "0x2E6CA28")]
		private void method_78()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031E8 RID: 12776 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E6CACC", Offset = "0x2E6CACC", VA = "0x2E6CACC")]
		[Token(Token = "0x60031E8")]
		private void method_79()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031E9 RID: 12777 RVA: 0x00062D44 File Offset: 0x00060F44
		[Token(Token = "0x60031E9")]
		[Address(RVA = "0x2E6CB6C", Offset = "0x2E6CB6C", VA = "0x2E6CB6C")]
		private void method_80()
		{
		}

		// Token: 0x060031EA RID: 12778 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031EA")]
		[Address(RVA = "0x2E6CD40", Offset = "0x2E6CD40", VA = "0x2E6CD40")]
		public void method_81(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031EB RID: 12779 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E6CD48", Offset = "0x2E6CD48", VA = "0x2E6CD48")]
		[Token(Token = "0x60031EB")]
		private void method_82()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031EC RID: 12780 RVA: 0x00062D54 File Offset: 0x00060F54
		[Token(Token = "0x60031EC")]
		[Address(RVA = "0x2E6CDE8", Offset = "0x2E6CDE8", VA = "0x2E6CDE8")]
		private void method_83()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)8192;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num2 = 1L;
				this.bool_0 = (num2 != 0L);
				this.float_4 = (float)17112;
				this.float_5 = (float)49152;
			}
		}

		// Token: 0x060031ED RID: 12781 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031ED")]
		[Address(RVA = "0x2E6CFC4", Offset = "0x2E6CFC4", VA = "0x2E6CFC4")]
		public Rigidbody method_84()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031EE RID: 12782 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2E6CFCC", Offset = "0x2E6CFCC", VA = "0x2E6CFCC")]
		[Token(Token = "0x60031EE")]
		private void method_85()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x060031EF RID: 12783 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031EF")]
		[Address(RVA = "0x2E6D070", Offset = "0x2E6D070", VA = "0x2E6D070")]
		private void method_86()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031F0 RID: 12784 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031F0")]
		[Address(RVA = "0x2E6D110", Offset = "0x2E6D110", VA = "0x2E6D110")]
		public void method_87(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031F1 RID: 12785 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6D118", Offset = "0x2E6D118", VA = "0x2E6D118")]
		[Token(Token = "0x60031F1")]
		public Rigidbody method_88()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031F2 RID: 12786 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x60031F2")]
		[Address(RVA = "0x2E6D120", Offset = "0x2E6D120", VA = "0x2E6D120")]
		private void Start()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031F3 RID: 12787 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031F3")]
		[Address(RVA = "0x2E6D1C4", Offset = "0x2E6D1C4", VA = "0x2E6D1C4")]
		public Rigidbody method_89()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031F4 RID: 12788 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6D1CC", Offset = "0x2E6D1CC", VA = "0x2E6D1CC")]
		[Token(Token = "0x60031F4")]
		public void method_90(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031F5 RID: 12789 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x60031F5")]
		[Address(RVA = "0x2E6D1D4", Offset = "0x2E6D1D4", VA = "0x2E6D1D4")]
		private void method_91()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031F6 RID: 12790 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031F6")]
		[Address(RVA = "0x2E6D274", Offset = "0x2E6D274", VA = "0x2E6D274")]
		public void method_92(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031F7 RID: 12791 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6D27C", Offset = "0x2E6D27C", VA = "0x2E6D27C")]
		[Token(Token = "0x60031F7")]
		public Rigidbody method_93()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031F8 RID: 12792 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031F8")]
		[Address(RVA = "0x2E6D284", Offset = "0x2E6D284", VA = "0x2E6D284")]
		public void method_94(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031F9 RID: 12793 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031F9")]
		[Address(RVA = "0x2E6D28C", Offset = "0x2E6D28C", VA = "0x2E6D28C")]
		public void method_95(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031FA RID: 12794 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E6D294", Offset = "0x2E6D294", VA = "0x2E6D294")]
		[Token(Token = "0x60031FA")]
		private void method_96()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060031FB RID: 12795 RVA: 0x00062E58 File Offset: 0x00061058
		[Address(RVA = "0x2E6D334", Offset = "0x2E6D334", VA = "0x2E6D334")]
		[Token(Token = "0x60031FB")]
		private void method_97()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)8192;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)17640;
				this.float_5 = (float)49152;
			}
		}

		// Token: 0x060031FC RID: 12796 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x60031FC")]
		[Address(RVA = "0x2E6D50C", Offset = "0x2E6D50C", VA = "0x2E6D50C")]
		public void method_98(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x060031FD RID: 12797 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x60031FD")]
		[Address(RVA = "0x2E6D514", Offset = "0x2E6D514", VA = "0x2E6D514")]
		private void method_99()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x060031FE RID: 12798 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x60031FE")]
		[Address(RVA = "0x2E6D5B8", Offset = "0x2E6D5B8", VA = "0x2E6D5B8")]
		public Rigidbody method_100()
		{
			return this.rigidbody_0;
		}

		// Token: 0x060031FF RID: 12799 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6D5C0", Offset = "0x2E6D5C0", VA = "0x2E6D5C0")]
		[Token(Token = "0x60031FF")]
		public void method_101(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003200 RID: 12800 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x6003200")]
		[Address(RVA = "0x2E6D5C8", Offset = "0x2E6D5C8", VA = "0x2E6D5C8")]
		public void method_102(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003201 RID: 12801 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6D5D0", Offset = "0x2E6D5D0", VA = "0x2E6D5D0")]
		[Token(Token = "0x6003201")]
		public void method_103(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003202 RID: 12802 RVA: 0x00062F44 File Offset: 0x00061144
		[Token(Token = "0x6003202")]
		[Address(RVA = "0x2E6D5D8", Offset = "0x2E6D5D8", VA = "0x2E6D5D8")]
		private void method_104()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)57344;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num2 = 1L;
				this.bool_0 = (num2 != 0L);
				this.float_4 = (float)32768;
				this.float_5 = (float)8192;
			}
		}

		// Token: 0x06003203 RID: 12803 RVA: 0x00063038 File Offset: 0x00061238
		[Token(Token = "0x6003203")]
		[Address(RVA = "0x2E6D7B0", Offset = "0x2E6D7B0", VA = "0x2E6D7B0")]
		private void method_105()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)16384;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num2 = 1L;
				this.bool_0 = (num2 != 0L);
				this.float_4 = (float)17560;
				this.float_5 = (float)49152;
			}
		}

		// Token: 0x06003204 RID: 12804 RVA: 0x0006313C File Offset: 0x0006133C
		[Address(RVA = "0x2E6D990", Offset = "0x2E6D990", VA = "0x2E6D990")]
		[Token(Token = "0x6003204")]
		private void method_106()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)32768;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			bool flag2 = this.bool_1;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				this.float_4 = (float)17234;
				this.float_5 = (float)40960;
			}
		}

		// Token: 0x06003205 RID: 12805 RVA: 0x00063228 File Offset: 0x00061428
		[Token(Token = "0x6003205")]
		[Address(RVA = "0x2E6DB68", Offset = "0x2E6DB68", VA = "0x2E6DB68")]
		private void method_107()
		{
			if (this.bool_0)
			{
				return;
			}
			float num = this.float_5;
			Rigidbody rigidbody = this.rigidbody_0;
			this.float_0 = num;
			Vector3 position = rigidbody.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)49152;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position2 = this.transform_0.position;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			bool flag2;
			if (flag2 = this.bool_0)
			{
				this.float_4 = flag2;
				this.float_5 = (float)57344;
			}
		}

		// Token: 0x06003206 RID: 12806 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x6003206")]
		[Address(RVA = "0x2E6DD34", Offset = "0x2E6DD34", VA = "0x2E6DD34")]
		private void method_108()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x06003207 RID: 12807 RVA: 0x00062034 File Offset: 0x00060234
		[Address(RVA = "0x2E6DDD4", Offset = "0x2E6DDD4", VA = "0x2E6DDD4")]
		[Token(Token = "0x6003207")]
		private void method_109()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x06003208 RID: 12808 RVA: 0x00063314 File Offset: 0x00061514
		[Token(Token = "0x6003208")]
		[Address(RVA = "0x2E6DE74", Offset = "0x2E6DE74", VA = "0x2E6DE74")]
		public MovingPlatform()
		{
			long num = 1065353216L;
			this.float_2 = (float)num;
			base..ctor();
		}

		// Token: 0x06003209 RID: 12809 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x6003209")]
		[Address(RVA = "0x2E6DE90", Offset = "0x2E6DE90", VA = "0x2E6DE90")]
		public void method_110(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x0600320A RID: 12810 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6DE98", Offset = "0x2E6DE98", VA = "0x2E6DE98")]
		[Token(Token = "0x600320A")]
		public void method_111(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x0600320B RID: 12811 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x600320B")]
		[Address(RVA = "0x2E6DEA0", Offset = "0x2E6DEA0", VA = "0x2E6DEA0")]
		public Rigidbody method_112()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600320C RID: 12812 RVA: 0x00063334 File Offset: 0x00061534
		[Address(RVA = "0x2E6DEA8", Offset = "0x2E6DEA8", VA = "0x2E6DEA8")]
		[Token(Token = "0x600320C")]
		private void method_113()
		{
			if (this.bool_0)
			{
				return;
			}
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			bool flag = this.bool_1;
			this.float_3 = (float)49152;
			float x;
			float y;
			float z;
			if (flag)
			{
				x = this.vector3_1.x;
				y = this.vector3_1.y;
				z = this.vector3_1.z;
				return;
			}
			Vector3 position = this.transform_0.position;
			bool flag2 = this.bool_1;
			long num = 1L;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
			this.vector3_0.z = z;
			this.bool_0 = (num != 0L);
			this.bool_1 = flag2;
			float deltaTime2 = Time.deltaTime;
			this.float_4 = x;
			float deltaTime3 = Time.deltaTime;
			this.float_5 = x;
			if (this.bool_0)
			{
				long num2 = 1L;
				this.bool_0 = (num2 != 0L);
				this.float_4 = (float)17475;
				this.float_5 = (float)24576;
			}
		}

		// Token: 0x0600320D RID: 12813 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x600320D")]
		[Address(RVA = "0x2E6E088", Offset = "0x2E6E088", VA = "0x2E6E088")]
		public Rigidbody method_114()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600320E RID: 12814 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6E090", Offset = "0x2E6E090", VA = "0x2E6E090")]
		[Token(Token = "0x600320E")]
		public Rigidbody method_115()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600320F RID: 12815 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6E098", Offset = "0x2E6E098", VA = "0x2E6E098")]
		[Token(Token = "0x600320F")]
		public Rigidbody method_116()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003210 RID: 12816 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x6003210")]
		[Address(RVA = "0x2E6E0A0", Offset = "0x2E6E0A0", VA = "0x2E6E0A0")]
		public Rigidbody method_117()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003211 RID: 12817 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x6003211")]
		[Address(RVA = "0x2E6E0A8", Offset = "0x2E6E0A8", VA = "0x2E6E0A8")]
		private void method_118()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x06003212 RID: 12818 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6E14C", Offset = "0x2E6E14C", VA = "0x2E6E14C")]
		[Token(Token = "0x6003212")]
		public Rigidbody method_119()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003213 RID: 12819 RVA: 0x00062034 File Offset: 0x00060234
		[Token(Token = "0x6003213")]
		[Address(RVA = "0x2E6E154", Offset = "0x2E6E154", VA = "0x2E6E154")]
		private void method_120()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x06003214 RID: 12820 RVA: 0x0006342C File Offset: 0x0006162C
		[Address(RVA = "0x2E6E1F4", Offset = "0x2E6E1F4", VA = "0x2E6E1F4")]
		[Token(Token = "0x6003214")]
		private void method_121()
		{
			base.GetComponent<Rigidbody>();
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x06003215 RID: 12821 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x6003215")]
		[Address(RVA = "0x2E6E298", Offset = "0x2E6E298", VA = "0x2E6E298")]
		private void method_122()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x06003216 RID: 12822 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x6003216")]
		[Address(RVA = "0x2E6E33C", Offset = "0x2E6E33C", VA = "0x2E6E33C")]
		public void method_123(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x06003217 RID: 12823 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6E344", Offset = "0x2E6E344", VA = "0x2E6E344")]
		[Token(Token = "0x6003217")]
		public Rigidbody method_124()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003218 RID: 12824 RVA: 0x00003125 File Offset: 0x00001325
		[Token(Token = "0x6003218")]
		[Address(RVA = "0x2E6E34C", Offset = "0x2E6E34C", VA = "0x2E6E34C")]
		public Rigidbody method_125()
		{
			return this.rigidbody_0;
		}

		// Token: 0x06003219 RID: 12825 RVA: 0x00003125 File Offset: 0x00001325
		[Address(RVA = "0x2E6E354", Offset = "0x2E6E354", VA = "0x2E6E354")]
		[Token(Token = "0x6003219")]
		public Rigidbody method_126()
		{
			return this.rigidbody_0;
		}

		// Token: 0x0600321A RID: 12826 RVA: 0x00063464 File Offset: 0x00061664
		[Token(Token = "0x600321A")]
		[Address(RVA = "0x2E6E35C", Offset = "0x2E6E35C", VA = "0x2E6E35C")]
		private void method_127()
		{
			if (this.bool_0)
			{
				return;
			}
			Vector3 position = this.rigidbody_0.position;
			float deltaTime = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			this.float_3 = (float)17285;
		}

		// Token: 0x0600321B RID: 12827 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x600321B")]
		[Address(RVA = "0x2E6E52C", Offset = "0x2E6E52C", VA = "0x2E6E52C")]
		public void method_128(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x0600321C RID: 12828 RVA: 0x0000312D File Offset: 0x0000132D
		[Token(Token = "0x600321C")]
		[Address(RVA = "0x2E6E534", Offset = "0x2E6E534", VA = "0x2E6E534")]
		public void method_129(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x0600321D RID: 12829 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x600321D")]
		[Address(RVA = "0x2E6E53C", Offset = "0x2E6E53C", VA = "0x2E6E53C")]
		private void method_130()
		{
			Rigidbody component = base.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = base.transform.position;
			long num = 1L;
			this.bool_1 = (num != 0L);
		}

		// Token: 0x0600321E RID: 12830 RVA: 0x0000312D File Offset: 0x0000132D
		[Address(RVA = "0x2E6E5E0", Offset = "0x2E6E5E0", VA = "0x2E6E5E0")]
		[Token(Token = "0x600321E")]
		public void method_131(Rigidbody rigidbody_1)
		{
			this.rigidbody_0 = rigidbody_1;
		}

		// Token: 0x04000632 RID: 1586
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000632")]
		[CompilerGenerated]
		private Rigidbody rigidbody_0;

		// Token: 0x04000633 RID: 1587
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000633")]
		public Transform transform_0;

		// Token: 0x04000634 RID: 1588
		[Token(Token = "0x4000634")]
		[FieldOffset(Offset = "0x28")]
		public float float_0;

		// Token: 0x04000635 RID: 1589
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000635")]
		public float float_1;

		// Token: 0x04000636 RID: 1590
		[Token(Token = "0x4000636")]
		[FieldOffset(Offset = "0x30")]
		public float float_2;

		// Token: 0x04000637 RID: 1591
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x4000637")]
		private Vector3 vector3_0;

		// Token: 0x04000638 RID: 1592
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000638")]
		private float float_3;

		// Token: 0x04000639 RID: 1593
		[FieldOffset(Offset = "0x44")]
		[Token(Token = "0x4000639")]
		private float float_4;

		// Token: 0x0400063A RID: 1594
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400063A")]
		private bool bool_0;

		// Token: 0x0400063B RID: 1595
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x400063B")]
		private Vector3 vector3_1;

		// Token: 0x0400063C RID: 1596
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x400063C")]
		private bool bool_1;

		// Token: 0x0400063D RID: 1597
		[FieldOffset(Offset = "0x5C")]
		[Token(Token = "0x400063D")]
		private float float_5;
	}
}
