﻿using System;
using Cpp2IlInjected;
using HexabodyVR.PlayerController;
using UnityEngine;

namespace HexabodyVR.SampleScene
{
	// Token: 0x0200013B RID: 315
	[Token(Token = "0x200013B")]
	public class SpiderHands : MonoBehaviour
	{
		// Token: 0x0600321F RID: 12831 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x600321F")]
		[Address(RVA = "0x2B982A4", Offset = "0x2B982A4", VA = "0x2B982A4")]
		private void method_0()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003220 RID: 12832 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003220")]
		[Address(RVA = "0x2B98318", Offset = "0x2B98318", VA = "0x2B98318")]
		private void method_1()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003221 RID: 12833 RVA: 0x000634C4 File Offset: 0x000616C4
		[Address(RVA = "0x2B9838C", Offset = "0x2B9838C", VA = "0x2B9838C")]
		[Token(Token = "0x6003221")]
		private void Start()
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003222 RID: 12834 RVA: 0x000634E8 File Offset: 0x000616E8
		[Token(Token = "0x6003222")]
		[Address(RVA = "0x2B983BC", Offset = "0x2B983BC", VA = "0x2B983BC")]
		private void method_2()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003223 RID: 12835 RVA: 0x0006350C File Offset: 0x0006170C
		[Token(Token = "0x6003223")]
		[Address(RVA = "0x2B983EC", Offset = "0x2B983EC", VA = "0x2B983EC")]
		private void method_3()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003224 RID: 12836 RVA: 0x000634E8 File Offset: 0x000616E8
		[Token(Token = "0x6003224")]
		[Address(RVA = "0x2B9841C", Offset = "0x2B9841C", VA = "0x2B9841C")]
		private void method_4()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003225 RID: 12837 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2B9844C", Offset = "0x2B9844C", VA = "0x2B9844C")]
		[Token(Token = "0x6003225")]
		private void method_5()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003226 RID: 12838 RVA: 0x00063530 File Offset: 0x00061730
		[Token(Token = "0x6003226")]
		[Address(RVA = "0x2B984C0", Offset = "0x2B984C0", VA = "0x2B984C0")]
		private void method_6()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003227 RID: 12839 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2B98994", Offset = "0x2B98994", VA = "0x2B98994")]
		[Token(Token = "0x6003227")]
		private void method_7()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003228 RID: 12840 RVA: 0x000635D8 File Offset: 0x000617D8
		[Token(Token = "0x6003228")]
		[Address(RVA = "0x2B989C4", Offset = "0x2B989C4", VA = "0x2B989C4")]
		private void method_8()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003229 RID: 12841 RVA: 0x0006350C File Offset: 0x0006170C
		[Address(RVA = "0x2B98E94", Offset = "0x2B98E94", VA = "0x2B98E94")]
		[Token(Token = "0x6003229")]
		private void method_9()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x0600322A RID: 12842 RVA: 0x00063680 File Offset: 0x00061880
		[Token(Token = "0x600322A")]
		[Address(RVA = "0x2B98EC4", Offset = "0x2B98EC4", VA = "0x2B98EC4")]
		private void method_10()
		{
			Vector3 position = this.transform_0.position;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600322B RID: 12843 RVA: 0x0006371C File Offset: 0x0006191C
		[Address(RVA = "0x2B99398", Offset = "0x2B99398", VA = "0x2B99398")]
		[Token(Token = "0x600322B")]
		private void FixedUpdate()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_89();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600322C RID: 12844 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x600322C")]
		[Address(RVA = "0x2B99A24", Offset = "0x2B99A24", VA = "0x2B99A24")]
		private void method_11()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600322D RID: 12845 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2B99AB0", Offset = "0x2B99AB0", VA = "0x2B99AB0")]
		[Token(Token = "0x600322D")]
		private void method_12()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600322E RID: 12846 RVA: 0x00063800 File Offset: 0x00061A00
		[Token(Token = "0x600322E")]
		[Address(RVA = "0x2B99B3C", Offset = "0x2B99B3C", VA = "0x2B99B3C")]
		private void method_13()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				if (hexaXRInputs.playerInputState_1 == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					long num = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					this.configurableJoint_0;
					UnityEngine.Object.Destroy(this.configurableJoint_0);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_94();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600322F RID: 12847 RVA: 0x0006350C File Offset: 0x0006170C
		[Address(RVA = "0x2B9A1D4", Offset = "0x2B9A1D4", VA = "0x2B9A1D4")]
		[Token(Token = "0x600322F")]
		private void method_14()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003230 RID: 12848 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x6003230")]
		[Address(RVA = "0x2B9A204", Offset = "0x2B9A204", VA = "0x2B9A204")]
		private void method_15()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003231 RID: 12849 RVA: 0x000638B0 File Offset: 0x00061AB0
		[Address(RVA = "0x2B9A290", Offset = "0x2B9A290", VA = "0x2B9A290")]
		[Token(Token = "0x6003231")]
		private void method_16()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					if (playerInputState_ != null)
					{
					}
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_136();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003232 RID: 12850 RVA: 0x00063958 File Offset: 0x00061B58
		[Address(RVA = "0x2B9A924", Offset = "0x2B9A924", VA = "0x2B9A924")]
		[Token(Token = "0x6003232")]
		private void method_17()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				if (hexaXRInputs.playerInputState_1 == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					long num = 1L;
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_125();
			}
			if (this.bool_0)
			{
				SoftJointLimit linearLimit = this.configurableJoint_0.linearLimit;
				float limit = linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
				float limit2;
				linearLimit.limit = limit2;
			}
		}

		// Token: 0x06003233 RID: 12851 RVA: 0x00063A24 File Offset: 0x00061C24
		[Token(Token = "0x6003233")]
		[Address(RVA = "0x2B9AFB8", Offset = "0x2B9AFB8", VA = "0x2B9AFB8")]
		private void method_18()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_33();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003234 RID: 12852 RVA: 0x00063ADC File Offset: 0x00061CDC
		[Token(Token = "0x6003234")]
		[Address(RVA = "0x2B9B648", Offset = "0x2B9B648", VA = "0x2B9B648")]
		private void method_19()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_42();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003235 RID: 12853 RVA: 0x00063B94 File Offset: 0x00061D94
		[Token(Token = "0x6003235")]
		[Address(RVA = "0x2B9BCDC", Offset = "0x2B9BCDC", VA = "0x2B9BCDC")]
		private void method_20()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			PlayerInputState playerInputState_;
			if (this.bool_0)
			{
				playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (playerInputState_ == null)
			{
				this.method_114();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003236 RID: 12854 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003236")]
		[Address(RVA = "0x2B9C370", Offset = "0x2B9C370", VA = "0x2B9C370")]
		private void method_21()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003237 RID: 12855 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2B9C3E4", Offset = "0x2B9C3E4", VA = "0x2B9C3E4")]
		[Token(Token = "0x6003237")]
		private void method_22()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003238 RID: 12856 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003238")]
		[Address(RVA = "0x2B9C470", Offset = "0x2B9C470", VA = "0x2B9C470")]
		private void method_23()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003239 RID: 12857 RVA: 0x00063C40 File Offset: 0x00061E40
		[Token(Token = "0x6003239")]
		[Address(RVA = "0x2B9C4E4", Offset = "0x2B9C4E4", VA = "0x2B9C4E4")]
		private void method_24()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					long num = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_6();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600323A RID: 12858 RVA: 0x00063D04 File Offset: 0x00061F04
		[Address(RVA = "0x2B9C6A8", Offset = "0x2B9C6A8", VA = "0x2B9C6A8")]
		[Token(Token = "0x600323A")]
		private void method_25()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				if (hexaXRInputs.playerInputState_1 == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					long num = 1L;
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_119();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600323B RID: 12859 RVA: 0x00063DC4 File Offset: 0x00061FC4
		[Token(Token = "0x600323B")]
		[Address(RVA = "0x2B9CD38", Offset = "0x2B9CD38", VA = "0x2B9CD38")]
		private void method_26()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				if (hexaXRInputs.playerInputState_1 == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					long num = 1L;
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_104();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600323C RID: 12860 RVA: 0x00063E84 File Offset: 0x00062084
		[Token(Token = "0x600323C")]
		[Address(RVA = "0x2B9D3D0", Offset = "0x2B9D3D0", VA = "0x2B9D3D0")]
		private void method_27()
		{
			LineRenderer lineRenderer;
			this.lineRenderer_0 = lineRenderer;
			BasicGrabber component = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component;
		}

		// Token: 0x0600323D RID: 12861 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2B9D45C", Offset = "0x2B9D45C", VA = "0x2B9D45C")]
		[Token(Token = "0x600323D")]
		private void method_28()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600323E RID: 12862 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x600323E")]
		[Address(RVA = "0x2B9D4D0", Offset = "0x2B9D4D0", VA = "0x2B9D4D0")]
		private void method_29()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600323F RID: 12863 RVA: 0x00063EA8 File Offset: 0x000620A8
		[Token(Token = "0x600323F")]
		[Address(RVA = "0x2B9D55C", Offset = "0x2B9D55C", VA = "0x2B9D55C")]
		private void method_30()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003240 RID: 12864 RVA: 0x00063F4C File Offset: 0x0006214C
		[Token(Token = "0x6003240")]
		[Address(RVA = "0x2B9DA30", Offset = "0x2B9DA30", VA = "0x2B9DA30")]
		private void method_31()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_73();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003241 RID: 12865 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2B9E0C0", Offset = "0x2B9E0C0", VA = "0x2B9E0C0")]
		[Token(Token = "0x6003241")]
		private void method_32()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003242 RID: 12866 RVA: 0x00064004 File Offset: 0x00062204
		[Address(RVA = "0x2B9B178", Offset = "0x2B9B178", VA = "0x2B9B178")]
		[Token(Token = "0x6003242")]
		private void method_33()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003243 RID: 12867 RVA: 0x000640AC File Offset: 0x000622AC
		[Token(Token = "0x6003243")]
		[Address(RVA = "0x2B9E134", Offset = "0x2B9E134", VA = "0x2B9E134")]
		private void method_34()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					long num = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_89();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003244 RID: 12868 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x6003244")]
		[Address(RVA = "0x2B9E2F8", Offset = "0x2B9E2F8", VA = "0x2B9E2F8")]
		private void method_35()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003245 RID: 12869 RVA: 0x00064170 File Offset: 0x00062370
		[Address(RVA = "0x2B9E384", Offset = "0x2B9E384", VA = "0x2B9E384")]
		[Token(Token = "0x6003245")]
		private void method_36()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003246 RID: 12870 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003246")]
		[Address(RVA = "0x2B9E858", Offset = "0x2B9E858", VA = "0x2B9E858")]
		private void method_37()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003247 RID: 12871 RVA: 0x00064210 File Offset: 0x00062410
		[Address(RVA = "0x2B9E8CC", Offset = "0x2B9E8CC", VA = "0x2B9E8CC")]
		[Token(Token = "0x6003247")]
		private void method_38()
		{
			if (this.bool_0)
			{
				Vector3 position = this.transform_0.position;
				return;
			}
		}

		// Token: 0x06003248 RID: 12872 RVA: 0x00064234 File Offset: 0x00062434
		[Token(Token = "0x6003248")]
		[Address(RVA = "0x2B9E940", Offset = "0x2B9E940", VA = "0x2B9E940")]
		private void Awake()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = component.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003249 RID: 12873 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2B9E9CC", Offset = "0x2B9E9CC", VA = "0x2B9E9CC")]
		[Token(Token = "0x6003249")]
		private void method_39()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600324A RID: 12874 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x600324A")]
		[Address(RVA = "0x2B9EA40", Offset = "0x2B9EA40", VA = "0x2B9EA40")]
		private void method_40()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600324B RID: 12875 RVA: 0x0006350C File Offset: 0x0006170C
		[Token(Token = "0x600324B")]
		[Address(RVA = "0x2B9EACC", Offset = "0x2B9EACC", VA = "0x2B9EACC")]
		private void method_41()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x0600324C RID: 12876 RVA: 0x00063530 File Offset: 0x00061730
		[Token(Token = "0x600324C")]
		[Address(RVA = "0x2B9B808", Offset = "0x2B9B808", VA = "0x2B9B808")]
		private void method_42()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600324D RID: 12877 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x600324D")]
		[Address(RVA = "0x2B9EAFC", Offset = "0x2B9EAFC", VA = "0x2B9EAFC")]
		private void method_43()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600324E RID: 12878 RVA: 0x00064260 File Offset: 0x00062460
		[Address(RVA = "0x2B9EB70", Offset = "0x2B9EB70", VA = "0x2B9EB70")]
		[Token(Token = "0x600324E")]
		private void method_44()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_8();
			}
			if (this.bool_0)
			{
				SoftJointLimit softJointLimit;
				float limit = softJointLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600324F RID: 12879 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x600324F")]
		[Address(RVA = "0x2B9ED30", Offset = "0x2B9ED30", VA = "0x2B9ED30")]
		private void method_45()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003250 RID: 12880 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2B9EDBC", Offset = "0x2B9EDBC", VA = "0x2B9EDBC")]
		[Token(Token = "0x6003250")]
		private void method_46()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003251 RID: 12881 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x6003251")]
		[Address(RVA = "0x2B9EE30", Offset = "0x2B9EE30", VA = "0x2B9EE30")]
		private void method_47()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003252 RID: 12882 RVA: 0x0006350C File Offset: 0x0006170C
		[Token(Token = "0x6003252")]
		[Address(RVA = "0x2B9EEBC", Offset = "0x2B9EEBC", VA = "0x2B9EEBC")]
		private void method_48()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003253 RID: 12883 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2B9EEEC", Offset = "0x2B9EEEC", VA = "0x2B9EEEC")]
		[Token(Token = "0x6003253")]
		private void method_49()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003254 RID: 12884 RVA: 0x00064310 File Offset: 0x00062510
		[Address(RVA = "0x2B9EF78", Offset = "0x2B9EF78", VA = "0x2B9EF78")]
		[Token(Token = "0x6003254")]
		private void method_50()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_104();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003255 RID: 12885 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2B9F134", Offset = "0x2B9F134", VA = "0x2B9F134")]
		[Token(Token = "0x6003255")]
		private void method_51()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003256 RID: 12886 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003256")]
		[Address(RVA = "0x2B9F164", Offset = "0x2B9F164", VA = "0x2B9F164")]
		private void method_52()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003257 RID: 12887 RVA: 0x000643C8 File Offset: 0x000625C8
		[Address(RVA = "0x2B9F1D8", Offset = "0x2B9F1D8", VA = "0x2B9F1D8")]
		[Token(Token = "0x6003257")]
		private void method_53()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_75();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003258 RID: 12888 RVA: 0x00064480 File Offset: 0x00062680
		[Address(RVA = "0x2B9F868", Offset = "0x2B9F868", VA = "0x2B9F868")]
		[Token(Token = "0x6003258")]
		private void method_54()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			PlayerInputState playerInputState_;
			if (this.bool_0)
			{
				playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (playerInputState_ == null)
			{
				this.method_8();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003259 RID: 12889 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2B9FA28", Offset = "0x2B9FA28", VA = "0x2B9FA28")]
		[Token(Token = "0x6003259")]
		private void method_55()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600325A RID: 12890 RVA: 0x0006452C File Offset: 0x0006272C
		[Address(RVA = "0x2B9FA9C", Offset = "0x2B9FA9C", VA = "0x2B9FA9C")]
		[Token(Token = "0x600325A")]
		private void method_56()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600325B RID: 12891 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2B9FF70", Offset = "0x2B9FF70", VA = "0x2B9FF70")]
		[Token(Token = "0x600325B")]
		private void method_57()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600325C RID: 12892 RVA: 0x00003136 File Offset: 0x00001336
		[Address(RVA = "0x2B9FFE4", Offset = "0x2B9FFE4", VA = "0x2B9FFE4")]
		[Token(Token = "0x600325C")]
		public SpiderHands()
		{
		}

		// Token: 0x0600325D RID: 12893 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA000C", Offset = "0x2BA000C", VA = "0x2BA000C")]
		[Token(Token = "0x600325D")]
		private void method_58()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600325E RID: 12894 RVA: 0x000645C8 File Offset: 0x000627C8
		[Address(RVA = "0x2BA0098", Offset = "0x2BA0098", VA = "0x2BA0098")]
		[Token(Token = "0x600325E")]
		private void method_59()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					long num = 1L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_89();
			}
			float limit = this.configurableJoint_0.linearLimit.limit;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x0600325F RID: 12895 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA025C", Offset = "0x2BA025C", VA = "0x2BA025C")]
		[Token(Token = "0x600325F")]
		private void method_60()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003260 RID: 12896 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA02E8", Offset = "0x2BA02E8", VA = "0x2BA02E8")]
		[Token(Token = "0x6003260")]
		private void method_61()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003261 RID: 12897 RVA: 0x00063530 File Offset: 0x00061730
		[Address(RVA = "0x2BA035C", Offset = "0x2BA035C", VA = "0x2BA035C")]
		[Token(Token = "0x6003261")]
		private void method_62()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003262 RID: 12898 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x2BA0830", Offset = "0x2BA0830", VA = "0x2BA0830")]
		[Token(Token = "0x6003262")]
		private void method_63()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003263 RID: 12899 RVA: 0x00064684 File Offset: 0x00062884
		[Address(RVA = "0x2BA08BC", Offset = "0x2BA08BC", VA = "0x2BA08BC")]
		[Token(Token = "0x6003263")]
		private void method_64()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				ConfigurableJoint exists = this.configurableJoint_0;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003264 RID: 12900 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA0D8C", Offset = "0x2BA0D8C", VA = "0x2BA0D8C")]
		[Token(Token = "0x6003264")]
		private void method_65()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003265 RID: 12901 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA0E00", Offset = "0x2BA0E00", VA = "0x2BA0E00")]
		[Token(Token = "0x6003265")]
		private void method_66()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003266 RID: 12902 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA0E8C", Offset = "0x2BA0E8C", VA = "0x2BA0E8C")]
		[Token(Token = "0x6003266")]
		private void method_67()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003267 RID: 12903 RVA: 0x00064734 File Offset: 0x00062934
		[Address(RVA = "0x2BA0F18", Offset = "0x2BA0F18", VA = "0x2BA0F18")]
		[Token(Token = "0x6003267")]
		private void method_68()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				ConfigurableJoint exists = this.configurableJoint_0;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003268 RID: 12904 RVA: 0x000647E4 File Offset: 0x000629E4
		[Token(Token = "0x6003268")]
		[Address(RVA = "0x2BA13E8", Offset = "0x2BA13E8", VA = "0x2BA13E8")]
		private void method_69()
		{
			Vector3 position = this.transform_0.position;
		}

		// Token: 0x06003269 RID: 12905 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA145C", Offset = "0x2BA145C", VA = "0x2BA145C")]
		[Token(Token = "0x6003269")]
		private void method_70()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600326A RID: 12906 RVA: 0x00064800 File Offset: 0x00062A00
		[Address(RVA = "0x2BA14E8", Offset = "0x2BA14E8", VA = "0x2BA14E8")]
		[Token(Token = "0x600326A")]
		private void method_71()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				if (hexaXRInputs.playerInputState_1 == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					long num = 1L;
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_114();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600326B RID: 12907 RVA: 0x000648C0 File Offset: 0x00062AC0
		[Address(RVA = "0x2BA16AC", Offset = "0x2BA16AC", VA = "0x2BA16AC")]
		[Token(Token = "0x600326B")]
		private void method_72()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_36();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600326C RID: 12908 RVA: 0x000635D8 File Offset: 0x000617D8
		[Address(RVA = "0x2B9DBF0", Offset = "0x2B9DBF0", VA = "0x2B9DBF0")]
		[Token(Token = "0x600326C")]
		private void method_73()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600326D RID: 12909 RVA: 0x00064978 File Offset: 0x00062B78
		[Address(RVA = "0x2BA186C", Offset = "0x2BA186C", VA = "0x2BA186C")]
		[Token(Token = "0x600326D")]
		private void method_74()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					long num = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_33();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x0600326E RID: 12910 RVA: 0x00064A3C File Offset: 0x00062C3C
		[Address(RVA = "0x2B9F398", Offset = "0x2B9F398", VA = "0x2B9F398")]
		[Token(Token = "0x600326E")]
		private void method_75()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			long num = 0L;
			float num2;
			Mathf.Clamp(num2, num2, num2);
			Transform transform3 = num.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600326F RID: 12911 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2BA1A30", Offset = "0x2BA1A30", VA = "0x2BA1A30")]
		[Token(Token = "0x600326F")]
		private void method_76()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003270 RID: 12912 RVA: 0x00064AD8 File Offset: 0x00062CD8
		[Address(RVA = "0x2BA1A60", Offset = "0x2BA1A60", VA = "0x2BA1A60")]
		[Token(Token = "0x6003270")]
		private void method_77()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_56();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003271 RID: 12913 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2BA1C20", Offset = "0x2BA1C20", VA = "0x2BA1C20")]
		[Token(Token = "0x6003271")]
		private void method_78()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003272 RID: 12914 RVA: 0x0006350C File Offset: 0x0006170C
		[Address(RVA = "0x2BA1C50", Offset = "0x2BA1C50", VA = "0x2BA1C50")]
		[Token(Token = "0x6003272")]
		private void method_79()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003273 RID: 12915 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA1C80", Offset = "0x2BA1C80", VA = "0x2BA1C80")]
		[Token(Token = "0x6003273")]
		private void method_80()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003274 RID: 12916 RVA: 0x00064B90 File Offset: 0x00062D90
		[Address(RVA = "0x2BA1CF4", Offset = "0x2BA1CF4", VA = "0x2BA1CF4")]
		[Token(Token = "0x6003274")]
		private void method_81()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003275 RID: 12917 RVA: 0x00064C38 File Offset: 0x00062E38
		[Address(RVA = "0x2BA21C4", Offset = "0x2BA21C4", VA = "0x2BA21C4")]
		[Token(Token = "0x6003275")]
		private void method_82()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					long num = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_64();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003276 RID: 12918 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003276")]
		[Address(RVA = "0x2BA2388", Offset = "0x2BA2388", VA = "0x2BA2388")]
		private void method_83()
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003277 RID: 12919 RVA: 0x000635D8 File Offset: 0x000617D8
		[Token(Token = "0x6003277")]
		[Address(RVA = "0x2BA285C", Offset = "0x2BA285C", VA = "0x2BA285C")]
		private void method_84()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003278 RID: 12920 RVA: 0x00064CFC File Offset: 0x00062EFC
		[Address(RVA = "0x2BA2D2C", Offset = "0x2BA2D2C", VA = "0x2BA2D2C")]
		[Token(Token = "0x6003278")]
		private void method_85()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
		}

		// Token: 0x06003279 RID: 12921 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2BA2DA0", Offset = "0x2BA2DA0", VA = "0x2BA2DA0")]
		[Token(Token = "0x6003279")]
		private void method_86()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x0600327A RID: 12922 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x600327A")]
		[Address(RVA = "0x2BA2DD0", Offset = "0x2BA2DD0", VA = "0x2BA2DD0")]
		private void method_87()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600327B RID: 12923 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x600327B")]
		[Address(RVA = "0x2BA2E44", Offset = "0x2BA2E44", VA = "0x2BA2E44")]
		private void method_88()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600327C RID: 12924 RVA: 0x00063530 File Offset: 0x00061730
		[Address(RVA = "0x2B99554", Offset = "0x2B99554", VA = "0x2B99554")]
		[Token(Token = "0x600327C")]
		private void method_89()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600327D RID: 12925 RVA: 0x00064D18 File Offset: 0x00062F18
		[Address(RVA = "0x2BA2EB8", Offset = "0x2BA2EB8", VA = "0x2BA2EB8")]
		[Token(Token = "0x600327D")]
		private void method_90()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			base.GetComponent<BasicGrabber>();
		}

		// Token: 0x0600327E RID: 12926 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA2F44", Offset = "0x2BA2F44", VA = "0x2BA2F44")]
		[Token(Token = "0x600327E")]
		private void Update()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600327F RID: 12927 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA2FB8", Offset = "0x2BA2FB8", VA = "0x2BA2FB8")]
		[Token(Token = "0x600327F")]
		private void method_91()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003280 RID: 12928 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003280")]
		[Address(RVA = "0x2BA3044", Offset = "0x2BA3044", VA = "0x2BA3044")]
		private void method_92()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003281 RID: 12929 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA30B8", Offset = "0x2BA30B8", VA = "0x2BA30B8")]
		[Token(Token = "0x6003281")]
		private void method_93()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003282 RID: 12930 RVA: 0x00063530 File Offset: 0x00061730
		[Address(RVA = "0x2B99D00", Offset = "0x2B99D00", VA = "0x2B99D00")]
		[Token(Token = "0x6003282")]
		private void method_94()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003283 RID: 12931 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA312C", Offset = "0x2BA312C", VA = "0x2BA312C")]
		[Token(Token = "0x6003283")]
		private void method_95()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003284 RID: 12932 RVA: 0x00064D3C File Offset: 0x00062F3C
		[Address(RVA = "0x2BA31A0", Offset = "0x2BA31A0", VA = "0x2BA31A0")]
		[Token(Token = "0x6003284")]
		private void method_96()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				LineRenderer lineRenderer = this.lineRenderer_0;
				long enabled = 1L;
				lineRenderer.enabled = (enabled != 0L);
				GameObject gameObject = this.gameObject_0;
				long active = 1L;
				gameObject.SetActive(active != 0L);
				ConfigurableJoint exists = this.configurableJoint_0;
				if (playerInputState_ != null)
				{
				}
				exists;
				if (playerInputState_ != null)
				{
				}
				return;
			}
			if (!this.basicGrabber_0.bool_0)
			{
				this.method_42();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003285 RID: 12933 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2BA3360", Offset = "0x2BA3360", VA = "0x2BA3360")]
		[Token(Token = "0x6003285")]
		private void method_97()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003286 RID: 12934 RVA: 0x000635D8 File Offset: 0x000617D8
		[Token(Token = "0x6003286")]
		[Address(RVA = "0x2BA3390", Offset = "0x2BA3390", VA = "0x2BA3390")]
		private void method_98()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003287 RID: 12935 RVA: 0x00064DE0 File Offset: 0x00062FE0
		[Address(RVA = "0x2BA3860", Offset = "0x2BA3860", VA = "0x2BA3860")]
		[Token(Token = "0x6003287")]
		private void method_99()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_62();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003288 RID: 12936 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA3A20", Offset = "0x2BA3A20", VA = "0x2BA3A20")]
		[Token(Token = "0x6003288")]
		private void method_100()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003289 RID: 12937 RVA: 0x00064D18 File Offset: 0x00062F18
		[Token(Token = "0x6003289")]
		[Address(RVA = "0x2BA3A94", Offset = "0x2BA3A94", VA = "0x2BA3A94")]
		private void method_101()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			base.GetComponent<BasicGrabber>();
		}

		// Token: 0x0600328A RID: 12938 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x600328A")]
		[Address(RVA = "0x2BA3B20", Offset = "0x2BA3B20", VA = "0x2BA3B20")]
		private void method_102()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600328B RID: 12939 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x600328B")]
		[Address(RVA = "0x2BA3BAC", Offset = "0x2BA3BAC", VA = "0x2BA3BAC")]
		private void method_103()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600328C RID: 12940 RVA: 0x00063530 File Offset: 0x00061730
		[Address(RVA = "0x2B9CEFC", Offset = "0x2B9CEFC", VA = "0x2B9CEFC")]
		[Token(Token = "0x600328C")]
		private void method_104()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600328D RID: 12941 RVA: 0x00064E94 File Offset: 0x00063094
		[Address(RVA = "0x2BA3C20", Offset = "0x2BA3C20", VA = "0x2BA3C20")]
		[Token(Token = "0x600328D")]
		private void method_105()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600328E RID: 12942 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x600328E")]
		[Address(RVA = "0x2BA40F4", Offset = "0x2BA40F4", VA = "0x2BA40F4")]
		private void method_106()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600328F RID: 12943 RVA: 0x00064F3C File Offset: 0x0006313C
		[Address(RVA = "0x2BA4180", Offset = "0x2BA4180", VA = "0x2BA4180")]
		[Token(Token = "0x600328F")]
		private void method_107()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_0;
			if (!hexaXRInputs.bool_11 || playerInputState_ == null)
			{
			}
			if (this.bool_0)
			{
				if (hexaXRInputs.playerInputState_1 == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					long num = 1L;
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (num != 0L)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_114();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x06003290 RID: 12944 RVA: 0x00064CFC File Offset: 0x00062EFC
		[Address(RVA = "0x2BA4344", Offset = "0x2BA4344", VA = "0x2BA4344")]
		[Token(Token = "0x6003290")]
		private void method_108()
		{
			Transform transform = this.transform_0;
			Vector3 position = transform.position;
		}

		// Token: 0x06003291 RID: 12945 RVA: 0x00063E84 File Offset: 0x00062084
		[Token(Token = "0x6003291")]
		[Address(RVA = "0x2BA43B8", Offset = "0x2BA43B8", VA = "0x2BA43B8")]
		private void method_109()
		{
			LineRenderer lineRenderer;
			this.lineRenderer_0 = lineRenderer;
			BasicGrabber component = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component;
		}

		// Token: 0x06003292 RID: 12946 RVA: 0x00063530 File Offset: 0x00061730
		[Address(RVA = "0x2BA4444", Offset = "0x2BA4444", VA = "0x2BA4444")]
		[Token(Token = "0x6003292")]
		private void method_110()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003293 RID: 12947 RVA: 0x00065000 File Offset: 0x00063200
		[Token(Token = "0x6003293")]
		[Address(RVA = "0x2BA4918", Offset = "0x2BA4918", VA = "0x2BA4918")]
		private void method_111()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003294 RID: 12948 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003294")]
		[Address(RVA = "0x2BA4DEC", Offset = "0x2BA4DEC", VA = "0x2BA4DEC")]
		private void method_112()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x06003295 RID: 12949 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA4E60", Offset = "0x2BA4E60", VA = "0x2BA4E60")]
		[Token(Token = "0x6003295")]
		private void method_113()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x06003296 RID: 12950 RVA: 0x000650A0 File Offset: 0x000632A0
		[Token(Token = "0x6003296")]
		[Address(RVA = "0x2B9BE9C", Offset = "0x2B9BE9C", VA = "0x2B9BE9C")]
		private void method_114()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x06003297 RID: 12951 RVA: 0x000634E8 File Offset: 0x000616E8
		[Token(Token = "0x6003297")]
		[Address(RVA = "0x2BA4EEC", Offset = "0x2BA4EEC", VA = "0x2BA4EEC")]
		private void method_115()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003298 RID: 12952 RVA: 0x0006350C File Offset: 0x0006170C
		[Address(RVA = "0x2BA4F1C", Offset = "0x2BA4F1C", VA = "0x2BA4F1C")]
		[Token(Token = "0x6003298")]
		private void method_116()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x06003299 RID: 12953 RVA: 0x000634A0 File Offset: 0x000616A0
		[Token(Token = "0x6003299")]
		[Address(RVA = "0x2BA4F4C", Offset = "0x2BA4F4C", VA = "0x2BA4F4C")]
		private void method_117()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x0600329A RID: 12954 RVA: 0x0006350C File Offset: 0x0006170C
		[Token(Token = "0x600329A")]
		[Address(RVA = "0x2BA4FC0", Offset = "0x2BA4FC0", VA = "0x2BA4FC0")]
		private void method_118()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x0600329B RID: 12955 RVA: 0x000635D8 File Offset: 0x000617D8
		[Address(RVA = "0x2B9C86C", Offset = "0x2B9C86C", VA = "0x2B9C86C")]
		[Token(Token = "0x600329B")]
		private void method_119()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x0600329C RID: 12956 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x600329C")]
		[Address(RVA = "0x2BA4FF0", Offset = "0x2BA4FF0", VA = "0x2BA4FF0")]
		private void method_120()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x0600329D RID: 12957 RVA: 0x000634E8 File Offset: 0x000616E8
		[Token(Token = "0x600329D")]
		[Address(RVA = "0x2BA507C", Offset = "0x2BA507C", VA = "0x2BA507C")]
		private void method_121()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x0600329E RID: 12958 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2BA50AC", Offset = "0x2BA50AC", VA = "0x2BA50AC")]
		[Token(Token = "0x600329E")]
		private void method_122()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x0600329F RID: 12959 RVA: 0x00065148 File Offset: 0x00063348
		[Token(Token = "0x600329F")]
		[Address(RVA = "0x2BA50DC", Offset = "0x2BA50DC", VA = "0x2BA50DC")]
		private void method_123()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					long num = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else
			{
				this.method_105();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x060032A0 RID: 12960 RVA: 0x000651FC File Offset: 0x000633FC
		[Token(Token = "0x60032A0")]
		[Address(RVA = "0x2BA52A0", Offset = "0x2BA52A0", VA = "0x2BA52A0")]
		private void method_124()
		{
			long num = 1L;
			if (num == 0L)
			{
				if (num != 0L)
				{
				}
				if (num != 0L)
				{
				}
				return;
			}
			if (num != 0L)
			{
				SoftJointLimit softJointLimit;
				float limit = softJointLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x060032A1 RID: 12961 RVA: 0x000635D8 File Offset: 0x000617D8
		[Address(RVA = "0x2B9AAE8", Offset = "0x2B9AAE8", VA = "0x2B9AAE8")]
		[Token(Token = "0x60032A1")]
		private void method_125()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x060032A2 RID: 12962 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x60032A2")]
		[Address(RVA = "0x2BA5460", Offset = "0x2BA5460", VA = "0x2BA5460")]
		private void method_126()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x060032A3 RID: 12963 RVA: 0x000637D4 File Offset: 0x000619D4
		[Token(Token = "0x60032A3")]
		[Address(RVA = "0x2BA54EC", Offset = "0x2BA54EC", VA = "0x2BA54EC")]
		private void method_127()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x060032A4 RID: 12964 RVA: 0x000634E8 File Offset: 0x000616E8
		[Address(RVA = "0x2BA5578", Offset = "0x2BA5578", VA = "0x2BA5578")]
		[Token(Token = "0x60032A4")]
		private void method_128()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 1L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x060032A5 RID: 12965 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA55A8", Offset = "0x2BA55A8", VA = "0x2BA55A8")]
		[Token(Token = "0x60032A5")]
		private void method_129()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x060032A6 RID: 12966 RVA: 0x00065228 File Offset: 0x00063428
		[Token(Token = "0x60032A6")]
		[Address(RVA = "0x2BA5634", Offset = "0x2BA5634", VA = "0x2BA5634")]
		private void method_130()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				Transform transform;
				ConfigurableJoint configurableJoint = transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform2 = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform3 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform4 = this.gameObject_0.transform;
			Transform transform5 = this.gameObject_0.transform;
		}

		// Token: 0x060032A7 RID: 12967 RVA: 0x000652C8 File Offset: 0x000634C8
		[Address(RVA = "0x2BA5B04", Offset = "0x2BA5B04", VA = "0x2BA5B04")]
		[Token(Token = "0x60032A7")]
		private void method_131()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				if (hexaXRInputs == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 1L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (hexaXRInputs != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (hexaXRInputs != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_81();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x060032A8 RID: 12968 RVA: 0x0006350C File Offset: 0x0006170C
		[Address(RVA = "0x2BA5CC4", Offset = "0x2BA5CC4", VA = "0x2BA5CC4")]
		[Token(Token = "0x60032A8")]
		private void method_132()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x060032A9 RID: 12969 RVA: 0x00065378 File Offset: 0x00063578
		[Token(Token = "0x60032A9")]
		[Address(RVA = "0x2BA5CF4", Offset = "0x2BA5CF4", VA = "0x2BA5CF4")]
		private void method_133()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			PlayerInputState playerInputState_;
			if (this.bool_0)
			{
				playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 1L;
					long num = 1L;
					gameObject.SetActive(active != 0L);
					this.bool_0 = (num != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					UnityEngine.Object.Destroy(this.configurableJoint_0);
					return;
				}
			}
			else if (playerInputState_ == null)
			{
				this.method_81();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x060032AA RID: 12970 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA5EB8", Offset = "0x2BA5EB8", VA = "0x2BA5EB8")]
		[Token(Token = "0x60032AA")]
		private void method_134()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x060032AB RID: 12971 RVA: 0x00065428 File Offset: 0x00063628
		[Address(RVA = "0x2BA5F44", Offset = "0x2BA5F44", VA = "0x2BA5F44")]
		[Token(Token = "0x60032AB")]
		private void method_135()
		{
			HexaXRInputs hexaXRInputs = this.hexaXRInputs_0;
			if (!hexaXRInputs.bool_11 || !hexaXRInputs.bool_15)
			{
			}
			if (this.bool_0)
			{
				PlayerInputState playerInputState_ = hexaXRInputs.playerInputState_1;
				if (playerInputState_ == null)
				{
					LineRenderer lineRenderer = this.lineRenderer_0;
					long enabled = 0L;
					lineRenderer.enabled = (enabled != 0L);
					GameObject gameObject = this.gameObject_0;
					long active = 0L;
					gameObject.SetActive(active != 0L);
					ConfigurableJoint exists = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					exists;
					ConfigurableJoint obj = this.configurableJoint_0;
					if (playerInputState_ != null)
					{
					}
					UnityEngine.Object.Destroy(obj);
					return;
				}
			}
			else if (!this.basicGrabber_0.bool_0)
			{
				this.method_83();
			}
			if (this.bool_0)
			{
				float limit = this.configurableJoint_0.linearLimit.limit;
				float fixedDeltaTime = Time.fixedDeltaTime;
			}
		}

		// Token: 0x060032AC RID: 12972 RVA: 0x000654E0 File Offset: 0x000636E0
		[Address(RVA = "0x2B9A450", Offset = "0x2B9A450", VA = "0x2B9A450")]
		[Token(Token = "0x60032AC")]
		private void method_136()
		{
			Vector3 position = this.transform_0.position;
			Vector3 forward = this.transform_0.forward;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.hexaXRInputs_0.playerInputState_1 != null)
			{
				ConfigurableJoint configurableJoint = this.rigidbody_0.transform.gameObject.AddComponent<ConfigurableJoint>();
				this.configurableJoint_0 = configurableJoint;
				Transform transform = base.transform;
				Vector3 position2 = this.transform_0.position;
				Rigidbody exists;
				exists;
				Rigidbody rigidbody;
				Transform transform2 = rigidbody.transform;
				return;
			}
			float num;
			Mathf.Clamp(num, num, num);
			Transform transform3 = this.gameObject_0.transform;
			Transform transform4 = this.gameObject_0.transform;
		}

		// Token: 0x060032AD RID: 12973 RVA: 0x000634A0 File Offset: 0x000616A0
		[Address(RVA = "0x2BA6104", Offset = "0x2BA6104", VA = "0x2BA6104")]
		[Token(Token = "0x60032AD")]
		private void method_137()
		{
			if (this.bool_0)
			{
				Transform transform = this.transform_0;
				Vector3 position = transform.position;
				return;
			}
		}

		// Token: 0x060032AE RID: 12974 RVA: 0x000637D4 File Offset: 0x000619D4
		[Address(RVA = "0x2BA6178", Offset = "0x2BA6178", VA = "0x2BA6178")]
		[Token(Token = "0x60032AE")]
		private void method_138()
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			this.lineRenderer_0 = component;
			BasicGrabber component2 = base.GetComponent<BasicGrabber>();
			this.basicGrabber_0 = component2;
		}

		// Token: 0x060032AF RID: 12975 RVA: 0x0006350C File Offset: 0x0006170C
		[Address(RVA = "0x2BA6204", Offset = "0x2BA6204", VA = "0x2BA6204")]
		[Token(Token = "0x60032AF")]
		private void method_139()
		{
			GameObject gameObject = this.gameObject_0.gameObject;
			long active = 0L;
			gameObject.SetActive(active != 0L);
		}

		// Token: 0x0400063E RID: 1598
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400063E")]
		public float float_0;

		// Token: 0x0400063F RID: 1599
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x400063F")]
		public float float_1;

		// Token: 0x04000640 RID: 1600
		[Token(Token = "0x4000640")]
		[FieldOffset(Offset = "0x20")]
		public LayerMask layerMask_0;

		// Token: 0x04000641 RID: 1601
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000641")]
		public HexaXRInputs hexaXRInputs_0;

		// Token: 0x04000642 RID: 1602
		[Token(Token = "0x4000642")]
		[FieldOffset(Offset = "0x30")]
		public bool bool_0;

		// Token: 0x04000643 RID: 1603
		[Token(Token = "0x4000643")]
		[FieldOffset(Offset = "0x38")]
		public Transform transform_0;

		// Token: 0x04000644 RID: 1604
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000644")]
		public Rigidbody rigidbody_0;

		// Token: 0x04000645 RID: 1605
		[Token(Token = "0x4000645")]
		[FieldOffset(Offset = "0x48")]
		public float float_2;

		// Token: 0x04000646 RID: 1606
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x4000646")]
		public float float_3;

		// Token: 0x04000647 RID: 1607
		[Token(Token = "0x4000647")]
		[FieldOffset(Offset = "0x50")]
		public float float_4 = (float)16672;

		// Token: 0x04000648 RID: 1608
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000648")]
		public GameObject gameObject_0;

		// Token: 0x04000649 RID: 1609
		[Token(Token = "0x4000649")]
		[FieldOffset(Offset = "0x60")]
		public ConfigurableJoint configurableJoint_0;

		// Token: 0x0400064A RID: 1610
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x400064A")]
		public BasicGrabber basicGrabber_0;

		// Token: 0x0400064B RID: 1611
		[Token(Token = "0x400064B")]
		[FieldOffset(Offset = "0x70")]
		public LineRenderer lineRenderer_0;

		// Token: 0x0400064C RID: 1612
		[Token(Token = "0x400064C")]
		[FieldOffset(Offset = "0x78")]
		private Vector3 vector3_0;

		// Token: 0x0400064D RID: 1613
		[FieldOffset(Offset = "0x84")]
		[Token(Token = "0x400064D")]
		private float float_5;
	}
}
