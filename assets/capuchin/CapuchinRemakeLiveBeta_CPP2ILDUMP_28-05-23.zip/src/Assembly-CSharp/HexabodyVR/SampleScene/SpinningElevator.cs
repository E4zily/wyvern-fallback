﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace HexabodyVR.SampleScene
{
	// Token: 0x0200013C RID: 316
	[Token(Token = "0x200013C")]
	public class SpinningElevator : MonoBehaviour
	{
		// Token: 0x060032B0 RID: 12976 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081018", Offset = "0x3081018", VA = "0x3081018")]
		[Token(Token = "0x60032B0")]
		private void method_0()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032B1 RID: 12977 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081084", Offset = "0x3081084", VA = "0x3081084")]
		[Token(Token = "0x60032B1")]
		private void method_1()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032B2 RID: 12978 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x30810F0", Offset = "0x30810F0", VA = "0x30810F0")]
		[Token(Token = "0x60032B2")]
		private void method_2()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032B3 RID: 12979 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x30811A4", Offset = "0x30811A4", VA = "0x30811A4")]
		[Token(Token = "0x60032B3")]
		private void method_3()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032B4 RID: 12980 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081210", Offset = "0x3081210", VA = "0x3081210")]
		[Token(Token = "0x60032B4")]
		private void method_4()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032B5 RID: 12981 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x308127C", Offset = "0x308127C", VA = "0x308127C")]
		[Token(Token = "0x60032B5")]
		private void method_5()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032B6 RID: 12982 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x30812E8", Offset = "0x30812E8", VA = "0x30812E8")]
		[Token(Token = "0x60032B6")]
		private void method_6()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032B7 RID: 12983 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081354", Offset = "0x3081354", VA = "0x3081354")]
		[Token(Token = "0x60032B7")]
		private void method_7()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032B8 RID: 12984 RVA: 0x000655A8 File Offset: 0x000637A8
		[Token(Token = "0x60032B8")]
		[Address(RVA = "0x30813C0", Offset = "0x30813C0", VA = "0x30813C0")]
		private void method_8()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032B9 RID: 12985 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x308147C", Offset = "0x308147C", VA = "0x308147C")]
		[Token(Token = "0x60032B9")]
		private void method_9()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032BA RID: 12986 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x30814E8", Offset = "0x30814E8", VA = "0x30814E8")]
		[Token(Token = "0x60032BA")]
		private void method_10()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032BB RID: 12987 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081554", Offset = "0x3081554", VA = "0x3081554")]
		[Token(Token = "0x60032BB")]
		private void FixedUpdate()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032BC RID: 12988 RVA: 0x00003149 File Offset: 0x00001349
		[Address(RVA = "0x3081608", Offset = "0x3081608", VA = "0x3081608")]
		[Token(Token = "0x60032BC")]
		public SpinningElevator()
		{
		}

		// Token: 0x060032BD RID: 12989 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081618", Offset = "0x3081618", VA = "0x3081618")]
		[Token(Token = "0x60032BD")]
		private void method_11()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032BE RID: 12990 RVA: 0x000655C8 File Offset: 0x000637C8
		[Address(RVA = "0x3081684", Offset = "0x3081684", VA = "0x3081684")]
		[Token(Token = "0x60032BE")]
		private void method_12()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032BF RID: 12991 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081740", Offset = "0x3081740", VA = "0x3081740")]
		[Token(Token = "0x60032BF")]
		private void method_13()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032C0 RID: 12992 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x30817AC", Offset = "0x30817AC", VA = "0x30817AC")]
		[Token(Token = "0x60032C0")]
		private void method_14()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032C1 RID: 12993 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081868", Offset = "0x3081868", VA = "0x3081868")]
		[Token(Token = "0x60032C1")]
		private void method_15()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032C2 RID: 12994 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081924", Offset = "0x3081924", VA = "0x3081924")]
		[Token(Token = "0x60032C2")]
		private void method_16()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032C3 RID: 12995 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x30819E0", Offset = "0x30819E0", VA = "0x30819E0")]
		[Token(Token = "0x60032C3")]
		private void method_17()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032C4 RID: 12996 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081A4C", Offset = "0x3081A4C", VA = "0x3081A4C")]
		[Token(Token = "0x60032C4")]
		private void method_18()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032C5 RID: 12997 RVA: 0x00065588 File Offset: 0x00063788
		[Token(Token = "0x60032C5")]
		[Address(RVA = "0x3081AB8", Offset = "0x3081AB8", VA = "0x3081AB8")]
		private void method_19()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032C6 RID: 12998 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081B24", Offset = "0x3081B24", VA = "0x3081B24")]
		[Token(Token = "0x60032C6")]
		private void method_20()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032C7 RID: 12999 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081B90", Offset = "0x3081B90", VA = "0x3081B90")]
		[Token(Token = "0x60032C7")]
		private void method_21()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032C8 RID: 13000 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081C4C", Offset = "0x3081C4C", VA = "0x3081C4C")]
		[Token(Token = "0x60032C8")]
		private void method_22()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032C9 RID: 13001 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081D08", Offset = "0x3081D08", VA = "0x3081D08")]
		[Token(Token = "0x60032C9")]
		private void method_23()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032CA RID: 13002 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081D74", Offset = "0x3081D74", VA = "0x3081D74")]
		[Token(Token = "0x60032CA")]
		private void method_24()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032CB RID: 13003 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081E30", Offset = "0x3081E30", VA = "0x3081E30")]
		[Token(Token = "0x60032CB")]
		private void method_25()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032CC RID: 13004 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3081EEC", Offset = "0x3081EEC", VA = "0x3081EEC")]
		[Token(Token = "0x60032CC")]
		private void method_26()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032CD RID: 13005 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3081F58", Offset = "0x3081F58", VA = "0x3081F58")]
		[Token(Token = "0x60032CD")]
		private void method_27()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032CE RID: 13006 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3082014", Offset = "0x3082014", VA = "0x3082014")]
		[Token(Token = "0x60032CE")]
		private void method_28()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032CF RID: 13007 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3082080", Offset = "0x3082080", VA = "0x3082080")]
		[Token(Token = "0x60032CF")]
		private void method_29()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032D0 RID: 13008 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x30820EC", Offset = "0x30820EC", VA = "0x30820EC")]
		[Token(Token = "0x60032D0")]
		private void method_30()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032D1 RID: 13009 RVA: 0x000655E8 File Offset: 0x000637E8
		[Address(RVA = "0x3082158", Offset = "0x3082158", VA = "0x3082158")]
		[Token(Token = "0x60032D1")]
		private void method_31()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032D2 RID: 13010 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3082214", Offset = "0x3082214", VA = "0x3082214")]
		[Token(Token = "0x60032D2")]
		private void method_32()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032D3 RID: 13011 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x30822D0", Offset = "0x30822D0", VA = "0x30822D0")]
		[Token(Token = "0x60032D3")]
		private void method_33()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032D4 RID: 13012 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x308233C", Offset = "0x308233C", VA = "0x308233C")]
		[Token(Token = "0x60032D4")]
		private void method_34()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032D5 RID: 13013 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x30823F8", Offset = "0x30823F8", VA = "0x30823F8")]
		[Token(Token = "0x60032D5")]
		private void method_35()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032D6 RID: 13014 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x30824B4", Offset = "0x30824B4", VA = "0x30824B4")]
		[Token(Token = "0x60032D6")]
		private void method_36()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032D7 RID: 13015 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3082570", Offset = "0x3082570", VA = "0x3082570")]
		[Token(Token = "0x60032D7")]
		private void method_37()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032D8 RID: 13016 RVA: 0x00065588 File Offset: 0x00063788
		[Token(Token = "0x60032D8")]
		[Address(RVA = "0x30825DC", Offset = "0x30825DC", VA = "0x30825DC")]
		private void method_38()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032D9 RID: 13017 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3082648", Offset = "0x3082648", VA = "0x3082648")]
		[Token(Token = "0x60032D9")]
		private void method_39()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032DA RID: 13018 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3082704", Offset = "0x3082704", VA = "0x3082704")]
		[Token(Token = "0x60032DA")]
		private void method_40()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032DB RID: 13019 RVA: 0x000655A8 File Offset: 0x000637A8
		[Token(Token = "0x60032DB")]
		[Address(RVA = "0x3082770", Offset = "0x3082770", VA = "0x3082770")]
		private void method_41()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032DC RID: 13020 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x308282C", Offset = "0x308282C", VA = "0x308282C")]
		[Token(Token = "0x60032DC")]
		private void method_42()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032DD RID: 13021 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x30828E8", Offset = "0x30828E8", VA = "0x30828E8")]
		[Token(Token = "0x60032DD")]
		private void method_43()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032DE RID: 13022 RVA: 0x000655A8 File Offset: 0x000637A8
		[Token(Token = "0x60032DE")]
		[Address(RVA = "0x3082954", Offset = "0x3082954", VA = "0x3082954")]
		private void method_44()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032DF RID: 13023 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3082A10", Offset = "0x3082A10", VA = "0x3082A10")]
		[Token(Token = "0x60032DF")]
		private void method_45()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032E0 RID: 13024 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3082A7C", Offset = "0x3082A7C", VA = "0x3082A7C")]
		[Token(Token = "0x60032E0")]
		private void method_46()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032E1 RID: 13025 RVA: 0x00065608 File Offset: 0x00063808
		[Address(RVA = "0x3082B38", Offset = "0x3082B38", VA = "0x3082B38")]
		[Token(Token = "0x60032E1")]
		private void Start()
		{
			GameObject gameObject;
			gameObject.GetComponent<Rigidbody>();
		}

		// Token: 0x060032E2 RID: 13026 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3082BA4", Offset = "0x3082BA4", VA = "0x3082BA4")]
		[Token(Token = "0x60032E2")]
		private void method_47()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032E3 RID: 13027 RVA: 0x0006561C File Offset: 0x0006381C
		[Address(RVA = "0x3082C10", Offset = "0x3082C10", VA = "0x3082C10")]
		[Token(Token = "0x60032E3")]
		private void method_48()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032E4 RID: 13028 RVA: 0x00065588 File Offset: 0x00063788
		[Address(RVA = "0x3082CCC", Offset = "0x3082CCC", VA = "0x3082CCC")]
		[Token(Token = "0x60032E4")]
		private void method_49()
		{
			Rigidbody component = base.gameObject.GetComponent<Rigidbody>();
			this.rigidbody_0 = component;
		}

		// Token: 0x060032E5 RID: 13029 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3082D38", Offset = "0x3082D38", VA = "0x3082D38")]
		[Token(Token = "0x60032E5")]
		private void method_50()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032E6 RID: 13030 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3082DF4", Offset = "0x3082DF4", VA = "0x3082DF4")]
		[Token(Token = "0x60032E6")]
		private void method_51()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x060032E7 RID: 13031 RVA: 0x000655A8 File Offset: 0x000637A8
		[Address(RVA = "0x3082EB0", Offset = "0x3082EB0", VA = "0x3082EB0")]
		[Token(Token = "0x60032E7")]
		private void method_52()
		{
			Quaternion rotation = base.transform.rotation;
			float fixedDeltaTime = Time.fixedDeltaTime;
		}

		// Token: 0x0400064E RID: 1614
		[Token(Token = "0x400064E")]
		[FieldOffset(Offset = "0x18")]
		public Rigidbody rigidbody_0;

		// Token: 0x0400064F RID: 1615
		[Token(Token = "0x400064F")]
		[FieldOffset(Offset = "0x20")]
		public float float_0 = (float)17036;
	}
}
