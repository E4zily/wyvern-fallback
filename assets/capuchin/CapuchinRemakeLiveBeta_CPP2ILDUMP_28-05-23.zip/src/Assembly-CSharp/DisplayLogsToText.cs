﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;

// Token: 0x020000BE RID: 190
[Token(Token = "0x20000BE")]
public class DisplayLogsToText : MonoBehaviour
{
	// Token: 0x06001AF8 RID: 6904 RVA: 0x00002833 File Offset: 0x00000A33
	[Address(RVA = "0x2EA69C0", Offset = "0x2EA69C0", VA = "0x2EA69C0")]
	[Token(Token = "0x6001AF8")]
	private void method_0()
	{
		if (this.bool_0)
		{
			GClass1.smethod_31(this.string_0);
		}
	}

	// Token: 0x06001AF9 RID: 6905 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA69F4", Offset = "0x2EA69F4", VA = "0x2EA69F4")]
	[Token(Token = "0x6001AF9")]
	private void method_1()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001AFA RID: 6906 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA6A48", Offset = "0x2EA6A48", VA = "0x2EA6A48")]
	[Token(Token = "0x6001AFA")]
	private void method_2()
	{
	}

	// Token: 0x06001AFB RID: 6907 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6A9C", Offset = "0x2EA6A9C", VA = "0x2EA6A9C")]
	[Token(Token = "0x6001AFB")]
	private void method_3()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001AFC RID: 6908 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6AF0", Offset = "0x2EA6AF0", VA = "0x2EA6AF0")]
	[Token(Token = "0x6001AFC")]
	private void method_4()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001AFD RID: 6909 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6B44", Offset = "0x2EA6B44", VA = "0x2EA6B44")]
	[Token(Token = "0x6001AFD")]
	private void method_5()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001AFE RID: 6910 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6B98", Offset = "0x2EA6B98", VA = "0x2EA6B98")]
	[Token(Token = "0x6001AFE")]
	private void method_6()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001AFF RID: 6911 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6BEC", Offset = "0x2EA6BEC", VA = "0x2EA6BEC")]
	[Token(Token = "0x6001AFF")]
	private void method_7()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B00 RID: 6912 RVA: 0x00002850 File Offset: 0x00000A50
	[Address(RVA = "0x2EA6C40", Offset = "0x2EA6C40", VA = "0x2EA6C40")]
	[Token(Token = "0x6001B00")]
	private void method_8()
	{
		if (this.bool_0)
		{
			GClass1.smethod_29(this.string_0);
		}
	}

	// Token: 0x06001B01 RID: 6913 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6C74", Offset = "0x2EA6C74", VA = "0x2EA6C74")]
	[Token(Token = "0x6001B01")]
	private void method_9()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B02 RID: 6914 RVA: 0x000350E0 File Offset: 0x000332E0
	[Address(RVA = "0x2EA6CC8", Offset = "0x2EA6CC8", VA = "0x2EA6CC8")]
	[Token(Token = "0x6001B02")]
	private void method_10()
	{
		if (this.bool_0)
		{
			GClass1.smethod_10(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B03 RID: 6915 RVA: 0x0003510C File Offset: 0x0003330C
	[Address(RVA = "0x2EA6D00", Offset = "0x2EA6D00", VA = "0x2EA6D00")]
	[Token(Token = "0x6001B03")]
	private void method_11()
	{
		if (this.bool_0)
		{
			GClass1.smethod_29(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B04 RID: 6916 RVA: 0x00002865 File Offset: 0x00000A65
	[Address(RVA = "0x2EA6D38", Offset = "0x2EA6D38", VA = "0x2EA6D38")]
	[Token(Token = "0x6001B04")]
	private void method_12()
	{
		if (this.bool_0)
		{
			GClass1.smethod_28(this.string_0);
		}
	}

	// Token: 0x06001B05 RID: 6917 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6D6C", Offset = "0x2EA6D6C", VA = "0x2EA6D6C")]
	[Token(Token = "0x6001B05")]
	private void method_13()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B06 RID: 6918 RVA: 0x00002833 File Offset: 0x00000A33
	[Address(RVA = "0x2EA6DC0", Offset = "0x2EA6DC0", VA = "0x2EA6DC0")]
	[Token(Token = "0x6001B06")]
	private void method_14()
	{
		if (this.bool_0)
		{
			GClass1.smethod_31(this.string_0);
		}
	}

	// Token: 0x06001B07 RID: 6919 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6DF4", Offset = "0x2EA6DF4", VA = "0x2EA6DF4")]
	[Token(Token = "0x6001B07")]
	private void method_15()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B08 RID: 6920 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6E48", Offset = "0x2EA6E48", VA = "0x2EA6E48")]
	[Token(Token = "0x6001B08")]
	private void method_16()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B09 RID: 6921 RVA: 0x0000287A File Offset: 0x00000A7A
	[Address(RVA = "0x2EA6E9C", Offset = "0x2EA6E9C", VA = "0x2EA6E9C")]
	[Token(Token = "0x6001B09")]
	private void method_17()
	{
		if (this.bool_0)
		{
			GClass1.smethod_2(this.string_0);
		}
	}

	// Token: 0x06001B0A RID: 6922 RVA: 0x0000288F File Offset: 0x00000A8F
	[Address(RVA = "0x2EA6ED0", Offset = "0x2EA6ED0", VA = "0x2EA6ED0")]
	[Token(Token = "0x6001B0A")]
	private void method_18()
	{
		if (this.bool_0)
		{
			GClass1.smethod_33(this.string_0);
		}
	}

	// Token: 0x06001B0B RID: 6923 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6F04", Offset = "0x2EA6F04", VA = "0x2EA6F04")]
	[Token(Token = "0x6001B0B")]
	private void method_19()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B0C RID: 6924 RVA: 0x0000288F File Offset: 0x00000A8F
	[Address(RVA = "0x2EA6F58", Offset = "0x2EA6F58", VA = "0x2EA6F58")]
	[Token(Token = "0x6001B0C")]
	private void method_20()
	{
		if (this.bool_0)
		{
			GClass1.smethod_33(this.string_0);
		}
	}

	// Token: 0x06001B0D RID: 6925 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6F8C", Offset = "0x2EA6F8C", VA = "0x2EA6F8C")]
	[Token(Token = "0x6001B0D")]
	private void method_21()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B0E RID: 6926 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA6FE0", Offset = "0x2EA6FE0", VA = "0x2EA6FE0")]
	[Token(Token = "0x6001B0E")]
	private void method_22()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B0F RID: 6927 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA7034", Offset = "0x2EA7034", VA = "0x2EA7034")]
	[Token(Token = "0x6001B0F")]
	private void method_23()
	{
	}

	// Token: 0x06001B10 RID: 6928 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA7088", Offset = "0x2EA7088", VA = "0x2EA7088")]
	[Token(Token = "0x6001B10")]
	private void method_24()
	{
	}

	// Token: 0x06001B11 RID: 6929 RVA: 0x0000287A File Offset: 0x00000A7A
	[Address(RVA = "0x2EA70DC", Offset = "0x2EA70DC", VA = "0x2EA70DC")]
	[Token(Token = "0x6001B11")]
	private void method_25()
	{
		if (this.bool_0)
		{
			GClass1.smethod_2(this.string_0);
		}
	}

	// Token: 0x06001B12 RID: 6930 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7114", Offset = "0x2EA7114", VA = "0x2EA7114")]
	[Token(Token = "0x6001B12")]
	private void Start()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B13 RID: 6931 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7168", Offset = "0x2EA7168", VA = "0x2EA7168")]
	[Token(Token = "0x6001B13")]
	private void method_26()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B14 RID: 6932 RVA: 0x0003510C File Offset: 0x0003330C
	[Address(RVA = "0x2EA71BC", Offset = "0x2EA71BC", VA = "0x2EA71BC")]
	[Token(Token = "0x6001B14")]
	private void method_27()
	{
		if (this.bool_0)
		{
			GClass1.smethod_29(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B15 RID: 6933 RVA: 0x00035138 File Offset: 0x00033338
	[Address(RVA = "0x2EA71F4", Offset = "0x2EA71F4", VA = "0x2EA71F4")]
	[Token(Token = "0x6001B15")]
	private void method_28()
	{
		if (this.bool_0)
		{
			GClass1.smethod_52(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B16 RID: 6934 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA722C", Offset = "0x2EA722C", VA = "0x2EA722C")]
	[Token(Token = "0x6001B16")]
	private void method_29()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B17 RID: 6935 RVA: 0x00035164 File Offset: 0x00033364
	[Address(RVA = "0x2EA7280", Offset = "0x2EA7280", VA = "0x2EA7280")]
	[Token(Token = "0x6001B17")]
	private void method_30()
	{
		if (this.bool_0)
		{
			GClass1.smethod_20(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B18 RID: 6936 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA72B8", Offset = "0x2EA72B8", VA = "0x2EA72B8")]
	[Token(Token = "0x6001B18")]
	private void method_31()
	{
	}

	// Token: 0x06001B19 RID: 6937 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA730C", Offset = "0x2EA730C", VA = "0x2EA730C")]
	[Token(Token = "0x6001B19")]
	private void method_32()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B1A RID: 6938 RVA: 0x00035190 File Offset: 0x00033390
	[Address(RVA = "0x2EA7360", Offset = "0x2EA7360", VA = "0x2EA7360")]
	[Token(Token = "0x6001B1A")]
	private void method_33()
	{
		if (this.bool_0)
		{
			GClass1.smethod_34(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B1B RID: 6939 RVA: 0x000351BC File Offset: 0x000333BC
	[Address(RVA = "0x2EA7398", Offset = "0x2EA7398", VA = "0x2EA7398")]
	[Token(Token = "0x6001B1B")]
	public DisplayLogsToText()
	{
		List<string> list = new List();
		this.list_0 = list;
		Dictionary<string, int> dictionary;
		this.dictionary_0 = dictionary;
		base..ctor();
	}

	// Token: 0x06001B1C RID: 6940 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7470", Offset = "0x2EA7470", VA = "0x2EA7470")]
	[Token(Token = "0x6001B1C")]
	private void method_34()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B1D RID: 6941 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2EA74C4", Offset = "0x2EA74C4", VA = "0x2EA74C4")]
	[Token(Token = "0x6001B1D")]
	private void method_35()
	{
	}

	// Token: 0x06001B1E RID: 6942 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7518", Offset = "0x2EA7518", VA = "0x2EA7518")]
	[Token(Token = "0x6001B1E")]
	private void method_36()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B1F RID: 6943 RVA: 0x000028A4 File Offset: 0x00000AA4
	[Address(RVA = "0x2EA756C", Offset = "0x2EA756C", VA = "0x2EA756C")]
	[Token(Token = "0x6001B1F")]
	private void Update()
	{
		if (this.bool_0)
		{
			GClass1.smethod_3(this.string_0);
		}
	}

	// Token: 0x06001B20 RID: 6944 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA75A0", Offset = "0x2EA75A0", VA = "0x2EA75A0")]
	[Token(Token = "0x6001B20")]
	private void method_37()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B21 RID: 6945 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA75F4", Offset = "0x2EA75F4", VA = "0x2EA75F4")]
	[Token(Token = "0x6001B21")]
	private void method_38()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B22 RID: 6946 RVA: 0x000028B9 File Offset: 0x00000AB9
	[Address(RVA = "0x2EA7648", Offset = "0x2EA7648", VA = "0x2EA7648")]
	[Token(Token = "0x6001B22")]
	private void method_39()
	{
		if (this.bool_0)
		{
			GClass1.smethod_4(this.string_0);
		}
	}

	// Token: 0x06001B23 RID: 6947 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA767C", Offset = "0x2EA767C", VA = "0x2EA767C")]
	[Token(Token = "0x6001B23")]
	private void method_40()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B24 RID: 6948 RVA: 0x00002850 File Offset: 0x00000A50
	[Address(RVA = "0x2EA76D0", Offset = "0x2EA76D0", VA = "0x2EA76D0")]
	[Token(Token = "0x6001B24")]
	private void method_41()
	{
		if (this.bool_0)
		{
			GClass1.smethod_29(this.string_0);
		}
	}

	// Token: 0x06001B25 RID: 6949 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7704", Offset = "0x2EA7704", VA = "0x2EA7704")]
	[Token(Token = "0x6001B25")]
	private void method_42()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B26 RID: 6950 RVA: 0x000028CE File Offset: 0x00000ACE
	[Address(RVA = "0x2EA7758", Offset = "0x2EA7758", VA = "0x2EA7758")]
	[Token(Token = "0x6001B26")]
	private void method_43()
	{
		GClass1.smethod_1(this.string_0);
	}

	// Token: 0x06001B27 RID: 6951 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA778C", Offset = "0x2EA778C", VA = "0x2EA778C")]
	[Token(Token = "0x6001B27")]
	private void method_44()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B28 RID: 6952 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA77E0", Offset = "0x2EA77E0", VA = "0x2EA77E0")]
	[Token(Token = "0x6001B28")]
	private void method_45()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B29 RID: 6953 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7834", Offset = "0x2EA7834", VA = "0x2EA7834")]
	[Token(Token = "0x6001B29")]
	private void method_46()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B2A RID: 6954 RVA: 0x000028DB File Offset: 0x00000ADB
	[Address(RVA = "0x2EA7888", Offset = "0x2EA7888", VA = "0x2EA7888")]
	[Token(Token = "0x6001B2A")]
	private void method_47()
	{
		if (this.bool_0)
		{
			GClass1.smethod_25(this.string_0);
		}
	}

	// Token: 0x06001B2B RID: 6955 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA78BC", Offset = "0x2EA78BC", VA = "0x2EA78BC")]
	[Token(Token = "0x6001B2B")]
	private void method_48()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B2C RID: 6956 RVA: 0x00002833 File Offset: 0x00000A33
	[Address(RVA = "0x2EA7910", Offset = "0x2EA7910", VA = "0x2EA7910")]
	[Token(Token = "0x6001B2C")]
	private void method_49()
	{
		if (this.bool_0)
		{
			GClass1.smethod_31(this.string_0);
		}
	}

	// Token: 0x06001B2D RID: 6957 RVA: 0x000028F0 File Offset: 0x00000AF0
	[Address(RVA = "0x2EA7944", Offset = "0x2EA7944", VA = "0x2EA7944")]
	[Token(Token = "0x6001B2D")]
	private void method_50()
	{
		if (this.bool_0)
		{
			GClass1.smethod_30(this.string_0);
		}
	}

	// Token: 0x06001B2E RID: 6958 RVA: 0x000351EC File Offset: 0x000333EC
	[Address(RVA = "0x2EA797C", Offset = "0x2EA797C", VA = "0x2EA797C")]
	[Token(Token = "0x6001B2E")]
	private void method_51()
	{
		GClass1.smethod_50(this.string_0);
		long num = 1L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06001B2F RID: 6959 RVA: 0x00035210 File Offset: 0x00033410
	[Address(RVA = "0x2EA79B4", Offset = "0x2EA79B4", VA = "0x2EA79B4")]
	[Token(Token = "0x6001B2F")]
	private void method_52()
	{
		if (this.bool_0)
		{
			GClass1.smethod_4(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B30 RID: 6960 RVA: 0x0003523C File Offset: 0x0003343C
	[Address(RVA = "0x2EA79EC", Offset = "0x2EA79EC", VA = "0x2EA79EC")]
	[Token(Token = "0x6001B30")]
	private void method_53()
	{
		if (this.bool_0)
		{
			GClass1.smethod_50(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B31 RID: 6961 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7A24", Offset = "0x2EA7A24", VA = "0x2EA7A24")]
	[Token(Token = "0x6001B31")]
	private void method_54()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B32 RID: 6962 RVA: 0x00002905 File Offset: 0x00000B05
	[Address(RVA = "0x2EA7A78", Offset = "0x2EA7A78", VA = "0x2EA7A78")]
	[Token(Token = "0x6001B32")]
	private void method_55()
	{
		if (this.bool_0)
		{
			GClass1.smethod_40(this.string_0);
		}
	}

	// Token: 0x06001B33 RID: 6963 RVA: 0x0000291A File Offset: 0x00000B1A
	[Address(RVA = "0x2EA7AAC", Offset = "0x2EA7AAC", VA = "0x2EA7AAC")]
	[Token(Token = "0x6001B33")]
	private void method_56()
	{
		if (this.bool_0)
		{
			GClass1.smethod_43(this.string_0);
		}
	}

	// Token: 0x06001B34 RID: 6964 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7AE0", Offset = "0x2EA7AE0", VA = "0x2EA7AE0")]
	[Token(Token = "0x6001B34")]
	private void method_57()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B35 RID: 6965 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7B34", Offset = "0x2EA7B34", VA = "0x2EA7B34")]
	[Token(Token = "0x6001B35")]
	private void method_58()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B36 RID: 6966 RVA: 0x00035268 File Offset: 0x00033468
	[Address(RVA = "0x2EA7B88", Offset = "0x2EA7B88", VA = "0x2EA7B88")]
	[Token(Token = "0x6001B36")]
	private void method_59()
	{
		if (this.bool_0)
		{
			GClass1.smethod_31(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B37 RID: 6967 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7BC0", Offset = "0x2EA7BC0", VA = "0x2EA7BC0")]
	[Token(Token = "0x6001B37")]
	private void method_60()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B38 RID: 6968 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7C14", Offset = "0x2EA7C14", VA = "0x2EA7C14")]
	[Token(Token = "0x6001B38")]
	private void method_61()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B39 RID: 6969 RVA: 0x000028DB File Offset: 0x00000ADB
	[Address(RVA = "0x2EA7C68", Offset = "0x2EA7C68", VA = "0x2EA7C68")]
	[Token(Token = "0x6001B39")]
	private void method_62()
	{
		if (this.bool_0)
		{
			GClass1.smethod_25(this.string_0);
		}
	}

	// Token: 0x06001B3A RID: 6970 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7C9C", Offset = "0x2EA7C9C", VA = "0x2EA7C9C")]
	[Token(Token = "0x6001B3A")]
	private void method_63()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B3B RID: 6971 RVA: 0x0000292F File Offset: 0x00000B2F
	[Address(RVA = "0x2EA7CF0", Offset = "0x2EA7CF0", VA = "0x2EA7CF0")]
	[Token(Token = "0x6001B3B")]
	private void method_64()
	{
		if (this.bool_0)
		{
			GClass1.smethod_6(this.string_0);
		}
	}

	// Token: 0x06001B3C RID: 6972 RVA: 0x00035294 File Offset: 0x00033494
	[Address(RVA = "0x2EA7D28", Offset = "0x2EA7D28", VA = "0x2EA7D28")]
	[Token(Token = "0x6001B3C")]
	private void method_65()
	{
		if (this.bool_0)
		{
			GClass1.smethod_33(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B3D RID: 6973 RVA: 0x0003510C File Offset: 0x0003330C
	[Address(RVA = "0x2EA7D60", Offset = "0x2EA7D60", VA = "0x2EA7D60")]
	[Token(Token = "0x6001B3D")]
	private void method_66()
	{
		if (this.bool_0)
		{
			GClass1.smethod_29(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B3E RID: 6974 RVA: 0x00002944 File Offset: 0x00000B44
	[Address(RVA = "0x2EA7D98", Offset = "0x2EA7D98", VA = "0x2EA7D98")]
	[Token(Token = "0x6001B3E")]
	private void method_67()
	{
		if (this.bool_0)
		{
			GClass1.smethod_5(this.string_0);
		}
	}

	// Token: 0x06001B3F RID: 6975 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7DCC", Offset = "0x2EA7DCC", VA = "0x2EA7DCC")]
	[Token(Token = "0x6001B3F")]
	private void method_68()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B40 RID: 6976 RVA: 0x00002959 File Offset: 0x00000B59
	[Address(RVA = "0x2EA7E20", Offset = "0x2EA7E20", VA = "0x2EA7E20")]
	[Token(Token = "0x6001B40")]
	private void method_69()
	{
		if (this.bool_0)
		{
			GClass1.smethod_24(this.string_0);
		}
	}

	// Token: 0x06001B41 RID: 6977 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7E54", Offset = "0x2EA7E54", VA = "0x2EA7E54")]
	[Token(Token = "0x6001B41")]
	private void method_70()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B42 RID: 6978 RVA: 0x00035138 File Offset: 0x00033338
	[Address(RVA = "0x2EA7EA8", Offset = "0x2EA7EA8", VA = "0x2EA7EA8")]
	[Token(Token = "0x6001B42")]
	private void method_71()
	{
		if (this.bool_0)
		{
			GClass1.smethod_52(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B43 RID: 6979 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7EE0", Offset = "0x2EA7EE0", VA = "0x2EA7EE0")]
	[Token(Token = "0x6001B43")]
	private void method_72()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B44 RID: 6980 RVA: 0x000352C0 File Offset: 0x000334C0
	[Address(RVA = "0x2EA7F34", Offset = "0x2EA7F34", VA = "0x2EA7F34")]
	[Token(Token = "0x6001B44")]
	private void method_73()
	{
		if (this.bool_0)
		{
			GClass1.smethod_36(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B45 RID: 6981 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7F6C", Offset = "0x2EA7F6C", VA = "0x2EA7F6C")]
	[Token(Token = "0x6001B45")]
	private void method_74()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B46 RID: 6982 RVA: 0x0000296E File Offset: 0x00000B6E
	[Address(RVA = "0x2EA7FC0", Offset = "0x2EA7FC0", VA = "0x2EA7FC0")]
	[Token(Token = "0x6001B46")]
	private void method_75()
	{
		if (this.bool_0)
		{
			GClass1.smethod_36(this.string_0);
		}
	}

	// Token: 0x06001B47 RID: 6983 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA7FF4", Offset = "0x2EA7FF4", VA = "0x2EA7FF4")]
	[Token(Token = "0x6001B47")]
	private void method_76()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B48 RID: 6984 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA8048", Offset = "0x2EA8048", VA = "0x2EA8048")]
	[Token(Token = "0x6001B48")]
	private void method_77()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B49 RID: 6985 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA809C", Offset = "0x2EA809C", VA = "0x2EA809C")]
	[Token(Token = "0x6001B49")]
	private void method_78()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B4A RID: 6986 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA80F0", Offset = "0x2EA80F0", VA = "0x2EA80F0")]
	[Token(Token = "0x6001B4A")]
	private void method_79()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B4B RID: 6987 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA8144", Offset = "0x2EA8144", VA = "0x2EA8144")]
	[Token(Token = "0x6001B4B")]
	private void method_80()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B4C RID: 6988 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA8198", Offset = "0x2EA8198", VA = "0x2EA8198")]
	[Token(Token = "0x6001B4C")]
	private void method_81()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B4D RID: 6989 RVA: 0x000352EC File Offset: 0x000334EC
	[Address(RVA = "0x2EA81EC", Offset = "0x2EA81EC", VA = "0x2EA81EC")]
	[Token(Token = "0x6001B4D")]
	private void method_82()
	{
		if (this.bool_0)
		{
			GClass1.smethod_28(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B4E RID: 6990 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA8224", Offset = "0x2EA8224", VA = "0x2EA8224")]
	[Token(Token = "0x6001B4E")]
	private void method_83()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B4F RID: 6991 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA8278", Offset = "0x2EA8278", VA = "0x2EA8278")]
	[Token(Token = "0x6001B4F")]
	private void method_84()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B50 RID: 6992 RVA: 0x00035318 File Offset: 0x00033518
	[Address(RVA = "0x2EA82CC", Offset = "0x2EA82CC", VA = "0x2EA82CC")]
	[Token(Token = "0x6001B50")]
	private void method_85()
	{
		if (this.bool_0)
		{
			GClass1.smethod_40(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06001B51 RID: 6993 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA8304", Offset = "0x2EA8304", VA = "0x2EA8304")]
	[Token(Token = "0x6001B51")]
	private void method_86()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B52 RID: 6994 RVA: 0x0000292F File Offset: 0x00000B2F
	[Address(RVA = "0x2EA8358", Offset = "0x2EA8358", VA = "0x2EA8358")]
	[Token(Token = "0x6001B52")]
	private void method_87()
	{
		if (this.bool_0)
		{
			GClass1.smethod_6(this.string_0);
		}
	}

	// Token: 0x06001B53 RID: 6995 RVA: 0x00002848 File Offset: 0x00000A48
	[Address(RVA = "0x2EA838C", Offset = "0x2EA838C", VA = "0x2EA838C")]
	[Token(Token = "0x6001B53")]
	private void method_88()
	{
		DisplayLogsToText.displayLogsToText_0 = this;
	}

	// Token: 0x06001B54 RID: 6996 RVA: 0x00002983 File Offset: 0x00000B83
	[Address(RVA = "0x2EA83E0", Offset = "0x2EA83E0", VA = "0x2EA83E0")]
	[Token(Token = "0x6001B54")]
	private void method_89()
	{
		if (this.bool_0)
		{
			GClass1.smethod_52(this.string_0);
		}
	}

	// Token: 0x06001B55 RID: 6997 RVA: 0x00035344 File Offset: 0x00033544
	[Address(RVA = "0x2EA8414", Offset = "0x2EA8414", VA = "0x2EA8414")]
	[Token(Token = "0x6001B55")]
	private void method_90()
	{
		if (this.bool_0)
		{
			GClass1.smethod_0(this.string_0);
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x04000376 RID: 886
	[Token(Token = "0x4000376")]
	public static DisplayLogsToText displayLogsToText_0;

	// Token: 0x04000377 RID: 887
	[Token(Token = "0x4000377")]
	[FieldOffset(Offset = "0x18")]
	public TMP_Text tmp_Text_0;

	// Token: 0x04000378 RID: 888
	[Token(Token = "0x4000378")]
	[FieldOffset(Offset = "0x20")]
	public int int_0 = 100;

	// Token: 0x04000379 RID: 889
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000379")]
	[HideInInspector]
	public List<string> list_0;

	// Token: 0x0400037A RID: 890
	[Token(Token = "0x400037A")]
	[FieldOffset(Offset = "0x30")]
	public Dictionary<string, int> dictionary_0;

	// Token: 0x0400037B RID: 891
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400037B")]
	public bool bool_0;

	// Token: 0x0400037C RID: 892
	[Token(Token = "0x400037C")]
	[FieldOffset(Offset = "0x40")]
	public string string_0;
}
