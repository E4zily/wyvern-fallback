﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x02000006 RID: 6
[Token(Token = "0x2000006")]
public class BetterWeatherCycle : MonoBehaviour
{
	// Token: 0x060000F9 RID: 249 RVA: 0x00005604 File Offset: 0x00003804
	[Address(RVA = "0x366A978", Offset = "0x366A978", VA = "0x366A978")]
	[Token(Token = "0x60000F9")]
	public void method_0()
	{
		string text = DateTime.UtcNow.ToString("ChangeMaterialToNormal");
		this.string_0 = text;
		this.bool_0 = ("ChangeMaterialToNormal" != null);
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)8192;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("gameMode", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060000FA RID: 250 RVA: 0x000056E4 File Offset: 0x000038E4
	[Token(Token = "0x60000FA")]
	[Address(RVA = "0x366AD8C", Offset = "0x366AD8C", VA = "0x366AD8C")]
	public void method_1()
	{
		string text = DateTime.UtcNow.ToString("Player");
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)17120;
		long num = 1L;
		this.bool_1 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("This is the 5000 Bananas button, and it was just clicked", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x060000FB RID: 251 RVA: 0x000057B4 File Offset: 0x000039B4
	[Token(Token = "0x60000FB")]
	[Address(RVA = "0x366B014", Offset = "0x366B014", VA = "0x366B014")]
	public void method_2()
	{
		string text = DateTime.UtcNow.ToString("Removing ");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)17515;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		num;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Add/Remove Sword", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_2 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060000FC RID: 252 RVA: 0x00005874 File Offset: 0x00003A74
	[Token(Token = "0x60000FC")]
	[Address(RVA = "0x366B434", Offset = "0x366B434", VA = "0x366B434")]
	public void method_3()
	{
		string text = DateTime.UtcNow.ToString("Open");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)8192;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("TurnAmount", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_2 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060000FD RID: 253 RVA: 0x0000594C File Offset: 0x00003B4C
	[Token(Token = "0x60000FD")]
	[Address(RVA = "0x366B850", Offset = "0x366B850", VA = "0x366B850")]
	public void method_4()
	{
		string text = DateTime.UtcNow.ToString("PushToTalk");
		this.string_0 = text;
		GameObject gameObject = this.gameObject_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		bool activeSelf = gameObject.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)17260;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("/", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num3 = 1L;
			this.bool_2 = (num3 != 0L);
		}
		float num4 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060000FE RID: 254 RVA: 0x00005A3C File Offset: 0x00003C3C
	[Address(RVA = "0x366BC64", Offset = "0x366BC64", VA = "0x366BC64")]
	[Token(Token = "0x60000FE")]
	public void method_5()
	{
		DateTime utcNow = DateTime.UtcNow;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("TurnAmount", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x060000FF RID: 255 RVA: 0x00005B00 File Offset: 0x00003D00
	[Address(RVA = "0x366C07C", Offset = "0x366C07C", VA = "0x366C07C")]
	[Token(Token = "0x60000FF")]
	public void method_6()
	{
		string text = DateTime.UtcNow.ToString("liftoff failed!");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)57344;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float g = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		this.float_0 = g;
		float deltaTime3 = Time.deltaTime;
		this.color_0.g = g;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("INSIGNIFICANT CURRENCY", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000100 RID: 256 RVA: 0x00005BD4 File Offset: 0x00003DD4
	[Address(RVA = "0x366C494", Offset = "0x366C494", VA = "0x366C494")]
	[Token(Token = "0x6000100")]
	public void method_7()
	{
		string text = DateTime.UtcNow.ToString("true");
		this.string_0 = text;
		GameObject gameObject = this.gameObject_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		bool activeSelf = gameObject.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)40960;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("PlayWave", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num3 = 1L;
			this.bool_2 = (num3 != 0L);
		}
		float num4 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000101 RID: 257 RVA: 0x00005CC4 File Offset: 0x00003EC4
	[Token(Token = "0x6000101")]
	[Address(RVA = "0x366C8A4", Offset = "0x366C8A4", VA = "0x366C8A4")]
	public void method_8()
	{
		string text = DateTime.UtcNow.ToString("TurnAmount");
		this.string_0 = text;
		GameObject gameObject = this.gameObject_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		bool activeSelf = gameObject.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)8192;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Collided", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num3 = 1L;
			this.bool_2 = (num3 != 0L);
		}
		float num4 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000102 RID: 258 RVA: 0x00005DB0 File Offset: 0x00003FB0
	[Address(RVA = "0x366CCC0", Offset = "0x366CCC0", VA = "0x366CCC0")]
	[Token(Token = "0x6000102")]
	public void method_9()
	{
		DateTime utcNow = DateTime.UtcNow;
		string text;
		this.string_0 = text;
		GameObject gameObject = this.gameObject_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		bool activeSelf = gameObject.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)17513;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("closeToObject", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num3 = 1L;
			this.bool_2 = (num3 != 0L);
		}
		float num4 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000103 RID: 259 RVA: 0x00005E98 File Offset: 0x00004098
	[Token(Token = "0x6000103")]
	[Address(RVA = "0x366D0D0", Offset = "0x366D0D0", VA = "0x366D0D0")]
	public void FixedUpdate()
	{
		string text = DateTime.UtcNow.ToString("hh:mmtt");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)52429;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Vector1_d371bd24217449349bd747533d51af6b", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000104 RID: 260 RVA: 0x00005F70 File Offset: 0x00004170
	[Address(RVA = "0x366D4D4", Offset = "0x366D4D4", VA = "0x366D4D4")]
	[Token(Token = "0x6000104")]
	public void method_10()
	{
		string text = DateTime.UtcNow.ToString("CapuchinStore");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)17211;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("DisableCosmetic", value);
		if (!this.bool_2)
		{
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000105 RID: 261 RVA: 0x0000603C File Offset: 0x0000423C
	[Token(Token = "0x6000105")]
	[Address(RVA = "0x366D8E4", Offset = "0x366D8E4", VA = "0x366D8E4")]
	public void method_11()
	{
		DateTime utcNow = DateTime.UtcNow;
		string text;
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)16384;
		long num = 1L;
		this.bool_1 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("friend", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00006100 File Offset: 0x00004300
	[Token(Token = "0x6000106")]
	[Address(RVA = "0x366DB70", Offset = "0x366DB70", VA = "0x366DB70")]
	public void method_12()
	{
		string text = DateTime.UtcNow.ToString("Charging...");
		this.string_0 = text;
		GameObject gameObject = this.gameObject_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		bool activeSelf = gameObject.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("hand 1", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num3 = 1L;
			this.bool_2 = (num3 != 0L);
		}
		float num4 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000107 RID: 263 RVA: 0x000061F0 File Offset: 0x000043F0
	[Token(Token = "0x6000107")]
	[Address(RVA = "0x366DF8C", Offset = "0x366DF8C", VA = "0x366DF8C")]
	public void method_13()
	{
		DateTime utcNow = DateTime.UtcNow;
		string text;
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)16384;
		long num = 1L;
		this.bool_1 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("retract broken", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x06000108 RID: 264 RVA: 0x000062B4 File Offset: 0x000044B4
	[Address(RVA = "0x366E218", Offset = "0x366E218", VA = "0x366E218")]
	[Token(Token = "0x6000108")]
	public void method_14()
	{
		DateTime utcNow = DateTime.UtcNow;
		string text;
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat(". Please update you game to the latest version", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x06000109 RID: 265 RVA: 0x00006370 File Offset: 0x00004570
	[Token(Token = "0x6000109")]
	[Address(RVA = "0x366E4A0", Offset = "0x366E4A0", VA = "0x366E4A0")]
	public void method_15()
	{
		DateTime.UtcNow.ToString("sound play play");
		this.lerpSpeeds_0.RALspeed = (float)57344;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("StartSong", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0600010A RID: 266 RVA: 0x0000642C File Offset: 0x0000462C
	[Address(RVA = "0x366E728", Offset = "0x366E728", VA = "0x366E728")]
	[Token(Token = "0x600010A")]
	public void method_16()
	{
		string text = DateTime.UtcNow.ToString("True");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("FingerTip", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_2 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x0600010B RID: 267 RVA: 0x0000650C File Offset: 0x0000470C
	[Token(Token = "0x600010B")]
	[Address(RVA = "0x366EB3C", Offset = "0x366EB3C", VA = "0x366EB3C")]
	public void method_17()
	{
		string text = DateTime.UtcNow.ToString("Did Hit");
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)17436;
		long num = 1L;
		this.bool_1 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("EnableCosmetic", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x0600010C RID: 268 RVA: 0x000065DC File Offset: 0x000047DC
	[Token(Token = "0x600010C")]
	[Address(RVA = "0x366EDC4", Offset = "0x366EDC4", VA = "0x366EDC4")]
	public void method_18()
	{
		string text = DateTime.UtcNow.ToString("M/d/yyyy");
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("_WobbleZ", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0600010D RID: 269 RVA: 0x000066A0 File Offset: 0x000048A0
	[Address(RVA = "0x366F04C", Offset = "0x366F04C", VA = "0x366F04C")]
	[Token(Token = "0x600010D")]
	public void method_19()
	{
		string text = DateTime.UtcNow.ToString("[InputHelpers.IsPressed] The value of <button> is out or the supported range.");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Joined Public Room Successfully", value);
		AudioSource audioSource;
		if (this.bool_2)
		{
			audioSource = this.audioSource_0;
			audioSource.Play();
		}
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x0600010E RID: 270 RVA: 0x00006778 File Offset: 0x00004978
	[Address(RVA = "0x366F464", Offset = "0x366F464", VA = "0x366F464")]
	[Token(Token = "0x600010E")]
	public void method_20()
	{
		string text = DateTime.UtcNow.ToString("NGNNoSound");
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)17300;
		long num = 1L;
		this.bool_1 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("PURCHASED!", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x0600010F RID: 271 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600010F")]
	[Address(RVA = "0x366F6EC", Offset = "0x366F6EC", VA = "0x366F6EC")]
	public BetterWeatherCycle()
	{
	}

	// Token: 0x06000110 RID: 272 RVA: 0x00006848 File Offset: 0x00004A48
	[Token(Token = "0x6000110")]
	[Address(RVA = "0x366F6F4", Offset = "0x366F6F4", VA = "0x366F6F4")]
	public void method_21()
	{
		string text = DateTime.UtcNow.ToString("Starting to bake textures on frame ");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)17433;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("An error has occured while buying bananas, please restart your game and try again", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_2 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000111 RID: 273 RVA: 0x00006920 File Offset: 0x00004B20
	[Address(RVA = "0x366FB10", Offset = "0x366FB10", VA = "0x366FB10")]
	[Token(Token = "0x6000111")]
	public void method_22()
	{
		string text = DateTime.UtcNow.ToString("Cannot access an empty buffer.");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Time to bake textures: ", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_2 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000112 RID: 274 RVA: 0x00006A00 File Offset: 0x00004C00
	[Address(RVA = "0x366FF24", Offset = "0x366FF24", VA = "0x366FF24")]
	[Token(Token = "0x6000112")]
	public void method_23()
	{
		string text = DateTime.UtcNow.ToString("PlayerHead");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("Name Changing Error. Error: ", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num2 = 1L;
			this.bool_2 = (num2 != 0L);
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000113 RID: 275 RVA: 0x00006AE0 File Offset: 0x00004CE0
	[Token(Token = "0x6000113")]
	[Address(RVA = "0x3670344", Offset = "0x3670344", VA = "0x3670344")]
	public void method_24()
	{
		string text = DateTime.UtcNow.ToString("An error has occured while buying bananas, please restart your game and try again");
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)49152;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		float deltaTime4 = Time.deltaTime;
		if (this.bool_2)
		{
			this.audioSource_0.Play();
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000114 RID: 276 RVA: 0x00006BA0 File Offset: 0x00004DA0
	[Token(Token = "0x6000114")]
	[Address(RVA = "0x367075C", Offset = "0x367075C", VA = "0x367075C")]
	public void method_25()
	{
		DateTime utcNow = DateTime.UtcNow;
		string text;
		this.string_0 = text;
		bool activeSelf = this.gameObject_0.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)16384;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("ErrorScreen", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
		}
		float num2 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000115 RID: 277 RVA: 0x00006C6C File Offset: 0x00004E6C
	[Address(RVA = "0x3670B7C", Offset = "0x3670B7C", VA = "0x3670B7C")]
	[Token(Token = "0x6000115")]
	public void method_26()
	{
		string text = DateTime.UtcNow.ToString("run");
		this.string_0 = text;
		GameObject gameObject = this.gameObject_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		bool activeSelf = gameObject.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float g = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		this.float_0 = g;
		float deltaTime3 = Time.deltaTime;
		this.color_0.g = g;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("BloodKill", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
		}
		float num3 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000116 RID: 278 RVA: 0x00006D4C File Offset: 0x00004F4C
	[Token(Token = "0x6000116")]
	[Address(RVA = "0x3670F88", Offset = "0x3670F88", VA = "0x3670F88")]
	public void method_27()
	{
		string text = DateTime.UtcNow.ToString(" and the correct version is ");
		this.string_0 = text;
		GameObject gameObject = this.gameObject_0;
		long num = 1L;
		this.bool_0 = (num != 0L);
		bool activeSelf = gameObject.activeSelf;
		this.lerpSpeeds_0.RALspeed = (float)57344;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime3 = Time.deltaTime;
		volume.weight = weight;
		Material material = this.material_0;
		float deltaTime4 = Time.deltaTime;
		float value;
		material.SetFloat("EnableCosmetic", value);
		if (this.bool_2)
		{
			this.audioSource_0.Play();
			long num3 = 1L;
			this.bool_2 = (num3 != 0L);
		}
		float num4 = this.audioSource_0.volume;
		float deltaTime5 = Time.deltaTime;
	}

	// Token: 0x06000117 RID: 279 RVA: 0x00006E3C File Offset: 0x0000503C
	[Address(RVA = "0x36713A0", Offset = "0x36713A0", VA = "0x36713A0")]
	[Token(Token = "0x6000117")]
	public void method_28()
	{
		string text = DateTime.UtcNow.ToString(", ");
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)49152;
		long num = 1L;
		this.bool_1 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x06000118 RID: 280 RVA: 0x00006EEC File Offset: 0x000050EC
	[Address(RVA = "0x367162C", Offset = "0x367162C", VA = "0x367162C")]
	[Token(Token = "0x6000118")]
	public void method_29()
	{
		string text = DateTime.UtcNow.ToString("Is Colliding");
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)17116;
		long num = 1L;
		this.bool_1 = (num != 0L);
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num2;
		RenderSettings.fogEndDistance = num2;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num2;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("Tagging", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num3 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num4;
		audioSource.volume = num4;
	}

	// Token: 0x06000119 RID: 281 RVA: 0x00006FBC File Offset: 0x000051BC
	[Address(RVA = "0x36718B4", Offset = "0x36718B4", VA = "0x36718B4")]
	[Token(Token = "0x6000119")]
	public void method_30()
	{
		DateTime utcNow = DateTime.UtcNow;
		string text;
		this.string_0 = text;
		this.lerpSpeeds_0.RALspeed = (float)17429;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		Material material = this.material_0;
		float deltaTime2 = Time.deltaTime;
		float value;
		material.SetFloat("TurnAmount", value);
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0600011A RID: 282 RVA: 0x00007078 File Offset: 0x00005278
	[Address(RVA = "0x3671B38", Offset = "0x3671B38", VA = "0x3671B38")]
	[Token(Token = "0x600011A")]
	public void method_31()
	{
		DateTime.UtcNow.ToString("HeadAttachPoint");
		this.lerpSpeeds_0.RALspeed = (float)32768;
		float fogEndDistance = RenderSettings.fogEndDistance;
		float deltaTime = Time.deltaTime;
		float num;
		RenderSettings.fogEndDistance = num;
		ParticleSystem.EmissionModule emission = this.particleSystem_0.emission;
		float weight = this.float_0;
		num;
		float deltaTime2 = Time.deltaTime;
		float deltaTime3 = Time.deltaTime;
		Volume volume = this.volume;
		this.float_0 = weight;
		float deltaTime4 = Time.deltaTime;
		volume.weight = weight;
		AudioSource audioSource = this.audioSource_0;
		float num2 = audioSource.volume;
		float deltaTime5 = Time.deltaTime;
		float num3;
		audioSource.volume = num3;
	}

	// Token: 0x0400000B RID: 11
	[FieldOffset(Offset = "0x18")]
	[Space]
	[Token(Token = "0x400000B")]
	public bool bool_0;

	// Token: 0x0400000C RID: 12
	[FieldOffset(Offset = "0x1C")]
	[Space]
	[Token(Token = "0x400000C")]
	public BetterWeatherCycle.GEnum0 genum0_0;

	// Token: 0x0400000D RID: 13
	[Token(Token = "0x400000D")]
	[FieldOffset(Offset = "0x20")]
	public Color color_0;

	// Token: 0x0400000E RID: 14
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400000E")]
	public ParticleSystem particleSystem_0;

	// Token: 0x0400000F RID: 15
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400000F")]
	public bool bool_1;

	// Token: 0x04000010 RID: 16
	[Token(Token = "0x4000010")]
	[FieldOffset(Offset = "0x40")]
	public Material material_0;

	// Token: 0x04000011 RID: 17
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000011")]
	public BetterWeatherCycle.lerpSpeeds lerpSpeeds_0;

	// Token: 0x04000012 RID: 18
	[SerializeField]
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4000012")]
	private Volume volume;

	// Token: 0x04000013 RID: 19
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000013")]
	private float float_0;

	// Token: 0x04000014 RID: 20
	[Token(Token = "0x4000014")]
	[FieldOffset(Offset = "0x70")]
	public GameObject gameObject_0;

	// Token: 0x04000015 RID: 21
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x4000015")]
	public AudioSource audioSource_0;

	// Token: 0x04000016 RID: 22
	[Token(Token = "0x4000016")]
	[FieldOffset(Offset = "0x80")]
	private float float_1;

	// Token: 0x04000017 RID: 23
	[FieldOffset(Offset = "0x84")]
	[Token(Token = "0x4000017")]
	public bool bool_2;

	// Token: 0x04000018 RID: 24
	[Token(Token = "0x4000018")]
	[FieldOffset(Offset = "0x88")]
	public BetterWeatherCycle.Thunder thunder_0;

	// Token: 0x04000019 RID: 25
	[Token(Token = "0x4000019")]
	[FieldOffset(Offset = "0xB0")]
	private bool bool_3;

	// Token: 0x0400001A RID: 26
	[Token(Token = "0x400001A")]
	[FieldOffset(Offset = "0xB8")]
	[Space]
	public string string_0;

	// Token: 0x0400001B RID: 27
	[Space]
	[FieldOffset(Offset = "0xC0")]
	[Token(Token = "0x400001B")]
	public List<string> list_0;

	// Token: 0x02000007 RID: 7
	[Token(Token = "0x2000007")]
	public enum GEnum0
	{
		// Token: 0x0400001D RID: 29
		[Token(Token = "0x400001D")]
		const_0,
		// Token: 0x0400001E RID: 30
		[Token(Token = "0x400001E")]
		[InspectorName("Rain & Thunder")]
		const_1
	}

	// Token: 0x02000008 RID: 8
	[Token(Token = "0x2000008")]
	[Serializable]
	public struct lerpSpeeds
	{
		// Token: 0x0400001F RID: 31
		[Token(Token = "0x400001F")]
		[Header("Lerp Values (Order should be 0.8f, 0.2f, 0.2f, 0.05f, and 0.2f)")]
		[FieldOffset(Offset = "0x0")]
		public float FLspeed;

		// Token: 0x04000020 RID: 32
		[Token(Token = "0x4000020")]
		[FieldOffset(Offset = "0x4")]
		public float volumeWeightSpeed;

		// Token: 0x04000021 RID: 33
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4000021")]
		public float RLspeed;

		// Token: 0x04000022 RID: 34
		[FieldOffset(Offset = "0xC")]
		[Token(Token = "0x4000022")]
		public float RALspeed;

		// Token: 0x04000023 RID: 35
		[Token(Token = "0x4000023")]
		[FieldOffset(Offset = "0x10")]
		public float cloudLerpSpeed;
	}

	// Token: 0x02000009 RID: 9
	[Token(Token = "0x2000009")]
	[Serializable]
	public struct Thunder
	{
		// Token: 0x04000024 RID: 36
		[Token(Token = "0x4000024")]
		[FieldOffset(Offset = "0x0")]
		public Transform[] possibleLightningStrikes;

		// Token: 0x04000025 RID: 37
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4000025")]
		public AudioSource thunder;

		// Token: 0x04000026 RID: 38
		[Token(Token = "0x4000026")]
		[FieldOffset(Offset = "0x10")]
		public AudioClip[] sounds;

		// Token: 0x04000027 RID: 39
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000027")]
		public ParticleSystem strike;

		// Token: 0x04000028 RID: 40
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000028")]
		public GameObject thunderThing;
	}
}
