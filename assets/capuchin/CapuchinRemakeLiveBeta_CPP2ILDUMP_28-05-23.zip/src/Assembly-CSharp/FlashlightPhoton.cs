﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000CB RID: 203
[Token(Token = "0x20000CB")]
public class FlashlightPhoton : MonoBehaviour
{
	// Token: 0x06001CF0 RID: 7408 RVA: 0x00037354 File Offset: 0x00035554
	[Address(RVA = "0x34F8C78", Offset = "0x34F8C78", VA = "0x34F8C78")]
	[Token(Token = "0x6001CF0")]
	private void method_0()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF1 RID: 7409 RVA: 0x000373AC File Offset: 0x000355AC
	[Address(RVA = "0x34F8CEC", Offset = "0x34F8CEC", VA = "0x34F8CEC")]
	[Token(Token = "0x6001CF1")]
	private void method_1()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF2 RID: 7410 RVA: 0x00037400 File Offset: 0x00035600
	[Address(RVA = "0x34F8D64", Offset = "0x34F8D64", VA = "0x34F8D64")]
	[Token(Token = "0x6001CF2")]
	private void method_2()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF3 RID: 7411 RVA: 0x00037458 File Offset: 0x00035658
	[Address(RVA = "0x34F8DD8", Offset = "0x34F8DD8", VA = "0x34F8DD8")]
	[Token(Token = "0x6001CF3")]
	private void method_3()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF4 RID: 7412 RVA: 0x000374AC File Offset: 0x000356AC
	[Address(RVA = "0x34F8E50", Offset = "0x34F8E50", VA = "0x34F8E50")]
	[Token(Token = "0x6001CF4")]
	private void method_4()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF5 RID: 7413 RVA: 0x00037504 File Offset: 0x00035704
	[Address(RVA = "0x34F8EC4", Offset = "0x34F8EC4", VA = "0x34F8EC4")]
	[Token(Token = "0x6001CF5")]
	private void method_5()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF6 RID: 7414 RVA: 0x00037400 File Offset: 0x00035600
	[Address(RVA = "0x34F8F38", Offset = "0x34F8F38", VA = "0x34F8F38")]
	[Token(Token = "0x6001CF6")]
	private void method_6()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF7 RID: 7415 RVA: 0x0003755C File Offset: 0x0003575C
	[Address(RVA = "0x34F8FAC", Offset = "0x34F8FAC", VA = "0x34F8FAC")]
	[Token(Token = "0x6001CF7")]
	private void method_7()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF8 RID: 7416 RVA: 0x00037400 File Offset: 0x00035600
	[Address(RVA = "0x34F9024", Offset = "0x34F9024", VA = "0x34F9024")]
	[Token(Token = "0x6001CF8")]
	private void method_8()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CF9 RID: 7417 RVA: 0x000375B0 File Offset: 0x000357B0
	[Address(RVA = "0x34F9098", Offset = "0x34F9098", VA = "0x34F9098")]
	[Token(Token = "0x6001CF9")]
	private void method_9()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CFA RID: 7418 RVA: 0x000373AC File Offset: 0x000355AC
	[Address(RVA = "0x34F9110", Offset = "0x34F9110", VA = "0x34F9110")]
	[Token(Token = "0x6001CFA")]
	private void method_10()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CFB RID: 7419 RVA: 0x00037604 File Offset: 0x00035804
	[Address(RVA = "0x34F9188", Offset = "0x34F9188", VA = "0x34F9188")]
	[Token(Token = "0x6001CFB")]
	private void method_11()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CFC RID: 7420 RVA: 0x00037658 File Offset: 0x00035858
	[Address(RVA = "0x34F9200", Offset = "0x34F9200", VA = "0x34F9200")]
	[Token(Token = "0x6001CFC")]
	private void method_12()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06001CFD RID: 7421 RVA: 0x0003755C File Offset: 0x0003575C
	[Address(RVA = "0x34F9278", Offset = "0x34F9278", VA = "0x34F9278")]
	[Token(Token = "0x6001CFD")]
	private void method_13()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CFE RID: 7422 RVA: 0x000375B0 File Offset: 0x000357B0
	[Address(RVA = "0x34F92F0", Offset = "0x34F92F0", VA = "0x34F92F0")]
	[Token(Token = "0x6001CFE")]
	private void method_14()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001CFF RID: 7423 RVA: 0x00037674 File Offset: 0x00035874
	[Address(RVA = "0x34F9368", Offset = "0x34F9368", VA = "0x34F9368")]
	[Token(Token = "0x6001CFF")]
	private void method_15()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D00 RID: 7424 RVA: 0x000376CC File Offset: 0x000358CC
	[Address(RVA = "0x34F93DC", Offset = "0x34F93DC", VA = "0x34F93DC")]
	[Token(Token = "0x6001D00")]
	private void method_16()
	{
		while (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		this.gameObject_1.SetActive(active2 != 0L);
	}

	// Token: 0x06001D01 RID: 7425 RVA: 0x000375B0 File Offset: 0x000357B0
	[Address(RVA = "0x34F9450", Offset = "0x34F9450", VA = "0x34F9450")]
	[Token(Token = "0x6001D01")]
	private void method_17()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D02 RID: 7426 RVA: 0x0003771C File Offset: 0x0003591C
	[Address(RVA = "0x34F94C8", Offset = "0x34F94C8", VA = "0x34F94C8")]
	[Token(Token = "0x6001D02")]
	private void Update()
	{
		long active2;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			active2 = 1L;
			return;
		}
		this.gameObject_0.SetActive(active2 != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active3 = 0L;
		gameObject2.SetActive(active3 != 0L);
	}

	// Token: 0x06001D03 RID: 7427 RVA: 0x000374AC File Offset: 0x000356AC
	[Address(RVA = "0x34F9540", Offset = "0x34F9540", VA = "0x34F9540")]
	[Token(Token = "0x6001D03")]
	private void method_18()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D04 RID: 7428 RVA: 0x0003776C File Offset: 0x0003596C
	[Address(RVA = "0x34F95B4", Offset = "0x34F95B4", VA = "0x34F95B4")]
	[Token(Token = "0x6001D04")]
	private void method_19()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D05 RID: 7429 RVA: 0x00037354 File Offset: 0x00035554
	[Address(RVA = "0x34F9628", Offset = "0x34F9628", VA = "0x34F9628")]
	[Token(Token = "0x6001D05")]
	private void method_20()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D06 RID: 7430 RVA: 0x000377C4 File Offset: 0x000359C4
	[Address(RVA = "0x34F969C", Offset = "0x34F969C", VA = "0x34F969C")]
	[Token(Token = "0x6001D06")]
	private void method_21()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D07 RID: 7431 RVA: 0x00037818 File Offset: 0x00035A18
	[Address(RVA = "0x34F9714", Offset = "0x34F9714", VA = "0x34F9714")]
	[Token(Token = "0x6001D07")]
	private void method_22()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D08 RID: 7432 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x34F978C", Offset = "0x34F978C", VA = "0x34F978C")]
	[Token(Token = "0x6001D08")]
	public FlashlightPhoton()
	{
	}

	// Token: 0x06001D09 RID: 7433 RVA: 0x00037400 File Offset: 0x00035600
	[Address(RVA = "0x34F9794", Offset = "0x34F9794", VA = "0x34F9794")]
	[Token(Token = "0x6001D09")]
	private void method_23()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D0A RID: 7434 RVA: 0x00037674 File Offset: 0x00035874
	[Address(RVA = "0x34F9808", Offset = "0x34F9808", VA = "0x34F9808")]
	[Token(Token = "0x6001D0A")]
	private void method_24()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D0B RID: 7435 RVA: 0x00037458 File Offset: 0x00035658
	[Address(RVA = "0x34F987C", Offset = "0x34F987C", VA = "0x34F987C")]
	[Token(Token = "0x6001D0B")]
	private void method_25()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D0C RID: 7436 RVA: 0x00037818 File Offset: 0x00035A18
	[Address(RVA = "0x34F98F4", Offset = "0x34F98F4", VA = "0x34F98F4")]
	[Token(Token = "0x6001D0C")]
	private void method_26()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D0D RID: 7437 RVA: 0x00037458 File Offset: 0x00035658
	[Address(RVA = "0x34F996C", Offset = "0x34F996C", VA = "0x34F996C")]
	[Token(Token = "0x6001D0D")]
	private void method_27()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D0E RID: 7438 RVA: 0x0003786C File Offset: 0x00035A6C
	[Address(RVA = "0x34F99E4", Offset = "0x34F99E4", VA = "0x34F99E4")]
	[Token(Token = "0x6001D0E")]
	private void method_28()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D0F RID: 7439 RVA: 0x00037504 File Offset: 0x00035704
	[Address(RVA = "0x34F9A58", Offset = "0x34F9A58", VA = "0x34F9A58")]
	[Token(Token = "0x6001D0F")]
	private void method_29()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D10 RID: 7440 RVA: 0x000373AC File Offset: 0x000355AC
	[Address(RVA = "0x34F9ACC", Offset = "0x34F9ACC", VA = "0x34F9ACC")]
	[Token(Token = "0x6001D10")]
	private void method_30()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D11 RID: 7441 RVA: 0x00037400 File Offset: 0x00035600
	[Address(RVA = "0x34F9B44", Offset = "0x34F9B44", VA = "0x34F9B44")]
	[Token(Token = "0x6001D11")]
	private void method_31()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D12 RID: 7442 RVA: 0x000374AC File Offset: 0x000356AC
	[Address(RVA = "0x34F9BB8", Offset = "0x34F9BB8", VA = "0x34F9BB8")]
	[Token(Token = "0x6001D12")]
	private void method_32()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D13 RID: 7443 RVA: 0x0003776C File Offset: 0x0003596C
	[Address(RVA = "0x34F9C2C", Offset = "0x34F9C2C", VA = "0x34F9C2C")]
	[Token(Token = "0x6001D13")]
	private void method_33()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D14 RID: 7444 RVA: 0x0003771C File Offset: 0x0003591C
	[Address(RVA = "0x34F9CA0", Offset = "0x34F9CA0", VA = "0x34F9CA0")]
	[Token(Token = "0x6001D14")]
	private void method_34()
	{
		long active2;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			active2 = 1L;
			return;
		}
		this.gameObject_0.SetActive(active2 != 0L);
		GameObject gameObject2 = this.gameObject_1;
		long active3 = 0L;
		gameObject2.SetActive(active3 != 0L);
	}

	// Token: 0x06001D15 RID: 7445 RVA: 0x00037818 File Offset: 0x00035A18
	[Address(RVA = "0x34F9D18", Offset = "0x34F9D18", VA = "0x34F9D18")]
	[Token(Token = "0x6001D15")]
	private void method_35()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D16 RID: 7446 RVA: 0x0003776C File Offset: 0x0003596C
	[Address(RVA = "0x34F9D90", Offset = "0x34F9D90", VA = "0x34F9D90")]
	[Token(Token = "0x6001D16")]
	private void method_36()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D17 RID: 7447 RVA: 0x000375B0 File Offset: 0x000357B0
	[Address(RVA = "0x34F9E04", Offset = "0x34F9E04", VA = "0x34F9E04")]
	[Token(Token = "0x6001D17")]
	private void method_37()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D18 RID: 7448 RVA: 0x000378C4 File Offset: 0x00035AC4
	[Address(RVA = "0x34F9E7C", Offset = "0x34F9E7C", VA = "0x34F9E7C")]
	[Token(Token = "0x6001D18")]
	private void method_38()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D19 RID: 7449 RVA: 0x00037918 File Offset: 0x00035B18
	[Address(RVA = "0x34F9EF4", Offset = "0x34F9EF4", VA = "0x34F9EF4")]
	[Token(Token = "0x6001D19")]
	private void method_39()
	{
		if (this.photonView_0 != null)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D1A RID: 7450 RVA: 0x00037604 File Offset: 0x00035804
	[Address(RVA = "0x34F9F6C", Offset = "0x34F9F6C", VA = "0x34F9F6C")]
	[Token(Token = "0x6001D1A")]
	private void method_40()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D1B RID: 7451 RVA: 0x000373AC File Offset: 0x000355AC
	[Address(RVA = "0x34F9FE4", Offset = "0x34F9FE4", VA = "0x34F9FE4")]
	[Token(Token = "0x6001D1B")]
	private void method_41()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D1C RID: 7452 RVA: 0x00037458 File Offset: 0x00035658
	[Address(RVA = "0x34FA05C", Offset = "0x34FA05C", VA = "0x34FA05C")]
	[Token(Token = "0x6001D1C")]
	private void method_42()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D1D RID: 7453 RVA: 0x000377C4 File Offset: 0x000359C4
	[Address(RVA = "0x34FA0D4", Offset = "0x34FA0D4", VA = "0x34FA0D4")]
	[Token(Token = "0x6001D1D")]
	private void method_43()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D1E RID: 7454 RVA: 0x00037674 File Offset: 0x00035874
	[Address(RVA = "0x34FA14C", Offset = "0x34FA14C", VA = "0x34FA14C")]
	[Token(Token = "0x6001D1E")]
	private void method_44()
	{
		GameObject gameObject3;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.gameObject_0 == null)
			{
				return;
			}
		}
		else
		{
			GameObject gameObject2 = this.gameObject_0;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			gameObject3 = this.gameObject_1;
		}
		long active3 = 0L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D1F RID: 7455 RVA: 0x00037818 File Offset: 0x00035A18
	[Address(RVA = "0x34FA1C0", Offset = "0x34FA1C0", VA = "0x34FA1C0")]
	[Token(Token = "0x6001D1F")]
	private void method_45()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x06001D20 RID: 7456 RVA: 0x000378C4 File Offset: 0x00035AC4
	[Address(RVA = "0x34FA238", Offset = "0x34FA238", VA = "0x34FA238")]
	[Token(Token = "0x6001D20")]
	private void method_46()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			return;
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
		GameObject gameObject3 = this.gameObject_1;
		long active3 = 1L;
		gameObject3.SetActive(active3 != 0L);
	}

	// Token: 0x040003E8 RID: 1000
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003E8")]
	public GameObject gameObject_0;

	// Token: 0x040003E9 RID: 1001
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40003E9")]
	public GameObject gameObject_1;

	// Token: 0x040003EA RID: 1002
	[Token(Token = "0x40003EA")]
	[FieldOffset(Offset = "0x28")]
	public PhotonView photonView_0;
}
