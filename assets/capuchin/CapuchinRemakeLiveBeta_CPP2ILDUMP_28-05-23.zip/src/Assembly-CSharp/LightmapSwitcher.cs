﻿using System;
using System.Collections.Generic;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000031 RID: 49
[Token(Token = "0x2000031")]
public class LightmapSwitcher : MonoBehaviour
{
	// Token: 0x060005B5 RID: 1461 RVA: 0x0000F71C File Offset: 0x0000D91C
	[Address(RVA = "0x2D8F7DC", Offset = "0x2D8F7DC", VA = "0x2D8F7DC")]
	[Token(Token = "0x60005B5")]
	private void method_0()
	{
		long int_ = 0L;
		this.method_47((int)int_);
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x0000F734 File Offset: 0x0000D934
	[Address(RVA = "0x2D8F92C", Offset = "0x2D8F92C", VA = "0x2D8F92C")]
	[Token(Token = "0x60005B6")]
	private void method_1()
	{
		long int_ = 1L;
		this.method_68((int)int_);
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Token(Token = "0x60005B7")]
	[Address(RVA = "0x2D8FA7C", Offset = "0x2D8FA7C", VA = "0x2D8FA7C")]
	private void method_2(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D8FBC4", Offset = "0x2D8FBC4", VA = "0x2D8FBC4")]
	[Token(Token = "0x60005B8")]
	private void method_3()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D8FD7C", Offset = "0x2D8FD7C", VA = "0x2D8FD7C")]
	[Token(Token = "0x60005B9")]
	private void method_4(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x60005BA")]
	[Address(RVA = "0x2D8FEA4", Offset = "0x2D8FEA4", VA = "0x2D8FEA4")]
	private void method_5(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Address(RVA = "0x2D8FFCC", Offset = "0x2D8FFCC", VA = "0x2D8FFCC")]
	[Token(Token = "0x60005BB")]
	private void method_6(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D90114", Offset = "0x2D90114", VA = "0x2D90114")]
	[Token(Token = "0x60005BC")]
	private void method_7(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x60005BD")]
	[Address(RVA = "0x2D9023C", Offset = "0x2D9023C", VA = "0x2D9023C")]
	private void method_8(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x0000F780 File Offset: 0x0000D980
	[Token(Token = "0x60005BE")]
	[Address(RVA = "0x2D90364", Offset = "0x2D90364", VA = "0x2D90364")]
	private void method_9()
	{
		long int_ = 1L;
		this.method_67((int)int_);
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x60005BF")]
	[Address(RVA = "0x2D90494", Offset = "0x2D90494", VA = "0x2D90494")]
	private void method_10()
	{
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x0000F71C File Offset: 0x0000D91C
	[Address(RVA = "0x2D90504", Offset = "0x2D90504", VA = "0x2D90504")]
	[Token(Token = "0x60005C0")]
	private void method_11()
	{
		long int_ = 0L;
		this.method_47((int)int_);
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x0000F7A8 File Offset: 0x0000D9A8
	[Address(RVA = "0x2D9050C", Offset = "0x2D9050C", VA = "0x2D9050C")]
	[Token(Token = "0x60005C1")]
	private void method_12()
	{
		long int_ = 1L;
		this.method_74((int)int_);
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x0000F7C0 File Offset: 0x0000D9C0
	[Address(RVA = "0x2D90638", Offset = "0x2D90638", VA = "0x2D90638")]
	[Token(Token = "0x60005C2")]
	private void method_13()
	{
		long int_ = 1L;
		this.method_92((int)int_);
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x60005C3")]
	[Address(RVA = "0x2D90768", Offset = "0x2D90768", VA = "0x2D90768")]
	private void method_14(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D90890", Offset = "0x2D90890", VA = "0x2D90890")]
	[Token(Token = "0x60005C4")]
	private void method_15()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005C5 RID: 1477 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x60005C5")]
	[Address(RVA = "0x2D90A24", Offset = "0x2D90A24", VA = "0x2D90A24")]
	private void method_16(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005C6 RID: 1478 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D90B4C", Offset = "0x2D90B4C", VA = "0x2D90B4C")]
	[Token(Token = "0x60005C6")]
	private void method_17()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005C7 RID: 1479 RVA: 0x0000F7F8 File Offset: 0x0000D9F8
	[Token(Token = "0x60005C7")]
	[Address(RVA = "0x2D90BBC", Offset = "0x2D90BBC", VA = "0x2D90BBC")]
	private void method_18()
	{
		long int_ = 0L;
		this.method_74((int)int_);
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x0000F810 File Offset: 0x0000DA10
	[Address(RVA = "0x2D90BC4", Offset = "0x2D90BC4", VA = "0x2D90BC4")]
	[Token(Token = "0x60005C8")]
	private void method_19()
	{
		long int_ = 0L;
		this.method_82((int)int_);
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x0000F7A8 File Offset: 0x0000D9A8
	[Address(RVA = "0x2D90CF4", Offset = "0x2D90CF4", VA = "0x2D90CF4")]
	[Token(Token = "0x60005C9")]
	private void method_20()
	{
		long int_ = 1L;
		this.method_74((int)int_);
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x0000F828 File Offset: 0x0000DA28
	[Address(RVA = "0x2D90CFC", Offset = "0x2D90CFC", VA = "0x2D90CFC")]
	[Token(Token = "0x60005CA")]
	private void method_21()
	{
		long int_ = 0L;
		this.method_14((int)int_);
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D90D04", Offset = "0x2D90D04", VA = "0x2D90D04")]
	[Token(Token = "0x60005CB")]
	private void method_22()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Address(RVA = "0x2D90E9C", Offset = "0x2D90E9C", VA = "0x2D90E9C")]
	[Token(Token = "0x60005CC")]
	private void method_23(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D90FE4", Offset = "0x2D90FE4", VA = "0x2D90FE4")]
	[Token(Token = "0x60005CD")]
	private void method_24()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2D91054", Offset = "0x2D91054", VA = "0x2D91054")]
	[Token(Token = "0x60005CE")]
	private void method_25()
	{
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x0000F7F8 File Offset: 0x0000D9F8
	[Token(Token = "0x60005CF")]
	[Address(RVA = "0x2D910C4", Offset = "0x2D910C4", VA = "0x2D910C4")]
	private void method_26()
	{
		long int_ = 0L;
		this.method_74((int)int_);
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x0000F840 File Offset: 0x0000DA40
	[Token(Token = "0x60005D0")]
	[Address(RVA = "0x2D910CC", Offset = "0x2D910CC", VA = "0x2D910CC")]
	private void method_27()
	{
		long int_ = 0L;
		this.method_54((int)int_);
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x0000F858 File Offset: 0x0000DA58
	[Token(Token = "0x60005D1")]
	[Address(RVA = "0x2D911FC", Offset = "0x2D911FC", VA = "0x2D911FC")]
	private void method_28()
	{
		long int_ = 0L;
		this.method_5((int)int_);
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x60005D2")]
	[Address(RVA = "0x2D91204", Offset = "0x2D91204", VA = "0x2D91204")]
	private void method_29()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D913B8", Offset = "0x2D913B8", VA = "0x2D913B8")]
	[Token(Token = "0x60005D3")]
	private void method_30(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x0000F870 File Offset: 0x0000DA70
	[Token(Token = "0x60005D4")]
	[Address(RVA = "0x2D914E0", Offset = "0x2D914E0", VA = "0x2D914E0")]
	private void method_31()
	{
		long int_ = 0L;
		this.method_78((int)int_);
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D914E8", Offset = "0x2D914E8", VA = "0x2D914E8")]
	[Token(Token = "0x60005D5")]
	private void method_32()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x0000F888 File Offset: 0x0000DA88
	[Token(Token = "0x60005D6")]
	[Address(RVA = "0x2D9167C", Offset = "0x2D9167C", VA = "0x2D9167C")]
	private void method_33()
	{
		long int_ = 0L;
		this.method_72((int)int_);
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D91684", Offset = "0x2D91684", VA = "0x2D91684")]
	[Token(Token = "0x60005D7")]
	private void method_34()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Address(RVA = "0x2D90D78", Offset = "0x2D90D78", VA = "0x2D90D78")]
	[Token(Token = "0x60005D8")]
	private void method_35(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D916F8", Offset = "0x2D916F8", VA = "0x2D916F8")]
	[Token(Token = "0x60005D9")]
	private void method_36(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D91820", Offset = "0x2D91820", VA = "0x2D91820")]
	[Token(Token = "0x60005DA")]
	private void method_37()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D919B4", Offset = "0x2D919B4", VA = "0x2D919B4")]
	[Token(Token = "0x60005DB")]
	private void method_38()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005DC RID: 1500 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x60005DC")]
	[Address(RVA = "0x2D91B6C", Offset = "0x2D91B6C", VA = "0x2D91B6C")]
	private void method_39()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x0000F8A0 File Offset: 0x0000DAA0
	[Address(RVA = "0x2D91BDC", Offset = "0x2D91BDC", VA = "0x2D91BDC")]
	[Token(Token = "0x60005DD")]
	private void method_40()
	{
		long int_ = 1L;
		this.method_82((int)int_);
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D91BE4", Offset = "0x2D91BE4", VA = "0x2D91BE4")]
	[Token(Token = "0x60005DE")]
	private void method_41()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005DF RID: 1503 RVA: 0x0000F8B8 File Offset: 0x0000DAB8
	[Address(RVA = "0x2D91C54", Offset = "0x2D91C54", VA = "0x2D91C54")]
	[Token(Token = "0x60005DF")]
	private void method_42()
	{
		long int_ = 1L;
		this.method_6((int)int_);
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Address(RVA = "0x2D91270", Offset = "0x2D91270", VA = "0x2D91270")]
	[Token(Token = "0x60005E0")]
	private void method_43(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005E1 RID: 1505 RVA: 0x0000F8D0 File Offset: 0x0000DAD0
	[Token(Token = "0x60005E1")]
	[Address(RVA = "0x2D91C5C", Offset = "0x2D91C5C", VA = "0x2D91C5C")]
	private void method_44()
	{
		long int_ = 1L;
		this.method_35((int)int_);
	}

	// Token: 0x060005E2 RID: 1506 RVA: 0x0000F840 File Offset: 0x0000DA40
	[Address(RVA = "0x2D91C64", Offset = "0x2D91C64", VA = "0x2D91C64")]
	[Token(Token = "0x60005E2")]
	private void method_45()
	{
		long int_ = 0L;
		this.method_54((int)int_);
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D91C6C", Offset = "0x2D91C6C", VA = "0x2D91C6C")]
	[Token(Token = "0x60005E3")]
	private void method_46(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Token(Token = "0x60005E4")]
	[Address(RVA = "0x2D8F7E4", Offset = "0x2D8F7E4", VA = "0x2D8F7E4")]
	private void method_47(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005E5 RID: 1509 RVA: 0x0000F734 File Offset: 0x0000D934
	[Token(Token = "0x60005E5")]
	[Address(RVA = "0x2D91D94", Offset = "0x2D91D94", VA = "0x2D91D94")]
	private void method_48()
	{
		long int_ = 1L;
		this.method_68((int)int_);
	}

	// Token: 0x060005E6 RID: 1510 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x60005E6")]
	[Address(RVA = "0x2D91D9C", Offset = "0x2D91D9C", VA = "0x2D91D9C")]
	private void method_49()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005E7 RID: 1511 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x60005E7")]
	[Address(RVA = "0x2D91E08", Offset = "0x2D91E08", VA = "0x2D91E08")]
	private void method_50()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005E8 RID: 1512 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D91E78", Offset = "0x2D91E78", VA = "0x2D91E78")]
	[Token(Token = "0x60005E8")]
	private void method_51()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D92010", Offset = "0x2D92010", VA = "0x2D92010")]
	[Token(Token = "0x60005E9")]
	private void method_52()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005EA RID: 1514 RVA: 0x0000F8E8 File Offset: 0x0000DAE8
	[Address(RVA = "0x2D9207C", Offset = "0x2D9207C", VA = "0x2D9207C")]
	[Token(Token = "0x60005EA")]
	private void method_53()
	{
		long int_ = 1L;
		this.method_5((int)int_);
	}

	// Token: 0x060005EB RID: 1515 RVA: 0x0000F900 File Offset: 0x0000DB00
	[Token(Token = "0x60005EB")]
	[Address(RVA = "0x2D910D4", Offset = "0x2D910D4", VA = "0x2D910D4")]
	private void method_54(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>();
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x0000F914 File Offset: 0x0000DB14
	[Token(Token = "0x60005EC")]
	[Address(RVA = "0x2D92084", Offset = "0x2D92084", VA = "0x2D92084")]
	private void method_55()
	{
		long int_ = 0L;
		this.method_46((int)int_);
	}

	// Token: 0x060005ED RID: 1517 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x60005ED")]
	[Address(RVA = "0x2D9208C", Offset = "0x2D9208C", VA = "0x2D9208C")]
	private void method_56()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005EE RID: 1518 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D91554", Offset = "0x2D91554", VA = "0x2D91554")]
	[Token(Token = "0x60005EE")]
	private void method_57(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005EF RID: 1519 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D920F8", Offset = "0x2D920F8", VA = "0x2D920F8")]
	[Token(Token = "0x60005EF")]
	private void method_58(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x60005F0")]
	[Address(RVA = "0x2D9188C", Offset = "0x2D9188C", VA = "0x2D9188C")]
	private void method_59(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D92220", Offset = "0x2D92220", VA = "0x2D92220")]
	[Token(Token = "0x60005F1")]
	private void Update()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x0000F7F8 File Offset: 0x0000D9F8
	[Address(RVA = "0x2D92290", Offset = "0x2D92290", VA = "0x2D92290")]
	[Token(Token = "0x60005F2")]
	private void method_60()
	{
		long int_ = 0L;
		this.method_74((int)int_);
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x0000F92C File Offset: 0x0000DB2C
	[Token(Token = "0x60005F3")]
	[Address(RVA = "0x2D92298", Offset = "0x2D92298", VA = "0x2D92298")]
	private void method_61()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x0000F94C File Offset: 0x0000DB4C
	[Token(Token = "0x60005F4")]
	[Address(RVA = "0x2D92308", Offset = "0x2D92308", VA = "0x2D92308")]
	private void method_62()
	{
		long int_ = 1L;
		this.method_7((int)int_);
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D92310", Offset = "0x2D92310", VA = "0x2D92310")]
	[Token(Token = "0x60005F5")]
	private void method_63()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Token(Token = "0x60005F6")]
	[Address(RVA = "0x2D92384", Offset = "0x2D92384", VA = "0x2D92384")]
	private void method_64()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x60005F7")]
	[Address(RVA = "0x2D923F4", Offset = "0x2D923F4", VA = "0x2D923F4")]
	private void method_65()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x60005F8")]
	[Address(RVA = "0x2D91EE8", Offset = "0x2D91EE8", VA = "0x2D91EE8")]
	private void method_66(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x60005F9")]
	[Address(RVA = "0x2D9036C", Offset = "0x2D9036C", VA = "0x2D9036C")]
	private void method_67(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Token(Token = "0x60005FA")]
	[Address(RVA = "0x2D8F934", Offset = "0x2D8F934", VA = "0x2D8F934")]
	private void method_68(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D92464", Offset = "0x2D92464", VA = "0x2D92464")]
	[Token(Token = "0x60005FB")]
	private void method_69()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Address(RVA = "0x2D91A24", Offset = "0x2D91A24", VA = "0x2D91A24")]
	[Token(Token = "0x60005FC")]
	private void method_70(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D924D8", Offset = "0x2D924D8", VA = "0x2D924D8")]
	[Token(Token = "0x60005FD")]
	private void method_71()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Address(RVA = "0x2D8FC34", Offset = "0x2D8FC34", VA = "0x2D8FC34")]
	[Token(Token = "0x60005FE")]
	private void method_72(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x0000F768 File Offset: 0x0000D968
	[Address(RVA = "0x2D92544", Offset = "0x2D92544", VA = "0x2D92544")]
	[Token(Token = "0x60005FF")]
	private void method_73()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x6000600")]
	[Address(RVA = "0x2D90514", Offset = "0x2D90514", VA = "0x2D90514")]
	private void method_74(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x0000F858 File Offset: 0x0000DA58
	[Token(Token = "0x6000601")]
	[Address(RVA = "0x2D925B0", Offset = "0x2D925B0", VA = "0x2D925B0")]
	private void method_75()
	{
		long int_ = 0L;
		this.method_5((int)int_);
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x6000602")]
	[Address(RVA = "0x2D925B8", Offset = "0x2D925B8", VA = "0x2D925B8")]
	private void method_76()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2D92624", Offset = "0x2D92624", VA = "0x2D92624")]
	[Token(Token = "0x6000603")]
	public LightmapSwitcher()
	{
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D9262C", Offset = "0x2D9262C", VA = "0x2D9262C")]
	[Token(Token = "0x6000604")]
	private void method_77()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D90900", Offset = "0x2D90900", VA = "0x2D90900")]
	[Token(Token = "0x6000605")]
	private void method_78(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x0000F964 File Offset: 0x0000DB64
	[Address(RVA = "0x2D9269C", Offset = "0x2D9269C", VA = "0x2D9269C")]
	[Token(Token = "0x6000606")]
	private void method_79()
	{
		long int_ = 1L;
		this.method_14((int)int_);
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Token(Token = "0x6000607")]
	[Address(RVA = "0x2D926A4", Offset = "0x2D926A4", VA = "0x2D926A4")]
	private void method_80(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x0000F97C File Offset: 0x0000DB7C
	[Token(Token = "0x6000608")]
	[Address(RVA = "0x2D927EC", Offset = "0x2D927EC", VA = "0x2D927EC")]
	private void Start()
	{
		long int_ = 0L;
		this.method_35((int)int_);
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x0000F858 File Offset: 0x0000DA58
	[Token(Token = "0x6000609")]
	[Address(RVA = "0x2D927F4", Offset = "0x2D927F4", VA = "0x2D927F4")]
	private void method_81()
	{
		long int_ = 0L;
		this.method_5((int)int_);
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x0000215E File Offset: 0x0000035E
	[Token(Token = "0x600060A")]
	[Address(RVA = "0x2D90BCC", Offset = "0x2D90BCC", VA = "0x2D90BCC")]
	private void method_82(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x0000F994 File Offset: 0x0000DB94
	[Address(RVA = "0x2D927FC", Offset = "0x2D927FC", VA = "0x2D927FC")]
	[Token(Token = "0x600060B")]
	private void method_83()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x0600060C RID: 1548 RVA: 0x0000F9B4 File Offset: 0x0000DBB4
	[Token(Token = "0x600060C")]
	[Address(RVA = "0x2D9286C", Offset = "0x2D9286C", VA = "0x2D9286C")]
	private void method_84()
	{
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D928D8", Offset = "0x2D928D8", VA = "0x2D928D8")]
	[Token(Token = "0x600060D")]
	private void method_85()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x0000F768 File Offset: 0x0000D968
	[Token(Token = "0x600060E")]
	[Address(RVA = "0x2D92948", Offset = "0x2D92948", VA = "0x2D92948")]
	private void method_86()
	{
		if (!this.bool_0)
		{
		}
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x0000F9C4 File Offset: 0x0000DBC4
	[Address(RVA = "0x2D929B8", Offset = "0x2D929B8", VA = "0x2D929B8")]
	[Token(Token = "0x600060F")]
	private void method_87()
	{
		long int_ = 0L;
		this.method_57((int)int_);
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D929C0", Offset = "0x2D929C0", VA = "0x2D929C0")]
	[Token(Token = "0x6000610")]
	private void method_88()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x0000F94C File Offset: 0x0000DB4C
	[Token(Token = "0x6000611")]
	[Address(RVA = "0x2D92A30", Offset = "0x2D92A30", VA = "0x2D92A30")]
	private void method_89()
	{
		long int_ = 1L;
		this.method_7((int)int_);
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x0000F7D8 File Offset: 0x0000D9D8
	[Address(RVA = "0x2D92A38", Offset = "0x2D92A38", VA = "0x2D92A38")]
	[Token(Token = "0x6000612")]
	private void method_90()
	{
		if (this.bool_0)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
		}
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x0000F9DC File Offset: 0x0000DBDC
	[Address(RVA = "0x2D92AAC", Offset = "0x2D92AAC", VA = "0x2D92AAC")]
	[Token(Token = "0x6000613")]
	private void method_91()
	{
		long int_ = 1L;
		this.method_54((int)int_);
	}

	// Token: 0x06000614 RID: 1556 RVA: 0x0000215E File Offset: 0x0000035E
	[Address(RVA = "0x2D90640", Offset = "0x2D90640", VA = "0x2D90640")]
	[Token(Token = "0x6000614")]
	private void method_92(int int_1)
	{
		UnityEngine.Object.FindObjectsOfType<Renderer>().lightmapIndex = int_1;
	}

	// Token: 0x06000615 RID: 1557 RVA: 0x0000F74C File Offset: 0x0000D94C
	[Token(Token = "0x6000615")]
	[Address(RVA = "0x2D92AB4", Offset = "0x2D92AB4", VA = "0x2D92AB4")]
	private void method_93(int int_1)
	{
		Renderer[] array = UnityEngine.Object.FindObjectsOfType<Renderer>();
		array.lightmapIndex = int_1;
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x0000F7A8 File Offset: 0x0000D9A8
	[Address(RVA = "0x2D92BFC", Offset = "0x2D92BFC", VA = "0x2D92BFC")]
	[Token(Token = "0x6000616")]
	private void method_94()
	{
		long int_ = 1L;
		this.method_74((int)int_);
	}

	// Token: 0x040000DF RID: 223
	[Token(Token = "0x40000DF")]
	[FieldOffset(Offset = "0x18")]
	public List<Texture2D> list_0;

	// Token: 0x040000E0 RID: 224
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000E0")]
	private int int_0;

	// Token: 0x040000E1 RID: 225
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40000E1")]
	public bool bool_0;
}
