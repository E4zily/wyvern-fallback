﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E0 RID: 224
[Token(Token = "0x20000E0")]
public class HandColliders : MonoBehaviour
{
	// Token: 0x0600216E RID: 8558 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3508F40", Offset = "0x3508F40", VA = "0x3508F40")]
	[Token(Token = "0x600216E")]
	public HandColliders()
	{
	}

	// Token: 0x0400046F RID: 1135
	[Token(Token = "0x400046F")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;
}
