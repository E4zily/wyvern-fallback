﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D9 RID: 217
[Token(Token = "0x20000D9")]
public class LookAT : MonoBehaviour
{
	// Token: 0x06002040 RID: 8256 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427924", Offset = "0x2427924", VA = "0x2427924")]
	[Token(Token = "0x6002040")]
	private void method_0()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002041 RID: 8257 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427990", Offset = "0x2427990", VA = "0x2427990")]
	[Token(Token = "0x6002041")]
	private void method_1()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002042 RID: 8258 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24279FC", Offset = "0x24279FC", VA = "0x24279FC")]
	[Token(Token = "0x6002042")]
	private void method_2()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002043 RID: 8259 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427A68", Offset = "0x2427A68", VA = "0x2427A68")]
	[Token(Token = "0x6002043")]
	private void method_3()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002044 RID: 8260 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427AD4", Offset = "0x2427AD4", VA = "0x2427AD4")]
	[Token(Token = "0x6002044")]
	private void method_4()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002045 RID: 8261 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427B40", Offset = "0x2427B40", VA = "0x2427B40")]
	[Token(Token = "0x6002045")]
	private void method_5()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002046 RID: 8262 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427BAC", Offset = "0x2427BAC", VA = "0x2427BAC")]
	[Token(Token = "0x6002046")]
	private void method_6()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002047 RID: 8263 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427C18", Offset = "0x2427C18", VA = "0x2427C18")]
	[Token(Token = "0x6002047")]
	private void method_7()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002048 RID: 8264 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427C84", Offset = "0x2427C84", VA = "0x2427C84")]
	[Token(Token = "0x6002048")]
	private void method_8()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002049 RID: 8265 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427CF0", Offset = "0x2427CF0", VA = "0x2427CF0")]
	[Token(Token = "0x6002049")]
	private void method_9()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600204A RID: 8266 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427D5C", Offset = "0x2427D5C", VA = "0x2427D5C")]
	[Token(Token = "0x600204A")]
	private void method_10()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600204B RID: 8267 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427DC8", Offset = "0x2427DC8", VA = "0x2427DC8")]
	[Token(Token = "0x600204B")]
	private void method_11()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600204C RID: 8268 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427E34", Offset = "0x2427E34", VA = "0x2427E34")]
	[Token(Token = "0x600204C")]
	private void method_12()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600204D RID: 8269 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427EA0", Offset = "0x2427EA0", VA = "0x2427EA0")]
	[Token(Token = "0x600204D")]
	private void method_13()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600204E RID: 8270 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427F0C", Offset = "0x2427F0C", VA = "0x2427F0C")]
	[Token(Token = "0x600204E")]
	private void method_14()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600204F RID: 8271 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427F78", Offset = "0x2427F78", VA = "0x2427F78")]
	[Token(Token = "0x600204F")]
	private void method_15()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002050 RID: 8272 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2427FE4", Offset = "0x2427FE4", VA = "0x2427FE4")]
	[Token(Token = "0x6002050")]
	private void method_16()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002051 RID: 8273 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428050", Offset = "0x2428050", VA = "0x2428050")]
	[Token(Token = "0x6002051")]
	private void method_17()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002052 RID: 8274 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24280BC", Offset = "0x24280BC", VA = "0x24280BC")]
	[Token(Token = "0x6002052")]
	private void method_18()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002053 RID: 8275 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428128", Offset = "0x2428128", VA = "0x2428128")]
	[Token(Token = "0x6002053")]
	private void method_19()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002054 RID: 8276 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428194", Offset = "0x2428194", VA = "0x2428194")]
	[Token(Token = "0x6002054")]
	private void method_20()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002055 RID: 8277 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428200", Offset = "0x2428200", VA = "0x2428200")]
	[Token(Token = "0x6002055")]
	private void method_21()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002056 RID: 8278 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x242826C", Offset = "0x242826C", VA = "0x242826C")]
	[Token(Token = "0x6002056")]
	private void method_22()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002057 RID: 8279 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24282D8", Offset = "0x24282D8", VA = "0x24282D8")]
	[Token(Token = "0x6002057")]
	private void method_23()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002058 RID: 8280 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428344", Offset = "0x2428344", VA = "0x2428344")]
	[Token(Token = "0x6002058")]
	private void method_24()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002059 RID: 8281 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24283B0", Offset = "0x24283B0", VA = "0x24283B0")]
	[Token(Token = "0x6002059")]
	private void method_25()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600205A RID: 8282 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x242841C", Offset = "0x242841C", VA = "0x242841C")]
	[Token(Token = "0x600205A")]
	private void Update()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600205B RID: 8283 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428488", Offset = "0x2428488", VA = "0x2428488")]
	[Token(Token = "0x600205B")]
	private void method_26()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600205C RID: 8284 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24284F4", Offset = "0x24284F4", VA = "0x24284F4")]
	[Token(Token = "0x600205C")]
	private void method_27()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600205D RID: 8285 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428560", Offset = "0x2428560", VA = "0x2428560")]
	[Token(Token = "0x600205D")]
	private void method_28()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600205E RID: 8286 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24285CC", Offset = "0x24285CC", VA = "0x24285CC")]
	[Token(Token = "0x600205E")]
	private void method_29()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0600205F RID: 8287 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428638", Offset = "0x2428638", VA = "0x2428638")]
	[Token(Token = "0x600205F")]
	private void method_30()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002060 RID: 8288 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24286A4", Offset = "0x24286A4", VA = "0x24286A4")]
	[Token(Token = "0x6002060")]
	private void method_31()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002061 RID: 8289 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428710", Offset = "0x2428710", VA = "0x2428710")]
	[Token(Token = "0x6002061")]
	private void method_32()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002062 RID: 8290 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x242877C", Offset = "0x242877C", VA = "0x242877C")]
	[Token(Token = "0x6002062")]
	public LookAT()
	{
	}

	// Token: 0x06002063 RID: 8291 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428784", Offset = "0x2428784", VA = "0x2428784")]
	[Token(Token = "0x6002063")]
	private void method_33()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002064 RID: 8292 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24287F0", Offset = "0x24287F0", VA = "0x24287F0")]
	[Token(Token = "0x6002064")]
	private void method_34()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002065 RID: 8293 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x242885C", Offset = "0x242885C", VA = "0x242885C")]
	[Token(Token = "0x6002065")]
	private void method_35()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002066 RID: 8294 RVA: 0x0003C7F8 File Offset: 0x0003A9F8
	[Address(RVA = "0x24288C8", Offset = "0x24288C8", VA = "0x24288C8")]
	[Token(Token = "0x6002066")]
	private void method_36()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002067 RID: 8295 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428934", Offset = "0x2428934", VA = "0x2428934")]
	[Token(Token = "0x6002067")]
	private void method_37()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002068 RID: 8296 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x24289A0", Offset = "0x24289A0", VA = "0x24289A0")]
	[Token(Token = "0x6002068")]
	private void method_38()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x06002069 RID: 8297 RVA: 0x0003C7C8 File Offset: 0x0003A9C8
	[Address(RVA = "0x2428A0C", Offset = "0x2428A0C", VA = "0x2428A0C")]
	[Token(Token = "0x6002069")]
	private void method_39()
	{
		Transform transform = base.transform;
		Transform target = this.transform_0;
		transform.LookAt(target);
		Quaternion rotation = base.transform.rotation;
	}

	// Token: 0x0400044D RID: 1101
	[Token(Token = "0x400044D")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x0400044E RID: 1102
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400044E")]
	public Quaternion quaternion_0;
}
