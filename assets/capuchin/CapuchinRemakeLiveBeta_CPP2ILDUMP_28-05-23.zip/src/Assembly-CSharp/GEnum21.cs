﻿using System;
using Cpp2IlInjected;

// Token: 0x02000165 RID: 357
[Token(Token = "0x2000165")]
public enum GEnum21
{
	// Token: 0x04000963 RID: 2403
	[Token(Token = "0x4000963")]
	const_0,
	// Token: 0x04000964 RID: 2404
	[Token(Token = "0x4000964")]
	const_1,
	// Token: 0x04000965 RID: 2405
	[Token(Token = "0x4000965")]
	const_2,
	// Token: 0x04000966 RID: 2406
	[Token(Token = "0x4000966")]
	const_3
}
