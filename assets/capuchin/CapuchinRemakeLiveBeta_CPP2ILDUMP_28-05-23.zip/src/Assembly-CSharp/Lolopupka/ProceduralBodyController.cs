﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000179 RID: 377
	[Token(Token = "0x2000179")]
	public class ProceduralBodyController : MonoBehaviour
	{
		// Token: 0x060039BF RID: 14783 RVA: 0x00072D3C File Offset: 0x00070F3C
		[Token(Token = "0x60039BF")]
		[Address(RVA = "0x2A7E07C", Offset = "0x2A7E07C", VA = "0x2A7E07C")]
		private void method_0()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.smartBodyPosition)
			{
				this.method_50();
				this.method_73();
				this.method_80();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			this.method_73();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060039C0 RID: 14784 RVA: 0x00072DE8 File Offset: 0x00070FE8
		[Token(Token = "0x60039C0")]
		[Address(RVA = "0x2A7E4B0", Offset = "0x2A7E4B0", VA = "0x2A7E4B0")]
		private void method_1()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.smartBodyPosition)
			{
				this.method_80();
				this.method_47();
				this.method_88();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			this.method_69();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			Transform transform3 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060039C1 RID: 14785 RVA: 0x00003639 File Offset: 0x00001839
		[Address(RVA = "0x2A7E85C", Offset = "0x2A7E85C", VA = "0x2A7E85C")]
		[Token(Token = "0x60039C1")]
		private void method_2()
		{
			this.method_18();
			if (this.bodyOrientation)
			{
				this.method_81();
				return;
			}
		}

		// Token: 0x060039C2 RID: 14786 RVA: 0x00072E8C File Offset: 0x0007108C
		[Token(Token = "0x60039C2")]
		[Address(RVA = "0x2A7EDE8", Offset = "0x2A7EDE8", VA = "0x2A7EDE8")]
		private void method_3()
		{
			proceduralAnimation proceduralAnimation = this.proceduralAnimation;
			Transform[] legIktargets = proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
			float stepDistance = proceduralAnimation.stepDistance;
			this.int_0 = (int)stepDistance;
		}

		// Token: 0x060039C3 RID: 14787 RVA: 0x00072EBC File Offset: 0x000710BC
		[Token(Token = "0x60039C3")]
		[Address(RVA = "0x2A7EE34", Offset = "0x2A7EE34", VA = "0x2A7EE34")]
		private void method_4()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039C4 RID: 14788 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A7EE80", Offset = "0x2A7EE80", VA = "0x2A7EE80")]
		[Token(Token = "0x60039C4")]
		private void method_5()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039C5 RID: 14789 RVA: 0x00072F08 File Offset: 0x00071108
		[Address(RVA = "0x2A7EECC", Offset = "0x2A7EECC", VA = "0x2A7EECC")]
		[Token(Token = "0x60039C5")]
		private void method_6()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			Transform transform;
			Vector3 forward = transform.forward;
			Transform transform2;
			Quaternion rotation = transform2.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = transform2.transform.up;
		}

		// Token: 0x060039C6 RID: 14790 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A7F214", Offset = "0x2A7F214", VA = "0x2A7F214")]
		[Token(Token = "0x60039C6")]
		private void Start()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039C7 RID: 14791 RVA: 0x00072F64 File Offset: 0x00071164
		[Address(RVA = "0x2A7F260", Offset = "0x2A7F260", VA = "0x2A7F260")]
		[Token(Token = "0x60039C7")]
		private void OnDrawGizmosSelected()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039C8 RID: 14792 RVA: 0x00003650 File Offset: 0x00001850
		[Address(RVA = "0x2A7F3D4", Offset = "0x2A7F3D4", VA = "0x2A7F3D4")]
		[Token(Token = "0x60039C8")]
		private void method_7()
		{
			this.method_1();
			this.method_79();
		}

		// Token: 0x060039C9 RID: 14793 RVA: 0x00072FA4 File Offset: 0x000711A4
		[Address(RVA = "0x2A7F6C4", Offset = "0x2A7F6C4", VA = "0x2A7F6C4")]
		[Token(Token = "0x60039C9")]
		private float method_8()
		{
			this.proceduralAnimation.method_5();
			throw new NullReferenceException();
		}

		// Token: 0x060039CA RID: 14794 RVA: 0x00072FC4 File Offset: 0x000711C4
		[Address(RVA = "0x2A7F6FC", Offset = "0x2A7F6FC", VA = "0x2A7F6FC")]
		[Token(Token = "0x60039CA")]
		private void method_9()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x060039CB RID: 14795 RVA: 0x0000365E File Offset: 0x0000185E
		[Address(RVA = "0x2A7F9B4", Offset = "0x2A7F9B4", VA = "0x2A7F9B4")]
		[Token(Token = "0x60039CB")]
		private void method_10()
		{
			this.method_0();
			if (this.bodyOrientation)
			{
				this.method_29();
				return;
			}
		}

		// Token: 0x060039CC RID: 14796 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A7FCA0", Offset = "0x2A7FCA0", VA = "0x2A7FCA0")]
		[Token(Token = "0x60039CC")]
		private void method_11()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039CD RID: 14797 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A7FCEC", Offset = "0x2A7FCEC", VA = "0x2A7FCEC")]
		[Token(Token = "0x60039CD")]
		private void method_12()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039CE RID: 14798 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A7FD38", Offset = "0x2A7FD38", VA = "0x2A7FD38")]
		[Token(Token = "0x60039CE")]
		private void Awake()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039CF RID: 14799 RVA: 0x00072F64 File Offset: 0x00071164
		[Address(RVA = "0x2A7FD84", Offset = "0x2A7FD84", VA = "0x2A7FD84")]
		[Token(Token = "0x60039CF")]
		private void method_13()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039D0 RID: 14800 RVA: 0x00073048 File Offset: 0x00071248
		[Address(RVA = "0x2A7FEF8", Offset = "0x2A7FEF8", VA = "0x2A7FEF8")]
		[Token(Token = "0x60039D0")]
		private float method_14()
		{
			this.proceduralAnimation.method_7();
			throw new NullReferenceException();
		}

		// Token: 0x060039D1 RID: 14801 RVA: 0x00003675 File Offset: 0x00001875
		[Address(RVA = "0x2A7FF30", Offset = "0x2A7FF30", VA = "0x2A7FF30")]
		[Token(Token = "0x60039D1")]
		private void method_15()
		{
			this.method_30();
			if (this.bodyOrientation)
			{
				this.method_29();
				return;
			}
		}

		// Token: 0x060039D2 RID: 14802 RVA: 0x00073068 File Offset: 0x00071268
		[Address(RVA = "0x2A80204", Offset = "0x2A80204", VA = "0x2A80204")]
		[Token(Token = "0x60039D2")]
		private Vector3 method_16()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x060039D3 RID: 14803 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A802B4", Offset = "0x2A802B4", VA = "0x2A802B4")]
		[Token(Token = "0x60039D3")]
		private void method_17()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039D4 RID: 14804 RVA: 0x00073088 File Offset: 0x00071288
		[Address(RVA = "0x2A80300", Offset = "0x2A80300", VA = "0x2A80300")]
		[Token(Token = "0x60039D4")]
		public ProceduralBodyController()
		{
			long num = 1065353216L;
			this.height = (float)num;
			long num2 = 1L;
			this.bodyRotationSpeed = (float)16840;
			this.smartBodyPosition = (num2 != 0L);
			this.showGizmos = (num2 != 0L);
			this.raycastRange = (float)16576;
			base..ctor();
		}

		// Token: 0x060039D5 RID: 14805 RVA: 0x000730D0 File Offset: 0x000712D0
		[Address(RVA = "0x2A7E894", Offset = "0x2A7E894", VA = "0x2A7E894")]
		[Token(Token = "0x60039D5")]
		private void method_18()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.smartBodyPosition)
			{
				this.method_50();
				this.method_61();
				this.method_76();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			this.method_69();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060039D6 RID: 14806 RVA: 0x00072FC4 File Offset: 0x000711C4
		[Address(RVA = "0x2A80428", Offset = "0x2A80428", VA = "0x2A80428")]
		[Token(Token = "0x60039D6")]
		private void method_19()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x060039D7 RID: 14807 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x2A806E0", Offset = "0x2A806E0", VA = "0x2A806E0")]
		[Token(Token = "0x60039D7")]
		private Quaternion method_20(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039D8 RID: 14808 RVA: 0x00072F64 File Offset: 0x00071164
		[Address(RVA = "0x2A80780", Offset = "0x2A80780", VA = "0x2A80780")]
		[Token(Token = "0x60039D8")]
		private void method_21()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039D9 RID: 14809 RVA: 0x0007317C File Offset: 0x0007137C
		[Address(RVA = "0x2A808F4", Offset = "0x2A808F4", VA = "0x2A808F4")]
		[Token(Token = "0x60039D9")]
		private Vector3 method_22()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x060039DA RID: 14810 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A809A4", Offset = "0x2A809A4", VA = "0x2A809A4")]
		[Token(Token = "0x60039DA")]
		private void method_23()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039DB RID: 14811 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A809F0", Offset = "0x2A809F0", VA = "0x2A809F0")]
		[Token(Token = "0x60039DB")]
		private void method_24()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039DC RID: 14812 RVA: 0x0007319C File Offset: 0x0007139C
		[Address(RVA = "0x2A80A3C", Offset = "0x2A80A3C", VA = "0x2A80A3C")]
		[Token(Token = "0x60039DC")]
		private void method_25()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.smartBodyPosition)
			{
				this.method_42();
				this.method_47();
				this.method_42();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			this.method_47();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060039DD RID: 14813 RVA: 0x00073248 File Offset: 0x00071448
		[Address(RVA = "0x2A80D88", Offset = "0x2A80D88", VA = "0x2A80D88")]
		[Token(Token = "0x60039DD")]
		private void method_26()
		{
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039DE RID: 14814 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A80DD4", Offset = "0x2A80DD4", VA = "0x2A80DD4")]
		[Token(Token = "0x60039DE")]
		private void method_27()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039DF RID: 14815 RVA: 0x00073264 File Offset: 0x00071464
		[Address(RVA = "0x2A80E20", Offset = "0x2A80E20", VA = "0x2A80E20")]
		[Token(Token = "0x60039DF")]
		private void method_28()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x060039E0 RID: 14816 RVA: 0x00072FC4 File Offset: 0x000711C4
		[Address(RVA = "0x2A7F9EC", Offset = "0x2A7F9EC", VA = "0x2A7F9EC")]
		[Token(Token = "0x60039E0")]
		private void method_29()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x060039E1 RID: 14817 RVA: 0x000732E8 File Offset: 0x000714E8
		[Address(RVA = "0x2A7FF68", Offset = "0x2A7FF68", VA = "0x2A7FF68")]
		[Token(Token = "0x60039E1")]
		private void method_30()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.smartBodyPosition)
			{
				this.method_88();
				this.method_47();
				this.method_43();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			this.method_8();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060039E2 RID: 14818 RVA: 0x00073068 File Offset: 0x00071268
		[Address(RVA = "0x2A81224", Offset = "0x2A81224", VA = "0x2A81224")]
		[Token(Token = "0x60039E2")]
		private Vector3 method_31()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x060039E3 RID: 14819 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x2A812D4", Offset = "0x2A812D4", VA = "0x2A812D4")]
		[Token(Token = "0x60039E3")]
		private Quaternion method_32(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039E4 RID: 14820 RVA: 0x00072F64 File Offset: 0x00071164
		[Address(RVA = "0x2A81374", Offset = "0x2A81374", VA = "0x2A81374")]
		[Token(Token = "0x60039E4")]
		private void method_33()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039E5 RID: 14821 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A814E8", Offset = "0x2A814E8", VA = "0x2A814E8")]
		[Token(Token = "0x60039E5")]
		private void method_34()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039E6 RID: 14822 RVA: 0x00073394 File Offset: 0x00071594
		[Address(RVA = "0x2A81534", Offset = "0x2A81534", VA = "0x2A81534")]
		[Token(Token = "0x60039E6")]
		private void method_35()
		{
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask_0;
			mask;
			if (this.smartBodyPosition)
			{
				this.method_88();
				this.method_14();
				this.method_22();
				Transform transform = base.transform;
				return;
			}
			Vector3 position2 = base.transform.position;
			this.method_8();
			Vector3 position3 = base.transform.position;
			Transform transform2 = base.transform;
			Transform transform3 = base.transform;
			Transform transform4 = base.transform;
			Vector3 position4 = base.transform.position;
			float deltaTime = Time.deltaTime;
			Mathf.Clamp01(deltaTime);
		}

		// Token: 0x060039E7 RID: 14823 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x2A817D0", Offset = "0x2A817D0", VA = "0x2A817D0")]
		[Token(Token = "0x60039E7")]
		private Quaternion method_36(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039E8 RID: 14824 RVA: 0x00072F64 File Offset: 0x00071164
		[Address(RVA = "0x2A81870", Offset = "0x2A81870", VA = "0x2A81870")]
		[Token(Token = "0x60039E8")]
		private void method_37()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039E9 RID: 14825 RVA: 0x00073440 File Offset: 0x00071640
		[Address(RVA = "0x2A819E4", Offset = "0x2A819E4", VA = "0x2A819E4")]
		[Token(Token = "0x60039E9")]
		private void method_38()
		{
		}

		// Token: 0x060039EA RID: 14826 RVA: 0x0000368C File Offset: 0x0000188C
		[Address(RVA = "0x2A81A30", Offset = "0x2A81A30", VA = "0x2A81A30")]
		[Token(Token = "0x60039EA")]
		private void method_39()
		{
			this.method_30();
			if (this.bodyOrientation)
			{
				this.method_55();
				return;
			}
		}

		// Token: 0x060039EB RID: 14827 RVA: 0x00072F64 File Offset: 0x00071164
		[Address(RVA = "0x2A81D14", Offset = "0x2A81D14", VA = "0x2A81D14")]
		[Token(Token = "0x60039EB")]
		private void method_40()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039EC RID: 14828 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A81E88", Offset = "0x2A81E88", VA = "0x2A81E88")]
		[Token(Token = "0x60039EC")]
		private void method_41()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039ED RID: 14829 RVA: 0x0007317C File Offset: 0x0007137C
		[Address(RVA = "0x2A80CD8", Offset = "0x2A80CD8", VA = "0x2A80CD8")]
		[Token(Token = "0x60039ED")]
		private Vector3 method_42()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x060039EE RID: 14830 RVA: 0x0007317C File Offset: 0x0007137C
		[Address(RVA = "0x2A81174", Offset = "0x2A81174", VA = "0x2A81174")]
		[Token(Token = "0x60039EE")]
		private Vector3 method_43()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x060039EF RID: 14831 RVA: 0x00073450 File Offset: 0x00071650
		[Address(RVA = "0x2A81ED4", Offset = "0x2A81ED4", VA = "0x2A81ED4")]
		[Token(Token = "0x60039EF")]
		private float method_44()
		{
			this.proceduralAnimation.method_91();
			throw new NullReferenceException();
		}

		// Token: 0x060039F0 RID: 14832 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A81F0C", Offset = "0x2A81F0C", VA = "0x2A81F0C")]
		[Token(Token = "0x60039F0")]
		private void method_45()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039F1 RID: 14833 RVA: 0x00072FA4 File Offset: 0x000711A4
		[Address(RVA = "0x2A81F58", Offset = "0x2A81F58", VA = "0x2A81F58")]
		[Token(Token = "0x60039F1")]
		private float method_46()
		{
			this.proceduralAnimation.method_5();
			throw new NullReferenceException();
		}

		// Token: 0x060039F2 RID: 14834 RVA: 0x00073048 File Offset: 0x00071248
		[Address(RVA = "0x2A7E74C", Offset = "0x2A7E74C", VA = "0x2A7E74C")]
		[Token(Token = "0x60039F2")]
		private float method_47()
		{
			this.proceduralAnimation.method_7();
			throw new NullReferenceException();
		}

		// Token: 0x060039F3 RID: 14835 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A81F90", Offset = "0x2A81F90", VA = "0x2A81F90")]
		[Token(Token = "0x60039F3")]
		private void method_48()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039F4 RID: 14836 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A81FDC", Offset = "0x2A81FDC", VA = "0x2A81FDC")]
		[Token(Token = "0x60039F4")]
		private void method_49()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039F5 RID: 14837 RVA: 0x000036A3 File Offset: 0x000018A3
		[Address(RVA = "0x2A82028", Offset = "0x2A82028", VA = "0x2A82028")]
		[Token(Token = "0x60039F5")]
		private void LateUpdate()
		{
			this.method_25();
			if (this.bodyOrientation)
			{
				this.method_29();
				return;
			}
		}

		// Token: 0x060039F6 RID: 14838 RVA: 0x0007317C File Offset: 0x0007137C
		[Address(RVA = "0x2A7E318", Offset = "0x2A7E318", VA = "0x2A7E318")]
		[Token(Token = "0x60039F6")]
		private Vector3 method_50()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x060039F7 RID: 14839 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x2A810DC", Offset = "0x2A810DC", VA = "0x2A810DC")]
		[Token(Token = "0x60039F7")]
		private Quaternion method_51(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039F8 RID: 14840 RVA: 0x00073470 File Offset: 0x00071670
		[Address(RVA = "0x2A82060", Offset = "0x2A82060", VA = "0x2A82060")]
		[Token(Token = "0x60039F8")]
		private void method_52()
		{
			if (this.showGizmos)
			{
				Transform transform;
				Vector3 position = transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039F9 RID: 14841 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A821D4", Offset = "0x2A821D4", VA = "0x2A821D4")]
		[Token(Token = "0x60039F9")]
		private void method_53()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x060039FA RID: 14842 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x2A82220", Offset = "0x2A82220", VA = "0x2A82220")]
		[Token(Token = "0x60039FA")]
		private Quaternion method_54(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039FB RID: 14843 RVA: 0x000734AC File Offset: 0x000716AC
		[Address(RVA = "0x2A81A68", Offset = "0x2A81A68", VA = "0x2A81A68")]
		[Token(Token = "0x60039FB")]
		private void method_55()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
		}

		// Token: 0x060039FC RID: 14844 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A822C0", Offset = "0x2A822C0", VA = "0x2A822C0")]
		[Token(Token = "0x60039FC")]
		private void method_56()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x060039FD RID: 14845 RVA: 0x00073264 File Offset: 0x00071464
		[Token(Token = "0x60039FD")]
		[Address(RVA = "0x2A8230C", Offset = "0x2A8230C", VA = "0x2A8230C")]
		private void method_57()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x060039FE RID: 14846 RVA: 0x00072F64 File Offset: 0x00071164
		[Token(Token = "0x60039FE")]
		[Address(RVA = "0x2A825B4", Offset = "0x2A825B4", VA = "0x2A825B4")]
		private void method_58()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x060039FF RID: 14847 RVA: 0x000036BA File Offset: 0x000018BA
		[Address(RVA = "0x2A82728", Offset = "0x2A82728", VA = "0x2A82728")]
		[Token(Token = "0x60039FF")]
		private void method_59()
		{
			this.method_0();
			if (this.bodyOrientation)
			{
				this.method_79();
				return;
			}
		}

		// Token: 0x06003A00 RID: 14848 RVA: 0x000036D1 File Offset: 0x000018D1
		[Token(Token = "0x6003A00")]
		[Address(RVA = "0x2A82760", Offset = "0x2A82760", VA = "0x2A82760")]
		private void method_60()
		{
			this.method_18();
			if (this.bodyOrientation)
			{
				this.method_79();
				return;
			}
		}

		// Token: 0x06003A01 RID: 14849 RVA: 0x0007351C File Offset: 0x0007171C
		[Token(Token = "0x6003A01")]
		[Address(RVA = "0x2A80340", Offset = "0x2A80340", VA = "0x2A80340")]
		private float method_61()
		{
			this.proceduralAnimation.method_47();
			throw new NullReferenceException();
		}

		// Token: 0x06003A02 RID: 14850 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A82798", Offset = "0x2A82798", VA = "0x2A82798")]
		[Token(Token = "0x6003A02")]
		private void method_62()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x06003A03 RID: 14851 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A827E4", Offset = "0x2A827E4", VA = "0x2A827E4")]
		[Token(Token = "0x6003A03")]
		private void method_63()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x06003A04 RID: 14852 RVA: 0x000036E8 File Offset: 0x000018E8
		[Address(RVA = "0x2A82830", Offset = "0x2A82830", VA = "0x2A82830")]
		[Token(Token = "0x6003A04")]
		private void method_64()
		{
			this.method_25();
			if (this.bodyOrientation)
			{
				this.method_79();
				return;
			}
		}

		// Token: 0x06003A05 RID: 14853 RVA: 0x000036FF File Offset: 0x000018FF
		[Token(Token = "0x6003A05")]
		[Address(RVA = "0x2A82868", Offset = "0x2A82868", VA = "0x2A82868")]
		private void method_65()
		{
			this.method_30();
			if (this.bodyOrientation)
			{
				this.method_28();
				return;
			}
		}

		// Token: 0x06003A06 RID: 14854 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x6003A06")]
		[Address(RVA = "0x2A828A0", Offset = "0x2A828A0", VA = "0x2A828A0")]
		private Quaternion method_66(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06003A07 RID: 14855 RVA: 0x00072EDC File Offset: 0x000710DC
		[Token(Token = "0x6003A07")]
		[Address(RVA = "0x2A82940", Offset = "0x2A82940", VA = "0x2A82940")]
		private void method_67()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x06003A08 RID: 14856 RVA: 0x0007353C File Offset: 0x0007173C
		[Address(RVA = "0x2A8298C", Offset = "0x2A8298C", VA = "0x2A8298C")]
		[Token(Token = "0x6003A08")]
		private void method_68()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x06003A09 RID: 14857 RVA: 0x0007357C File Offset: 0x0007177C
		[Address(RVA = "0x2A7E824", Offset = "0x2A7E824", VA = "0x2A7E824")]
		[Token(Token = "0x6003A09")]
		private float method_69()
		{
			this.proceduralAnimation.method_5();
			throw new NullReferenceException();
		}

		// Token: 0x06003A0A RID: 14858 RVA: 0x00072EDC File Offset: 0x000710DC
		[Token(Token = "0x6003A0A")]
		[Address(RVA = "0x2A82B00", Offset = "0x2A82B00", VA = "0x2A82B00")]
		private void method_70()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x06003A0B RID: 14859 RVA: 0x00072EBC File Offset: 0x000710BC
		[Token(Token = "0x6003A0B")]
		[Address(RVA = "0x2A82B4C", Offset = "0x2A82B4C", VA = "0x2A82B4C")]
		private void method_71()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x06003A0C RID: 14860 RVA: 0x00072EDC File Offset: 0x000710DC
		[Token(Token = "0x6003A0C")]
		[Address(RVA = "0x2A82B98", Offset = "0x2A82B98", VA = "0x2A82B98")]
		private void method_72()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x06003A0D RID: 14861 RVA: 0x00073450 File Offset: 0x00071650
		[Token(Token = "0x6003A0D")]
		[Address(RVA = "0x2A7E3C8", Offset = "0x2A7E3C8", VA = "0x2A7E3C8")]
		private float method_73()
		{
			this.proceduralAnimation.method_91();
			throw new NullReferenceException();
		}

		// Token: 0x06003A0E RID: 14862 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x6003A0E")]
		[Address(RVA = "0x2A7F174", Offset = "0x2A7F174", VA = "0x2A7F174")]
		private Quaternion method_74(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06003A0F RID: 14863 RVA: 0x00072F64 File Offset: 0x00071164
		[Token(Token = "0x6003A0F")]
		[Address(RVA = "0x2A82BE4", Offset = "0x2A82BE4", VA = "0x2A82BE4")]
		private void method_75()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x06003A10 RID: 14864 RVA: 0x00073068 File Offset: 0x00071268
		[Address(RVA = "0x2A80378", Offset = "0x2A80378", VA = "0x2A80378")]
		[Token(Token = "0x6003A10")]
		private Vector3 method_76()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x06003A11 RID: 14865 RVA: 0x00003716 File Offset: 0x00001916
		[Address(RVA = "0x2A82D58", Offset = "0x2A82D58", VA = "0x2A82D58")]
		[Token(Token = "0x6003A11")]
		private void method_77()
		{
			this.method_25();
			if (this.bodyOrientation)
			{
				this.method_81();
				return;
			}
		}

		// Token: 0x06003A12 RID: 14866 RVA: 0x00072F64 File Offset: 0x00071164
		[Token(Token = "0x6003A12")]
		[Address(RVA = "0x2A82D90", Offset = "0x2A82D90", VA = "0x2A82D90")]
		private void method_78()
		{
			if (this.showGizmos)
			{
				Vector3 position = base.transform.position;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Color green = Color.green;
				Vector3 position2 = base.transform.position;
				return;
			}
		}

		// Token: 0x06003A13 RID: 14867 RVA: 0x00072FC4 File Offset: 0x000711C4
		[Token(Token = "0x6003A13")]
		[Address(RVA = "0x2A7F40C", Offset = "0x2A7F40C", VA = "0x2A7F40C")]
		private void method_79()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x06003A14 RID: 14868 RVA: 0x0007317C File Offset: 0x0007137C
		[Address(RVA = "0x2A7E400", Offset = "0x2A7E400", VA = "0x2A7E400")]
		[Token(Token = "0x6003A14")]
		private Vector3 method_80()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x06003A15 RID: 14869 RVA: 0x00072FC4 File Offset: 0x000711C4
		[Address(RVA = "0x2A7EB30", Offset = "0x2A7EB30", VA = "0x2A7EB30")]
		[Token(Token = "0x6003A15")]
		private void method_81()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			float y = this.bodyRotationSpeed;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x06003A16 RID: 14870 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x2A82F04", Offset = "0x2A82F04", VA = "0x2A82F04")]
		[Token(Token = "0x6003A16")]
		private Quaternion method_82(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x06003A17 RID: 14871 RVA: 0x0000372D File Offset: 0x0000192D
		[Token(Token = "0x6003A17")]
		[Address(RVA = "0x2A82FA4", Offset = "0x2A82FA4", VA = "0x2A82FA4")]
		private void method_83()
		{
			this.method_1();
			if (this.bodyOrientation)
			{
				this.method_81();
				return;
			}
		}

		// Token: 0x06003A18 RID: 14872 RVA: 0x00072EDC File Offset: 0x000710DC
		[Address(RVA = "0x2A82FDC", Offset = "0x2A82FDC", VA = "0x2A82FDC")]
		[Token(Token = "0x6003A18")]
		private void method_84()
		{
			LayerMask layerMask = this.proceduralAnimation.layerMask;
			this.layerMask_0 = layerMask;
			Vector3 up = base.transform.up;
		}

		// Token: 0x06003A19 RID: 14873 RVA: 0x0007359C File Offset: 0x0007179C
		[Address(RVA = "0x2A83028", Offset = "0x2A83028", VA = "0x2A83028")]
		[Token(Token = "0x6003A19")]
		private Vector3 method_85()
		{
			do
			{
				Vector3 zero = Vector3.zero;
			}
			while (this.transform_0 != null);
			throw new NullReferenceException();
		}

		// Token: 0x06003A1A RID: 14874 RVA: 0x000735BC File Offset: 0x000717BC
		[Address(RVA = "0x2A830C8", Offset = "0x2A830C8", VA = "0x2A830C8")]
		[Token(Token = "0x6003A1A")]
		private void method_86()
		{
			Vector3 zero = Vector3.zero;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask_0;
			Vector3 vector;
			Vector3 normalized = vector.normalized.normalized;
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
		}

		// Token: 0x06003A1B RID: 14875 RVA: 0x00072EBC File Offset: 0x000710BC
		[Address(RVA = "0x2A83380", Offset = "0x2A83380", VA = "0x2A83380")]
		[Token(Token = "0x6003A1B")]
		private void method_87()
		{
			Transform[] legIktargets = this.proceduralAnimation.legIktargets;
			this.transform_0 = legIktargets;
		}

		// Token: 0x06003A1C RID: 14876 RVA: 0x0007362C File Offset: 0x0007182C
		[Token(Token = "0x6003A1C")]
		[Address(RVA = "0x2A7E784", Offset = "0x2A7E784", VA = "0x2A7E784")]
		private Vector3 method_88()
		{
			Vector3 zero = Vector3.zero;
			Vector3 vector;
			while (vector != null)
			{
			}
			throw new NullReferenceException();
		}

		// Token: 0x04000A19 RID: 2585
		[SerializeField]
		[Token(Token = "0x4000A19")]
		[FieldOffset(Offset = "0x18")]
		private proceduralAnimation proceduralAnimation;

		// Token: 0x04000A1A RID: 2586
		[Token(Token = "0x4000A1A")]
		[SerializeField]
		[FieldOffset(Offset = "0x20")]
		private Vector3 bodyOffset;

		// Token: 0x04000A1B RID: 2587
		[Token(Token = "0x4000A1B")]
		[FieldOffset(Offset = "0x2C")]
		[SerializeField]
		private float bodySpeed;

		// Token: 0x04000A1C RID: 2588
		[FieldOffset(Offset = "0x30")]
		[Tooltip("How much legs affect body position")]
		[SerializeField]
		[Token(Token = "0x4000A1C")]
		private float legsImpact;

		// Token: 0x04000A1D RID: 2589
		[FieldOffset(Offset = "0x34")]
		[SerializeField]
		[Token(Token = "0x4000A1D")]
		private float height;

		// Token: 0x04000A1E RID: 2590
		[FieldOffset(Offset = "0x38")]
		[Tooltip("Calculates body position based on average leg positions, use body offset vector to set desired body position")]
		[SerializeField]
		[Token(Token = "0x4000A1E")]
		private bool smartBodyPosition;

		// Token: 0x04000A1F RID: 2591
		[FieldOffset(Offset = "0x39")]
		[Tooltip("rotates body towards the ground with speed of bodyRotationSpeed")]
		[SerializeField]
		[Token(Token = "0x4000A1F")]
		private bool bodyOrientation;

		// Token: 0x04000A20 RID: 2592
		[SerializeField]
		[FieldOffset(Offset = "0x3C")]
		[Token(Token = "0x4000A20")]
		private float bodyRotationSpeed;

		// Token: 0x04000A21 RID: 2593
		[SerializeField]
		[Header("Raycasts")]
		[Token(Token = "0x4000A21")]
		[FieldOffset(Offset = "0x40")]
		private bool showGizmos;

		// Token: 0x04000A22 RID: 2594
		[SerializeField]
		[Token(Token = "0x4000A22")]
		[Tooltip("body ground check range")]
		[FieldOffset(Offset = "0x44")]
		private float sphereCastRadius;

		// Token: 0x04000A23 RID: 2595
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000A23")]
		[SerializeField]
		private float racastOffset;

		// Token: 0x04000A24 RID: 2596
		[Token(Token = "0x4000A24")]
		[FieldOffset(Offset = "0x4C")]
		[SerializeField]
		private float raycastRange;

		// Token: 0x04000A25 RID: 2597
		[Token(Token = "0x4000A25")]
		[FieldOffset(Offset = "0x50")]
		private LayerMask layerMask_0;

		// Token: 0x04000A26 RID: 2598
		[Token(Token = "0x4000A26")]
		[FieldOffset(Offset = "0x58")]
		private Transform[] transform_0;

		// Token: 0x04000A27 RID: 2599
		[Token(Token = "0x4000A27")]
		[FieldOffset(Offset = "0x60")]
		private int int_0;

		// Token: 0x04000A28 RID: 2600
		[Token(Token = "0x4000A28")]
		[FieldOffset(Offset = "0x64")]
		private Vector3 vector3_0;
	}
}
