﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000173 RID: 371
	[Token(Token = "0x2000173")]
	public class follow : MonoBehaviour
	{
		// Token: 0x06003956 RID: 14678 RVA: 0x000726B4 File Offset: 0x000708B4
		[Address(RVA = "0x354DF44", Offset = "0x354DF44", VA = "0x354DF44")]
		[Token(Token = "0x6003956")]
		private void method_0()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003957 RID: 14679 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x6003957")]
		[Address(RVA = "0x354E370", Offset = "0x354E370", VA = "0x354E370")]
		private void method_1()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003958 RID: 14680 RVA: 0x000726E4 File Offset: 0x000708E4
		[Address(RVA = "0x354E79C", Offset = "0x354E79C", VA = "0x354E79C")]
		[Token(Token = "0x6003958")]
		private void method_2()
		{
		}

		// Token: 0x06003959 RID: 14681 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x6003959")]
		[Address(RVA = "0x354EBD0", Offset = "0x354EBD0", VA = "0x354EBD0")]
		private void method_3()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600395A RID: 14682 RVA: 0x000726CC File Offset: 0x000708CC
		[Address(RVA = "0x354EFFC", Offset = "0x354EFFC", VA = "0x354EFFC")]
		[Token(Token = "0x600395A")]
		private void method_4()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600395B RID: 14683 RVA: 0x000726E4 File Offset: 0x000708E4
		[Token(Token = "0x600395B")]
		[Address(RVA = "0x354F428", Offset = "0x354F428", VA = "0x354F428")]
		private void FixedUpdate()
		{
		}

		// Token: 0x0600395C RID: 14684 RVA: 0x000726F4 File Offset: 0x000708F4
		[Token(Token = "0x600395C")]
		[Address(RVA = "0x354F85C", Offset = "0x354F85C", VA = "0x354F85C")]
		private void Update()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600395D RID: 14685 RVA: 0x000726CC File Offset: 0x000708CC
		[Address(RVA = "0x354FC8C", Offset = "0x354FC8C", VA = "0x354FC8C")]
		[Token(Token = "0x600395D")]
		private void method_5()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600395E RID: 14686 RVA: 0x0007270C File Offset: 0x0007090C
		[Token(Token = "0x600395E")]
		[Address(RVA = "0x35500B4", Offset = "0x35500B4", VA = "0x35500B4")]
		private void method_6()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600395F RID: 14687 RVA: 0x00072724 File Offset: 0x00070924
		[Address(RVA = "0x35504E0", Offset = "0x35504E0", VA = "0x35504E0")]
		[Token(Token = "0x600395F")]
		private void method_7()
		{
		}

		// Token: 0x06003960 RID: 14688 RVA: 0x000726E4 File Offset: 0x000708E4
		[Token(Token = "0x6003960")]
		[Address(RVA = "0x3550910", Offset = "0x3550910", VA = "0x3550910")]
		private void method_8()
		{
		}

		// Token: 0x06003961 RID: 14689 RVA: 0x00072734 File Offset: 0x00070934
		[Token(Token = "0x6003961")]
		[Address(RVA = "0x3550D40", Offset = "0x3550D40", VA = "0x3550D40")]
		private void method_9()
		{
		}

		// Token: 0x06003962 RID: 14690 RVA: 0x00072744 File Offset: 0x00070944
		[Token(Token = "0x6003962")]
		[Address(RVA = "0x3551170", Offset = "0x3551170", VA = "0x3551170")]
		private void method_10()
		{
		}

		// Token: 0x06003963 RID: 14691 RVA: 0x00072754 File Offset: 0x00070954
		[Token(Token = "0x6003963")]
		[Address(RVA = "0x35515A0", Offset = "0x35515A0", VA = "0x35515A0")]
		private void method_11()
		{
		}

		// Token: 0x06003964 RID: 14692 RVA: 0x000726E4 File Offset: 0x000708E4
		[Token(Token = "0x6003964")]
		[Address(RVA = "0x35519D0", Offset = "0x35519D0", VA = "0x35519D0")]
		private void method_12()
		{
		}

		// Token: 0x06003965 RID: 14693 RVA: 0x000726F4 File Offset: 0x000708F4
		[Address(RVA = "0x3551E04", Offset = "0x3551E04", VA = "0x3551E04")]
		[Token(Token = "0x6003965")]
		private void method_13()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003966 RID: 14694 RVA: 0x00072764 File Offset: 0x00070964
		[Token(Token = "0x6003966")]
		[Address(RVA = "0x3552230", Offset = "0x3552230", VA = "0x3552230")]
		private void method_14()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003967 RID: 14695 RVA: 0x0007277C File Offset: 0x0007097C
		[Address(RVA = "0x355265C", Offset = "0x355265C", VA = "0x355265C")]
		[Token(Token = "0x6003967")]
		private void method_15()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003968 RID: 14696 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x6003968")]
		[Address(RVA = "0x3552A88", Offset = "0x3552A88", VA = "0x3552A88")]
		private void method_16()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003969 RID: 14697 RVA: 0x00072794 File Offset: 0x00070994
		[Address(RVA = "0x3552EB0", Offset = "0x3552EB0", VA = "0x3552EB0")]
		[Token(Token = "0x6003969")]
		private void method_17()
		{
		}

		// Token: 0x0600396A RID: 14698 RVA: 0x000727A4 File Offset: 0x000709A4
		[Token(Token = "0x600396A")]
		[Address(RVA = "0x35532DC", Offset = "0x35532DC", VA = "0x35532DC")]
		private void method_18()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600396B RID: 14699 RVA: 0x000727BC File Offset: 0x000709BC
		[Address(RVA = "0x3553708", Offset = "0x3553708", VA = "0x3553708")]
		[Token(Token = "0x600396B")]
		private void method_19()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600396C RID: 14700 RVA: 0x000726E4 File Offset: 0x000708E4
		[Token(Token = "0x600396C")]
		[Address(RVA = "0x3553B34", Offset = "0x3553B34", VA = "0x3553B34")]
		private void method_20()
		{
		}

		// Token: 0x0600396D RID: 14701 RVA: 0x000726E4 File Offset: 0x000708E4
		[Address(RVA = "0x3553F68", Offset = "0x3553F68", VA = "0x3553F68")]
		[Token(Token = "0x600396D")]
		private void method_21()
		{
		}

		// Token: 0x0600396E RID: 14702 RVA: 0x000727D4 File Offset: 0x000709D4
		[Token(Token = "0x600396E")]
		[Address(RVA = "0x3554398", Offset = "0x3554398", VA = "0x3554398")]
		private void LateUpdate()
		{
		}

		// Token: 0x0600396F RID: 14703 RVA: 0x000727E4 File Offset: 0x000709E4
		[Address(RVA = "0x35547CC", Offset = "0x35547CC", VA = "0x35547CC")]
		[Token(Token = "0x600396F")]
		private void method_22()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003970 RID: 14704 RVA: 0x000727FC File Offset: 0x000709FC
		[Address(RVA = "0x3554BF8", Offset = "0x3554BF8", VA = "0x3554BF8")]
		[Token(Token = "0x6003970")]
		private void method_23()
		{
		}

		// Token: 0x06003971 RID: 14705 RVA: 0x0007280C File Offset: 0x00070A0C
		[Token(Token = "0x6003971")]
		[Address(RVA = "0x3555028", Offset = "0x3555028", VA = "0x3555028")]
		private void method_24()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003972 RID: 14706 RVA: 0x00072824 File Offset: 0x00070A24
		[Token(Token = "0x6003972")]
		[Address(RVA = "0x3555450", Offset = "0x3555450", VA = "0x3555450")]
		private void method_25()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003973 RID: 14707 RVA: 0x0007283C File Offset: 0x00070A3C
		[Token(Token = "0x6003973")]
		[Address(RVA = "0x355587C", Offset = "0x355587C", VA = "0x355587C")]
		private void method_26()
		{
		}

		// Token: 0x06003974 RID: 14708 RVA: 0x0007284C File Offset: 0x00070A4C
		[Token(Token = "0x6003974")]
		[Address(RVA = "0x3555CB0", Offset = "0x3555CB0", VA = "0x3555CB0")]
		private void method_27()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003975 RID: 14709 RVA: 0x00072864 File Offset: 0x00070A64
		[Address(RVA = "0x35560D8", Offset = "0x35560D8", VA = "0x35560D8")]
		[Token(Token = "0x6003975")]
		private void method_28()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003976 RID: 14710 RVA: 0x000726E4 File Offset: 0x000708E4
		[Token(Token = "0x6003976")]
		[Address(RVA = "0x3556504", Offset = "0x3556504", VA = "0x3556504")]
		private void method_29()
		{
		}

		// Token: 0x06003977 RID: 14711 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x6003977")]
		[Address(RVA = "0x3556934", Offset = "0x3556934", VA = "0x3556934")]
		private void method_30()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003978 RID: 14712 RVA: 0x0007287C File Offset: 0x00070A7C
		[Token(Token = "0x6003978")]
		[Address(RVA = "0x3556D64", Offset = "0x3556D64", VA = "0x3556D64")]
		private void method_31()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003979 RID: 14713 RVA: 0x000726E4 File Offset: 0x000708E4
		[Address(RVA = "0x3557190", Offset = "0x3557190", VA = "0x3557190")]
		[Token(Token = "0x6003979")]
		private void method_32()
		{
		}

		// Token: 0x0600397A RID: 14714 RVA: 0x00072864 File Offset: 0x00070A64
		[Token(Token = "0x600397A")]
		[Address(RVA = "0x35575BC", Offset = "0x35575BC", VA = "0x35575BC")]
		private void method_33()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600397B RID: 14715 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x600397B")]
		[Address(RVA = "0x35579E8", Offset = "0x35579E8", VA = "0x35579E8")]
		private void method_34()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600397C RID: 14716 RVA: 0x0007270C File Offset: 0x0007090C
		[Token(Token = "0x600397C")]
		[Address(RVA = "0x3557E10", Offset = "0x3557E10", VA = "0x3557E10")]
		private void method_35()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600397D RID: 14717 RVA: 0x000726CC File Offset: 0x000708CC
		[Address(RVA = "0x3558238", Offset = "0x3558238", VA = "0x3558238")]
		[Token(Token = "0x600397D")]
		private void method_36()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600397E RID: 14718 RVA: 0x00072894 File Offset: 0x00070A94
		[Token(Token = "0x600397E")]
		[Address(RVA = "0x3558660", Offset = "0x3558660", VA = "0x3558660")]
		private void method_37()
		{
		}

		// Token: 0x0600397F RID: 14719 RVA: 0x000728A4 File Offset: 0x00070AA4
		[Address(RVA = "0x3558A90", Offset = "0x3558A90", VA = "0x3558A90")]
		[Token(Token = "0x600397F")]
		private void method_38()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003980 RID: 14720 RVA: 0x000728BC File Offset: 0x00070ABC
		[Token(Token = "0x6003980")]
		[Address(RVA = "0x3558EB8", Offset = "0x3558EB8", VA = "0x3558EB8")]
		private void method_39()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003981 RID: 14721 RVA: 0x000728D4 File Offset: 0x00070AD4
		[Address(RVA = "0x35592E4", Offset = "0x35592E4", VA = "0x35592E4")]
		[Token(Token = "0x6003981")]
		private void method_40()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003982 RID: 14722 RVA: 0x000726E4 File Offset: 0x000708E4
		[Token(Token = "0x6003982")]
		[Address(RVA = "0x3559710", Offset = "0x3559710", VA = "0x3559710")]
		private void method_41()
		{
		}

		// Token: 0x06003983 RID: 14723 RVA: 0x000728EC File Offset: 0x00070AEC
		[Token(Token = "0x6003983")]
		[Address(RVA = "0x3559B40", Offset = "0x3559B40", VA = "0x3559B40")]
		private void method_42()
		{
		}

		// Token: 0x06003984 RID: 14724 RVA: 0x000726CC File Offset: 0x000708CC
		[Address(RVA = "0x3559F6C", Offset = "0x3559F6C", VA = "0x3559F6C")]
		[Token(Token = "0x6003984")]
		private void method_43()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003985 RID: 14725 RVA: 0x00072724 File Offset: 0x00070924
		[Token(Token = "0x6003985")]
		[Address(RVA = "0x355A39C", Offset = "0x355A39C", VA = "0x355A39C")]
		private void method_44()
		{
		}

		// Token: 0x06003986 RID: 14726 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x6003986")]
		[Address(RVA = "0x355A7CC", Offset = "0x355A7CC", VA = "0x355A7CC")]
		private void method_45()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x06003987 RID: 14727 RVA: 0x000728FC File Offset: 0x00070AFC
		[Address(RVA = "0x355ABF4", Offset = "0x355ABF4", VA = "0x355ABF4")]
		[Token(Token = "0x6003987")]
		private void method_46()
		{
		}

		// Token: 0x06003988 RID: 14728 RVA: 0x000726E4 File Offset: 0x000708E4
		[Address(RVA = "0x355B024", Offset = "0x355B024", VA = "0x355B024")]
		[Token(Token = "0x6003988")]
		private void method_47()
		{
		}

		// Token: 0x06003989 RID: 14729 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x6003989")]
		[Address(RVA = "0x355B454", Offset = "0x355B454", VA = "0x355B454")]
		private void method_48()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600398A RID: 14730 RVA: 0x000726CC File Offset: 0x000708CC
		[Token(Token = "0x600398A")]
		[Address(RVA = "0x355B884", Offset = "0x355B884", VA = "0x355B884")]
		private void method_49()
		{
			if (this.genum25_0 == follow.GEnum25.const_0)
			{
				return;
			}
		}

		// Token: 0x0600398B RID: 14731 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x355BCAC", Offset = "0x355BCAC", VA = "0x355BCAC")]
		[Token(Token = "0x600398B")]
		public follow()
		{
		}

		// Token: 0x040009F9 RID: 2553
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40009F9")]
		public Transform transform_0;

		// Token: 0x040009FA RID: 2554
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40009FA")]
		public float float_0;

		// Token: 0x040009FB RID: 2555
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x40009FB")]
		public float float_1;

		// Token: 0x040009FC RID: 2556
		[Token(Token = "0x40009FC")]
		[FieldOffset(Offset = "0x28")]
		public float float_2;

		// Token: 0x040009FD RID: 2557
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x40009FD")]
		public follow.GEnum25 genum25_0;

		// Token: 0x040009FE RID: 2558
		[Token(Token = "0x40009FE")]
		[FieldOffset(Offset = "0x30")]
		public follow.GEnum26 genum26_0;

		// Token: 0x040009FF RID: 2559
		[Token(Token = "0x40009FF")]
		[FieldOffset(Offset = "0x34")]
		public follow.GEnum27 genum27_0;

		// Token: 0x02000174 RID: 372
		[Token(Token = "0x2000174")]
		public enum GEnum25
		{
			// Token: 0x04000A01 RID: 2561
			[Token(Token = "0x4000A01")]
			const_0,
			// Token: 0x04000A02 RID: 2562
			[Token(Token = "0x4000A02")]
			const_1,
			// Token: 0x04000A03 RID: 2563
			[Token(Token = "0x4000A03")]
			const_2
		}

		// Token: 0x02000175 RID: 373
		[Token(Token = "0x2000175")]
		public enum GEnum26
		{
			// Token: 0x04000A05 RID: 2565
			[Token(Token = "0x4000A05")]
			const_0,
			// Token: 0x04000A06 RID: 2566
			[Token(Token = "0x4000A06")]
			const_1,
			// Token: 0x04000A07 RID: 2567
			[Token(Token = "0x4000A07")]
			const_2,
			// Token: 0x04000A08 RID: 2568
			[Token(Token = "0x4000A08")]
			const_3,
			// Token: 0x04000A09 RID: 2569
			[Token(Token = "0x4000A09")]
			const_4,
			// Token: 0x04000A0A RID: 2570
			[Token(Token = "0x4000A0A")]
			const_5
		}

		// Token: 0x02000176 RID: 374
		[Token(Token = "0x2000176")]
		public enum GEnum27
		{
			// Token: 0x04000A0C RID: 2572
			[Token(Token = "0x4000A0C")]
			const_0,
			// Token: 0x04000A0D RID: 2573
			[Token(Token = "0x4000A0D")]
			const_1,
			// Token: 0x04000A0E RID: 2574
			[Token(Token = "0x4000A0E")]
			const_2,
			// Token: 0x04000A0F RID: 2575
			[Token(Token = "0x4000A0F")]
			const_3,
			// Token: 0x04000A10 RID: 2576
			[Token(Token = "0x4000A10")]
			const_4
		}
	}
}
