﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000178 RID: 376
	[Token(Token = "0x2000178")]
	public class GroundAlliment : MonoBehaviour
	{
		// Token: 0x060039A6 RID: 14758 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x3506CC8", Offset = "0x3506CC8", VA = "0x3506CC8")]
		[Token(Token = "0x60039A6")]
		private Quaternion method_0(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039A7 RID: 14759 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x60039A7")]
		[Address(RVA = "0x3506D68", Offset = "0x3506D68", VA = "0x3506D68")]
		private Quaternion method_1(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039A8 RID: 14760 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Token(Token = "0x60039A8")]
		[Address(RVA = "0x3506E08", Offset = "0x3506E08", VA = "0x3506E08")]
		private void method_2()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039A9 RID: 14761 RVA: 0x00072B74 File Offset: 0x00070D74
		[Token(Token = "0x60039A9")]
		[Address(RVA = "0x35070E8", Offset = "0x35070E8", VA = "0x35070E8")]
		private void method_3()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039AA RID: 14762 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x35073C0", Offset = "0x35073C0", VA = "0x35073C0")]
		[Token(Token = "0x60039AA")]
		private Quaternion method_4(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039AB RID: 14763 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x60039AB")]
		[Address(RVA = "0x3507328", Offset = "0x3507328", VA = "0x3507328")]
		private Quaternion method_5(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039AC RID: 14764 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Token(Token = "0x60039AC")]
		[Address(RVA = "0x3507460", Offset = "0x3507460", VA = "0x3507460")]
		private void method_6()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039AD RID: 14765 RVA: 0x00072C14 File Offset: 0x00070E14
		[Address(RVA = "0x3507740", Offset = "0x3507740", VA = "0x3507740")]
		[Token(Token = "0x60039AD")]
		private void method_7()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039AE RID: 14766 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x60039AE")]
		[Address(RVA = "0x3507980", Offset = "0x3507980", VA = "0x3507980")]
		private Quaternion method_8(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039AF RID: 14767 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x60039AF")]
		[Address(RVA = "0x3507A20", Offset = "0x3507A20", VA = "0x3507A20")]
		private Quaternion method_9(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039B0 RID: 14768 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x3507AC0", Offset = "0x3507AC0", VA = "0x3507AC0")]
		[Token(Token = "0x60039B0")]
		private Quaternion method_10(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039B1 RID: 14769 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x60039B1")]
		[Address(RVA = "0x3507B60", Offset = "0x3507B60", VA = "0x3507B60")]
		public GroundAlliment()
		{
		}

		// Token: 0x060039B2 RID: 14770 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x60039B2")]
		[Address(RVA = "0x3507B74", Offset = "0x3507B74", VA = "0x3507B74")]
		private Quaternion method_11(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039B3 RID: 14771 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x3507C14", Offset = "0x3507C14", VA = "0x3507C14")]
		[Token(Token = "0x60039B3")]
		private Quaternion method_12(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039B4 RID: 14772 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x35076A0", Offset = "0x35076A0", VA = "0x35076A0")]
		[Token(Token = "0x60039B4")]
		private Quaternion method_13(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039B5 RID: 14773 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Address(RVA = "0x3507CB4", Offset = "0x3507CB4", VA = "0x3507CB4")]
		[Token(Token = "0x60039B5")]
		private void method_14()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039B6 RID: 14774 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Address(RVA = "0x3507EF4", Offset = "0x3507EF4", VA = "0x3507EF4")]
		[Token(Token = "0x60039B6")]
		private Quaternion method_15(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039B7 RID: 14775 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Address(RVA = "0x3507F94", Offset = "0x3507F94", VA = "0x3507F94")]
		[Token(Token = "0x60039B7")]
		private void method_16()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039B8 RID: 14776 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Address(RVA = "0x35081D4", Offset = "0x35081D4", VA = "0x35081D4")]
		[Token(Token = "0x60039B8")]
		private void method_17()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039B9 RID: 14777 RVA: 0x00072AC4 File Offset: 0x00070CC4
		[Token(Token = "0x60039B9")]
		[Address(RVA = "0x3507048", Offset = "0x3507048", VA = "0x3507048")]
		private Quaternion method_18(Vector3 vector3_1, Vector3 vector3_2)
		{
			Quaternion result;
			return result;
		}

		// Token: 0x060039BA RID: 14778 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Token(Token = "0x60039BA")]
		[Address(RVA = "0x3508414", Offset = "0x3508414", VA = "0x3508414")]
		private void method_19()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039BB RID: 14779 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Address(RVA = "0x3508654", Offset = "0x3508654", VA = "0x3508654")]
		[Token(Token = "0x60039BB")]
		private void method_20()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039BC RID: 14780 RVA: 0x00072CB4 File Offset: 0x00070EB4
		[Token(Token = "0x60039BC")]
		[Address(RVA = "0x3508894", Offset = "0x3508894", VA = "0x3508894")]
		private void method_21()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.y = y;
		}

		// Token: 0x060039BD RID: 14781 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Address(RVA = "0x3508AD4", Offset = "0x3508AD4", VA = "0x3508AD4")]
		[Token(Token = "0x60039BD")]
		private void method_22()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x060039BE RID: 14782 RVA: 0x00072AD4 File Offset: 0x00070CD4
		[Address(RVA = "0x3508D14", Offset = "0x3508D14", VA = "0x3508D14")]
		[Token(Token = "0x60039BE")]
		private void Update()
		{
			float deltaTime = Time.deltaTime;
			Vector3 position = base.transform.position;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			LayerMask mask = this.layerMask;
			mask;
			float x = this.float_0;
			float y = this.orientationSpeed;
			Mathf.Clamp01(deltaTime);
			Vector3 forward = base.transform.forward;
			Transform transform = base.transform;
			Quaternion rotation = base.transform.rotation;
			float deltaTime2 = Time.deltaTime;
			Vector3 up3 = base.transform.up;
			this.vector3_0.x = x;
			this.vector3_0.y = y;
		}

		// Token: 0x04000A14 RID: 2580
		[Token(Token = "0x4000A14")]
		[SerializeField]
		[FieldOffset(Offset = "0x18")]
		private float checkRange;

		// Token: 0x04000A15 RID: 2581
		[SerializeField]
		[Token(Token = "0x4000A15")]
		[FieldOffset(Offset = "0x1C")]
		private float orientationSpeed;

		// Token: 0x04000A16 RID: 2582
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000A16")]
		[SerializeField]
		private LayerMask layerMask;

		// Token: 0x04000A17 RID: 2583
		[Token(Token = "0x4000A17")]
		[FieldOffset(Offset = "0x24")]
		private Vector3 vector3_0;

		// Token: 0x04000A18 RID: 2584
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000A18")]
		private float float_0;
	}
}
