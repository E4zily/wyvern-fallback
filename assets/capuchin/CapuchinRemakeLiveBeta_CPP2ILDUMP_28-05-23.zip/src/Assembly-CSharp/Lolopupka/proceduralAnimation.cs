﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x0200017C RID: 380
	[Token(Token = "0x200017C")]
	public class proceduralAnimation : MonoBehaviour
	{
		// Token: 0x06003A98 RID: 15000 RVA: 0x00073768 File Offset: 0x00071968
		[Address(RVA = "0x3539CB8", Offset = "0x3539CB8", VA = "0x3539CB8")]
		[Token(Token = "0x6003A98")]
		private void method_0()
		{
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float z = this.vector3_4.z;
			this.vector3_5.z = z;
		}

		// Token: 0x06003A99 RID: 15001 RVA: 0x000737B0 File Offset: 0x000719B0
		[Address(RVA = "0x353A2A8", Offset = "0x353A2A8", VA = "0x353A2A8")]
		[Token(Token = "0x6003A99")]
		private void method_1(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003A9A RID: 15002 RVA: 0x000737C8 File Offset: 0x000719C8
		[Address(RVA = "0x353A41C", Offset = "0x353A41C", VA = "0x353A41C")]
		[Token(Token = "0x6003A9A")]
		private IEnumerator method_2(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003A9B RID: 15003 RVA: 0x000737F0 File Offset: 0x000719F0
		[Address(RVA = "0x353A4A4", Offset = "0x353A4A4", VA = "0x353A4A4")]
		[Token(Token = "0x6003A9B")]
		public static float smethod_0(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003A9B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_0(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003A9C RID: 15004 RVA: 0x00073810 File Offset: 0x00071A10
		[Address(RVA = "0x353A4EC", Offset = "0x353A4EC", VA = "0x353A4EC")]
		[Token(Token = "0x6003A9C")]
		public float method_3(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06003A9D RID: 15005 RVA: 0x00003744 File Offset: 0x00001944
		[Address(RVA = "0x353A644", Offset = "0x353A644", VA = "0x353A644")]
		[Token(Token = "0x6003A9D")]
		public Transform[] method_4()
		{
			return this.legIktargets;
		}

		// Token: 0x06003A9E RID: 15006 RVA: 0x0007383C File Offset: 0x00071A3C
		[Address(RVA = "0x353A64C", Offset = "0x353A64C", VA = "0x353A64C")]
		[Token(Token = "0x6003A9E")]
		public float method_5()
		{
			/*
An exception occurred when decompiling this method (06003A9E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_5()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(1)); 	call:float32(proceduralAnimation::method_74, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003A9F RID: 15007 RVA: 0x00003744 File Offset: 0x00001944
		[Address(RVA = "0x353A808", Offset = "0x353A808", VA = "0x353A808")]
		[Token(Token = "0x6003A9F")]
		public Transform[] method_6()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AA0 RID: 15008 RVA: 0x000737F0 File Offset: 0x000719F0
		[Address(RVA = "0x353A810", Offset = "0x353A810", VA = "0x353A810")]
		[Token(Token = "0x6003AA0")]
		public static float smethod_1(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AA0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_1(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AA1 RID: 15009 RVA: 0x00073854 File Offset: 0x00071A54
		[Token(Token = "0x6003AA1")]
		[Address(RVA = "0x353A858", Offset = "0x353A858", VA = "0x353A858")]
		public float method_7()
		{
			/*
An exception occurred when decompiling this method (06003AA1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_7()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(0)); 	call:float32(proceduralAnimation::method_67, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AA2 RID: 15010 RVA: 0x00003744 File Offset: 0x00001944
		[Token(Token = "0x6003AA2")]
		[Address(RVA = "0x353AA10", Offset = "0x353AA10", VA = "0x353AA10")]
		public Transform[] method_8()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AA3 RID: 15011 RVA: 0x0007386C File Offset: 0x00071A6C
		[Token(Token = "0x6003AA3")]
		[Address(RVA = "0x353AA18", Offset = "0x353AA18", VA = "0x353AA18")]
		private void method_9(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003AA4 RID: 15012 RVA: 0x00003744 File Offset: 0x00001944
		[Address(RVA = "0x353AB8C", Offset = "0x353AB8C", VA = "0x353AB8C")]
		[Token(Token = "0x6003AA4")]
		public Transform[] method_10()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AA5 RID: 15013 RVA: 0x00073884 File Offset: 0x00071A84
		[Token(Token = "0x6003AA5")]
		[Address(RVA = "0x353AB94", Offset = "0x353AB94", VA = "0x353AB94")]
		private void method_11()
		{
			Application.IsPlaying(this);
			Transform transform = base.transform;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			Color blue = Color.blue;
			Color green = Color.green;
			Transform transform2 = base.transform;
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			Transform transform3 = base.transform;
		}

		// Token: 0x06003AA6 RID: 15014 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Token(Token = "0x6003AA6")]
		[Address(RVA = "0x353AE10", Offset = "0x353AE10", VA = "0x353AE10")]
		private IEnumerator method_12(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003AA7 RID: 15015 RVA: 0x00073904 File Offset: 0x00071B04
		[Token(Token = "0x6003AA7")]
		[Address(RVA = "0x353AEBC", Offset = "0x353AEBC", VA = "0x353AEBC")]
		private void method_13()
		{
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float z = this.vector3_4.z;
			this.vector3_5.z = z;
		}

		// Token: 0x06003AA8 RID: 15016 RVA: 0x0007394C File Offset: 0x00071B4C
		[Address(RVA = "0x353B4BC", Offset = "0x353B4BC", VA = "0x353B4BC")]
		[Token(Token = "0x6003AA8")]
		private void Update()
		{
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float z = this.vector3_4.z;
			this.vector3_5.z = z;
		}

		// Token: 0x06003AA9 RID: 15017 RVA: 0x00073994 File Offset: 0x00071B94
		[Token(Token = "0x6003AA9")]
		[Address(RVA = "0x353B7C4", Offset = "0x353B7C4", VA = "0x353B7C4")]
		private void method_14()
		{
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float z = this.vector3_4.z;
			this.vector3_5.z = z;
		}

		// Token: 0x06003AAA RID: 15018 RVA: 0x000739DC File Offset: 0x00071BDC
		[Address(RVA = "0x353BD6C", Offset = "0x353BD6C", VA = "0x353BD6C")]
		[Token(Token = "0x6003AAA")]
		private void method_15()
		{
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float z = this.vector3_4.z;
			this.vector3_5.z = z;
		}

		// Token: 0x06003AAB RID: 15019 RVA: 0x00073A24 File Offset: 0x00071C24
		[Token(Token = "0x6003AAB")]
		[Address(RVA = "0x353C08C", Offset = "0x353C08C", VA = "0x353C08C")]
		public static float smethod_2(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AAB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_2(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AAC RID: 15020 RVA: 0x00009500 File Offset: 0x00007700
		[Token(Token = "0x6003AAC")]
		[Address(RVA = "0x353C0D4", Offset = "0x353C0D4", VA = "0x353C0D4")]
		private IEnumerator method_16(float float_5)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003AAD RID: 15021 RVA: 0x00073A44 File Offset: 0x00071C44
		[Address(RVA = "0x353C15C", Offset = "0x353C15C", VA = "0x353C15C")]
		[Token(Token = "0x6003AAD")]
		public bool method_17(int int_2)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003AAE RID: 15022 RVA: 0x00073A58 File Offset: 0x00071C58
		[Token(Token = "0x6003AAE")]
		[Address(RVA = "0x353C198", Offset = "0x353C198", VA = "0x353C198")]
		public proceduralAnimation()
		{
			long num = 1065353216L;
			this.cycleSpeed = (float)num;
			this.timigsOffset = 0f;
			Keyframe[] array = new Keyframe[3];
			if (array.m_OutWeight == null)
			{
				throw new IndexOutOfRangeException();
			}
			AnimationCurve animationCurve = new AnimationCurve(array);
			this.legArcPathY = animationCurve;
			AnimationCurve animationCurve2;
			this.easingFunction = animationCurve2;
			long num2 = 1L;
			this.bool_0 = (num2 != 0L);
			base..ctor();
		}

		// Token: 0x06003AAF RID: 15023 RVA: 0x000737B0 File Offset: 0x000719B0
		[Address(RVA = "0x353C3A8", Offset = "0x353C3A8", VA = "0x353C3A8")]
		[Token(Token = "0x6003AAF")]
		private void method_18(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003AB0 RID: 15024 RVA: 0x00073810 File Offset: 0x00071A10
		[Address(RVA = "0x353C51C", Offset = "0x353C51C", VA = "0x353C51C")]
		[Token(Token = "0x6003AB0")]
		public float method_19(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06003AB1 RID: 15025 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Token(Token = "0x6003AB1")]
		[Address(RVA = "0x353C674", Offset = "0x353C674", VA = "0x353C674")]
		private IEnumerator method_20(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003AB2 RID: 15026 RVA: 0x00073810 File Offset: 0x00071A10
		[Token(Token = "0x6003AB2")]
		[Address(RVA = "0x353C720", Offset = "0x353C720", VA = "0x353C720")]
		public float method_21(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06003AB3 RID: 15027 RVA: 0x0000374C File Offset: 0x0000194C
		[Address(RVA = "0x353C878", Offset = "0x353C878", VA = "0x353C878")]
		[Token(Token = "0x6003AB3")]
		public LayerMask method_22()
		{
			return this.layerMask;
		}

		// Token: 0x06003AB4 RID: 15028 RVA: 0x00003744 File Offset: 0x00001944
		[Token(Token = "0x6003AB4")]
		[Address(RVA = "0x353C880", Offset = "0x353C880", VA = "0x353C880")]
		public Transform[] method_23()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AB5 RID: 15029 RVA: 0x00073ABC File Offset: 0x00071CBC
		[Address(RVA = "0x353C888", Offset = "0x353C888", VA = "0x353C888")]
		[Token(Token = "0x6003AB5")]
		private void method_24()
		{
			this.vector3_1 = typeof(Vector3[]).TypeHandle;
			Vector3[] array = new Vector3[this.int_0];
			this.vector3_0 = array;
			Vector3[] array2 = new Vector3[this.int_0];
			this.vector3_3 = array2;
			bool[] array3 = new bool[this.int_0];
			this.bool_1 = array3;
			float[] array4 = new float[this.int_0];
			this.float_0 = array4;
			float[] array5 = new float[this.int_0];
			this.float_4 = array5;
			float[] array6 = new float[this.int_0];
			this.float_2 = array6;
			if (this.SetTimingsManually)
			{
				Debug.LogError("_Tint");
			}
			float[] array7;
			if (this.SetTimingsManually)
			{
				array7 = this.manualTimings;
				return;
			}
			if (array7 != null)
			{
				Transform[] array8 = this.legIktargets;
				if (array7 != null && array8 != null)
				{
					Transform[] array9 = this.legIktargets;
					if (array7 != null && array9 != null)
					{
						IEnumerator routine;
						base.StartCoroutine(routine);
						return;
					}
				}
			}
			throw new IndexOutOfRangeException();
		}

		// Token: 0x06003AB6 RID: 15030 RVA: 0x00073BA4 File Offset: 0x00071DA4
		[Address(RVA = "0x353BAAC", Offset = "0x353BAAC", VA = "0x353BAAC")]
		[Token(Token = "0x6003AB6")]
		public void method_25(int int_2)
		{
			Transform transform = base.transform;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			this.method_94(int_2);
			Vector3 zero = Vector3.zero;
			IEnumerator routine;
			base.StartCoroutine(routine);
		}

		// Token: 0x06003AB7 RID: 15031 RVA: 0x00003744 File Offset: 0x00001944
		[Address(RVA = "0x353CD4C", Offset = "0x353CD4C", VA = "0x353CD4C")]
		[Token(Token = "0x6003AB7")]
		public Transform[] method_26()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AB8 RID: 15032 RVA: 0x00073BDC File Offset: 0x00071DDC
		[Token(Token = "0x6003AB8")]
		[Address(RVA = "0x353CD54", Offset = "0x353CD54", VA = "0x353CD54")]
		public float method_27()
		{
			/*
An exception occurred when decompiling this method (06003AB8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_27()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(0)); 	call:float32(proceduralAnimation::method_62, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AB9 RID: 15033 RVA: 0x000737F0 File Offset: 0x000719F0
		[Token(Token = "0x6003AB9")]
		[Address(RVA = "0x353CF10", Offset = "0x353CF10", VA = "0x353CF10")]
		public static float smethod_3(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AB9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_3(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003ABA RID: 15034 RVA: 0x00073BF4 File Offset: 0x00071DF4
		[Address(RVA = "0x353CF58", Offset = "0x353CF58", VA = "0x353CF58")]
		[Token(Token = "0x6003ABA")]
		public float method_28()
		{
			/*
An exception occurred when decompiling this method (06003ABA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_28()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(0)); 	call:float32(proceduralAnimation::method_3, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003ABB RID: 15035 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Address(RVA = "0x353CFC4", Offset = "0x353CFC4", VA = "0x353CFC4")]
		[Token(Token = "0x6003ABB")]
		private float method_29(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003ABC RID: 15036 RVA: 0x000737C8 File Offset: 0x000719C8
		[Address(RVA = "0x353D09C", Offset = "0x353D09C", VA = "0x353D09C")]
		[Token(Token = "0x6003ABC")]
		private IEnumerator method_30(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003ABD RID: 15037 RVA: 0x00073A44 File Offset: 0x00071C44
		[Address(RVA = "0x353D124", Offset = "0x353D124", VA = "0x353D124")]
		[Token(Token = "0x6003ABD")]
		public bool method_31(int int_2)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003ABE RID: 15038 RVA: 0x00073C28 File Offset: 0x00071E28
		[Token(Token = "0x6003ABE")]
		[Address(RVA = "0x353D160", Offset = "0x353D160", VA = "0x353D160")]
		private void method_32()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003ABF RID: 15039 RVA: 0x000737C8 File Offset: 0x000719C8
		[Address(RVA = "0x353D3DC", Offset = "0x353D3DC", VA = "0x353D3DC")]
		[Token(Token = "0x6003ABF")]
		private IEnumerator method_33(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003AC0 RID: 15040 RVA: 0x000737F0 File Offset: 0x000719F0
		[Address(RVA = "0x353B170", Offset = "0x353B170", VA = "0x353B170")]
		[Token(Token = "0x6003AC0")]
		public static float smethod_4(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AC0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_4(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AC1 RID: 15041 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Address(RVA = "0x353D464", Offset = "0x353D464", VA = "0x353D464")]
		[Token(Token = "0x6003AC1")]
		private float method_34(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003AC2 RID: 15042 RVA: 0x00073904 File Offset: 0x00071B04
		[Address(RVA = "0x353D53C", Offset = "0x353D53C", VA = "0x353D53C")]
		[Token(Token = "0x6003AC2")]
		private void method_35()
		{
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float z = this.vector3_4.z;
			this.vector3_5.z = z;
		}

		// Token: 0x06003AC3 RID: 15043 RVA: 0x00003744 File Offset: 0x00001944
		[Token(Token = "0x6003AC3")]
		[Address(RVA = "0x353D818", Offset = "0x353D818", VA = "0x353D818")]
		public Transform[] method_36()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AC4 RID: 15044 RVA: 0x00003744 File Offset: 0x00001944
		[Address(RVA = "0x353D820", Offset = "0x353D820", VA = "0x353D820")]
		[Token(Token = "0x6003AC4")]
		public Transform[] method_37()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AC5 RID: 15045 RVA: 0x00003744 File Offset: 0x00001944
		[Address(RVA = "0x353D828", Offset = "0x353D828", VA = "0x353D828")]
		[Token(Token = "0x6003AC5")]
		public Transform[] method_38()
		{
			return this.legIktargets;
		}

		// Token: 0x06003AC6 RID: 15046 RVA: 0x00073C80 File Offset: 0x00071E80
		[Address(RVA = "0x3539FE8", Offset = "0x3539FE8", VA = "0x3539FE8")]
		[Token(Token = "0x6003AC6")]
		public void method_39(int int_2)
		{
			Transform transform = base.transform;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			this.method_89(int_2);
			Vector3 zero = Vector3.zero;
			IEnumerator routine;
			base.StartCoroutine(routine);
		}

		// Token: 0x06003AC7 RID: 15047 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Address(RVA = "0x353D9B4", Offset = "0x353D9B4", VA = "0x353D9B4")]
		[Token(Token = "0x6003AC7")]
		private float method_40(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003AC8 RID: 15048 RVA: 0x00073CB8 File Offset: 0x00071EB8
		[Address(RVA = "0x353DA8C", Offset = "0x353DA8C", VA = "0x353DA8C")]
		[Token(Token = "0x6003AC8")]
		private void method_41()
		{
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			float deltaTime2 = Time.deltaTime;
			Vector3 vector;
			float magnitude = vector.magnitude;
			float z = this.vector3_4.z;
			this.vector3_5.z = z;
		}

		// Token: 0x06003AC9 RID: 15049 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Address(RVA = "0x353DD58", Offset = "0x353DD58", VA = "0x353DD58")]
		[Token(Token = "0x6003AC9")]
		private IEnumerator method_42(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003ACA RID: 15050 RVA: 0x00073A44 File Offset: 0x00071C44
		[Token(Token = "0x6003ACA")]
		[Address(RVA = "0x353DE04", Offset = "0x353DE04", VA = "0x353DE04")]
		public bool method_43(int int_2)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003ACB RID: 15051 RVA: 0x00073D00 File Offset: 0x00071F00
		[Address(RVA = "0x353DE40", Offset = "0x353DE40", VA = "0x353DE40")]
		[Token(Token = "0x6003ACB")]
		private void method_44()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
			}
		}

		// Token: 0x06003ACC RID: 15052 RVA: 0x000737C8 File Offset: 0x000719C8
		[Address(RVA = "0x353E0BC", Offset = "0x353E0BC", VA = "0x353E0BC")]
		[Token(Token = "0x6003ACC")]
		private IEnumerator method_45(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003ACD RID: 15053 RVA: 0x000737C8 File Offset: 0x000719C8
		[Token(Token = "0x6003ACD")]
		[Address(RVA = "0x353CB40", Offset = "0x353CB40", VA = "0x353CB40")]
		private IEnumerator method_46(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003ACE RID: 15054 RVA: 0x000737F0 File Offset: 0x000719F0
		[Token(Token = "0x6003ACE")]
		[Address(RVA = "0x3539F58", Offset = "0x3539F58", VA = "0x3539F58")]
		public static float smethod_5(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003ACE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_5(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003ACF RID: 15055 RVA: 0x00073BF4 File Offset: 0x00071DF4
		[Address(RVA = "0x353E144", Offset = "0x353E144", VA = "0x353E144")]
		[Token(Token = "0x6003ACF")]
		public float method_47()
		{
			/*
An exception occurred when decompiling this method (06003ACF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_47()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(0)); 	call:float32(proceduralAnimation::method_3, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AD0 RID: 15056 RVA: 0x00073D40 File Offset: 0x00071F40
		[Address(RVA = "0x353E1B0", Offset = "0x353E1B0", VA = "0x353E1B0")]
		[Token(Token = "0x6003AD0")]
		private IEnumerator method_48(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003AD1 RID: 15057 RVA: 0x00073D68 File Offset: 0x00071F68
		[Address(RVA = "0x353B200", Offset = "0x353B200", VA = "0x353B200")]
		[Token(Token = "0x6003AD1")]
		public void method_49(int int_2)
		{
			Transform transform = base.transform;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			this.method_40(int_2);
			Vector3 zero = Vector3.zero;
			IEnumerator routine;
			base.StartCoroutine(routine);
		}

		// Token: 0x06003AD2 RID: 15058 RVA: 0x000737C8 File Offset: 0x000719C8
		[Token(Token = "0x6003AD2")]
		[Address(RVA = "0x353E25C", Offset = "0x353E25C", VA = "0x353E25C")]
		private IEnumerator method_50(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003AD3 RID: 15059 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Address(RVA = "0x353E2E4", Offset = "0x353E2E4", VA = "0x353E2E4")]
		[Token(Token = "0x6003AD3")]
		private float method_51(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003AD4 RID: 15060 RVA: 0x0000374C File Offset: 0x0000194C
		[Address(RVA = "0x353E3BC", Offset = "0x353E3BC", VA = "0x353E3BC")]
		[Token(Token = "0x6003AD4")]
		public LayerMask method_52()
		{
			return this.layerMask;
		}

		// Token: 0x06003AD5 RID: 15061 RVA: 0x00073DA0 File Offset: 0x00071FA0
		[Address(RVA = "0x353D908", Offset = "0x353D908", VA = "0x353D908")]
		[Token(Token = "0x6003AD5")]
		private IEnumerator method_53(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003AD6 RID: 15062 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Token(Token = "0x6003AD6")]
		[Address(RVA = "0x353E3C4", Offset = "0x353E3C4", VA = "0x353E3C4")]
		private float method_54(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003AD7 RID: 15063 RVA: 0x00073DC8 File Offset: 0x00071FC8
		[Address(RVA = "0x353E49C", Offset = "0x353E49C", VA = "0x353E49C")]
		[Token(Token = "0x6003AD7")]
		private void method_55()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003AD8 RID: 15064 RVA: 0x000737C8 File Offset: 0x000719C8
		[Address(RVA = "0x353E6E8", Offset = "0x353E6E8", VA = "0x353E6E8")]
		[Token(Token = "0x6003AD8")]
		private IEnumerator method_56(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003AD9 RID: 15065 RVA: 0x000737B0 File Offset: 0x000719B0
		[Address(RVA = "0x353E770", Offset = "0x353E770", VA = "0x353E770")]
		[Token(Token = "0x6003AD9")]
		private void method_57(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003ADA RID: 15066 RVA: 0x00073E20 File Offset: 0x00072020
		[Address(RVA = "0x353E8E4", Offset = "0x353E8E4", VA = "0x353E8E4")]
		[Token(Token = "0x6003ADA")]
		private void method_58(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003ADB RID: 15067 RVA: 0x0000374C File Offset: 0x0000194C
		[Address(RVA = "0x353EA54", Offset = "0x353EA54", VA = "0x353EA54")]
		[Token(Token = "0x6003ADB")]
		public LayerMask method_59()
		{
			return this.layerMask;
		}

		// Token: 0x06003ADC RID: 15068 RVA: 0x00073E38 File Offset: 0x00072038
		[Address(RVA = "0x353EA5C", Offset = "0x353EA5C", VA = "0x353EA5C")]
		[Token(Token = "0x6003ADC")]
		private void method_60()
		{
			this.vector3_1 = typeof(Vector3[]).TypeHandle;
			Vector3[] array = new Vector3[this.int_0];
			this.vector3_0 = array;
			Vector3[] array2 = new Vector3[this.int_0];
			this.vector3_3 = array2;
			bool[] array3 = new bool[this.int_0];
			this.bool_1 = array3;
			float[] array4 = new float[this.int_0];
			this.float_0 = array4;
			float[] array5 = new float[this.int_0];
			this.float_4 = array5;
			float[] array6 = new float[this.int_0];
			this.float_2 = array6;
			if (this.SetTimingsManually)
			{
				Debug.LogError("username");
			}
			float[] array7;
			if (this.SetTimingsManually)
			{
				array7 = this.manualTimings;
				return;
			}
			if (array7 != null)
			{
				Transform[] array8 = this.legIktargets;
				if (array7 != null && array8 != null)
				{
					Transform[] array9 = this.legIktargets;
					if (array7 != null && array9 != null)
					{
						return;
					}
				}
			}
			throw new IndexOutOfRangeException();
		}

		// Token: 0x06003ADD RID: 15069 RVA: 0x000737B0 File Offset: 0x000719B0
		[Address(RVA = "0x353ED14", Offset = "0x353ED14", VA = "0x353ED14")]
		[Token(Token = "0x6003ADD")]
		private void method_61(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003ADE RID: 15070 RVA: 0x00073F18 File Offset: 0x00072118
		[Address(RVA = "0x353EE88", Offset = "0x353EE88", VA = "0x353EE88")]
		[Token(Token = "0x6003ADE")]
		private void Start()
		{
			this.vector3_1 = typeof(Vector3[]).TypeHandle;
			Vector3[] array = new Vector3[this.int_0];
			this.vector3_3 = array;
			bool[] array2 = new bool[this.int_0];
			this.bool_1 = array2;
			float[] array3 = new float[this.int_0];
			this.float_0 = array3;
			float[] array4 = new float[this.int_0];
			this.float_4 = array4;
			float[] array5 = new float[this.int_0];
			this.float_2 = array5;
			if (this.SetTimingsManually)
			{
				Debug.LogError("manual footTimings length should be equal to the leg count");
			}
			if (this.SetTimingsManually)
			{
				return;
			}
			IEnumerator routine;
			base.StartCoroutine(routine);
		}

		// Token: 0x06003ADF RID: 15071 RVA: 0x00073810 File Offset: 0x00071A10
		[Address(RVA = "0x353CDB8", Offset = "0x353CDB8", VA = "0x353CDB8")]
		[Token(Token = "0x6003ADF")]
		public float method_62(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06003AE0 RID: 15072 RVA: 0x00073A44 File Offset: 0x00071C44
		[Address(RVA = "0x353F21C", Offset = "0x353F21C", VA = "0x353F21C")]
		[Token(Token = "0x6003AE0")]
		public bool method_63(int int_2)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003AE1 RID: 15073 RVA: 0x00073C28 File Offset: 0x00071E28
		[Address(RVA = "0x353F258", Offset = "0x353F258", VA = "0x353F258")]
		[Token(Token = "0x6003AE1")]
		private void method_64()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003AE2 RID: 15074 RVA: 0x000737B0 File Offset: 0x000719B0
		[Address(RVA = "0x353F4D4", Offset = "0x353F4D4", VA = "0x353F4D4")]
		[Token(Token = "0x6003AE2")]
		private void method_65(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003AE3 RID: 15075 RVA: 0x00073C28 File Offset: 0x00071E28
		[Address(RVA = "0x353F648", Offset = "0x353F648", VA = "0x353F648")]
		[Token(Token = "0x6003AE3")]
		private void OnDrawGizmosSelected()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003AE4 RID: 15076 RVA: 0x0000374C File Offset: 0x0000194C
		[Address(RVA = "0x353F8BC", Offset = "0x353F8BC", VA = "0x353F8BC")]
		[Token(Token = "0x6003AE4")]
		public LayerMask method_66()
		{
			return this.layerMask;
		}

		// Token: 0x06003AE5 RID: 15077 RVA: 0x00073810 File Offset: 0x00071A10
		[Address(RVA = "0x353A8C0", Offset = "0x353A8C0", VA = "0x353A8C0")]
		[Token(Token = "0x6003AE5")]
		public float method_67(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06003AE6 RID: 15078 RVA: 0x00073A44 File Offset: 0x00071C44
		[Token(Token = "0x6003AE6")]
		[Address(RVA = "0x353F8C4", Offset = "0x353F8C4", VA = "0x353F8C4")]
		public bool method_68(int int_2)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003AE7 RID: 15079 RVA: 0x00073A44 File Offset: 0x00071C44
		[Address(RVA = "0x353F900", Offset = "0x353F900", VA = "0x353F900")]
		[Token(Token = "0x6003AE7")]
		public bool method_69(int int_2)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003AE8 RID: 15080 RVA: 0x000737F0 File Offset: 0x000719F0
		[Address(RVA = "0x353C044", Offset = "0x353C044", VA = "0x353C044")]
		[Token(Token = "0x6003AE8")]
		public static float smethod_6(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AE8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_6(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AE9 RID: 15081 RVA: 0x0000374C File Offset: 0x0000194C
		[Address(RVA = "0x353F93C", Offset = "0x353F93C", VA = "0x353F93C")]
		[Token(Token = "0x6003AE9")]
		public LayerMask method_70()
		{
			return this.layerMask;
		}

		// Token: 0x06003AEA RID: 15082 RVA: 0x00073FBC File Offset: 0x000721BC
		[Address(RVA = "0x353F944", Offset = "0x353F944", VA = "0x353F944")]
		[Token(Token = "0x6003AEA")]
		private void method_71()
		{
			this.vector3_1 = typeof(Vector3[]).TypeHandle;
			Vector3[] array = new Vector3[this.int_0];
			this.vector3_0 = array;
			Vector3[] array2 = new Vector3[this.int_0];
			this.vector3_3 = array2;
			bool[] array3 = new bool[this.int_0];
			this.bool_1 = array3;
			float[] array4 = new float[this.int_0];
			this.float_0 = array4;
			float[] array5 = new float[this.int_0];
			this.float_4 = array5;
			float[] array6 = new float[this.int_0];
			this.float_2 = array6;
			if (this.SetTimingsManually)
			{
				Debug.LogError("Agreed");
			}
			if (this.SetTimingsManually)
			{
				return;
			}
			IEnumerator routine;
			base.StartCoroutine(routine);
		}

		// Token: 0x06003AEB RID: 15083 RVA: 0x00073C28 File Offset: 0x00071E28
		[Token(Token = "0x6003AEB")]
		[Address(RVA = "0x353FC14", Offset = "0x353FC14", VA = "0x353FC14")]
		private void method_72()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003AEC RID: 15084 RVA: 0x00074070 File Offset: 0x00072270
		[Token(Token = "0x6003AEC")]
		[Address(RVA = "0x353F194", Offset = "0x353F194", VA = "0x353F194")]
		private IEnumerator method_73(float float_5)
		{
			proceduralAnimation.Class59 @class;
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003AED RID: 15085 RVA: 0x0007408C File Offset: 0x0007228C
		[Address(RVA = "0x353A6B0", Offset = "0x353A6B0", VA = "0x353A6B0")]
		[Token(Token = "0x6003AED")]
		public float method_74(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			throw new NullReferenceException();
		}

		// Token: 0x06003AEE RID: 15086 RVA: 0x000740AC File Offset: 0x000722AC
		[Token(Token = "0x6003AEE")]
		[Address(RVA = "0x353FE90", Offset = "0x353FE90", VA = "0x353FE90")]
		private void method_75()
		{
			this.vector3_1 = typeof(Vector3[]).TypeHandle;
			Vector3[] array = new Vector3[this.int_0];
			this.vector3_0 = array;
			Vector3[] array2 = new Vector3[this.int_0];
			this.vector3_3 = array2;
			bool[] array3 = new bool[this.int_0];
			this.bool_1 = array3;
			float[] array4 = new float[this.int_0];
			this.float_0 = array4;
			float[] array5 = new float[this.int_0];
			this.float_4 = array5;
			float[] array6 = new float[this.int_0];
			this.float_2 = array6;
			if (this.SetTimingsManually)
			{
				Debug.LogError("TurnAmount");
			}
			if (this.SetTimingsManually)
			{
				return;
			}
			IEnumerator routine;
			base.StartCoroutine(routine);
		}

		// Token: 0x06003AEF RID: 15087 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Token(Token = "0x6003AEF")]
		[Address(RVA = "0x3540160", Offset = "0x3540160", VA = "0x3540160")]
		private float method_76(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003AF0 RID: 15088 RVA: 0x000737F0 File Offset: 0x000719F0
		[Address(RVA = "0x353B77C", Offset = "0x353B77C", VA = "0x353B77C")]
		[Token(Token = "0x6003AF0")]
		public static float smethod_7(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AF0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_7(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AF1 RID: 15089 RVA: 0x000737B0 File Offset: 0x000719B0
		[Token(Token = "0x6003AF1")]
		[Address(RVA = "0x3540238", Offset = "0x3540238", VA = "0x3540238")]
		private void method_77(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003AF2 RID: 15090 RVA: 0x00073810 File Offset: 0x00071A10
		[Token(Token = "0x6003AF2")]
		[Address(RVA = "0x35403AC", Offset = "0x35403AC", VA = "0x35403AC")]
		public float method_78(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06003AF3 RID: 15091 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Address(RVA = "0x3540504", Offset = "0x3540504", VA = "0x3540504")]
		[Token(Token = "0x6003AF3")]
		private float method_79(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003AF4 RID: 15092 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Address(RVA = "0x35405DC", Offset = "0x35405DC", VA = "0x35405DC")]
		[Token(Token = "0x6003AF4")]
		private IEnumerator method_80(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003AF5 RID: 15093 RVA: 0x00073C28 File Offset: 0x00071E28
		[Address(RVA = "0x3540688", Offset = "0x3540688", VA = "0x3540688")]
		[Token(Token = "0x6003AF5")]
		private void method_81()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003AF6 RID: 15094 RVA: 0x000737F0 File Offset: 0x000719F0
		[Token(Token = "0x6003AF6")]
		[Address(RVA = "0x353B1B8", Offset = "0x353B1B8", VA = "0x353B1B8")]
		public static float smethod_8(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AF6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_8(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AF7 RID: 15095 RVA: 0x000737C8 File Offset: 0x000719C8
		[Token(Token = "0x6003AF7")]
		[Address(RVA = "0x3540904", Offset = "0x3540904", VA = "0x3540904")]
		private IEnumerator method_82(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003AF8 RID: 15096 RVA: 0x000737C8 File Offset: 0x000719C8
		[Token(Token = "0x6003AF8")]
		[Address(RVA = "0x354098C", Offset = "0x354098C", VA = "0x354098C")]
		private IEnumerator method_83(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003AF9 RID: 15097 RVA: 0x00073810 File Offset: 0x00071A10
		[Token(Token = "0x6003AF9")]
		[Address(RVA = "0x3540A14", Offset = "0x3540A14", VA = "0x3540A14")]
		public float method_84(int int_2)
		{
			Vector3 up = Vector3.up;
			Vector3 up2 = Vector3.up;
			this.layerMask;
			throw new NullReferenceException();
		}

		// Token: 0x06003AFA RID: 15098 RVA: 0x000737F0 File Offset: 0x000719F0
		[Address(RVA = "0x3540B6C", Offset = "0x3540B6C", VA = "0x3540B6C")]
		[Token(Token = "0x6003AFA")]
		public static float smethod_9(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003AFA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_9(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003AFB RID: 15099 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Address(RVA = "0x3540BB4", Offset = "0x3540BB4", VA = "0x3540BB4")]
		[Token(Token = "0x6003AFB")]
		private IEnumerator method_85(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003AFC RID: 15100 RVA: 0x00074160 File Offset: 0x00072360
		[Token(Token = "0x6003AFC")]
		[Address(RVA = "0x3540C60", Offset = "0x3540C60", VA = "0x3540C60")]
		public void method_86(int int_2)
		{
			Transform transform = base.transform;
			Vector3 vector;
			float magnitude = vector.normalized.magnitude;
			this.method_29(int_2);
			Vector3 zero = Vector3.zero;
			IEnumerator routine;
			base.StartCoroutine(routine);
		}

		// Token: 0x06003AFD RID: 15101 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Token(Token = "0x6003AFD")]
		[Address(RVA = "0x3540F20", Offset = "0x3540F20", VA = "0x3540F20")]
		private IEnumerator method_87(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003AFE RID: 15102 RVA: 0x00073A44 File Offset: 0x00071C44
		[Token(Token = "0x6003AFE")]
		[Address(RVA = "0x3540FCC", Offset = "0x3540FCC", VA = "0x3540FCC")]
		public bool method_88(int int_2)
		{
			throw new NullReferenceException();
		}

		// Token: 0x06003AFF RID: 15103 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Token(Token = "0x6003AFF")]
		[Address(RVA = "0x353D830", Offset = "0x353D830", VA = "0x353D830")]
		private float method_89(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003B00 RID: 15104 RVA: 0x000737C8 File Offset: 0x000719C8
		[Token(Token = "0x6003B00")]
		[Address(RVA = "0x3541008", Offset = "0x3541008", VA = "0x3541008")]
		private IEnumerator method_90(float float_5)
		{
			proceduralAnimation.Class59 @class = new proceduralAnimation.Class59((int)0L);
			@class.<>4__this = this;
			throw new NullReferenceException();
		}

		// Token: 0x06003B01 RID: 15105 RVA: 0x00074198 File Offset: 0x00072398
		[Token(Token = "0x6003B01")]
		[Address(RVA = "0x3541090", Offset = "0x3541090", VA = "0x3541090")]
		public float method_91()
		{
			/*
An exception occurred when decompiling this method (06003B01)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_91()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(1)); 	call:float32(proceduralAnimation::method_3, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003B02 RID: 15106 RVA: 0x00073E20 File Offset: 0x00072020
		[Token(Token = "0x6003B02")]
		[Address(RVA = "0x35410F4", Offset = "0x35410F4", VA = "0x35410F4")]
		private void method_92(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003B03 RID: 15107 RVA: 0x0007383C File Offset: 0x00071A3C
		[Token(Token = "0x6003B03")]
		[Address(RVA = "0x3541264", Offset = "0x3541264", VA = "0x3541264")]
		public float method_93()
		{
			/*
An exception occurred when decompiling this method (06003B03)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_93()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(1)); 	call:float32(proceduralAnimation::method_74, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003B04 RID: 15108 RVA: 0x00073C0C File Offset: 0x00071E0C
		[Token(Token = "0x6003B04")]
		[Address(RVA = "0x353CBC8", Offset = "0x353CBC8", VA = "0x353CBC8")]
		private float method_94(int int_2)
		{
			Transform transform = base.transform;
			throw new NullReferenceException();
		}

		// Token: 0x06003B05 RID: 15109 RVA: 0x000741B0 File Offset: 0x000723B0
		[Token(Token = "0x6003B05")]
		[Address(RVA = "0x35412D0", Offset = "0x35412D0", VA = "0x35412D0")]
		private void method_95()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003B06 RID: 15110 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Address(RVA = "0x353CCA0", Offset = "0x353CCA0", VA = "0x353CCA0")]
		[Token(Token = "0x6003B06")]
		private IEnumerator method_96(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x06003B07 RID: 15111 RVA: 0x000737F0 File Offset: 0x000719F0
		[Token(Token = "0x6003B07")]
		[Address(RVA = "0x3539FA0", Offset = "0x3539FA0", VA = "0x3539FA0")]
		public static float smethod_10(float float_5, float float_6, float float_7, float float_8, float float_9)
		{
			/*
An exception occurred when decompiling this method (06003B07)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::smethod_10(System.Single,System.Single,System.Single,System.Single,System.Single)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:float32(var_1_08, call:float32(Mathf::InverseLerp, ldloc:float32(float_5), ldloc:float32(float_6), ldloc:float32(float_7))); 	call:float32(Mathf::Lerp, ldloc:float32(float_7), ldloc:float32(float_8), ldloc:float32(var_1_08)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003B08 RID: 15112 RVA: 0x00073854 File Offset: 0x00071A54
		[Token(Token = "0x6003B08")]
		[Address(RVA = "0x3541528", Offset = "0x3541528", VA = "0x3541528")]
		public float method_97()
		{
			/*
An exception occurred when decompiling this method (06003B08)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Single Lolopupka.proceduralAnimation::method_97()

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	stloc:int64(var_1_01, ldc.i4:int64(0)); 	call:float32(proceduralAnimation::method_67, ldloc:proceduralAnimation(this), ldloc:int64[exp:int32](var_1_01)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 99
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06003B09 RID: 15113 RVA: 0x00073C28 File Offset: 0x00071E28
		[Address(RVA = "0x3541594", Offset = "0x3541594", VA = "0x3541594")]
		[Token(Token = "0x6003B09")]
		private void method_98()
		{
			if (this.bool_0)
			{
				Application.IsPlaying(this);
				Transform transform = base.transform;
				Vector3 vector;
				float magnitude = vector.normalized.magnitude;
				Color blue = Color.blue;
				Color green = Color.green;
				Transform transform2 = base.transform;
				Vector3 up = Vector3.up;
				Vector3 up2 = Vector3.up;
				Transform transform3 = base.transform;
			}
		}

		// Token: 0x06003B0A RID: 15114 RVA: 0x00074208 File Offset: 0x00072408
		[Token(Token = "0x6003B0A")]
		[Address(RVA = "0x3541810", Offset = "0x3541810", VA = "0x3541810")]
		private void method_99(Vector3 vector3_7, int int_2)
		{
			if (this.eventHandler_0 == null)
			{
			}
		}

		// Token: 0x06003B0B RID: 15115 RVA: 0x000738D4 File Offset: 0x00071AD4
		[Address(RVA = "0x3541984", Offset = "0x3541984", VA = "0x3541984")]
		[Token(Token = "0x6003B0B")]
		private IEnumerator method_100(Vector3 vector3_7, int int_2)
		{
			proceduralAnimation.Class58 @class = new proceduralAnimation.Class58((int)0L);
			@class.<>4__this = this;
			@class.index = vector3_7;
			throw new NullReferenceException();
		}

		// Token: 0x04000A2D RID: 2605
		[Token(Token = "0x4000A2D")]
		[FieldOffset(Offset = "0x18")]
		[SerializeField]
		[Tooltip("Step distance is used to calculate step height. When character makes a short step there is no need to rase foot all the way up so if the current step distance is less then this step distance value step height will be lover then usual.")]
		private float stepDistance;

		// Token: 0x04000A2E RID: 2606
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000A2E")]
		[SerializeField]
		private float stepHeight;

		// Token: 0x04000A2F RID: 2607
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000A2F")]
		[SerializeField]
		private float stepSpeed;

		// Token: 0x04000A30 RID: 2608
		[Tooltip("Velocity multiplier used to make step wider when moving on high speed (if you toggle the show gizmoz below and move your model around you could clearly see what this does. The blue spheres represent the target step points and will move further ahead if you increase velocity multiplier)")]
		[Token(Token = "0x4000A30")]
		[SerializeField]
		[FieldOffset(Offset = "0x24")]
		private float velocityMultiplier;

		// Token: 0x04000A31 RID: 2609
		[Token(Token = "0x4000A31")]
		[SerializeField]
		[FieldOffset(Offset = "0x28")]
		private float cycleSpeed;

		// Token: 0x04000A32 RID: 2610
		[Tooltip("how often in seconds legs will move (every one second by default)")]
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4000A32")]
		[SerializeField]
		private float cycleLimit;

		// Token: 0x04000A33 RID: 2611
		[SerializeField]
		[Token(Token = "0x4000A33")]
		[Tooltip("â\u0080¢\tIf you want some legs to move together enable the Set Timings Manually. And add as many timings as your model has legs. The first Manual Timing is relative to the first leg in the leg IK targets array etc. For example: if your character has four legs and you want two left legs move first and two right to move second you need to set timings to [0.5, 0.5, 0, 0]. That means that first two legs will move and only 0.5 second later the second two will move. ")]
		[FieldOffset(Offset = "0x30")]
		private bool SetTimingsManually;

		// Token: 0x04000A34 RID: 2612
		[SerializeField]
		[Token(Token = "0x4000A34")]
		[FieldOffset(Offset = "0x38")]
		private float[] manualTimings;

		// Token: 0x04000A35 RID: 2613
		[FieldOffset(Offset = "0x40")]
		[Tooltip("If you want only one leg to move at a time then set Timings offset as one divided by the number of legs. For example: if your character has four legs you need to set this as Â¼ = 0.25. The script will offset the cycle of every leg by 0.25 seconds. ")]
		[SerializeField]
		[Token(Token = "0x4000A35")]
		private float timigsOffset;

		// Token: 0x04000A36 RID: 2614
		[Token(Token = "0x4000A36")]
		[FieldOffset(Offset = "0x44")]
		[Tooltip("Velocity clamp limits the step distance while moving on high speed.")]
		[SerializeField]
		private float velocityClamp;

		// Token: 0x04000A37 RID: 2615
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4000A37")]
		[SerializeField]
		private LayerMask layerMask;

		// Token: 0x04000A38 RID: 2616
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4000A38")]
		[SerializeField]
		private AnimationCurve legArcPathY;

		// Token: 0x04000A39 RID: 2617
		[FieldOffset(Offset = "0x58")]
		[SerializeField]
		[Token(Token = "0x4000A39")]
		private AnimationCurve easingFunction;

		// Token: 0x04000A3A RID: 2618
		[Token(Token = "0x4000A3A")]
		[SerializeField]
		[FieldOffset(Offset = "0x60")]
		private Transform[] legIktargets;

		// Token: 0x04000A3B RID: 2619
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x4000A3B")]
		public bool bool_0;

		// Token: 0x04000A3C RID: 2620
		[Token(Token = "0x4000A3C")]
		[FieldOffset(Offset = "0x6C")]
		[SerializeField]
		private float legRayoffset;

		// Token: 0x04000A3D RID: 2621
		[Token(Token = "0x4000A3D")]
		[FieldOffset(Offset = "0x70")]
		[SerializeField]
		private float legRayLength;

		// Token: 0x04000A3E RID: 2622
		[SerializeField]
		[FieldOffset(Offset = "0x74")]
		[Tooltip("Ground check range for every leg")]
		[Token(Token = "0x4000A3E")]
		private float sphereCastRadius;

		// Token: 0x04000A3F RID: 2623
		[SerializeField]
		[Token(Token = "0x4000A3F")]
		[Tooltip("Refresh Timings rate updates timings and sets it to default value to make sure every leg is making step at the right time. If your character moves slowly, you can set it as some big value like 100 so it updates only every 100 seconds but if not, you need to lower this value. For example: fast pink robot in demo scene has this value set as 10. ")]
		[FieldOffset(Offset = "0x78")]
		[Header("Advansed")]
		private float refreshTimingRate;

		// Token: 0x04000A40 RID: 2624
		[Token(Token = "0x4000A40")]
		[FieldOffset(Offset = "0x80")]
		public EventHandler<Vector3> eventHandler_0;

		// Token: 0x04000A41 RID: 2625
		[Token(Token = "0x4000A41")]
		[FieldOffset(Offset = "0x88")]
		private Vector3[] vector3_0;

		// Token: 0x04000A42 RID: 2626
		[FieldOffset(Offset = "0x90")]
		[Token(Token = "0x4000A42")]
		private Vector3[] vector3_1;

		// Token: 0x04000A43 RID: 2627
		[Token(Token = "0x4000A43")]
		[FieldOffset(Offset = "0x98")]
		private Vector3[] vector3_2;

		// Token: 0x04000A44 RID: 2628
		[Token(Token = "0x4000A44")]
		[FieldOffset(Offset = "0xA0")]
		private Vector3[] vector3_3;

		// Token: 0x04000A45 RID: 2629
		[Token(Token = "0x4000A45")]
		[FieldOffset(Offset = "0xA8")]
		private Vector3 vector3_4;

		// Token: 0x04000A46 RID: 2630
		[Token(Token = "0x4000A46")]
		[FieldOffset(Offset = "0xB4")]
		private Vector3 vector3_5;

		// Token: 0x04000A47 RID: 2631
		[Token(Token = "0x4000A47")]
		[FieldOffset(Offset = "0xC0")]
		private Vector3 vector3_6;

		// Token: 0x04000A48 RID: 2632
		[FieldOffset(Offset = "0xD0")]
		[Token(Token = "0x4000A48")]
		private float[] float_0;

		// Token: 0x04000A49 RID: 2633
		[FieldOffset(Offset = "0xD8")]
		[Token(Token = "0x4000A49")]
		private float[] float_1;

		// Token: 0x04000A4A RID: 2634
		[FieldOffset(Offset = "0xE0")]
		[Token(Token = "0x4000A4A")]
		private float[] float_2;

		// Token: 0x04000A4B RID: 2635
		[Token(Token = "0x4000A4B")]
		[FieldOffset(Offset = "0xE8")]
		private float float_3;

		// Token: 0x04000A4C RID: 2636
		[Token(Token = "0x4000A4C")]
		[FieldOffset(Offset = "0xF0")]
		private float[] float_4;

		// Token: 0x04000A4D RID: 2637
		[FieldOffset(Offset = "0xF8")]
		[Token(Token = "0x4000A4D")]
		private int int_0;

		// Token: 0x04000A4E RID: 2638
		[Token(Token = "0x4000A4E")]
		[FieldOffset(Offset = "0xFC")]
		private int int_1;

		// Token: 0x04000A4F RID: 2639
		[Token(Token = "0x4000A4F")]
		[FieldOffset(Offset = "0x100")]
		private bool[] bool_1;
	}
}
