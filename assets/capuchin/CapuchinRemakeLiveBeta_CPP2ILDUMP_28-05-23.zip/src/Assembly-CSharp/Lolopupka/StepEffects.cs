﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x0200017A RID: 378
	[Token(Token = "0x200017A")]
	public class StepEffects : MonoBehaviour
	{
		// Token: 0x06003A1D RID: 14877 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x3083058", Offset = "0x3083058", VA = "0x3083058")]
		[Token(Token = "0x6003A1D")]
		public StepEffects()
		{
		}

		// Token: 0x06003A1E RID: 14878 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003A1E")]
		[Address(RVA = "0x3083060", Offset = "0x3083060", VA = "0x3083060")]
		private void method_0(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A1F RID: 14879 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003A1F")]
		[Address(RVA = "0x3083218", Offset = "0x3083218", VA = "0x3083218")]
		private void method_1(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A20 RID: 14880 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x30833CC", Offset = "0x30833CC", VA = "0x30833CC")]
		[Token(Token = "0x6003A20")]
		private void method_2(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A21 RID: 14881 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3083584", Offset = "0x3083584", VA = "0x3083584")]
		[Token(Token = "0x6003A21")]
		private void method_3(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A22 RID: 14882 RVA: 0x00073648 File Offset: 0x00071848
		[Token(Token = "0x6003A22")]
		[Address(RVA = "0x3083738", Offset = "0x3083738", VA = "0x3083738")]
		private void method_4()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) == null)
			{
			}
		}

		// Token: 0x06003A23 RID: 14883 RVA: 0x00073648 File Offset: 0x00071848
		[Token(Token = "0x6003A23")]
		[Address(RVA = "0x3083908", Offset = "0x3083908", VA = "0x3083908")]
		private void Start()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) == null)
			{
			}
		}

		// Token: 0x06003A24 RID: 14884 RVA: 0x00073648 File Offset: 0x00071848
		[Address(RVA = "0x3083AD8", Offset = "0x3083AD8", VA = "0x3083AD8")]
		[Token(Token = "0x6003A24")]
		private void method_5()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) == null)
			{
			}
		}

		// Token: 0x06003A25 RID: 14885 RVA: 0x00073648 File Offset: 0x00071848
		[Address(RVA = "0x3083CA8", Offset = "0x3083CA8", VA = "0x3083CA8")]
		[Token(Token = "0x6003A25")]
		private void method_6()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) == null)
			{
			}
		}

		// Token: 0x06003A26 RID: 14886 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003A26")]
		[Address(RVA = "0x3083E78", Offset = "0x3083E78", VA = "0x3083E78")]
		private void method_7(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A27 RID: 14887 RVA: 0x00073648 File Offset: 0x00071848
		[Address(RVA = "0x3084030", Offset = "0x3084030", VA = "0x3084030")]
		[Token(Token = "0x6003A27")]
		private void method_8()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) == null)
			{
			}
		}

		// Token: 0x06003A28 RID: 14888 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3084200", Offset = "0x3084200", VA = "0x3084200")]
		[Token(Token = "0x6003A28")]
		private void method_9(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A29 RID: 14889 RVA: 0x00002068 File Offset: 0x00000268
		[Token(Token = "0x6003A29")]
		[Address(RVA = "0x30843B8", Offset = "0x30843B8", VA = "0x30843B8")]
		private void method_10(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A2A RID: 14890 RVA: 0x00073648 File Offset: 0x00071848
		[Token(Token = "0x6003A2A")]
		[Address(RVA = "0x3084570", Offset = "0x3084570", VA = "0x3084570")]
		private void method_11()
		{
			EventHandler<Vector3> eventHandler;
			if (Delegate.Combine(eventHandler, eventHandler) == null)
			{
			}
		}

		// Token: 0x06003A2B RID: 14891 RVA: 0x00002068 File Offset: 0x00000268
		[Address(RVA = "0x3084740", Offset = "0x3084740", VA = "0x3084740")]
		[Token(Token = "0x6003A2B")]
		private void method_12(object object_0, Vector3 vector3_0)
		{
			throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
		}

		// Token: 0x06003A2C RID: 14892 RVA: 0x00073660 File Offset: 0x00071860
		[Token(Token = "0x6003A2C")]
		[Address(RVA = "0x30848F8", Offset = "0x30848F8", VA = "0x30848F8")]
		private void method_13()
		{
			Delegate @delegate;
			if (@delegate == null)
			{
			}
		}

		// Token: 0x04000A29 RID: 2601
		[Token(Token = "0x4000A29")]
		[FieldOffset(Offset = "0x18")]
		[SerializeField]
		private AudioClip[] stepSVX;

		// Token: 0x04000A2A RID: 2602
		[Token(Token = "0x4000A2A")]
		[FieldOffset(Offset = "0x20")]
		[SerializeField]
		private GameObject stepVFX;

		// Token: 0x04000A2B RID: 2603
		[Token(Token = "0x4000A2B")]
		[FieldOffset(Offset = "0x28")]
		private proceduralAnimation proceduralAnimation_0;

		// Token: 0x04000A2C RID: 2604
		[Token(Token = "0x4000A2C")]
		[FieldOffset(Offset = "0x30")]
		private AudioSource audioSource_0;
	}
}
