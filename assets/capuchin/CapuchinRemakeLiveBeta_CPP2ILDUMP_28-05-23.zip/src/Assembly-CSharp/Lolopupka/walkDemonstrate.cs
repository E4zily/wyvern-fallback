﻿using System;
using Cpp2IlInjected;
using UnityEngine;

namespace Lolopupka
{
	// Token: 0x02000177 RID: 375
	[Token(Token = "0x2000177")]
	public class walkDemonstrate : MonoBehaviour
	{
		// Token: 0x0600398C RID: 14732 RVA: 0x0007290C File Offset: 0x00070B0C
		[Token(Token = "0x600398C")]
		[Address(RVA = "0x35485EC", Offset = "0x35485EC", VA = "0x35485EC")]
		private void method_0()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600398D RID: 14733 RVA: 0x00072948 File Offset: 0x00070B48
		[Address(RVA = "0x3548768", Offset = "0x3548768", VA = "0x3548768")]
		[Token(Token = "0x600398D")]
		private void method_1()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600398E RID: 14734 RVA: 0x0007297C File Offset: 0x00070B7C
		[Token(Token = "0x600398E")]
		[Address(RVA = "0x35488E0", Offset = "0x35488E0", VA = "0x35488E0")]
		private void method_2()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x0600398F RID: 14735 RVA: 0x000729C0 File Offset: 0x00070BC0
		[Address(RVA = "0x3548A78", Offset = "0x3548A78", VA = "0x3548A78")]
		[Token(Token = "0x600398F")]
		private void method_3()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num2 = this.int_0;
			this.int_0 = num2;
		}

		// Token: 0x06003990 RID: 14736 RVA: 0x0007297C File Offset: 0x00070B7C
		[Token(Token = "0x6003990")]
		[Address(RVA = "0x3548C14", Offset = "0x3548C14", VA = "0x3548C14")]
		private void method_4()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x06003991 RID: 14737 RVA: 0x0007297C File Offset: 0x00070B7C
		[Address(RVA = "0x3548DAC", Offset = "0x3548DAC", VA = "0x3548DAC")]
		[Token(Token = "0x6003991")]
		private void method_5()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x06003992 RID: 14738 RVA: 0x00002060 File Offset: 0x00000260
		[Token(Token = "0x6003992")]
		[Address(RVA = "0x3548F44", Offset = "0x3548F44", VA = "0x3548F44")]
		public walkDemonstrate()
		{
		}

		// Token: 0x06003993 RID: 14739 RVA: 0x000729C0 File Offset: 0x00070BC0
		[Address(RVA = "0x3548F4C", Offset = "0x3548F4C", VA = "0x3548F4C")]
		[Token(Token = "0x6003993")]
		private void method_6()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num2 = this.int_0;
			this.int_0 = num2;
		}

		// Token: 0x06003994 RID: 14740 RVA: 0x0007297C File Offset: 0x00070B7C
		[Address(RVA = "0x35490E8", Offset = "0x35490E8", VA = "0x35490E8")]
		[Token(Token = "0x6003994")]
		private void method_7()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x06003995 RID: 14741 RVA: 0x0007297C File Offset: 0x00070B7C
		[Token(Token = "0x6003995")]
		[Address(RVA = "0x3549284", Offset = "0x3549284", VA = "0x3549284")]
		private void method_8()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x06003996 RID: 14742 RVA: 0x0007290C File Offset: 0x00070B0C
		[Address(RVA = "0x354941C", Offset = "0x354941C", VA = "0x354941C")]
		[Token(Token = "0x6003996")]
		private void method_9()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x06003997 RID: 14743 RVA: 0x0007297C File Offset: 0x00070B7C
		[Token(Token = "0x6003997")]
		[Address(RVA = "0x3549598", Offset = "0x3549598", VA = "0x3549598")]
		private void Update()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x06003998 RID: 14744 RVA: 0x000729C0 File Offset: 0x00070BC0
		[Address(RVA = "0x3549730", Offset = "0x3549730", VA = "0x3549730")]
		[Token(Token = "0x6003998")]
		private void method_10()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num2 = this.int_0;
			this.int_0 = num2;
		}

		// Token: 0x06003999 RID: 14745 RVA: 0x0007290C File Offset: 0x00070B0C
		[Token(Token = "0x6003999")]
		[Address(RVA = "0x35498CC", Offset = "0x35498CC", VA = "0x35498CC")]
		private void method_11()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600399A RID: 14746 RVA: 0x0007290C File Offset: 0x00070B0C
		[Token(Token = "0x600399A")]
		[Address(RVA = "0x3549A48", Offset = "0x3549A48", VA = "0x3549A48")]
		private void method_12()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600399B RID: 14747 RVA: 0x00072948 File Offset: 0x00070B48
		[Address(RVA = "0x3549BC4", Offset = "0x3549BC4", VA = "0x3549BC4")]
		[Token(Token = "0x600399B")]
		private void method_13()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600399C RID: 14748 RVA: 0x0007297C File Offset: 0x00070B7C
		[Token(Token = "0x600399C")]
		[Address(RVA = "0x3549D3C", Offset = "0x3549D3C", VA = "0x3549D3C")]
		private void method_14()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x0600399D RID: 14749 RVA: 0x00072A0C File Offset: 0x00070C0C
		[Address(RVA = "0x3549ED4", Offset = "0x3549ED4", VA = "0x3549ED4")]
		[Token(Token = "0x600399D")]
		private void method_15()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600399E RID: 14750 RVA: 0x00072A48 File Offset: 0x00070C48
		[Address(RVA = "0x354A050", Offset = "0x354A050", VA = "0x354A050")]
		[Token(Token = "0x600399E")]
		private void method_16()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x0600399F RID: 14751 RVA: 0x00072A84 File Offset: 0x00070C84
		[Token(Token = "0x600399F")]
		[Address(RVA = "0x354A1CC", Offset = "0x354A1CC", VA = "0x354A1CC")]
		private void method_17()
		{
			Vector3 position = base.transform.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x060039A0 RID: 14752 RVA: 0x0007290C File Offset: 0x00070B0C
		[Token(Token = "0x60039A0")]
		[Address(RVA = "0x354A364", Offset = "0x354A364", VA = "0x354A364")]
		private void method_18()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060039A1 RID: 14753 RVA: 0x00072948 File Offset: 0x00070B48
		[Token(Token = "0x60039A1")]
		[Address(RVA = "0x354A4E0", Offset = "0x354A4E0", VA = "0x354A4E0")]
		private void method_19()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060039A2 RID: 14754 RVA: 0x0007290C File Offset: 0x00070B0C
		[Address(RVA = "0x354A658", Offset = "0x354A658", VA = "0x354A658")]
		[Token(Token = "0x60039A2")]
		private void method_20()
		{
			long num = 1L;
			this.int_0 = (int)num;
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060039A3 RID: 14755 RVA: 0x00072948 File Offset: 0x00070B48
		[Address(RVA = "0x354A7D4", Offset = "0x354A7D4", VA = "0x354A7D4")]
		[Token(Token = "0x60039A3")]
		private void method_21()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060039A4 RID: 14756 RVA: 0x00072948 File Offset: 0x00070B48
		[Token(Token = "0x60039A4")]
		[Address(RVA = "0x354A94C", Offset = "0x354A94C", VA = "0x354A94C")]
		private void method_22()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
		}

		// Token: 0x060039A5 RID: 14757 RVA: 0x0007297C File Offset: 0x00070B7C
		[Token(Token = "0x60039A5")]
		[Address(RVA = "0x354AAC8", Offset = "0x354AAC8", VA = "0x354AAC8")]
		private void method_23()
		{
			Transform transform = base.transform;
			Vector3 position = base.transform.position;
			float deltaTime = Time.deltaTime;
			Vector3 position2 = base.transform.position;
			int num = this.int_0;
			this.int_0 = num;
		}

		// Token: 0x04000A11 RID: 2577
		[Token(Token = "0x4000A11")]
		[FieldOffset(Offset = "0x18")]
		public float float_0;

		// Token: 0x04000A12 RID: 2578
		[Token(Token = "0x4000A12")]
		[FieldOffset(Offset = "0x20")]
		public Transform[] transform_0;

		// Token: 0x04000A13 RID: 2579
		[Token(Token = "0x4000A13")]
		[FieldOffset(Offset = "0x28")]
		private int int_0;
	}
}
