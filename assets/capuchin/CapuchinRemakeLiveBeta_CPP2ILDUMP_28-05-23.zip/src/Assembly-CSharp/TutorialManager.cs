﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000F0 RID: 240
[Token(Token = "0x20000F0")]
public class TutorialManager : MonoBehaviour
{
	// Token: 0x0600240C RID: 9228 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F45EC", Offset = "0x20F45EC", VA = "0x20F45EC")]
	[Token(Token = "0x600240C")]
	private void method_0()
	{
	}

	// Token: 0x0600240D RID: 9229 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F45F0", Offset = "0x20F45F0", VA = "0x20F45F0")]
	[Token(Token = "0x600240D")]
	private void method_1()
	{
	}

	// Token: 0x0600240E RID: 9230 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F45F4", Offset = "0x20F45F4", VA = "0x20F45F4")]
	[Token(Token = "0x600240E")]
	private void method_2()
	{
	}

	// Token: 0x0600240F RID: 9231 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F45F8", Offset = "0x20F45F8", VA = "0x20F45F8")]
	[Token(Token = "0x600240F")]
	private void method_3()
	{
	}

	// Token: 0x06002410 RID: 9232 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F45FC", Offset = "0x20F45FC", VA = "0x20F45FC")]
	[Token(Token = "0x6002410")]
	private void method_4()
	{
	}

	// Token: 0x06002411 RID: 9233 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4600", Offset = "0x20F4600", VA = "0x20F4600")]
	[Token(Token = "0x6002411")]
	private void method_5()
	{
	}

	// Token: 0x06002412 RID: 9234 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4604", Offset = "0x20F4604", VA = "0x20F4604")]
	[Token(Token = "0x6002412")]
	private void method_6()
	{
	}

	// Token: 0x06002413 RID: 9235 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4608", Offset = "0x20F4608", VA = "0x20F4608")]
	[Token(Token = "0x6002413")]
	private void method_7()
	{
	}

	// Token: 0x06002414 RID: 9236 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F460C", Offset = "0x20F460C", VA = "0x20F460C")]
	[Token(Token = "0x6002414")]
	private void method_8()
	{
	}

	// Token: 0x06002415 RID: 9237 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4610", Offset = "0x20F4610", VA = "0x20F4610")]
	[Token(Token = "0x6002415")]
	private void method_9()
	{
	}

	// Token: 0x06002416 RID: 9238 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4614", Offset = "0x20F4614", VA = "0x20F4614")]
	[Token(Token = "0x6002416")]
	private void method_10()
	{
	}

	// Token: 0x06002417 RID: 9239 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4618", Offset = "0x20F4618", VA = "0x20F4618")]
	[Token(Token = "0x6002417")]
	private void method_11()
	{
	}

	// Token: 0x06002418 RID: 9240 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F461C", Offset = "0x20F461C", VA = "0x20F461C")]
	[Token(Token = "0x6002418")]
	private void method_12()
	{
	}

	// Token: 0x06002419 RID: 9241 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4620", Offset = "0x20F4620", VA = "0x20F4620")]
	[Token(Token = "0x6002419")]
	private void method_13()
	{
	}

	// Token: 0x0600241A RID: 9242 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4624", Offset = "0x20F4624", VA = "0x20F4624")]
	[Token(Token = "0x600241A")]
	private void method_14()
	{
	}

	// Token: 0x0600241B RID: 9243 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4628", Offset = "0x20F4628", VA = "0x20F4628")]
	[Token(Token = "0x600241B")]
	private void method_15()
	{
	}

	// Token: 0x0600241C RID: 9244 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F462C", Offset = "0x20F462C", VA = "0x20F462C")]
	[Token(Token = "0x600241C")]
	private void method_16()
	{
	}

	// Token: 0x0600241D RID: 9245 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4630", Offset = "0x20F4630", VA = "0x20F4630")]
	[Token(Token = "0x600241D")]
	private void method_17()
	{
	}

	// Token: 0x0600241E RID: 9246 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4634", Offset = "0x20F4634", VA = "0x20F4634")]
	[Token(Token = "0x600241E")]
	private void method_18()
	{
	}

	// Token: 0x0600241F RID: 9247 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4638", Offset = "0x20F4638", VA = "0x20F4638")]
	[Token(Token = "0x600241F")]
	private void method_19()
	{
	}

	// Token: 0x06002420 RID: 9248 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F463C", Offset = "0x20F463C", VA = "0x20F463C")]
	[Token(Token = "0x6002420")]
	private void method_20()
	{
	}

	// Token: 0x06002421 RID: 9249 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4640", Offset = "0x20F4640", VA = "0x20F4640")]
	[Token(Token = "0x6002421")]
	private void method_21()
	{
	}

	// Token: 0x06002422 RID: 9250 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4644", Offset = "0x20F4644", VA = "0x20F4644")]
	[Token(Token = "0x6002422")]
	private void method_22()
	{
	}

	// Token: 0x06002423 RID: 9251 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4648", Offset = "0x20F4648", VA = "0x20F4648")]
	[Token(Token = "0x6002423")]
	private void method_23()
	{
	}

	// Token: 0x06002424 RID: 9252 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F464C", Offset = "0x20F464C", VA = "0x20F464C")]
	[Token(Token = "0x6002424")]
	private void method_24()
	{
	}

	// Token: 0x06002425 RID: 9253 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4650", Offset = "0x20F4650", VA = "0x20F4650")]
	[Token(Token = "0x6002425")]
	private void method_25()
	{
	}

	// Token: 0x06002426 RID: 9254 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4654", Offset = "0x20F4654", VA = "0x20F4654")]
	[Token(Token = "0x6002426")]
	private void method_26()
	{
	}

	// Token: 0x06002427 RID: 9255 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4658", Offset = "0x20F4658", VA = "0x20F4658")]
	[Token(Token = "0x6002427")]
	private void method_27()
	{
	}

	// Token: 0x06002428 RID: 9256 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F465C", Offset = "0x20F465C", VA = "0x20F465C")]
	[Token(Token = "0x6002428")]
	private void method_28()
	{
	}

	// Token: 0x06002429 RID: 9257 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4660", Offset = "0x20F4660", VA = "0x20F4660")]
	[Token(Token = "0x6002429")]
	private void method_29()
	{
	}

	// Token: 0x0600242A RID: 9258 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4664", Offset = "0x20F4664", VA = "0x20F4664")]
	[Token(Token = "0x600242A")]
	private void method_30()
	{
	}

	// Token: 0x0600242B RID: 9259 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4668", Offset = "0x20F4668", VA = "0x20F4668")]
	[Token(Token = "0x600242B")]
	private void method_31()
	{
	}

	// Token: 0x0600242C RID: 9260 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F466C", Offset = "0x20F466C", VA = "0x20F466C")]
	[Token(Token = "0x600242C")]
	private void method_32()
	{
	}

	// Token: 0x0600242D RID: 9261 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4670", Offset = "0x20F4670", VA = "0x20F4670")]
	[Token(Token = "0x600242D")]
	private void method_33()
	{
	}

	// Token: 0x0600242E RID: 9262 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4674", Offset = "0x20F4674", VA = "0x20F4674")]
	[Token(Token = "0x600242E")]
	private void method_34()
	{
	}

	// Token: 0x0600242F RID: 9263 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4678", Offset = "0x20F4678", VA = "0x20F4678")]
	[Token(Token = "0x600242F")]
	private void method_35()
	{
	}

	// Token: 0x06002430 RID: 9264 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F467C", Offset = "0x20F467C", VA = "0x20F467C")]
	[Token(Token = "0x6002430")]
	private void method_36()
	{
	}

	// Token: 0x06002431 RID: 9265 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4680", Offset = "0x20F4680", VA = "0x20F4680")]
	[Token(Token = "0x6002431")]
	private void method_37()
	{
	}

	// Token: 0x06002432 RID: 9266 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4684", Offset = "0x20F4684", VA = "0x20F4684")]
	[Token(Token = "0x6002432")]
	private void method_38()
	{
	}

	// Token: 0x06002433 RID: 9267 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4688", Offset = "0x20F4688", VA = "0x20F4688")]
	[Token(Token = "0x6002433")]
	private void method_39()
	{
	}

	// Token: 0x06002434 RID: 9268 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F468C", Offset = "0x20F468C", VA = "0x20F468C")]
	[Token(Token = "0x6002434")]
	private void method_40()
	{
	}

	// Token: 0x06002435 RID: 9269 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4690", Offset = "0x20F4690", VA = "0x20F4690")]
	[Token(Token = "0x6002435")]
	private void method_41()
	{
	}

	// Token: 0x06002436 RID: 9270 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4694", Offset = "0x20F4694", VA = "0x20F4694")]
	[Token(Token = "0x6002436")]
	private void method_42()
	{
	}

	// Token: 0x06002437 RID: 9271 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4698", Offset = "0x20F4698", VA = "0x20F4698")]
	[Token(Token = "0x6002437")]
	private void method_43()
	{
	}

	// Token: 0x06002438 RID: 9272 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F469C", Offset = "0x20F469C", VA = "0x20F469C")]
	[Token(Token = "0x6002438")]
	private void method_44()
	{
	}

	// Token: 0x06002439 RID: 9273 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46A0", Offset = "0x20F46A0", VA = "0x20F46A0")]
	[Token(Token = "0x6002439")]
	private void method_45()
	{
	}

	// Token: 0x0600243A RID: 9274 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46A4", Offset = "0x20F46A4", VA = "0x20F46A4")]
	[Token(Token = "0x600243A")]
	private void method_46()
	{
	}

	// Token: 0x0600243B RID: 9275 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46A8", Offset = "0x20F46A8", VA = "0x20F46A8")]
	[Token(Token = "0x600243B")]
	private void method_47()
	{
	}

	// Token: 0x0600243C RID: 9276 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46AC", Offset = "0x20F46AC", VA = "0x20F46AC")]
	[Token(Token = "0x600243C")]
	private void method_48()
	{
	}

	// Token: 0x0600243D RID: 9277 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46B0", Offset = "0x20F46B0", VA = "0x20F46B0")]
	[Token(Token = "0x600243D")]
	private void method_49()
	{
	}

	// Token: 0x0600243E RID: 9278 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46B4", Offset = "0x20F46B4", VA = "0x20F46B4")]
	[Token(Token = "0x600243E")]
	private void method_50()
	{
	}

	// Token: 0x0600243F RID: 9279 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46B8", Offset = "0x20F46B8", VA = "0x20F46B8")]
	[Token(Token = "0x600243F")]
	private void method_51()
	{
	}

	// Token: 0x06002440 RID: 9280 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46BC", Offset = "0x20F46BC", VA = "0x20F46BC")]
	[Token(Token = "0x6002440")]
	private void method_52()
	{
	}

	// Token: 0x06002441 RID: 9281 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46C0", Offset = "0x20F46C0", VA = "0x20F46C0")]
	[Token(Token = "0x6002441")]
	private void method_53()
	{
	}

	// Token: 0x06002442 RID: 9282 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46C4", Offset = "0x20F46C4", VA = "0x20F46C4")]
	[Token(Token = "0x6002442")]
	private void method_54()
	{
	}

	// Token: 0x06002443 RID: 9283 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46C8", Offset = "0x20F46C8", VA = "0x20F46C8")]
	[Token(Token = "0x6002443")]
	private void method_55()
	{
	}

	// Token: 0x06002444 RID: 9284 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46CC", Offset = "0x20F46CC", VA = "0x20F46CC")]
	[Token(Token = "0x6002444")]
	private void method_56()
	{
	}

	// Token: 0x06002445 RID: 9285 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46D0", Offset = "0x20F46D0", VA = "0x20F46D0")]
	[Token(Token = "0x6002445")]
	private void method_57()
	{
	}

	// Token: 0x06002446 RID: 9286 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46D4", Offset = "0x20F46D4", VA = "0x20F46D4")]
	[Token(Token = "0x6002446")]
	private void method_58()
	{
	}

	// Token: 0x06002447 RID: 9287 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46D8", Offset = "0x20F46D8", VA = "0x20F46D8")]
	[Token(Token = "0x6002447")]
	private void Start()
	{
	}

	// Token: 0x06002448 RID: 9288 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46DC", Offset = "0x20F46DC", VA = "0x20F46DC")]
	[Token(Token = "0x6002448")]
	private void method_59()
	{
	}

	// Token: 0x06002449 RID: 9289 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46E0", Offset = "0x20F46E0", VA = "0x20F46E0")]
	[Token(Token = "0x6002449")]
	private void method_60()
	{
	}

	// Token: 0x0600244A RID: 9290 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46E4", Offset = "0x20F46E4", VA = "0x20F46E4")]
	[Token(Token = "0x600244A")]
	private void method_61()
	{
	}

	// Token: 0x0600244B RID: 9291 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46E8", Offset = "0x20F46E8", VA = "0x20F46E8")]
	[Token(Token = "0x600244B")]
	private void method_62()
	{
	}

	// Token: 0x0600244C RID: 9292 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46EC", Offset = "0x20F46EC", VA = "0x20F46EC")]
	[Token(Token = "0x600244C")]
	private void method_63()
	{
	}

	// Token: 0x0600244D RID: 9293 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46F0", Offset = "0x20F46F0", VA = "0x20F46F0")]
	[Token(Token = "0x600244D")]
	private void method_64()
	{
	}

	// Token: 0x0600244E RID: 9294 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46F4", Offset = "0x20F46F4", VA = "0x20F46F4")]
	[Token(Token = "0x600244E")]
	private void method_65()
	{
	}

	// Token: 0x0600244F RID: 9295 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46F8", Offset = "0x20F46F8", VA = "0x20F46F8")]
	[Token(Token = "0x600244F")]
	private void method_66()
	{
	}

	// Token: 0x06002450 RID: 9296 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F46FC", Offset = "0x20F46FC", VA = "0x20F46FC")]
	[Token(Token = "0x6002450")]
	private void method_67()
	{
	}

	// Token: 0x06002451 RID: 9297 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4700", Offset = "0x20F4700", VA = "0x20F4700")]
	[Token(Token = "0x6002451")]
	private void method_68()
	{
	}

	// Token: 0x06002452 RID: 9298 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4704", Offset = "0x20F4704", VA = "0x20F4704")]
	[Token(Token = "0x6002452")]
	private void method_69()
	{
	}

	// Token: 0x06002453 RID: 9299 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4708", Offset = "0x20F4708", VA = "0x20F4708")]
	[Token(Token = "0x6002453")]
	private void method_70()
	{
	}

	// Token: 0x06002454 RID: 9300 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F470C", Offset = "0x20F470C", VA = "0x20F470C")]
	[Token(Token = "0x6002454")]
	private void method_71()
	{
	}

	// Token: 0x06002455 RID: 9301 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4710", Offset = "0x20F4710", VA = "0x20F4710")]
	[Token(Token = "0x6002455")]
	private void method_72()
	{
	}

	// Token: 0x06002456 RID: 9302 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4714", Offset = "0x20F4714", VA = "0x20F4714")]
	[Token(Token = "0x6002456")]
	private void method_73()
	{
	}

	// Token: 0x06002457 RID: 9303 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4718", Offset = "0x20F4718", VA = "0x20F4718")]
	[Token(Token = "0x6002457")]
	private void method_74()
	{
	}

	// Token: 0x06002458 RID: 9304 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x20F471C", Offset = "0x20F471C", VA = "0x20F471C")]
	[Token(Token = "0x6002458")]
	public TutorialManager()
	{
	}

	// Token: 0x06002459 RID: 9305 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4724", Offset = "0x20F4724", VA = "0x20F4724")]
	[Token(Token = "0x6002459")]
	private void method_75()
	{
	}

	// Token: 0x0600245A RID: 9306 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4728", Offset = "0x20F4728", VA = "0x20F4728")]
	[Token(Token = "0x600245A")]
	private void method_76()
	{
	}

	// Token: 0x0600245B RID: 9307 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F472C", Offset = "0x20F472C", VA = "0x20F472C")]
	[Token(Token = "0x600245B")]
	private void Update()
	{
	}

	// Token: 0x0600245C RID: 9308 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4730", Offset = "0x20F4730", VA = "0x20F4730")]
	[Token(Token = "0x600245C")]
	private void method_77()
	{
	}

	// Token: 0x0600245D RID: 9309 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4734", Offset = "0x20F4734", VA = "0x20F4734")]
	[Token(Token = "0x600245D")]
	private void method_78()
	{
	}

	// Token: 0x0600245E RID: 9310 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4738", Offset = "0x20F4738", VA = "0x20F4738")]
	[Token(Token = "0x600245E")]
	private void method_79()
	{
	}

	// Token: 0x0600245F RID: 9311 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F473C", Offset = "0x20F473C", VA = "0x20F473C")]
	[Token(Token = "0x600245F")]
	private void method_80()
	{
	}

	// Token: 0x06002460 RID: 9312 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4740", Offset = "0x20F4740", VA = "0x20F4740")]
	[Token(Token = "0x6002460")]
	private void method_81()
	{
	}

	// Token: 0x06002461 RID: 9313 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4744", Offset = "0x20F4744", VA = "0x20F4744")]
	[Token(Token = "0x6002461")]
	private void method_82()
	{
	}

	// Token: 0x06002462 RID: 9314 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4748", Offset = "0x20F4748", VA = "0x20F4748")]
	[Token(Token = "0x6002462")]
	private void method_83()
	{
	}

	// Token: 0x06002463 RID: 9315 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F474C", Offset = "0x20F474C", VA = "0x20F474C")]
	[Token(Token = "0x6002463")]
	private void method_84()
	{
	}

	// Token: 0x06002464 RID: 9316 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x20F4750", Offset = "0x20F4750", VA = "0x20F4750")]
	[Token(Token = "0x6002464")]
	private void method_85()
	{
	}
}
