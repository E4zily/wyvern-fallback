﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200007A RID: 122
[Token(Token = "0x200007A")]
public class LavaStartButton : MonoBehaviour
{
	// Token: 0x06001145 RID: 4421 RVA: 0x00023FD4 File Offset: 0x000221D4
	[Address(RVA = "0x2D897D8", Offset = "0x2D897D8", VA = "0x2D897D8")]
	[Token(Token = "0x6001145")]
	public void method_0(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)24576;
			this.lavaManager_0.float_0 = (float)32768;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_63(bool_);
	}

	// Token: 0x06001146 RID: 4422 RVA: 0x00024030 File Offset: 0x00022230
	[Address(RVA = "0x2D898E8", Offset = "0x2D898E8", VA = "0x2D898E8")]
	[Token(Token = "0x6001146")]
	public void method_1(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)17336;
			this.lavaManager_0.float_0 = (float)16384;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_36(bool_);
	}

	// Token: 0x06001147 RID: 4423 RVA: 0x00024088 File Offset: 0x00022288
	[Token(Token = "0x6001147")]
	[Address(RVA = "0x2D899F4", Offset = "0x2D899F4", VA = "0x2D899F4")]
	public void method_2(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)32768;
			this.lavaManager_0.float_0 = (float)40960;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_36(bool_2);
	}

	// Token: 0x06001148 RID: 4424 RVA: 0x000240F8 File Offset: 0x000222F8
	[Token(Token = "0x6001148")]
	[Address(RVA = "0x2D89B08", Offset = "0x2D89B08", VA = "0x2D89B08")]
	public void method_3(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)16384;
			this.lavaManager_0.float_0 = (float)57344;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_58(bool_2);
	}

	// Token: 0x06001149 RID: 4425 RVA: 0x00024168 File Offset: 0x00022368
	[Token(Token = "0x6001149")]
	[Address(RVA = "0x2D89C1C", Offset = "0x2D89C1C", VA = "0x2D89C1C")]
	public void method_4(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)40960;
			this.lavaManager_0.float_0 = (float)40960;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_34(bool_);
	}

	// Token: 0x0600114A RID: 4426 RVA: 0x000241C4 File Offset: 0x000223C4
	[Token(Token = "0x600114A")]
	[Address(RVA = "0x2D89D2C", Offset = "0x2D89D2C", VA = "0x2D89D2C")]
	public void method_5(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)17580;
			this.lavaManager_0.float_0 = (float)17528;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_63(bool_2);
	}

	// Token: 0x0600114B RID: 4427 RVA: 0x00024234 File Offset: 0x00022434
	[Address(RVA = "0x2D89E38", Offset = "0x2D89E38", VA = "0x2D89E38")]
	[Token(Token = "0x600114B")]
	public void method_6(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)40960;
			this.lavaManager_0.float_0 = (float)32768;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_60(bool_2);
	}

	// Token: 0x0600114C RID: 4428 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2D89F4C", Offset = "0x2D89F4C", VA = "0x2D89F4C")]
	[Token(Token = "0x600114C")]
	public LavaStartButton()
	{
	}

	// Token: 0x0600114D RID: 4429 RVA: 0x000242A4 File Offset: 0x000224A4
	[Address(RVA = "0x2D89F54", Offset = "0x2D89F54", VA = "0x2D89F54")]
	[Token(Token = "0x600114D")]
	public void method_7(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)17136;
			this.lavaManager_0.float_0 = (float)49152;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_58(bool_);
	}

	// Token: 0x0600114E RID: 4430 RVA: 0x00024300 File Offset: 0x00022500
	[Address(RVA = "0x2D8A060", Offset = "0x2D8A060", VA = "0x2D8A060")]
	[Token(Token = "0x600114E")]
	public void method_8(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)49152;
			this.lavaManager_0.float_0 = (float)17419;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_58(bool_);
	}

	// Token: 0x0600114F RID: 4431 RVA: 0x0002435C File Offset: 0x0002255C
	[Token(Token = "0x600114F")]
	[Address(RVA = "0x2D8A16C", Offset = "0x2D8A16C", VA = "0x2D8A16C")]
	public void method_9(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)16384;
			this.lavaManager_0.float_0 = (float)32768;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_16(bool_);
	}

	// Token: 0x06001150 RID: 4432 RVA: 0x000243B8 File Offset: 0x000225B8
	[Token(Token = "0x6001150")]
	[Address(RVA = "0x2D8A27C", Offset = "0x2D8A27C", VA = "0x2D8A27C")]
	public void method_10(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)49152;
			this.lavaManager_0.float_0 = (float)17280;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_17(bool_2);
	}

	// Token: 0x06001151 RID: 4433 RVA: 0x00024428 File Offset: 0x00022628
	[Token(Token = "0x6001151")]
	[Address(RVA = "0x2D8A38C", Offset = "0x2D8A38C", VA = "0x2D8A38C")]
	public void method_11(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)32768;
			this.lavaManager_0.float_0 = (float)32768;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_63(bool_2);
	}

	// Token: 0x06001152 RID: 4434 RVA: 0x00024498 File Offset: 0x00022698
	[Address(RVA = "0x2D8A4A0", Offset = "0x2D8A4A0", VA = "0x2D8A4A0")]
	[Token(Token = "0x6001152")]
	public void method_12(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)16384;
			this.lavaManager_0.float_0 = (float)32768;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_63(bool_);
	}

	// Token: 0x06001153 RID: 4435 RVA: 0x000244F4 File Offset: 0x000226F4
	[Token(Token = "0x6001153")]
	[Address(RVA = "0x2D8A5B0", Offset = "0x2D8A5B0", VA = "0x2D8A5B0")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.float_0 = (float)17036;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_39(bool_2);
	}

	// Token: 0x06001154 RID: 4436 RVA: 0x00024550 File Offset: 0x00022750
	[Address(RVA = "0x2D8A6B8", Offset = "0x2D8A6B8", VA = "0x2D8A6B8")]
	[Token(Token = "0x6001154")]
	public void method_13(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)32768;
			this.lavaManager_0.float_0 = (float)49152;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_63(bool_);
	}

	// Token: 0x06001155 RID: 4437 RVA: 0x000245AC File Offset: 0x000227AC
	[Token(Token = "0x6001155")]
	[Address(RVA = "0x2D8A7C8", Offset = "0x2D8A7C8", VA = "0x2D8A7C8")]
	public void method_14(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)16384;
			this.lavaManager_0.float_0 = (float)32768;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_58(bool_2);
	}

	// Token: 0x06001156 RID: 4438 RVA: 0x0002461C File Offset: 0x0002281C
	[Token(Token = "0x6001156")]
	[Address(RVA = "0x2D8A8DC", Offset = "0x2D8A8DC", VA = "0x2D8A8DC")]
	public void method_15(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)17192;
			this.lavaManager_0.float_0 = (float)57344;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_60(bool_2);
	}

	// Token: 0x06001157 RID: 4439 RVA: 0x0002468C File Offset: 0x0002288C
	[Address(RVA = "0x2D8A9EC", Offset = "0x2D8A9EC", VA = "0x2D8A9EC")]
	[Token(Token = "0x6001157")]
	public void method_16(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)16384;
			this.lavaManager_0.float_0 = (float)57344;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_63(bool_2);
	}

	// Token: 0x06001158 RID: 4440 RVA: 0x000246FC File Offset: 0x000228FC
	[Token(Token = "0x6001158")]
	[Address(RVA = "0x2D8AB00", Offset = "0x2D8AB00", VA = "0x2D8AB00")]
	public void method_17(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)17392;
			this.lavaManager_0.float_0 = (float)17287;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_36(bool_);
	}

	// Token: 0x06001159 RID: 4441 RVA: 0x00024758 File Offset: 0x00022958
	[Token(Token = "0x6001159")]
	[Address(RVA = "0x2D8AC08", Offset = "0x2D8AC08", VA = "0x2D8AC08")]
	public void method_18(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)17365;
			this.lavaManager_0.float_0 = (float)40960;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_58(bool_);
	}

	// Token: 0x0600115A RID: 4442 RVA: 0x000247B4 File Offset: 0x000229B4
	[Token(Token = "0x600115A")]
	[Address(RVA = "0x2D8AD14", Offset = "0x2D8AD14", VA = "0x2D8AD14")]
	public void method_19(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		collider_0;
	}

	// Token: 0x0600115B RID: 4443 RVA: 0x000247D0 File Offset: 0x000229D0
	[Address(RVA = "0x2D8AE24", Offset = "0x2D8AE24", VA = "0x2D8AE24")]
	[Token(Token = "0x600115B")]
	public void method_20(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		collider_0;
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)49152;
			this.lavaManager_0.float_0 = (float)17477;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_16(bool_);
	}

	// Token: 0x0600115C RID: 4444 RVA: 0x00024830 File Offset: 0x00022A30
	[Token(Token = "0x600115C")]
	[Address(RVA = "0x2D8AF30", Offset = "0x2D8AF30", VA = "0x2D8AF30")]
	public void method_21(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)57344;
			this.lavaManager_0.float_0 = (float)49152;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_34(bool_2);
	}

	// Token: 0x0600115D RID: 4445 RVA: 0x000248A0 File Offset: 0x00022AA0
	[Address(RVA = "0x2D8B044", Offset = "0x2D8B044", VA = "0x2D8B044")]
	[Token(Token = "0x600115D")]
	public void method_22(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)49152;
			this.lavaManager_0.float_0 = (float)17531;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_36(bool_);
	}

	// Token: 0x0600115E RID: 4446 RVA: 0x000248FC File Offset: 0x00022AFC
	[Token(Token = "0x600115E")]
	[Address(RVA = "0x2D8B150", Offset = "0x2D8B150", VA = "0x2D8B150")]
	public void method_23(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)40960;
			this.lavaManager_0.float_0 = (float)16384;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_17(bool_);
	}

	// Token: 0x0600115F RID: 4447 RVA: 0x00024958 File Offset: 0x00022B58
	[Token(Token = "0x600115F")]
	[Address(RVA = "0x2D8B260", Offset = "0x2D8B260", VA = "0x2D8B260")]
	public void method_24(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			this.lavaManager_0.vector3_0.z = (float)32768;
			this.lavaManager_0.float_0 = (float)57344;
		}
		LavaManager lavaManager = this.lavaManager_0;
		bool bool_ = this.bool_0;
		lavaManager.method_16(bool_);
	}

	// Token: 0x06001160 RID: 4448 RVA: 0x000249B4 File Offset: 0x00022BB4
	[Address(RVA = "0x2D8B370", Offset = "0x2D8B370", VA = "0x2D8B370")]
	[Token(Token = "0x6001160")]
	public void method_25(Collider collider_0)
	{
		collider_0.GetComponent<HandColliders>();
		if (this.bool_1)
		{
			LavaManager lavaManager = this.lavaManager_0;
			long bool_ = 1L;
			lavaManager.bool_4 = (bool_ != 0L);
			this.lavaManager_0.vector3_0.z = (float)40960;
			this.lavaManager_0.float_0 = (float)16384;
		}
		LavaManager lavaManager2 = this.lavaManager_0;
		bool bool_2 = this.bool_0;
		lavaManager2.method_58(bool_2);
	}

	// Token: 0x0400027A RID: 634
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400027A")]
	public LavaManager lavaManager_0;

	// Token: 0x0400027B RID: 635
	[Token(Token = "0x400027B")]
	[FieldOffset(Offset = "0x20")]
	private bool bool_0;

	// Token: 0x0400027C RID: 636
	[FieldOffset(Offset = "0x21")]
	[Token(Token = "0x400027C")]
	public bool bool_1;
}
