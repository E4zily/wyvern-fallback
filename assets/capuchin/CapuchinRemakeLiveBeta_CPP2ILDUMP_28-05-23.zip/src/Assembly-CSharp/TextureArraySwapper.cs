﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000047 RID: 71
[Token(Token = "0x2000047")]
public class TextureArraySwapper : MonoBehaviour
{
	// Token: 0x06000966 RID: 2406 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x6000966")]
	[Address(RVA = "0x25CC028", Offset = "0x25CC028", VA = "0x25CC028")]
	private void method_0()
	{
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC03C", Offset = "0x25CC03C", VA = "0x25CC03C")]
	[Token(Token = "0x6000967")]
	public IEnumerator method_1()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x6000968")]
	[Address(RVA = "0x25CC0B4", Offset = "0x25CC0B4", VA = "0x25CC0B4")]
	public IEnumerator method_2()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC12C", Offset = "0x25CC12C", VA = "0x25CC12C")]
	[Token(Token = "0x6000969")]
	public IEnumerator method_3()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x00016798 File Offset: 0x00014998
	[Token(Token = "0x600096A")]
	[Address(RVA = "0x25CC1A4", Offset = "0x25CC1A4", VA = "0x25CC1A4")]
	public void method_4()
	{
		IEnumerator routine = this.method_71();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x600096B")]
	[Address(RVA = "0x25CC248", Offset = "0x25CC248", VA = "0x25CC248")]
	public IEnumerator method_5()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x600096C")]
	[Address(RVA = "0x25CC2C0", Offset = "0x25CC2C0", VA = "0x25CC2C0")]
	private void method_6()
	{
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x600096D")]
	[Address(RVA = "0x25CC2D4", Offset = "0x25CC2D4", VA = "0x25CC2D4")]
	public IEnumerator method_7()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600096E RID: 2414 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC34C", Offset = "0x25CC34C", VA = "0x25CC34C")]
	[Token(Token = "0x600096E")]
	public IEnumerator method_8()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x600096F")]
	[Address(RVA = "0x25CC3C4", Offset = "0x25CC3C4", VA = "0x25CC3C4")]
	private void method_9()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CC3DC", Offset = "0x25CC3DC", VA = "0x25CC3DC")]
	[Token(Token = "0x6000970")]
	private void method_10()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x6000971")]
	[Address(RVA = "0x25CC3F4", Offset = "0x25CC3F4", VA = "0x25CC3F4")]
	public IEnumerator method_11()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC46C", Offset = "0x25CC46C", VA = "0x25CC46C")]
	[Token(Token = "0x6000972")]
	public IEnumerator method_12()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000973 RID: 2419 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x6000973")]
	[Address(RVA = "0x25CC4E4", Offset = "0x25CC4E4", VA = "0x25CC4E4")]
	private void method_13()
	{
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CC4F8", Offset = "0x25CC4F8", VA = "0x25CC4F8")]
	[Token(Token = "0x6000974")]
	private void method_14()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x06000975 RID: 2421 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC510", Offset = "0x25CC510", VA = "0x25CC510")]
	[Token(Token = "0x6000975")]
	public IEnumerator method_15()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000976 RID: 2422 RVA: 0x000167CC File Offset: 0x000149CC
	[Token(Token = "0x6000976")]
	[Address(RVA = "0x25CC588", Offset = "0x25CC588", VA = "0x25CC588")]
	public void method_16()
	{
		IEnumerator routine = this.method_114();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x000167E8 File Offset: 0x000149E8
	[Address(RVA = "0x25CC62C", Offset = "0x25CC62C", VA = "0x25CC62C")]
	[Token(Token = "0x6000977")]
	public void method_17()
	{
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000978 RID: 2424 RVA: 0x00016804 File Offset: 0x00014A04
	[Address(RVA = "0x25CC6D0", Offset = "0x25CC6D0", VA = "0x25CC6D0")]
	[Token(Token = "0x6000978")]
	public void method_18()
	{
		IEnumerator routine = this.method_11();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000979 RID: 2425 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x6000979")]
	[Address(RVA = "0x25CC6FC", Offset = "0x25CC6FC", VA = "0x25CC6FC")]
	public IEnumerator method_19()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600097A RID: 2426 RVA: 0x00016820 File Offset: 0x00014A20
	[Address(RVA = "0x25CC774", Offset = "0x25CC774", VA = "0x25CC774")]
	[Token(Token = "0x600097A")]
	public void method_20()
	{
		IEnumerator routine = this.method_37();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600097B RID: 2427 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x600097B")]
	[Address(RVA = "0x25CC818", Offset = "0x25CC818", VA = "0x25CC818")]
	private void method_21()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x0600097C RID: 2428 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CC830", Offset = "0x25CC830", VA = "0x25CC830")]
	[Token(Token = "0x600097C")]
	private void method_22()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x0600097D RID: 2429 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x600097D")]
	[Address(RVA = "0x25CC848", Offset = "0x25CC848", VA = "0x25CC848")]
	public IEnumerator method_23()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600097E RID: 2430 RVA: 0x0001683C File Offset: 0x00014A3C
	[Address(RVA = "0x25CC8C0", Offset = "0x25CC8C0", VA = "0x25CC8C0")]
	[Token(Token = "0x600097E")]
	public void method_24()
	{
		IEnumerator routine = this.method_95();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600097F RID: 2431 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x600097F")]
	[Address(RVA = "0x25CC964", Offset = "0x25CC964", VA = "0x25CC964")]
	public IEnumerator method_25()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000980 RID: 2432 RVA: 0x00016858 File Offset: 0x00014A58
	[Token(Token = "0x6000980")]
	[Address(RVA = "0x25CC9DC", Offset = "0x25CC9DC", VA = "0x25CC9DC")]
	public void method_26()
	{
		IEnumerator routine = this.method_76();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000981 RID: 2433 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CCA80", Offset = "0x25CCA80", VA = "0x25CCA80")]
	[Token(Token = "0x6000981")]
	private void method_27()
	{
	}

	// Token: 0x06000982 RID: 2434 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CCA98", Offset = "0x25CCA98", VA = "0x25CCA98")]
	[Token(Token = "0x6000982")]
	public IEnumerator method_28()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000983 RID: 2435 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CCB10", Offset = "0x25CCB10", VA = "0x25CCB10")]
	[Token(Token = "0x6000983")]
	public IEnumerator method_29()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000984 RID: 2436 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CCB88", Offset = "0x25CCB88", VA = "0x25CCB88")]
	[Token(Token = "0x6000984")]
	public IEnumerator method_30()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000985 RID: 2437 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CCC00", Offset = "0x25CCC00", VA = "0x25CCC00")]
	[Token(Token = "0x6000985")]
	public IEnumerator method_31()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000986 RID: 2438 RVA: 0x00016874 File Offset: 0x00014A74
	[Token(Token = "0x6000986")]
	[Address(RVA = "0x25CCC78", Offset = "0x25CCC78", VA = "0x25CCC78")]
	public void method_32()
	{
		IEnumerator routine = this.method_2();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000987 RID: 2439 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CCCA4", Offset = "0x25CCCA4", VA = "0x25CCCA4")]
	[Token(Token = "0x6000987")]
	private void method_33()
	{
	}

	// Token: 0x06000988 RID: 2440 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x6000988")]
	[Address(RVA = "0x25CCCB8", Offset = "0x25CCCB8", VA = "0x25CCCB8")]
	public IEnumerator method_34()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000989 RID: 2441 RVA: 0x00016890 File Offset: 0x00014A90
	[Token(Token = "0x6000989")]
	[Address(RVA = "0x25CCD30", Offset = "0x25CCD30", VA = "0x25CCD30")]
	public void method_35()
	{
		IEnumerator routine = this.method_23();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600098A RID: 2442 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CCD5C", Offset = "0x25CCD5C", VA = "0x25CCD5C")]
	[Token(Token = "0x600098A")]
	public IEnumerator method_36()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600098B RID: 2443 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC7A0", Offset = "0x25CC7A0", VA = "0x25CC7A0")]
	[Token(Token = "0x600098B")]
	public IEnumerator method_37()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600098C RID: 2444 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC658", Offset = "0x25CC658", VA = "0x25CC658")]
	[Token(Token = "0x600098C")]
	public IEnumerator method_38()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600098D RID: 2445 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x600098D")]
	[Address(RVA = "0x25CCDD4", Offset = "0x25CCDD4", VA = "0x25CCDD4")]
	public IEnumerator method_39()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600098E RID: 2446 RVA: 0x000168AC File Offset: 0x00014AAC
	[Token(Token = "0x600098E")]
	[Address(RVA = "0x25CCE4C", Offset = "0x25CCE4C", VA = "0x25CCE4C")]
	public void method_40()
	{
		IEnumerator routine = this.method_39();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600098F RID: 2447 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x600098F")]
	[Address(RVA = "0x25CCE78", Offset = "0x25CCE78", VA = "0x25CCE78")]
	private void method_41()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x06000990 RID: 2448 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x6000990")]
	[Address(RVA = "0x25CCE90", Offset = "0x25CCE90", VA = "0x25CCE90")]
	private void method_42()
	{
	}

	// Token: 0x06000991 RID: 2449 RVA: 0x00016874 File Offset: 0x00014A74
	[Token(Token = "0x6000991")]
	[Address(RVA = "0x25CCEA4", Offset = "0x25CCEA4", VA = "0x25CCEA4")]
	public void method_43()
	{
		IEnumerator routine = this.method_2();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000992 RID: 2450 RVA: 0x000168C8 File Offset: 0x00014AC8
	[Token(Token = "0x6000992")]
	[Address(RVA = "0x25CCED0", Offset = "0x25CCED0", VA = "0x25CCED0")]
	public void method_44()
	{
		IEnumerator routine = this.method_102();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000993 RID: 2451 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CCF74", Offset = "0x25CCF74", VA = "0x25CCF74")]
	[Token(Token = "0x6000993")]
	public IEnumerator method_45()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06000994 RID: 2452 RVA: 0x000168E4 File Offset: 0x00014AE4
	[Address(RVA = "0x25CCFEC", Offset = "0x25CCFEC", VA = "0x25CCFEC")]
	[Token(Token = "0x6000994")]
	public void method_46()
	{
		IEnumerator routine = this.method_1();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000995 RID: 2453 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CD018", Offset = "0x25CD018", VA = "0x25CD018")]
	[Token(Token = "0x6000995")]
	private void method_47()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x06000996 RID: 2454 RVA: 0x00016900 File Offset: 0x00014B00
	[Address(RVA = "0x25CD030", Offset = "0x25CD030", VA = "0x25CD030")]
	[Token(Token = "0x6000996")]
	public void method_48()
	{
		IEnumerator routine = this.method_25();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000997 RID: 2455 RVA: 0x0001691C File Offset: 0x00014B1C
	[Address(RVA = "0x25CD05C", Offset = "0x25CD05C", VA = "0x25CD05C")]
	[Token(Token = "0x6000997")]
	public void method_49()
	{
		IEnumerator routine = this.method_5();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000998 RID: 2456 RVA: 0x00016938 File Offset: 0x00014B38
	[Address(RVA = "0x25CD088", Offset = "0x25CD088", VA = "0x25CD088")]
	[Token(Token = "0x6000998")]
	public void method_50()
	{
		IEnumerator routine = this.method_56();
		base.StartCoroutine(routine);
	}

	// Token: 0x06000999 RID: 2457 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x6000999")]
	[Address(RVA = "0x25CD12C", Offset = "0x25CD12C", VA = "0x25CD12C")]
	private void method_51()
	{
	}

	// Token: 0x0600099A RID: 2458 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x600099A")]
	[Address(RVA = "0x25CD140", Offset = "0x25CD140", VA = "0x25CD140")]
	private void method_52()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x0600099B RID: 2459 RVA: 0x00016954 File Offset: 0x00014B54
	[Address(RVA = "0x25CD158", Offset = "0x25CD158", VA = "0x25CD158")]
	[Token(Token = "0x600099B")]
	public void method_53()
	{
		IEnumerator routine = this.method_90();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600099C RID: 2460 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CD1FC", Offset = "0x25CD1FC", VA = "0x25CD1FC")]
	[Token(Token = "0x600099C")]
	public IEnumerator method_54()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600099D RID: 2461 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CD274", Offset = "0x25CD274", VA = "0x25CD274")]
	[Token(Token = "0x600099D")]
	private void method_55()
	{
	}

	// Token: 0x0600099E RID: 2462 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CD0B4", Offset = "0x25CD0B4", VA = "0x25CD0B4")]
	[Token(Token = "0x600099E")]
	public IEnumerator method_56()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600099F RID: 2463 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x600099F")]
	[Address(RVA = "0x25CD288", Offset = "0x25CD288", VA = "0x25CD288")]
	public IEnumerator method_57()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009A0 RID: 2464 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009A0")]
	[Address(RVA = "0x25CD300", Offset = "0x25CD300", VA = "0x25CD300")]
	public IEnumerator method_58()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009A1 RID: 2465 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CD378", Offset = "0x25CD378", VA = "0x25CD378")]
	[Token(Token = "0x60009A1")]
	public IEnumerator method_59()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009A2 RID: 2466 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009A2")]
	[Address(RVA = "0x25CD3F0", Offset = "0x25CD3F0", VA = "0x25CD3F0")]
	public IEnumerator method_60()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009A3 RID: 2467 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009A3")]
	[Address(RVA = "0x25CD468", Offset = "0x25CD468", VA = "0x25CD468")]
	public IEnumerator method_61()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009A4 RID: 2468 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x60009A4")]
	[Address(RVA = "0x25CD4E0", Offset = "0x25CD4E0", VA = "0x25CD4E0")]
	private void method_62()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009A5 RID: 2469 RVA: 0x00016970 File Offset: 0x00014B70
	[Address(RVA = "0x25CD4F8", Offset = "0x25CD4F8", VA = "0x25CD4F8")]
	[Token(Token = "0x60009A5")]
	public void method_63()
	{
		IEnumerator routine = this.method_110();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009A6 RID: 2470 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x60009A6")]
	[Address(RVA = "0x25CD59C", Offset = "0x25CD59C", VA = "0x25CD59C")]
	private void method_64()
	{
	}

	// Token: 0x060009A7 RID: 2471 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CD5B0", Offset = "0x25CD5B0", VA = "0x25CD5B0")]
	[Token(Token = "0x60009A7")]
	public IEnumerator method_65()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009A8 RID: 2472 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x60009A8")]
	[Address(RVA = "0x25CD628", Offset = "0x25CD628", VA = "0x25CD628")]
	private void method_66()
	{
	}

	// Token: 0x060009A9 RID: 2473 RVA: 0x0001698C File Offset: 0x00014B8C
	[Token(Token = "0x60009A9")]
	[Address(RVA = "0x25CD63C", Offset = "0x25CD63C", VA = "0x25CD63C")]
	public void method_67()
	{
		IEnumerator routine = this.method_30();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009AA RID: 2474 RVA: 0x000168AC File Offset: 0x00014AAC
	[Token(Token = "0x60009AA")]
	[Address(RVA = "0x25CD668", Offset = "0x25CD668", VA = "0x25CD668")]
	public void method_68()
	{
		IEnumerator routine = this.method_39();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009AB RID: 2475 RVA: 0x000169A8 File Offset: 0x00014BA8
	[Token(Token = "0x60009AB")]
	[Address(RVA = "0x25CD694", Offset = "0x25CD694", VA = "0x25CD694")]
	public void method_69()
	{
		IEnumerator routine = this.method_70();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009AC RID: 2476 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009AC")]
	[Address(RVA = "0x25CD6C0", Offset = "0x25CD6C0", VA = "0x25CD6C0")]
	public IEnumerator method_70()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009AD RID: 2477 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009AD")]
	[Address(RVA = "0x25CC1D0", Offset = "0x25CC1D0", VA = "0x25CC1D0")]
	public IEnumerator method_71()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009AE RID: 2478 RVA: 0x000169C4 File Offset: 0x00014BC4
	[Token(Token = "0x60009AE")]
	[Address(RVA = "0x25CD738", Offset = "0x25CD738", VA = "0x25CD738")]
	public void method_72()
	{
		IEnumerator routine = this.method_57();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009AF RID: 2479 RVA: 0x000169E0 File Offset: 0x00014BE0
	[Address(RVA = "0x25CD764", Offset = "0x25CD764", VA = "0x25CD764")]
	[Token(Token = "0x60009AF")]
	public void method_73()
	{
		this.method_93();
	}

	// Token: 0x060009B0 RID: 2480 RVA: 0x000169F4 File Offset: 0x00014BF4
	[Token(Token = "0x60009B0")]
	[Address(RVA = "0x25CD808", Offset = "0x25CD808", VA = "0x25CD808")]
	public void method_74()
	{
		IEnumerator routine = this.method_3();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009B1 RID: 2481 RVA: 0x00016A10 File Offset: 0x00014C10
	[Address(RVA = "0x25CD834", Offset = "0x25CD834", VA = "0x25CD834")]
	[Token(Token = "0x60009B1")]
	public void method_75()
	{
		IEnumerator routine = this.method_84();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009B2 RID: 2482 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009B2")]
	[Address(RVA = "0x25CCA08", Offset = "0x25CCA08", VA = "0x25CCA08")]
	public IEnumerator method_76()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B3 RID: 2483 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CD8D8", Offset = "0x25CD8D8", VA = "0x25CD8D8")]
	[Token(Token = "0x60009B3")]
	private void method_77()
	{
	}

	// Token: 0x060009B4 RID: 2484 RVA: 0x00016A2C File Offset: 0x00014C2C
	[Token(Token = "0x60009B4")]
	[Address(RVA = "0x25CD8EC", Offset = "0x25CD8EC", VA = "0x25CD8EC")]
	public void method_78()
	{
		this.method_79();
	}

	// Token: 0x060009B5 RID: 2485 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CD918", Offset = "0x25CD918", VA = "0x25CD918")]
	[Token(Token = "0x60009B5")]
	public IEnumerator method_79()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009B6 RID: 2486 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x60009B6")]
	[Address(RVA = "0x25CD990", Offset = "0x25CD990", VA = "0x25CD990")]
	private void method_80()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009B7 RID: 2487 RVA: 0x00016A40 File Offset: 0x00014C40
	[Address(RVA = "0x25CD9A8", Offset = "0x25CD9A8", VA = "0x25CD9A8")]
	[Token(Token = "0x60009B7")]
	public void method_81()
	{
		IEnumerator routine = this.method_19();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009B8 RID: 2488 RVA: 0x00016970 File Offset: 0x00014B70
	[Token(Token = "0x60009B8")]
	[Address(RVA = "0x25CD9D4", Offset = "0x25CD9D4", VA = "0x25CD9D4")]
	public void method_82()
	{
		IEnumerator routine = this.method_110();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009B9 RID: 2489 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CDA00", Offset = "0x25CDA00", VA = "0x25CDA00")]
	[Token(Token = "0x60009B9")]
	private void Update()
	{
	}

	// Token: 0x060009BA RID: 2490 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CDA14", Offset = "0x25CDA14", VA = "0x25CDA14")]
	[Token(Token = "0x60009BA")]
	private void method_83()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009BB RID: 2491 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009BB")]
	[Address(RVA = "0x25CD860", Offset = "0x25CD860", VA = "0x25CD860")]
	public IEnumerator method_84()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009BC RID: 2492 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CDA2C", Offset = "0x25CDA2C", VA = "0x25CDA2C")]
	[Token(Token = "0x60009BC")]
	public IEnumerator method_85()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009BD RID: 2493 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x60009BD")]
	[Address(RVA = "0x25CDAA4", Offset = "0x25CDAA4", VA = "0x25CDAA4")]
	private void method_86()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009BE RID: 2494 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009BE")]
	[Address(RVA = "0x25CDABC", Offset = "0x25CDABC", VA = "0x25CDABC")]
	public IEnumerator method_87()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009BF RID: 2495 RVA: 0x00016804 File Offset: 0x00014A04
	[Token(Token = "0x60009BF")]
	[Address(RVA = "0x25CDB34", Offset = "0x25CDB34", VA = "0x25CDB34")]
	public void method_88()
	{
		IEnumerator routine = this.method_11();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009C0 RID: 2496 RVA: 0x00016A5C File Offset: 0x00014C5C
	[Address(RVA = "0x25CDB60", Offset = "0x25CDB60", VA = "0x25CDB60")]
	[Token(Token = "0x60009C0")]
	public void Awake()
	{
		IEnumerator routine = this.method_107();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009C1 RID: 2497 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x60009C1")]
	[Address(RVA = "0x25CDC04", Offset = "0x25CDC04", VA = "0x25CDC04")]
	private void method_89()
	{
	}

	// Token: 0x060009C2 RID: 2498 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009C2")]
	[Address(RVA = "0x25CD184", Offset = "0x25CD184", VA = "0x25CD184")]
	public IEnumerator method_90()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009C3 RID: 2499 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CDC18", Offset = "0x25CDC18", VA = "0x25CDC18")]
	[Token(Token = "0x60009C3")]
	public IEnumerator method_91()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009C4 RID: 2500 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CDC90", Offset = "0x25CDC90", VA = "0x25CDC90")]
	[Token(Token = "0x60009C4")]
	private void method_92()
	{
	}

	// Token: 0x060009C5 RID: 2501 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009C5")]
	[Address(RVA = "0x25CD790", Offset = "0x25CD790", VA = "0x25CD790")]
	public IEnumerator method_93()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009C6 RID: 2502 RVA: 0x00016A78 File Offset: 0x00014C78
	[Address(RVA = "0x25CDCA4", Offset = "0x25CDCA4", VA = "0x25CDCA4")]
	[Token(Token = "0x60009C6")]
	public void method_94()
	{
		IEnumerator routine = this.method_7();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009C7 RID: 2503 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC8EC", Offset = "0x25CC8EC", VA = "0x25CC8EC")]
	[Token(Token = "0x60009C7")]
	public IEnumerator method_95()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009C8 RID: 2504 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CDCD0", Offset = "0x25CDCD0", VA = "0x25CDCD0")]
	[Token(Token = "0x60009C8")]
	private void method_96()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009C9 RID: 2505 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CDCE8", Offset = "0x25CDCE8", VA = "0x25CDCE8")]
	[Token(Token = "0x60009C9")]
	private void method_97()
	{
	}

	// Token: 0x060009CA RID: 2506 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CDCFC", Offset = "0x25CDCFC", VA = "0x25CDCFC")]
	[Token(Token = "0x60009CA")]
	private void method_98()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009CB RID: 2507 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60009CB")]
	[Address(RVA = "0x25CDD14", Offset = "0x25CDD14", VA = "0x25CDD14")]
	public TextureArraySwapper()
	{
	}

	// Token: 0x060009CC RID: 2508 RVA: 0x00016A94 File Offset: 0x00014C94
	[Token(Token = "0x60009CC")]
	[Address(RVA = "0x25CDD1C", Offset = "0x25CDD1C", VA = "0x25CDD1C")]
	public IEnumerator method_99()
	{
		new TextureArraySwapper.Class11((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060009CD RID: 2509 RVA: 0x000167B4 File Offset: 0x000149B4
	[Address(RVA = "0x25CDD94", Offset = "0x25CDD94", VA = "0x25CDD94")]
	[Token(Token = "0x60009CD")]
	private void method_100()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009CE RID: 2510 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009CE")]
	[Address(RVA = "0x25CDDAC", Offset = "0x25CDDAC", VA = "0x25CDDAC")]
	public IEnumerator method_101()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009CF RID: 2511 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CCEFC", Offset = "0x25CCEFC", VA = "0x25CCEFC")]
	[Token(Token = "0x60009CF")]
	public IEnumerator method_102()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D0 RID: 2512 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x60009D0")]
	[Address(RVA = "0x25CDE24", Offset = "0x25CDE24", VA = "0x25CDE24")]
	private void method_103()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009D1 RID: 2513 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CDE3C", Offset = "0x25CDE3C", VA = "0x25CDE3C")]
	[Token(Token = "0x60009D1")]
	public IEnumerator method_104()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D2 RID: 2514 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CDEB4", Offset = "0x25CDEB4", VA = "0x25CDEB4")]
	[Token(Token = "0x60009D2")]
	public IEnumerator method_105()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D3 RID: 2515 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009D3")]
	[Address(RVA = "0x25CDF2C", Offset = "0x25CDF2C", VA = "0x25CDF2C")]
	public IEnumerator method_106()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D4 RID: 2516 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009D4")]
	[Address(RVA = "0x25CDB8C", Offset = "0x25CDB8C", VA = "0x25CDB8C")]
	public IEnumerator method_107()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D5 RID: 2517 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009D5")]
	[Address(RVA = "0x25CDFA4", Offset = "0x25CDFA4", VA = "0x25CDFA4")]
	public IEnumerator method_108()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D6 RID: 2518 RVA: 0x00016AB8 File Offset: 0x00014CB8
	[Token(Token = "0x60009D6")]
	[Address(RVA = "0x25CE01C", Offset = "0x25CE01C", VA = "0x25CE01C")]
	public void method_109()
	{
		IEnumerator routine = this.method_31();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009D7 RID: 2519 RVA: 0x00016770 File Offset: 0x00014970
	[Token(Token = "0x60009D7")]
	[Address(RVA = "0x25CD524", Offset = "0x25CD524", VA = "0x25CD524")]
	public IEnumerator method_110()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009D8 RID: 2520 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x60009D8")]
	[Address(RVA = "0x25CE048", Offset = "0x25CE048", VA = "0x25CE048")]
	private void method_111()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009D9 RID: 2521 RVA: 0x0000F798 File Offset: 0x0000D998
	[Address(RVA = "0x25CE060", Offset = "0x25CE060", VA = "0x25CE060")]
	[Token(Token = "0x60009D9")]
	private void method_112()
	{
	}

	// Token: 0x060009DA RID: 2522 RVA: 0x0000F798 File Offset: 0x0000D998
	[Token(Token = "0x60009DA")]
	[Address(RVA = "0x25CE074", Offset = "0x25CE074", VA = "0x25CE074")]
	private void method_113()
	{
	}

	// Token: 0x060009DB RID: 2523 RVA: 0x00016770 File Offset: 0x00014970
	[Address(RVA = "0x25CC5B4", Offset = "0x25CC5B4", VA = "0x25CC5B4")]
	[Token(Token = "0x60009DB")]
	public IEnumerator method_114()
	{
		TextureArraySwapper.Class11 @class = new TextureArraySwapper.Class11((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060009DC RID: 2524 RVA: 0x00016A5C File Offset: 0x00014C5C
	[Address(RVA = "0x25CE088", Offset = "0x25CE088", VA = "0x25CE088")]
	[Token(Token = "0x60009DC")]
	public void method_115()
	{
		IEnumerator routine = this.method_107();
		base.StartCoroutine(routine);
	}

	// Token: 0x060009DD RID: 2525 RVA: 0x000167B4 File Offset: 0x000149B4
	[Token(Token = "0x60009DD")]
	[Address(RVA = "0x25CE0B4", Offset = "0x25CE0B4", VA = "0x25CE0B4")]
	private void method_116()
	{
		long num = 1L;
		this.int_0 = (int)num;
	}

	// Token: 0x060009DE RID: 2526 RVA: 0x00016AD4 File Offset: 0x00014CD4
	[Address(RVA = "0x25CE0CC", Offset = "0x25CE0CC", VA = "0x25CE0CC")]
	[Token(Token = "0x60009DE")]
	private void method_117()
	{
		int num = this.int_0;
		this.int_0 = num;
	}

	// Token: 0x0400016D RID: 365
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400016D")]
	public Material material_0;

	// Token: 0x0400016E RID: 366
	[Token(Token = "0x400016E")]
	[FieldOffset(Offset = "0x20")]
	public Texture2D[] texture2D_0;

	// Token: 0x0400016F RID: 367
	[Token(Token = "0x400016F")]
	[FieldOffset(Offset = "0x28")]
	public float float_0;

	// Token: 0x04000170 RID: 368
	[Token(Token = "0x4000170")]
	[FieldOffset(Offset = "0x2C")]
	private int int_0;
}
