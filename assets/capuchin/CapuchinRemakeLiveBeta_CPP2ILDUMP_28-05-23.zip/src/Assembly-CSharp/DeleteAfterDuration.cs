﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000028 RID: 40
[Token(Token = "0x2000028")]
public class DeleteAfterDuration : MonoBehaviour
{
	// Token: 0x060004D8 RID: 1240 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A07F78", Offset = "0x2A07F78", VA = "0x2A07F78")]
	[Token(Token = "0x60004D8")]
	public void method_0()
	{
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004D9")]
	[Address(RVA = "0x2A07FF0", Offset = "0x2A07FF0", VA = "0x2A07FF0")]
	public void method_1()
	{
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08068", Offset = "0x2A08068", VA = "0x2A08068")]
	[Token(Token = "0x60004DA")]
	public void method_2()
	{
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60004DB")]
	[Address(RVA = "0x2A080E0", Offset = "0x2A080E0", VA = "0x2A080E0")]
	public DeleteAfterDuration()
	{
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004DC")]
	[Address(RVA = "0x2A080E8", Offset = "0x2A080E8", VA = "0x2A080E8")]
	public void method_3()
	{
	}

	// Token: 0x060004DD RID: 1245 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08160", Offset = "0x2A08160", VA = "0x2A08160")]
	[Token(Token = "0x60004DD")]
	public void method_4()
	{
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004DE")]
	[Address(RVA = "0x2A081D8", Offset = "0x2A081D8", VA = "0x2A081D8")]
	public void method_5()
	{
	}

	// Token: 0x060004DF RID: 1247 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08250", Offset = "0x2A08250", VA = "0x2A08250")]
	[Token(Token = "0x60004DF")]
	public void method_6()
	{
	}

	// Token: 0x060004E0 RID: 1248 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A082C8", Offset = "0x2A082C8", VA = "0x2A082C8")]
	[Token(Token = "0x60004E0")]
	public void method_7()
	{
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004E1")]
	[Address(RVA = "0x2A08340", Offset = "0x2A08340", VA = "0x2A08340")]
	public void method_8()
	{
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A083B8", Offset = "0x2A083B8", VA = "0x2A083B8")]
	[Token(Token = "0x60004E2")]
	public void method_9()
	{
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08430", Offset = "0x2A08430", VA = "0x2A08430")]
	[Token(Token = "0x60004E3")]
	public void method_10()
	{
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A084A8", Offset = "0x2A084A8", VA = "0x2A084A8")]
	[Token(Token = "0x60004E4")]
	public void method_11()
	{
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08520", Offset = "0x2A08520", VA = "0x2A08520")]
	[Token(Token = "0x60004E5")]
	public void method_12()
	{
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08598", Offset = "0x2A08598", VA = "0x2A08598")]
	[Token(Token = "0x60004E6")]
	public void method_13()
	{
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004E7")]
	[Address(RVA = "0x2A08610", Offset = "0x2A08610", VA = "0x2A08610")]
	public void method_14()
	{
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004E8")]
	[Address(RVA = "0x2A08688", Offset = "0x2A08688", VA = "0x2A08688")]
	public void method_15()
	{
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08700", Offset = "0x2A08700", VA = "0x2A08700")]
	[Token(Token = "0x60004E9")]
	public void method_16()
	{
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08778", Offset = "0x2A08778", VA = "0x2A08778")]
	[Token(Token = "0x60004EA")]
	public void method_17()
	{
	}

	// Token: 0x060004EB RID: 1259 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A087F0", Offset = "0x2A087F0", VA = "0x2A087F0")]
	[Token(Token = "0x60004EB")]
	public void method_18()
	{
	}

	// Token: 0x060004EC RID: 1260 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004EC")]
	[Address(RVA = "0x2A08868", Offset = "0x2A08868", VA = "0x2A08868")]
	public void Start()
	{
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004ED")]
	[Address(RVA = "0x2A088E0", Offset = "0x2A088E0", VA = "0x2A088E0")]
	public void method_19()
	{
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08958", Offset = "0x2A08958", VA = "0x2A08958")]
	[Token(Token = "0x60004EE")]
	public void method_20()
	{
	}

	// Token: 0x060004EF RID: 1263 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A089D0", Offset = "0x2A089D0", VA = "0x2A089D0")]
	[Token(Token = "0x60004EF")]
	public void method_21()
	{
	}

	// Token: 0x060004F0 RID: 1264 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08A48", Offset = "0x2A08A48", VA = "0x2A08A48")]
	[Token(Token = "0x60004F0")]
	public void method_22()
	{
	}

	// Token: 0x060004F1 RID: 1265 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08AC0", Offset = "0x2A08AC0", VA = "0x2A08AC0")]
	[Token(Token = "0x60004F1")]
	public void method_23()
	{
	}

	// Token: 0x060004F2 RID: 1266 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08B38", Offset = "0x2A08B38", VA = "0x2A08B38")]
	[Token(Token = "0x60004F2")]
	public void method_24()
	{
	}

	// Token: 0x060004F3 RID: 1267 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Token(Token = "0x60004F3")]
	[Address(RVA = "0x2A08BB0", Offset = "0x2A08BB0", VA = "0x2A08BB0")]
	public void method_25()
	{
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x0000E0BC File Offset: 0x0000C2BC
	[Address(RVA = "0x2A08C28", Offset = "0x2A08C28", VA = "0x2A08C28")]
	[Token(Token = "0x60004F4")]
	public void method_26()
	{
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x0000E0CC File Offset: 0x0000C2CC
	[Token(Token = "0x60004F5")]
	[Address(RVA = "0x2A08CA0", Offset = "0x2A08CA0", VA = "0x2A08CA0")]
	public void method_27()
	{
	}

	// Token: 0x040000BC RID: 188
	[Token(Token = "0x40000BC")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;

	// Token: 0x040000BD RID: 189
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000BD")]
	public float float_0;
}
