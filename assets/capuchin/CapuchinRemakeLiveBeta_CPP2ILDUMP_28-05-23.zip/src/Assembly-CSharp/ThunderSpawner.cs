﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000FF RID: 255
[Token(Token = "0x20000FF")]
public class ThunderSpawner : MonoBehaviour
{
	// Token: 0x060026D7 RID: 9943 RVA: 0x00048508 File Offset: 0x00046708
	[Token(Token = "0x60026D7")]
	[Address(RVA = "0x25D00E8", Offset = "0x25D00E8", VA = "0x25D00E8")]
	public void method_0()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026D8 RID: 9944 RVA: 0x00048540 File Offset: 0x00046740
	[Token(Token = "0x60026D8")]
	[Address(RVA = "0x25D01D4", Offset = "0x25D01D4", VA = "0x25D01D4")]
	public void method_1()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform;
		Vector3 position = transform.position;
		long maxExclusive2 = 0L;
		UnityEngine.Random.Range(0, (int)maxExclusive2);
	}

	// Token: 0x060026D9 RID: 9945 RVA: 0x0004856C File Offset: 0x0004676C
	[Address(RVA = "0x25D02C0", Offset = "0x25D02C0", VA = "0x25D02C0")]
	[Token(Token = "0x60026D9")]
	public void method_2()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026DA RID: 9946 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D03AC", Offset = "0x25D03AC", VA = "0x25D03AC")]
	[Token(Token = "0x60026DA")]
	public void method_3()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026DB RID: 9947 RVA: 0x000485DC File Offset: 0x000467DC
	[Token(Token = "0x60026DB")]
	[Address(RVA = "0x25D0498", Offset = "0x25D0498", VA = "0x25D0498")]
	public void method_4()
	{
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026DC RID: 9948 RVA: 0x000485DC File Offset: 0x000467DC
	[Address(RVA = "0x25D0584", Offset = "0x25D0584", VA = "0x25D0584")]
	[Token(Token = "0x60026DC")]
	public void method_5()
	{
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026DD RID: 9949 RVA: 0x00048608 File Offset: 0x00046808
	[Address(RVA = "0x25D0670", Offset = "0x25D0670", VA = "0x25D0670")]
	[Token(Token = "0x60026DD")]
	public void method_6()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026DE RID: 9950 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x60026DE")]
	[Address(RVA = "0x25D075C", Offset = "0x25D075C", VA = "0x25D075C")]
	public void method_7()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026DF RID: 9951 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D0848", Offset = "0x25D0848", VA = "0x25D0848")]
	[Token(Token = "0x60026DF")]
	public void method_8()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E0 RID: 9952 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D0934", Offset = "0x25D0934", VA = "0x25D0934")]
	[Token(Token = "0x60026E0")]
	public void method_9()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E1 RID: 9953 RVA: 0x00048640 File Offset: 0x00046840
	[Address(RVA = "0x25D0A20", Offset = "0x25D0A20", VA = "0x25D0A20")]
	[Token(Token = "0x60026E1")]
	public void method_10()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E2 RID: 9954 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D0B0C", Offset = "0x25D0B0C", VA = "0x25D0B0C")]
	[Token(Token = "0x60026E2")]
	public void method_11()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E3 RID: 9955 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D0BF8", Offset = "0x25D0BF8", VA = "0x25D0BF8")]
	[Token(Token = "0x60026E3")]
	public void method_12()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E4 RID: 9956 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D0CE4", Offset = "0x25D0CE4", VA = "0x25D0CE4")]
	[Token(Token = "0x60026E4")]
	public void method_13()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E5 RID: 9957 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D0DD0", Offset = "0x25D0DD0", VA = "0x25D0DD0")]
	[Token(Token = "0x60026E5")]
	public void method_14()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E6 RID: 9958 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026E6")]
	[Address(RVA = "0x25D0EBC", Offset = "0x25D0EBC", VA = "0x25D0EBC")]
	public void method_15()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E7 RID: 9959 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x60026E7")]
	[Address(RVA = "0x25D0FA8", Offset = "0x25D0FA8", VA = "0x25D0FA8")]
	public void method_16()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E8 RID: 9960 RVA: 0x00048678 File Offset: 0x00046878
	[Token(Token = "0x60026E8")]
	[Address(RVA = "0x25D1094", Offset = "0x25D1094", VA = "0x25D1094")]
	public void method_17()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		long maxExclusive2 = 0L;
		UnityEngine.Random.Range(1, (int)maxExclusive2);
		this.particleSystem_0.Play();
	}

	// Token: 0x060026E9 RID: 9961 RVA: 0x00048640 File Offset: 0x00046840
	[Address(RVA = "0x25D1180", Offset = "0x25D1180", VA = "0x25D1180")]
	[Token(Token = "0x60026E9")]
	public void method_18()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026EA RID: 9962 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x60026EA")]
	[Address(RVA = "0x25D126C", Offset = "0x25D126C", VA = "0x25D126C")]
	public void method_19()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026EB RID: 9963 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D1358", Offset = "0x25D1358", VA = "0x25D1358")]
	[Token(Token = "0x60026EB")]
	public void method_20()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026EC RID: 9964 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026EC")]
	[Address(RVA = "0x25D1444", Offset = "0x25D1444", VA = "0x25D1444")]
	public void method_21()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026ED RID: 9965 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D1530", Offset = "0x25D1530", VA = "0x25D1530")]
	[Token(Token = "0x60026ED")]
	public void method_22()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026EE RID: 9966 RVA: 0x00048640 File Offset: 0x00046840
	[Address(RVA = "0x25D161C", Offset = "0x25D161C", VA = "0x25D161C")]
	[Token(Token = "0x60026EE")]
	public void method_23()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026EF RID: 9967 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026EF")]
	[Address(RVA = "0x25D1708", Offset = "0x25D1708", VA = "0x25D1708")]
	public void method_24()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F0 RID: 9968 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026F0")]
	[Address(RVA = "0x25D17F4", Offset = "0x25D17F4", VA = "0x25D17F4")]
	public void method_25()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F1 RID: 9969 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026F1")]
	[Address(RVA = "0x25D18E0", Offset = "0x25D18E0", VA = "0x25D18E0")]
	public void method_26()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F2 RID: 9970 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026F2")]
	[Address(RVA = "0x25D19CC", Offset = "0x25D19CC", VA = "0x25D19CC")]
	public void method_27()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F3 RID: 9971 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x60026F3")]
	[Address(RVA = "0x25D1AB8", Offset = "0x25D1AB8", VA = "0x25D1AB8")]
	public void method_28()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F4 RID: 9972 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x60026F4")]
	[Address(RVA = "0x25D1BA4", Offset = "0x25D1BA4", VA = "0x25D1BA4")]
	public void method_29()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F5 RID: 9973 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026F5")]
	[Address(RVA = "0x25D1C90", Offset = "0x25D1C90", VA = "0x25D1C90")]
	public void method_30()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F6 RID: 9974 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D1D7C", Offset = "0x25D1D7C", VA = "0x25D1D7C")]
	[Token(Token = "0x60026F6")]
	public void method_31()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F7 RID: 9975 RVA: 0x000485DC File Offset: 0x000467DC
	[Address(RVA = "0x25D1E68", Offset = "0x25D1E68", VA = "0x25D1E68")]
	[Token(Token = "0x60026F7")]
	public void method_32()
	{
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F8 RID: 9976 RVA: 0x00048640 File Offset: 0x00046840
	[Address(RVA = "0x25D1F54", Offset = "0x25D1F54", VA = "0x25D1F54")]
	[Token(Token = "0x60026F8")]
	public void method_33()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026F9 RID: 9977 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026F9")]
	[Address(RVA = "0x25D2040", Offset = "0x25D2040", VA = "0x25D2040")]
	public void method_34()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026FA RID: 9978 RVA: 0x000486BC File Offset: 0x000468BC
	[Address(RVA = "0x25D212C", Offset = "0x25D212C", VA = "0x25D212C")]
	[Token(Token = "0x60026FA")]
	public void method_35()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform;
		Vector3 position = transform.position;
	}

	// Token: 0x060026FB RID: 9979 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x60026FB")]
	[Address(RVA = "0x25D2218", Offset = "0x25D2218", VA = "0x25D2218")]
	public void method_36()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026FC RID: 9980 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60026FC")]
	[Address(RVA = "0x25D2304", Offset = "0x25D2304", VA = "0x25D2304")]
	public ThunderSpawner()
	{
	}

	// Token: 0x060026FD RID: 9981 RVA: 0x00048640 File Offset: 0x00046840
	[Address(RVA = "0x25D230C", Offset = "0x25D230C", VA = "0x25D230C")]
	[Token(Token = "0x60026FD")]
	public void method_37()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026FE RID: 9982 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x60026FE")]
	[Address(RVA = "0x25D23F8", Offset = "0x25D23F8", VA = "0x25D23F8")]
	public void method_38()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x060026FF RID: 9983 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x60026FF")]
	[Address(RVA = "0x25D24E4", Offset = "0x25D24E4", VA = "0x25D24E4")]
	public void method_39()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x06002700 RID: 9984 RVA: 0x000485A4 File Offset: 0x000467A4
	[Address(RVA = "0x25D25D0", Offset = "0x25D25D0", VA = "0x25D25D0")]
	[Token(Token = "0x6002700")]
	public void method_40()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x06002701 RID: 9985 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x6002701")]
	[Address(RVA = "0x25D26BC", Offset = "0x25D26BC", VA = "0x25D26BC")]
	public void method_41()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x06002702 RID: 9986 RVA: 0x000486DC File Offset: 0x000468DC
	[Address(RVA = "0x25D27A8", Offset = "0x25D27A8", VA = "0x25D27A8")]
	[Token(Token = "0x6002702")]
	public void method_42()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x06002703 RID: 9987 RVA: 0x00048640 File Offset: 0x00046840
	[Token(Token = "0x6002703")]
	[Address(RVA = "0x25D2894", Offset = "0x25D2894", VA = "0x25D2894")]
	public void method_43()
	{
		long maxExclusive = 0L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x06002704 RID: 9988 RVA: 0x000485A4 File Offset: 0x000467A4
	[Token(Token = "0x6002704")]
	[Address(RVA = "0x25D2980", Offset = "0x25D2980", VA = "0x25D2980")]
	public void method_44()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform = this.gameObject_0.transform;
		Vector3 position = transform.position;
		this.particleSystem_0.Play();
	}

	// Token: 0x06002705 RID: 9989 RVA: 0x00048714 File Offset: 0x00046914
	[Token(Token = "0x6002705")]
	[Address(RVA = "0x25D2A6C", Offset = "0x25D2A6C", VA = "0x25D2A6C")]
	public void method_45()
	{
		long maxExclusive = 1L;
		UnityEngine.Random.Range(this, (int)maxExclusive);
		Transform transform;
		Vector3 position = transform.position;
		long maxExclusive2 = 0L;
		UnityEngine.Random.Range(1, (int)maxExclusive2);
	}

	// Token: 0x040004EC RID: 1260
	[Token(Token = "0x40004EC")]
	[FieldOffset(Offset = "0x18")]
	public Transform[] transform_0;

	// Token: 0x040004ED RID: 1261
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40004ED")]
	public AudioSource audioSource_0;

	// Token: 0x040004EE RID: 1262
	[Token(Token = "0x40004EE")]
	[FieldOffset(Offset = "0x28")]
	public AudioClip[] audioClip_0;

	// Token: 0x040004EF RID: 1263
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004EF")]
	public ParticleSystem particleSystem_0;

	// Token: 0x040004F0 RID: 1264
	[Token(Token = "0x40004F0")]
	[FieldOffset(Offset = "0x38")]
	public GameObject gameObject_0;
}
