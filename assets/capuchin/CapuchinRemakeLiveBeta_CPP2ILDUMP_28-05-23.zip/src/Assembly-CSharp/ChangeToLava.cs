﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x020000B2 RID: 178
[Token(Token = "0x20000B2")]
public class ChangeToLava : MonoBehaviour
{
	// Token: 0x06001969 RID: 6505 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9B4C", Offset = "0x2AE9B4C", VA = "0x2AE9B4C")]
	[Token(Token = "0x6001969")]
	public void method_0()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600196A RID: 6506 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AE9B8C", Offset = "0x2AE9B8C", VA = "0x2AE9B8C")]
	[Token(Token = "0x600196A")]
	public void method_1()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600196B RID: 6507 RVA: 0x00033310 File Offset: 0x00031510
	[Address(RVA = "0x2AE9BCC", Offset = "0x2AE9BCC", VA = "0x2AE9BCC")]
	[Token(Token = "0x600196B")]
	public void method_2()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600196C RID: 6508 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AE9C0C", Offset = "0x2AE9C0C", VA = "0x2AE9C0C")]
	[Token(Token = "0x600196C")]
	public void method_3()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600196D RID: 6509 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AE9C4C", Offset = "0x2AE9C4C", VA = "0x2AE9C4C")]
	[Token(Token = "0x600196D")]
	public void method_4()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600196E RID: 6510 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AE9C8C", Offset = "0x2AE9C8C", VA = "0x2AE9C8C")]
	[Token(Token = "0x600196E")]
	public void method_5()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600196F RID: 6511 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9CCC", Offset = "0x2AE9CCC", VA = "0x2AE9CCC")]
	[Token(Token = "0x600196F")]
	public void method_6()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001970 RID: 6512 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9D0C", Offset = "0x2AE9D0C", VA = "0x2AE9D0C")]
	[Token(Token = "0x6001970")]
	public void method_7()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001971 RID: 6513 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9D4C", Offset = "0x2AE9D4C", VA = "0x2AE9D4C")]
	[Token(Token = "0x6001971")]
	public void method_8()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001972 RID: 6514 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9D8C", Offset = "0x2AE9D8C", VA = "0x2AE9D8C")]
	[Token(Token = "0x6001972")]
	public void method_9()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001973 RID: 6515 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9DCC", Offset = "0x2AE9DCC", VA = "0x2AE9DCC")]
	[Token(Token = "0x6001973")]
	public void method_10()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001974 RID: 6516 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AE9E0C", Offset = "0x2AE9E0C", VA = "0x2AE9E0C")]
	[Token(Token = "0x6001974")]
	public void method_11()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001975 RID: 6517 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AE9E4C", Offset = "0x2AE9E4C", VA = "0x2AE9E4C")]
	[Token(Token = "0x6001975")]
	public void method_12()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001976 RID: 6518 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AE9E8C", Offset = "0x2AE9E8C", VA = "0x2AE9E8C")]
	[Token(Token = "0x6001976")]
	public void method_13()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001977 RID: 6519 RVA: 0x000332C8 File Offset: 0x000314C8
	[PunRPC]
	[Address(RVA = "0x2AE9ECC", Offset = "0x2AE9ECC", VA = "0x2AE9ECC")]
	[Token(Token = "0x6001977")]
	public void ChangeMaterialToNormal()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001978 RID: 6520 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9F0C", Offset = "0x2AE9F0C", VA = "0x2AE9F0C")]
	[Token(Token = "0x6001978")]
	public void method_14()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001979 RID: 6521 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9F4C", Offset = "0x2AE9F4C", VA = "0x2AE9F4C")]
	[Token(Token = "0x6001979")]
	public void method_15()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600197A RID: 6522 RVA: 0x00033334 File Offset: 0x00031534
	[Address(RVA = "0x2AE9F8C", Offset = "0x2AE9F8C", VA = "0x2AE9F8C")]
	[Token(Token = "0x600197A")]
	public void method_16()
	{
	}

	// Token: 0x0600197B RID: 6523 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AE9FCC", Offset = "0x2AE9FCC", VA = "0x2AE9FCC")]
	[Token(Token = "0x600197B")]
	public void method_17()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600197C RID: 6524 RVA: 0x00033344 File Offset: 0x00031544
	[Address(RVA = "0x2AEA00C", Offset = "0x2AEA00C", VA = "0x2AEA00C")]
	[Token(Token = "0x600197C")]
	public void method_18()
	{
	}

	// Token: 0x0600197D RID: 6525 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA04C", Offset = "0x2AEA04C", VA = "0x2AEA04C")]
	[Token(Token = "0x600197D")]
	public void method_19()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600197E RID: 6526 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA08C", Offset = "0x2AEA08C", VA = "0x2AEA08C")]
	[Token(Token = "0x600197E")]
	public void method_20()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600197F RID: 6527 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA0CC", Offset = "0x2AEA0CC", VA = "0x2AEA0CC")]
	[Token(Token = "0x600197F")]
	public void method_21()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001980 RID: 6528 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA10C", Offset = "0x2AEA10C", VA = "0x2AEA10C")]
	[Token(Token = "0x6001980")]
	public void method_22()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001981 RID: 6529 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA14C", Offset = "0x2AEA14C", VA = "0x2AEA14C")]
	[Token(Token = "0x6001981")]
	public void method_23()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001982 RID: 6530 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA18C", Offset = "0x2AEA18C", VA = "0x2AEA18C")]
	[Token(Token = "0x6001982")]
	public void method_24()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001983 RID: 6531 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA1CC", Offset = "0x2AEA1CC", VA = "0x2AEA1CC")]
	[Token(Token = "0x6001983")]
	public void method_25()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001984 RID: 6532 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA20C", Offset = "0x2AEA20C", VA = "0x2AEA20C")]
	[Token(Token = "0x6001984")]
	public void method_26()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001985 RID: 6533 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA24C", Offset = "0x2AEA24C", VA = "0x2AEA24C")]
	[Token(Token = "0x6001985")]
	public void method_27()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001986 RID: 6534 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA28C", Offset = "0x2AEA28C", VA = "0x2AEA28C")]
	[Token(Token = "0x6001986")]
	public void method_28()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001987 RID: 6535 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA2CC", Offset = "0x2AEA2CC", VA = "0x2AEA2CC")]
	[Token(Token = "0x6001987")]
	public void method_29()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001988 RID: 6536 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA30C", Offset = "0x2AEA30C", VA = "0x2AEA30C")]
	[Token(Token = "0x6001988")]
	public void method_30()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001989 RID: 6537 RVA: 0x00033354 File Offset: 0x00031554
	[Address(RVA = "0x2AEA34C", Offset = "0x2AEA34C", VA = "0x2AEA34C")]
	[Token(Token = "0x6001989")]
	public void method_31()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600198A RID: 6538 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA38C", Offset = "0x2AEA38C", VA = "0x2AEA38C")]
	[Token(Token = "0x600198A")]
	public void method_32()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600198B RID: 6539 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA3CC", Offset = "0x2AEA3CC", VA = "0x2AEA3CC")]
	[Token(Token = "0x600198B")]
	public void method_33()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600198C RID: 6540 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA40C", Offset = "0x2AEA40C", VA = "0x2AEA40C")]
	[Token(Token = "0x600198C")]
	public void method_34()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600198D RID: 6541 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA44C", Offset = "0x2AEA44C", VA = "0x2AEA44C")]
	[Token(Token = "0x600198D")]
	public void method_35()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600198E RID: 6542 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA48C", Offset = "0x2AEA48C", VA = "0x2AEA48C")]
	[Token(Token = "0x600198E")]
	public void method_36()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600198F RID: 6543 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA4CC", Offset = "0x2AEA4CC", VA = "0x2AEA4CC")]
	[Token(Token = "0x600198F")]
	public void method_37()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001990 RID: 6544 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA50C", Offset = "0x2AEA50C", VA = "0x2AEA50C")]
	[Token(Token = "0x6001990")]
	public void method_38()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001991 RID: 6545 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA54C", Offset = "0x2AEA54C", VA = "0x2AEA54C")]
	[Token(Token = "0x6001991")]
	public void method_39()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001992 RID: 6546 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA58C", Offset = "0x2AEA58C", VA = "0x2AEA58C")]
	[Token(Token = "0x6001992")]
	public void method_40()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001993 RID: 6547 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA5CC", Offset = "0x2AEA5CC", VA = "0x2AEA5CC")]
	[Token(Token = "0x6001993")]
	public void method_41()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001994 RID: 6548 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA60C", Offset = "0x2AEA60C", VA = "0x2AEA60C")]
	[Token(Token = "0x6001994")]
	public void method_42()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001995 RID: 6549 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA64C", Offset = "0x2AEA64C", VA = "0x2AEA64C")]
	[Token(Token = "0x6001995")]
	public void method_43()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001996 RID: 6550 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA68C", Offset = "0x2AEA68C", VA = "0x2AEA68C")]
	[Token(Token = "0x6001996")]
	public void method_44()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001997 RID: 6551 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA6CC", Offset = "0x2AEA6CC", VA = "0x2AEA6CC")]
	[Token(Token = "0x6001997")]
	public void method_45()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001998 RID: 6552 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA70C", Offset = "0x2AEA70C", VA = "0x2AEA70C")]
	[Token(Token = "0x6001998")]
	public void method_46()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x06001999 RID: 6553 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA74C", Offset = "0x2AEA74C", VA = "0x2AEA74C")]
	[Token(Token = "0x6001999")]
	public void method_47()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600199A RID: 6554 RVA: 0x00033344 File Offset: 0x00031544
	[Address(RVA = "0x2AEA78C", Offset = "0x2AEA78C", VA = "0x2AEA78C")]
	[Token(Token = "0x600199A")]
	public void method_48()
	{
	}

	// Token: 0x0600199B RID: 6555 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA7CC", Offset = "0x2AEA7CC", VA = "0x2AEA7CC")]
	[Token(Token = "0x600199B")]
	public void method_49()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600199C RID: 6556 RVA: 0x00033378 File Offset: 0x00031578
	[Address(RVA = "0x2AEA80C", Offset = "0x2AEA80C", VA = "0x2AEA80C")]
	[Token(Token = "0x600199C")]
	public void method_50()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600199D RID: 6557 RVA: 0x00033310 File Offset: 0x00031510
	[Address(RVA = "0x2AEA84C", Offset = "0x2AEA84C", VA = "0x2AEA84C")]
	[Token(Token = "0x600199D")]
	public void method_51()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600199E RID: 6558 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA88C", Offset = "0x2AEA88C", VA = "0x2AEA88C")]
	[Token(Token = "0x600199E")]
	public void method_52()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x0600199F RID: 6559 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA8CC", Offset = "0x2AEA8CC", VA = "0x2AEA8CC")]
	[Token(Token = "0x600199F")]
	public void method_53()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A0 RID: 6560 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA90C", Offset = "0x2AEA90C", VA = "0x2AEA90C")]
	[Token(Token = "0x60019A0")]
	public void method_54()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A1 RID: 6561 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA94C", Offset = "0x2AEA94C", VA = "0x2AEA94C")]
	[Token(Token = "0x60019A1")]
	public void method_55()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A2 RID: 6562 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEA98C", Offset = "0x2AEA98C", VA = "0x2AEA98C")]
	[Token(Token = "0x60019A2")]
	public void method_56()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A3 RID: 6563 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEA9CC", Offset = "0x2AEA9CC", VA = "0x2AEA9CC")]
	[Token(Token = "0x60019A3")]
	public void method_57()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A4 RID: 6564 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAA0C", Offset = "0x2AEAA0C", VA = "0x2AEAA0C")]
	[Token(Token = "0x60019A4")]
	public void method_58()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A5 RID: 6565 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAA4C", Offset = "0x2AEAA4C", VA = "0x2AEAA4C")]
	[Token(Token = "0x60019A5")]
	public void method_59()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A6 RID: 6566 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAA8C", Offset = "0x2AEAA8C", VA = "0x2AEAA8C")]
	[Token(Token = "0x60019A6")]
	public void method_60()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A7 RID: 6567 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAACC", Offset = "0x2AEAACC", VA = "0x2AEAACC")]
	[Token(Token = "0x60019A7")]
	public void method_61()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A8 RID: 6568 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEAB0C", Offset = "0x2AEAB0C", VA = "0x2AEAB0C")]
	[Token(Token = "0x60019A8")]
	public void method_62()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019A9 RID: 6569 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEAB4C", Offset = "0x2AEAB4C", VA = "0x2AEAB4C")]
	[Token(Token = "0x60019A9")]
	public void method_63()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019AA RID: 6570 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEAB8C", Offset = "0x2AEAB8C", VA = "0x2AEAB8C")]
	[Token(Token = "0x60019AA")]
	public void method_64()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019AB RID: 6571 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEABCC", Offset = "0x2AEABCC", VA = "0x2AEABCC")]
	[Token(Token = "0x60019AB")]
	public void method_65()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019AC RID: 6572 RVA: 0x000332EC File Offset: 0x000314EC
	[PunRPC]
	[Address(RVA = "0x2AEAC0C", Offset = "0x2AEAC0C", VA = "0x2AEAC0C")]
	[Token(Token = "0x60019AC")]
	public void ChangeMaterialToLava()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019AD RID: 6573 RVA: 0x00033334 File Offset: 0x00031534
	[Address(RVA = "0x2AEAC4C", Offset = "0x2AEAC4C", VA = "0x2AEAC4C")]
	[Token(Token = "0x60019AD")]
	public void method_66()
	{
	}

	// Token: 0x060019AE RID: 6574 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEAC8C", Offset = "0x2AEAC8C", VA = "0x2AEAC8C")]
	[Token(Token = "0x60019AE")]
	public void method_67()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019AF RID: 6575 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEACCC", Offset = "0x2AEACCC", VA = "0x2AEACCC")]
	[Token(Token = "0x60019AF")]
	public void method_68()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B0 RID: 6576 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAD0C", Offset = "0x2AEAD0C", VA = "0x2AEAD0C")]
	[Token(Token = "0x60019B0")]
	public void method_69()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B1 RID: 6577 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEAD4C", Offset = "0x2AEAD4C", VA = "0x2AEAD4C")]
	[Token(Token = "0x60019B1")]
	public void method_70()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B2 RID: 6578 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAD8C", Offset = "0x2AEAD8C", VA = "0x2AEAD8C")]
	[Token(Token = "0x60019B2")]
	public void method_71()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B3 RID: 6579 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEADCC", Offset = "0x2AEADCC", VA = "0x2AEADCC")]
	[Token(Token = "0x60019B3")]
	public void method_72()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B4 RID: 6580 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEAE0C", Offset = "0x2AEAE0C", VA = "0x2AEAE0C")]
	[Token(Token = "0x60019B4")]
	public void method_73()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B5 RID: 6581 RVA: 0x00033344 File Offset: 0x00031544
	[Address(RVA = "0x2AEAE4C", Offset = "0x2AEAE4C", VA = "0x2AEAE4C")]
	[Token(Token = "0x60019B5")]
	public void method_74()
	{
	}

	// Token: 0x060019B6 RID: 6582 RVA: 0x00033378 File Offset: 0x00031578
	[Address(RVA = "0x2AEAE8C", Offset = "0x2AEAE8C", VA = "0x2AEAE8C")]
	[Token(Token = "0x60019B6")]
	public void method_75()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B7 RID: 6583 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEAECC", Offset = "0x2AEAECC", VA = "0x2AEAECC")]
	[Token(Token = "0x60019B7")]
	public void method_76()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B8 RID: 6584 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAF0C", Offset = "0x2AEAF0C", VA = "0x2AEAF0C")]
	[Token(Token = "0x60019B8")]
	public void method_77()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019B9 RID: 6585 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAF4C", Offset = "0x2AEAF4C", VA = "0x2AEAF4C")]
	[Token(Token = "0x60019B9")]
	public void method_78()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019BA RID: 6586 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAF8C", Offset = "0x2AEAF8C", VA = "0x2AEAF8C")]
	[Token(Token = "0x60019BA")]
	public void method_79()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019BB RID: 6587 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEAFCC", Offset = "0x2AEAFCC", VA = "0x2AEAFCC")]
	[Token(Token = "0x60019BB")]
	public void method_80()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019BC RID: 6588 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2AEB00C", Offset = "0x2AEB00C", VA = "0x2AEB00C")]
	[Token(Token = "0x60019BC")]
	public ChangeToLava()
	{
	}

	// Token: 0x060019BD RID: 6589 RVA: 0x0003339C File Offset: 0x0003159C
	[Address(RVA = "0x2AEB014", Offset = "0x2AEB014", VA = "0x2AEB014")]
	[Token(Token = "0x60019BD")]
	public void method_81()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019BE RID: 6590 RVA: 0x000332C8 File Offset: 0x000314C8
	[Address(RVA = "0x2AEB054", Offset = "0x2AEB054", VA = "0x2AEB054")]
	[Token(Token = "0x60019BE")]
	public void method_82()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_0;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019BF RID: 6591 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEB094", Offset = "0x2AEB094", VA = "0x2AEB094")]
	[Token(Token = "0x60019BF")]
	public void method_83()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019C0 RID: 6592 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEB0D4", Offset = "0x2AEB0D4", VA = "0x2AEB0D4")]
	[Token(Token = "0x60019C0")]
	public void method_84()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019C1 RID: 6593 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEB114", Offset = "0x2AEB114", VA = "0x2AEB114")]
	[Token(Token = "0x60019C1")]
	public void method_85()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x060019C2 RID: 6594 RVA: 0x000332EC File Offset: 0x000314EC
	[Address(RVA = "0x2AEB154", Offset = "0x2AEB154", VA = "0x2AEB154")]
	[Token(Token = "0x60019C2")]
	public void method_86()
	{
		SkinnedMeshRenderer skinnedMeshRenderer = this.skinnedMeshRenderer_0;
		Material material = this.material_1;
		skinnedMeshRenderer.material = material;
	}

	// Token: 0x04000348 RID: 840
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000348")]
	public SkinnedMeshRenderer skinnedMeshRenderer_0;

	// Token: 0x04000349 RID: 841
	[Token(Token = "0x4000349")]
	[FieldOffset(Offset = "0x20")]
	public Material material_0;

	// Token: 0x0400034A RID: 842
	[Token(Token = "0x400034A")]
	[FieldOffset(Offset = "0x28")]
	public Material material_1;

	// Token: 0x0400034B RID: 843
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400034B")]
	public PhotonView photonView_0;
}
