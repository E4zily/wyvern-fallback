﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200001B RID: 27
[Token(Token = "0x200001B")]
public class RendererDisable : MonoBehaviour
{
	// Token: 0x06000357 RID: 855 RVA: 0x0000AD14 File Offset: 0x00008F14
	[Address(RVA = "0x3483830", Offset = "0x3483830", VA = "0x3483830")]
	[Token(Token = "0x6000357")]
	private void method_0()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			long num = 256L;
			long num2 = 1L;
			this.bool_0 = (num != 0L);
			this.bool_3 = (num2 != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 1L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		base.GetComponentsInChildren<BoxCollider>();
	}

	// Token: 0x06000358 RID: 856 RVA: 0x0000AD84 File Offset: 0x00008F84
	[Address(RVA = "0x3483A60", Offset = "0x3483A60", VA = "0x3483A60")]
	[Token(Token = "0x6000358")]
	private void method_1()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000359 RID: 857 RVA: 0x0000ADA8 File Offset: 0x00008FA8
	[Token(Token = "0x6000359")]
	[Address(RVA = "0x3483C5C", Offset = "0x3483C5C", VA = "0x3483C5C")]
	private void method_2()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.bool_3 = (num != 0L);
	}

	// Token: 0x0600035A RID: 858 RVA: 0x0000ADE0 File Offset: 0x00008FE0
	[Address(RVA = "0x3483E20", Offset = "0x3483E20", VA = "0x3483E20")]
	[Token(Token = "0x600035A")]
	private void method_3()
	{
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
		long enabled3 = 1L;
		componentsInChildren3.enabled = (enabled3 != 0L);
		base.GetComponentsInChildren<SphereCollider>();
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0000AE34 File Offset: 0x00009034
	[Token(Token = "0x600035B")]
	[Address(RVA = "0x348401C", Offset = "0x348401C", VA = "0x348401C")]
	private void method_4()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x0600035C RID: 860 RVA: 0x0000AE70 File Offset: 0x00009070
	[Address(RVA = "0x3484234", Offset = "0x3484234", VA = "0x3484234")]
	[Token(Token = "0x600035C")]
	private void method_5()
	{
	}

	// Token: 0x0600035D RID: 861 RVA: 0x0000AE80 File Offset: 0x00009080
	[Address(RVA = "0x3484418", Offset = "0x3484418", VA = "0x3484418")]
	[Token(Token = "0x600035D")]
	private void method_6()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600035E RID: 862 RVA: 0x0000AEA4 File Offset: 0x000090A4
	[Token(Token = "0x600035E")]
	[Address(RVA = "0x34845EC", Offset = "0x34845EC", VA = "0x34845EC")]
	private void method_7()
	{
	}

	// Token: 0x0600035F RID: 863 RVA: 0x0000AEB4 File Offset: 0x000090B4
	[Address(RVA = "0x34847E8", Offset = "0x34847E8", VA = "0x34847E8")]
	[Token(Token = "0x600035F")]
	private void method_8()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x06000360 RID: 864 RVA: 0x0000AEF0 File Offset: 0x000090F0
	[Address(RVA = "0x34849F4", Offset = "0x34849F4", VA = "0x34849F4")]
	[Token(Token = "0x6000360")]
	private void method_9()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000361 RID: 865 RVA: 0x0000AF14 File Offset: 0x00009114
	[Token(Token = "0x6000361")]
	[Address(RVA = "0x3484BE4", Offset = "0x3484BE4", VA = "0x3484BE4")]
	private void method_10()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 1L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			long enabled2 = 1L;
			componentsInChildren2.enabled = (enabled2 != 0L);
			BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
			long enabled3 = 1L;
			componentsInChildren3.enabled = (enabled3 != 0L);
			base.GetComponentsInChildren<SphereCollider>();
			return;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06000362 RID: 866 RVA: 0x0000AF80 File Offset: 0x00009180
	[Token(Token = "0x6000362")]
	[Address(RVA = "0x3484DE0", Offset = "0x3484DE0", VA = "0x3484DE0")]
	private void method_11()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000363 RID: 867 RVA: 0x0000AFA4 File Offset: 0x000091A4
	[Address(RVA = "0x3484FC0", Offset = "0x3484FC0", VA = "0x3484FC0")]
	[Token(Token = "0x6000363")]
	private void method_12()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 1L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			long enabled2 = 0L;
			componentsInChildren2.enabled = (enabled2 != 0L);
			base.GetComponentsInChildren<BoxCollider>();
			return;
		}
		this.bool_0 = (257 != 0);
	}

	// Token: 0x06000364 RID: 868 RVA: 0x0000AFF4 File Offset: 0x000091F4
	[Token(Token = "0x6000364")]
	[Address(RVA = "0x34851A0", Offset = "0x34851A0", VA = "0x34851A0")]
	private void method_13()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000365 RID: 869 RVA: 0x0000B018 File Offset: 0x00009218
	[Token(Token = "0x6000365")]
	[Address(RVA = "0x3485380", Offset = "0x3485380", VA = "0x3485380")]
	private void method_14()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			long num = 256L;
			this.bool_0 = (num != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		componentsInChildren.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x06000366 RID: 870 RVA: 0x0000B064 File Offset: 0x00009264
	[Token(Token = "0x6000366")]
	[Address(RVA = "0x3485580", Offset = "0x3485580", VA = "0x3485580")]
	private void method_15()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000367 RID: 871 RVA: 0x0000B088 File Offset: 0x00009288
	[Token(Token = "0x6000367")]
	[Address(RVA = "0x3485720", Offset = "0x3485720", VA = "0x3485720")]
	private void method_16()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			long num = 256L;
			long num2 = 1L;
			this.bool_0 = (num != 0L);
			this.bool_3 = (num2 != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
		long enabled3 = 1L;
		componentsInChildren3.enabled = (enabled3 != 0L);
		BoxCollider[] componentsInChildren4 = base.GetComponentsInChildren<BoxCollider>();
		if (this.bool_3)
		{
			return;
		}
		long enabled4 = 0L;
		componentsInChildren4.enabled = (enabled4 != 0L);
	}

	// Token: 0x06000368 RID: 872 RVA: 0x0000B124 File Offset: 0x00009324
	[Address(RVA = "0x348595C", Offset = "0x348595C", VA = "0x348595C")]
	[Token(Token = "0x6000368")]
	private void method_17()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			base.GetComponentsInChildren<CapsuleCollider>();
			return;
		}
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06000369 RID: 873 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3485B58", Offset = "0x3485B58", VA = "0x3485B58")]
	[Token(Token = "0x6000369")]
	private void method_18()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600036A RID: 874 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600036A")]
	[Address(RVA = "0x3485D48", Offset = "0x3485D48", VA = "0x3485D48")]
	private void method_19()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600036B RID: 875 RVA: 0x0000B158 File Offset: 0x00009358
	[Address(RVA = "0x3485F54", Offset = "0x3485F54", VA = "0x3485F54")]
	[Token(Token = "0x600036B")]
	private void method_20()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 0L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			long enabled2 = 1L;
			componentsInChildren2.enabled = (enabled2 != 0L);
			base.GetComponentsInChildren<BoxCollider>();
			return;
		}
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x0600036C RID: 876 RVA: 0x0000B1A8 File Offset: 0x000093A8
	[Address(RVA = "0x3486144", Offset = "0x3486144", VA = "0x3486144")]
	[Token(Token = "0x600036C")]
	private void method_21()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 0L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			long enabled2 = 1L;
			componentsInChildren2.enabled = (enabled2 != 0L);
			BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
			long enabled3 = 0L;
			componentsInChildren3.enabled = (enabled3 != 0L);
			base.GetComponentsInChildren<SphereCollider>();
			return;
		}
		long num = 1L;
		this.bool_0 = (257 != 0);
		this.bool_3 = (num != 0L);
	}

	// Token: 0x0600036D RID: 877 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600036D")]
	[Address(RVA = "0x3486344", Offset = "0x3486344", VA = "0x3486344")]
	private void method_22()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600036E RID: 878 RVA: 0x0000B218 File Offset: 0x00009418
	[Token(Token = "0x600036E")]
	[Address(RVA = "0x3486534", Offset = "0x3486534", VA = "0x3486534")]
	private void method_23()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
		long num = 256L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600036F RID: 879 RVA: 0x0000B24C File Offset: 0x0000944C
	[Address(RVA = "0x34866F8", Offset = "0x34866F8", VA = "0x34866F8")]
	[Token(Token = "0x600036F")]
	private void method_24()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			this.bool_0 = (257 != 0);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 1L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		base.GetComponentsInChildren<BoxCollider>();
	}

	// Token: 0x06000370 RID: 880 RVA: 0x0000B2B0 File Offset: 0x000094B0
	[Token(Token = "0x6000370")]
	[Address(RVA = "0x3486914", Offset = "0x3486914", VA = "0x3486914")]
	private void method_25()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
		long num = 256L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x06000371 RID: 881 RVA: 0x0000B2E4 File Offset: 0x000094E4
	[Token(Token = "0x6000371")]
	[Address(RVA = "0x3486B24", Offset = "0x3486B24", VA = "0x3486B24")]
	private void method_26()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			long num = 1L;
			this.bool_0 = (num != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
		long enabled3 = 1L;
		componentsInChildren3.enabled = (enabled3 != 0L);
		base.GetComponentsInChildren<SphereCollider>();
	}

	// Token: 0x06000372 RID: 882 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000372")]
	[Address(RVA = "0x3486D30", Offset = "0x3486D30", VA = "0x3486D30")]
	private void method_27()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000373 RID: 883 RVA: 0x0000B350 File Offset: 0x00009550
	[Address(RVA = "0x3486F10", Offset = "0x3486F10", VA = "0x3486F10")]
	[Token(Token = "0x6000373")]
	private void method_28()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 1L;
			componentsInChildren.enabled = (enabled != 0L);
			base.GetComponentsInChildren<CapsuleCollider>();
			return;
		}
	}

	// Token: 0x06000374 RID: 884 RVA: 0x0000B384 File Offset: 0x00009584
	[Token(Token = "0x6000374")]
	[Address(RVA = "0x34870F0", Offset = "0x34870F0", VA = "0x34870F0")]
	private void method_29()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000375 RID: 885 RVA: 0x0000AEF0 File Offset: 0x000090F0
	[Address(RVA = "0x348730C", Offset = "0x348730C", VA = "0x348730C")]
	[Token(Token = "0x6000375")]
	private void method_30()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000376 RID: 886 RVA: 0x0000B3A8 File Offset: 0x000095A8
	[Address(RVA = "0x3487494", Offset = "0x3487494", VA = "0x3487494")]
	[Token(Token = "0x6000376")]
	private void method_31()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x06000377 RID: 887 RVA: 0x0000B3E4 File Offset: 0x000095E4
	[Token(Token = "0x6000377")]
	[Address(RVA = "0x3487694", Offset = "0x3487694", VA = "0x3487694")]
	private void method_32()
	{
		if (this.photonView_0 == null)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		long enabled2;
		if (this.bool_1)
		{
			enabled2 = 1L;
			return;
		}
		componentsInChildren2.enabled = (enabled2 != 0L);
		base.GetComponentsInChildren<BoxCollider>();
	}

	// Token: 0x06000378 RID: 888 RVA: 0x0000B438 File Offset: 0x00009638
	[Address(RVA = "0x348789C", Offset = "0x348789C", VA = "0x348789C")]
	[Token(Token = "0x6000378")]
	private void method_33()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000379 RID: 889 RVA: 0x0000B45C File Offset: 0x0000965C
	[Token(Token = "0x6000379")]
	[Address(RVA = "0x3487A60", Offset = "0x3487A60", VA = "0x3487A60")]
	private void method_34()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600037A RID: 890 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3487C40", Offset = "0x3487C40", VA = "0x3487C40")]
	[Token(Token = "0x600037A")]
	private void method_35()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x0600037B RID: 891 RVA: 0x0000B480 File Offset: 0x00009680
	[Token(Token = "0x600037B")]
	[Address(RVA = "0x3487E10", Offset = "0x3487E10", VA = "0x3487E10")]
	private void method_36()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
		this.bool_0 = (257 != 0);
	}

	// Token: 0x0600037C RID: 892 RVA: 0x0000B4B0 File Offset: 0x000096B0
	[Token(Token = "0x600037C")]
	[Address(RVA = "0x3487FD4", Offset = "0x3487FD4", VA = "0x3487FD4")]
	private void method_37()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x0600037D RID: 893 RVA: 0x0000B4D4 File Offset: 0x000096D4
	[Token(Token = "0x600037D")]
	[Address(RVA = "0x3488188", Offset = "0x3488188", VA = "0x3488188")]
	private void Update()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			long num = 1L;
			this.bool_0 = (257 != 0);
			this.bool_3 = (num != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		BoxCollider[] componentsInChildren3 = base.GetComponentsInChildren<BoxCollider>();
		if (this.bool_2)
		{
			return;
		}
		long enabled3 = 0L;
		componentsInChildren3.enabled = (enabled3 != 0L);
		SphereCollider[] componentsInChildren4 = base.GetComponentsInChildren<SphereCollider>();
		if (this.bool_3)
		{
			return;
		}
		long enabled4 = 0L;
		componentsInChildren4.enabled = (enabled4 != 0L);
	}

	// Token: 0x0600037E RID: 894 RVA: 0x0000B574 File Offset: 0x00009774
	[Address(RVA = "0x34883D4", Offset = "0x34883D4", VA = "0x34883D4")]
	[Token(Token = "0x600037E")]
	private void method_38()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x0600037F RID: 895 RVA: 0x0000B5B0 File Offset: 0x000097B0
	[Token(Token = "0x600037F")]
	[Address(RVA = "0x34885B8", Offset = "0x34885B8", VA = "0x34885B8")]
	private void method_39()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			long num = 256L;
			long num2 = 1L;
			this.bool_0 = (num != 0L);
			this.bool_3 = (num2 != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 1L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		base.GetComponentsInChildren<BoxCollider>();
	}

	// Token: 0x06000380 RID: 896 RVA: 0x0000B618 File Offset: 0x00009818
	[Token(Token = "0x6000380")]
	[Address(RVA = "0x34887AC", Offset = "0x34887AC", VA = "0x34887AC")]
	private void method_40()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000381 RID: 897 RVA: 0x0000B63C File Offset: 0x0000983C
	[Token(Token = "0x6000381")]
	[Address(RVA = "0x3488980", Offset = "0x3488980", VA = "0x3488980")]
	private void method_41()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000382 RID: 898 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3488B3C", Offset = "0x3488B3C", VA = "0x3488B3C")]
	[Token(Token = "0x6000382")]
	public RendererDisable()
	{
	}

	// Token: 0x06000383 RID: 899 RVA: 0x0000B064 File Offset: 0x00009264
	[Address(RVA = "0x3488B44", Offset = "0x3488B44", VA = "0x3488B44")]
	[Token(Token = "0x6000383")]
	private void method_42()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000384 RID: 900 RVA: 0x0000B660 File Offset: 0x00009860
	[Token(Token = "0x6000384")]
	[Address(RVA = "0x3488CE4", Offset = "0x3488CE4", VA = "0x3488CE4")]
	private void method_43()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			long num = 1L;
			this.bool_3 = (num != 0L);
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		base.GetComponentsInChildren<BoxCollider>();
	}

	// Token: 0x06000385 RID: 901 RVA: 0x0000B6C4 File Offset: 0x000098C4
	[Token(Token = "0x6000385")]
	[Address(RVA = "0x3488F10", Offset = "0x3488F10", VA = "0x3488F10")]
	private void method_44()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 1L;
			componentsInChildren.enabled = (enabled != 0L);
			CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
			long enabled2 = 0L;
			componentsInChildren2.enabled = (enabled2 != 0L);
			base.GetComponentsInChildren<BoxCollider>();
			return;
		}
	}

	// Token: 0x06000386 RID: 902 RVA: 0x0000B708 File Offset: 0x00009908
	[Token(Token = "0x6000386")]
	[Address(RVA = "0x348910C", Offset = "0x348910C", VA = "0x348910C")]
	private void method_45()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
	}

	// Token: 0x06000387 RID: 903 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x6000387")]
	[Address(RVA = "0x3489300", Offset = "0x3489300", VA = "0x3489300")]
	private void method_46()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000388 RID: 904 RVA: 0x0000B72C File Offset: 0x0000992C
	[Address(RVA = "0x3489520", Offset = "0x3489520", VA = "0x3489520")]
	[Token(Token = "0x6000388")]
	private void method_47()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 1L;
		componentsInChildren.enabled = (enabled != 0L);
		base.GetComponentsInChildren<CapsuleCollider>();
	}

	// Token: 0x06000389 RID: 905 RVA: 0x0000B768 File Offset: 0x00009968
	[Address(RVA = "0x348971C", Offset = "0x348971C", VA = "0x348971C")]
	[Token(Token = "0x6000389")]
	private void method_48()
	{
		if (!this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
		Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
		if (this.bool_0)
		{
			return;
		}
		long enabled = 0L;
		componentsInChildren.enabled = (enabled != 0L);
		CapsuleCollider[] componentsInChildren2 = base.GetComponentsInChildren<CapsuleCollider>();
		if (this.bool_1)
		{
			return;
		}
		long enabled2 = 0L;
		componentsInChildren2.enabled = (enabled2 != 0L);
		base.GetComponentsInChildren<BoxCollider>();
	}

	// Token: 0x0600038A RID: 906 RVA: 0x0000B7C0 File Offset: 0x000099C0
	[Address(RVA = "0x3489938", Offset = "0x3489938", VA = "0x3489938")]
	[Token(Token = "0x600038A")]
	private void method_49()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
			long enabled = 0L;
			componentsInChildren.enabled = (enabled != 0L);
			base.GetComponentsInChildren<CapsuleCollider>();
			return;
		}
		long num = 256L;
		this.bool_0 = (num != 0L);
	}

	// Token: 0x0600038B RID: 907 RVA: 0x0000B804 File Offset: 0x00009A04
	[Address(RVA = "0x3489B28", Offset = "0x3489B28", VA = "0x3489B28")]
	[Token(Token = "0x600038B")]
	private void method_50()
	{
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			base.GetComponentsInChildren<Renderer>();
			return;
		}
		long num = 1L;
		this.bool_0 = (num != 0L);
		this.bool_3 = (num != 0L);
	}

	// Token: 0x0400006D RID: 109
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400006D")]
	public PhotonView photonView_0;

	// Token: 0x0400006E RID: 110
	[Token(Token = "0x400006E")]
	[FieldOffset(Offset = "0x20")]
	public bool bool_0;

	// Token: 0x0400006F RID: 111
	[Token(Token = "0x400006F")]
	[FieldOffset(Offset = "0x21")]
	public bool bool_1;

	// Token: 0x04000070 RID: 112
	[Token(Token = "0x4000070")]
	[FieldOffset(Offset = "0x22")]
	public bool bool_2;

	// Token: 0x04000071 RID: 113
	[FieldOffset(Offset = "0x23")]
	[Token(Token = "0x4000071")]
	public bool bool_3;
}
