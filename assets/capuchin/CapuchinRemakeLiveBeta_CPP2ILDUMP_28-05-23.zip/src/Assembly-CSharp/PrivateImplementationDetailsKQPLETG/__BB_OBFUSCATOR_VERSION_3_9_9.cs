﻿using System;
using System.Runtime.InteropServices;
using Cpp2IlInjected;

namespace PrivateImplementationDetailsKQPLETG
{
	// Token: 0x020001A7 RID: 423
	[Token(Token = "0x20001A7")]
	[StructLayout(3, CharSet = CharSet.Auto)]
	public class __BB_OBFUSCATOR_VERSION_3_9_9
	{
	}
}
