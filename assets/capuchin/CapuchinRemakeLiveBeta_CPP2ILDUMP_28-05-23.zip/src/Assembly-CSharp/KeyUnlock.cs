﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000078 RID: 120
[Token(Token = "0x2000078")]
public class KeyUnlock : MonoBehaviour
{
	// Token: 0x060010E7 RID: 4327 RVA: 0x00022D78 File Offset: 0x00020F78
	[Token(Token = "0x60010E7")]
	[Address(RVA = "0x3131000", Offset = "0x3131000", VA = "0x3131000")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("HandL");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010E8 RID: 4328 RVA: 0x00022DE0 File Offset: 0x00020FE0
	[Token(Token = "0x60010E8")]
	[Address(RVA = "0x31310FC", Offset = "0x31310FC", VA = "0x31310FC")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("sound play stopped");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010E9 RID: 4329 RVA: 0x00022E48 File Offset: 0x00021048
	[Address(RVA = "0x31311F8", Offset = "0x31311F8", VA = "0x31311F8")]
	[Token(Token = "0x60010E9")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("typesOfTalk");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010EA RID: 4330 RVA: 0x00022EB0 File Offset: 0x000210B0
	[Address(RVA = "0x31312F4", Offset = "0x31312F4", VA = "0x31312F4")]
	[Token(Token = "0x60010EA")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("BN");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010EB RID: 4331 RVA: 0x00022F18 File Offset: 0x00021118
	[Token(Token = "0x60010EB")]
	[Address(RVA = "0x31313F0", Offset = "0x31313F0", VA = "0x31313F0")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("clickLol");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010EC RID: 4332 RVA: 0x00022F80 File Offset: 0x00021180
	[Token(Token = "0x60010EC")]
	[Address(RVA = "0x31314EC", Offset = "0x31314EC", VA = "0x31314EC")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("username");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010ED RID: 4333 RVA: 0x00022FE8 File Offset: 0x000211E8
	[Token(Token = "0x60010ED")]
	[Address(RVA = "0x31315E8", Offset = "0x31315E8", VA = "0x31315E8")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("htc");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010EE RID: 4334 RVA: 0x00023050 File Offset: 0x00021250
	[Token(Token = "0x60010EE")]
	[Address(RVA = "0x31316E4", Offset = "0x31316E4", VA = "0x31316E4")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010EF RID: 4335 RVA: 0x000230B8 File Offset: 0x000212B8
	[Address(RVA = "0x31317E0", Offset = "0x31317E0", VA = "0x31317E0")]
	[Token(Token = "0x60010EF")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Tagged");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F0 RID: 4336 RVA: 0x00023120 File Offset: 0x00021320
	[Token(Token = "0x60010F0")]
	[Address(RVA = "0x31318DC", Offset = "0x31318DC", VA = "0x31318DC")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("amongus");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F1 RID: 4337 RVA: 0x00023188 File Offset: 0x00021388
	[Address(RVA = "0x31319D8", Offset = "0x31319D8", VA = "0x31319D8")]
	[Token(Token = "0x60010F1")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("BN");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F2 RID: 4338 RVA: 0x000231F0 File Offset: 0x000213F0
	[Token(Token = "0x60010F2")]
	[Address(RVA = "0x3131AD4", Offset = "0x3131AD4", VA = "0x3131AD4")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Joined Public Room Successfully");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F3 RID: 4339 RVA: 0x00023258 File Offset: 0x00021458
	[Token(Token = "0x60010F3")]
	[Address(RVA = "0x3131BD0", Offset = "0x3131BD0", VA = "0x3131BD0")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Key");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F4 RID: 4340 RVA: 0x000232C0 File Offset: 0x000214C0
	[Address(RVA = "0x3131CCC", Offset = "0x3131CCC", VA = "0x3131CCC")]
	[Token(Token = "0x60010F4")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PURCHASED!");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F5 RID: 4341 RVA: 0x00023328 File Offset: 0x00021528
	[Token(Token = "0x60010F5")]
	[Address(RVA = "0x3131DC8", Offset = "0x3131DC8", VA = "0x3131DC8")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("typesOfTalk");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F6 RID: 4342 RVA: 0x00023390 File Offset: 0x00021590
	[Token(Token = "0x60010F6")]
	[Address(RVA = "0x3131EC4", Offset = "0x3131EC4", VA = "0x3131EC4")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Room1");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F7 RID: 4343 RVA: 0x000233F8 File Offset: 0x000215F8
	[Token(Token = "0x60010F7")]
	[Address(RVA = "0x3131FC0", Offset = "0x3131FC0", VA = "0x3131FC0")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Purchase For ");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F8 RID: 4344 RVA: 0x00023460 File Offset: 0x00021660
	[Address(RVA = "0x31320BC", Offset = "0x31320BC", VA = "0x31320BC")]
	[Token(Token = "0x60010F8")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Color");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010F9 RID: 4345 RVA: 0x000234C8 File Offset: 0x000216C8
	[Address(RVA = "0x31321B8", Offset = "0x31321B8", VA = "0x31321B8")]
	[Token(Token = "0x60010F9")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Creating and loadingtexture");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010FA RID: 4346 RVA: 0x00023530 File Offset: 0x00021730
	[Token(Token = "0x60010FA")]
	[Address(RVA = "0x31322B4", Offset = "0x31322B4", VA = "0x31322B4")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("/");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010FB RID: 4347 RVA: 0x00022E48 File Offset: 0x00021048
	[Token(Token = "0x60010FB")]
	[Address(RVA = "0x31323B0", Offset = "0x31323B0", VA = "0x31323B0")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("typesOfTalk");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010FC RID: 4348 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x31324AC", Offset = "0x31324AC", VA = "0x31324AC")]
	[Token(Token = "0x60010FC")]
	public KeyUnlock()
	{
	}

	// Token: 0x060010FD RID: 4349 RVA: 0x00023598 File Offset: 0x00021798
	[Token(Token = "0x60010FD")]
	[Address(RVA = "0x31324B4", Offset = "0x31324B4", VA = "0x31324B4")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Tint");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010FE RID: 4350 RVA: 0x00023600 File Offset: 0x00021800
	[Token(Token = "0x60010FE")]
	[Address(RVA = "0x31325B0", Offset = "0x31325B0", VA = "0x31325B0")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CapuchinRemade");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x060010FF RID: 4351 RVA: 0x00023668 File Offset: 0x00021868
	[Token(Token = "0x60010FF")]
	[Address(RVA = "0x31326AC", Offset = "0x31326AC", VA = "0x31326AC")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001100 RID: 4352 RVA: 0x000236D0 File Offset: 0x000218D0
	[Token(Token = "0x6001100")]
	[Address(RVA = "0x31327A8", Offset = "0x31327A8", VA = "0x31327A8")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("procedural animation script required on ");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001101 RID: 4353 RVA: 0x00023738 File Offset: 0x00021938
	[Token(Token = "0x6001101")]
	[Address(RVA = "0x31328A4", Offset = "0x31328A4", VA = "0x31328A4")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Bare Torso");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001102 RID: 4354 RVA: 0x000237A0 File Offset: 0x000219A0
	[Address(RVA = "0x31329A0", Offset = "0x31329A0", VA = "0x31329A0")]
	[Token(Token = "0x6001102")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("containsStaff");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001103 RID: 4355 RVA: 0x00023808 File Offset: 0x00021A08
	[Address(RVA = "0x3132A9C", Offset = "0x3132A9C", VA = "0x3132A9C")]
	[Token(Token = "0x6001103")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Horizontal");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001104 RID: 4356 RVA: 0x00023870 File Offset: 0x00021A70
	[Address(RVA = "0x3132B98", Offset = "0x3132B98", VA = "0x3132B98")]
	[Token(Token = "0x6001104")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("goDownRPC");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001105 RID: 4357 RVA: 0x00023808 File Offset: 0x00021A08
	[Address(RVA = "0x3132C94", Offset = "0x3132C94", VA = "0x3132C94")]
	[Token(Token = "0x6001105")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Horizontal");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001106 RID: 4358 RVA: 0x000238D8 File Offset: 0x00021AD8
	[Token(Token = "0x6001106")]
	[Address(RVA = "0x3132D90", Offset = "0x3132D90", VA = "0x3132D90")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("liftoff failed!");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001107 RID: 4359 RVA: 0x00023050 File Offset: 0x00021250
	[Token(Token = "0x6001107")]
	[Address(RVA = "0x3132E8C", Offset = "0x3132E8C", VA = "0x3132E8C")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 0L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 0L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x06001108 RID: 4360 RVA: 0x00023940 File Offset: 0x00021B40
	[Token(Token = "0x6001108")]
	[Address(RVA = "0x3132F88", Offset = "0x3132F88", VA = "0x3132F88")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Cannot access an empty buffer.");
		throw new MissingMethodException();
	}

	// Token: 0x06001109 RID: 4361 RVA: 0x00023964 File Offset: 0x00021B64
	[Address(RVA = "0x3133084", Offset = "0x3133084", VA = "0x3133084")]
	[Token(Token = "0x6001109")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
		GameObject obj = this.gameObject_0;
		UnityEngine.Object.Destroy(obj);
		GameObject gameObject = this.gameObject_1;
		long active = 1L;
		gameObject.SetActive(active != 0L);
		MeshRenderer meshRenderer = this.meshRenderer_0;
		Material material = this.material_1;
		meshRenderer.material = material;
		BoxCollider boxCollider = this.boxCollider_0;
		long enabled = 1L;
		boxCollider.enabled = (enabled != 0L);
	}

	// Token: 0x04000270 RID: 624
	[Token(Token = "0x4000270")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;

	// Token: 0x04000271 RID: 625
	[Token(Token = "0x4000271")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_1;

	// Token: 0x04000272 RID: 626
	[Token(Token = "0x4000272")]
	[FieldOffset(Offset = "0x28")]
	public MeshRenderer meshRenderer_0;

	// Token: 0x04000273 RID: 627
	[Token(Token = "0x4000273")]
	[FieldOffset(Offset = "0x30")]
	public BoxCollider boxCollider_0;

	// Token: 0x04000274 RID: 628
	[Token(Token = "0x4000274")]
	[FieldOffset(Offset = "0x38")]
	public Material material_0;

	// Token: 0x04000275 RID: 629
	[Token(Token = "0x4000275")]
	[FieldOffset(Offset = "0x40")]
	public Material material_1;
}
