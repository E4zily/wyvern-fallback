﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

// Token: 0x02000067 RID: 103
[Token(Token = "0x2000067")]
public class PatrolAI : MonoBehaviour
{
	// Token: 0x06000E02 RID: 3586 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E02")]
	[Address(RVA = "0x345CC38", Offset = "0x345CC38", VA = "0x345CC38")]
	private void method_0()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E03 RID: 3587 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E03")]
	[Address(RVA = "0x345CC94", Offset = "0x345CC94", VA = "0x345CC94")]
	private void OnDrawGizmosSelected()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E04 RID: 3588 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x345CCE4", Offset = "0x345CCE4", VA = "0x345CCE4")]
	[Token(Token = "0x6000E04")]
	private void method_1()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E05 RID: 3589 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x345CD40", Offset = "0x345CD40", VA = "0x345CD40")]
	[Token(Token = "0x6000E05")]
	private void method_2()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E06 RID: 3590 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E06")]
	[Address(RVA = "0x345CD9C", Offset = "0x345CD9C", VA = "0x345CD9C")]
	private void method_3()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E07 RID: 3591 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E07")]
	[Address(RVA = "0x345CDEC", Offset = "0x345CDEC", VA = "0x345CDEC")]
	private void method_4()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E08 RID: 3592 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345CE48", Offset = "0x345CE48", VA = "0x345CE48")]
	[Token(Token = "0x6000E08")]
	public void method_5()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E09 RID: 3593 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
	[Token(Token = "0x6000E09")]
	[Address(RVA = "0x345CE64", Offset = "0x345CE64", VA = "0x345CE64")]
	private Transform method_6(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E0A RID: 3594 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
	[Address(RVA = "0x345CF6C", Offset = "0x345CF6C", VA = "0x345CF6C")]
	[Token(Token = "0x6000E0A")]
	private Transform method_7(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E0B RID: 3595 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E0B")]
	[Address(RVA = "0x345D074", Offset = "0x345D074", VA = "0x345D074")]
	private void method_8()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E0C RID: 3596 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E0C")]
	[Address(RVA = "0x345D0D0", Offset = "0x345D0D0", VA = "0x345D0D0")]
	private void method_9()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E0D RID: 3597 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E0D")]
	[Address(RVA = "0x345D120", Offset = "0x345D120", VA = "0x345D120")]
	private void method_10()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E0E RID: 3598 RVA: 0x0001E3E0 File Offset: 0x0001C5E0
	[Token(Token = "0x6000E0E")]
	[Address(RVA = "0x345D170", Offset = "0x345D170", VA = "0x345D170")]
	private void method_11()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("hh:mm:sstt");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_60(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		long num = 1L;
		this.bool_0 = (num != 0L);
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_48();
			return;
		}
	}

	// Token: 0x06000E0F RID: 3599 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E0F")]
	[Address(RVA = "0x345D728", Offset = "0x345D728", VA = "0x345D728")]
	private void method_12()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E10 RID: 3600 RVA: 0x0001E4BC File Offset: 0x0001C6BC
	[Address(RVA = "0x345D784", Offset = "0x345D784", VA = "0x345D784")]
	[Token(Token = "0x6000E10")]
	private void method_13()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("RainAndThunderWeather");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_34(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_19();
			return;
		}
	}

	// Token: 0x06000E11 RID: 3601 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E11")]
	[Address(RVA = "0x345DD14", Offset = "0x345DD14", VA = "0x345DD14")]
	public void method_14()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E12 RID: 3602 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Address(RVA = "0x345DE68", Offset = "0x345DE68", VA = "0x345DE68")]
	[Token(Token = "0x6000E12")]
	public void method_15()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E13 RID: 3603 RVA: 0x0001E5A0 File Offset: 0x0001C7A0
	[Address(RVA = "0x345DFD8", Offset = "0x345DFD8", VA = "0x345DFD8")]
	[Token(Token = "0x6000E13")]
	private void method_16()
	{
		GameObject.FindGameObjectsWithTag("tutorialCheck");
		Transform transform;
		Vector3 position = transform.transform.position;
		Vector3 position2 = transform.position;
		Transform transform2;
		Vector3 position3 = transform2.position;
		Vector3 position4 = transform.position;
		Transform transform3;
		Vector3 position5 = transform3.position;
		long num = 1L;
		if (num != 0L)
		{
			return;
		}
	}

	// Token: 0x06000E14 RID: 3604 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E14")]
	[Address(RVA = "0x345E48C", Offset = "0x345E48C", VA = "0x345E48C")]
	private void method_17()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E15 RID: 3605 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345E4E8", Offset = "0x345E4E8", VA = "0x345E4E8")]
	[Token(Token = "0x6000E15")]
	public void method_18()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E16 RID: 3606 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Address(RVA = "0x345DBC0", Offset = "0x345DBC0", VA = "0x345DBC0")]
	[Token(Token = "0x6000E16")]
	public void method_19()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E17 RID: 3607 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345E520", Offset = "0x345E520", VA = "0x345E520")]
	[Token(Token = "0x6000E17")]
	public void method_20()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E18 RID: 3608 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E18")]
	[Address(RVA = "0x345E53C", Offset = "0x345E53C", VA = "0x345E53C")]
	private void method_21()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E19 RID: 3609 RVA: 0x000024DC File Offset: 0x000006DC
	[Token(Token = "0x6000E19")]
	[Address(RVA = "0x345E598", Offset = "0x345E598", VA = "0x345E598")]
	public void method_22()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E1A RID: 3610 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Address(RVA = "0x345E5B4", Offset = "0x345E5B4", VA = "0x345E5B4")]
	[Token(Token = "0x6000E1A")]
	public void method_23()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E1B RID: 3611 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345DFBC", Offset = "0x345DFBC", VA = "0x345DFBC")]
	[Token(Token = "0x6000E1B")]
	public void method_24()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E1C RID: 3612 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E1C")]
	[Address(RVA = "0x345E724", Offset = "0x345E724", VA = "0x345E724")]
	private void method_25()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E1D RID: 3613 RVA: 0x0001E398 File Offset: 0x0001C598
	[Address(RVA = "0x345E774", Offset = "0x345E774", VA = "0x345E774")]
	[Token(Token = "0x6000E1D")]
	private void method_26()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E1E RID: 3614 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E1E")]
	[Address(RVA = "0x345E7C4", Offset = "0x345E7C4", VA = "0x345E7C4")]
	private void method_27()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E1F RID: 3615 RVA: 0x0001E398 File Offset: 0x0001C598
	[Address(RVA = "0x345E820", Offset = "0x345E820", VA = "0x345E820")]
	[Token(Token = "0x6000E1F")]
	private void method_28()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E20 RID: 3616 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E20")]
	[Address(RVA = "0x345E870", Offset = "0x345E870", VA = "0x345E870")]
	private void method_29()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E21 RID: 3617 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Address(RVA = "0x345E8C0", Offset = "0x345E8C0", VA = "0x345E8C0")]
	[Token(Token = "0x6000E21")]
	public void method_30()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E22 RID: 3618 RVA: 0x0001E398 File Offset: 0x0001C598
	[Address(RVA = "0x345EA14", Offset = "0x345EA14", VA = "0x345EA14")]
	[Token(Token = "0x6000E22")]
	private void method_31()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E23 RID: 3619 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345EA64", Offset = "0x345EA64", VA = "0x345EA64")]
	[Token(Token = "0x6000E23")]
	public void method_32()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E24 RID: 3620 RVA: 0x000024E9 File Offset: 0x000006E9
	[Address(RVA = "0x345EA80", Offset = "0x345EA80", VA = "0x345EA80")]
	[Token(Token = "0x6000E24")]
	public PatrolAI()
	{
	}

	// Token: 0x06000E25 RID: 3621 RVA: 0x0001E5EC File Offset: 0x0001C7EC
	[Token(Token = "0x6000E25")]
	[Address(RVA = "0x345EA90", Offset = "0x345EA90", VA = "0x345EA90")]
	public void method_33()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E26 RID: 3622 RVA: 0x0001E600 File Offset: 0x0001C800
	[Token(Token = "0x6000E26")]
	[Address(RVA = "0x345DAD8", Offset = "0x345DAD8", VA = "0x345DAD8")]
	private Transform method_34(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E27 RID: 3623 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E27")]
	[Address(RVA = "0x345EBE4", Offset = "0x345EBE4", VA = "0x345EBE4")]
	private void method_35()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E28 RID: 3624 RVA: 0x000024DC File Offset: 0x000006DC
	[Token(Token = "0x6000E28")]
	[Address(RVA = "0x345EC40", Offset = "0x345EC40", VA = "0x345EC40")]
	public void method_36()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E29 RID: 3625 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E29")]
	[Address(RVA = "0x345EC5C", Offset = "0x345EC5C", VA = "0x345EC5C")]
	private void method_37()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E2A RID: 3626 RVA: 0x000024DC File Offset: 0x000006DC
	[Token(Token = "0x6000E2A")]
	[Address(RVA = "0x345ECAC", Offset = "0x345ECAC", VA = "0x345ECAC")]
	public void method_38()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E2B RID: 3627 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x345ECC8", Offset = "0x345ECC8", VA = "0x345ECC8")]
	[Token(Token = "0x6000E2B")]
	private void method_39()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E2C RID: 3628 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Address(RVA = "0x345ED24", Offset = "0x345ED24", VA = "0x345ED24")]
	[Token(Token = "0x6000E2C")]
	public void method_40()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E2D RID: 3629 RVA: 0x0001E600 File Offset: 0x0001C800
	[Address(RVA = "0x345EE78", Offset = "0x345EE78", VA = "0x345EE78")]
	[Token(Token = "0x6000E2D")]
	private Transform method_41(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E2E RID: 3630 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
	[Token(Token = "0x6000E2E")]
	[Address(RVA = "0x345EF60", Offset = "0x345EF60", VA = "0x345EF60")]
	private Transform method_42(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E2F RID: 3631 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Address(RVA = "0x345F068", Offset = "0x345F068", VA = "0x345F068")]
	[Token(Token = "0x6000E2F")]
	public void method_43()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E30 RID: 3632 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E30")]
	[Address(RVA = "0x345F1BC", Offset = "0x345F1BC", VA = "0x345F1BC")]
	private void method_44()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E31 RID: 3633 RVA: 0x0001E628 File Offset: 0x0001C828
	[Address(RVA = "0x345F20C", Offset = "0x345F20C", VA = "0x345F20C")]
	[Token(Token = "0x6000E31")]
	private void method_45()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("username");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_52(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_30();
			return;
		}
	}

	// Token: 0x06000E32 RID: 3634 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E32")]
	[Address(RVA = "0x345F64C", Offset = "0x345F64C", VA = "0x345F64C")]
	public void method_46()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E33 RID: 3635 RVA: 0x000024DC File Offset: 0x000006DC
	[Token(Token = "0x6000E33")]
	[Address(RVA = "0x345F7BC", Offset = "0x345F7BC", VA = "0x345F7BC")]
	public void method_47()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E34 RID: 3636 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E34")]
	[Address(RVA = "0x345D5D4", Offset = "0x345D5D4", VA = "0x345D5D4")]
	public void method_48()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E35 RID: 3637 RVA: 0x0001E6F8 File Offset: 0x0001C8F8
	[Token(Token = "0x6000E35")]
	[Address(RVA = "0x345F7D8", Offset = "0x345F7D8", VA = "0x345F7D8")]
	private void method_49()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("containsStaff");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_42(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Transform transform2;
		Vector3 position5 = transform2.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_23();
			return;
		}
	}

	// Token: 0x06000E36 RID: 3638 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345FB30", Offset = "0x345FB30", VA = "0x345FB30")]
	[Token(Token = "0x6000E36")]
	public void method_50()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E37 RID: 3639 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E37")]
	[Address(RVA = "0x345FB4C", Offset = "0x345FB4C", VA = "0x345FB4C")]
	public void method_51()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E38 RID: 3640 RVA: 0x0001E600 File Offset: 0x0001C800
	[Token(Token = "0x6000E38")]
	[Address(RVA = "0x345F564", Offset = "0x345F564", VA = "0x345F564")]
	private Transform method_52(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E39 RID: 3641 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E39")]
	[Address(RVA = "0x345FCA0", Offset = "0x345FCA0", VA = "0x345FCA0")]
	private void method_53()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E3A RID: 3642 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345FCFC", Offset = "0x345FCFC", VA = "0x345FCFC")]
	[Token(Token = "0x6000E3A")]
	public void method_54()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E3B RID: 3643 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x345FD18", Offset = "0x345FD18", VA = "0x345FD18")]
	[Token(Token = "0x6000E3B")]
	private void method_55()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E3C RID: 3644 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E3C")]
	[Address(RVA = "0x345FD74", Offset = "0x345FD74", VA = "0x345FD74")]
	private void method_56()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E3D RID: 3645 RVA: 0x0001E7C4 File Offset: 0x0001C9C4
	[Address(RVA = "0x345FDC4", Offset = "0x345FDC4", VA = "0x345FDC4")]
	[Token(Token = "0x6000E3D")]
	private void method_57()
	{
		Color red = Color.red;
		Transform transform;
		Vector3 position = transform.position;
	}

	// Token: 0x06000E3E RID: 3646 RVA: 0x0001E7E0 File Offset: 0x0001C9E0
	[Address(RVA = "0x345FE14", Offset = "0x345FE14", VA = "0x345FE14")]
	[Token(Token = "0x6000E3E")]
	private void method_58()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("ORGPORT");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_42(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		long num = 1L;
		this.bool_0 = (num != 0L);
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_51();
			return;
		}
	}

	// Token: 0x06000E3F RID: 3647 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Address(RVA = "0x346016C", Offset = "0x346016C", VA = "0x346016C")]
	[Token(Token = "0x6000E3F")]
	public void method_59()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E40 RID: 3648 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
	[Token(Token = "0x6000E40")]
	[Address(RVA = "0x345D4CC", Offset = "0x345D4CC", VA = "0x345D4CC")]
	private Transform method_60(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E41 RID: 3649 RVA: 0x0001E8BC File Offset: 0x0001CABC
	[Token(Token = "0x6000E41")]
	[Address(RVA = "0x34602DC", Offset = "0x34602DC", VA = "0x34602DC")]
	private void method_61()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("Display Name Changed!");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		this.method_75(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = base.transform.position;
		Vector3 position3 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		Vector3 position4 = this.dave_0.playerCam.position;
		Vector3 position5 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 1L;
		long num = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_40();
			this.bool_1 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000E42 RID: 3650 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345E708", Offset = "0x345E708", VA = "0x345E708")]
	[Token(Token = "0x6000E42")]
	public void method_62()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E43 RID: 3651 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E43")]
	[Address(RVA = "0x3460724", Offset = "0x3460724", VA = "0x3460724")]
	public void method_63()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E44 RID: 3652 RVA: 0x0001E988 File Offset: 0x0001CB88
	[Token(Token = "0x6000E44")]
	[Address(RVA = "0x3460878", Offset = "0x3460878", VA = "0x3460878")]
	private void method_64()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("Open");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_42(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		long num = 1L;
		this.bool_0 = (num != 0L);
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 1L;
		long num2 = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_33();
			this.bool_1 = (num2 != 0L);
			return;
		}
	}

	// Token: 0x06000E45 RID: 3653 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x3460BDC", Offset = "0x3460BDC", VA = "0x3460BDC")]
	[Token(Token = "0x6000E45")]
	private void Start()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E46 RID: 3654 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x3460C38", Offset = "0x3460C38", VA = "0x3460C38")]
	[Token(Token = "0x6000E46")]
	private void method_65()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E47 RID: 3655 RVA: 0x0001EA6C File Offset: 0x0001CC6C
	[Address(RVA = "0x3460C94", Offset = "0x3460C94", VA = "0x3460C94")]
	[Token(Token = "0x6000E47")]
	private void Update()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("Player");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_60(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_43();
			return;
		}
	}

	// Token: 0x06000E48 RID: 3656 RVA: 0x000024DC File Offset: 0x000006DC
	[Address(RVA = "0x345F7A0", Offset = "0x345F7A0", VA = "0x345F7A0")]
	[Token(Token = "0x6000E48")]
	public void method_66()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E49 RID: 3657 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E49")]
	[Address(RVA = "0x3460FEC", Offset = "0x3460FEC", VA = "0x3460FEC")]
	public void method_67()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E4A RID: 3658 RVA: 0x000024DC File Offset: 0x000006DC
	[Token(Token = "0x6000E4A")]
	[Address(RVA = "0x345E504", Offset = "0x345E504", VA = "0x345E504")]
	[PunRPC]
	public void PlayNoise()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E4B RID: 3659 RVA: 0x0001EB3C File Offset: 0x0001CD3C
	[Token(Token = "0x6000E4B")]
	[Address(RVA = "0x346115C", Offset = "0x346115C", VA = "0x346115C")]
	private void method_68()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("Connected to Server.");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_42(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_48();
			long num = 1L;
			this.bool_1 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000E4C RID: 3660 RVA: 0x0001EC18 File Offset: 0x0001CE18
	[Token(Token = "0x6000E4C")]
	[Address(RVA = "0x34614B8", Offset = "0x34614B8", VA = "0x34614B8")]
	private void method_69()
	{
	}

	// Token: 0x06000E4D RID: 3661 RVA: 0x0001EC28 File Offset: 0x0001CE28
	[Address(RVA = "0x3461514", Offset = "0x3461514", VA = "0x3461514")]
	[Token(Token = "0x6000E4D")]
	private void method_70()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag(".Please press the button if you would like to play alone");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_60(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		long num = 1L;
		this.bool_0 = (num != 0L);
		Vector3 position6 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 0L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_30();
			return;
		}
	}

	// Token: 0x06000E4E RID: 3662 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x3461868", Offset = "0x3461868", VA = "0x3461868")]
	[Token(Token = "0x6000E4E")]
	private void method_71()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E4F RID: 3663 RVA: 0x000024DC File Offset: 0x000006DC
	[Token(Token = "0x6000E4F")]
	[Address(RVA = "0x34602C0", Offset = "0x34602C0", VA = "0x34602C0")]
	public void method_72()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x06000E50 RID: 3664 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Address(RVA = "0x34618C4", Offset = "0x34618C4", VA = "0x34618C4")]
	[Token(Token = "0x6000E50")]
	private void method_73()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E51 RID: 3665 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E51")]
	[Address(RVA = "0x3461920", Offset = "0x3461920", VA = "0x3461920")]
	private void method_74()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E52 RID: 3666 RVA: 0x0001E600 File Offset: 0x0001C800
	[Token(Token = "0x6000E52")]
	[Address(RVA = "0x346063C", Offset = "0x346063C", VA = "0x346063C")]
	private Transform method_75(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E53 RID: 3667 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E53")]
	[Address(RVA = "0x346197C", Offset = "0x346197C", VA = "0x346197C")]
	public void method_76()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E54 RID: 3668 RVA: 0x0001E58C File Offset: 0x0001C78C
	[Token(Token = "0x6000E54")]
	[Address(RVA = "0x345E338", Offset = "0x345E338", VA = "0x345E338")]
	public void method_77()
	{
		bool isConnected = PhotonNetwork.IsConnected;
	}

	// Token: 0x06000E55 RID: 3669 RVA: 0x0001ECF0 File Offset: 0x0001CEF0
	[Token(Token = "0x6000E55")]
	[Address(RVA = "0x3461AD0", Offset = "0x3461AD0", VA = "0x3461AD0")]
	private void method_78()
	{
		NavMeshPathStatus pathStatus = this.navMeshAgent_0.pathStatus;
		this.navMeshPathStatus_0 = pathStatus;
		GameObject[] array = GameObject.FindGameObjectsWithTag("Version");
		this.gameObject_0 = array;
		GameObject[] gameObject_ = this.gameObject_0;
		Transform transform = this.method_41(gameObject_);
		Vector3 position = base.transform.position;
		Vector3 position2 = transform.position;
		Vector3 position3 = base.transform.position;
		Vector3 position4 = transform.position;
		Vector3 position5 = base.transform.position;
		NavMeshAgent navMeshAgent = this.navMeshAgent_0;
		float speed;
		navMeshAgent.speed = speed;
		this.bool_0 = ("Version" != null);
		Vector3 position6 = this.dave_0.playerCam.position;
		Vector3 position7 = this.dave_0.playerCam.position;
		GameObject rightArmIK = this.dave_0.rightArmIK;
		long active = 1L;
		long num = 1L;
		rightArmIK.SetActive(active != 0L);
		if (this.bool_1)
		{
			this.method_48();
			this.bool_1 = (num != 0L);
			return;
		}
	}

	// Token: 0x06000E56 RID: 3670 RVA: 0x0001EDD4 File Offset: 0x0001CFD4
	[Address(RVA = "0x3461E2C", Offset = "0x3461E2C", VA = "0x3461E2C")]
	[Token(Token = "0x6000E56")]
	private void method_79()
	{
		NavMeshAgent navMeshAgent;
		this.navMeshAgent_0 = navMeshAgent;
	}

	// Token: 0x06000E57 RID: 3671 RVA: 0x0001E398 File Offset: 0x0001C598
	[Address(RVA = "0x3461E88", Offset = "0x3461E88", VA = "0x3461E88")]
	[Token(Token = "0x6000E57")]
	private void method_80()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E58 RID: 3672 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E58")]
	[Address(RVA = "0x3461ED8", Offset = "0x3461ED8", VA = "0x3461ED8")]
	private void method_81()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E59 RID: 3673 RVA: 0x0001E398 File Offset: 0x0001C598
	[Token(Token = "0x6000E59")]
	[Address(RVA = "0x3461F34", Offset = "0x3461F34", VA = "0x3461F34")]
	private void method_82()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E5A RID: 3674 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
	[Address(RVA = "0x3461F84", Offset = "0x3461F84", VA = "0x3461F84")]
	[Token(Token = "0x6000E5A")]
	private Transform method_83(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E5B RID: 3675 RVA: 0x0001E3B8 File Offset: 0x0001C5B8
	[Address(RVA = "0x346208C", Offset = "0x346208C", VA = "0x346208C")]
	[Token(Token = "0x6000E5B")]
	private Transform method_84(GameObject[] gameObject_1)
	{
		Vector3 position = base.transform.position;
		Transform transform;
		Vector3 position2 = transform.position;
		return 0.transform;
	}

	// Token: 0x06000E5C RID: 3676 RVA: 0x0001E37C File Offset: 0x0001C57C
	[Token(Token = "0x6000E5C")]
	[Address(RVA = "0x3462194", Offset = "0x3462194", VA = "0x3462194")]
	private void method_85()
	{
		NavMeshAgent component = base.GetComponent<NavMeshAgent>();
		this.navMeshAgent_0 = component;
	}

	// Token: 0x06000E5D RID: 3677 RVA: 0x0001E398 File Offset: 0x0001C598
	[Address(RVA = "0x34621F0", Offset = "0x34621F0", VA = "0x34621F0")]
	[Token(Token = "0x6000E5D")]
	private void method_86()
	{
		Color red = Color.red;
		Vector3 position = base.transform.position;
	}

	// Token: 0x06000E5E RID: 3678 RVA: 0x000024DC File Offset: 0x000006DC
	[Token(Token = "0x6000E5E")]
	[Address(RVA = "0x3461140", Offset = "0x3461140", VA = "0x3461140")]
	public void method_87()
	{
		this.audioSource_0.Play();
	}

	// Token: 0x04000212 RID: 530
	[Token(Token = "0x4000212")]
	[FieldOffset(Offset = "0x18")]
	private NavMeshAgent navMeshAgent_0;

	// Token: 0x04000213 RID: 531
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000213")]
	private GameObject[] gameObject_0;

	// Token: 0x04000214 RID: 532
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000214")]
	public float float_0 = (float)16512;

	// Token: 0x04000215 RID: 533
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000215")]
	public Transform transform_0;

	// Token: 0x04000216 RID: 534
	[Token(Token = "0x4000216")]
	[FieldOffset(Offset = "0x38")]
	public AiTarget aiTarget_0;

	// Token: 0x04000217 RID: 535
	[Token(Token = "0x4000217")]
	[FieldOffset(Offset = "0x40")]
	public float float_1;

	// Token: 0x04000218 RID: 536
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4000218")]
	public float float_2;

	// Token: 0x04000219 RID: 537
	[Token(Token = "0x4000219")]
	[FieldOffset(Offset = "0x48")]
	private bool bool_0;

	// Token: 0x0400021A RID: 538
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x400021A")]
	private NavMeshPathStatus navMeshPathStatus_0;

	// Token: 0x0400021B RID: 539
	[Token(Token = "0x400021B")]
	[FieldOffset(Offset = "0x50")]
	public float float_3;

	// Token: 0x0400021C RID: 540
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400021C")]
	public AudioSource audioSource_0;

	// Token: 0x0400021D RID: 541
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400021D")]
	public PhotonView photonView_0;

	// Token: 0x0400021E RID: 542
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400021E")]
	private bool bool_1;

	// Token: 0x0400021F RID: 543
	[Token(Token = "0x400021F")]
	[FieldOffset(Offset = "0x70")]
	public PatrolAI.Dave dave_0;

	// Token: 0x02000068 RID: 104
	[Token(Token = "0x2000068")]
	[Serializable]
	public struct Dave
	{
		// Token: 0x04000220 RID: 544
		[Token(Token = "0x4000220")]
		[FieldOffset(Offset = "0x0")]
		public GameObject leftArmTarget;

		// Token: 0x04000221 RID: 545
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4000221")]
		public GameObject leftArmIK;

		// Token: 0x04000222 RID: 546
		[Token(Token = "0x4000222")]
		[FieldOffset(Offset = "0x10")]
		public GameObject rightArmTarget;

		// Token: 0x04000223 RID: 547
		[Token(Token = "0x4000223")]
		[FieldOffset(Offset = "0x18")]
		public GameObject rightArmIK;

		// Token: 0x04000224 RID: 548
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000224")]
		public Transform playerCam;
	}
}
