﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D6 RID: 214
[Token(Token = "0x20000D6")]
public class LavaMusic : MonoBehaviour
{
	// Token: 0x06001F68 RID: 8040 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EDB5C", Offset = "0x35EDB5C", VA = "0x35EDB5C")]
	[Token(Token = "0x6001F68")]
	private void method_0()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F69 RID: 8041 RVA: 0x0003B068 File Offset: 0x00039268
	[Address(RVA = "0x35EDDAC", Offset = "0x35EDDAC", VA = "0x35EDDAC")]
	[Token(Token = "0x6001F69")]
	private void method_1()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F6A RID: 8042 RVA: 0x0003B128 File Offset: 0x00039328
	[Address(RVA = "0x35EE000", Offset = "0x35EE000", VA = "0x35EE000")]
	[Token(Token = "0x6001F6A")]
	private void method_2()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Vector3 position5 = this.transform_0.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource2.volume = volume3;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_3;
		Vector3 position7 = transform3.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource3.volume = volume4;
	}

	// Token: 0x06001F6B RID: 8043 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EE250", Offset = "0x35EE250", VA = "0x35EE250")]
	[Token(Token = "0x6001F6B")]
	private void method_3()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F6C RID: 8044 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EE498", Offset = "0x35EE498", VA = "0x35EE498")]
	[Token(Token = "0x6001F6C")]
	private void method_4()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F6D RID: 8045 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EE6EC", Offset = "0x35EE6EC", VA = "0x35EE6EC")]
	[Token(Token = "0x6001F6D")]
	private void method_5()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F6E RID: 8046 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EE938", Offset = "0x35EE938", VA = "0x35EE938")]
	[Token(Token = "0x6001F6E")]
	private void method_6()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F6F RID: 8047 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EEB88", Offset = "0x35EEB88", VA = "0x35EEB88")]
	[Token(Token = "0x6001F6F")]
	private void method_7()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F70 RID: 8048 RVA: 0x0003B1DC File Offset: 0x000393DC
	[Address(RVA = "0x35EEDD8", Offset = "0x35EEDD8", VA = "0x35EEDD8")]
	[Token(Token = "0x6001F70")]
	private void method_8()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position2 = transform2.position;
		Vector3 position3 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position4 = transform3.position;
		Vector3 position5 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position6 = transform4.position;
		Vector3 position7 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F71 RID: 8049 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EF028", Offset = "0x35EF028", VA = "0x35EF028")]
	[Token(Token = "0x6001F71")]
	private void method_9()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F72 RID: 8050 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EF27C", Offset = "0x35EF27C", VA = "0x35EF27C")]
	[Token(Token = "0x6001F72")]
	private void method_10()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F73 RID: 8051 RVA: 0x0003B290 File Offset: 0x00039490
	[Address(RVA = "0x35EF4C4", Offset = "0x35EF4C4", VA = "0x35EF4C4")]
	[Token(Token = "0x6001F73")]
	private void method_11()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		Transform transform3 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform4 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
	}

	// Token: 0x06001F74 RID: 8052 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EF714", Offset = "0x35EF714", VA = "0x35EF714")]
	[Token(Token = "0x6001F74")]
	private void Update()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F75 RID: 8053 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x35EF910", Offset = "0x35EF910", VA = "0x35EF910")]
	[Token(Token = "0x6001F75")]
	public LavaMusic()
	{
	}

	// Token: 0x06001F76 RID: 8054 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EF918", Offset = "0x35EF918", VA = "0x35EF918")]
	[Token(Token = "0x6001F76")]
	private void method_12()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F77 RID: 8055 RVA: 0x0003B1DC File Offset: 0x000393DC
	[Address(RVA = "0x35EFB68", Offset = "0x35EFB68", VA = "0x35EFB68")]
	[Token(Token = "0x6001F77")]
	private void method_13()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position2 = transform2.position;
		Vector3 position3 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position4 = transform3.position;
		Vector3 position5 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position6 = transform4.position;
		Vector3 position7 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F78 RID: 8056 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35EFDBC", Offset = "0x35EFDBC", VA = "0x35EFDBC")]
	[Token(Token = "0x6001F78")]
	private void method_14()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F79 RID: 8057 RVA: 0x0003B33C File Offset: 0x0003953C
	[Address(RVA = "0x35F0010", Offset = "0x35F0010", VA = "0x35F0010")]
	[Token(Token = "0x6001F79")]
	private void method_15()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F7A RID: 8058 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F0260", Offset = "0x35F0260", VA = "0x35F0260")]
	[Token(Token = "0x6001F7A")]
	private void method_16()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F7B RID: 8059 RVA: 0x0003B3FC File Offset: 0x000395FC
	[Address(RVA = "0x35F04B4", Offset = "0x35F04B4", VA = "0x35F04B4")]
	[Token(Token = "0x6001F7B")]
	private void method_17()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		Transform transform4 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
	}

	// Token: 0x06001F7C RID: 8060 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F0704", Offset = "0x35F0704", VA = "0x35F0704")]
	[Token(Token = "0x6001F7C")]
	private void method_18()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F7D RID: 8061 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F0950", Offset = "0x35F0950", VA = "0x35F0950")]
	[Token(Token = "0x6001F7D")]
	private void method_19()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F7E RID: 8062 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F0BA4", Offset = "0x35F0BA4", VA = "0x35F0BA4")]
	[Token(Token = "0x6001F7E")]
	private void method_20()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F7F RID: 8063 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F0DF0", Offset = "0x35F0DF0", VA = "0x35F0DF0")]
	[Token(Token = "0x6001F7F")]
	private void method_21()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F80 RID: 8064 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F1044", Offset = "0x35F1044", VA = "0x35F1044")]
	[Token(Token = "0x6001F80")]
	private void method_22()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F81 RID: 8065 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F1298", Offset = "0x35F1298", VA = "0x35F1298")]
	[Token(Token = "0x6001F81")]
	private void method_23()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F82 RID: 8066 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F14E8", Offset = "0x35F14E8", VA = "0x35F14E8")]
	[Token(Token = "0x6001F82")]
	private void method_24()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F83 RID: 8067 RVA: 0x0003B4A8 File Offset: 0x000396A8
	[Address(RVA = "0x35F173C", Offset = "0x35F173C", VA = "0x35F173C")]
	[Token(Token = "0x6001F83")]
	private void method_25()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F84 RID: 8068 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F1990", Offset = "0x35F1990", VA = "0x35F1990")]
	[Token(Token = "0x6001F84")]
	private void method_26()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F85 RID: 8069 RVA: 0x0003B568 File Offset: 0x00039768
	[Address(RVA = "0x35F1BE0", Offset = "0x35F1BE0", VA = "0x35F1BE0")]
	[Token(Token = "0x6001F85")]
	private void method_27()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Vector3 position5 = this.transform_0.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource2.volume = volume3;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_3;
		Vector3 position7 = transform3.position;
		float volume4;
		audioSource3.volume = volume4;
	}

	// Token: 0x06001F86 RID: 8070 RVA: 0x0003B610 File Offset: 0x00039810
	[Address(RVA = "0x35F1E34", Offset = "0x35F1E34", VA = "0x35F1E34")]
	[Token(Token = "0x6001F86")]
	private void method_28()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position2 = transform2.position;
		Vector3 position3 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position4 = transform3.position;
		Vector3 position5 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position6 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F87 RID: 8071 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F2088", Offset = "0x35F2088", VA = "0x35F2088")]
	[Token(Token = "0x6001F87")]
	private void method_29()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F88 RID: 8072 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F22D8", Offset = "0x35F22D8", VA = "0x35F22D8")]
	[Token(Token = "0x6001F88")]
	private void method_30()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F89 RID: 8073 RVA: 0x0003B6B4 File Offset: 0x000398B4
	[Address(RVA = "0x35F252C", Offset = "0x35F252C", VA = "0x35F252C")]
	[Token(Token = "0x6001F89")]
	private void method_31()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position6 = transform4.position;
		Vector3 position7 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F8A RID: 8074 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F2780", Offset = "0x35F2780", VA = "0x35F2780")]
	[Token(Token = "0x6001F8A")]
	private void method_32()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F8B RID: 8075 RVA: 0x0003B768 File Offset: 0x00039968
	[Address(RVA = "0x35F29D0", Offset = "0x35F29D0", VA = "0x35F29D0")]
	[Token(Token = "0x6001F8B")]
	private void method_33()
	{
		Transform transform = this.transform_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		Transform transform2 = this.transform_0;
		AudioSource audioSource = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform3 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform4 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
	}

	// Token: 0x06001F8C RID: 8076 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F2C24", Offset = "0x35F2C24", VA = "0x35F2C24")]
	[Token(Token = "0x6001F8C")]
	private void method_34()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F8D RID: 8077 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F2E74", Offset = "0x35F2E74", VA = "0x35F2E74")]
	[Token(Token = "0x6001F8D")]
	private void method_35()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F8E RID: 8078 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F30C8", Offset = "0x35F30C8", VA = "0x35F30C8")]
	[Token(Token = "0x6001F8E")]
	private void method_36()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F8F RID: 8079 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F3318", Offset = "0x35F3318", VA = "0x35F3318")]
	[Token(Token = "0x6001F8F")]
	private void method_37()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F90 RID: 8080 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F356C", Offset = "0x35F356C", VA = "0x35F356C")]
	[Token(Token = "0x6001F90")]
	private void method_38()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F91 RID: 8081 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F37C0", Offset = "0x35F37C0", VA = "0x35F37C0")]
	[Token(Token = "0x6001F91")]
	private void method_39()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F92 RID: 8082 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F3A14", Offset = "0x35F3A14", VA = "0x35F3A14")]
	[Token(Token = "0x6001F92")]
	private void method_40()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F93 RID: 8083 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F3C68", Offset = "0x35F3C68", VA = "0x35F3C68")]
	[Token(Token = "0x6001F93")]
	private void method_41()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F94 RID: 8084 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F3EBC", Offset = "0x35F3EBC", VA = "0x35F3EBC")]
	[Token(Token = "0x6001F94")]
	private void method_42()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F95 RID: 8085 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F4110", Offset = "0x35F4110", VA = "0x35F4110")]
	[Token(Token = "0x6001F95")]
	private void method_43()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F96 RID: 8086 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F4360", Offset = "0x35F4360", VA = "0x35F4360")]
	[Token(Token = "0x6001F96")]
	private void method_44()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F97 RID: 8087 RVA: 0x0003B818 File Offset: 0x00039A18
	[Address(RVA = "0x35F45B0", Offset = "0x35F45B0", VA = "0x35F45B0")]
	[Token(Token = "0x6001F97")]
	private void method_45()
	{
		Vector3 position = this.transform_0.position;
		Vector3 position2 = this.transform_1.position;
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_1;
		Vector3 position3 = transform.position;
		Vector3 position4 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_2;
		Vector3 position5 = transform2.position;
		Vector3 position6 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_3;
		Vector3 position7 = transform3.position;
		Vector3 position8 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
	}

	// Token: 0x06001F98 RID: 8088 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F47F8", Offset = "0x35F47F8", VA = "0x35F47F8")]
	[Token(Token = "0x6001F98")]
	private void method_46()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F99 RID: 8089 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F4A44", Offset = "0x35F4A44", VA = "0x35F4A44")]
	[Token(Token = "0x6001F99")]
	private void method_47()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F9A RID: 8090 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F4C98", Offset = "0x35F4C98", VA = "0x35F4C98")]
	[Token(Token = "0x6001F9A")]
	private void method_48()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F9B RID: 8091 RVA: 0x0003AFA8 File Offset: 0x000391A8
	[Address(RVA = "0x35F4EE8", Offset = "0x35F4EE8", VA = "0x35F4EE8")]
	[Token(Token = "0x6001F9B")]
	private void method_49()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_2;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		float volume3;
		audioSource3.volume = volume3;
		Transform transform4 = this.transform_0;
		AudioSource audioSource4 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		Vector3 position8 = this.transform_1.position;
		float volume4;
		audioSource4.volume = volume4;
	}

	// Token: 0x06001F9C RID: 8092 RVA: 0x0003B8C4 File Offset: 0x00039AC4
	[Address(RVA = "0x35F513C", Offset = "0x35F513C", VA = "0x35F513C")]
	[Token(Token = "0x6001F9C")]
	private void method_50()
	{
		Transform transform = this.transform_0;
		AudioSource audioSource = this.audioSource_0;
		Vector3 position = transform.position;
		Vector3 position2 = this.transform_1.position;
		float volume;
		audioSource.volume = volume;
		Transform transform2 = this.transform_0;
		AudioSource audioSource2 = this.audioSource_1;
		Vector3 position3 = transform2.position;
		Vector3 position4 = this.transform_1.position;
		float volume2;
		audioSource2.volume = volume2;
		Transform transform3 = this.transform_0;
		Vector3 position5 = transform3.position;
		Vector3 position6 = this.transform_1.position;
		Transform transform4 = this.transform_0;
		AudioSource audioSource3 = this.audioSource_3;
		Vector3 position7 = transform4.position;
		float volume3;
		audioSource3.volume = volume3;
	}

	// Token: 0x0400043F RID: 1087
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400043F")]
	public AudioSource audioSource_0;

	// Token: 0x04000440 RID: 1088
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000440")]
	public AudioSource audioSource_1;

	// Token: 0x04000441 RID: 1089
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000441")]
	public AudioSource audioSource_2;

	// Token: 0x04000442 RID: 1090
	[Token(Token = "0x4000442")]
	[FieldOffset(Offset = "0x30")]
	public AudioSource audioSource_3;

	// Token: 0x04000443 RID: 1091
	[Token(Token = "0x4000443")]
	[FieldOffset(Offset = "0x38")]
	public Transform transform_0;

	// Token: 0x04000444 RID: 1092
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000444")]
	public Transform transform_1;
}
