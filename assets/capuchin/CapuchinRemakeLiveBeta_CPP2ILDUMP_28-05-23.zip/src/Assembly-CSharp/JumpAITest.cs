﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000076 RID: 118
[Token(Token = "0x2000076")]
public class JumpAITest : MonoBehaviour
{
	// Token: 0x0600107C RID: 4220 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600107C")]
	[Address(RVA = "0x31230E4", Offset = "0x31230E4", VA = "0x31230E4")]
	private void method_0()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600107D RID: 4221 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600107D")]
	[Address(RVA = "0x31232A8", Offset = "0x31232A8", VA = "0x31232A8")]
	private void method_1()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600107E RID: 4222 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600107E")]
	[Address(RVA = "0x312346C", Offset = "0x312346C", VA = "0x312346C")]
	private void method_2()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600107F RID: 4223 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600107F")]
	[Address(RVA = "0x3123630", Offset = "0x3123630", VA = "0x3123630")]
	private void method_3()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001080 RID: 4224 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x31237F4", Offset = "0x31237F4", VA = "0x31237F4")]
	[Token(Token = "0x6001080")]
	private void method_4()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001081 RID: 4225 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001081")]
	[Address(RVA = "0x31239B8", Offset = "0x31239B8", VA = "0x31239B8")]
	private void method_5()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001082 RID: 4226 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3123B7C", Offset = "0x3123B7C", VA = "0x3123B7C")]
	[Token(Token = "0x6001082")]
	private void method_6()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001083 RID: 4227 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001083")]
	[Address(RVA = "0x3123D40", Offset = "0x3123D40", VA = "0x3123D40")]
	private void method_7()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001084 RID: 4228 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3123F04", Offset = "0x3123F04", VA = "0x3123F04")]
	[Token(Token = "0x6001084")]
	private void method_8()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001085 RID: 4229 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001085")]
	[Address(RVA = "0x31240C8", Offset = "0x31240C8", VA = "0x31240C8")]
	private void method_9()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001086 RID: 4230 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x312428C", Offset = "0x312428C", VA = "0x312428C")]
	[Token(Token = "0x6001086")]
	private void method_10()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001087 RID: 4231 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001087")]
	[Address(RVA = "0x3124450", Offset = "0x3124450", VA = "0x3124450")]
	private void method_11()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001088 RID: 4232 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3124614", Offset = "0x3124614", VA = "0x3124614")]
	[Token(Token = "0x6001088")]
	private void method_12()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001089 RID: 4233 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x31247D8", Offset = "0x31247D8", VA = "0x31247D8")]
	[Token(Token = "0x6001089")]
	private void method_13()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600108A RID: 4234 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600108A")]
	[Address(RVA = "0x312499C", Offset = "0x312499C", VA = "0x312499C")]
	private void method_14()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600108B RID: 4235 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600108B")]
	[Address(RVA = "0x3124B60", Offset = "0x3124B60", VA = "0x3124B60")]
	private void method_15()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600108C RID: 4236 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3124D24", Offset = "0x3124D24", VA = "0x3124D24")]
	[Token(Token = "0x600108C")]
	private void FixedUpdate()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600108D RID: 4237 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3124EE8", Offset = "0x3124EE8", VA = "0x3124EE8")]
	[Token(Token = "0x600108D")]
	private void method_16()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600108E RID: 4238 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600108E")]
	[Address(RVA = "0x31250AC", Offset = "0x31250AC", VA = "0x31250AC")]
	private void method_17()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600108F RID: 4239 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600108F")]
	[Address(RVA = "0x3125270", Offset = "0x3125270", VA = "0x3125270")]
	private void method_18()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001090 RID: 4240 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3125434", Offset = "0x3125434", VA = "0x3125434")]
	[Token(Token = "0x6001090")]
	private void method_19()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001091 RID: 4241 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001091")]
	[Address(RVA = "0x31255F8", Offset = "0x31255F8", VA = "0x31255F8")]
	private void method_20()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001092 RID: 4242 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001092")]
	[Address(RVA = "0x31257BC", Offset = "0x31257BC", VA = "0x31257BC")]
	private void method_21()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001093 RID: 4243 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001093")]
	[Address(RVA = "0x3125980", Offset = "0x3125980", VA = "0x3125980")]
	private void method_22()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001094 RID: 4244 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3125B44", Offset = "0x3125B44", VA = "0x3125B44")]
	[Token(Token = "0x6001094")]
	private void method_23()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001095 RID: 4245 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3125D08", Offset = "0x3125D08", VA = "0x3125D08")]
	[Token(Token = "0x6001095")]
	public JumpAITest()
	{
	}

	// Token: 0x06001096 RID: 4246 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001096")]
	[Address(RVA = "0x3125D10", Offset = "0x3125D10", VA = "0x3125D10")]
	private void method_24()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001097 RID: 4247 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001097")]
	[Address(RVA = "0x3125ED4", Offset = "0x3125ED4", VA = "0x3125ED4")]
	private void method_25()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001098 RID: 4248 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3126098", Offset = "0x3126098", VA = "0x3126098")]
	[Token(Token = "0x6001098")]
	private void method_26()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x06001099 RID: 4249 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x6001099")]
	[Address(RVA = "0x312625C", Offset = "0x312625C", VA = "0x312625C")]
	private void method_27()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600109A RID: 4250 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600109A")]
	[Address(RVA = "0x3126420", Offset = "0x3126420", VA = "0x3126420")]
	private void method_28()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600109B RID: 4251 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600109B")]
	[Address(RVA = "0x31265E4", Offset = "0x31265E4", VA = "0x31265E4")]
	private void method_29()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600109C RID: 4252 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600109C")]
	[Address(RVA = "0x31267A8", Offset = "0x31267A8", VA = "0x31267A8")]
	private void method_30()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600109D RID: 4253 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x600109D")]
	[Address(RVA = "0x312696C", Offset = "0x312696C", VA = "0x312696C")]
	private void method_31()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600109E RID: 4254 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3126B30", Offset = "0x3126B30", VA = "0x3126B30")]
	[Token(Token = "0x600109E")]
	private void method_32()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x0600109F RID: 4255 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3126CF4", Offset = "0x3126CF4", VA = "0x3126CF4")]
	[Token(Token = "0x600109F")]
	private void method_33()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A0 RID: 4256 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3126EB8", Offset = "0x3126EB8", VA = "0x3126EB8")]
	[Token(Token = "0x60010A0")]
	private void method_34()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A1 RID: 4257 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x312707C", Offset = "0x312707C", VA = "0x312707C")]
	[Token(Token = "0x60010A1")]
	private void method_35()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A2 RID: 4258 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010A2")]
	[Address(RVA = "0x3127240", Offset = "0x3127240", VA = "0x3127240")]
	private void method_36()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A3 RID: 4259 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010A3")]
	[Address(RVA = "0x3127404", Offset = "0x3127404", VA = "0x3127404")]
	private void method_37()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A4 RID: 4260 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010A4")]
	[Address(RVA = "0x31275C8", Offset = "0x31275C8", VA = "0x31275C8")]
	private void method_38()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A5 RID: 4261 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x312778C", Offset = "0x312778C", VA = "0x312778C")]
	[Token(Token = "0x60010A5")]
	private void method_39()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A6 RID: 4262 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3127950", Offset = "0x3127950", VA = "0x3127950")]
	[Token(Token = "0x60010A6")]
	private void method_40()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A7 RID: 4263 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010A7")]
	[Address(RVA = "0x3127B14", Offset = "0x3127B14", VA = "0x3127B14")]
	private void method_41()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A8 RID: 4264 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010A8")]
	[Address(RVA = "0x3127CD8", Offset = "0x3127CD8", VA = "0x3127CD8")]
	private void method_42()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010A9 RID: 4265 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010A9")]
	[Address(RVA = "0x3127E9C", Offset = "0x3127E9C", VA = "0x3127E9C")]
	private void method_43()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010AA RID: 4266 RVA: 0x00020230 File Offset: 0x0001E430
	[Address(RVA = "0x3128060", Offset = "0x3128060", VA = "0x3128060")]
	[Token(Token = "0x60010AA")]
	private void method_44()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010AB RID: 4267 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010AB")]
	[Address(RVA = "0x3128224", Offset = "0x3128224", VA = "0x3128224")]
	private void method_45()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010AC RID: 4268 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010AC")]
	[Address(RVA = "0x31283E8", Offset = "0x31283E8", VA = "0x31283E8")]
	private void method_46()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010AD RID: 4269 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010AD")]
	[Address(RVA = "0x31285AC", Offset = "0x31285AC", VA = "0x31285AC")]
	private void method_47()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010AE RID: 4270 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010AE")]
	[Address(RVA = "0x3128770", Offset = "0x3128770", VA = "0x3128770")]
	private void method_48()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x060010AF RID: 4271 RVA: 0x00020230 File Offset: 0x0001E430
	[Token(Token = "0x60010AF")]
	[Address(RVA = "0x3128934", Offset = "0x3128934", VA = "0x3128934")]
	private void method_49()
	{
		Vector3 position = this.transform_0.position;
		Vector3 forward = Vector3.forward;
		Vector3 position2 = this.transform_0.position;
		Vector3 forward2 = Vector3.forward;
		Color red = Color.red;
	}

	// Token: 0x04000264 RID: 612
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000264")]
	public Transform transform_0;

	// Token: 0x04000265 RID: 613
	[Token(Token = "0x4000265")]
	[FieldOffset(Offset = "0x20")]
	public float float_0;
}
