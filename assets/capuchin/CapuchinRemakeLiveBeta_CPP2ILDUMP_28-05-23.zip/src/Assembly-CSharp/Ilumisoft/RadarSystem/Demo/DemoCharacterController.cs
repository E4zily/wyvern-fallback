﻿using System;
using System.Runtime.CompilerServices;
using Cpp2IlInjected;
using UnityEngine;

namespace Ilumisoft.RadarSystem.Demo
{
	// Token: 0x02000185 RID: 389
	[Token(Token = "0x2000185")]
	public class DemoCharacterController : MonoBehaviour
	{
		// Token: 0x06003BAA RID: 15274 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003BAA")]
		[Address(RVA = "0x2A12A50", Offset = "0x2A12A50", VA = "0x2A12A50")]
		private void method_0()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BAB RID: 15275 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A12AAC", Offset = "0x2A12AAC", VA = "0x2A12AAC")]
		[Token(Token = "0x6003BAB")]
		private void method_1(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BAC RID: 15276 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A12AB4", Offset = "0x2A12AB4", VA = "0x2A12AB4")]
		[Token(Token = "0x6003BAC")]
		private void method_2()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BAD RID: 15277 RVA: 0x0007529C File Offset: 0x0007349C
		[Address(RVA = "0x2A12B10", Offset = "0x2A12B10", VA = "0x2A12B10")]
		[Token(Token = "0x6003BAD")]
		private void Update()
		{
			Input.GetAxisRaw("Horizontal");
			Input.GetAxisRaw("Vertical");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BAE RID: 15278 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003BAE")]
		[Address(RVA = "0x2A12C68", Offset = "0x2A12C68", VA = "0x2A12C68")]
		private void method_3()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BAF RID: 15279 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A12CC4", Offset = "0x2A12CC4", VA = "0x2A12CC4")]
		[Token(Token = "0x6003BAF")]
		private CharacterController method_4()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BB0 RID: 15280 RVA: 0x000752E4 File Offset: 0x000734E4
		[Token(Token = "0x6003BB0")]
		[Address(RVA = "0x2A12CCC", Offset = "0x2A12CCC", VA = "0x2A12CCC")]
		private void method_5()
		{
			Input.GetAxisRaw("");
			Input.GetAxisRaw("Stopped Colliding");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BB1 RID: 15281 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A12E24", Offset = "0x2A12E24", VA = "0x2A12E24")]
		[Token(Token = "0x6003BB1")]
		private void method_6(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BB2 RID: 15282 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A12E2C", Offset = "0x2A12E2C", VA = "0x2A12E2C")]
		[Token(Token = "0x6003BB2")]
		private CharacterController method_7()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BB3 RID: 15283 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A12E34", Offset = "0x2A12E34", VA = "0x2A12E34")]
		[Token(Token = "0x6003BB3")]
		private CharacterController method_8()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BB4 RID: 15284 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A12E3C", Offset = "0x2A12E3C", VA = "0x2A12E3C")]
		[Token(Token = "0x6003BB4")]
		private void method_9()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BB5 RID: 15285 RVA: 0x0007532C File Offset: 0x0007352C
		[Token(Token = "0x6003BB5")]
		[Address(RVA = "0x2A12E98", Offset = "0x2A12E98", VA = "0x2A12E98")]
		private void method_10()
		{
			Input.GetAxisRaw("");
			Input.GetAxisRaw("NGNNoSound");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BB6 RID: 15286 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A12FF0", Offset = "0x2A12FF0", VA = "0x2A12FF0")]
		[Token(Token = "0x6003BB6")]
		private void method_11()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BB7 RID: 15287 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003BB7")]
		[Address(RVA = "0x2A1304C", Offset = "0x2A1304C", VA = "0x2A1304C")]
		private void method_12()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BB8 RID: 15288 RVA: 0x00075374 File Offset: 0x00073574
		[Token(Token = "0x6003BB8")]
		[Address(RVA = "0x2A130A8", Offset = "0x2A130A8", VA = "0x2A130A8")]
		private void method_13()
		{
			Input.GetAxisRaw("We don't need this electrical box");
			Input.GetAxisRaw("Player");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BB9 RID: 15289 RVA: 0x000037E3 File Offset: 0x000019E3
		[Token(Token = "0x6003BB9")]
		[Address(RVA = "0x2A13200", Offset = "0x2A13200", VA = "0x2A13200")]
		private CharacterController method_14()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BBA RID: 15290 RVA: 0x000753BC File Offset: 0x000735BC
		[Address(RVA = "0x2A13208", Offset = "0x2A13208", VA = "0x2A13208")]
		[Token(Token = "0x6003BBA")]
		private void method_15()
		{
			Input.GetAxisRaw("Player");
			Input.GetAxisRaw("FingerTip");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BBB RID: 15291 RVA: 0x00075404 File Offset: 0x00073604
		[Address(RVA = "0x2A13360", Offset = "0x2A13360", VA = "0x2A13360")]
		[Token(Token = "0x6003BBB")]
		private void method_16()
		{
			Input.GetAxisRaw("[InputHelpers.IsPressed] The value of <button> is out or the supported range.");
			Input.GetAxisRaw("StartGamemode");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BBC RID: 15292 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003BBC")]
		[Address(RVA = "0x2A134B8", Offset = "0x2A134B8", VA = "0x2A134B8")]
		private void method_17()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BBD RID: 15293 RVA: 0x0007544C File Offset: 0x0007364C
		[Token(Token = "0x6003BBD")]
		[Address(RVA = "0x2A13514", Offset = "0x2A13514", VA = "0x2A13514")]
		private void method_18()
		{
			Input.GetAxisRaw("Try Connect To Server...");
			Input.GetAxisRaw("vive");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BBE RID: 15294 RVA: 0x000037DA File Offset: 0x000019DA
		[Token(Token = "0x6003BBE")]
		[Address(RVA = "0x2A1366C", Offset = "0x2A1366C", VA = "0x2A1366C")]
		private void method_19(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BBF RID: 15295 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A13674", Offset = "0x2A13674", VA = "0x2A13674")]
		[Token(Token = "0x6003BBF")]
		private void method_20(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BC0 RID: 15296 RVA: 0x000037DA File Offset: 0x000019DA
		[Token(Token = "0x6003BC0")]
		[Address(RVA = "0x2A1367C", Offset = "0x2A1367C", VA = "0x2A1367C")]
		private void method_21(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BC1 RID: 15297 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A13684", Offset = "0x2A13684", VA = "0x2A13684")]
		[Token(Token = "0x6003BC1")]
		private void method_22()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BC2 RID: 15298 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A136E0", Offset = "0x2A136E0", VA = "0x2A136E0")]
		[Token(Token = "0x6003BC2")]
		private void method_23(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BC3 RID: 15299 RVA: 0x00075494 File Offset: 0x00073694
		[Token(Token = "0x6003BC3")]
		[Address(RVA = "0x2A136E8", Offset = "0x2A136E8", VA = "0x2A136E8")]
		private void method_24()
		{
			Input.GetAxisRaw(". Please update you game to the latest version");
			Input.GetAxisRaw("Player");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BC4 RID: 15300 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003BC4")]
		[Address(RVA = "0x2A13840", Offset = "0x2A13840", VA = "0x2A13840")]
		private void method_25()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BC5 RID: 15301 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003BC5")]
		[Address(RVA = "0x2A1389C", Offset = "0x2A1389C", VA = "0x2A1389C")]
		private void method_26()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BC6 RID: 15302 RVA: 0x000754DC File Offset: 0x000736DC
		[Token(Token = "0x6003BC6")]
		[Address(RVA = "0x2A138F8", Offset = "0x2A138F8", VA = "0x2A138F8")]
		private void method_27()
		{
			Input.GetAxisRaw("Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.");
			Input.GetAxisRaw("FingerTip");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BC7 RID: 15303 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A13A50", Offset = "0x2A13A50", VA = "0x2A13A50")]
		[Token(Token = "0x6003BC7")]
		private CharacterController method_28()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BC8 RID: 15304 RVA: 0x00075524 File Offset: 0x00073724
		[Address(RVA = "0x2A13A58", Offset = "0x2A13A58", VA = "0x2A13A58")]
		[Token(Token = "0x6003BC8")]
		private void method_29()
		{
			Input.GetAxisRaw("HorrorAgreement");
			Input.GetAxisRaw("FingerTip");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BC9 RID: 15305 RVA: 0x0007556C File Offset: 0x0007376C
		[Address(RVA = "0x2A13BB0", Offset = "0x2A13BB0", VA = "0x2A13BB0")]
		[Token(Token = "0x6003BC9")]
		private void method_30()
		{
			Input.GetAxisRaw("_BumpScale");
			Input.GetAxisRaw("forced knee");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BCA RID: 15306 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A13D08", Offset = "0x2A13D08", VA = "0x2A13D08")]
		[Token(Token = "0x6003BCA")]
		private void method_31(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BCB RID: 15307 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A13D10", Offset = "0x2A13D10", VA = "0x2A13D10")]
		[Token(Token = "0x6003BCB")]
		private CharacterController method_32()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BCC RID: 15308 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A13D18", Offset = "0x2A13D18", VA = "0x2A13D18")]
		[Token(Token = "0x6003BCC")]
		private CharacterController method_33()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BCD RID: 15309 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A13D20", Offset = "0x2A13D20", VA = "0x2A13D20")]
		[Token(Token = "0x6003BCD")]
		private CharacterController method_34()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BCE RID: 15310 RVA: 0x000755B4 File Offset: 0x000737B4
		[Address(RVA = "0x2A13D28", Offset = "0x2A13D28", VA = "0x2A13D28")]
		[Token(Token = "0x6003BCE")]
		private void method_35()
		{
			Input.GetAxisRaw("Round end");
			Input.GetAxisRaw("Is Colliding");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BCF RID: 15311 RVA: 0x000037E3 File Offset: 0x000019E3
		[Token(Token = "0x6003BCF")]
		[Address(RVA = "0x2A13E80", Offset = "0x2A13E80", VA = "0x2A13E80")]
		private CharacterController method_36()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BD0 RID: 15312 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A13E88", Offset = "0x2A13E88", VA = "0x2A13E88")]
		[Token(Token = "0x6003BD0")]
		private void method_37()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BD1 RID: 15313 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A13EE4", Offset = "0x2A13EE4", VA = "0x2A13EE4")]
		[Token(Token = "0x6003BD1")]
		private void method_38(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BD2 RID: 15314 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A13EEC", Offset = "0x2A13EEC", VA = "0x2A13EEC")]
		[Token(Token = "0x6003BD2")]
		private void method_39()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BD3 RID: 15315 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A13F48", Offset = "0x2A13F48", VA = "0x2A13F48")]
		[Token(Token = "0x6003BD3")]
		private void Awake()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BD4 RID: 15316 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A13FA4", Offset = "0x2A13FA4", VA = "0x2A13FA4")]
		[Token(Token = "0x6003BD4")]
		private void method_40(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BD5 RID: 15317 RVA: 0x000755FC File Offset: 0x000737FC
		[Address(RVA = "0x2A13FAC", Offset = "0x2A13FAC", VA = "0x2A13FAC")]
		[Token(Token = "0x6003BD5")]
		private void method_41()
		{
			throw new MissingMethodException();
		}

		// Token: 0x06003BD6 RID: 15318 RVA: 0x000037DA File Offset: 0x000019DA
		[Token(Token = "0x6003BD6")]
		[Address(RVA = "0x2A14104", Offset = "0x2A14104", VA = "0x2A14104")]
		private void method_42(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BD7 RID: 15319 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A1410C", Offset = "0x2A1410C", VA = "0x2A1410C")]
		[Token(Token = "0x6003BD7")]
		private void method_43(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BD8 RID: 15320 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A14114", Offset = "0x2A14114", VA = "0x2A14114")]
		[Token(Token = "0x6003BD8")]
		private void method_44()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06003BD9 RID: 15321 RVA: 0x000037E3 File Offset: 0x000019E3
		// (set) Token: 0x06003C44 RID: 15428 RVA: 0x000037DA File Offset: 0x000019DA
		[Token(Token = "0x170000F5")]
		private CharacterController CharacterController_0 { [Address(RVA = "0x2A14170", Offset = "0x2A14170", VA = "0x2A14170")] [Token(Token = "0x6003BD9")] get; [Address(RVA = "0x2A170F8", Offset = "0x2A170F8", VA = "0x2A170F8")] [Token(Token = "0x6003C44")] set; }

		// Token: 0x06003BDA RID: 15322 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A14178", Offset = "0x2A14178", VA = "0x2A14178")]
		[Token(Token = "0x6003BDA")]
		private void method_45(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BDB RID: 15323 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A14180", Offset = "0x2A14180", VA = "0x2A14180")]
		[Token(Token = "0x6003BDB")]
		private void method_46()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BDC RID: 15324 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A141DC", Offset = "0x2A141DC", VA = "0x2A141DC")]
		[Token(Token = "0x6003BDC")]
		private void method_47(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BDD RID: 15325 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A141E4", Offset = "0x2A141E4", VA = "0x2A141E4")]
		[Token(Token = "0x6003BDD")]
		private void method_48(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BDE RID: 15326 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A141EC", Offset = "0x2A141EC", VA = "0x2A141EC")]
		[Token(Token = "0x6003BDE")]
		private void method_49(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BDF RID: 15327 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A141F4", Offset = "0x2A141F4", VA = "0x2A141F4")]
		[Token(Token = "0x6003BDF")]
		private void method_50()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BE0 RID: 15328 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A14250", Offset = "0x2A14250", VA = "0x2A14250")]
		[Token(Token = "0x6003BE0")]
		private CharacterController method_51()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BE1 RID: 15329 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A14258", Offset = "0x2A14258", VA = "0x2A14258")]
		[Token(Token = "0x6003BE1")]
		private void method_52()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BE2 RID: 15330 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A142B4", Offset = "0x2A142B4", VA = "0x2A142B4")]
		[Token(Token = "0x6003BE2")]
		private void method_53(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BE3 RID: 15331 RVA: 0x00075610 File Offset: 0x00073810
		[Address(RVA = "0x2A142BC", Offset = "0x2A142BC", VA = "0x2A142BC")]
		[Token(Token = "0x6003BE3")]
		private void method_54()
		{
			Input.GetAxisRaw("NGNNoSound");
			Input.GetAxisRaw("n0");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BE4 RID: 15332 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A14414", Offset = "0x2A14414", VA = "0x2A14414")]
		[Token(Token = "0x6003BE4")]
		private CharacterController method_55()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BE5 RID: 15333 RVA: 0x00075658 File Offset: 0x00073858
		[Address(RVA = "0x2A1441C", Offset = "0x2A1441C", VA = "0x2A1441C")]
		[Token(Token = "0x6003BE5")]
		private void method_56()
		{
			Input.GetAxisRaw("TurnAmount");
			Input.GetAxisRaw("NetworkPlayer");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BE6 RID: 15334 RVA: 0x000756A0 File Offset: 0x000738A0
		[Address(RVA = "0x2A14574", Offset = "0x2A14574", VA = "0x2A14574")]
		[Token(Token = "0x6003BE6")]
		private void method_57()
		{
			Input.GetAxisRaw("FingerTip");
			Input.GetAxisRaw("FingerTip");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BE7 RID: 15335 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A146B8", Offset = "0x2A146B8", VA = "0x2A146B8")]
		[Token(Token = "0x6003BE7")]
		private void method_58(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BE8 RID: 15336 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A146C0", Offset = "0x2A146C0", VA = "0x2A146C0")]
		[Token(Token = "0x6003BE8")]
		private void method_59(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BE9 RID: 15337 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A146C8", Offset = "0x2A146C8", VA = "0x2A146C8")]
		[Token(Token = "0x6003BE9")]
		private void method_60()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BEA RID: 15338 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A14724", Offset = "0x2A14724", VA = "0x2A14724")]
		[Token(Token = "0x6003BEA")]
		private void method_61()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BEB RID: 15339 RVA: 0x000756E8 File Offset: 0x000738E8
		[Address(RVA = "0x2A14780", Offset = "0x2A14780", VA = "0x2A14780")]
		[Token(Token = "0x6003BEB")]
		private void method_62()
		{
			Input.GetAxisRaw("DisableCosmetic");
			Input.GetAxisRaw("make more points bobo");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BEC RID: 15340 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A148D8", Offset = "0x2A148D8", VA = "0x2A148D8")]
		[Token(Token = "0x6003BEC")]
		private void method_63(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BED RID: 15341 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A148E0", Offset = "0x2A148E0", VA = "0x2A148E0")]
		[Token(Token = "0x6003BED")]
		private CharacterController method_64()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BEE RID: 15342 RVA: 0x00075730 File Offset: 0x00073930
		[Address(RVA = "0x2A148E8", Offset = "0x2A148E8", VA = "0x2A148E8")]
		[Token(Token = "0x6003BEE")]
		private void method_65()
		{
			Input.GetAxisRaw("");
			Input.GetAxisRaw("true");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BEF RID: 15343 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A14A40", Offset = "0x2A14A40", VA = "0x2A14A40")]
		[Token(Token = "0x6003BEF")]
		private CharacterController method_66()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BF0 RID: 15344 RVA: 0x00075778 File Offset: 0x00073978
		[Address(RVA = "0x2A14A48", Offset = "0x2A14A48", VA = "0x2A14A48")]
		[Token(Token = "0x6003BF0")]
		private void method_67()
		{
			Input.GetAxisRaw("FingerTip");
			Input.GetAxisRaw("User has been reported for: ");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BF1 RID: 15345 RVA: 0x00075524 File Offset: 0x00073724
		[Address(RVA = "0x2A14BA0", Offset = "0x2A14BA0", VA = "0x2A14BA0")]
		[Token(Token = "0x6003BF1")]
		private void method_68()
		{
			Input.GetAxisRaw("HorrorAgreement");
			Input.GetAxisRaw("FingerTip");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BF2 RID: 15346 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A14CF8", Offset = "0x2A14CF8", VA = "0x2A14CF8")]
		[Token(Token = "0x6003BF2")]
		private CharacterController method_69()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BF3 RID: 15347 RVA: 0x000757C0 File Offset: 0x000739C0
		[Address(RVA = "0x2A14D00", Offset = "0x2A14D00", VA = "0x2A14D00")]
		[Token(Token = "0x6003BF3")]
		private void method_70()
		{
			Input.GetAxisRaw("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
			Input.GetAxisRaw("User has been reported for: ");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BF4 RID: 15348 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A14E58", Offset = "0x2A14E58", VA = "0x2A14E58")]
		[Token(Token = "0x6003BF4")]
		private void method_71()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BF5 RID: 15349 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A14EB4", Offset = "0x2A14EB4", VA = "0x2A14EB4")]
		[Token(Token = "0x6003BF5")]
		private void method_72(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BF6 RID: 15350 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003BF6")]
		[Address(RVA = "0x2A14EBC", Offset = "0x2A14EBC", VA = "0x2A14EBC")]
		private void method_73()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BF7 RID: 15351 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A14F18", Offset = "0x2A14F18", VA = "0x2A14F18")]
		[Token(Token = "0x6003BF7")]
		private void method_74()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BF8 RID: 15352 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A14F74", Offset = "0x2A14F74", VA = "0x2A14F74")]
		[Token(Token = "0x6003BF8")]
		private void method_75()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BF9 RID: 15353 RVA: 0x00075808 File Offset: 0x00073A08
		[Address(RVA = "0x2A14FD0", Offset = "0x2A14FD0", VA = "0x2A14FD0")]
		[Token(Token = "0x6003BF9")]
		private void method_76()
		{
			Input.GetAxisRaw("True");
			Input.GetAxisRaw("NetworkPlayer");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BFA RID: 15354 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A15128", Offset = "0x2A15128", VA = "0x2A15128")]
		[Token(Token = "0x6003BFA")]
		private CharacterController method_77()
		{
			return this.characterController_0;
		}

		// Token: 0x06003BFB RID: 15355 RVA: 0x00075850 File Offset: 0x00073A50
		[Address(RVA = "0x2A15130", Offset = "0x2A15130", VA = "0x2A15130")]
		[Token(Token = "0x6003BFB")]
		private void method_78()
		{
			Input.GetAxisRaw("down unstuck");
			Input.GetAxisRaw("Name Changing Error. Error: ");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003BFC RID: 15356 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A15288", Offset = "0x2A15288", VA = "0x2A15288")]
		[Token(Token = "0x6003BFC")]
		private void method_79()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BFD RID: 15357 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A152E4", Offset = "0x2A152E4", VA = "0x2A152E4")]
		[Token(Token = "0x6003BFD")]
		private void method_80()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003BFE RID: 15358 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A15340", Offset = "0x2A15340", VA = "0x2A15340")]
		[Token(Token = "0x6003BFE")]
		private void method_81(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003BFF RID: 15359 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A15348", Offset = "0x2A15348", VA = "0x2A15348")]
		[Token(Token = "0x6003BFF")]
		private void method_82(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C00 RID: 15360 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A15350", Offset = "0x2A15350", VA = "0x2A15350")]
		[Token(Token = "0x6003C00")]
		private CharacterController method_83()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C01 RID: 15361 RVA: 0x00075898 File Offset: 0x00073A98
		[Address(RVA = "0x2A15358", Offset = "0x2A15358", VA = "0x2A15358")]
		[Token(Token = "0x6003C01")]
		private void method_84()
		{
			Input.GetAxisRaw("EnableCosmetic");
			Input.GetAxisRaw("EnableCosmetic");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C02 RID: 15362 RVA: 0x000758E0 File Offset: 0x00073AE0
		[Token(Token = "0x6003C02")]
		[Address(RVA = "0x2A1549C", Offset = "0x2A1549C", VA = "0x2A1549C")]
		private void method_85()
		{
			Input.GetAxisRaw("username");
			Input.GetAxisRaw("PURCHASED");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C03 RID: 15363 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A155F4", Offset = "0x2A155F4", VA = "0x2A155F4")]
		[Token(Token = "0x6003C03")]
		private CharacterController method_86()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C04 RID: 15364 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A155FC", Offset = "0x2A155FC", VA = "0x2A155FC")]
		[Token(Token = "0x6003C04")]
		private void method_87()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C05 RID: 15365 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A15658", Offset = "0x2A15658", VA = "0x2A15658")]
		[Token(Token = "0x6003C05")]
		private void method_88()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C06 RID: 15366 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A156B4", Offset = "0x2A156B4", VA = "0x2A156B4")]
		[Token(Token = "0x6003C06")]
		private void method_89(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C07 RID: 15367 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A156BC", Offset = "0x2A156BC", VA = "0x2A156BC")]
		[Token(Token = "0x6003C07")]
		private void method_90(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C08 RID: 15368 RVA: 0x00075928 File Offset: 0x00073B28
		[Address(RVA = "0x2A156C4", Offset = "0x2A156C4", VA = "0x2A156C4")]
		[Token(Token = "0x6003C08")]
		private void method_91()
		{
			Input.GetAxisRaw("duration done");
			Input.GetAxisRaw("Added Winner Money");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C09 RID: 15369 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A1581C", Offset = "0x2A1581C", VA = "0x2A1581C")]
		[Token(Token = "0x6003C09")]
		private void method_92()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C0A RID: 15370 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A15878", Offset = "0x2A15878", VA = "0x2A15878")]
		[Token(Token = "0x6003C0A")]
		private void method_93()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C0B RID: 15371 RVA: 0x00002060 File Offset: 0x00000260
		[Address(RVA = "0x2A158D4", Offset = "0x2A158D4", VA = "0x2A158D4")]
		[Token(Token = "0x6003C0B")]
		public DemoCharacterController()
		{
		}

		// Token: 0x06003C0C RID: 15372 RVA: 0x00075970 File Offset: 0x00073B70
		[Address(RVA = "0x2A158E8", Offset = "0x2A158E8", VA = "0x2A158E8")]
		[Token(Token = "0x6003C0C")]
		private void method_94()
		{
			Input.GetAxisRaw("_Tint");
			Input.GetAxisRaw("RightHandAttachPoint");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C0D RID: 15373 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A15A40", Offset = "0x2A15A40", VA = "0x2A15A40")]
		[Token(Token = "0x6003C0D")]
		private void method_95(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C0E RID: 15374 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A15A48", Offset = "0x2A15A48", VA = "0x2A15A48")]
		[Token(Token = "0x6003C0E")]
		private CharacterController method_96()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C0F RID: 15375 RVA: 0x000759B8 File Offset: 0x00073BB8
		[Address(RVA = "0x2A15A50", Offset = "0x2A15A50", VA = "0x2A15A50")]
		[Token(Token = "0x6003C0F")]
		private void method_97()
		{
			Input.GetAxisRaw("\n");
			Input.GetAxisRaw("Faild To Add Winner Money: ");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C10 RID: 15376 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A15BA8", Offset = "0x2A15BA8", VA = "0x2A15BA8")]
		[Token(Token = "0x6003C10")]
		private void method_98(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C11 RID: 15377 RVA: 0x000037E3 File Offset: 0x000019E3
		[Token(Token = "0x6003C11")]
		[Address(RVA = "0x2A15BB0", Offset = "0x2A15BB0", VA = "0x2A15BB0")]
		private CharacterController method_99()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C12 RID: 15378 RVA: 0x00075A00 File Offset: 0x00073C00
		[Address(RVA = "0x2A15BB8", Offset = "0x2A15BB8", VA = "0x2A15BB8")]
		[Token(Token = "0x6003C12")]
		private void method_100()
		{
			Input.GetAxisRaw("This scene is set up to create a combined material and meshes with adjusted UVs so \n objects can share a material and be batched by Unity's static/dynamic batching.\n This scene has added a BatchPrefabBaker component to a Mesh and Material Baker which \n  can bake many prefabs (each of which can have several renderers) in one click.\n The batching tool accepts prefab assets instead of scene objects. \n");
			Input.GetAxisRaw("EnableCosmetic");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C13 RID: 15379 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A15D10", Offset = "0x2A15D10", VA = "0x2A15D10")]
		[Token(Token = "0x6003C13")]
		private void method_101(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C14 RID: 15380 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A15D18", Offset = "0x2A15D18", VA = "0x2A15D18")]
		[Token(Token = "0x6003C14")]
		private void method_102(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C15 RID: 15381 RVA: 0x00075A48 File Offset: 0x00073C48
		[Address(RVA = "0x2A15D20", Offset = "0x2A15D20", VA = "0x2A15D20")]
		[Token(Token = "0x6003C15")]
		private void method_103()
		{
			Input.GetAxisRaw("Version");
			Input.GetAxisRaw("TurnAmount");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C16 RID: 15382 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A15E78", Offset = "0x2A15E78", VA = "0x2A15E78")]
		[Token(Token = "0x6003C16")]
		private CharacterController method_104()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C17 RID: 15383 RVA: 0x00075A90 File Offset: 0x00073C90
		[Address(RVA = "0x2A15E80", Offset = "0x2A15E80", VA = "0x2A15E80")]
		[Token(Token = "0x6003C17")]
		private void method_105()
		{
			Input.GetAxisRaw("An error has occured while buying bananas, please restart your game and try again");
			Input.GetAxisRaw("PlayWave");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C18 RID: 15384 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A15FD8", Offset = "0x2A15FD8", VA = "0x2A15FD8")]
		[Token(Token = "0x6003C18")]
		private void method_106(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C19 RID: 15385 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A15FE0", Offset = "0x2A15FE0", VA = "0x2A15FE0")]
		[Token(Token = "0x6003C19")]
		private void method_107()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C1A RID: 15386 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A1603C", Offset = "0x2A1603C", VA = "0x2A1603C")]
		[Token(Token = "0x6003C1A")]
		private void method_108(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C1B RID: 15387 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A16044", Offset = "0x2A16044", VA = "0x2A16044")]
		[Token(Token = "0x6003C1B")]
		private CharacterController method_109()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C1C RID: 15388 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A1604C", Offset = "0x2A1604C", VA = "0x2A1604C")]
		[Token(Token = "0x6003C1C")]
		private CharacterController method_110()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C1D RID: 15389 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A16054", Offset = "0x2A16054", VA = "0x2A16054")]
		[Token(Token = "0x6003C1D")]
		private CharacterController method_111()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C1E RID: 15390 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A1605C", Offset = "0x2A1605C", VA = "0x2A1605C")]
		[Token(Token = "0x6003C1E")]
		private void method_112(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C1F RID: 15391 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A16064", Offset = "0x2A16064", VA = "0x2A16064")]
		[Token(Token = "0x6003C1F")]
		private void method_113(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C20 RID: 15392 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A1606C", Offset = "0x2A1606C", VA = "0x2A1606C")]
		[Token(Token = "0x6003C20")]
		private CharacterController method_114()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C21 RID: 15393 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A16074", Offset = "0x2A16074", VA = "0x2A16074")]
		[Token(Token = "0x6003C21")]
		private void method_115(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C22 RID: 15394 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A1607C", Offset = "0x2A1607C", VA = "0x2A1607C")]
		[Token(Token = "0x6003C22")]
		private void method_116(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C23 RID: 15395 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003C23")]
		[Address(RVA = "0x2A16084", Offset = "0x2A16084", VA = "0x2A16084")]
		private void method_117()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C24 RID: 15396 RVA: 0x00075AD8 File Offset: 0x00073CD8
		[Address(RVA = "0x2A160E0", Offset = "0x2A160E0", VA = "0x2A160E0")]
		[Token(Token = "0x6003C24")]
		private void method_118()
		{
			Input.GetAxisRaw("betaAgree");
			Input.GetAxisRaw("Reason: ");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C25 RID: 15397 RVA: 0x00075B20 File Offset: 0x00073D20
		[Address(RVA = "0x2A16238", Offset = "0x2A16238", VA = "0x2A16238")]
		[Token(Token = "0x6003C25")]
		private void method_119()
		{
			Input.GetAxisRaw("tutorialCheck");
			Input.GetAxisRaw("Charging...");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C26 RID: 15398 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A16390", Offset = "0x2A16390", VA = "0x2A16390")]
		[Token(Token = "0x6003C26")]
		private void method_120()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C27 RID: 15399 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A163EC", Offset = "0x2A163EC", VA = "0x2A163EC")]
		[Token(Token = "0x6003C27")]
		private void method_121(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C28 RID: 15400 RVA: 0x000037E3 File Offset: 0x000019E3
		[Token(Token = "0x6003C28")]
		[Address(RVA = "0x2A163F4", Offset = "0x2A163F4", VA = "0x2A163F4")]
		private CharacterController method_122()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C29 RID: 15401 RVA: 0x000037DA File Offset: 0x000019DA
		[Token(Token = "0x6003C29")]
		[Address(RVA = "0x2A163FC", Offset = "0x2A163FC", VA = "0x2A163FC")]
		private void method_123(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C2A RID: 15402 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003C2A")]
		[Address(RVA = "0x2A16404", Offset = "0x2A16404", VA = "0x2A16404")]
		private void method_124()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C2B RID: 15403 RVA: 0x00075B68 File Offset: 0x00073D68
		[Address(RVA = "0x2A16460", Offset = "0x2A16460", VA = "0x2A16460")]
		[Token(Token = "0x6003C2B")]
		private void method_125()
		{
			Input.GetAxisRaw("Press space to switch the material on one of the cubes. This scene reuses the Texture Bake Result from the SceneBasic example.");
			Input.GetAxisRaw("On");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C2C RID: 15404 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A165B8", Offset = "0x2A165B8", VA = "0x2A165B8")]
		[Token(Token = "0x6003C2C")]
		private void method_126(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C2D RID: 15405 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A165C0", Offset = "0x2A165C0", VA = "0x2A165C0")]
		[Token(Token = "0x6003C2D")]
		private void method_127(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C2E RID: 15406 RVA: 0x00075BB0 File Offset: 0x00073DB0
		[Address(RVA = "0x2A165C8", Offset = "0x2A165C8", VA = "0x2A165C8")]
		[Token(Token = "0x6003C2E")]
		private void method_128()
		{
			Input.GetAxisRaw("Applying to material");
			Input.GetAxisRaw("Player");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C2F RID: 15407 RVA: 0x00075BF8 File Offset: 0x00073DF8
		[Address(RVA = "0x2A16720", Offset = "0x2A16720", VA = "0x2A16720")]
		[Token(Token = "0x6003C2F")]
		private void method_129()
		{
			Input.GetAxisRaw("On");
			Input.GetAxisRaw("HDRP/Lit");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C30 RID: 15408 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003C30")]
		[Address(RVA = "0x2A16878", Offset = "0x2A16878", VA = "0x2A16878")]
		private void method_130()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C31 RID: 15409 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A168D4", Offset = "0x2A168D4", VA = "0x2A168D4")]
		[Token(Token = "0x6003C31")]
		private CharacterController method_131()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C32 RID: 15410 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A168DC", Offset = "0x2A168DC", VA = "0x2A168DC")]
		[Token(Token = "0x6003C32")]
		private CharacterController method_132()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C33 RID: 15411 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A168E4", Offset = "0x2A168E4", VA = "0x2A168E4")]
		[Token(Token = "0x6003C33")]
		private CharacterController method_133()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C34 RID: 15412 RVA: 0x00075C40 File Offset: 0x00073E40
		[Address(RVA = "0x2A168EC", Offset = "0x2A168EC", VA = "0x2A168EC")]
		[Token(Token = "0x6003C34")]
		private void method_134()
		{
			Input.GetAxisRaw("username");
			Input.GetAxisRaw("retract broken");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C35 RID: 15413 RVA: 0x00075C88 File Offset: 0x00073E88
		[Address(RVA = "0x2A16A44", Offset = "0x2A16A44", VA = "0x2A16A44")]
		[Token(Token = "0x6003C35")]
		private void method_135()
		{
			Input.GetAxisRaw("Holdable");
			Input.GetAxisRaw("Push To Talk");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C36 RID: 15414 RVA: 0x00075280 File Offset: 0x00073480
		[Token(Token = "0x6003C36")]
		[Address(RVA = "0x2A16B9C", Offset = "0x2A16B9C", VA = "0x2A16B9C")]
		private void method_136()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C37 RID: 15415 RVA: 0x00075CD0 File Offset: 0x00073ED0
		[Token(Token = "0x6003C37")]
		[Address(RVA = "0x2A16BF8", Offset = "0x2A16BF8", VA = "0x2A16BF8")]
		private void method_137()
		{
			Input.GetAxisRaw("Skelechin");
			Input.GetAxisRaw(" and the correct version is ");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C38 RID: 15416 RVA: 0x000037E3 File Offset: 0x000019E3
		[Token(Token = "0x6003C38")]
		[Address(RVA = "0x2A16D50", Offset = "0x2A16D50", VA = "0x2A16D50")]
		private CharacterController method_138()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C39 RID: 15417 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A16D58", Offset = "0x2A16D58", VA = "0x2A16D58")]
		[Token(Token = "0x6003C39")]
		private void method_139()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C3A RID: 15418 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A16DB4", Offset = "0x2A16DB4", VA = "0x2A16DB4")]
		[Token(Token = "0x6003C3A")]
		private void method_140(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C3B RID: 15419 RVA: 0x000037DA File Offset: 0x000019DA
		[Address(RVA = "0x2A16DBC", Offset = "0x2A16DBC", VA = "0x2A16DBC")]
		[Token(Token = "0x6003C3B")]
		private void method_141(CharacterController characterController_1)
		{
			this.characterController_0 = characterController_1;
		}

		// Token: 0x06003C3C RID: 15420 RVA: 0x00075D18 File Offset: 0x00073F18
		[Address(RVA = "0x2A16DC4", Offset = "0x2A16DC4", VA = "0x2A16DC4")]
		[Token(Token = "0x6003C3C")]
		private void method_142()
		{
			Input.GetAxisRaw("monke screamed");
			Input.GetAxisRaw("Is Colliding");
			float deltaTime = Time.deltaTime;
			Vector3 forward = base.transform.forward;
			float deltaTime2 = Time.deltaTime;
			Vector3 up = Vector3.up;
			Transform transform = base.transform;
		}

		// Token: 0x06003C3D RID: 15421 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A16F1C", Offset = "0x2A16F1C", VA = "0x2A16F1C")]
		[Token(Token = "0x6003C3D")]
		private void method_143()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C3E RID: 15422 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A16F78", Offset = "0x2A16F78", VA = "0x2A16F78")]
		[Token(Token = "0x6003C3E")]
		private void method_144()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C3F RID: 15423 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A16FD4", Offset = "0x2A16FD4", VA = "0x2A16FD4")]
		[Token(Token = "0x6003C3F")]
		private CharacterController method_145()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C40 RID: 15424 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A16FDC", Offset = "0x2A16FDC", VA = "0x2A16FDC")]
		[Token(Token = "0x6003C40")]
		private void method_146()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C41 RID: 15425 RVA: 0x000037E3 File Offset: 0x000019E3
		[Address(RVA = "0x2A17038", Offset = "0x2A17038", VA = "0x2A17038")]
		[Token(Token = "0x6003C41")]
		private CharacterController method_147()
		{
			return this.characterController_0;
		}

		// Token: 0x06003C42 RID: 15426 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A17040", Offset = "0x2A17040", VA = "0x2A17040")]
		[Token(Token = "0x6003C42")]
		private void method_148()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x06003C43 RID: 15427 RVA: 0x00075280 File Offset: 0x00073480
		[Address(RVA = "0x2A1709C", Offset = "0x2A1709C", VA = "0x2A1709C")]
		[Token(Token = "0x6003C43")]
		private void method_149()
		{
			CharacterController component = base.GetComponent<CharacterController>();
			this.characterController_0 = component;
		}

		// Token: 0x04000A9A RID: 2714
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000A9A")]
		public float float_0;

		// Token: 0x04000A9B RID: 2715
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000A9B")]
		public float float_1;

		// Token: 0x04000A9C RID: 2716
		[Token(Token = "0x4000A9C")]
		[FieldOffset(Offset = "0x20")]
		[CompilerGenerated]
		private CharacterController characterController_0;
	}
}
