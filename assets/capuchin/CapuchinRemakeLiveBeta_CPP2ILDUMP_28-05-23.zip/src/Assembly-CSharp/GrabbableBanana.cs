﻿using System;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000CC RID: 204
[Token(Token = "0x20000CC")]
public class GrabbableBanana : MonoBehaviour
{
	// Token: 0x06001D21 RID: 7457 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FA2B0", Offset = "0x34FA2B0", VA = "0x34FA2B0")]
	[Token(Token = "0x6001D21")]
	public void method_0(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D22 RID: 7458 RVA: 0x00037964 File Offset: 0x00035B64
	[Address(RVA = "0x34FA5C8", Offset = "0x34FA5C8", VA = "0x34FA5C8")]
	[Token(Token = "0x6001D22")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Open");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D23 RID: 7459 RVA: 0x0003798C File Offset: 0x00035B8C
	[Address(RVA = "0x34FA648", Offset = "0x34FA648", VA = "0x34FA648")]
	[Token(Token = "0x6001D23")]
	public void method_2(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x06001D24 RID: 7460 RVA: 0x000379B8 File Offset: 0x00035BB8
	[Address(RVA = "0x34FA6F4", Offset = "0x34FA6F4", VA = "0x34FA6F4")]
	[Token(Token = "0x6001D24")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D25 RID: 7461 RVA: 0x000379E0 File Offset: 0x00035BE0
	[Address(RVA = "0x34FA774", Offset = "0x34FA774", VA = "0x34FA774")]
	[Token(Token = "0x6001D25")]
	public void method_4(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
	}

	// Token: 0x06001D26 RID: 7462 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FA7F0", Offset = "0x34FA7F0", VA = "0x34FA7F0")]
	[Token(Token = "0x6001D26")]
	public void method_5(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D27 RID: 7463 RVA: 0x000379F4 File Offset: 0x00035BF4
	[Address(RVA = "0x34FAB08", Offset = "0x34FAB08", VA = "0x34FAB08")]
	[Token(Token = "0x6001D27")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Connected to Server.");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D28 RID: 7464 RVA: 0x00037A1C File Offset: 0x00035C1C
	[Address(RVA = "0x34FAB88", Offset = "0x34FAB88", VA = "0x34FAB88")]
	[Token(Token = "0x6001D28")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_BaseColor");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D29 RID: 7465 RVA: 0x00037A44 File Offset: 0x00035C44
	[Address(RVA = "0x34FAC08", Offset = "0x34FAC08", VA = "0x34FAC08")]
	[Token(Token = "0x6001D29")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("BN");
	}

	// Token: 0x06001D2A RID: 7466 RVA: 0x00037A64 File Offset: 0x00035C64
	[Address(RVA = "0x34FAC84", Offset = "0x34FAC84", VA = "0x34FAC84")]
	[Token(Token = "0x6001D2A")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
	}

	// Token: 0x06001D2B RID: 7467 RVA: 0x00037A84 File Offset: 0x00035C84
	[Address(RVA = "0x34FAD00", Offset = "0x34FAD00", VA = "0x34FAD00")]
	[Token(Token = "0x6001D2B")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("SaveHeight");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D2C RID: 7468 RVA: 0x00037AAC File Offset: 0x00035CAC
	[Address(RVA = "0x34FAD80", Offset = "0x34FAD80", VA = "0x34FAD80")]
	[Token(Token = "0x6001D2C")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("TurnAmount");
	}

	// Token: 0x06001D2D RID: 7469 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FAE2C", Offset = "0x34FAE2C", VA = "0x34FAE2C")]
	[Token(Token = "0x6001D2D")]
	public void OnTriggerEnter(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D2E RID: 7470 RVA: 0x00037ACC File Offset: 0x00035CCC
	[Address(RVA = "0x34FB144", Offset = "0x34FB144", VA = "0x34FB144")]
	[Token(Token = "0x6001D2E")]
	public void method_12(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("_Tint");
	}

	// Token: 0x06001D2F RID: 7471 RVA: 0x00037AF8 File Offset: 0x00035CF8
	[Address(RVA = "0x34FB1F0", Offset = "0x34FB1F0", VA = "0x34FB1F0")]
	[Token(Token = "0x6001D2F")]
	public void method_13(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("TurnAmount");
	}

	// Token: 0x06001D30 RID: 7472 RVA: 0x000379B8 File Offset: 0x00035BB8
	[Address(RVA = "0x34FB29C", Offset = "0x34FB29C", VA = "0x34FB29C")]
	[Token(Token = "0x6001D30")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D31 RID: 7473 RVA: 0x00037B24 File Offset: 0x00035D24
	[Address(RVA = "0x34FB31C", Offset = "0x34FB31C", VA = "0x34FB31C")]
	[Token(Token = "0x6001D31")]
	public void method_15(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x06001D32 RID: 7474 RVA: 0x00037B50 File Offset: 0x00035D50
	[Address(RVA = "0x34FB3C8", Offset = "0x34FB3C8", VA = "0x34FB3C8")]
	[Token(Token = "0x6001D32")]
	public void method_16(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("_BaseColor");
	}

	// Token: 0x06001D33 RID: 7475 RVA: 0x00037B7C File Offset: 0x00035D7C
	[Address(RVA = "0x34FB474", Offset = "0x34FB474", VA = "0x34FB474")]
	[Token(Token = "0x6001D33")]
	public void method_17(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("Code:{0},{1},{2}\r\n Dist: {3:f0}\r\nState: {4}\r\nTolerance: {5:f0}\r\nL_Bound: {6:f0}\r\nU_Bound: {7:f0}");
	}

	// Token: 0x06001D34 RID: 7476 RVA: 0x00037BA8 File Offset: 0x00035DA8
	[Address(RVA = "0x34FB520", Offset = "0x34FB520", VA = "0x34FB520")]
	[Token(Token = "0x6001D34")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("trol");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D35 RID: 7477 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FB5A0", Offset = "0x34FB5A0", VA = "0x34FB5A0")]
	[Token(Token = "0x6001D35")]
	public void method_19(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D36 RID: 7478 RVA: 0x00037BD0 File Offset: 0x00035DD0
	[Address(RVA = "0x34FB8B8", Offset = "0x34FB8B8", VA = "0x34FB8B8")]
	[Token(Token = "0x6001D36")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D37 RID: 7479 RVA: 0x00037ACC File Offset: 0x00035CCC
	[Address(RVA = "0x34FB938", Offset = "0x34FB938", VA = "0x34FB938")]
	[Token(Token = "0x6001D37")]
	public void method_21(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("_Tint");
	}

	// Token: 0x06001D38 RID: 7480 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FB9E4", Offset = "0x34FB9E4", VA = "0x34FB9E4")]
	[Token(Token = "0x6001D38")]
	public void method_22(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D39 RID: 7481 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FBCFC", Offset = "0x34FBCFC", VA = "0x34FBCFC")]
	[Token(Token = "0x6001D39")]
	public void method_23(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D3A RID: 7482 RVA: 0x00037B24 File Offset: 0x00035D24
	[Address(RVA = "0x34FC014", Offset = "0x34FC014", VA = "0x34FC014")]
	[Token(Token = "0x6001D3A")]
	public void method_24(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x06001D3B RID: 7483 RVA: 0x00037BF8 File Offset: 0x00035DF8
	[Address(RVA = "0x34FC0C0", Offset = "0x34FC0C0", VA = "0x34FC0C0")]
	[Token(Token = "0x6001D3B")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("TurnAmount");
	}

	// Token: 0x06001D3C RID: 7484 RVA: 0x000379E0 File Offset: 0x00035BE0
	[Address(RVA = "0x34FC13C", Offset = "0x34FC13C", VA = "0x34FC13C")]
	[Token(Token = "0x6001D3C")]
	public void method_26(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
	}

	// Token: 0x06001D3D RID: 7485 RVA: 0x00037C18 File Offset: 0x00035E18
	[Address(RVA = "0x34FC1B8", Offset = "0x34FC1B8", VA = "0x34FC1B8")]
	[Token(Token = "0x6001D3D")]
	public void method_27(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("");
	}

	// Token: 0x06001D3E RID: 7486 RVA: 0x00037BD0 File Offset: 0x00035DD0
	[Address(RVA = "0x34FC264", Offset = "0x34FC264", VA = "0x34FC264")]
	[Token(Token = "0x6001D3E")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("This scene creates a combined material and meshes with adjusted UVs so objects \n can share a material and be batched by Unity's static/dynamic batching.\n Output has been set to 'bakeMeshAssetsInPlace' on the Mesh Baker\n Position, Scale and Rotation will be baked into meshes so place them appropriately.\n Dynamic batching requires objects with uniform scale. You can fix non-uniform scale here\n After baking you need to duplicate your source prefab assets and replace the  \n meshes and materials with the generated ones.\n");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D3F RID: 7487 RVA: 0x00037C44 File Offset: 0x00035E44
	[Address(RVA = "0x34FC2E4", Offset = "0x34FC2E4", VA = "0x34FC2E4")]
	[Token(Token = "0x6001D3F")]
	public void method_29(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("EnableCosmetic");
	}

	// Token: 0x06001D40 RID: 7488 RVA: 0x00037C70 File Offset: 0x00035E70
	[Address(RVA = "0x34FC390", Offset = "0x34FC390", VA = "0x34FC390")]
	[Token(Token = "0x6001D40")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("\n");
	}

	// Token: 0x06001D41 RID: 7489 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FC40C", Offset = "0x34FC40C", VA = "0x34FC40C")]
	[Token(Token = "0x6001D41")]
	public void method_31(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D42 RID: 7490 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FC724", Offset = "0x34FC724", VA = "0x34FC724")]
	[Token(Token = "0x6001D42")]
	public void method_32(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D43 RID: 7491 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FCA3C", Offset = "0x34FCA3C", VA = "0x34FCA3C")]
	[Token(Token = "0x6001D43")]
	public void method_33(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D44 RID: 7492 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x34FCD54", Offset = "0x34FCD54", VA = "0x34FCD54")]
	[Token(Token = "0x6001D44")]
	public GrabbableBanana()
	{
	}

	// Token: 0x06001D45 RID: 7493 RVA: 0x00037C90 File Offset: 0x00035E90
	[Address(RVA = "0x34FCD5C", Offset = "0x34FCD5C", VA = "0x34FCD5C")]
	[Token(Token = "0x6001D45")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("monke screamed");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D46 RID: 7494 RVA: 0x00037CB8 File Offset: 0x00035EB8
	[Address(RVA = "0x34FCDDC", Offset = "0x34FCDDC", VA = "0x34FCDDC")]
	[Token(Token = "0x6001D46")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Squeeze");
	}

	// Token: 0x06001D47 RID: 7495 RVA: 0x00037CD8 File Offset: 0x00035ED8
	[Address(RVA = "0x34FCE58", Offset = "0x34FCE58", VA = "0x34FCE58")]
	[Token(Token = "0x6001D47")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("On");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D48 RID: 7496 RVA: 0x00037D00 File Offset: 0x00035F00
	[Address(RVA = "0x34FCED8", Offset = "0x34FCED8", VA = "0x34FCED8")]
	[Token(Token = "0x6001D48")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("True");
	}

	// Token: 0x06001D49 RID: 7497 RVA: 0x00037D20 File Offset: 0x00035F20
	[Address(RVA = "0x34FCF54", Offset = "0x34FCF54", VA = "0x34FCF54")]
	[Token(Token = "0x6001D49")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PlayNoise");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D4A RID: 7498 RVA: 0x00037D48 File Offset: 0x00035F48
	[Address(RVA = "0x34FCFD4", Offset = "0x34FCFD4", VA = "0x34FCFD4")]
	[Token(Token = "0x6001D4A")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.CompareTag(" hours. You were banned because of ");
	}

	// Token: 0x06001D4B RID: 7499 RVA: 0x00037D68 File Offset: 0x00035F68
	[Address(RVA = "0x34FD050", Offset = "0x34FD050", VA = "0x34FD050")]
	[Token(Token = "0x6001D4B")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D4C RID: 7500 RVA: 0x00037D90 File Offset: 0x00035F90
	[Address(RVA = "0x34FD0D0", Offset = "0x34FD0D0", VA = "0x34FD0D0")]
	[Token(Token = "0x6001D4C")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Color");
	}

	// Token: 0x06001D4D RID: 7501 RVA: 0x00037DB0 File Offset: 0x00035FB0
	[Address(RVA = "0x34FD14C", Offset = "0x34FD14C", VA = "0x34FD14C")]
	[Token(Token = "0x6001D4D")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Joined Public Room Successfully");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D4E RID: 7502 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FD1CC", Offset = "0x34FD1CC", VA = "0x34FD1CC")]
	[Token(Token = "0x6001D4E")]
	public void method_43(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D4F RID: 7503 RVA: 0x00037DD8 File Offset: 0x00035FD8
	[Address(RVA = "0x34FD4E4", Offset = "0x34FD4E4", VA = "0x34FD4E4")]
	[Token(Token = "0x6001D4F")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("True");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D50 RID: 7504 RVA: 0x00037E00 File Offset: 0x00036000
	[Address(RVA = "0x34FD564", Offset = "0x34FD564", VA = "0x34FD564")]
	[Token(Token = "0x6001D50")]
	public void method_45(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("waited for your bullshit unity grrr");
	}

	// Token: 0x06001D51 RID: 7505 RVA: 0x00037E2C File Offset: 0x0003602C
	[Address(RVA = "0x34FD610", Offset = "0x34FD610", VA = "0x34FD610")]
	[Token(Token = "0x6001D51")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Holdable");
		this.bool_3 = ("Holdable" != null);
	}

	// Token: 0x06001D52 RID: 7506 RVA: 0x00037E58 File Offset: 0x00036058
	[Address(RVA = "0x34FD690", Offset = "0x34FD690", VA = "0x34FD690")]
	[Token(Token = "0x6001D52")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("lava");
	}

	// Token: 0x06001D53 RID: 7507 RVA: 0x00037E78 File Offset: 0x00036078
	[Address(RVA = "0x34FD70C", Offset = "0x34FD70C", VA = "0x34FD70C")]
	[Token(Token = "0x6001D53")]
	public void method_48(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("PlayerHead");
	}

	// Token: 0x06001D54 RID: 7508 RVA: 0x00037EA4 File Offset: 0x000360A4
	[Address(RVA = "0x34FD7B8", Offset = "0x34FD7B8", VA = "0x34FD7B8")]
	[Token(Token = "0x6001D54")]
	public void method_49(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		collider_0.gameObject.CompareTag("HandL");
	}

	// Token: 0x06001D55 RID: 7509 RVA: 0x00037ED0 File Offset: 0x000360D0
	[Address(RVA = "0x34FD864", Offset = "0x34FD864", VA = "0x34FD864")]
	[Token(Token = "0x6001D55")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.");
	}

	// Token: 0x06001D56 RID: 7510 RVA: 0x00037EF0 File Offset: 0x000360F0
	[Address(RVA = "0x34FD8E0", Offset = "0x34FD8E0", VA = "0x34FD8E0")]
	[Token(Token = "0x6001D56")]
	public void method_51(Collider collider_0)
	{
		InputDevices.GetDeviceAtXRNode(this.xrnode_0);
		GameObject gameObject = collider_0.gameObject;
	}

	// Token: 0x06001D57 RID: 7511 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FD98C", Offset = "0x34FD98C", VA = "0x34FD98C")]
	[Token(Token = "0x6001D57")]
	public void method_52(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D58 RID: 7512 RVA: 0x00037F10 File Offset: 0x00036110
	[Address(RVA = "0x34FDCA4", Offset = "0x34FDCA4", VA = "0x34FDCA4")]
	[Token(Token = "0x6001D58")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Start Gamemode");
	}

	// Token: 0x06001D59 RID: 7513 RVA: 0x000379B8 File Offset: 0x00035BB8
	[Address(RVA = "0x34FDD20", Offset = "0x34FDD20", VA = "0x34FDD20")]
	[Token(Token = "0x6001D59")]
	public void method_54(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D5A RID: 7514 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FDDA0", Offset = "0x34FDDA0", VA = "0x34FDDA0")]
	[Token(Token = "0x6001D5A")]
	public void method_55(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D5B RID: 7515 RVA: 0x00037F30 File Offset: 0x00036130
	[Address(RVA = "0x34FE0B8", Offset = "0x34FE0B8", VA = "0x34FE0B8")]
	[Token(Token = "0x6001D5B")]
	public void method_56(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PlayerHead");
	}

	// Token: 0x06001D5C RID: 7516 RVA: 0x00037F50 File Offset: 0x00036150
	[Address(RVA = "0x34FE134", Offset = "0x34FE134", VA = "0x34FE134")]
	[Token(Token = "0x6001D5C")]
	public void method_57(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("username");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D5D RID: 7517 RVA: 0x00037F78 File Offset: 0x00036178
	[Address(RVA = "0x34FE1B4", Offset = "0x34FE1B4", VA = "0x34FE1B4")]
	[Token(Token = "0x6001D5D")]
	public void method_58(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("username");
	}

	// Token: 0x06001D5E RID: 7518 RVA: 0x00037F98 File Offset: 0x00036198
	[Address(RVA = "0x34FE230", Offset = "0x34FE230", VA = "0x34FE230")]
	[Token(Token = "0x6001D5E")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Universal Render Pipeline/Lit");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D5F RID: 7519 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FE2B0", Offset = "0x34FE2B0", VA = "0x34FE2B0")]
	[Token(Token = "0x6001D5F")]
	public void method_60(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D60 RID: 7520 RVA: 0x00037FC0 File Offset: 0x000361C0
	[Address(RVA = "0x34FE5C8", Offset = "0x34FE5C8", VA = "0x34FE5C8")]
	[Token(Token = "0x6001D60")]
	public void method_61(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ORGPORT");
		long num = 1L;
		this.bool_3 = (num != 0L);
	}

	// Token: 0x06001D61 RID: 7521 RVA: 0x00037FE8 File Offset: 0x000361E8
	[Address(RVA = "0x34FE648", Offset = "0x34FE648", VA = "0x34FE648")]
	[Token(Token = "0x6001D61")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x06001D62 RID: 7522 RVA: 0x00038008 File Offset: 0x00036208
	[Address(RVA = "0x34FE6C4", Offset = "0x34FE6C4", VA = "0x34FE6C4")]
	[Token(Token = "0x6001D62")]
	public void method_62(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Name Changing Error. Error: ");
	}

	// Token: 0x06001D63 RID: 7523 RVA: 0x00038028 File Offset: 0x00036228
	[Address(RVA = "0x34FE744", Offset = "0x34FE744", VA = "0x34FE744")]
	[Token(Token = "0x6001D63")]
	public void method_63(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Add/Remove Glasses");
	}

	// Token: 0x06001D64 RID: 7524 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FE7C4", Offset = "0x34FE7C4", VA = "0x34FE7C4")]
	[Token(Token = "0x6001D64")]
	public void method_64(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06001D65 RID: 7525 RVA: 0x00038048 File Offset: 0x00036248
	[Address(RVA = "0x34FEADC", Offset = "0x34FEADC", VA = "0x34FEADC")]
	[Token(Token = "0x6001D65")]
	public void method_65(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Try Connect To Server...");
	}

	// Token: 0x06001D66 RID: 7526 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x34FEB58", Offset = "0x34FEB58", VA = "0x34FEB58")]
	[Token(Token = "0x6001D66")]
	public void method_66(Collider collider_0)
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x040003EB RID: 1003
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003EB")]
	public bool bool_0;

	// Token: 0x040003EC RID: 1004
	[FieldOffset(Offset = "0x19")]
	[Token(Token = "0x40003EC")]
	public bool bool_1;

	// Token: 0x040003ED RID: 1005
	[Token(Token = "0x40003ED")]
	[FieldOffset(Offset = "0x1A")]
	public bool bool_2;

	// Token: 0x040003EE RID: 1006
	[Token(Token = "0x40003EE")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_0;

	// Token: 0x040003EF RID: 1007
	[Token(Token = "0x40003EF")]
	[FieldOffset(Offset = "0x28")]
	public GameObject gameObject_1;

	// Token: 0x040003F0 RID: 1008
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40003F0")]
	public GameObject gameObject_2;

	// Token: 0x040003F1 RID: 1009
	[Token(Token = "0x40003F1")]
	[FieldOffset(Offset = "0x38")]
	public bool bool_3;

	// Token: 0x040003F2 RID: 1010
	[Token(Token = "0x40003F2")]
	[FieldOffset(Offset = "0x3C")]
	public XRNode xrnode_0;
}
