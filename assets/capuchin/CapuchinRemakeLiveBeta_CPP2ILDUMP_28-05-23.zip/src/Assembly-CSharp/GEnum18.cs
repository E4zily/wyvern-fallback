﻿using System;
using Cpp2IlInjected;

// Token: 0x02000161 RID: 353
[Token(Token = "0x2000161")]
public enum GEnum18
{
	// Token: 0x04000953 RID: 2387
	[Token(Token = "0x4000953")]
	const_0,
	// Token: 0x04000954 RID: 2388
	[Token(Token = "0x4000954")]
	const_1
}
