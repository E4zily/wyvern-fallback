﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E3 RID: 227
[Token(Token = "0x20000E3")]
public class PhotonDelete : MonoBehaviour
{
	// Token: 0x060021F5 RID: 8693 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x305335C", Offset = "0x305335C", VA = "0x305335C")]
	[Token(Token = "0x60021F5")]
	public void method_0()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021F6 RID: 8694 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053438", Offset = "0x3053438", VA = "0x3053438")]
	[Token(Token = "0x60021F6")]
	public void method_1()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021F7 RID: 8695 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053514", Offset = "0x3053514", VA = "0x3053514")]
	[Token(Token = "0x60021F7")]
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021F8 RID: 8696 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x30535E8", Offset = "0x30535E8", VA = "0x30535E8")]
	[Token(Token = "0x60021F8")]
	public void method_2()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021F9 RID: 8697 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x30536C4", Offset = "0x30536C4", VA = "0x30536C4")]
	[Token(Token = "0x60021F9")]
	public void method_3()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021FA RID: 8698 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x30537A0", Offset = "0x30537A0", VA = "0x30537A0")]
	[Token(Token = "0x60021FA")]
	public void method_4()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021FB RID: 8699 RVA: 0x0003F150 File Offset: 0x0003D350
	[Address(RVA = "0x305387C", Offset = "0x305387C", VA = "0x305387C")]
	[Token(Token = "0x60021FB")]
	public void method_5()
	{
		float deltaTime = Time.deltaTime;
		base.GetComponent<GameObject>();
	}

	// Token: 0x060021FC RID: 8700 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053958", Offset = "0x3053958", VA = "0x3053958")]
	[Token(Token = "0x60021FC")]
	public void method_6()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021FD RID: 8701 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053A34", Offset = "0x3053A34", VA = "0x3053A34")]
	[Token(Token = "0x60021FD")]
	public void method_7()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021FE RID: 8702 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053B10", Offset = "0x3053B10", VA = "0x3053B10")]
	[Token(Token = "0x60021FE")]
	public void method_8()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x060021FF RID: 8703 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053BEC", Offset = "0x3053BEC", VA = "0x3053BEC")]
	[Token(Token = "0x60021FF")]
	public void method_9()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002200 RID: 8704 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053CC8", Offset = "0x3053CC8", VA = "0x3053CC8")]
	[Token(Token = "0x6002200")]
	public void method_10()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002201 RID: 8705 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053DA4", Offset = "0x3053DA4", VA = "0x3053DA4")]
	[Token(Token = "0x6002201")]
	public void method_11()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002202 RID: 8706 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x3053E80", Offset = "0x3053E80", VA = "0x3053E80")]
	[Token(Token = "0x6002202")]
	public void method_12()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06002203 RID: 8707 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3053F5C", Offset = "0x3053F5C", VA = "0x3053F5C")]
	[Token(Token = "0x6002203")]
	public void method_13()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002204 RID: 8708 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3054038", Offset = "0x3054038", VA = "0x3054038")]
	[Token(Token = "0x6002204")]
	public void method_14()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002205 RID: 8709 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x3054114", Offset = "0x3054114", VA = "0x3054114")]
	[Token(Token = "0x6002205")]
	public void method_15()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002206 RID: 8710 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x30541F0", Offset = "0x30541F0", VA = "0x30541F0")]
	[Token(Token = "0x6002206")]
	public PhotonDelete()
	{
	}

	// Token: 0x06002207 RID: 8711 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x30541F8", Offset = "0x30541F8", VA = "0x30541F8")]
	[Token(Token = "0x6002207")]
	public void method_16()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002208 RID: 8712 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x30542D4", Offset = "0x30542D4", VA = "0x30542D4")]
	[Token(Token = "0x6002208")]
	public void method_17()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x06002209 RID: 8713 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x30543B0", Offset = "0x30543B0", VA = "0x30543B0")]
	[Token(Token = "0x6002209")]
	public void method_18()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x0600220A RID: 8714 RVA: 0x0003F12C File Offset: 0x0003D32C
	[Address(RVA = "0x305448C", Offset = "0x305448C", VA = "0x305448C")]
	[Token(Token = "0x600220A")]
	public void method_19()
	{
		float deltaTime = Time.deltaTime;
		GameObject component = base.GetComponent<GameObject>();
		this.gameObject_0 = component;
	}

	// Token: 0x04000474 RID: 1140
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000474")]
	private GameObject gameObject_0;

	// Token: 0x04000475 RID: 1141
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000475")]
	public float float_0;
}
