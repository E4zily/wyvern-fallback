﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000102 RID: 258
[Token(Token = "0x2000102")]
public class WardrobeStart : MonoBehaviour
{
	// Token: 0x06002750 RID: 10064 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F65C8", Offset = "0x20F65C8", VA = "0x20F65C8")]
	[Token(Token = "0x6002750")]
	private void method_0()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002751 RID: 10065 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F6648", Offset = "0x20F6648", VA = "0x20F6648")]
	[Token(Token = "0x6002751")]
	private void method_1()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002752 RID: 10066 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F66C8", Offset = "0x20F66C8", VA = "0x20F66C8")]
	[Token(Token = "0x6002752")]
	private void method_2()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002753 RID: 10067 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F6748", Offset = "0x20F6748", VA = "0x20F6748")]
	[Token(Token = "0x6002753")]
	private void method_3()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002754 RID: 10068 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F67C8", Offset = "0x20F67C8", VA = "0x20F67C8")]
	[Token(Token = "0x6002754")]
	private void Awake()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002755 RID: 10069 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F6848", Offset = "0x20F6848", VA = "0x20F6848")]
	[Token(Token = "0x6002755")]
	private void method_4()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002756 RID: 10070 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F68C8", Offset = "0x20F68C8", VA = "0x20F68C8")]
	[Token(Token = "0x6002756")]
	private void method_5()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002757 RID: 10071 RVA: 0x00050578 File Offset: 0x0004E778
	[Token(Token = "0x6002757")]
	[Address(RVA = "0x20F6948", Offset = "0x20F6948", VA = "0x20F6948")]
	private void method_6()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002758 RID: 10072 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F69C8", Offset = "0x20F69C8", VA = "0x20F69C8")]
	[Token(Token = "0x6002758")]
	private void method_7()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x06002759 RID: 10073 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x20F6A48", Offset = "0x20F6A48", VA = "0x20F6A48")]
	[Token(Token = "0x6002759")]
	public WardrobeStart()
	{
	}

	// Token: 0x0600275A RID: 10074 RVA: 0x00050578 File Offset: 0x0004E778
	[Address(RVA = "0x20F6A50", Offset = "0x20F6A50", VA = "0x20F6A50")]
	[Token(Token = "0x600275A")]
	private void method_8()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x0600275B RID: 10075 RVA: 0x00050578 File Offset: 0x0004E778
	[Token(Token = "0x600275B")]
	[Address(RVA = "0x20F6AD0", Offset = "0x20F6AD0", VA = "0x20F6AD0")]
	private void method_9()
	{
		GameObject gameObject = base.GetComponent<Transform>().gameObject;
		this.gameObject_0 = gameObject;
	}

	// Token: 0x040004F9 RID: 1273
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004F9")]
	private GameObject gameObject_0;
}
