﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E2 RID: 226
[Token(Token = "0x20000E2")]
public class ParentOnEnter : MonoBehaviour
{
	// Token: 0x0600219E RID: 8606 RVA: 0x0003E528 File Offset: 0x0003C728
	[Address(RVA = "0x3459920", Offset = "0x3459920", VA = "0x3459920")]
	[Token(Token = "0x600219E")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("A Player has left the Room.");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x0600219F RID: 8607 RVA: 0x0003E55C File Offset: 0x0003C75C
	[Address(RVA = "0x34599B8", Offset = "0x34599B8", VA = "0x34599B8")]
	[Token(Token = "0x600219F")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("SetColor");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021A0 RID: 8608 RVA: 0x0003E590 File Offset: 0x0003C790
	[Address(RVA = "0x3459A50", Offset = "0x3459A50", VA = "0x3459A50")]
	[Token(Token = "0x60021A0")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Charging...");
	}

	// Token: 0x060021A1 RID: 8609 RVA: 0x0003E5B0 File Offset: 0x0003C7B0
	[Address(RVA = "0x3459AE8", Offset = "0x3459AE8", VA = "0x3459AE8")]
	[Token(Token = "0x60021A1")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("amongus");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021A2 RID: 8610 RVA: 0x0003E5E4 File Offset: 0x0003C7E4
	[Address(RVA = "0x3459B80", Offset = "0x3459B80", VA = "0x3459B80")]
	[Token(Token = "0x60021A2")]
	public void method_4(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.CompareTag("Player");
	}

	// Token: 0x060021A3 RID: 8611 RVA: 0x0003E600 File Offset: 0x0003C800
	[Address(RVA = "0x3459C18", Offset = "0x3459C18", VA = "0x3459C18")]
	[Token(Token = "0x60021A3")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Grip");
	}

	// Token: 0x060021A4 RID: 8612 RVA: 0x0003E620 File Offset: 0x0003C820
	[Address(RVA = "0x3459CB0", Offset = "0x3459CB0", VA = "0x3459CB0")]
	[Token(Token = "0x60021A4")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x060021A5 RID: 8613 RVA: 0x0003E640 File Offset: 0x0003C840
	[Address(RVA = "0x3459D48", Offset = "0x3459D48", VA = "0x3459D48")]
	[Token(Token = "0x60021A5")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("TurnAmount");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021A6 RID: 8614 RVA: 0x0003E674 File Offset: 0x0003C874
	[Address(RVA = "0x3459DE0", Offset = "0x3459DE0", VA = "0x3459DE0")]
	[Token(Token = "0x60021A6")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("false");
	}

	// Token: 0x060021A7 RID: 8615 RVA: 0x0003E694 File Offset: 0x0003C894
	[Address(RVA = "0x3459E78", Offset = "0x3459E78", VA = "0x3459E78")]
	[Token(Token = "0x60021A7")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("DisableCosmetic");
	}

	// Token: 0x060021A8 RID: 8616 RVA: 0x0003E6B4 File Offset: 0x0003C8B4
	[Address(RVA = "0x3459F10", Offset = "0x3459F10", VA = "0x3459F10")]
	[Token(Token = "0x60021A8")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Diffuse");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021A9 RID: 8617 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x3459FA8", Offset = "0x3459FA8", VA = "0x3459FA8")]
	[Token(Token = "0x60021A9")]
	public ParentOnEnter()
	{
	}

	// Token: 0x060021AA RID: 8618 RVA: 0x0003E6E8 File Offset: 0x0003C8E8
	[Address(RVA = "0x3459FB0", Offset = "0x3459FB0", VA = "0x3459FB0")]
	[Token(Token = "0x60021AA")]
	public void method_10(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
		throw new MissingMethodException();
	}

	// Token: 0x060021AB RID: 8619 RVA: 0x0003E704 File Offset: 0x0003C904
	[Address(RVA = "0x345A048", Offset = "0x345A048", VA = "0x345A048")]
	[Token(Token = "0x60021AB")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Removing ");
	}

	// Token: 0x060021AC RID: 8620 RVA: 0x0003E724 File Offset: 0x0003C924
	[Address(RVA = "0x345A0E0", Offset = "0x345A0E0", VA = "0x345A0E0")]
	[Token(Token = "0x60021AC")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Starting to bake textures on frame ");
	}

	// Token: 0x060021AD RID: 8621 RVA: 0x0003E744 File Offset: 0x0003C944
	[Address(RVA = "0x345A178", Offset = "0x345A178", VA = "0x345A178")]
	[Token(Token = "0x60021AD")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("waited for your bullshit unity grrr");
	}

	// Token: 0x060021AE RID: 8622 RVA: 0x0003E764 File Offset: 0x0003C964
	[Address(RVA = "0x345A210", Offset = "0x345A210", VA = "0x345A210")]
	[Token(Token = "0x60021AE")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("isLava");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021AF RID: 8623 RVA: 0x0003E798 File Offset: 0x0003C998
	[Address(RVA = "0x345A2A8", Offset = "0x345A2A8", VA = "0x345A2A8")]
	[Token(Token = "0x60021AF")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
	}

	// Token: 0x060021B0 RID: 8624 RVA: 0x0003E7B8 File Offset: 0x0003C9B8
	[Address(RVA = "0x345A340", Offset = "0x345A340", VA = "0x345A340")]
	[Token(Token = "0x60021B0")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("StartGamemode");
	}

	// Token: 0x060021B1 RID: 8625 RVA: 0x0003E7D8 File Offset: 0x0003C9D8
	[Address(RVA = "0x345A3D8", Offset = "0x345A3D8", VA = "0x345A3D8")]
	[Token(Token = "0x60021B1")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Bruh i cannot go here you stupid L bozo");
	}

	// Token: 0x060021B2 RID: 8626 RVA: 0x0003E7F8 File Offset: 0x0003C9F8
	[Address(RVA = "0x345A470", Offset = "0x345A470", VA = "0x345A470")]
	[Token(Token = "0x60021B2")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Not connected to room");
	}

	// Token: 0x060021B3 RID: 8627 RVA: 0x0003E818 File Offset: 0x0003CA18
	[Address(RVA = "0x345A508", Offset = "0x345A508", VA = "0x345A508")]
	[Token(Token = "0x60021B3")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
	}

	// Token: 0x060021B4 RID: 8628 RVA: 0x0003E838 File Offset: 0x0003CA38
	[Address(RVA = "0x345A5A0", Offset = "0x345A5A0", VA = "0x345A5A0")]
	[Token(Token = "0x60021B4")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Date: ");
	}

	// Token: 0x060021B5 RID: 8629 RVA: 0x0003E858 File Offset: 0x0003CA58
	[Address(RVA = "0x345A638", Offset = "0x345A638", VA = "0x345A638")]
	[Token(Token = "0x60021B5")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("TurnAmount");
	}

	// Token: 0x060021B6 RID: 8630 RVA: 0x0003E878 File Offset: 0x0003CA78
	[Address(RVA = "0x345A6D0", Offset = "0x345A6D0", VA = "0x345A6D0")]
	[Token(Token = "0x60021B6")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("HandL");
	}

	// Token: 0x060021B7 RID: 8631 RVA: 0x0003E898 File Offset: 0x0003CA98
	[Address(RVA = "0x345A768", Offset = "0x345A768", VA = "0x345A768")]
	[Token(Token = "0x60021B7")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("A new Player joined a Room.");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021B8 RID: 8632 RVA: 0x0003E8CC File Offset: 0x0003CACC
	[Address(RVA = "0x345A800", Offset = "0x345A800", VA = "0x345A800")]
	[Token(Token = "0x60021B8")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ChangeToRegular");
	}

	// Token: 0x060021B9 RID: 8633 RVA: 0x0003E8EC File Offset: 0x0003CAEC
	[Address(RVA = "0x345A898", Offset = "0x345A898", VA = "0x345A898")]
	[Token(Token = "0x60021B9")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Thumb");
	}

	// Token: 0x060021BA RID: 8634 RVA: 0x0003E90C File Offset: 0x0003CB0C
	[Address(RVA = "0x345A930", Offset = "0x345A930", VA = "0x345A930")]
	[Token(Token = "0x60021BA")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Skelechin");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021BB RID: 8635 RVA: 0x0003E940 File Offset: 0x0003CB40
	[Address(RVA = "0x345A9C8", Offset = "0x345A9C8", VA = "0x345A9C8")]
	[Token(Token = "0x60021BB")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("FingerTip");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021BC RID: 8636 RVA: 0x0003E974 File Offset: 0x0003CB74
	[Address(RVA = "0x345AA60", Offset = "0x345AA60", VA = "0x345AA60")]
	[Token(Token = "0x60021BC")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Vector1_d371bd24217449349bd747533d51af6b");
	}

	// Token: 0x060021BD RID: 8637 RVA: 0x0003E798 File Offset: 0x0003C998
	[Address(RVA = "0x345AAF8", Offset = "0x345AAF8", VA = "0x345AAF8")]
	[Token(Token = "0x60021BD")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
	}

	// Token: 0x060021BE RID: 8638 RVA: 0x0003E994 File Offset: 0x0003CB94
	[Address(RVA = "0x345AB90", Offset = "0x345AB90", VA = "0x345AB90")]
	[Token(Token = "0x60021BE")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("HorrorAgreement");
	}

	// Token: 0x060021BF RID: 8639 RVA: 0x0003E9B4 File Offset: 0x0003CBB4
	[Address(RVA = "0x345AC28", Offset = "0x345AC28", VA = "0x345AC28")]
	[Token(Token = "0x60021BF")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PlayerHead");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021C0 RID: 8640 RVA: 0x0003E9E8 File Offset: 0x0003CBE8
	[Address(RVA = "0x345ACC0", Offset = "0x345ACC0", VA = "0x345ACC0")]
	[Token(Token = "0x60021C0")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Not connected to room");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021C1 RID: 8641 RVA: 0x0003EA1C File Offset: 0x0003CC1C
	[Address(RVA = "0x345AD58", Offset = "0x345AD58", VA = "0x345AD58")]
	[Token(Token = "0x60021C1")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Target");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021C2 RID: 8642 RVA: 0x0003EA50 File Offset: 0x0003CC50
	[Address(RVA = "0x345ADF0", Offset = "0x345ADF0", VA = "0x345ADF0")]
	[Token(Token = "0x60021C2")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021C3 RID: 8643 RVA: 0x0003EA84 File Offset: 0x0003CC84
	[Address(RVA = "0x345AE88", Offset = "0x345AE88", VA = "0x345AE88")]
	[Token(Token = "0x60021C3")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("BN");
	}

	// Token: 0x060021C4 RID: 8644 RVA: 0x0003EAA4 File Offset: 0x0003CCA4
	[Address(RVA = "0x345AF20", Offset = "0x345AF20", VA = "0x345AF20")]
	[Token(Token = "0x60021C4")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("got funky mone");
	}

	// Token: 0x060021C5 RID: 8645 RVA: 0x0003EAC4 File Offset: 0x0003CCC4
	[Address(RVA = "0x345AFB8", Offset = "0x345AFB8", VA = "0x345AFB8")]
	[Token(Token = "0x60021C5")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_WobbleX");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021C6 RID: 8646 RVA: 0x0003EAF8 File Offset: 0x0003CCF8
	[Address(RVA = "0x345B050", Offset = "0x345B050", VA = "0x345B050")]
	[Token(Token = "0x60021C6")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Calling success callback. baking meshes");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021C7 RID: 8647 RVA: 0x0003EB2C File Offset: 0x0003CD2C
	[Token(Token = "0x60021C7")]
	[Address(RVA = "0x345B0E8", Offset = "0x345B0E8", VA = "0x345B0E8")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021C8 RID: 8648 RVA: 0x0003EB60 File Offset: 0x0003CD60
	[Address(RVA = "0x345B180", Offset = "0x345B180", VA = "0x345B180")]
	[Token(Token = "0x60021C8")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("ORGPORT");
	}

	// Token: 0x060021C9 RID: 8649 RVA: 0x0003EB80 File Offset: 0x0003CD80
	[Address(RVA = "0x345B218", Offset = "0x345B218", VA = "0x345B218")]
	[Token(Token = "0x60021C9")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("jump char false");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021CA RID: 8650 RVA: 0x0003EBB4 File Offset: 0x0003CDB4
	[Address(RVA = "0x345B2B0", Offset = "0x345B2B0", VA = "0x345B2B0")]
	[Token(Token = "0x60021CA")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("goUpRPC");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021CB RID: 8651 RVA: 0x0003EAA4 File Offset: 0x0003CCA4
	[Address(RVA = "0x345B348", Offset = "0x345B348", VA = "0x345B348")]
	[Token(Token = "0x60021CB")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("got funky mone");
	}

	// Token: 0x060021CC RID: 8652 RVA: 0x0003EBE8 File Offset: 0x0003CDE8
	[Token(Token = "0x60021CC")]
	[Address(RVA = "0x345B3E0", Offset = "0x345B3E0", VA = "0x345B3E0")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("true");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021CD RID: 8653 RVA: 0x0003EB2C File Offset: 0x0003CD2C
	[Address(RVA = "0x345B478", Offset = "0x345B478", VA = "0x345B478")]
	[Token(Token = "0x60021CD")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021CE RID: 8654 RVA: 0x0003EC1C File Offset: 0x0003CE1C
	[Address(RVA = "0x345B510", Offset = "0x345B510", VA = "0x345B510")]
	[Token(Token = "0x60021CE")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Collided");
	}

	// Token: 0x060021CF RID: 8655 RVA: 0x0003EC3C File Offset: 0x0003CE3C
	[Address(RVA = "0x345B5A8", Offset = "0x345B5A8", VA = "0x345B5A8")]
	[Token(Token = "0x60021CF")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("procedural animation script required on ");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021D0 RID: 8656 RVA: 0x0003EC70 File Offset: 0x0003CE70
	[Address(RVA = "0x345B640", Offset = "0x345B640", VA = "0x345B640")]
	[Token(Token = "0x60021D0")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player was caught cheating");
	}

	// Token: 0x060021D1 RID: 8657 RVA: 0x0003EC90 File Offset: 0x0003CE90
	[Address(RVA = "0x345B6D8", Offset = "0x345B6D8", VA = "0x345B6D8")]
	[Token(Token = "0x60021D1")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("_Tint");
	}

	// Token: 0x060021D2 RID: 8658 RVA: 0x0003E55C File Offset: 0x0003C75C
	[Address(RVA = "0x345B770", Offset = "0x345B770", VA = "0x345B770")]
	[Token(Token = "0x60021D2")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("SetColor");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021D3 RID: 8659 RVA: 0x0003ECB0 File Offset: 0x0003CEB0
	[Address(RVA = "0x345B808", Offset = "0x345B808", VA = "0x345B808")]
	[Token(Token = "0x60021D3")]
	public void method_51(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("isLava");
	}

	// Token: 0x060021D4 RID: 8660 RVA: 0x0003ECD0 File Offset: 0x0003CED0
	[Address(RVA = "0x345B8A0", Offset = "0x345B8A0", VA = "0x345B8A0")]
	[Token(Token = "0x60021D4")]
	public void method_52(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("PURCHASED");
	}

	// Token: 0x060021D5 RID: 8661 RVA: 0x0003ECF0 File Offset: 0x0003CEF0
	[Address(RVA = "0x345B938", Offset = "0x345B938", VA = "0x345B938")]
	[Token(Token = "0x60021D5")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Stopped Colliding");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021D6 RID: 8662 RVA: 0x0003ED24 File Offset: 0x0003CF24
	[Address(RVA = "0x345B9D0", Offset = "0x345B9D0", VA = "0x345B9D0")]
	[Token(Token = "0x60021D6")]
	public void method_54(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("down unstuck");
	}

	// Token: 0x060021D7 RID: 8663 RVA: 0x0003E798 File Offset: 0x0003C998
	[Address(RVA = "0x345BA68", Offset = "0x345BA68", VA = "0x345BA68")]
	[Token(Token = "0x60021D7")]
	public void method_55(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("EnableCosmetic");
	}

	// Token: 0x060021D8 RID: 8664 RVA: 0x0003ED44 File Offset: 0x0003CF44
	[Address(RVA = "0x345BB00", Offset = "0x345BB00", VA = "0x345BB00")]
	[Token(Token = "0x60021D8")]
	public void method_56(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("We don't need this electrical box");
	}

	// Token: 0x060021D9 RID: 8665 RVA: 0x0003ED64 File Offset: 0x0003CF64
	[Address(RVA = "0x345BB98", Offset = "0x345BB98", VA = "0x345BB98")]
	[Token(Token = "0x60021D9")]
	public void method_57(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("unlocked!");
	}

	// Token: 0x060021DA RID: 8666 RVA: 0x0003ED84 File Offset: 0x0003CF84
	[Address(RVA = "0x345BC30", Offset = "0x345BC30", VA = "0x345BC30")]
	[Token(Token = "0x60021DA")]
	public void method_58(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.CompareTag("Updating Material to: ");
	}

	// Token: 0x060021DB RID: 8667 RVA: 0x0003EDA0 File Offset: 0x0003CFA0
	[Address(RVA = "0x345BCC8", Offset = "0x345BCC8", VA = "0x345BCC8")]
	[Token(Token = "0x60021DB")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Add/Remove Sword");
	}

	// Token: 0x060021DC RID: 8668 RVA: 0x0003EDC0 File Offset: 0x0003CFC0
	[Address(RVA = "0x345BD60", Offset = "0x345BD60", VA = "0x345BD60")]
	[Token(Token = "0x60021DC")]
	public void method_60(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("You are not the master of the server, you cannot start the game.");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021DD RID: 8669 RVA: 0x0003EDF4 File Offset: 0x0003CFF4
	[Address(RVA = "0x345BDF8", Offset = "0x345BDF8", VA = "0x345BDF8")]
	[Token(Token = "0x60021DD")]
	public void method_61(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Purchased: ");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021DE RID: 8670 RVA: 0x0003EE28 File Offset: 0x0003D028
	[Address(RVA = "0x345BE90", Offset = "0x345BE90", VA = "0x345BE90")]
	[Token(Token = "0x60021DE")]
	public void method_62(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("/");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021DF RID: 8671 RVA: 0x0003EE5C File Offset: 0x0003D05C
	[Address(RVA = "0x345BF28", Offset = "0x345BF28", VA = "0x345BF28")]
	[Token(Token = "0x60021DF")]
	public void method_63(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("clickLol");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021E0 RID: 8672 RVA: 0x0003EE90 File Offset: 0x0003D090
	[Address(RVA = "0x345BFC0", Offset = "0x345BFC0", VA = "0x345BFC0")]
	[Token(Token = "0x60021E0")]
	public void method_64(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Try Connect To Server...");
	}

	// Token: 0x060021E1 RID: 8673 RVA: 0x0003EEB0 File Offset: 0x0003D0B0
	[Address(RVA = "0x345C058", Offset = "0x345C058", VA = "0x345C058")]
	[Token(Token = "0x60021E1")]
	public void method_65(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("gamemode");
	}

	// Token: 0x060021E2 RID: 8674 RVA: 0x0003EED0 File Offset: 0x0003D0D0
	[Address(RVA = "0x345C0F0", Offset = "0x345C0F0", VA = "0x345C0F0")]
	[Token(Token = "0x60021E2")]
	public void method_66(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021E3 RID: 8675 RVA: 0x0003EF04 File Offset: 0x0003D104
	[Address(RVA = "0x345C188", Offset = "0x345C188", VA = "0x345C188")]
	[Token(Token = "0x60021E3")]
	public void method_67(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.CompareTag("Regular");
	}

	// Token: 0x060021E4 RID: 8676 RVA: 0x0003EF20 File Offset: 0x0003D120
	[Address(RVA = "0x345C220", Offset = "0x345C220", VA = "0x345C220")]
	[Token(Token = "0x60021E4")]
	public void method_68(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("hh:mmtt");
	}

	// Token: 0x060021E5 RID: 8677 RVA: 0x0003EF40 File Offset: 0x0003D140
	[Address(RVA = "0x345C2B8", Offset = "0x345C2B8", VA = "0x345C2B8")]
	[Token(Token = "0x60021E5")]
	public void method_69(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("down unstuck");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021E6 RID: 8678 RVA: 0x0003EF74 File Offset: 0x0003D174
	[Address(RVA = "0x345C350", Offset = "0x345C350", VA = "0x345C350")]
	[Token(Token = "0x60021E6")]
	public void method_70(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("");
	}

	// Token: 0x060021E7 RID: 8679 RVA: 0x0003EB2C File Offset: 0x0003CD2C
	[Address(RVA = "0x345C3E8", Offset = "0x345C3E8", VA = "0x345C3E8")]
	[Token(Token = "0x60021E7")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021E8 RID: 8680 RVA: 0x0003EF94 File Offset: 0x0003D194
	[Address(RVA = "0x345C480", Offset = "0x345C480", VA = "0x345C480")]
	[Token(Token = "0x60021E8")]
	public void method_71(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("procedural animation script required on ");
	}

	// Token: 0x060021E9 RID: 8681 RVA: 0x0003EFB4 File Offset: 0x0003D1B4
	[Address(RVA = "0x345C518", Offset = "0x345C518", VA = "0x345C518")]
	[Token(Token = "0x60021E9")]
	public void method_72(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Not enough amount of currency");
	}

	// Token: 0x060021EA RID: 8682 RVA: 0x0003EFD4 File Offset: 0x0003D1D4
	[Address(RVA = "0x345C5B0", Offset = "0x345C5B0", VA = "0x345C5B0")]
	[Token(Token = "0x60021EA")]
	public void method_73(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("character limit reached");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021EB RID: 8683 RVA: 0x0003F008 File Offset: 0x0003D208
	[Address(RVA = "0x345C648", Offset = "0x345C648", VA = "0x345C648")]
	[Token(Token = "0x60021EB")]
	public void method_74(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CapuchinStore");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021EC RID: 8684 RVA: 0x0003F03C File Offset: 0x0003D23C
	[Address(RVA = "0x345C6E0", Offset = "0x345C6E0", VA = "0x345C6E0")]
	[Token(Token = "0x60021EC")]
	public void method_75(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Collided");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021ED RID: 8685 RVA: 0x0003F070 File Offset: 0x0003D270
	[Address(RVA = "0x345C778", Offset = "0x345C778", VA = "0x345C778")]
	[Token(Token = "0x60021ED")]
	public void method_76(Collider collider_0)
	{
		GameObject gameObject = collider_0.gameObject;
	}

	// Token: 0x060021EE RID: 8686 RVA: 0x0003E620 File Offset: 0x0003C820
	[Address(RVA = "0x345C810", Offset = "0x345C810", VA = "0x345C810")]
	[Token(Token = "0x60021EE")]
	public void method_77(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Player");
	}

	// Token: 0x060021EF RID: 8687 RVA: 0x0003F084 File Offset: 0x0003D284
	[Address(RVA = "0x345C8A8", Offset = "0x345C8A8", VA = "0x345C8A8")]
	[Token(Token = "0x60021EF")]
	public void method_78(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Done");
	}

	// Token: 0x060021F0 RID: 8688 RVA: 0x0003F0A4 File Offset: 0x0003D2A4
	[Address(RVA = "0x345C940", Offset = "0x345C940", VA = "0x345C940")]
	[Token(Token = "0x60021F0")]
	public void method_79(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("On");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021F1 RID: 8689 RVA: 0x0003EBE8 File Offset: 0x0003CDE8
	[Address(RVA = "0x345C9D8", Offset = "0x345C9D8", VA = "0x345C9D8")]
	[Token(Token = "0x60021F1")]
	public void method_80(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("true");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021F2 RID: 8690 RVA: 0x0003EED0 File Offset: 0x0003D0D0
	[Address(RVA = "0x345CA70", Offset = "0x345CA70", VA = "0x345CA70")]
	[Token(Token = "0x60021F2")]
	public void method_81(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021F3 RID: 8691 RVA: 0x0003F0D8 File Offset: 0x0003D2D8
	[Address(RVA = "0x345CB08", Offset = "0x345CB08", VA = "0x345CB08")]
	[Token(Token = "0x60021F3")]
	public void method_82(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("CASUAL");
		Transform transform = this.transform_0;
		Transform parent = this.transform_1;
		transform.parent = parent;
	}

	// Token: 0x060021F4 RID: 8692 RVA: 0x0003F10C File Offset: 0x0003D30C
	[Address(RVA = "0x345CBA0", Offset = "0x345CBA0", VA = "0x345CBA0")]
	[Token(Token = "0x60021F4")]
	public void method_83(Collider collider_0)
	{
		collider_0.gameObject.CompareTag("n0");
	}

	// Token: 0x04000472 RID: 1138
	[Token(Token = "0x4000472")]
	[FieldOffset(Offset = "0x18")]
	public Transform transform_0;

	// Token: 0x04000473 RID: 1139
	[Token(Token = "0x4000473")]
	[FieldOffset(Offset = "0x20")]
	public Transform transform_1;
}
