﻿using System;
using System.Collections;
using Cpp2IlInjected;
using TMPro;
using UnityEngine;
using UnityEngine.Video;

// Token: 0x020000FA RID: 250
[Token(Token = "0x20000FA")]
public class TVManager : MonoBehaviour
{
	// Token: 0x060025A6 RID: 9638 RVA: 0x00046504 File Offset: 0x00044704
	[Address(RVA = "0x308EAFC", Offset = "0x308EAFC", VA = "0x308EAFC")]
	[Token(Token = "0x60025A6")]
	public void method_0()
	{
		IEnumerator routine = this.method_67();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025A7 RID: 9639 RVA: 0x00046520 File Offset: 0x00044720
	[Address(RVA = "0x308EBA0", Offset = "0x308EBA0", VA = "0x308EBA0")]
	[Token(Token = "0x60025A7")]
	public void method_1()
	{
		IEnumerator routine = this.method_19();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025A8 RID: 9640 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x308EC44", Offset = "0x308EC44", VA = "0x308EC44")]
	[Token(Token = "0x60025A8")]
	public IEnumerator method_2()
	{
		throw new NullReferenceException();
	}

	// Token: 0x060025A9 RID: 9641 RVA: 0x0004653C File Offset: 0x0004473C
	[Address(RVA = "0x308ECBC", Offset = "0x308ECBC", VA = "0x308ECBC")]
	[Token(Token = "0x60025A9")]
	public void method_3()
	{
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025AA RID: 9642 RVA: 0x00046558 File Offset: 0x00044758
	[Address(RVA = "0x308ED60", Offset = "0x308ED60", VA = "0x308ED60")]
	[Token(Token = "0x60025AA")]
	public void method_4()
	{
		IEnumerator routine = this.method_57();
		base.StartCoroutine(routine);
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025AB RID: 9643 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308EFB4", Offset = "0x308EFB4", VA = "0x308EFB4")]
	[Token(Token = "0x60025AB")]
	public IEnumerator method_5()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025AC RID: 9644 RVA: 0x0004660C File Offset: 0x0004480C
	[Address(RVA = "0x308F02C", Offset = "0x308F02C", VA = "0x308F02C")]
	[Token(Token = "0x60025AC")]
	public void method_6()
	{
		IEnumerator routine = this.method_5();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025AD RID: 9645 RVA: 0x00046628 File Offset: 0x00044828
	[Address(RVA = "0x308F058", Offset = "0x308F058", VA = "0x308F058")]
	[Token(Token = "0x60025AD")]
	public void method_7()
	{
		IEnumerator routine = this.method_57();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025AE RID: 9646 RVA: 0x00046644 File Offset: 0x00044844
	[Address(RVA = "0x308F084", Offset = "0x308F084", VA = "0x308F084")]
	[Token(Token = "0x60025AE")]
	public void method_8()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025AF RID: 9647 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308F128", Offset = "0x308F128", VA = "0x308F128")]
	[Token(Token = "0x60025AF")]
	public IEnumerator method_9()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025B0 RID: 9648 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308F1A0", Offset = "0x308F1A0", VA = "0x308F1A0")]
	[Token(Token = "0x60025B0")]
	public IEnumerator method_10()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025B1 RID: 9649 RVA: 0x00046660 File Offset: 0x00044860
	[Address(RVA = "0x308F218", Offset = "0x308F218", VA = "0x308F218")]
	[Token(Token = "0x60025B1")]
	public void method_11()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_43();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		num2.ToString();
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025B2 RID: 9650 RVA: 0x000466F4 File Offset: 0x000448F4
	[Address(RVA = "0x308F3F8", Offset = "0x308F3F8", VA = "0x308F3F8")]
	[Token(Token = "0x60025B2")]
	public void method_12()
	{
		IEnumerator routine = this.method_52();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025B3 RID: 9651 RVA: 0x00046710 File Offset: 0x00044910
	[Address(RVA = "0x308F49C", Offset = "0x308F49C", VA = "0x308F49C")]
	[Token(Token = "0x60025B3")]
	public void method_13()
	{
		IEnumerator routine = this.method_10();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025B4 RID: 9652 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308F4C8", Offset = "0x308F4C8", VA = "0x308F4C8")]
	[Token(Token = "0x60025B4")]
	public IEnumerator method_14()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025B5 RID: 9653 RVA: 0x00046644 File Offset: 0x00044844
	[Address(RVA = "0x308F540", Offset = "0x308F540", VA = "0x308F540")]
	[Token(Token = "0x60025B5")]
	public void Start()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025B6 RID: 9654 RVA: 0x0004672C File Offset: 0x0004492C
	[Address(RVA = "0x308F56C", Offset = "0x308F56C", VA = "0x308F56C")]
	[Token(Token = "0x60025B6")]
	public void method_15()
	{
		this.method_9();
	}

	// Token: 0x060025B7 RID: 9655 RVA: 0x0004660C File Offset: 0x0004480C
	[Address(RVA = "0x308F598", Offset = "0x308F598", VA = "0x308F598")]
	[Token(Token = "0x60025B7")]
	public void method_16()
	{
		IEnumerator routine = this.method_5();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025B8 RID: 9656 RVA: 0x00046740 File Offset: 0x00044940
	[Address(RVA = "0x308F5C4", Offset = "0x308F5C4", VA = "0x308F5C4")]
	[Token(Token = "0x60025B8")]
	public void method_17()
	{
		IEnumerator routine = this.method_9();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025B9 RID: 9657 RVA: 0x0004675C File Offset: 0x0004495C
	[Token(Token = "0x60025B9")]
	[Address(RVA = "0x308F5F0", Offset = "0x308F5F0", VA = "0x308F5F0")]
	public void method_18()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_68();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		string str;
		Mathf.RoundToInt((float)f2).ToString() + "typesOfTalk" + str;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		VideoClip clip = this.videoClip_1;
		videoPlayer.clip = clip;
	}

	// Token: 0x060025BA RID: 9658 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025BA")]
	[Address(RVA = "0x308EBCC", Offset = "0x308EBCC", VA = "0x308EBCC")]
	public IEnumerator method_19()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025BB RID: 9659 RVA: 0x000467D4 File Offset: 0x000449D4
	[Address(RVA = "0x308F848", Offset = "0x308F848", VA = "0x308F848")]
	[Token(Token = "0x60025BB")]
	public void method_20()
	{
		if (this.bool_1)
		{
			IEnumerator routine;
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + " hours. You were banned because of " + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025BC RID: 9660 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025BC")]
	[Address(RVA = "0x308F9B0", Offset = "0x308F9B0", VA = "0x308F9B0")]
	public IEnumerator method_21()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025BD RID: 9661 RVA: 0x0004686C File Offset: 0x00044A6C
	[Address(RVA = "0x308FA28", Offset = "0x308FA28", VA = "0x308FA28")]
	[Token(Token = "0x60025BD")]
	public void method_22()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_28();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + "Start Gamemode" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025BE RID: 9662 RVA: 0x0004690C File Offset: 0x00044B0C
	[Address(RVA = "0x308FC08", Offset = "0x308FC08", VA = "0x308FC08")]
	[Token(Token = "0x60025BE")]
	public void method_23()
	{
		IEnumerator routine = this.method_54();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025BF RID: 9663 RVA: 0x00046928 File Offset: 0x00044B28
	[Address(RVA = "0x308FCAC", Offset = "0x308FCAC", VA = "0x308FCAC")]
	[Token(Token = "0x60025BF")]
	public void method_24()
	{
		IEnumerator routine = this.method_41();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025C0 RID: 9664 RVA: 0x00046944 File Offset: 0x00044B44
	[Token(Token = "0x60025C0")]
	[Address(RVA = "0x308FD50", Offset = "0x308FD50", VA = "0x308FD50")]
	public void method_25()
	{
		IEnumerator routine = this.method_27();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025C1 RID: 9665 RVA: 0x0004660C File Offset: 0x0004480C
	[Address(RVA = "0x308FDF4", Offset = "0x308FDF4", VA = "0x308FDF4")]
	[Token(Token = "0x60025C1")]
	public void method_26()
	{
		IEnumerator routine = this.method_5();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025C2 RID: 9666 RVA: 0x00046960 File Offset: 0x00044B60
	[Address(RVA = "0x308FD7C", Offset = "0x308FD7C", VA = "0x308FD7C")]
	[Token(Token = "0x60025C2")]
	public IEnumerator method_27()
	{
		new TVManager.Class35((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060025C3 RID: 9667 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025C3")]
	[Address(RVA = "0x308FB90", Offset = "0x308FB90", VA = "0x308FB90")]
	public IEnumerator method_28()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025C4 RID: 9668 RVA: 0x00046960 File Offset: 0x00044B60
	[Token(Token = "0x60025C4")]
	[Address(RVA = "0x308ECE8", Offset = "0x308ECE8", VA = "0x308ECE8")]
	public IEnumerator method_29()
	{
		new TVManager.Class35((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060025C5 RID: 9669 RVA: 0x00046628 File Offset: 0x00044828
	[Address(RVA = "0x308FE20", Offset = "0x308FE20", VA = "0x308FE20")]
	[Token(Token = "0x60025C5")]
	public void method_30()
	{
		IEnumerator routine = this.method_57();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025C6 RID: 9670 RVA: 0x00046960 File Offset: 0x00044B60
	[Token(Token = "0x60025C6")]
	[Address(RVA = "0x308FE4C", Offset = "0x308FE4C", VA = "0x308FE4C")]
	public IEnumerator method_31()
	{
		new TVManager.Class35((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060025C7 RID: 9671 RVA: 0x00046984 File Offset: 0x00044B84
	[Token(Token = "0x60025C7")]
	[Address(RVA = "0x308FEC4", Offset = "0x308FEC4", VA = "0x308FEC4")]
	public void method_32()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_56();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "You Look Like Butt" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025C8 RID: 9672 RVA: 0x00046928 File Offset: 0x00044B28
	[Token(Token = "0x60025C8")]
	[Address(RVA = "0x30900A0", Offset = "0x30900A0", VA = "0x30900A0")]
	public void method_33()
	{
		IEnumerator routine = this.method_41();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025C9 RID: 9673 RVA: 0x00046504 File Offset: 0x00044704
	[Token(Token = "0x60025C9")]
	[Address(RVA = "0x30900CC", Offset = "0x30900CC", VA = "0x30900CC")]
	public void method_34()
	{
		IEnumerator routine = this.method_67();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025CA RID: 9674 RVA: 0x00046A18 File Offset: 0x00044C18
	[Address(RVA = "0x30900F8", Offset = "0x30900F8", VA = "0x30900F8")]
	[Token(Token = "0x60025CA")]
	public void method_35()
	{
		IEnumerator routine = this.method_58();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025CB RID: 9675 RVA: 0x00046A34 File Offset: 0x00044C34
	[Address(RVA = "0x3090124", Offset = "0x3090124", VA = "0x3090124")]
	[Token(Token = "0x60025CB")]
	public void method_36()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_40();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		int num2 = Mathf.RoundToInt((float)f);
		string str;
		num2.ToString() + "DISABLE" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025CC RID: 9676 RVA: 0x00046AC8 File Offset: 0x00044CC8
	[Address(RVA = "0x3090304", Offset = "0x3090304", VA = "0x3090304")]
	[Token(Token = "0x60025CC")]
	public void method_37()
	{
		if (this.bool_1)
		{
			this.method_40();
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + "Player" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025CD RID: 9677 RVA: 0x00046B60 File Offset: 0x00044D60
	[Token(Token = "0x60025CD")]
	[Address(RVA = "0x30904E4", Offset = "0x30904E4", VA = "0x30904E4")]
	public void method_38()
	{
		string str;
		0.ToString() + "NGNNoSound" + str;
	}

	// Token: 0x060025CE RID: 9678 RVA: 0x00046B80 File Offset: 0x00044D80
	[Address(RVA = "0x30906C4", Offset = "0x30906C4", VA = "0x30906C4")]
	[Token(Token = "0x60025CE")]
	public void method_39()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_41();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		num.ToString();
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025CF RID: 9679 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x309028C", Offset = "0x309028C", VA = "0x309028C")]
	[Token(Token = "0x60025CF")]
	public IEnumerator method_40()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025D0 RID: 9680 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025D0")]
	[Address(RVA = "0x308FCD8", Offset = "0x308FCD8", VA = "0x308FCD8")]
	public IEnumerator method_41()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025D1 RID: 9681 RVA: 0x00046C08 File Offset: 0x00044E08
	[Token(Token = "0x60025D1")]
	[Address(RVA = "0x3090828", Offset = "0x3090828", VA = "0x3090828")]
	public void method_42()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_40();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "liftoff failed!" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025D2 RID: 9682 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308F0B0", Offset = "0x308F0B0", VA = "0x308F0B0")]
	[Token(Token = "0x60025D2")]
	public IEnumerator method_43()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025D3 RID: 9683 RVA: 0x00046928 File Offset: 0x00044B28
	[Token(Token = "0x60025D3")]
	[Address(RVA = "0x3090A04", Offset = "0x3090A04", VA = "0x3090A04")]
	public void method_44()
	{
		IEnumerator routine = this.method_41();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025D4 RID: 9684 RVA: 0x00046C9C File Offset: 0x00044E9C
	[Token(Token = "0x60025D4")]
	[Address(RVA = "0x3090A30", Offset = "0x3090A30", VA = "0x3090A30")]
	public void method_45()
	{
		IEnumerator routine = this.method_2();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025D5 RID: 9685 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x3090A5C", Offset = "0x3090A5C", VA = "0x3090A5C")]
	[Token(Token = "0x60025D5")]
	public IEnumerator method_46()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025D6 RID: 9686 RVA: 0x00046CB8 File Offset: 0x00044EB8
	[Token(Token = "0x60025D6")]
	[Address(RVA = "0x3090AD4", Offset = "0x3090AD4", VA = "0x3090AD4")]
	public void method_47()
	{
		this.method_76();
	}

	// Token: 0x060025D7 RID: 9687 RVA: 0x00046CCC File Offset: 0x00044ECC
	[Address(RVA = "0x3090B00", Offset = "0x3090B00", VA = "0x3090B00")]
	[Token(Token = "0x60025D7")]
	public void method_48()
	{
		IEnumerator routine = this.method_81();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025D8 RID: 9688 RVA: 0x00046644 File Offset: 0x00044844
	[Address(RVA = "0x3090B2C", Offset = "0x3090B2C", VA = "0x3090B2C")]
	[Token(Token = "0x60025D8")]
	public void method_49()
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025D9 RID: 9689 RVA: 0x00046CE8 File Offset: 0x00044EE8
	[Address(RVA = "0x3090B58", Offset = "0x3090B58", VA = "0x3090B58")]
	[Token(Token = "0x60025D9")]
	public void method_50()
	{
		this.method_46();
	}

	// Token: 0x060025DA RID: 9690 RVA: 0x00046CFC File Offset: 0x00044EFC
	[Token(Token = "0x60025DA")]
	[Address(RVA = "0x3090B84", Offset = "0x3090B84", VA = "0x3090B84")]
	public void method_51()
	{
		IEnumerator routine = this.method_60();
		base.StartCoroutine(routine);
		long num = 1L;
		this.bool_1 = (num != 0L);
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + ".Please press the button if you would like to play alone" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025DB RID: 9691 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025DB")]
	[Address(RVA = "0x308F424", Offset = "0x308F424", VA = "0x308F424")]
	public IEnumerator method_52()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025DC RID: 9692 RVA: 0x00046D94 File Offset: 0x00044F94
	[Token(Token = "0x60025DC")]
	[Address(RVA = "0x3090D64", Offset = "0x3090D64", VA = "0x3090D64")]
	public void method_53()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_60();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "EnableCosmetic" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025DD RID: 9693 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308FC34", Offset = "0x308FC34", VA = "0x308FC34")]
	[Token(Token = "0x60025DD")]
	public IEnumerator method_54()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025DE RID: 9694 RVA: 0x00046E28 File Offset: 0x00045028
	[Token(Token = "0x60025DE")]
	[Address(RVA = "0x3090EC8", Offset = "0x3090EC8", VA = "0x3090EC8")]
	public void method_55()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_79();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "Tagged" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025DF RID: 9695 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025DF")]
	[Address(RVA = "0x308F380", Offset = "0x308F380", VA = "0x308F380")]
	public IEnumerator method_56()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025E0 RID: 9696 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025E0")]
	[Address(RVA = "0x308EEC4", Offset = "0x308EEC4", VA = "0x308EEC4")]
	public IEnumerator method_57()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025E1 RID: 9697 RVA: 0x00046EBC File Offset: 0x000450BC
	[Address(RVA = "0x308F7D0", Offset = "0x308F7D0", VA = "0x308F7D0")]
	[Token(Token = "0x60025E1")]
	public IEnumerator method_58()
	{
		TVManager.Class35 @class;
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025E2 RID: 9698 RVA: 0x00046ED8 File Offset: 0x000450D8
	[Token(Token = "0x60025E2")]
	[Address(RVA = "0x309102C", Offset = "0x309102C", VA = "0x309102C")]
	public void method_59()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_40();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + "Target" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025E3 RID: 9699 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x3090CEC", Offset = "0x3090CEC", VA = "0x3090CEC")]
	[Token(Token = "0x60025E3")]
	public IEnumerator method_60()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025E4 RID: 9700 RVA: 0x00046F78 File Offset: 0x00045178
	[Token(Token = "0x60025E4")]
	[Address(RVA = "0x3091194", Offset = "0x3091194", VA = "0x3091194")]
	public void Update()
	{
		string str;
		0.ToString() + "/" + str;
	}

	// Token: 0x060025E5 RID: 9701 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025E5")]
	[Address(RVA = "0x3090028", Offset = "0x3090028", VA = "0x3090028")]
	public IEnumerator method_61()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025E6 RID: 9702 RVA: 0x00046F98 File Offset: 0x00045198
	[Address(RVA = "0x30912F8", Offset = "0x30912F8", VA = "0x30912F8")]
	[Token(Token = "0x60025E6")]
	public void method_62()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_19();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + "Not enough amount of currency" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025E7 RID: 9703 RVA: 0x00047038 File Offset: 0x00045238
	[Address(RVA = "0x3091460", Offset = "0x3091460", VA = "0x3091460")]
	[Token(Token = "0x60025E7")]
	public void method_63()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_19();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "Bruh i cannot go here you stupid L bozo" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025E8 RID: 9704 RVA: 0x000470CC File Offset: 0x000452CC
	[Address(RVA = "0x30915C4", Offset = "0x30915C4", VA = "0x30915C4")]
	[Token(Token = "0x60025E8")]
	public void method_64()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + "Horizontal" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025E9 RID: 9705 RVA: 0x0004716C File Offset: 0x0004536C
	[Address(RVA = "0x309172C", Offset = "0x309172C", VA = "0x309172C")]
	[Token(Token = "0x60025E9")]
	public void method_65()
	{
		IEnumerator routine = this.method_69();
		base.StartCoroutine(routine);
		long num = 1L;
		this.bool_1 = (num != 0L);
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		num2.ToString();
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025EA RID: 9706 RVA: 0x00046504 File Offset: 0x00044704
	[Address(RVA = "0x309190C", Offset = "0x309190C", VA = "0x309190C")]
	[Token(Token = "0x60025EA")]
	public void method_66()
	{
		IEnumerator routine = this.method_67();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025EB RID: 9707 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308EB28", Offset = "0x308EB28", VA = "0x308EB28")]
	[Token(Token = "0x60025EB")]
	public IEnumerator method_67()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025EC RID: 9708 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308F758", Offset = "0x308F758", VA = "0x308F758")]
	[Token(Token = "0x60025EC")]
	public IEnumerator method_68()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025ED RID: 9709 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x3091894", Offset = "0x3091894", VA = "0x3091894")]
	[Token(Token = "0x60025ED")]
	public IEnumerator method_69()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025EE RID: 9710 RVA: 0x000471F8 File Offset: 0x000453F8
	[Address(RVA = "0x3091938", Offset = "0x3091938", VA = "0x3091938")]
	[Token(Token = "0x60025EE")]
	public void method_70()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_76();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + "{0}/{1:f0}" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025EF RID: 9711 RVA: 0x00047298 File Offset: 0x00045498
	[Token(Token = "0x60025EF")]
	[Address(RVA = "0x3091AA0", Offset = "0x3091AA0", VA = "0x3091AA0")]
	public void method_71()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_2();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		num.ToString();
		string text;
		text + "Connected to Server." + text;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025F0 RID: 9712 RVA: 0x00047330 File Offset: 0x00045530
	[Token(Token = "0x60025F0")]
	[Address(RVA = "0x3091C04", Offset = "0x3091C04", VA = "0x3091C04")]
	public void method_72()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_54();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		num.ToString();
		string text;
		text + "You are on an outdated version of Capuchin. Your version is " + text;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025F1 RID: 9713 RVA: 0x000473C8 File Offset: 0x000455C8
	[Address(RVA = "0x3091D68", Offset = "0x3091D68", VA = "0x3091D68")]
	[Token(Token = "0x60025F1")]
	public void method_73()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_54();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "Song Index: " + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025F2 RID: 9714 RVA: 0x00046928 File Offset: 0x00044B28
	[Token(Token = "0x60025F2")]
	[Address(RVA = "0x3091ECC", Offset = "0x3091ECC", VA = "0x3091ECC")]
	public void method_74()
	{
		IEnumerator routine = this.method_41();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025F3 RID: 9715 RVA: 0x0004745C File Offset: 0x0004565C
	[Token(Token = "0x60025F3")]
	[Address(RVA = "0x3091EF8", Offset = "0x3091EF8", VA = "0x3091EF8")]
	public void method_75()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_41();
			base.StartCoroutine(routine);
			long num = 1L;
			this.bool_1 = (num != 0L);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num2 = Mathf.RoundToInt((float)f2);
		string str;
		num2.ToString() + "BloodKill" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025F4 RID: 9716 RVA: 0x000465E4 File Offset: 0x000447E4
	[Token(Token = "0x60025F4")]
	[Address(RVA = "0x309098C", Offset = "0x309098C", VA = "0x309098C")]
	public IEnumerator method_76()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025F5 RID: 9717 RVA: 0x000474FC File Offset: 0x000456FC
	[Token(Token = "0x60025F5")]
	[Address(RVA = "0x3092060", Offset = "0x3092060", VA = "0x3092060")]
	public void method_77()
	{
		IEnumerator routine = this.method_80();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025F6 RID: 9718 RVA: 0x00047518 File Offset: 0x00045718
	[Token(Token = "0x60025F6")]
	[Address(RVA = "0x309208C", Offset = "0x309208C", VA = "0x309208C")]
	public void method_78()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_57();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "goUpRPC" + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
		this.double_1 = (double)deltaTime;
	}

	// Token: 0x060025F7 RID: 9719 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x309064C", Offset = "0x309064C", VA = "0x309064C")]
	[Token(Token = "0x60025F7")]
	public IEnumerator method_79()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025F8 RID: 9720 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x308EF3C", Offset = "0x308EF3C", VA = "0x308EF3C")]
	[Token(Token = "0x60025F8")]
	public IEnumerator method_80()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025F9 RID: 9721 RVA: 0x000465E4 File Offset: 0x000447E4
	[Address(RVA = "0x309046C", Offset = "0x309046C", VA = "0x309046C")]
	[Token(Token = "0x60025F9")]
	public IEnumerator method_81()
	{
		TVManager.Class35 @class = new TVManager.Class35((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060025FA RID: 9722 RVA: 0x000475AC File Offset: 0x000457AC
	[Token(Token = "0x60025FA")]
	[Address(RVA = "0x30921F0", Offset = "0x30921F0", VA = "0x30921F0")]
	public void method_82()
	{
		this.method_41();
	}

	// Token: 0x060025FB RID: 9723 RVA: 0x000474FC File Offset: 0x000456FC
	[Token(Token = "0x60025FB")]
	[Address(RVA = "0x309221C", Offset = "0x309221C", VA = "0x309221C")]
	public void method_83()
	{
		IEnumerator routine = this.method_80();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025FC RID: 9724 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x60025FC")]
	[Address(RVA = "0x3092248", Offset = "0x3092248", VA = "0x3092248")]
	public TVManager()
	{
	}

	// Token: 0x060025FD RID: 9725 RVA: 0x00046A18 File Offset: 0x00044C18
	[Address(RVA = "0x3092250", Offset = "0x3092250", VA = "0x3092250")]
	[Token(Token = "0x60025FD")]
	public void method_84()
	{
		IEnumerator routine = this.method_58();
		base.StartCoroutine(routine);
	}

	// Token: 0x060025FE RID: 9726 RVA: 0x000475C0 File Offset: 0x000457C0
	[Address(RVA = "0x309227C", Offset = "0x309227C", VA = "0x309227C")]
	[Token(Token = "0x60025FE")]
	public void method_85()
	{
		this.method_61();
	}

	// Token: 0x060025FF RID: 9727 RVA: 0x00046C9C File Offset: 0x00044E9C
	[Token(Token = "0x60025FF")]
	[Address(RVA = "0x30922A8", Offset = "0x30922A8", VA = "0x30922A8")]
	public void method_86()
	{
		IEnumerator routine = this.method_2();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002600 RID: 9728 RVA: 0x000466F4 File Offset: 0x000448F4
	[Address(RVA = "0x30922D4", Offset = "0x30922D4", VA = "0x30922D4")]
	[Token(Token = "0x6002600")]
	public void method_87()
	{
		IEnumerator routine = this.method_52();
		base.StartCoroutine(routine);
	}

	// Token: 0x06002601 RID: 9729 RVA: 0x000475D4 File Offset: 0x000457D4
	[Address(RVA = "0x3092300", Offset = "0x3092300", VA = "0x3092300")]
	[Token(Token = "0x6002601")]
	public void method_88()
	{
		if (this.bool_1)
		{
			IEnumerator routine = this.method_68();
			base.StartCoroutine(routine);
		}
		double f = this.double_1;
		Mathf.RoundToInt((float)f);
		double f2 = this.double_0;
		int num = Mathf.RoundToInt((float)f2);
		string str;
		num.ToString() + "A new Player joined a Room." + str;
		bool flag = this.bool_0;
		VideoPlayer videoPlayer = this.videoPlayer_0;
		if (flag)
		{
			VideoClip clip = this.videoClip_1;
			videoPlayer.clip = clip;
			return;
		}
		bool isPlaying = videoPlayer.isPlaying;
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x06002602 RID: 9730 RVA: 0x0004690C File Offset: 0x00044B0C
	[Token(Token = "0x6002602")]
	[Address(RVA = "0x3092464", Offset = "0x3092464", VA = "0x3092464")]
	public void method_89()
	{
		IEnumerator routine = this.method_54();
		base.StartCoroutine(routine);
	}

	// Token: 0x040004D9 RID: 1241
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004D9")]
	public VideoPlayer videoPlayer_0;

	// Token: 0x040004DA RID: 1242
	[Token(Token = "0x40004DA")]
	[FieldOffset(Offset = "0x20")]
	public VideoClip[] videoClip_0;

	// Token: 0x040004DB RID: 1243
	[Token(Token = "0x40004DB")]
	[FieldOffset(Offset = "0x28")]
	public VideoClip videoClip_1;

	// Token: 0x040004DC RID: 1244
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004DC")]
	public bool bool_0;

	// Token: 0x040004DD RID: 1245
	[FieldOffset(Offset = "0x31")]
	[Token(Token = "0x40004DD")]
	public bool bool_1;

	// Token: 0x040004DE RID: 1246
	[Token(Token = "0x40004DE")]
	[FieldOffset(Offset = "0x38")]
	public double double_0;

	// Token: 0x040004DF RID: 1247
	[Token(Token = "0x40004DF")]
	[FieldOffset(Offset = "0x40")]
	public double double_1;

	// Token: 0x040004E0 RID: 1248
	[Token(Token = "0x40004E0")]
	[FieldOffset(Offset = "0x48")]
	public TextMeshPro textMeshPro_0;
}
