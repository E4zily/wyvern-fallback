﻿using System;
using System.Collections;
using CapuchinPlayFab;
using Cpp2IlInjected;
using Oculus.Platform;
using Oculus.Platform.Models;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using UnityEngine;

// Token: 0x020000B0 RID: 176
[Token(Token = "0x20000B0")]
public class BuyScript : MonoBehaviour
{
	// Token: 0x060018F2 RID: 6386 RVA: 0x0003275C File Offset: 0x0003095C
	[Address(RVA = "0x25AEE84", Offset = "0x25AEE84", VA = "0x25AEE84")]
	[Token(Token = "0x60018F2")]
	private void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Core.Initialize("Muted");
		this.method_104();
	}

	// Token: 0x060018F3 RID: 6387 RVA: 0x00032790 File Offset: 0x00030990
	[Address(RVA = "0x25AF040", Offset = "0x25AF040", VA = "0x25AF040")]
	[Token(Token = "0x60018F3")]
	private void method_1(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_109();
		base.StartCoroutine(routine);
		this.method_16();
		this.method_82();
	}

	// Token: 0x060018F4 RID: 6388 RVA: 0x000327C0 File Offset: 0x000309C0
	[Address(RVA = "0x25AF378", Offset = "0x25AF378", VA = "0x25AF378")]
	[Token(Token = "0x60018F4")]
	private void method_2(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_43();
	}

	// Token: 0x060018F5 RID: 6389 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25AF3B4", Offset = "0x25AF3B4", VA = "0x25AF3B4")]
	[Token(Token = "0x60018F5")]
	private IEnumerator method_3()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018F6 RID: 6390 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25AF42C", Offset = "0x25AF42C", VA = "0x25AF42C")]
	[Token(Token = "0x60018F6")]
	private IEnumerator method_4()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018F7 RID: 6391 RVA: 0x00032800 File Offset: 0x00030A00
	[Address(RVA = "0x25AF4A4", Offset = "0x25AF4A4", VA = "0x25AF4A4")]
	[Token(Token = "0x60018F7")]
	private void method_5(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_56();
		base.StartCoroutine(routine);
	}

	// Token: 0x060018F8 RID: 6392 RVA: 0x0003281C File Offset: 0x00030A1C
	[Address(RVA = "0x25AF548", Offset = "0x25AF548", VA = "0x25AF548")]
	[Token(Token = "0x60018F8")]
	private void method_6()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "BN";
	}

	// Token: 0x060018F9 RID: 6393 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25AF6D4", Offset = "0x25AF6D4", VA = "0x25AF6D4")]
	[Token(Token = "0x60018F9")]
	private IEnumerator method_7()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060018FA RID: 6394 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25AF74C", Offset = "0x25AF74C", VA = "0x25AF74C")]
	[Token(Token = "0x60018FA")]
	public void method_8()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x060018FB RID: 6395 RVA: 0x00032858 File Offset: 0x00030A58
	[Address(RVA = "0x25AF828", Offset = "0x25AF828", VA = "0x25AF828")]
	[Token(Token = "0x60018FB")]
	private void method_9(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		Core.Initialize("Player");
		this.method_20();
	}

	// Token: 0x060018FC RID: 6396 RVA: 0x00032884 File Offset: 0x00030A84
	[Address(RVA = "0x25AF9E4", Offset = "0x25AF9E4", VA = "0x25AF9E4")]
	[Token(Token = "0x60018FC")]
	private void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
		Core.Initialize("retract broken");
		this.method_107();
	}

	// Token: 0x060018FD RID: 6397 RVA: 0x000328B8 File Offset: 0x00030AB8
	[Address(RVA = "0x25AFBA0", Offset = "0x25AFBA0", VA = "0x25AFBA0")]
	[Token(Token = "0x60018FD")]
	private void method_11(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
	}

	// Token: 0x060018FE RID: 6398 RVA: 0x000328D4 File Offset: 0x00030AD4
	[Address(RVA = "0x25AFC44", Offset = "0x25AFC44", VA = "0x25AFC44")]
	[Token(Token = "0x60018FE")]
	private void method_12()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "Combine textures & build combined mesh using coroutine";
	}

	// Token: 0x060018FF RID: 6399 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25AFDD0", Offset = "0x25AFDD0", VA = "0x25AFDD0")]
	[Token(Token = "0x60018FF")]
	public void method_13()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001900 RID: 6400 RVA: 0x000328F0 File Offset: 0x00030AF0
	[Address(RVA = "0x25AFEAC", Offset = "0x25AFEAC", VA = "0x25AFEAC")]
	[Token(Token = "0x6001900")]
	private void method_14(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_62();
	}

	// Token: 0x06001901 RID: 6401 RVA: 0x00032908 File Offset: 0x00030B08
	[Address(RVA = "0x25AFEE8", Offset = "0x25AFEE8", VA = "0x25AFEE8")]
	[Token(Token = "0x6001901")]
	private void method_15(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_7();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001902 RID: 6402 RVA: 0x0003292C File Offset: 0x00030B2C
	[Address(RVA = "0x25AF120", Offset = "0x25AF120", VA = "0x25AF120")]
	[Token(Token = "0x6001902")]
	private void method_16()
	{
		Message<PurchaseList>.Callback callback;
		IAP.GetViewerPurchases(true).OnComplete(callback);
	}

	// Token: 0x06001903 RID: 6403 RVA: 0x00032948 File Offset: 0x00030B48
	[Address(RVA = "0x25B01EC", Offset = "0x25B01EC", VA = "0x25B01EC")]
	[Token(Token = "0x6001903")]
	private void method_17()
	{
		IAP.GetViewerPurchases(false);
	}

	// Token: 0x06001904 RID: 6404 RVA: 0x0003295C File Offset: 0x00030B5C
	[Address(RVA = "0x25B02B8", Offset = "0x25B02B8", VA = "0x25B02B8")]
	[Token(Token = "0x6001904")]
	private void method_18()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "trol";
	}

	// Token: 0x06001905 RID: 6405 RVA: 0x00032978 File Offset: 0x00030B78
	[Address(RVA = "0x25B0444", Offset = "0x25B0444", VA = "0x25B0444")]
	[Token(Token = "0x6001905")]
	private void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "HandR";
		Core.Initialize("PURCHASED!");
		this.method_8();
	}

	// Token: 0x06001906 RID: 6406 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25AF908", Offset = "0x25AF908", VA = "0x25AF908")]
	[Token(Token = "0x6001906")]
	public void method_20()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001907 RID: 6407 RVA: 0x000329AC File Offset: 0x00030BAC
	[Address(RVA = "0x25B0524", Offset = "0x25B0524", VA = "0x25B0524")]
	[Token(Token = "0x6001907")]
	private void method_21()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "Add/Remove Sword";
	}

	// Token: 0x06001908 RID: 6408 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B06B0", Offset = "0x25B06B0", VA = "0x25B06B0")]
	[Token(Token = "0x6001908")]
	public void method_22()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001909 RID: 6409 RVA: 0x000329C8 File Offset: 0x00030BC8
	[Address(RVA = "0x25B078C", Offset = "0x25B078C", VA = "0x25B078C")]
	[Token(Token = "0x6001909")]
	private void method_23(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
		this.method_54();
		this.method_86();
	}

	// Token: 0x0600190A RID: 6410 RVA: 0x000329F8 File Offset: 0x00030BF8
	[Address(RVA = "0x25B0AC4", Offset = "0x25B0AC4", VA = "0x25B0AC4")]
	[Token(Token = "0x600190A")]
	private void method_24(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
		this.method_42();
		this.method_12();
	}

	// Token: 0x0600190B RID: 6411 RVA: 0x00032A28 File Offset: 0x00030C28
	[Address(RVA = "0x25B0BF8", Offset = "0x25B0BF8", VA = "0x25B0BF8")]
	[Token(Token = "0x600190B")]
	private void method_25(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600190C RID: 6412 RVA: 0x00032A4C File Offset: 0x00030C4C
	[Address(RVA = "0x25B0EFC", Offset = "0x25B0EFC", VA = "0x25B0EFC")]
	[Token(Token = "0x600190C")]
	private void method_26(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_43();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600190D RID: 6413 RVA: 0x00032A74 File Offset: 0x00030C74
	[Address(RVA = "0x25B0F3C", Offset = "0x25B0F3C", VA = "0x25B0F3C")]
	[Token(Token = "0x600190D")]
	private void method_27(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_4();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600190E RID: 6414 RVA: 0x00032A90 File Offset: 0x00030C90
	[Address(RVA = "0x25B0F68", Offset = "0x25B0F68", VA = "0x25B0F68")]
	[Token(Token = "0x600190E")]
	private void method_28(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		Core.Initialize("Queue");
		this.method_107();
	}

	// Token: 0x0600190F RID: 6415 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25B07F4", Offset = "0x25B07F4", VA = "0x25B07F4")]
	[Token(Token = "0x600190F")]
	private IEnumerator method_29()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001910 RID: 6416 RVA: 0x00032ABC File Offset: 0x00030CBC
	[Address(RVA = "0x25B1048", Offset = "0x25B1048", VA = "0x25B1048")]
	[Token(Token = "0x6001910")]
	private void method_30()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "containsStaff";
	}

	// Token: 0x06001911 RID: 6417 RVA: 0x00032AD8 File Offset: 0x00030CD8
	[Address(RVA = "0x25B11D4", Offset = "0x25B11D4", VA = "0x25B11D4")]
	[Token(Token = "0x6001911")]
	private void method_31(Message<PurchaseList> message_0)
	{
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001912 RID: 6418 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B14D8", Offset = "0x25B14D8", VA = "0x25B14D8")]
	[Token(Token = "0x6001912")]
	public void method_32()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001913 RID: 6419 RVA: 0x00032AF4 File Offset: 0x00030CF4
	[Address(RVA = "0x25B15B4", Offset = "0x25B15B4", VA = "0x25B15B4")]
	[Token(Token = "0x6001913")]
	private void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == "On";
		Core.Initialize("Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.");
		this.method_89();
	}

	// Token: 0x06001914 RID: 6420 RVA: 0x00032B28 File Offset: 0x00030D28
	[Address(RVA = "0x25B1770", Offset = "0x25B1770", VA = "0x25B1770")]
	[Token(Token = "0x6001914")]
	private void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "RainAndThunderWeather";
		Core.Initialize("_Tint");
		this.method_32();
	}

	// Token: 0x06001915 RID: 6421 RVA: 0x00032B5C File Offset: 0x00030D5C
	[Address(RVA = "0x25B1850", Offset = "0x25B1850", VA = "0x25B1850")]
	[Token(Token = "0x6001915")]
	private void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "You are not the master of the server, you cannot start the game.";
		this.method_100();
	}

	// Token: 0x06001916 RID: 6422 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B1A0C", Offset = "0x25B1A0C", VA = "0x25B1A0C")]
	[Token(Token = "0x6001916")]
	public void method_36()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001917 RID: 6423 RVA: 0x00032B88 File Offset: 0x00030D88
	[Address(RVA = "0x25B1AE8", Offset = "0x25B1AE8", VA = "0x25B1AE8")]
	[Token(Token = "0x6001917")]
	private void method_37(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_3();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001918 RID: 6424 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25B1DEC", Offset = "0x25B1DEC", VA = "0x25B1DEC")]
	[Token(Token = "0x6001918")]
	private IEnumerator method_38()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001919 RID: 6425 RVA: 0x00032A4C File Offset: 0x00030C4C
	[Address(RVA = "0x25B1E64", Offset = "0x25B1E64", VA = "0x25B1E64")]
	[Token(Token = "0x6001919")]
	private void method_39(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_43();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600191A RID: 6426 RVA: 0x00032BAC File Offset: 0x00030DAC
	[Address(RVA = "0x25B1EA4", Offset = "0x25B1EA4", VA = "0x25B1EA4")]
	[Token(Token = "0x600191A")]
	private void method_40(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_94();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600191B RID: 6427 RVA: 0x00032BC8 File Offset: 0x00030DC8
	[Address(RVA = "0x25B1F48", Offset = "0x25B1F48", VA = "0x25B1F48")]
	[Token(Token = "0x600191B")]
	private void method_41(Collider collider_0)
	{
		collider_0.gameObject.tag == "A new Player joined a Room.";
		Core.Initialize("EnableCosmetic");
		this.method_107();
	}

	// Token: 0x0600191C RID: 6428 RVA: 0x00032BFC File Offset: 0x00030DFC
	[Address(RVA = "0x25B0B2C", Offset = "0x25B0B2C", VA = "0x25B0B2C")]
	[Token(Token = "0x600191C")]
	private void method_42()
	{
		IAP.GetViewerPurchases(false);
	}

	// Token: 0x0600191D RID: 6429 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25B2028", Offset = "0x25B2028", VA = "0x25B2028")]
	[Token(Token = "0x600191D")]
	private IEnumerator method_43()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600191E RID: 6430 RVA: 0x000327C0 File Offset: 0x000309C0
	[Address(RVA = "0x25B20A0", Offset = "0x25B20A0", VA = "0x25B20A0")]
	[Token(Token = "0x600191E")]
	private void method_44(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_43();
	}

	// Token: 0x0600191F RID: 6431 RVA: 0x00032908 File Offset: 0x00030B08
	[Address(RVA = "0x25B20DC", Offset = "0x25B20DC", VA = "0x25B20DC")]
	[Token(Token = "0x600191F")]
	private void method_45(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_7();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001920 RID: 6432 RVA: 0x00032C10 File Offset: 0x00030E10
	[Address(RVA = "0x25B23E0", Offset = "0x25B23E0", VA = "0x25B23E0")]
	[Token(Token = "0x6001920")]
	private void method_46(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_94();
		base.StartCoroutine(routine);
		this.method_16();
		this.method_6();
	}

	// Token: 0x06001921 RID: 6433 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B2448", Offset = "0x25B2448", VA = "0x25B2448")]
	[Token(Token = "0x6001921")]
	public void method_47()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001922 RID: 6434 RVA: 0x00032C40 File Offset: 0x00030E40
	[Address(RVA = "0x25B2524", Offset = "0x25B2524", VA = "0x25B2524")]
	[Token(Token = "0x6001922")]
	private void method_48(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_73();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001923 RID: 6435 RVA: 0x00032C64 File Offset: 0x00030E64
	[Address(RVA = "0x25B28A0", Offset = "0x25B28A0", VA = "0x25B28A0")]
	[Token(Token = "0x6001923")]
	private void method_49(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_3();
		base.StartCoroutine(routine);
		this.method_17();
		this.method_82();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06001924 RID: 6436 RVA: 0x00032CA8 File Offset: 0x00030EA8
	[Address(RVA = "0x25B290C", Offset = "0x25B290C", VA = "0x25B290C")]
	[Token(Token = "0x6001924")]
	private void method_50(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_109();
		base.StartCoroutine(routine);
		this.method_68();
		this.method_92();
	}

	// Token: 0x06001925 RID: 6437 RVA: 0x00032CD8 File Offset: 0x00030ED8
	[Address(RVA = "0x25B2BCC", Offset = "0x25B2BCC", VA = "0x25B2BCC")]
	[Token(Token = "0x6001925")]
	private void method_51()
	{
		Message<PurchaseList>.Callback callback;
		IAP.GetViewerPurchases(false).OnComplete(callback);
	}

	// Token: 0x06001926 RID: 6438 RVA: 0x00032CF4 File Offset: 0x00030EF4
	[Address(RVA = "0x25B2C98", Offset = "0x25B2C98", VA = "0x25B2C98")]
	[Token(Token = "0x6001926")]
	private void method_52(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001927 RID: 6439 RVA: 0x00032D18 File Offset: 0x00030F18
	[Address(RVA = "0x25B2F9C", Offset = "0x25B2F9C", VA = "0x25B2F9C")]
	[Token(Token = "0x6001927")]
	private void method_53()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "GET";
	}

	// Token: 0x06001928 RID: 6440 RVA: 0x00032CD8 File Offset: 0x00030ED8
	[Address(RVA = "0x25B086C", Offset = "0x25B086C", VA = "0x25B086C")]
	[Token(Token = "0x6001928")]
	private void method_54()
	{
		Message<PurchaseList>.Callback callback;
		IAP.GetViewerPurchases(false).OnComplete(callback);
	}

	// Token: 0x06001929 RID: 6441 RVA: 0x00032D34 File Offset: 0x00030F34
	[Address(RVA = "0x25B3128", Offset = "0x25B3128", VA = "0x25B3128")]
	[Token(Token = "0x6001929")]
	private void method_55()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "Round end";
	}

	// Token: 0x0600192A RID: 6442 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25AF4D0", Offset = "0x25AF4D0", VA = "0x25AF4D0")]
	[Token(Token = "0x600192A")]
	private IEnumerator method_56()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600192B RID: 6443 RVA: 0x00032D50 File Offset: 0x00030F50
	[Address(RVA = "0x25B32B4", Offset = "0x25B32B4", VA = "0x25B32B4")]
	[Token(Token = "0x600192B")]
	private void method_57(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600192C RID: 6444 RVA: 0x00032D74 File Offset: 0x00030F74
	[Address(RVA = "0x25B35B8", Offset = "0x25B35B8", VA = "0x25B35B8")]
	[Token(Token = "0x600192C")]
	private void method_58(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
		this.method_51();
		this.method_86();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600192D RID: 6445 RVA: 0x00032DB8 File Offset: 0x00030FB8
	[Address(RVA = "0x25B3624", Offset = "0x25B3624", VA = "0x25B3624")]
	[Token(Token = "0x600192D")]
	private void method_59(Collider collider_0)
	{
		collider_0.gameObject.tag == "\n Time: ";
		Core.Initialize("Update User Inventory");
		this.method_97();
	}

	// Token: 0x0600192E RID: 6446 RVA: 0x00032DEC File Offset: 0x00030FEC
	[Address(RVA = "0x25B37E0", Offset = "0x25B37E0", VA = "0x25B37E0")]
	[Token(Token = "0x600192E")]
	private void method_60(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
		this.method_17();
		this.method_21();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600192F RID: 6447 RVA: 0x00032E30 File Offset: 0x00031030
	[Address(RVA = "0x25B384C", Offset = "0x25B384C", VA = "0x25B384C")]
	[Token(Token = "0x600192F")]
	private void method_61(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_109();
		base.StartCoroutine(routine);
		this.method_54();
		this.method_30();
	}

	// Token: 0x06001930 RID: 6448 RVA: 0x00032E60 File Offset: 0x00031060
	[Address(RVA = "0x25B38B4", Offset = "0x25B38B4", VA = "0x25B38B4")]
	[Token(Token = "0x6001930")]
	private void method_62(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "Mesh";
		Core.Initialize("got funky mone");
		this.method_36();
	}

	// Token: 0x06001931 RID: 6449 RVA: 0x000328F0 File Offset: 0x00030AF0
	[Address(RVA = "0x25B3994", Offset = "0x25B3994", VA = "0x25B3994")]
	[Token(Token = "0x6001931")]
	private void method_63(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_62();
	}

	// Token: 0x06001932 RID: 6450 RVA: 0x00032E90 File Offset: 0x00031090
	[Address(RVA = "0x25B39D0", Offset = "0x25B39D0", VA = "0x25B39D0")]
	[Token(Token = "0x6001932")]
	private void method_64(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001933 RID: 6451 RVA: 0x00032EB4 File Offset: 0x000310B4
	[Address(RVA = "0x25B3CD4", Offset = "0x25B3CD4", VA = "0x25B3CD4")]
	[Token(Token = "0x6001933")]
	private void method_65()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "Not enough amount of currency";
	}

	// Token: 0x06001934 RID: 6452 RVA: 0x00032ED0 File Offset: 0x000310D0
	[Address(RVA = "0x25B3E60", Offset = "0x25B3E60", VA = "0x25B3E60")]
	[Token(Token = "0x6001934")]
	private void OnTriggerEnter(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "FingerTip";
		Core.Initialize("");
		this.method_32();
	}

	// Token: 0x06001935 RID: 6453 RVA: 0x00032A74 File Offset: 0x00030C74
	[Address(RVA = "0x25B3F40", Offset = "0x25B3F40", VA = "0x25B3F40")]
	[Token(Token = "0x6001935")]
	private void method_66(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_4();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001936 RID: 6454 RVA: 0x00032F00 File Offset: 0x00031100
	[Address(RVA = "0x25B3F6C", Offset = "0x25B3F6C", VA = "0x25B3F6C")]
	[Token(Token = "0x6001936")]
	private void method_67(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_7();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001937 RID: 6455 RVA: 0x00032F1C File Offset: 0x0003111C
	[Address(RVA = "0x25B2974", Offset = "0x25B2974", VA = "0x25B2974")]
	[Token(Token = "0x6001937")]
	private void method_68()
	{
		IAP.GetViewerPurchases(true);
	}

	// Token: 0x06001938 RID: 6456 RVA: 0x00032F30 File Offset: 0x00031130
	[Address(RVA = "0x25B3F98", Offset = "0x25B3F98", VA = "0x25B3F98")]
	[Token(Token = "0x6001938")]
	private void method_69()
	{
		IAP.GetViewerPurchases(true);
	}

	// Token: 0x06001939 RID: 6457 RVA: 0x00032F44 File Offset: 0x00031144
	[Address(RVA = "0x25B4064", Offset = "0x25B4064", VA = "0x25B4064")]
	[Token(Token = "0x6001939")]
	private void method_70(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "Player";
		Core.Initialize("Joined Public Room Successfully");
		this.method_97();
	}

	// Token: 0x0600193A RID: 6458 RVA: 0x00032F74 File Offset: 0x00031174
	[Address(RVA = "0x25B4144", Offset = "0x25B4144", VA = "0x25B4144")]
	[Token(Token = "0x600193A")]
	private void method_71(Collider collider_0)
	{
		collider_0.gameObject.tag == "Calling success callback. baking meshes";
		Core.Initialize("liftoff failed!");
		this.method_104();
	}

	// Token: 0x0600193B RID: 6459 RVA: 0x00032A74 File Offset: 0x00030C74
	[Address(RVA = "0x25B4224", Offset = "0x25B4224", VA = "0x25B4224")]
	[Token(Token = "0x600193B")]
	private void method_72(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_4();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600193C RID: 6460 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25B2828", Offset = "0x25B2828", VA = "0x25B2828")]
	[Token(Token = "0x600193C")]
	private IEnumerator method_73()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x0600193D RID: 6461 RVA: 0x00032FA8 File Offset: 0x000311A8
	[Address(RVA = "0x25B4250", Offset = "0x25B4250", VA = "0x25B4250")]
	[Token(Token = "0x600193D")]
	private void method_74(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600193E RID: 6462 RVA: 0x00032FCC File Offset: 0x000311CC
	[Address(RVA = "0x25B4554", Offset = "0x25B4554", VA = "0x25B4554")]
	[Token(Token = "0x600193E")]
	private void method_75(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_109();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600193F RID: 6463 RVA: 0x00032FE8 File Offset: 0x000311E8
	[Address(RVA = "0x25B4580", Offset = "0x25B4580", VA = "0x25B4580")]
	[Token(Token = "0x600193F")]
	private void method_76(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_43();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001940 RID: 6464 RVA: 0x00033004 File Offset: 0x00031204
	[Address(RVA = "0x25B45AC", Offset = "0x25B45AC", VA = "0x25B45AC")]
	[Token(Token = "0x6001940")]
	private void method_77(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
		this.method_83();
		this.method_55();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06001941 RID: 6465 RVA: 0x00033048 File Offset: 0x00031248
	[Address(RVA = "0x25B46E4", Offset = "0x25B46E4", VA = "0x25B46E4")]
	[Token(Token = "0x6001941")]
	private void method_78(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_73();
		base.StartCoroutine(routine);
		this.method_55();
	}

	// Token: 0x06001942 RID: 6466 RVA: 0x00033074 File Offset: 0x00031274
	[Address(RVA = "0x25B474C", Offset = "0x25B474C", VA = "0x25B474C")]
	[Token(Token = "0x6001942")]
	private void method_79(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_29();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001943 RID: 6467 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B4778", Offset = "0x25B4778", VA = "0x25B4778")]
	[Token(Token = "0x6001943")]
	public void method_80()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001944 RID: 6468 RVA: 0x00032B88 File Offset: 0x00030D88
	[Address(RVA = "0x25B4854", Offset = "0x25B4854", VA = "0x25B4854")]
	[Token(Token = "0x6001944")]
	private void method_81(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_3();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001945 RID: 6469 RVA: 0x00033090 File Offset: 0x00031290
	[Address(RVA = "0x25AF1EC", Offset = "0x25AF1EC", VA = "0x25AF1EC")]
	[Token(Token = "0x6001945")]
	private void method_82()
	{
		new AddUserVirtualCurrencyRequest();
	}

	// Token: 0x06001946 RID: 6470 RVA: 0x0003292C File Offset: 0x00030B2C
	[Address(RVA = "0x25B4618", Offset = "0x25B4618", VA = "0x25B4618")]
	[Token(Token = "0x6001946")]
	private void method_83()
	{
		Message<PurchaseList>.Callback callback;
		IAP.GetViewerPurchases(true).OnComplete(callback);
	}

	// Token: 0x06001947 RID: 6471 RVA: 0x000330A4 File Offset: 0x000312A4
	[Address(RVA = "0x25B4B58", Offset = "0x25B4B58", VA = "0x25B4B58")]
	[Token(Token = "0x6001947")]
	private void method_84()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "typesOfTalk";
	}

	// Token: 0x06001948 RID: 6472 RVA: 0x000330C0 File Offset: 0x000312C0
	[Address(RVA = "0x25B4CE4", Offset = "0x25B4CE4", VA = "0x25B4CE4")]
	[Token(Token = "0x6001948")]
	private void method_85(Collider collider_0)
	{
		collider_0.gameObject.tag == "Not connected to room";
		Core.Initialize("Head");
		this.method_97();
	}

	// Token: 0x06001949 RID: 6473 RVA: 0x000330F4 File Offset: 0x000312F4
	[Address(RVA = "0x25B0938", Offset = "0x25B0938", VA = "0x25B0938")]
	[Token(Token = "0x6001949")]
	private void method_86()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "PlayWave";
	}

	// Token: 0x0600194A RID: 6474 RVA: 0x00033110 File Offset: 0x00031310
	[Address(RVA = "0x25B4DC4", Offset = "0x25B4DC4", VA = "0x25B4DC4")]
	[Token(Token = "0x600194A")]
	private void method_87(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_109();
		base.StartCoroutine(routine);
		this.method_16();
		this.method_92();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600194B RID: 6475 RVA: 0x00033154 File Offset: 0x00031354
	[Address(RVA = "0x25B4E30", Offset = "0x25B4E30", VA = "0x25B4E30")]
	[Token(Token = "0x600194B")]
	private void method_88(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
		this.method_17();
		this.method_6();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600194C RID: 6476 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B1694", Offset = "0x25B1694", VA = "0x25B1694")]
	[Token(Token = "0x600194C")]
	public void method_89()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x0600194D RID: 6477 RVA: 0x000328B8 File Offset: 0x00030AB8
	[Address(RVA = "0x25B4E9C", Offset = "0x25B4E9C", VA = "0x25B4E9C")]
	[Token(Token = "0x600194D")]
	private void method_90(PlayFabError playFabError_0)
	{
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
	}

	// Token: 0x0600194E RID: 6478 RVA: 0x00033198 File Offset: 0x00031398
	[Address(RVA = "0x25B4EC8", Offset = "0x25B4EC8", VA = "0x25B4EC8")]
	[Token(Token = "0x600194E")]
	private void method_91(Message<Purchase> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_38();
		base.StartCoroutine(routine);
		this.method_42();
		this.method_18();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600194F RID: 6479 RVA: 0x000331DC File Offset: 0x000313DC
	[Address(RVA = "0x25B4F34", Offset = "0x25B4F34", VA = "0x25B4F34")]
	[Token(Token = "0x600194F")]
	public BuyScript()
	{
	}

	// Token: 0x06001950 RID: 6480 RVA: 0x000331EC File Offset: 0x000313EC
	[Address(RVA = "0x25B2A40", Offset = "0x25B2A40", VA = "0x25B2A40")]
	[Token(Token = "0x6001950")]
	private void method_92()
	{
		new AddUserVirtualCurrencyRequest().VirtualCurrency = "Queue";
	}

	// Token: 0x06001951 RID: 6481 RVA: 0x00032A28 File Offset: 0x00030C28
	[Address(RVA = "0x25B50B4", Offset = "0x25B50B4", VA = "0x25B50B4")]
	[Token(Token = "0x6001951")]
	private void method_93(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_98();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001952 RID: 6482 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25B1ED0", Offset = "0x25B1ED0", VA = "0x25B1ED0")]
	[Token(Token = "0x6001952")]
	private IEnumerator method_94()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001953 RID: 6483 RVA: 0x00033208 File Offset: 0x00031408
	[Address(RVA = "0x25B53B8", Offset = "0x25B53B8", VA = "0x25B53B8")]
	[Token(Token = "0x6001953")]
	private void method_95(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_94();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001954 RID: 6484 RVA: 0x000327C0 File Offset: 0x000309C0
	[Address(RVA = "0x25B56BC", Offset = "0x25B56BC", VA = "0x25B56BC")]
	[Token(Token = "0x6001954")]
	private void method_96(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_43();
	}

	// Token: 0x06001955 RID: 6485 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B3704", Offset = "0x25B3704", VA = "0x25B3704")]
	[Token(Token = "0x6001955")]
	public void method_97()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001956 RID: 6486 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25AFBCC", Offset = "0x25AFBCC", VA = "0x25AFBCC")]
	[Token(Token = "0x6001956")]
	private IEnumerator method_98()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001957 RID: 6487 RVA: 0x00032A4C File Offset: 0x00030C4C
	[Address(RVA = "0x25B56F8", Offset = "0x25B56F8", VA = "0x25B56F8")]
	[Token(Token = "0x6001957")]
	private void method_99(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_43();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x06001958 RID: 6488 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B1930", Offset = "0x25B1930", VA = "0x25B1930")]
	[Token(Token = "0x6001958")]
	public void method_100()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001959 RID: 6489 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B5738", Offset = "0x25B5738", VA = "0x25B5738")]
	[Token(Token = "0x6001959")]
	public void method_101()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x0600195A RID: 6490 RVA: 0x00032A4C File Offset: 0x00030C4C
	[Address(RVA = "0x25B5814", Offset = "0x25B5814", VA = "0x25B5814")]
	[Token(Token = "0x600195A")]
	private void method_102(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_43();
		DoorLerp doorLerp = this.doorLerp_0;
		long bool_ = 1L;
		doorLerp.bool_0 = (bool_ != 0L);
	}

	// Token: 0x0600195B RID: 6491 RVA: 0x0003322C File Offset: 0x0003142C
	[Address(RVA = "0x25B5854", Offset = "0x25B5854", VA = "0x25B5854")]
	[Token(Token = "0x600195B")]
	private void method_103(Collider collider_0)
	{
		collider_0.gameObject.tag == "Round end";
		Core.Initialize("\n Time: ");
		this.method_47();
	}

	// Token: 0x0600195C RID: 6492 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25AEF64", Offset = "0x25AEF64", VA = "0x25AEF64")]
	[Token(Token = "0x600195C")]
	public void method_104()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x0600195D RID: 6493 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25B5934", Offset = "0x25B5934", VA = "0x25B5934")]
	[Token(Token = "0x600195D")]
	public void method_105()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x0600195E RID: 6494 RVA: 0x00033260 File Offset: 0x00031460
	[Address(RVA = "0x25B5A10", Offset = "0x25B5A10", VA = "0x25B5A10")]
	[Token(Token = "0x600195E")]
	private void method_106(ModifyUserVirtualCurrencyResult modifyUserVirtualCurrencyResult_0)
	{
		this.loginManager_0.method_49();
	}

	// Token: 0x0600195F RID: 6495 RVA: 0x00032838 File Offset: 0x00030A38
	[Address(RVA = "0x25AFAC4", Offset = "0x25AFAC4", VA = "0x25AFAC4")]
	[Token(Token = "0x600195F")]
	public void method_107()
	{
		Message<Purchase>.Callback callback;
		IAP.LaunchCheckoutFlow(this.string_0).OnComplete(callback);
	}

	// Token: 0x06001960 RID: 6496 RVA: 0x00033278 File Offset: 0x00031478
	[Address(RVA = "0x25B5A4C", Offset = "0x25B5A4C", VA = "0x25B5A4C")]
	[Token(Token = "0x6001960")]
	private void method_108(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_109();
		base.StartCoroutine(routine);
	}

	// Token: 0x06001961 RID: 6497 RVA: 0x000327D8 File Offset: 0x000309D8
	[Address(RVA = "0x25AF0A8", Offset = "0x25AF0A8", VA = "0x25AF0A8")]
	[Token(Token = "0x6001961")]
	private IEnumerator method_109()
	{
		BuyScript.Class24 @class = new BuyScript.Class24((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x06001962 RID: 6498 RVA: 0x00032C40 File Offset: 0x00030E40
	[Address(RVA = "0x25B5D50", Offset = "0x25B5D50", VA = "0x25B5D50")]
	[Token(Token = "0x6001962")]
	private void method_110(Message<PurchaseList> message_0)
	{
		bool isError = message_0.IsError;
		IEnumerator routine = this.method_73();
		base.StartCoroutine(routine);
	}

	// Token: 0x0400033F RID: 831
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400033F")]
	public string string_0;

	// Token: 0x04000340 RID: 832
	[Token(Token = "0x4000340")]
	[FieldOffset(Offset = "0x20")]
	public int int_0;

	// Token: 0x04000341 RID: 833
	[Token(Token = "0x4000341")]
	[FieldOffset(Offset = "0x28")]
	private string[] string_1;

	// Token: 0x04000342 RID: 834
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000342")]
	public LoginManager loginManager_0;

	// Token: 0x04000343 RID: 835
	[Token(Token = "0x4000343")]
	[FieldOffset(Offset = "0x38")]
	public DoorLerp doorLerp_0;

	// Token: 0x04000344 RID: 836
	[Token(Token = "0x4000344")]
	[FieldOffset(Offset = "0x40")]
	public TextMeshPro textMeshPro_0;
}
