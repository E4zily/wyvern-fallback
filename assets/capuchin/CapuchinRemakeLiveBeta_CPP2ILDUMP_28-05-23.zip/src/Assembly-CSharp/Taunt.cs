﻿using System;
using System.Collections;
using Cpp2IlInjected;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000ED RID: 237
[Token(Token = "0x20000ED")]
public class Taunt : MonoBehaviour
{
	// Token: 0x060023BE RID: 9150 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D2F73C", Offset = "0x2D2F73C", VA = "0x2D2F73C")]
	[Token(Token = "0x60023BE")]
	public void LateUpdate()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060023BF RID: 9151 RVA: 0x00009500 File Offset: 0x00007700
	[Address(RVA = "0x2D2F838", Offset = "0x2D2F838", VA = "0x2D2F838")]
	[Token(Token = "0x60023BF")]
	public IEnumerator method_0()
	{
		throw new NullReferenceException();
	}

	// Token: 0x060023C0 RID: 9152 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2D2F8B0", Offset = "0x2D2F8B0", VA = "0x2D2F8B0")]
	[Token(Token = "0x60023C0")]
	private void method_1()
	{
	}

	// Token: 0x060023C1 RID: 9153 RVA: 0x00042C4C File Offset: 0x00040E4C
	[Address(RVA = "0x2D2F8B4", Offset = "0x2D2F8B4", VA = "0x2D2F8B4")]
	[Token(Token = "0x60023C1")]
	private void Update()
	{
		if (!this.bool_0)
		{
			string name = this.gameObject_0.name;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_1.position;
			Quaternion identity = Quaternion.identity;
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.transform_1.forward;
			Vector3 velocity = this.rigidbody_0.velocity;
			Rigidbody rigidbody = this.rigidbody_0;
			long isKinematic = 1L;
			long num = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			this.bool_0 = (num != 0L);
			IEnumerator routine = this.method_0();
			base.StartCoroutine(routine);
		}
	}

	// Token: 0x060023C2 RID: 9154 RVA: 0x00042CDC File Offset: 0x00040EDC
	[Address(RVA = "0x2D2FB64", Offset = "0x2D2FB64", VA = "0x2D2FB64")]
	[Token(Token = "0x60023C2")]
	private void method_2()
	{
		if (!this.bool_0)
		{
			string name = this.gameObject_0.name;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_1.position;
			Quaternion identity = Quaternion.identity;
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.transform_1.forward;
			Vector3 velocity = this.rigidbody_0.velocity;
			Rigidbody rigidbody = this.rigidbody_0;
			long isKinematic = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			IEnumerator routine = this.method_17();
			base.StartCoroutine(routine);
		}
	}

	// Token: 0x060023C3 RID: 9155 RVA: 0x00042D60 File Offset: 0x00040F60
	[Address(RVA = "0x2D2FE8C", Offset = "0x2D2FE8C", VA = "0x2D2FE8C")]
	[Token(Token = "0x60023C3")]
	public IEnumerator method_3()
	{
		Taunt.Class34 @class = new Taunt.Class34((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023C4 RID: 9156 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D2FF04", Offset = "0x2D2FF04", VA = "0x2D2FF04")]
	[Token(Token = "0x60023C4")]
	public void method_4()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060023C5 RID: 9157 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2D3000C", Offset = "0x2D3000C", VA = "0x2D3000C")]
	[Token(Token = "0x60023C5")]
	public Taunt()
	{
	}

	// Token: 0x060023C6 RID: 9158 RVA: 0x00042D88 File Offset: 0x00040F88
	[Address(RVA = "0x2D30014", Offset = "0x2D30014", VA = "0x2D30014")]
	[Token(Token = "0x60023C6")]
	private void method_5()
	{
		if (!this.bool_0)
		{
			string name = this.gameObject_0.name;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_1.position;
			Quaternion identity = Quaternion.identity;
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.transform_1.forward;
			Vector3 velocity = this.rigidbody_0.velocity;
			Rigidbody rigidbody = this.rigidbody_0;
			long isKinematic = 1L;
			long num = 1L;
			rigidbody.isKinematic = (isKinematic != 0L);
			this.bool_0 = (num != 0L);
			IEnumerator routine = this.method_14();
			base.StartCoroutine(routine);
		}
	}

	// Token: 0x060023C7 RID: 9159 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D30340", Offset = "0x2D30340", VA = "0x2D30340")]
	[Token(Token = "0x60023C7")]
	public void method_6()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060023C8 RID: 9160 RVA: 0x00042D60 File Offset: 0x00040F60
	[Address(RVA = "0x2D3043C", Offset = "0x2D3043C", VA = "0x2D3043C")]
	[Token(Token = "0x60023C8")]
	public IEnumerator method_7()
	{
		Taunt.Class34 @class = new Taunt.Class34((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023C9 RID: 9161 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D304B4", Offset = "0x2D304B4", VA = "0x2D304B4")]
	[Token(Token = "0x60023C9")]
	public void method_8()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060023CA RID: 9162 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2D305C8", Offset = "0x2D305C8", VA = "0x2D305C8")]
	[Token(Token = "0x60023CA")]
	private void method_9()
	{
	}

	// Token: 0x060023CB RID: 9163 RVA: 0x00042D60 File Offset: 0x00040F60
	[Address(RVA = "0x2D305CC", Offset = "0x2D305CC", VA = "0x2D305CC")]
	[Token(Token = "0x60023CB")]
	public IEnumerator method_10()
	{
		Taunt.Class34 @class = new Taunt.Class34((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023CC RID: 9164 RVA: 0x00042D60 File Offset: 0x00040F60
	[Address(RVA = "0x2D30644", Offset = "0x2D30644", VA = "0x2D30644")]
	[Token(Token = "0x60023CC")]
	public IEnumerator method_11()
	{
		Taunt.Class34 @class = new Taunt.Class34((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x060023CD RID: 9165 RVA: 0x00042E18 File Offset: 0x00041018
	[Address(RVA = "0x2D306BC", Offset = "0x2D306BC", VA = "0x2D306BC")]
	[Token(Token = "0x60023CD")]
	private void method_12()
	{
		if (!this.bool_0)
		{
			string name = this.gameObject_0.name;
			Vector3 position = this.transform_0.position;
			Vector3 position2 = this.transform_1.position;
			Quaternion identity = Quaternion.identity;
			GameObject gameObject;
			Transform transform = gameObject.transform;
			Vector3 forward = this.transform_1.forward;
			Vector3 velocity = this.rigidbody_0.velocity;
			Rigidbody rigidbody = this.rigidbody_0;
			long isKinematic = 0L;
			rigidbody.isKinematic = (isKinematic != 0L);
			long num = 1L;
			this.bool_0 = (num != 0L);
			IEnumerator routine = this.method_11();
			base.StartCoroutine(routine);
		}
	}

	// Token: 0x060023CE RID: 9166 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2D30970", Offset = "0x2D30970", VA = "0x2D30970")]
	[Token(Token = "0x60023CE")]
	private void method_13()
	{
	}

	// Token: 0x060023CF RID: 9167 RVA: 0x00042EA8 File Offset: 0x000410A8
	[Address(RVA = "0x2D302C8", Offset = "0x2D302C8", VA = "0x2D302C8")]
	[Token(Token = "0x60023CF")]
	public IEnumerator method_14()
	{
		new Taunt.Class34((int)0L);
		throw new NullReferenceException();
	}

	// Token: 0x060023D0 RID: 9168 RVA: 0x00002068 File Offset: 0x00000268
	[Address(RVA = "0x2D30974", Offset = "0x2D30974", VA = "0x2D30974")]
	[Token(Token = "0x60023D0")]
	public void method_15()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x060023D1 RID: 9169 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2D30A7C", Offset = "0x2D30A7C", VA = "0x2D30A7C")]
	[Token(Token = "0x60023D1")]
	private void method_16()
	{
	}

	// Token: 0x060023D2 RID: 9170 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2D30A80", Offset = "0x2D30A80", VA = "0x2D30A80")]
	[Token(Token = "0x60023D2")]
	private void Start()
	{
	}

	// Token: 0x060023D3 RID: 9171 RVA: 0x00042D60 File Offset: 0x00040F60
	[Address(RVA = "0x2D2FE14", Offset = "0x2D2FE14", VA = "0x2D2FE14")]
	[Token(Token = "0x60023D3")]
	public IEnumerator method_17()
	{
		Taunt.Class34 @class = new Taunt.Class34((int)0L);
		@class.<>4__this = this;
		throw new NullReferenceException();
	}

	// Token: 0x040004B8 RID: 1208
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004B8")]
	public GameObject gameObject_0;

	// Token: 0x040004B9 RID: 1209
	[Token(Token = "0x40004B9")]
	[FieldOffset(Offset = "0x20")]
	public Rigidbody rigidbody_0;

	// Token: 0x040004BA RID: 1210
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004BA")]
	public Transform transform_0;

	// Token: 0x040004BB RID: 1211
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004BB")]
	public Transform transform_1;

	// Token: 0x040004BC RID: 1212
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40004BC")]
	private InputDevice inputDevice_0;

	// Token: 0x040004BD RID: 1213
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40004BD")]
	private InputDevice inputDevice_1;

	// Token: 0x040004BE RID: 1214
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40004BE")]
	private bool bool_0;

	// Token: 0x040004BF RID: 1215
	[Token(Token = "0x40004BF")]
	[FieldOffset(Offset = "0x5C")]
	public Vector3 vector3_0;
}
