﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000E6 RID: 230
[Token(Token = "0x20000E6")]
public class PlayWindowSound : MonoBehaviour
{
	// Token: 0x0600225E RID: 8798 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F060", Offset = "0x305F060", VA = "0x305F060")]
	[Token(Token = "0x600225E")]
	public void method_0(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0600225F RID: 8799 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F084", Offset = "0x305F084", VA = "0x305F084")]
	[Token(Token = "0x600225F")]
	public void method_1(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002260 RID: 8800 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F0A8", Offset = "0x305F0A8", VA = "0x305F0A8")]
	[Token(Token = "0x6002260")]
	public void method_2(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002261 RID: 8801 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F0CC", Offset = "0x305F0CC", VA = "0x305F0CC")]
	[Token(Token = "0x6002261")]
	public void method_3(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002262 RID: 8802 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F0F0", Offset = "0x305F0F0", VA = "0x305F0F0")]
	[Token(Token = "0x6002262")]
	public void method_4(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002263 RID: 8803 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F114", Offset = "0x305F114", VA = "0x305F114")]
	[Token(Token = "0x6002263")]
	public void method_5(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002264 RID: 8804 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F138", Offset = "0x305F138", VA = "0x305F138")]
	[Token(Token = "0x6002264")]
	public void method_6(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002265 RID: 8805 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F15C", Offset = "0x305F15C", VA = "0x305F15C")]
	[Token(Token = "0x6002265")]
	public void method_7(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002266 RID: 8806 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x305F180", Offset = "0x305F180", VA = "0x305F180")]
	[Token(Token = "0x6002266")]
	public PlayWindowSound()
	{
	}

	// Token: 0x06002267 RID: 8807 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F188", Offset = "0x305F188", VA = "0x305F188")]
	[Token(Token = "0x6002267")]
	public void OnTriggerEnter(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002268 RID: 8808 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F1AC", Offset = "0x305F1AC", VA = "0x305F1AC")]
	[Token(Token = "0x6002268")]
	public void method_8(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002269 RID: 8809 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F1D0", Offset = "0x305F1D0", VA = "0x305F1D0")]
	[Token(Token = "0x6002269")]
	public void method_9(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0600226A RID: 8810 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F1F4", Offset = "0x305F1F4", VA = "0x305F1F4")]
	[Token(Token = "0x600226A")]
	public void method_10(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0600226B RID: 8811 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F218", Offset = "0x305F218", VA = "0x305F218")]
	[Token(Token = "0x600226B")]
	public void method_11(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0600226C RID: 8812 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F23C", Offset = "0x305F23C", VA = "0x305F23C")]
	[Token(Token = "0x600226C")]
	public void method_12(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0600226D RID: 8813 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F260", Offset = "0x305F260", VA = "0x305F260")]
	[Token(Token = "0x600226D")]
	public void method_13(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0600226E RID: 8814 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F284", Offset = "0x305F284", VA = "0x305F284")]
	[Token(Token = "0x600226E")]
	public void method_14(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0600226F RID: 8815 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F2A8", Offset = "0x305F2A8", VA = "0x305F2A8")]
	[Token(Token = "0x600226F")]
	public void method_15(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002270 RID: 8816 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F2CC", Offset = "0x305F2CC", VA = "0x305F2CC")]
	[Token(Token = "0x6002270")]
	public void method_16(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002271 RID: 8817 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F2F0", Offset = "0x305F2F0", VA = "0x305F2F0")]
	[Token(Token = "0x6002271")]
	public void method_17(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002272 RID: 8818 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F314", Offset = "0x305F314", VA = "0x305F314")]
	[Token(Token = "0x6002272")]
	public void method_18(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002273 RID: 8819 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F338", Offset = "0x305F338", VA = "0x305F338")]
	[Token(Token = "0x6002273")]
	public void method_19(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002274 RID: 8820 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F35C", Offset = "0x305F35C", VA = "0x305F35C")]
	[Token(Token = "0x6002274")]
	public void method_20(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002275 RID: 8821 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F380", Offset = "0x305F380", VA = "0x305F380")]
	[Token(Token = "0x6002275")]
	public void method_21(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002276 RID: 8822 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F3A4", Offset = "0x305F3A4", VA = "0x305F3A4")]
	[Token(Token = "0x6002276")]
	public void method_22(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002277 RID: 8823 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F3C8", Offset = "0x305F3C8", VA = "0x305F3C8")]
	[Token(Token = "0x6002277")]
	public void method_23(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002278 RID: 8824 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F3EC", Offset = "0x305F3EC", VA = "0x305F3EC")]
	[Token(Token = "0x6002278")]
	public void method_24(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x06002279 RID: 8825 RVA: 0x0003F45C File Offset: 0x0003D65C
	[Address(RVA = "0x305F410", Offset = "0x305F410", VA = "0x305F410")]
	[Token(Token = "0x6002279")]
	public void method_25(Collider collider_0)
	{
		AudioSource audioSource = this.audioSource_0;
		AudioClip clip = this.audioClip_0;
		audioSource.PlayOneShot(clip);
	}

	// Token: 0x0400047D RID: 1149
	[Token(Token = "0x400047D")]
	[FieldOffset(Offset = "0x18")]
	public AudioClip audioClip_0;

	// Token: 0x0400047E RID: 1150
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400047E")]
	public AudioSource audioSource_0;
}
