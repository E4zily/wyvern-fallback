﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000EB RID: 235
[Token(Token = "0x20000EB")]
public class SecondOrderDynamics : MonoBehaviour
{
	// Token: 0x0600233C RID: 9020 RVA: 0x0004286C File Offset: 0x00040A6C
	[Address(RVA = "0x2B8ABD4", Offset = "0x2B8ABD4", VA = "0x2B8ABD4")]
	[Token(Token = "0x600233C")]
	public void method_0()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x0600233D RID: 9021 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8AD10", Offset = "0x2B8AD10", VA = "0x2B8AD10")]
	[Token(Token = "0x600233D")]
	private void method_1()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600233E RID: 9022 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2B8AD48", Offset = "0x2B8AD48", VA = "0x2B8AD48")]
	[Token(Token = "0x600233E")]
	public SecondOrderDynamics()
	{
	}

	// Token: 0x0600233F RID: 9023 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8AD50", Offset = "0x2B8AD50", VA = "0x2B8AD50")]
	[Token(Token = "0x600233F")]
	private void method_2()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002340 RID: 9024 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8AD88", Offset = "0x2B8AD88", VA = "0x2B8AD88")]
	[Token(Token = "0x6002340")]
	private void method_3()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002341 RID: 9025 RVA: 0x0004291C File Offset: 0x00040B1C
	[Address(RVA = "0x2B8ADC0", Offset = "0x2B8ADC0", VA = "0x2B8ADC0")]
	[Token(Token = "0x6002341")]
	public void method_4()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.float_1;
		this.vector3_3.z = z;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z2;
	}

	// Token: 0x06002342 RID: 9026 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8AEFC", Offset = "0x2B8AEFC", VA = "0x2B8AEFC")]
	[Token(Token = "0x6002342")]
	private void method_5()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002343 RID: 9027 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8AF34", Offset = "0x2B8AF34", VA = "0x2B8AF34")]
	[Token(Token = "0x6002343")]
	private void method_6()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002344 RID: 9028 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8AF6C", Offset = "0x2B8AF6C", VA = "0x2B8AF6C")]
	[Token(Token = "0x6002344")]
	private void method_7()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002345 RID: 9029 RVA: 0x0004286C File Offset: 0x00040A6C
	[Address(RVA = "0x2B8AFA4", Offset = "0x2B8AFA4", VA = "0x2B8AFA4")]
	[Token(Token = "0x6002345")]
	public void method_8()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x06002346 RID: 9030 RVA: 0x0004286C File Offset: 0x00040A6C
	[Address(RVA = "0x2B8B0E0", Offset = "0x2B8B0E0", VA = "0x2B8B0E0")]
	[Token(Token = "0x6002346")]
	public void method_9()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x06002347 RID: 9031 RVA: 0x000429A0 File Offset: 0x00040BA0
	[Address(RVA = "0x2B8B21C", Offset = "0x2B8B21C", VA = "0x2B8B21C")]
	[Token(Token = "0x6002347")]
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x06002348 RID: 9032 RVA: 0x0004286C File Offset: 0x00040A6C
	[Address(RVA = "0x2B8B33C", Offset = "0x2B8B33C", VA = "0x2B8B33C")]
	[Token(Token = "0x6002348")]
	public void method_10()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x06002349 RID: 9033 RVA: 0x00042A2C File Offset: 0x00040C2C
	[Address(RVA = "0x2B8B478", Offset = "0x2B8B478", VA = "0x2B8B478")]
	[Token(Token = "0x6002349")]
	public void method_11()
	{
		float deltaTime = Time.deltaTime;
		float num = this.float_4;
		float z = this.float_5;
		this.float_1 = z;
		Transform transform = this.transform_1;
		this.float_3 = num;
		Vector3 position = transform.position;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x0600234A RID: 9034 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8B5B0", Offset = "0x2B8B5B0", VA = "0x2B8B5B0")]
	[Token(Token = "0x600234A")]
	private void method_12()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600234B RID: 9035 RVA: 0x0004286C File Offset: 0x00040A6C
	[Address(RVA = "0x2B8B5E8", Offset = "0x2B8B5E8", VA = "0x2B8B5E8")]
	[Token(Token = "0x600234B")]
	public void method_13()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x0600234C RID: 9036 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8B724", Offset = "0x2B8B724", VA = "0x2B8B724")]
	[Token(Token = "0x600234C")]
	private void Start()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600234D RID: 9037 RVA: 0x00042AB4 File Offset: 0x00040CB4
	[Address(RVA = "0x2B8B75C", Offset = "0x2B8B75C", VA = "0x2B8B75C")]
	[Token(Token = "0x600234D")]
	public void method_14()
	{
		float deltaTime = Time.deltaTime;
	}

	// Token: 0x0600234E RID: 9038 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8B898", Offset = "0x2B8B898", VA = "0x2B8B898")]
	[Token(Token = "0x600234E")]
	private void method_15()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x0600234F RID: 9039 RVA: 0x0004286C File Offset: 0x00040A6C
	[Address(RVA = "0x2B8B8D0", Offset = "0x2B8B8D0", VA = "0x2B8B8D0")]
	[Token(Token = "0x600234F")]
	public void method_16()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x06002350 RID: 9040 RVA: 0x0004286C File Offset: 0x00040A6C
	[Address(RVA = "0x2B8BA0C", Offset = "0x2B8BA0C", VA = "0x2B8BA0C")]
	[Token(Token = "0x6002350")]
	public void method_17()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.x = deltaTime;
		this.vector3_4.z = z3;
	}

	// Token: 0x06002351 RID: 9041 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8BB48", Offset = "0x2B8BB48", VA = "0x2B8BB48")]
	[Token(Token = "0x6002351")]
	private void method_18()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x06002352 RID: 9042 RVA: 0x00042AC8 File Offset: 0x00040CC8
	[Address(RVA = "0x2B8BB80", Offset = "0x2B8BB80", VA = "0x2B8BB80")]
	[Token(Token = "0x6002352")]
	public void method_19()
	{
		float deltaTime = Time.deltaTime;
		float y = this.float_4;
		float z = this.float_5;
		Transform transform = this.transform_1;
		this.float_1 = z;
		this.float_3 = y;
		Vector3 position = transform.position;
		this.vector3_1.y = y;
		this.vector3_1.z = z;
		float z2 = this.vector3_2.z;
		float z3 = this.float_1;
		this.vector3_3.z = z2;
		this.vector3_4.z = z3;
	}

	// Token: 0x06002353 RID: 9043 RVA: 0x00042900 File Offset: 0x00040B00
	[Address(RVA = "0x2B8BCBC", Offset = "0x2B8BCBC", VA = "0x2B8BCBC")]
	[Token(Token = "0x6002353")]
	private void method_20()
	{
		Vector3 position = this.transform_0.position;
	}

	// Token: 0x040004A7 RID: 1191
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004A7")]
	private Vector3 vector3_0;

	// Token: 0x040004A8 RID: 1192
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40004A8")]
	private Vector3 vector3_1;

	// Token: 0x040004A9 RID: 1193
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40004A9")]
	private Vector3 vector3_2;

	// Token: 0x040004AA RID: 1194
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40004AA")]
	public Vector3 vector3_3;

	// Token: 0x040004AB RID: 1195
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40004AB")]
	public Vector3 vector3_4;

	// Token: 0x040004AC RID: 1196
	[FieldOffset(Offset = "0x54")]
	[Token(Token = "0x40004AC")]
	private float float_0;

	// Token: 0x040004AD RID: 1197
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40004AD")]
	private float float_1;

	// Token: 0x040004AE RID: 1198
	[Token(Token = "0x40004AE")]
	[FieldOffset(Offset = "0x5C")]
	private float float_2;

	// Token: 0x040004AF RID: 1199
	[Token(Token = "0x40004AF")]
	[FieldOffset(Offset = "0x60")]
	private float float_3;

	// Token: 0x040004B0 RID: 1200
	[Token(Token = "0x40004B0")]
	[FieldOffset(Offset = "0x68")]
	public Transform transform_0;

	// Token: 0x040004B1 RID: 1201
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40004B1")]
	public Transform transform_1;

	// Token: 0x040004B2 RID: 1202
	[Token(Token = "0x40004B2")]
	[FieldOffset(Offset = "0x78")]
	public float float_4;

	// Token: 0x040004B3 RID: 1203
	[FieldOffset(Offset = "0x7C")]
	[Token(Token = "0x40004B3")]
	public float float_5;

	// Token: 0x040004B4 RID: 1204
	[Token(Token = "0x40004B4")]
	[FieldOffset(Offset = "0x80")]
	public float float_6;
}
