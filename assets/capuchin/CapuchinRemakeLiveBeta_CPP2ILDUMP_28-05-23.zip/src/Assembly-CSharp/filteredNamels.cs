﻿using System;
using Cpp2IlInjected;

// Token: 0x020000F5 RID: 245
[Token(Token = "0x20000F5")]
[Serializable]
public class filteredNamels
{
	// Token: 0x060024E5 RID: 9445 RVA: 0x000020B4 File Offset: 0x000002B4
	[Address(RVA = "0x354DF3C", Offset = "0x354DF3C", VA = "0x354DF3C")]
	[Token(Token = "0x60024E5")]
	public filteredNamels()
	{
	}

	// Token: 0x040004D1 RID: 1233
	[Token(Token = "0x40004D1")]
	[FieldOffset(Offset = "0x10")]
	public string word;
}
