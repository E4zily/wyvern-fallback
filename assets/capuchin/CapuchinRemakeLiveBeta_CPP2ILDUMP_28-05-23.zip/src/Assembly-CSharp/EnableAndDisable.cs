﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200001A RID: 26
[Token(Token = "0x200001A")]
public class EnableAndDisable : MonoBehaviour
{
	// Token: 0x06000347 RID: 839 RVA: 0x0000AB20 File Offset: 0x00008D20
	[Address(RVA = "0x10D5DC0", Offset = "0x10D5DC0", VA = "0x10D5DC0")]
	[Token(Token = "0x6000347")]
	public void method_0(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000348 RID: 840 RVA: 0x0000AB80 File Offset: 0x00008D80
	[Address(RVA = "0x10D5E4C", Offset = "0x10D5E4C", VA = "0x10D5E4C")]
	[Token(Token = "0x6000348")]
	public void method_1(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000349 RID: 841 RVA: 0x0000ABE0 File Offset: 0x00008DE0
	[Address(RVA = "0x10D5ED8", Offset = "0x10D5ED8", VA = "0x10D5ED8")]
	[Token(Token = "0x6000349")]
	public void method_2(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
	}

	// Token: 0x0600034A RID: 842 RVA: 0x0000ABFC File Offset: 0x00008DFC
	[Token(Token = "0x600034A")]
	[Address(RVA = "0x10D5F64", Offset = "0x10D5F64", VA = "0x10D5F64")]
	public void method_3(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600034B RID: 843 RVA: 0x0000AB20 File Offset: 0x00008D20
	[Address(RVA = "0x10D5FF0", Offset = "0x10D5FF0", VA = "0x10D5FF0")]
	[Token(Token = "0x600034B")]
	public void method_4(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600034C RID: 844 RVA: 0x0000AC5C File Offset: 0x00008E5C
	[Address(RVA = "0x10D607C", Offset = "0x10D607C", VA = "0x10D607C")]
	[Token(Token = "0x600034C")]
	public void method_5(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0600034D RID: 845 RVA: 0x0000ACBC File Offset: 0x00008EBC
	[Address(RVA = "0x10D6108", Offset = "0x10D6108", VA = "0x10D6108")]
	[Token(Token = "0x600034D")]
	public void method_6(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		GameObject gameObject;
		if (this.bool_0)
		{
			gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		long active2 = 1L;
		gameObject.SetActive(active2 != 0L);
	}

	// Token: 0x0600034E RID: 846 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x600034E")]
	[Address(RVA = "0x10D6194", Offset = "0x10D6194", VA = "0x10D6194")]
	public EnableAndDisable()
	{
	}

	// Token: 0x0600034F RID: 847 RVA: 0x0000AB20 File Offset: 0x00008D20
	[Address(RVA = "0x10D619C", Offset = "0x10D619C", VA = "0x10D619C")]
	[Token(Token = "0x600034F")]
	public void method_7(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000350 RID: 848 RVA: 0x0000AB80 File Offset: 0x00008D80
	[Token(Token = "0x6000350")]
	[Address(RVA = "0x10D6228", Offset = "0x10D6228", VA = "0x10D6228")]
	public void method_8(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000351 RID: 849 RVA: 0x0000AB80 File Offset: 0x00008D80
	[Address(RVA = "0x10D62B4", Offset = "0x10D62B4", VA = "0x10D62B4")]
	[Token(Token = "0x6000351")]
	public void method_9(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000352 RID: 850 RVA: 0x0000AC5C File Offset: 0x00008E5C
	[Token(Token = "0x6000352")]
	[Address(RVA = "0x10D6340", Offset = "0x10D6340", VA = "0x10D6340")]
	public void method_10(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000353 RID: 851 RVA: 0x0000AB80 File Offset: 0x00008D80
	[Token(Token = "0x6000353")]
	[Address(RVA = "0x10D63CC", Offset = "0x10D63CC", VA = "0x10D63CC")]
	public void method_11(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000354 RID: 852 RVA: 0x0000AB20 File Offset: 0x00008D20
	[Token(Token = "0x6000354")]
	[Address(RVA = "0x10D6458", Offset = "0x10D6458", VA = "0x10D6458")]
	public void method_12(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000355 RID: 853 RVA: 0x0000AC5C File Offset: 0x00008E5C
	[Token(Token = "0x6000355")]
	[Address(RVA = "0x10D64E4", Offset = "0x10D64E4", VA = "0x10D64E4")]
	public void method_13(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 0L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x06000356 RID: 854 RVA: 0x0000ABFC File Offset: 0x00008DFC
	[Address(RVA = "0x10D6570", Offset = "0x10D6570", VA = "0x10D6570")]
	[Token(Token = "0x6000356")]
	public void OnTriggerEnter(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		string b = this.string_0;
		tag == b;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			if (this.bool_0)
			{
				return;
			}
		}
		GameObject gameObject2 = this.gameObject_0;
		long active2 = 1L;
		gameObject2.SetActive(active2 != 0L);
	}

	// Token: 0x0400006A RID: 106
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400006A")]
	public bool bool_0;

	// Token: 0x0400006B RID: 107
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400006B")]
	public GameObject gameObject_0;

	// Token: 0x0400006C RID: 108
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400006C")]
	public string string_0;
}
