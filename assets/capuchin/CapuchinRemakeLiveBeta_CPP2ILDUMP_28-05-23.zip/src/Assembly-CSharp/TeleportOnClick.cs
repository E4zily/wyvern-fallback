﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000EF RID: 239
[Token(Token = "0x20000EF")]
public class TeleportOnClick : MonoBehaviour
{
	// Token: 0x060023DA RID: 9178 RVA: 0x00042F0C File Offset: 0x0004110C
	[Address(RVA = "0x25BC5A8", Offset = "0x25BC5A8", VA = "0x25BC5A8")]
	[Token(Token = "0x60023DA")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "Not enough amount of currency";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023DB RID: 9179 RVA: 0x00042F40 File Offset: 0x00041140
	[Address(RVA = "0x25BC658", Offset = "0x25BC658", VA = "0x25BC658")]
	[Token(Token = "0x60023DB")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "sound play stopped";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023DC RID: 9180 RVA: 0x00042F74 File Offset: 0x00041174
	[Address(RVA = "0x25BC708", Offset = "0x25BC708", VA = "0x25BC708")]
	[Token(Token = "0x60023DC")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023DD RID: 9181 RVA: 0x00042FA8 File Offset: 0x000411A8
	[Address(RVA = "0x25BC7B8", Offset = "0x25BC7B8", VA = "0x25BC7B8")]
	[Token(Token = "0x60023DD")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.tag == "spooky guy true";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023DE RID: 9182 RVA: 0x00042FDC File Offset: 0x000411DC
	[Address(RVA = "0x25BC868", Offset = "0x25BC868", VA = "0x25BC868")]
	[Token(Token = "0x60023DE")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "HeadAttachPoint";
		Vector3 position = this.transform_1.position;
	}

	// Token: 0x060023DF RID: 9183 RVA: 0x0004300C File Offset: 0x0004120C
	[Address(RVA = "0x25BC918", Offset = "0x25BC918", VA = "0x25BC918")]
	[Token(Token = "0x60023DF")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "DisableCosmetic";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E0 RID: 9184 RVA: 0x00043040 File Offset: 0x00041240
	[Address(RVA = "0x25BC9C8", Offset = "0x25BC9C8", VA = "0x25BC9C8")]
	[Token(Token = "0x60023E0")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "{0}/{1:f0}";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E1 RID: 9185 RVA: 0x00043074 File Offset: 0x00041274
	[Address(RVA = "0x25BCA78", Offset = "0x25BCA78", VA = "0x25BCA78")]
	[Token(Token = "0x60023E1")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E2 RID: 9186 RVA: 0x000430A8 File Offset: 0x000412A8
	[Address(RVA = "0x25BCB28", Offset = "0x25BCB28", VA = "0x25BCB28")]
	[Token(Token = "0x60023E2")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot take elements from an empty buffer.";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E3 RID: 9187 RVA: 0x000430DC File Offset: 0x000412DC
	[Address(RVA = "0x25BCBD8", Offset = "0x25BCBD8", VA = "0x25BCBD8")]
	[Token(Token = "0x60023E3")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "Tagged";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E4 RID: 9188 RVA: 0x00043110 File Offset: 0x00041310
	[Address(RVA = "0x25BCC88", Offset = "0x25BCC88", VA = "0x25BCC88")]
	[Token(Token = "0x60023E4")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "Dynamically updates the vertices, normals and tangents in combined mesh every frame.\nThis is similar to dynamic batching. It is not recommended to do this every frame.\nAlso consider baking the mesh renderer objects into a skinned mesh renderer\nThe skinned mesh approach is faster for objects that need to move independently of each other every frame.";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E5 RID: 9189 RVA: 0x00043144 File Offset: 0x00041344
	[Address(RVA = "0x25BCD38", Offset = "0x25BCD38", VA = "0x25BCD38")]
	[Token(Token = "0x60023E5")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cheating";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E6 RID: 9190 RVA: 0x00043178 File Offset: 0x00041378
	[Address(RVA = "0x25BCDE8", Offset = "0x25BCDE8", VA = "0x25BCDE8")]
	[Token(Token = "0x60023E6")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Color";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E7 RID: 9191 RVA: 0x00042F74 File Offset: 0x00041174
	[Address(RVA = "0x25BCE98", Offset = "0x25BCE98", VA = "0x25BCE98")]
	[Token(Token = "0x60023E7")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E8 RID: 9192 RVA: 0x000431AC File Offset: 0x000413AC
	[Address(RVA = "0x25BCF48", Offset = "0x25BCF48", VA = "0x25BCF48")]
	[Token(Token = "0x60023E8")]
	public void method_14(Collider collider_0)
	{
		collider_0.gameObject.tag == "Left a room";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023E9 RID: 9193 RVA: 0x000431E0 File Offset: 0x000413E0
	[Address(RVA = "0x25BCFF8", Offset = "0x25BCFF8", VA = "0x25BCFF8")]
	[Token(Token = "0x60023E9")]
	public void method_15(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023EA RID: 9194 RVA: 0x00043208 File Offset: 0x00041408
	[Address(RVA = "0x25BD0A8", Offset = "0x25BD0A8", VA = "0x25BD0A8")]
	[Token(Token = "0x60023EA")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "Pause";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023EB RID: 9195 RVA: 0x0004323C File Offset: 0x0004143C
	[Address(RVA = "0x25BD158", Offset = "0x25BD158", VA = "0x25BD158")]
	[Token(Token = "0x60023EB")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "On";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023EC RID: 9196 RVA: 0x00043270 File Offset: 0x00041470
	[Address(RVA = "0x25BD208", Offset = "0x25BD208", VA = "0x25BD208")]
	[Token(Token = "0x60023EC")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "Damaged Arm";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023ED RID: 9197 RVA: 0x000432A4 File Offset: 0x000414A4
	[Address(RVA = "0x25BD2B8", Offset = "0x25BD2B8", VA = "0x25BD2B8")]
	[Token(Token = "0x60023ED")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "BN";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023EE RID: 9198 RVA: 0x000432D8 File Offset: 0x000414D8
	[Address(RVA = "0x25BD368", Offset = "0x25BD368", VA = "0x25BD368")]
	[Token(Token = "0x60023EE")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "Universal Render Pipeline/Lit";
	}

	// Token: 0x060023EF RID: 9199 RVA: 0x000432FC File Offset: 0x000414FC
	[Address(RVA = "0x25BD418", Offset = "0x25BD418", VA = "0x25BD418")]
	[Token(Token = "0x60023EF")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F0 RID: 9200 RVA: 0x00043330 File Offset: 0x00041530
	[Address(RVA = "0x25BD4C8", Offset = "0x25BD4C8", VA = "0x25BD4C8")]
	[Token(Token = "0x60023F0")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "SaveHeight";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F1 RID: 9201 RVA: 0x00043364 File Offset: 0x00041564
	[Address(RVA = "0x25BD578", Offset = "0x25BD578", VA = "0x25BD578")]
	[Token(Token = "0x60023F1")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "Joined a Room.";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F2 RID: 9202 RVA: 0x00043398 File Offset: 0x00041598
	[Address(RVA = "0x25BD628", Offset = "0x25BD628", VA = "0x25BD628")]
	[Token(Token = "0x60023F2")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "NGNNoSound";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F3 RID: 9203 RVA: 0x000433CC File Offset: 0x000415CC
	[Address(RVA = "0x25BD6D8", Offset = "0x25BD6D8", VA = "0x25BD6D8")]
	[Token(Token = "0x60023F3")]
	public void method_25(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "This is the 2500 Bananas button, and it was just clicked";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F4 RID: 9204 RVA: 0x000433F8 File Offset: 0x000415F8
	[Address(RVA = "0x25BD788", Offset = "0x25BD788", VA = "0x25BD788")]
	[Token(Token = "0x60023F4")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "XR Usage";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F5 RID: 9205 RVA: 0x0004342C File Offset: 0x0004162C
	[Address(RVA = "0x25BD838", Offset = "0x25BD838", VA = "0x25BD838")]
	[Token(Token = "0x60023F5")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F6 RID: 9206 RVA: 0x000432FC File Offset: 0x000414FC
	[Address(RVA = "0x25BD8E8", Offset = "0x25BD8E8", VA = "0x25BD8E8")]
	[Token(Token = "0x60023F6")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F7 RID: 9207 RVA: 0x00043460 File Offset: 0x00041660
	[Address(RVA = "0x25BD998", Offset = "0x25BD998", VA = "0x25BD998")]
	[Token(Token = "0x60023F7")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.tag == "Try Connect To Server...";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F8 RID: 9208 RVA: 0x00043494 File Offset: 0x00041694
	[Address(RVA = "0x25BDA48", Offset = "0x25BDA48", VA = "0x25BDA48")]
	[Token(Token = "0x60023F8")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == "SetColor";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023F9 RID: 9209 RVA: 0x000431E0 File Offset: 0x000413E0
	[Address(RVA = "0x25BDAF8", Offset = "0x25BDAF8", VA = "0x25BDAF8")]
	[Token(Token = "0x60023F9")]
	public void method_30(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023FA RID: 9210 RVA: 0x000434C8 File Offset: 0x000416C8
	[Address(RVA = "0x25BDBA8", Offset = "0x25BDBA8", VA = "0x25BDBA8")]
	[Token(Token = "0x60023FA")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "Name Changing Error. Error: ";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023FB RID: 9211 RVA: 0x000434FC File Offset: 0x000416FC
	[Address(RVA = "0x25BDC58", Offset = "0x25BDC58", VA = "0x25BDC58")]
	[Token(Token = "0x60023FB")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "ChangeToRegular";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023FC RID: 9212 RVA: 0x00043530 File Offset: 0x00041730
	[Address(RVA = "0x25BDD08", Offset = "0x25BDD08", VA = "0x25BDD08")]
	[Token(Token = "0x60023FC")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == "EnableCosmetic";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023FD RID: 9213 RVA: 0x00042F40 File Offset: 0x00041140
	[Address(RVA = "0x25BDDB8", Offset = "0x25BDDB8", VA = "0x25BDDB8")]
	[Token(Token = "0x60023FD")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "sound play stopped";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023FE RID: 9214 RVA: 0x00043564 File Offset: 0x00041764
	[Address(RVA = "0x25BDE68", Offset = "0x25BDE68", VA = "0x25BDE68")]
	[Token(Token = "0x60023FE")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "retract broken";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x060023FF RID: 9215 RVA: 0x00042F74 File Offset: 0x00041174
	[Address(RVA = "0x25BDF18", Offset = "0x25BDF18", VA = "0x25BDF18")]
	[Token(Token = "0x60023FF")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002400 RID: 9216 RVA: 0x00042F74 File Offset: 0x00041174
	[Address(RVA = "0x25BDFC8", Offset = "0x25BDFC8", VA = "0x25BDFC8")]
	[Token(Token = "0x6002400")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002401 RID: 9217 RVA: 0x00043598 File Offset: 0x00041798
	[Address(RVA = "0x25BE078", Offset = "0x25BE078", VA = "0x25BE078")]
	[Token(Token = "0x6002401")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.tag == "True";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002402 RID: 9218 RVA: 0x000432FC File Offset: 0x000414FC
	[Address(RVA = "0x25BE128", Offset = "0x25BE128", VA = "0x25BE128")]
	[Token(Token = "0x6002402")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002403 RID: 9219 RVA: 0x000432A4 File Offset: 0x000414A4
	[Address(RVA = "0x25BE1D8", Offset = "0x25BE1D8", VA = "0x25BE1D8")]
	[Token(Token = "0x6002403")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.tag == "BN";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002404 RID: 9220 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x25BE288", Offset = "0x25BE288", VA = "0x25BE288")]
	[Token(Token = "0x6002404")]
	public TeleportOnClick()
	{
	}

	// Token: 0x06002405 RID: 9221 RVA: 0x000435CC File Offset: 0x000417CC
	[Address(RVA = "0x25BE290", Offset = "0x25BE290", VA = "0x25BE290")]
	[Token(Token = "0x6002405")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.tag == "Holdable";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002406 RID: 9222 RVA: 0x00043600 File Offset: 0x00041800
	[Address(RVA = "0x25BE340", Offset = "0x25BE340", VA = "0x25BE340")]
	[Token(Token = "0x6002406")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.tag == "This is the 1000 Bananas button, and it was just clicked";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002407 RID: 9223 RVA: 0x0004342C File Offset: 0x0004162C
	[Address(RVA = "0x25BE3F0", Offset = "0x25BE3F0", VA = "0x25BE3F0")]
	[Token(Token = "0x6002407")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002408 RID: 9224 RVA: 0x00043634 File Offset: 0x00041834
	[Address(RVA = "0x25BE4A0", Offset = "0x25BE4A0", VA = "0x25BE4A0")]
	[Token(Token = "0x6002408")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayWave";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x06002409 RID: 9225 RVA: 0x00043668 File Offset: 0x00041868
	[Address(RVA = "0x25BE550", Offset = "0x25BE550", VA = "0x25BE550")]
	[Token(Token = "0x6002409")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.tag == "Mesh Renderer objects have been baked into a skinned mesh. Each source object\n is still in the scene (with renderer disabled) and becomes a bone. Any scripts, animations,\n or physics that affect the invisible source objects will be visible in the\nSkinned Mesh. This approach is more efficient than either dynamic batching or updating every frame \n for many small objects that constantly and independently move. \n With this approach pay attention to the SkinnedMeshRenderer Bounds and Animation Culling\nsettings. You may need to write your own script to manage/update these or your object may vanish or stop animating.\n You can update the combined mesh at runtime as objects are added and deleted from the scene.";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x0600240A RID: 9226 RVA: 0x0004369C File Offset: 0x0004189C
	[Address(RVA = "0x25BE600", Offset = "0x25BE600", VA = "0x25BE600")]
	[Token(Token = "0x600240A")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		Transform transform = this.transform_1;
		Vector3 position = transform.position;
	}

	// Token: 0x0600240B RID: 9227 RVA: 0x000436D0 File Offset: 0x000418D0
	[Address(RVA = "0x25BE6B0", Offset = "0x25BE6B0", VA = "0x25BE6B0")]
	[Token(Token = "0x600240B")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.tag == "n0";
		Vector3 position = this.transform_1.position;
	}

	// Token: 0x040004C3 RID: 1219
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004C3")]
	public Transform transform_0;

	// Token: 0x040004C4 RID: 1220
	[Token(Token = "0x40004C4")]
	[FieldOffset(Offset = "0x20")]
	public Transform transform_1;
}
