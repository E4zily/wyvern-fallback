﻿using System;
using System.Collections;
using Cpp2IlInjected;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x02000038 RID: 56
[Token(Token = "0x2000038")]
public class NetworkManager : MonoBehaviourPunCallbacks
{
	// Token: 0x06000718 RID: 1816 RVA: 0x0000208D File Offset: 0x0000028D
	[Token(Token = "0x6000718")]
	[Address(RVA = "0x2D4BB60", Offset = "0x2D4BB60", VA = "0x2D4BB60")]
	public NetworkManager()
	{
	}

	// Token: 0x06000719 RID: 1817 RVA: 0x00011A40 File Offset: 0x0000FC40
	[Address(RVA = "0x2D4BB68", Offset = "0x2D4BB68", VA = "0x2D4BB68")]
	[Token(Token = "0x6000719")]
	private void method_0()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("PlayerHead");
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x00011A60 File Offset: 0x0000FC60
	[Token(Token = "0x600071A")]
	[Address(RVA = "0x2D4BC10", Offset = "0x2D4BC10", VA = "0x2D4BC10")]
	private void method_1()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("StartSong");
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x00011A80 File Offset: 0x0000FC80
	[Token(Token = "0x600071B")]
	[Address(RVA = "0x2D4BCB8", Offset = "0x2D4BCB8", VA = "0x2D4BCB8")]
	private void method_2()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Joined a Room.");
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x00011AA0 File Offset: 0x0000FCA0
	[Address(RVA = "0x2D4BD60", Offset = "0x2D4BD60", VA = "0x2D4BD60")]
	[Token(Token = "0x600071C")]
	private void method_3()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Try Connect To Server...");
	}

	// Token: 0x0600071D RID: 1821 RVA: 0x00002182 File Offset: 0x00000382
	[Address(RVA = "0x2D4BE08", Offset = "0x2D4BE08", VA = "0x2D4BE08")]
	[Token(Token = "0x600071D")]
	private void method_4()
	{
		this.method_0();
	}

	// Token: 0x0600071E RID: 1822 RVA: 0x0000218A File Offset: 0x0000038A
	[Address(RVA = "0x2D4BE0C", Offset = "0x2D4BE0C", VA = "0x2D4BE0C")]
	[Token(Token = "0x600071E")]
	private void method_5()
	{
		this.method_40();
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x00002192 File Offset: 0x00000392
	[Token(Token = "0x600071F")]
	[Address(RVA = "0x2D4BEB8", Offset = "0x2D4BEB8", VA = "0x2D4BEB8")]
	private void method_6()
	{
		this.method_34();
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x0000219A File Offset: 0x0000039A
	[Address(RVA = "0x2D4BF64", Offset = "0x2D4BF64", VA = "0x2D4BF64")]
	[Token(Token = "0x6000720")]
	private void Start()
	{
		this.method_3();
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x00011AC0 File Offset: 0x0000FCC0
	[Token(Token = "0x6000721")]
	[Address(RVA = "0x2D4BF68", Offset = "0x2D4BF68", VA = "0x2D4BF68")]
	private void method_7()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Squeeze");
	}

	// Token: 0x06000722 RID: 1826 RVA: 0x00011AE0 File Offset: 0x0000FCE0
	[Address(RVA = "0x2D4C010", Offset = "0x2D4C010", VA = "0x2D4C010")]
	[Token(Token = "0x6000722")]
	private void method_8()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Key");
	}

	// Token: 0x06000723 RID: 1827 RVA: 0x00011AA0 File Offset: 0x0000FCA0
	[Token(Token = "0x6000723")]
	[Address(RVA = "0x2D4C0B8", Offset = "0x2D4C0B8", VA = "0x2D4C0B8")]
	private void method_9()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Try Connect To Server...");
	}

	// Token: 0x06000724 RID: 1828 RVA: 0x000021A2 File Offset: 0x000003A2
	[Address(RVA = "0x2D4C160", Offset = "0x2D4C160", VA = "0x2D4C160")]
	[Token(Token = "0x6000724")]
	private void method_10()
	{
		this.method_13();
	}

	// Token: 0x06000725 RID: 1829 RVA: 0x00011B00 File Offset: 0x0000FD00
	[Token(Token = "0x6000725")]
	[Address(RVA = "0x2D4C20C", Offset = "0x2D4C20C", VA = "0x2D4C20C")]
	private void method_11()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Failed to get catalog, cosmetic name, and price. Exact error details is: ");
	}

	// Token: 0x06000726 RID: 1830 RVA: 0x000021AA File Offset: 0x000003AA
	[Token(Token = "0x6000726")]
	[Address(RVA = "0x2D4C2B4", Offset = "0x2D4C2B4", VA = "0x2D4C2B4")]
	private void method_12()
	{
		this.method_2();
	}

	// Token: 0x06000727 RID: 1831 RVA: 0x00011B20 File Offset: 0x0000FD20
	[Token(Token = "0x6000727")]
	[Address(RVA = "0x2D4C164", Offset = "0x2D4C164", VA = "0x2D4C164")]
	private void method_13()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("TurnAmount");
	}

	// Token: 0x06000728 RID: 1832 RVA: 0x000021B2 File Offset: 0x000003B2
	[Address(RVA = "0x2D4C2B8", Offset = "0x2D4C2B8", VA = "0x2D4C2B8")]
	[Token(Token = "0x6000728")]
	private void method_14()
	{
		this.method_28();
	}

	// Token: 0x06000729 RID: 1833 RVA: 0x000021BA File Offset: 0x000003BA
	[Token(Token = "0x6000729")]
	[Address(RVA = "0x2D4C364", Offset = "0x2D4C364", VA = "0x2D4C364")]
	private void method_15()
	{
		this.method_7();
	}

	// Token: 0x0600072A RID: 1834 RVA: 0x000021A2 File Offset: 0x000003A2
	[Token(Token = "0x600072A")]
	[Address(RVA = "0x2D4C368", Offset = "0x2D4C368", VA = "0x2D4C368")]
	private void method_16()
	{
		this.method_13();
	}

	// Token: 0x0600072B RID: 1835 RVA: 0x000021C2 File Offset: 0x000003C2
	[Token(Token = "0x600072B")]
	[Address(RVA = "0x2D4C36C", Offset = "0x2D4C36C", VA = "0x2D4C36C")]
	private void method_17()
	{
		this.method_19();
	}

	// Token: 0x0600072C RID: 1836 RVA: 0x000021CA File Offset: 0x000003CA
	[Address(RVA = "0x2D4C418", Offset = "0x2D4C418", VA = "0x2D4C418")]
	[Token(Token = "0x600072C")]
	private void method_18()
	{
		this.method_9();
	}

	// Token: 0x0600072D RID: 1837 RVA: 0x00011A60 File Offset: 0x0000FC60
	[Address(RVA = "0x2D4C370", Offset = "0x2D4C370", VA = "0x2D4C370")]
	[Token(Token = "0x600072D")]
	private void method_19()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("StartSong");
	}

	// Token: 0x0600072E RID: 1838 RVA: 0x000021D2 File Offset: 0x000003D2
	[Address(RVA = "0x2D4C41C", Offset = "0x2D4C41C", VA = "0x2D4C41C")]
	[Token(Token = "0x600072E")]
	private void method_20()
	{
		this.method_37();
	}

	// Token: 0x0600072F RID: 1839 RVA: 0x000021B2 File Offset: 0x000003B2
	[Address(RVA = "0x2D4C4C8", Offset = "0x2D4C4C8", VA = "0x2D4C4C8")]
	[Token(Token = "0x600072F")]
	private void method_21()
	{
		this.method_28();
	}

	// Token: 0x06000730 RID: 1840 RVA: 0x000021DA File Offset: 0x000003DA
	[Token(Token = "0x6000730")]
	[Address(RVA = "0x2D4C4CC", Offset = "0x2D4C4CC", VA = "0x2D4C4CC", Slot = "41")]
	public override void OnJoinedRoom()
	{
		Debug.Log("Joined a Room.");
		base.OnJoinedRoom();
	}

	// Token: 0x06000731 RID: 1841 RVA: 0x00011B40 File Offset: 0x0000FD40
	[Address(RVA = "0x2D4C550", Offset = "0x2D4C550", VA = "0x2D4C550")]
	[Token(Token = "0x6000731")]
	private void method_22()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("username");
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x00011B60 File Offset: 0x0000FD60
	[Token(Token = "0x6000732")]
	[Address(RVA = "0x2D4C5F8", Offset = "0x2D4C5F8", VA = "0x2D4C5F8")]
	private void method_23()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("");
	}

	// Token: 0x06000733 RID: 1843 RVA: 0x00011B80 File Offset: 0x0000FD80
	[Address(RVA = "0x2D4C6A0", Offset = "0x2D4C6A0", VA = "0x2D4C6A0")]
	[Token(Token = "0x6000733")]
	private void method_24()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("META");
	}

	// Token: 0x06000734 RID: 1844 RVA: 0x00011BA0 File Offset: 0x0000FDA0
	[Address(RVA = "0x2D4C748", Offset = "0x2D4C748", VA = "0x2D4C748", Slot = "45")]
	[Token(Token = "0x6000734")]
	public override void OnConnectedToMaster()
	{
		Debug.Log("Connected to Server.");
		base.OnConnectedToMaster();
		new Hashtable();
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = 10;
		roomOptions.isVisible = (257 != 0);
	}

	// Token: 0x06000735 RID: 1845 RVA: 0x000021EC File Offset: 0x000003EC
	[Address(RVA = "0x2D4C910", Offset = "0x2D4C910", VA = "0x2D4C910")]
	[Token(Token = "0x6000735")]
	private void method_25()
	{
		this.method_1();
	}

	// Token: 0x06000736 RID: 1846 RVA: 0x000021F4 File Offset: 0x000003F4
	[Address(RVA = "0x2D4C914", Offset = "0x2D4C914", VA = "0x2D4C914", Slot = "42")]
	[Token(Token = "0x6000736")]
	public override void OnPlayerEnteredRoom(Player newPlayer)
	{
		Debug.Log("A new Player joined a Room.");
		base.OnPlayerEnteredRoom(newPlayer);
	}

	// Token: 0x06000737 RID: 1847 RVA: 0x0000218A File Offset: 0x0000038A
	[Token(Token = "0x6000737")]
	[Address(RVA = "0x2D4C9A8", Offset = "0x2D4C9A8", VA = "0x2D4C9A8")]
	private void method_26()
	{
		this.method_40();
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x00011AA0 File Offset: 0x0000FCA0
	[Address(RVA = "0x2D4C9AC", Offset = "0x2D4C9AC", VA = "0x2D4C9AC")]
	[Token(Token = "0x6000738")]
	private void method_27()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Try Connect To Server...");
	}

	// Token: 0x06000739 RID: 1849 RVA: 0x00011BDC File Offset: 0x0000FDDC
	[Address(RVA = "0x2D4C2BC", Offset = "0x2D4C2BC", VA = "0x2D4C2BC")]
	[Token(Token = "0x6000739")]
	private void method_28()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Trying Getting Entilement...");
	}

	// Token: 0x0600073A RID: 1850 RVA: 0x00002207 File Offset: 0x00000407
	[Token(Token = "0x600073A")]
	[Address(RVA = "0x2D4CA54", Offset = "0x2D4CA54", VA = "0x2D4CA54", Slot = "43")]
	public override void OnPlayerLeftRoom(Player otherPlayer)
	{
		Debug.Log("A Player has left the Room.");
		base.OnPlayerLeftRoom(otherPlayer);
	}

	// Token: 0x0600073B RID: 1851 RVA: 0x00011BFC File Offset: 0x0000FDFC
	[Address(RVA = "0x2D4CAE8", Offset = "0x2D4CAE8", VA = "0x2D4CAE8")]
	[Token(Token = "0x600073B")]
	private void method_29()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("trol");
	}

	// Token: 0x0600073C RID: 1852 RVA: 0x0000221A File Offset: 0x0000041A
	[Address(RVA = "0x2D4CB90", Offset = "0x2D4CB90", VA = "0x2D4CB90")]
	[Token(Token = "0x600073C")]
	private void method_30()
	{
		this.method_23();
	}

	// Token: 0x0600073D RID: 1853 RVA: 0x000021CA File Offset: 0x000003CA
	[Address(RVA = "0x2D4CB94", Offset = "0x2D4CB94", VA = "0x2D4CB94")]
	[Token(Token = "0x600073D")]
	private void method_31()
	{
		this.method_9();
	}

	// Token: 0x0600073E RID: 1854 RVA: 0x000021A2 File Offset: 0x000003A2
	[Address(RVA = "0x2D4CB98", Offset = "0x2D4CB98", VA = "0x2D4CB98")]
	[Token(Token = "0x600073E")]
	private void method_32()
	{
		this.method_13();
	}

	// Token: 0x0600073F RID: 1855 RVA: 0x00002222 File Offset: 0x00000422
	[Address(RVA = "0x2D4CB9C", Offset = "0x2D4CB9C", VA = "0x2D4CB9C")]
	[Token(Token = "0x600073F")]
	private void method_33()
	{
		this.method_24();
	}

	// Token: 0x06000740 RID: 1856 RVA: 0x00011C1C File Offset: 0x0000FE1C
	[Token(Token = "0x6000740")]
	[Address(RVA = "0x2D4BEBC", Offset = "0x2D4BEBC", VA = "0x2D4BEBC")]
	private void method_34()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log(" and for the price of ");
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x0000222A File Offset: 0x0000042A
	[Address(RVA = "0x2D4CBA0", Offset = "0x2D4CBA0", VA = "0x2D4CBA0")]
	[Token(Token = "0x6000741")]
	private void method_35()
	{
		this.method_11();
	}

	// Token: 0x06000742 RID: 1858 RVA: 0x00002232 File Offset: 0x00000432
	[Address(RVA = "0x2D4CBA4", Offset = "0x2D4CBA4", VA = "0x2D4CBA4")]
	[Token(Token = "0x6000742")]
	private void method_36()
	{
		this.method_42();
	}

	// Token: 0x06000743 RID: 1859 RVA: 0x00011C3C File Offset: 0x0000FE3C
	[Token(Token = "0x6000743")]
	[Address(RVA = "0x2D4C420", Offset = "0x2D4C420", VA = "0x2D4C420")]
	private void method_37()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Failed to login, please restart");
	}

	// Token: 0x06000744 RID: 1860 RVA: 0x00011C5C File Offset: 0x0000FE5C
	[Address(RVA = "0x2D4CC50", Offset = "0x2D4CC50", VA = "0x2D4CC50")]
	[Token(Token = "0x6000744")]
	private void method_38()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("cheese");
	}

	// Token: 0x06000745 RID: 1861 RVA: 0x00002192 File Offset: 0x00000392
	[Token(Token = "0x6000745")]
	[Address(RVA = "0x2D4CCF8", Offset = "0x2D4CCF8", VA = "0x2D4CCF8")]
	private void method_39()
	{
		this.method_34();
	}

	// Token: 0x06000746 RID: 1862 RVA: 0x00011B20 File Offset: 0x0000FD20
	[Address(RVA = "0x2D4BE10", Offset = "0x2D4BE10", VA = "0x2D4BE10")]
	[Token(Token = "0x6000746")]
	private void method_40()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("TurnAmount");
	}

	// Token: 0x06000747 RID: 1863 RVA: 0x000021C2 File Offset: 0x000003C2
	[Token(Token = "0x6000747")]
	[Address(RVA = "0x2D4CCFC", Offset = "0x2D4CCFC", VA = "0x2D4CCFC")]
	private void method_41()
	{
		this.method_19();
	}

	// Token: 0x06000748 RID: 1864 RVA: 0x00011C7C File Offset: 0x0000FE7C
	[Address(RVA = "0x2D4CBA8", Offset = "0x2D4CBA8", VA = "0x2D4CBA8")]
	[Token(Token = "0x6000748")]
	private void method_42()
	{
		PhotonNetwork.ConnectUsingSettings();
	}

	// Token: 0x06000749 RID: 1865 RVA: 0x0000221A File Offset: 0x0000041A
	[Token(Token = "0x6000749")]
	[Address(RVA = "0x2D4CD00", Offset = "0x2D4CD00", VA = "0x2D4CD00")]
	private void method_43()
	{
		this.method_23();
	}

	// Token: 0x0600074A RID: 1866 RVA: 0x000021AA File Offset: 0x000003AA
	[Address(RVA = "0x2D4CD04", Offset = "0x2D4CD04", VA = "0x2D4CD04")]
	[Token(Token = "0x600074A")]
	private void method_44()
	{
		this.method_2();
	}

	// Token: 0x0600074B RID: 1867 RVA: 0x00011C90 File Offset: 0x0000FE90
	[Token(Token = "0x600074B")]
	[Address(RVA = "0x2D4CD08", Offset = "0x2D4CD08", VA = "0x2D4CD08")]
	private void method_45()
	{
		PhotonNetwork.ConnectUsingSettings();
		Debug.Log("Queue");
	}

	// Token: 0x0600074C RID: 1868 RVA: 0x0000223A File Offset: 0x0000043A
	[Address(RVA = "0x2D4CDB0", Offset = "0x2D4CDB0", VA = "0x2D4CDB0")]
	[Token(Token = "0x600074C")]
	private void method_46()
	{
		this.method_22();
	}
}
