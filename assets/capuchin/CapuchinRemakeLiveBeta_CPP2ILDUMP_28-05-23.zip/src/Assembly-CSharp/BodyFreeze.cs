﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000AC RID: 172
[Token(Token = "0x20000AC")]
public class BodyFreeze : MonoBehaviour
{
	// Token: 0x06001882 RID: 6274 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A8F48", Offset = "0x25A8F48", VA = "0x25A8F48")]
	[Token(Token = "0x6001882")]
	private void method_0()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001883 RID: 6275 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A8F80", Offset = "0x25A8F80", VA = "0x25A8F80")]
	[Token(Token = "0x6001883")]
	private void method_1()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001884 RID: 6276 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A8FB8", Offset = "0x25A8FB8", VA = "0x25A8FB8")]
	[Token(Token = "0x6001884")]
	private void method_2()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001885 RID: 6277 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A8FF0", Offset = "0x25A8FF0", VA = "0x25A8FF0")]
	[Token(Token = "0x6001885")]
	private void method_3()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001886 RID: 6278 RVA: 0x00031E88 File Offset: 0x00030088
	[Address(RVA = "0x25A9028", Offset = "0x25A9028", VA = "0x25A9028")]
	[Token(Token = "0x6001886")]
	private void method_4()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001887 RID: 6279 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x25A9060", Offset = "0x25A9060", VA = "0x25A9060")]
	[Token(Token = "0x6001887")]
	public BodyFreeze()
	{
	}

	// Token: 0x06001888 RID: 6280 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9068", Offset = "0x25A9068", VA = "0x25A9068")]
	[Token(Token = "0x6001888")]
	private void method_5()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001889 RID: 6281 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A90A0", Offset = "0x25A90A0", VA = "0x25A90A0")]
	[Token(Token = "0x6001889")]
	private void method_6()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600188A RID: 6282 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A90D8", Offset = "0x25A90D8", VA = "0x25A90D8")]
	[Token(Token = "0x600188A")]
	private void method_7()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600188B RID: 6283 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9110", Offset = "0x25A9110", VA = "0x25A9110")]
	[Token(Token = "0x600188B")]
	private void method_8()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600188C RID: 6284 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9148", Offset = "0x25A9148", VA = "0x25A9148")]
	[Token(Token = "0x600188C")]
	private void method_9()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600188D RID: 6285 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9180", Offset = "0x25A9180", VA = "0x25A9180")]
	[Token(Token = "0x600188D")]
	private void Update()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600188E RID: 6286 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A91B8", Offset = "0x25A91B8", VA = "0x25A91B8")]
	[Token(Token = "0x600188E")]
	private void method_10()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600188F RID: 6287 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A91F0", Offset = "0x25A91F0", VA = "0x25A91F0")]
	[Token(Token = "0x600188F")]
	private void method_11()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001890 RID: 6288 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9228", Offset = "0x25A9228", VA = "0x25A9228")]
	[Token(Token = "0x6001890")]
	private void method_12()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001891 RID: 6289 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9260", Offset = "0x25A9260", VA = "0x25A9260")]
	[Token(Token = "0x6001891")]
	private void method_13()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001892 RID: 6290 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9298", Offset = "0x25A9298", VA = "0x25A9298")]
	[Token(Token = "0x6001892")]
	private void method_14()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001893 RID: 6291 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A92D0", Offset = "0x25A92D0", VA = "0x25A92D0")]
	[Token(Token = "0x6001893")]
	private void method_15()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001894 RID: 6292 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9308", Offset = "0x25A9308", VA = "0x25A9308")]
	[Token(Token = "0x6001894")]
	private void method_16()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001895 RID: 6293 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9340", Offset = "0x25A9340", VA = "0x25A9340")]
	[Token(Token = "0x6001895")]
	private void method_17()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001896 RID: 6294 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9378", Offset = "0x25A9378", VA = "0x25A9378")]
	[Token(Token = "0x6001896")]
	private void method_18()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001897 RID: 6295 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A93B0", Offset = "0x25A93B0", VA = "0x25A93B0")]
	[Token(Token = "0x6001897")]
	private void method_19()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001898 RID: 6296 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A93E8", Offset = "0x25A93E8", VA = "0x25A93E8")]
	[Token(Token = "0x6001898")]
	private void method_20()
	{
		Transform transform = base.transform;
	}

	// Token: 0x06001899 RID: 6297 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9420", Offset = "0x25A9420", VA = "0x25A9420")]
	[Token(Token = "0x6001899")]
	private void method_21()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600189A RID: 6298 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9458", Offset = "0x25A9458", VA = "0x25A9458")]
	[Token(Token = "0x600189A")]
	private void method_22()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600189B RID: 6299 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9490", Offset = "0x25A9490", VA = "0x25A9490")]
	[Token(Token = "0x600189B")]
	private void method_23()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600189C RID: 6300 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A94C8", Offset = "0x25A94C8", VA = "0x25A94C8")]
	[Token(Token = "0x600189C")]
	private void method_24()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600189D RID: 6301 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9500", Offset = "0x25A9500", VA = "0x25A9500")]
	[Token(Token = "0x600189D")]
	private void method_25()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600189E RID: 6302 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9538", Offset = "0x25A9538", VA = "0x25A9538")]
	[Token(Token = "0x600189E")]
	private void method_26()
	{
		Transform transform = base.transform;
	}

	// Token: 0x0600189F RID: 6303 RVA: 0x00031E9C File Offset: 0x0003009C
	[Address(RVA = "0x25A9570", Offset = "0x25A9570", VA = "0x25A9570")]
	[Token(Token = "0x600189F")]
	private void method_27()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A0 RID: 6304 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A95A8", Offset = "0x25A95A8", VA = "0x25A95A8")]
	[Token(Token = "0x60018A0")]
	private void method_28()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A1 RID: 6305 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A95E0", Offset = "0x25A95E0", VA = "0x25A95E0")]
	[Token(Token = "0x60018A1")]
	private void method_29()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A2 RID: 6306 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9618", Offset = "0x25A9618", VA = "0x25A9618")]
	[Token(Token = "0x60018A2")]
	private void method_30()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A3 RID: 6307 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9650", Offset = "0x25A9650", VA = "0x25A9650")]
	[Token(Token = "0x60018A3")]
	private void method_31()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A4 RID: 6308 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9688", Offset = "0x25A9688", VA = "0x25A9688")]
	[Token(Token = "0x60018A4")]
	private void method_32()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A5 RID: 6309 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A96C0", Offset = "0x25A96C0", VA = "0x25A96C0")]
	[Token(Token = "0x60018A5")]
	private void method_33()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A6 RID: 6310 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A96F8", Offset = "0x25A96F8", VA = "0x25A96F8")]
	[Token(Token = "0x60018A6")]
	private void method_34()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A7 RID: 6311 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9730", Offset = "0x25A9730", VA = "0x25A9730")]
	[Token(Token = "0x60018A7")]
	private void method_35()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A8 RID: 6312 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9768", Offset = "0x25A9768", VA = "0x25A9768")]
	[Token(Token = "0x60018A8")]
	private void method_36()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018A9 RID: 6313 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A97A0", Offset = "0x25A97A0", VA = "0x25A97A0")]
	[Token(Token = "0x60018A9")]
	private void method_37()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018AA RID: 6314 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A97D8", Offset = "0x25A97D8", VA = "0x25A97D8")]
	[Token(Token = "0x60018AA")]
	private void method_38()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018AB RID: 6315 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9810", Offset = "0x25A9810", VA = "0x25A9810")]
	[Token(Token = "0x60018AB")]
	private void method_39()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018AC RID: 6316 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9848", Offset = "0x25A9848", VA = "0x25A9848")]
	[Token(Token = "0x60018AC")]
	private void method_40()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018AD RID: 6317 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9880", Offset = "0x25A9880", VA = "0x25A9880")]
	[Token(Token = "0x60018AD")]
	private void method_41()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018AE RID: 6318 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A98B8", Offset = "0x25A98B8", VA = "0x25A98B8")]
	[Token(Token = "0x60018AE")]
	private void method_42()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018AF RID: 6319 RVA: 0x00031E88 File Offset: 0x00030088
	[Address(RVA = "0x25A98F0", Offset = "0x25A98F0", VA = "0x25A98F0")]
	[Token(Token = "0x60018AF")]
	private void method_43()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B0 RID: 6320 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9928", Offset = "0x25A9928", VA = "0x25A9928")]
	[Token(Token = "0x60018B0")]
	private void method_44()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B1 RID: 6321 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9960", Offset = "0x25A9960", VA = "0x25A9960")]
	[Token(Token = "0x60018B1")]
	private void method_45()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B2 RID: 6322 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9998", Offset = "0x25A9998", VA = "0x25A9998")]
	[Token(Token = "0x60018B2")]
	private void method_46()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B3 RID: 6323 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A99D0", Offset = "0x25A99D0", VA = "0x25A99D0")]
	[Token(Token = "0x60018B3")]
	private void method_47()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B4 RID: 6324 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9A08", Offset = "0x25A9A08", VA = "0x25A9A08")]
	[Token(Token = "0x60018B4")]
	private void method_48()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B5 RID: 6325 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9A40", Offset = "0x25A9A40", VA = "0x25A9A40")]
	[Token(Token = "0x60018B5")]
	private void method_49()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B6 RID: 6326 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9A78", Offset = "0x25A9A78", VA = "0x25A9A78")]
	[Token(Token = "0x60018B6")]
	private void method_50()
	{
		Transform transform = base.transform;
	}

	// Token: 0x060018B7 RID: 6327 RVA: 0x00031E74 File Offset: 0x00030074
	[Address(RVA = "0x25A9AB0", Offset = "0x25A9AB0", VA = "0x25A9AB0")]
	[Token(Token = "0x60018B7")]
	private void method_51()
	{
		Transform transform = base.transform;
	}

	// Token: 0x04000333 RID: 819
	[Token(Token = "0x4000333")]
	[FieldOffset(Offset = "0x18")]
	public Quaternion quaternion_0;
}
