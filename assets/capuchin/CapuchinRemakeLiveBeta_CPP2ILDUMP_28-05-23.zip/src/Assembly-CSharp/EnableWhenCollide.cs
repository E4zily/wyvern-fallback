﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000C9 RID: 201
[Token(Token = "0x20000C9")]
public class EnableWhenCollide : MonoBehaviour
{
	// Token: 0x06001C86 RID: 7302 RVA: 0x000361A0 File Offset: 0x000343A0
	[Address(RVA = "0x10D70F4", Offset = "0x10D70F4", VA = "0x10D70F4")]
	[Token(Token = "0x6001C86")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "Added Winner Money";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C87 RID: 7303 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10D7194", Offset = "0x10D7194", VA = "0x10D7194")]
	[Token(Token = "0x6001C87")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C88 RID: 7304 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10D7234", Offset = "0x10D7234", VA = "0x10D7234")]
	[Token(Token = "0x6001C88")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C89 RID: 7305 RVA: 0x00036208 File Offset: 0x00034408
	[Address(RVA = "0x10D72D4", Offset = "0x10D72D4", VA = "0x10D72D4")]
	[Token(Token = "0x6001C89")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.tag == "_BaseMap";
	}

	// Token: 0x06001C8A RID: 7306 RVA: 0x0003622C File Offset: 0x0003442C
	[Address(RVA = "0x10D7374", Offset = "0x10D7374", VA = "0x10D7374")]
	[Token(Token = "0x6001C8A")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "hand 2";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C8B RID: 7307 RVA: 0x00036260 File Offset: 0x00034460
	[Address(RVA = "0x10D7414", Offset = "0x10D7414", VA = "0x10D7414")]
	[Token(Token = "0x6001C8B")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "username";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C8C RID: 7308 RVA: 0x00036294 File Offset: 0x00034494
	[Address(RVA = "0x10D74B4", Offset = "0x10D74B4", VA = "0x10D74B4")]
	[Token(Token = "0x6001C8C")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "Done";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C8D RID: 7309 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10D7554", Offset = "0x10D7554", VA = "0x10D7554")]
	[Token(Token = "0x6001C8D")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C8E RID: 7310 RVA: 0x000362C8 File Offset: 0x000344C8
	[Address(RVA = "0x10D75F4", Offset = "0x10D75F4", VA = "0x10D75F4")]
	[Token(Token = "0x6001C8E")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C8F RID: 7311 RVA: 0x000362FC File Offset: 0x000344FC
	[Address(RVA = "0x10D7694", Offset = "0x10D7694", VA = "0x10D7694")]
	[Token(Token = "0x6001C8F")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Already Own This Item";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C90 RID: 7312 RVA: 0x00036330 File Offset: 0x00034530
	[Address(RVA = "0x10D7734", Offset = "0x10D7734", VA = "0x10D7734")]
	[Token(Token = "0x6001C90")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerHead";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C91 RID: 7313 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x10D77D4", Offset = "0x10D77D4", VA = "0x10D77D4")]
	[Token(Token = "0x6001C91")]
	public EnableWhenCollide()
	{
	}

	// Token: 0x06001C92 RID: 7314 RVA: 0x00036364 File Offset: 0x00034564
	[Address(RVA = "0x10D77DC", Offset = "0x10D77DC", VA = "0x10D77DC")]
	[Token(Token = "0x6001C92")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "This is the 2500 Bananas button, and it was just clicked";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C93 RID: 7315 RVA: 0x00036398 File Offset: 0x00034598
	[Address(RVA = "0x10D787C", Offset = "0x10D787C", VA = "0x10D787C")]
	[Token(Token = "0x6001C93")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "Muted";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C94 RID: 7316 RVA: 0x000363CC File Offset: 0x000345CC
	[Address(RVA = "0x10D791C", Offset = "0x10D791C", VA = "0x10D791C")]
	[Token(Token = "0x6001C94")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C95 RID: 7317 RVA: 0x00036400 File Offset: 0x00034600
	[Address(RVA = "0x10D79BC", Offset = "0x10D79BC", VA = "0x10D79BC")]
	[Token(Token = "0x6001C95")]
	public void method_14(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C96 RID: 7318 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10D7A5C", Offset = "0x10D7A5C", VA = "0x10D7A5C")]
	[Token(Token = "0x6001C96")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C97 RID: 7319 RVA: 0x0003642C File Offset: 0x0003462C
	[Address(RVA = "0x10D7AFC", Offset = "0x10D7AFC", VA = "0x10D7AFC")]
	[Token(Token = "0x6001C97")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "NetworkPlayer";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C98 RID: 7320 RVA: 0x00036460 File Offset: 0x00034660
	[Address(RVA = "0x10D7B9C", Offset = "0x10D7B9C", VA = "0x10D7B9C")]
	[Token(Token = "0x6001C98")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "Open";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C99 RID: 7321 RVA: 0x00036494 File Offset: 0x00034694
	[Address(RVA = "0x10D7C3C", Offset = "0x10D7C3C", VA = "0x10D7C3C")]
	[Token(Token = "0x6001C99")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "Updating Material to: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C9A RID: 7322 RVA: 0x000364C8 File Offset: 0x000346C8
	[Address(RVA = "0x10D7CDC", Offset = "0x10D7CDC", VA = "0x10D7CDC")]
	[Token(Token = "0x6001C9A")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "HDRP/Lit";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C9B RID: 7323 RVA: 0x000364FC File Offset: 0x000346FC
	[Address(RVA = "0x10D7D7C", Offset = "0x10D7D7C", VA = "0x10D7D7C")]
	[Token(Token = "0x6001C9B")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "typesOfTalk";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C9C RID: 7324 RVA: 0x00036530 File Offset: 0x00034730
	[Address(RVA = "0x10D7E1C", Offset = "0x10D7E1C", VA = "0x10D7E1C")]
	[Token(Token = "0x6001C9C")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "character limit reached";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C9D RID: 7325 RVA: 0x00036564 File Offset: 0x00034764
	[Address(RVA = "0x10D7EBC", Offset = "0x10D7EBC", VA = "0x10D7EBC")]
	[Token(Token = "0x6001C9D")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "tutorialCheck";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C9E RID: 7326 RVA: 0x00036598 File Offset: 0x00034798
	[Address(RVA = "0x10D7F5C", Offset = "0x10D7F5C", VA = "0x10D7F5C")]
	[Token(Token = "0x6001C9E")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "Time to bake textures: ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001C9F RID: 7327 RVA: 0x000365CC File Offset: 0x000347CC
	[Address(RVA = "0x10D7FFC", Offset = "0x10D7FFC", VA = "0x10D7FFC")]
	[Token(Token = "0x6001C9F")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA0 RID: 7328 RVA: 0x00036600 File Offset: 0x00034800
	[Address(RVA = "0x10D809C", Offset = "0x10D809C", VA = "0x10D809C")]
	[Token(Token = "0x6001CA0")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA1 RID: 7329 RVA: 0x00036634 File Offset: 0x00034834
	[Address(RVA = "0x10D813C", Offset = "0x10D813C", VA = "0x10D813C")]
	[Token(Token = "0x6001CA1")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "Date: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA2 RID: 7330 RVA: 0x00036668 File Offset: 0x00034868
	[Address(RVA = "0x10D81DC", Offset = "0x10D81DC", VA = "0x10D81DC")]
	[Token(Token = "0x6001CA2")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "Network Player";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA3 RID: 7331 RVA: 0x0003669C File Offset: 0x0003489C
	[Address(RVA = "0x10D827C", Offset = "0x10D827C", VA = "0x10D827C")]
	[Token(Token = "0x6001CA3")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "Version";
	}

	// Token: 0x06001CA4 RID: 7332 RVA: 0x000366C0 File Offset: 0x000348C0
	[Address(RVA = "0x10D831C", Offset = "0x10D831C", VA = "0x10D831C")]
	[Token(Token = "0x6001CA4")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.tag == "Faild To Add Winner Money: ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA5 RID: 7333 RVA: 0x000366F4 File Offset: 0x000348F4
	[Address(RVA = "0x10D83BC", Offset = "0x10D83BC", VA = "0x10D83BC")]
	[Token(Token = "0x6001CA5")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == "Unpause";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA6 RID: 7334 RVA: 0x00036728 File Offset: 0x00034928
	[Address(RVA = "0x10D845C", Offset = "0x10D845C", VA = "0x10D845C")]
	[Token(Token = "0x6001CA6")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == "gamemode";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA7 RID: 7335 RVA: 0x0003675C File Offset: 0x0003495C
	[Address(RVA = "0x10D84FC", Offset = "0x10D84FC", VA = "0x10D84FC")]
	[Token(Token = "0x6001CA7")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "DisableCosmetic";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA8 RID: 7336 RVA: 0x00036790 File Offset: 0x00034990
	[Address(RVA = "0x10D859C", Offset = "0x10D859C", VA = "0x10D859C")]
	[Token(Token = "0x6001CA8")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CA9 RID: 7337 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10D863C", Offset = "0x10D863C", VA = "0x10D863C")]
	[Token(Token = "0x6001CA9")]
	public void OnTriggerExit(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CAA RID: 7338 RVA: 0x000367C4 File Offset: 0x000349C4
	[Address(RVA = "0x10D86DC", Offset = "0x10D86DC", VA = "0x10D86DC")]
	[Token(Token = "0x6001CAA")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CAB RID: 7339 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10D877C", Offset = "0x10D877C", VA = "0x10D877C")]
	[Token(Token = "0x6001CAB")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CAC RID: 7340 RVA: 0x000367F8 File Offset: 0x000349F8
	[Address(RVA = "0x10D881C", Offset = "0x10D881C", VA = "0x10D881C")]
	[Token(Token = "0x6001CAC")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "BN";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CAD RID: 7341 RVA: 0x0003682C File Offset: 0x00034A2C
	[Address(RVA = "0x10D88BC", Offset = "0x10D88BC", VA = "0x10D88BC")]
	[Token(Token = "0x6001CAD")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "FLSPTLT";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CAE RID: 7342 RVA: 0x00036860 File Offset: 0x00034A60
	[Address(RVA = "0x10D895C", Offset = "0x10D895C", VA = "0x10D895C")]
	[Token(Token = "0x6001CAE")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "casual";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CAF RID: 7343 RVA: 0x00036894 File Offset: 0x00034A94
	[Address(RVA = "0x10D89FC", Offset = "0x10D89FC", VA = "0x10D89FC")]
	[Token(Token = "0x6001CAF")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.tag == "DISABLE";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB0 RID: 7344 RVA: 0x000368C8 File Offset: 0x00034AC8
	[Address(RVA = "0x10D8A9C", Offset = "0x10D8A9C", VA = "0x10D8A9C")]
	[Token(Token = "0x6001CB0")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Look Like Butt";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB1 RID: 7345 RVA: 0x000368FC File Offset: 0x00034AFC
	[Address(RVA = "0x10D8B3C", Offset = "0x10D8B3C", VA = "0x10D8B3C")]
	[Token(Token = "0x6001CB1")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.tag == "friend";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB2 RID: 7346 RVA: 0x00036930 File Offset: 0x00034B30
	[Address(RVA = "0x10D8BDC", Offset = "0x10D8BDC", VA = "0x10D8BDC")]
	[Token(Token = "0x6001CB2")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.tag == "Bruh i cannot go here you stupid L bozo";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB3 RID: 7347 RVA: 0x00036964 File Offset: 0x00034B64
	[Address(RVA = "0x10D8C7C", Offset = "0x10D8C7C", VA = "0x10D8C7C")]
	[Token(Token = "0x6001CB3")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.tag == "True";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB4 RID: 7348 RVA: 0x00036998 File Offset: 0x00034B98
	[Address(RVA = "0x10D8D1C", Offset = "0x10D8D1C", VA = "0x10D8D1C")]
	[Token(Token = "0x6001CB4")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB5 RID: 7349 RVA: 0x000369CC File Offset: 0x00034BCC
	[Address(RVA = "0x10D8DBC", Offset = "0x10D8DBC", VA = "0x10D8DBC")]
	[Token(Token = "0x6001CB5")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.tag == "Charged!";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB6 RID: 7350 RVA: 0x00036998 File Offset: 0x00034B98
	[Address(RVA = "0x10D8E5C", Offset = "0x10D8E5C", VA = "0x10D8E5C")]
	[Token(Token = "0x6001CB6")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB7 RID: 7351 RVA: 0x00036A00 File Offset: 0x00034C00
	[Address(RVA = "0x10D8EFC", Offset = "0x10D8EFC", VA = "0x10D8EFC")]
	[Token(Token = "0x6001CB7")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.tag == "PURCHASED";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB8 RID: 7352 RVA: 0x00036A34 File Offset: 0x00034C34
	[Address(RVA = "0x10D8F9C", Offset = "0x10D8F9C", VA = "0x10D8F9C")]
	[Token(Token = "0x6001CB8")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.tag == "Error";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CB9 RID: 7353 RVA: 0x00036A68 File Offset: 0x00034C68
	[Address(RVA = "0x10D903C", Offset = "0x10D903C", VA = "0x10D903C")]
	[Token(Token = "0x6001CB9")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.tag == "Dynamically instantiates game objects. \nRepeatedly adds and removes some of them\n from the combined mesh.";
	}

	// Token: 0x06001CBA RID: 7354 RVA: 0x00036A8C File Offset: 0x00034C8C
	[Address(RVA = "0x10D90DC", Offset = "0x10D90DC", VA = "0x10D90DC")]
	[Token(Token = "0x6001CBA")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.tag == "StartSong";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CBB RID: 7355 RVA: 0x00036AC0 File Offset: 0x00034CC0
	[Address(RVA = "0x10D917C", Offset = "0x10D917C", VA = "0x10D917C")]
	[Token(Token = "0x6001CBB")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.tag == "Version";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CBC RID: 7356 RVA: 0x00036AF4 File Offset: 0x00034CF4
	[Address(RVA = "0x10D921C", Offset = "0x10D921C", VA = "0x10D921C")]
	[Token(Token = "0x6001CBC")]
	public void method_51(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "Trying Getting Entilement...";
		GameObject gameObject2 = this.gameObject_0;
		long active = 1L;
		gameObject2.SetActive(active != 0L);
	}

	// Token: 0x06001CBD RID: 7357 RVA: 0x00036B24 File Offset: 0x00034D24
	[Address(RVA = "0x10D92BC", Offset = "0x10D92BC", VA = "0x10D92BC")]
	[Token(Token = "0x6001CBD")]
	public void method_52(Collider collider_0)
	{
		collider_0.gameObject.tag == "Joined a Room.";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CBE RID: 7358 RVA: 0x00036B58 File Offset: 0x00034D58
	[Address(RVA = "0x10D935C", Offset = "0x10D935C", VA = "0x10D935C")]
	[Token(Token = "0x6001CBE")]
	public void method_53(Collider collider_0)
	{
		collider_0.gameObject.tag == ".Please press the button if you would like to play alone";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CBF RID: 7359 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10D93FC", Offset = "0x10D93FC", VA = "0x10D93FC")]
	[Token(Token = "0x6001CBF")]
	public void method_54(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC0 RID: 7360 RVA: 0x00036B8C File Offset: 0x00034D8C
	[Address(RVA = "0x10D949C", Offset = "0x10D949C", VA = "0x10D949C")]
	[Token(Token = "0x6001CC0")]
	public void method_55(Collider collider_0)
	{
		collider_0.gameObject.tag == "BLUPORT";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC1 RID: 7361 RVA: 0x000367C4 File Offset: 0x000349C4
	[Address(RVA = "0x10D953C", Offset = "0x10D953C", VA = "0x10D953C")]
	[Token(Token = "0x6001CC1")]
	public void method_56(Collider collider_0)
	{
		collider_0.gameObject.tag == "TurnAmount";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC2 RID: 7362 RVA: 0x00036BC0 File Offset: 0x00034DC0
	[Address(RVA = "0x10D95DC", Offset = "0x10D95DC", VA = "0x10D95DC")]
	[Token(Token = "0x6001CC2")]
	public void method_57(Collider collider_0)
	{
		collider_0.gameObject.tag == "DisableCosmetic";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC3 RID: 7363 RVA: 0x00036BF4 File Offset: 0x00034DF4
	[Address(RVA = "0x10D967C", Offset = "0x10D967C", VA = "0x10D967C")]
	[Token(Token = "0x6001CC3")]
	public void method_58(Collider collider_0)
	{
		collider_0.gameObject.tag == "User has been reported for: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC4 RID: 7364 RVA: 0x00036C28 File Offset: 0x00034E28
	[Address(RVA = "0x10D971C", Offset = "0x10D971C", VA = "0x10D971C")]
	[Token(Token = "0x6001CC4")]
	public void method_59(Collider collider_0)
	{
		collider_0.gameObject.tag == "PushToTalk";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC5 RID: 7365 RVA: 0x0003642C File Offset: 0x0003462C
	[Address(RVA = "0x10D97BC", Offset = "0x10D97BC", VA = "0x10D97BC")]
	[Token(Token = "0x6001CC5")]
	public void method_60(Collider collider_0)
	{
		collider_0.gameObject.tag == "NetworkPlayer";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC6 RID: 7366 RVA: 0x00036C5C File Offset: 0x00034E5C
	[Address(RVA = "0x10D985C", Offset = "0x10D985C", VA = "0x10D985C")]
	[Token(Token = "0x6001CC6")]
	public void method_61(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC7 RID: 7367 RVA: 0x00036C90 File Offset: 0x00034E90
	[Address(RVA = "0x10D98FC", Offset = "0x10D98FC", VA = "0x10D98FC")]
	[Token(Token = "0x6001CC7")]
	public void method_62(Collider collider_0)
	{
		collider_0.gameObject.tag == "Starting to bake textures on frame ";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC8 RID: 7368 RVA: 0x00036CC4 File Offset: 0x00034EC4
	[Address(RVA = "0x10D999C", Offset = "0x10D999C", VA = "0x10D999C")]
	[Token(Token = "0x6001CC8")]
	public void method_63(Collider collider_0)
	{
		collider_0.gameObject.tag == "Name Changing Error. Error: ";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CC9 RID: 7369 RVA: 0x00036CF8 File Offset: 0x00034EF8
	[Address(RVA = "0x10D9A3C", Offset = "0x10D9A3C", VA = "0x10D9A3C")]
	[Token(Token = "0x6001CC9")]
	public void method_64(Collider collider_0)
	{
		collider_0.gameObject.tag == "Queue";
	}

	// Token: 0x06001CCA RID: 7370 RVA: 0x00036D1C File Offset: 0x00034F1C
	[Address(RVA = "0x10D9ADC", Offset = "0x10D9ADC", VA = "0x10D9ADC")]
	[Token(Token = "0x6001CCA")]
	public void method_65(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerDeath";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CCB RID: 7371 RVA: 0x00036668 File Offset: 0x00034868
	[Address(RVA = "0x10D9B7C", Offset = "0x10D9B7C", VA = "0x10D9B7C")]
	[Token(Token = "0x6001CCB")]
	public void method_66(Collider collider_0)
	{
		collider_0.gameObject.tag == "Network Player";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CCC RID: 7372 RVA: 0x00036D50 File Offset: 0x00034F50
	[Address(RVA = "0x10D9C1C", Offset = "0x10D9C1C", VA = "0x10D9C1C")]
	[Token(Token = "0x6001CCC")]
	public void method_67(Collider collider_0)
	{
		collider_0.gameObject.tag == "CapuchinStore";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CCD RID: 7373 RVA: 0x00036D84 File Offset: 0x00034F84
	[Address(RVA = "0x10D9CBC", Offset = "0x10D9CBC", VA = "0x10D9CBC")]
	[Token(Token = "0x6001CCD")]
	public void method_68(Collider collider_0)
	{
		GameObject gameObject;
		gameObject.tag == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject2 = this.gameObject_0;
		long active = 1L;
		gameObject2.SetActive(active != 0L);
	}

	// Token: 0x06001CCE RID: 7374 RVA: 0x00036600 File Offset: 0x00034800
	[Address(RVA = "0x10D9D5C", Offset = "0x10D9D5C", VA = "0x10D9D5C")]
	[Token(Token = "0x6001CCE")]
	public void method_69(Collider collider_0)
	{
		collider_0.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CCF RID: 7375 RVA: 0x00036DB4 File Offset: 0x00034FB4
	[Address(RVA = "0x10D9DFC", Offset = "0x10D9DFC", VA = "0x10D9DFC")]
	[Token(Token = "0x6001CCF")]
	public void method_70(Collider collider_0)
	{
		collider_0.gameObject.tag == "/";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD0 RID: 7376 RVA: 0x000364FC File Offset: 0x000346FC
	[Address(RVA = "0x10D9E9C", Offset = "0x10D9E9C", VA = "0x10D9E9C")]
	[Token(Token = "0x6001CD0")]
	public void method_71(Collider collider_0)
	{
		collider_0.gameObject.tag == "typesOfTalk";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD1 RID: 7377 RVA: 0x00036DE8 File Offset: 0x00034FE8
	[Address(RVA = "0x10D9F3C", Offset = "0x10D9F3C", VA = "0x10D9F3C")]
	[Token(Token = "0x6001CD1")]
	public void method_72(Collider collider_0)
	{
		collider_0.gameObject.tag == "RainAndThunderWeather";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD2 RID: 7378 RVA: 0x00036E1C File Offset: 0x0003501C
	[Address(RVA = "0x10D9FDC", Offset = "0x10D9FDC", VA = "0x10D9FDC")]
	[Token(Token = "0x6001CD2")]
	public void method_73(Collider collider_0)
	{
		collider_0.gameObject.tag == "Cannot take elements from an empty buffer.";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD3 RID: 7379 RVA: 0x00036E50 File Offset: 0x00035050
	[Address(RVA = "0x10DA07C", Offset = "0x10DA07C", VA = "0x10DA07C")]
	[Token(Token = "0x6001CD3")]
	public void method_74(Collider collider_0)
	{
		collider_0.gameObject.tag == "Diffuse";
	}

	// Token: 0x06001CD4 RID: 7380 RVA: 0x000361D4 File Offset: 0x000343D4
	[Address(RVA = "0x10DA11C", Offset = "0x10DA11C", VA = "0x10DA11C")]
	[Token(Token = "0x6001CD4")]
	public void method_75(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD5 RID: 7381 RVA: 0x00036E74 File Offset: 0x00035074
	[Address(RVA = "0x10DA1BC", Offset = "0x10DA1BC", VA = "0x10DA1BC")]
	[Token(Token = "0x6001CD5")]
	public void method_76(Collider collider_0)
	{
		collider_0.gameObject.tag == "PRESS AGAIN TO CONFIRM";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD6 RID: 7382 RVA: 0x00036BC0 File Offset: 0x00034DC0
	[Address(RVA = "0x10DA25C", Offset = "0x10DA25C", VA = "0x10DA25C")]
	[Token(Token = "0x6001CD6")]
	public void method_77(Collider collider_0)
	{
		collider_0.gameObject.tag == "DisableCosmetic";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD7 RID: 7383 RVA: 0x00036EA8 File Offset: 0x000350A8
	[Address(RVA = "0x10DA2FC", Offset = "0x10DA2FC", VA = "0x10DA2FC")]
	[Token(Token = "0x6001CD7")]
	public void method_78(Collider collider_0)
	{
		collider_0.gameObject.tag == "Room1";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD8 RID: 7384 RVA: 0x00036EDC File Offset: 0x000350DC
	[Address(RVA = "0x10DA39C", Offset = "0x10DA39C", VA = "0x10DA39C")]
	[Token(Token = "0x6001CD8")]
	public void method_79(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CD9 RID: 7385 RVA: 0x00036EDC File Offset: 0x000350DC
	[Address(RVA = "0x10DA43C", Offset = "0x10DA43C", VA = "0x10DA43C")]
	[Token(Token = "0x6001CD9")]
	public void method_80(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CDA RID: 7386 RVA: 0x00036F10 File Offset: 0x00035110
	[Address(RVA = "0x10DA4DC", Offset = "0x10DA4DC", VA = "0x10DA4DC")]
	[Token(Token = "0x6001CDA")]
	public void method_81(Collider collider_0)
	{
		collider_0.gameObject.tag == "NetworkPlayer";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CDB RID: 7387 RVA: 0x00036F44 File Offset: 0x00035144
	[Address(RVA = "0x10DA57C", Offset = "0x10DA57C", VA = "0x10DA57C")]
	[Token(Token = "0x6001CDB")]
	public void method_82(Collider collider_0)
	{
		collider_0.gameObject.tag == "button";
		GameObject gameObject = this.gameObject_0;
		long active = 0L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x06001CDC RID: 7388 RVA: 0x00036F78 File Offset: 0x00035178
	[Address(RVA = "0x10DA61C", Offset = "0x10DA61C", VA = "0x10DA61C")]
	[Token(Token = "0x6001CDC")]
	public void method_83(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayWave";
		GameObject gameObject = this.gameObject_0;
		long active = 1L;
		gameObject.SetActive(active != 0L);
	}

	// Token: 0x040003E4 RID: 996
	[Token(Token = "0x40003E4")]
	[FieldOffset(Offset = "0x18")]
	public GameObject gameObject_0;
}
