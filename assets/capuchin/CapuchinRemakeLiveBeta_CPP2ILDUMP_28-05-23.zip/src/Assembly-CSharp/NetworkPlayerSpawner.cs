﻿using System;
using Cpp2IlInjected;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000039 RID: 57
[Token(Token = "0x2000039")]
public class NetworkPlayerSpawner : MonoBehaviourPunCallbacks
{
	// Token: 0x0600074D RID: 1869 RVA: 0x00002242 File Offset: 0x00000442
	[Token(Token = "0x600074D")]
	[Address(RVA = "0x2D53A38", Offset = "0x2D53A38", VA = "0x2D53A38")]
	private void method_0()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x0600074E RID: 1870 RVA: 0x00002242 File Offset: 0x00000442
	[Token(Token = "0x600074E")]
	[Address(RVA = "0x2D53A8C", Offset = "0x2D53A8C", VA = "0x2D53A8C")]
	private void method_1()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x0600074F RID: 1871 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D53AE0", Offset = "0x2D53AE0", VA = "0x2D53AE0")]
	[Token(Token = "0x600074F")]
	private void method_2()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000750 RID: 1872 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D53B34", Offset = "0x2D53B34", VA = "0x2D53B34")]
	[Token(Token = "0x6000750")]
	private void method_3()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000751 RID: 1873 RVA: 0x00002242 File Offset: 0x00000442
	[Token(Token = "0x6000751")]
	[Address(RVA = "0x2D53B88", Offset = "0x2D53B88", VA = "0x2D53B88")]
	private void method_4()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000752 RID: 1874 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x6000752")]
	[Address(RVA = "0x2D53BDC", Offset = "0x2D53BDC", VA = "0x2D53BDC")]
	private void method_5()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000753 RID: 1875 RVA: 0x00011CD4 File Offset: 0x0000FED4
	[Address(RVA = "0x2D53D8C", Offset = "0x2D53D8C", VA = "0x2D53D8C")]
	[Token(Token = "0x6000753")]
	private void method_6()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000754 RID: 1876 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D53EE4", Offset = "0x2D53EE4", VA = "0x2D53EE4")]
	[Token(Token = "0x6000754")]
	private void method_7(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000755 RID: 1877 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Address(RVA = "0x2D53F3C", Offset = "0x2D53F3C", VA = "0x2D53F3C")]
	[Token(Token = "0x6000755")]
	private void method_8()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000756 RID: 1878 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D540EC", Offset = "0x2D540EC", VA = "0x2D540EC")]
	[Token(Token = "0x6000756")]
	private void method_9()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D54140", Offset = "0x2D54140", VA = "0x2D54140")]
	[Token(Token = "0x6000757")]
	private void method_10(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x00011D14 File Offset: 0x0000FF14
	[Address(RVA = "0x2D53C84", Offset = "0x2D53C84", VA = "0x2D53C84")]
	[Token(Token = "0x6000758")]
	private void method_11(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_7.rotation;
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x00002242 File Offset: 0x00000442
	[Token(Token = "0x6000759")]
	[Address(RVA = "0x2D54198", Offset = "0x2D54198", VA = "0x2D54198")]
	private void method_12()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x0600075A RID: 1882 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x600075A")]
	[Address(RVA = "0x2D53E34", Offset = "0x2D53E34", VA = "0x2D53E34")]
	private void method_13(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D541EC", Offset = "0x2D541EC", VA = "0x2D541EC")]
	[Token(Token = "0x600075B")]
	private void method_14()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x600075C")]
	[Address(RVA = "0x2D54240", Offset = "0x2D54240", VA = "0x2D54240")]
	private void method_15()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600075D RID: 1885 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D54398", Offset = "0x2D54398", VA = "0x2D54398")]
	[Token(Token = "0x600075D")]
	private void method_16()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x0600075E RID: 1886 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D543EC", Offset = "0x2D543EC", VA = "0x2D543EC")]
	[Token(Token = "0x600075E")]
	private void method_17()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x0600075F RID: 1887 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D54440", Offset = "0x2D54440", VA = "0x2D54440")]
	[Token(Token = "0x600075F")]
	private void method_18()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D53FE4", Offset = "0x2D53FE4", VA = "0x2D53FE4")]
	[Token(Token = "0x6000760")]
	private void method_19(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000761 RID: 1889 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D54494", Offset = "0x2D54494", VA = "0x2D54494")]
	[Token(Token = "0x6000761")]
	private void method_20(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000762 RID: 1890 RVA: 0x00011D30 File Offset: 0x0000FF30
	[Token(Token = "0x6000762")]
	[Address(RVA = "0x2D544EC", Offset = "0x2D544EC", VA = "0x2D544EC")]
	private void method_21()
	{
		bool inRoom = PhotonNetwork.InRoom;
	}

	// Token: 0x06000763 RID: 1891 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x6000763")]
	[Address(RVA = "0x2D54594", Offset = "0x2D54594", VA = "0x2D54594")]
	private void method_22()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000764 RID: 1892 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Address(RVA = "0x2D54694", Offset = "0x2D54694", VA = "0x2D54694")]
	[Token(Token = "0x6000764")]
	private void method_23()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000765 RID: 1893 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x6000765")]
	[Address(RVA = "0x2D54794", Offset = "0x2D54794", VA = "0x2D54794")]
	private void Update()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000766 RID: 1894 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x6000766")]
	[Address(RVA = "0x2D5483C", Offset = "0x2D5483C", VA = "0x2D5483C")]
	private void method_24()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000767 RID: 1895 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Address(RVA = "0x2D548E4", Offset = "0x2D548E4", VA = "0x2D548E4")]
	[Token(Token = "0x6000767")]
	private void method_25()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000768 RID: 1896 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x6000768")]
	[Address(RVA = "0x2D5498C", Offset = "0x2D5498C", VA = "0x2D5498C")]
	private void method_26()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D54A8C", Offset = "0x2D54A8C", VA = "0x2D54A8C")]
	[Token(Token = "0x6000769")]
	private void method_27()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x600076A")]
	[Address(RVA = "0x2D54A34", Offset = "0x2D54A34", VA = "0x2D54A34")]
	private void method_28(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Address(RVA = "0x2D54AE0", Offset = "0x2D54AE0", VA = "0x2D54AE0")]
	[Token(Token = "0x600076B")]
	private void method_29()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600076C RID: 1900 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x600076C")]
	[Address(RVA = "0x2D54B88", Offset = "0x2D54B88", VA = "0x2D54B88")]
	private void method_30()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D54C88", Offset = "0x2D54C88", VA = "0x2D54C88")]
	[Token(Token = "0x600076D")]
	private void method_31(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x600076E")]
	[Address(RVA = "0x2D54340", Offset = "0x2D54340", VA = "0x2D54340")]
	private void method_32(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D5463C", Offset = "0x2D5463C", VA = "0x2D5463C")]
	[Token(Token = "0x600076F")]
	private void method_33(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x0000208D File Offset: 0x0000028D
	[Token(Token = "0x6000770")]
	[Address(RVA = "0x2D54CE0", Offset = "0x2D54CE0", VA = "0x2D54CE0")]
	public NetworkPlayerSpawner()
	{
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x6000771")]
	[Address(RVA = "0x2D53E8C", Offset = "0x2D53E8C", VA = "0x2D53E8C")]
	private void method_34(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x00002242 File Offset: 0x00000442
	[Token(Token = "0x6000772")]
	[Address(RVA = "0x2D54CE8", Offset = "0x2D54CE8", VA = "0x2D54CE8")]
	private void method_35()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D542E8", Offset = "0x2D542E8", VA = "0x2D542E8")]
	[Token(Token = "0x6000773")]
	private void method_36(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000774 RID: 1908 RVA: 0x00011D44 File Offset: 0x0000FF44
	[Token(Token = "0x6000774")]
	[Address(RVA = "0x2D54D3C", Offset = "0x2D54D3C", VA = "0x2D54D3C", Slot = "31")]
	public override void OnLeftRoom()
	{
		base.OnLeftRoom();
		GameObject targetGo = this.gameObject_0;
		PhotonNetwork.Destroy(targetGo);
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x6000775")]
	[Address(RVA = "0x2D54C30", Offset = "0x2D54C30", VA = "0x2D54C30")]
	private void method_37(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D54DB8", Offset = "0x2D54DB8", VA = "0x2D54DB8")]
	[Token(Token = "0x6000776")]
	private void method_38()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x6000777")]
	[Address(RVA = "0x2D53D34", Offset = "0x2D53D34", VA = "0x2D53D34")]
	private void method_39(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D54E0C", Offset = "0x2D54E0C", VA = "0x2D54E0C")]
	[Token(Token = "0x6000778")]
	private void method_40()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x6000779")]
	[Address(RVA = "0x2D54E60", Offset = "0x2D54E60", VA = "0x2D54E60")]
	private void method_41()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x00011D14 File Offset: 0x0000FF14
	[Address(RVA = "0x2D5473C", Offset = "0x2D5473C", VA = "0x2D5473C")]
	[Token(Token = "0x600077A")]
	private void method_42(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_7.rotation;
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Address(RVA = "0x2D54F60", Offset = "0x2D54F60", VA = "0x2D54F60")]
	[Token(Token = "0x600077B")]
	private void method_43()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x600077C")]
	[Address(RVA = "0x2D53CDC", Offset = "0x2D53CDC", VA = "0x2D53CDC")]
	private void method_44(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Address(RVA = "0x2D55008", Offset = "0x2D55008", VA = "0x2D55008")]
	[Token(Token = "0x600077D")]
	private void method_45()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	[Token(Token = "0x600077E")]
	[Address(RVA = "0x2D550B0", Offset = "0x2D550B0", VA = "0x2D550B0")]
	private void method_46()
	{
		bool inRoom = PhotonNetwork.InRoom;
		if (this.photonView_0.<IsMine>k__BackingField)
		{
			return;
		}
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x00002068 File Offset: 0x00000268
	[Token(Token = "0x600077F")]
	[Address(RVA = "0x2D55158", Offset = "0x2D55158", VA = "0x2D55158", Slot = "41")]
	public override void OnJoinedRoom()
	{
		throw new AnalysisFailedException("CPP2IL failed to recover any usable IL for this method.");
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D5403C", Offset = "0x2D5403C", VA = "0x2D5403C")]
	[Token(Token = "0x6000780")]
	private void method_47(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x00002242 File Offset: 0x00000442
	[Token(Token = "0x6000781")]
	[Address(RVA = "0x2D553AC", Offset = "0x2D553AC", VA = "0x2D553AC")]
	private void method_48()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Address(RVA = "0x2D54F08", Offset = "0x2D54F08", VA = "0x2D54F08")]
	[Token(Token = "0x6000782")]
	private void method_49(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x00002242 File Offset: 0x00000442
	[Token(Token = "0x6000783")]
	[Address(RVA = "0x2D55400", Offset = "0x2D55400", VA = "0x2D55400")]
	private void method_50()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000784 RID: 1924 RVA: 0x00002242 File Offset: 0x00000442
	[Address(RVA = "0x2D55454", Offset = "0x2D55454", VA = "0x2D55454")]
	[Token(Token = "0x6000784")]
	private void Start()
	{
		NetworkPlayerSpawner.networkPlayerSpawner_0 = this;
	}

	// Token: 0x06000785 RID: 1925 RVA: 0x00011CF8 File Offset: 0x0000FEF8
	[Token(Token = "0x6000785")]
	[Address(RVA = "0x2D54094", Offset = "0x2D54094", VA = "0x2D54094")]
	private void method_51(Transform transform_7, Transform transform_8)
	{
		Vector3 position = transform_8.position;
		Quaternion rotation = transform_8.rotation;
	}

	// Token: 0x040000FE RID: 254
	[Token(Token = "0x40000FE")]
	public static NetworkPlayerSpawner networkPlayerSpawner_0;

	// Token: 0x040000FF RID: 255
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40000FF")]
	public GameObject gameObject_0;

	// Token: 0x04000100 RID: 256
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000100")]
	public bool bool_0;

	// Token: 0x04000101 RID: 257
	[Token(Token = "0x4000101")]
	[FieldOffset(Offset = "0x30")]
	public Transform transform_0;

	// Token: 0x04000102 RID: 258
	[Token(Token = "0x4000102")]
	[FieldOffset(Offset = "0x38")]
	public Transform transform_1;

	// Token: 0x04000103 RID: 259
	[Token(Token = "0x4000103")]
	[FieldOffset(Offset = "0x40")]
	public Transform transform_2;

	// Token: 0x04000104 RID: 260
	[Token(Token = "0x4000104")]
	[FieldOffset(Offset = "0x48")]
	private Transform transform_3;

	// Token: 0x04000105 RID: 261
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000105")]
	private Transform transform_4;

	// Token: 0x04000106 RID: 262
	[Token(Token = "0x4000106")]
	[FieldOffset(Offset = "0x58")]
	private Transform transform_5;

	// Token: 0x04000107 RID: 263
	[Token(Token = "0x4000107")]
	[FieldOffset(Offset = "0x60")]
	private Transform transform_6;

	// Token: 0x04000108 RID: 264
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4000108")]
	public PhotonView photonView_0;
}
