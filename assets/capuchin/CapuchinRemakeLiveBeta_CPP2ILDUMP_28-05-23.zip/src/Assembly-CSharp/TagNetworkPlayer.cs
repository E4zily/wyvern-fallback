﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000FC RID: 252
[Token(Token = "0x20000FC")]
public class TagNetworkPlayer : MonoBehaviour
{
	// Token: 0x06002609 RID: 9737 RVA: 0x000476B0 File Offset: 0x000458B0
	[Address(RVA = "0x2D2DC5C", Offset = "0x2D2DC5C", VA = "0x2D2DC5C")]
	[Token(Token = "0x6002609")]
	public void method_0()
	{
	}

	// Token: 0x0600260A RID: 9738 RVA: 0x000476C0 File Offset: 0x000458C0
	[Address(RVA = "0x2D2DD0C", Offset = "0x2D2DD0C", VA = "0x2D2DD0C")]
	[Token(Token = "0x600260A")]
	public void method_1()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600260B RID: 9739 RVA: 0x000476D8 File Offset: 0x000458D8
	[Token(Token = "0x600260B")]
	[Address(RVA = "0x2D2DD8C", Offset = "0x2D2DD8C", VA = "0x2D2DD8C")]
	public void method_2()
	{
		if (this.bool_0)
		{
			return;
		}
	}

	// Token: 0x0600260C RID: 9740 RVA: 0x000476B0 File Offset: 0x000458B0
	[Token(Token = "0x600260C")]
	[Address(RVA = "0x2D2DE58", Offset = "0x2D2DE58", VA = "0x2D2DE58")]
	public void method_3()
	{
	}

	// Token: 0x0600260D RID: 9741 RVA: 0x000476B0 File Offset: 0x000458B0
	[Address(RVA = "0x2D2DF08", Offset = "0x2D2DF08", VA = "0x2D2DF08")]
	[Token(Token = "0x600260D")]
	public void method_4()
	{
	}

	// Token: 0x0600260E RID: 9742 RVA: 0x000476D8 File Offset: 0x000458D8
	[Token(Token = "0x600260E")]
	[Address(RVA = "0x2D2DFB8", Offset = "0x2D2DFB8", VA = "0x2D2DFB8")]
	public void method_5()
	{
		if (this.bool_0)
		{
			return;
		}
	}

	// Token: 0x0600260F RID: 9743 RVA: 0x000476F0 File Offset: 0x000458F0
	[Address(RVA = "0x2D2E084", Offset = "0x2D2E084", VA = "0x2D2E084")]
	[Token(Token = "0x600260F")]
	public void method_6()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002610 RID: 9744 RVA: 0x000476F0 File Offset: 0x000458F0
	[Address(RVA = "0x2D2E134", Offset = "0x2D2E134", VA = "0x2D2E134")]
	[Token(Token = "0x6002610")]
	public void method_7()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002611 RID: 9745 RVA: 0x000476F0 File Offset: 0x000458F0
	[Token(Token = "0x6002611")]
	[Address(RVA = "0x2D2E1E4", Offset = "0x2D2E1E4", VA = "0x2D2E1E4")]
	public void method_8()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002612 RID: 9746 RVA: 0x000476B0 File Offset: 0x000458B0
	[Token(Token = "0x6002612")]
	[Address(RVA = "0x2D2E294", Offset = "0x2D2E294", VA = "0x2D2E294")]
	public void method_9()
	{
	}

	// Token: 0x06002613 RID: 9747 RVA: 0x000476F0 File Offset: 0x000458F0
	[Token(Token = "0x6002613")]
	[Address(RVA = "0x2D2E344", Offset = "0x2D2E344", VA = "0x2D2E344")]
	public void method_10()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002614 RID: 9748 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2D2E3F4", Offset = "0x2D2E3F4", VA = "0x2D2E3F4")]
	[Token(Token = "0x6002614")]
	public TagNetworkPlayer()
	{
	}

	// Token: 0x06002615 RID: 9749 RVA: 0x000476B0 File Offset: 0x000458B0
	[Token(Token = "0x6002615")]
	[Address(RVA = "0x2D2E3FC", Offset = "0x2D2E3FC", VA = "0x2D2E3FC")]
	public void method_11()
	{
	}

	// Token: 0x06002616 RID: 9750 RVA: 0x000476B0 File Offset: 0x000458B0
	[Address(RVA = "0x2D2E4AC", Offset = "0x2D2E4AC", VA = "0x2D2E4AC")]
	[Token(Token = "0x6002616")]
	public void method_12()
	{
	}

	// Token: 0x06002617 RID: 9751 RVA: 0x000476F0 File Offset: 0x000458F0
	[Address(RVA = "0x2D2E55C", Offset = "0x2D2E55C", VA = "0x2D2E55C")]
	[Token(Token = "0x6002617")]
	public void method_13()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002618 RID: 9752 RVA: 0x00047714 File Offset: 0x00045914
	[Token(Token = "0x6002618")]
	[Address(RVA = "0x2D2E60C", Offset = "0x2D2E60C", VA = "0x2D2E60C")]
	public void method_14()
	{
	}

	// Token: 0x06002619 RID: 9753 RVA: 0x000476D8 File Offset: 0x000458D8
	[Token(Token = "0x6002619")]
	[Address(RVA = "0x2D2E6BC", Offset = "0x2D2E6BC", VA = "0x2D2E6BC")]
	public void method_15()
	{
		if (this.bool_0)
		{
			return;
		}
	}

	// Token: 0x0600261A RID: 9754 RVA: 0x000476C0 File Offset: 0x000458C0
	[Address(RVA = "0x2D2E788", Offset = "0x2D2E788", VA = "0x2D2E788")]
	[Token(Token = "0x600261A")]
	public void method_16()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600261B RID: 9755 RVA: 0x000476F0 File Offset: 0x000458F0
	[Token(Token = "0x600261B")]
	[Address(RVA = "0x2D2E808", Offset = "0x2D2E808", VA = "0x2D2E808")]
	public void method_17()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x0600261C RID: 9756 RVA: 0x000476F0 File Offset: 0x000458F0
	[Token(Token = "0x600261C")]
	[Address(RVA = "0x2D2E8B8", Offset = "0x2D2E8B8", VA = "0x2D2E8B8")]
	public void method_18()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x0600261D RID: 9757 RVA: 0x000476D8 File Offset: 0x000458D8
	[Token(Token = "0x600261D")]
	[Address(RVA = "0x2D2E968", Offset = "0x2D2E968", VA = "0x2D2E968")]
	public void method_19()
	{
		if (this.bool_0)
		{
			return;
		}
	}

	// Token: 0x0600261E RID: 9758 RVA: 0x000476C0 File Offset: 0x000458C0
	[Address(RVA = "0x2D2EA34", Offset = "0x2D2EA34", VA = "0x2D2EA34")]
	[Token(Token = "0x600261E")]
	public void method_20()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600261F RID: 9759 RVA: 0x000476C0 File Offset: 0x000458C0
	[Address(RVA = "0x2D2EAB4", Offset = "0x2D2EAB4", VA = "0x2D2EAB4")]
	[Token(Token = "0x600261F")]
	public void method_21()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x06002620 RID: 9760 RVA: 0x000476D8 File Offset: 0x000458D8
	[Address(RVA = "0x2D2EB34", Offset = "0x2D2EB34", VA = "0x2D2EB34")]
	[Token(Token = "0x6002620")]
	public void method_22()
	{
		if (this.bool_0)
		{
			return;
		}
	}

	// Token: 0x06002621 RID: 9761 RVA: 0x000476B0 File Offset: 0x000458B0
	[Address(RVA = "0x2D2EC00", Offset = "0x2D2EC00", VA = "0x2D2EC00")]
	[Token(Token = "0x6002621")]
	public void method_23()
	{
	}

	// Token: 0x06002622 RID: 9762 RVA: 0x000476F0 File Offset: 0x000458F0
	[Token(Token = "0x6002622")]
	[Address(RVA = "0x2D2ECB0", Offset = "0x2D2ECB0", VA = "0x2D2ECB0")]
	public void method_24()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002623 RID: 9763 RVA: 0x000476C0 File Offset: 0x000458C0
	[Address(RVA = "0x2D2ED60", Offset = "0x2D2ED60", VA = "0x2D2ED60")]
	[Token(Token = "0x6002623")]
	public void method_25()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x06002624 RID: 9764 RVA: 0x000476F0 File Offset: 0x000458F0
	[Address(RVA = "0x2D2EDE0", Offset = "0x2D2EDE0", VA = "0x2D2EDE0")]
	[Token(Token = "0x6002624")]
	public void method_26()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002625 RID: 9765 RVA: 0x000476C0 File Offset: 0x000458C0
	[Address(RVA = "0x2D2EE90", Offset = "0x2D2EE90", VA = "0x2D2EE90")]
	[Token(Token = "0x6002625")]
	public void method_27()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x06002626 RID: 9766 RVA: 0x000476D8 File Offset: 0x000458D8
	[Address(RVA = "0x2D2EF10", Offset = "0x2D2EF10", VA = "0x2D2EF10")]
	[Token(Token = "0x6002626")]
	public void method_28()
	{
		if (this.bool_0)
		{
			return;
		}
	}

	// Token: 0x06002627 RID: 9767 RVA: 0x000476F0 File Offset: 0x000458F0
	[Address(RVA = "0x2D2EFDC", Offset = "0x2D2EFDC", VA = "0x2D2EFDC")]
	[Token(Token = "0x6002627")]
	public void method_29()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x06002628 RID: 9768 RVA: 0x000476B0 File Offset: 0x000458B0
	[Token(Token = "0x6002628")]
	[Address(RVA = "0x2D2F08C", Offset = "0x2D2F08C", VA = "0x2D2F08C")]
	public void method_30()
	{
	}

	// Token: 0x06002629 RID: 9769 RVA: 0x000476C0 File Offset: 0x000458C0
	[Token(Token = "0x6002629")]
	[Address(RVA = "0x2D2F13C", Offset = "0x2D2F13C", VA = "0x2D2F13C")]
	public void method_31()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x0600262A RID: 9770 RVA: 0x000476F0 File Offset: 0x000458F0
	[Address(RVA = "0x2D2F1BC", Offset = "0x2D2F1BC", VA = "0x2D2F1BC")]
	[Token(Token = "0x600262A")]
	public void method_32()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x0600262B RID: 9771 RVA: 0x000476F0 File Offset: 0x000458F0
	[Token(Token = "0x600262B")]
	[Address(RVA = "0x2D2F26C", Offset = "0x2D2F26C", VA = "0x2D2F26C")]
	public void method_33()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x0600262C RID: 9772 RVA: 0x000476D8 File Offset: 0x000458D8
	[Token(Token = "0x600262C")]
	[Address(RVA = "0x2D2F31C", Offset = "0x2D2F31C", VA = "0x2D2F31C")]
	public void Update()
	{
		if (this.bool_0)
		{
			return;
		}
	}

	// Token: 0x0600262D RID: 9773 RVA: 0x000476F0 File Offset: 0x000458F0
	[Address(RVA = "0x2D2F3E8", Offset = "0x2D2F3E8", VA = "0x2D2F3E8")]
	[Token(Token = "0x600262D")]
	public void method_34()
	{
		bool flag = this.bool_0;
		Renderer[] array = this.renderer_0;
		if (!flag)
		{
			return;
		}
		if (array == null)
		{
			return;
		}
	}

	// Token: 0x0600262E RID: 9774 RVA: 0x000476C0 File Offset: 0x000458C0
	[Token(Token = "0x600262E")]
	[Address(RVA = "0x2D2F498", Offset = "0x2D2F498", VA = "0x2D2F498")]
	public void method_35()
	{
		if (this.renderer_0 == null)
		{
			return;
		}
	}

	// Token: 0x040004E4 RID: 1252
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40004E4")]
	public Renderer[] renderer_0;

	// Token: 0x040004E5 RID: 1253
	[Token(Token = "0x40004E5")]
	[FieldOffset(Offset = "0x20")]
	public bool bool_0;

	// Token: 0x040004E6 RID: 1254
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40004E6")]
	public Material material_0;

	// Token: 0x040004E7 RID: 1255
	[Token(Token = "0x40004E7")]
	[FieldOffset(Offset = "0x30")]
	public Material material_1;
}
