﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x020000D8 RID: 216
[Token(Token = "0x20000D8")]
public class Logger : MonoBehaviour
{
	// Token: 0x06001FEB RID: 8171 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D55C", Offset = "0x241D55C", VA = "0x241D55C")]
	[Token(Token = "0x6001FEB")]
	private void method_0()
	{
	}

	// Token: 0x06001FEC RID: 8172 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D560", Offset = "0x241D560", VA = "0x241D560")]
	[Token(Token = "0x6001FEC")]
	private void method_1()
	{
	}

	// Token: 0x06001FED RID: 8173 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D564", Offset = "0x241D564", VA = "0x241D564")]
	[Token(Token = "0x6001FED")]
	private void method_2()
	{
	}

	// Token: 0x06001FEE RID: 8174 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FEE")]
	[Address(RVA = "0x241D568", Offset = "0x241D568", VA = "0x241D568")]
	private void method_3()
	{
	}

	// Token: 0x06001FEF RID: 8175 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6001FEF")]
	[Address(RVA = "0x241D56C", Offset = "0x241D56C", VA = "0x241D56C")]
	public Logger()
	{
	}

	// Token: 0x06001FF0 RID: 8176 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D574", Offset = "0x241D574", VA = "0x241D574")]
	[Token(Token = "0x6001FF0")]
	private void method_4()
	{
	}

	// Token: 0x06001FF1 RID: 8177 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FF1")]
	[Address(RVA = "0x241D578", Offset = "0x241D578", VA = "0x241D578")]
	private void method_5()
	{
	}

	// Token: 0x06001FF2 RID: 8178 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D57C", Offset = "0x241D57C", VA = "0x241D57C")]
	[Token(Token = "0x6001FF2")]
	private void method_6()
	{
	}

	// Token: 0x06001FF3 RID: 8179 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D580", Offset = "0x241D580", VA = "0x241D580")]
	[Token(Token = "0x6001FF3")]
	private void method_7()
	{
	}

	// Token: 0x06001FF4 RID: 8180 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FF4")]
	[Address(RVA = "0x241D584", Offset = "0x241D584", VA = "0x241D584")]
	private void method_8()
	{
	}

	// Token: 0x06001FF5 RID: 8181 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FF5")]
	[Address(RVA = "0x241D588", Offset = "0x241D588", VA = "0x241D588")]
	private void method_9()
	{
	}

	// Token: 0x06001FF6 RID: 8182 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FF6")]
	[Address(RVA = "0x241D58C", Offset = "0x241D58C", VA = "0x241D58C")]
	private void method_10()
	{
	}

	// Token: 0x06001FF7 RID: 8183 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D590", Offset = "0x241D590", VA = "0x241D590")]
	[Token(Token = "0x6001FF7")]
	private void method_11()
	{
	}

	// Token: 0x06001FF8 RID: 8184 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D594", Offset = "0x241D594", VA = "0x241D594")]
	[Token(Token = "0x6001FF8")]
	private void method_12()
	{
	}

	// Token: 0x06001FF9 RID: 8185 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FF9")]
	[Address(RVA = "0x241D598", Offset = "0x241D598", VA = "0x241D598")]
	private void Update()
	{
	}

	// Token: 0x06001FFA RID: 8186 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D59C", Offset = "0x241D59C", VA = "0x241D59C")]
	[Token(Token = "0x6001FFA")]
	private void method_13()
	{
	}

	// Token: 0x06001FFB RID: 8187 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FFB")]
	[Address(RVA = "0x241D5A0", Offset = "0x241D5A0", VA = "0x241D5A0")]
	private void method_14()
	{
	}

	// Token: 0x06001FFC RID: 8188 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6001FFC")]
	[Address(RVA = "0x241D5A4", Offset = "0x241D5A4", VA = "0x241D5A4")]
	private void method_15()
	{
	}

	// Token: 0x06001FFD RID: 8189 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5A8", Offset = "0x241D5A8", VA = "0x241D5A8")]
	[Token(Token = "0x6001FFD")]
	private void method_16()
	{
	}

	// Token: 0x06001FFE RID: 8190 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5AC", Offset = "0x241D5AC", VA = "0x241D5AC")]
	[Token(Token = "0x6001FFE")]
	private void method_17()
	{
	}

	// Token: 0x06001FFF RID: 8191 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5B0", Offset = "0x241D5B0", VA = "0x241D5B0")]
	[Token(Token = "0x6001FFF")]
	private void method_18()
	{
	}

	// Token: 0x06002000 RID: 8192 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002000")]
	[Address(RVA = "0x241D5B4", Offset = "0x241D5B4", VA = "0x241D5B4")]
	private void method_19()
	{
	}

	// Token: 0x06002001 RID: 8193 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002001")]
	[Address(RVA = "0x241D5B8", Offset = "0x241D5B8", VA = "0x241D5B8")]
	private void method_20()
	{
	}

	// Token: 0x06002002 RID: 8194 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5BC", Offset = "0x241D5BC", VA = "0x241D5BC")]
	[Token(Token = "0x6002002")]
	private void method_21()
	{
	}

	// Token: 0x06002003 RID: 8195 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5C0", Offset = "0x241D5C0", VA = "0x241D5C0")]
	[Token(Token = "0x6002003")]
	private void method_22()
	{
	}

	// Token: 0x06002004 RID: 8196 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002004")]
	[Address(RVA = "0x241D5C4", Offset = "0x241D5C4", VA = "0x241D5C4")]
	private void method_23()
	{
	}

	// Token: 0x06002005 RID: 8197 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5C8", Offset = "0x241D5C8", VA = "0x241D5C8")]
	[Token(Token = "0x6002005")]
	private void method_24()
	{
	}

	// Token: 0x06002006 RID: 8198 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002006")]
	[Address(RVA = "0x241D5CC", Offset = "0x241D5CC", VA = "0x241D5CC")]
	private void method_25()
	{
	}

	// Token: 0x06002007 RID: 8199 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002007")]
	[Address(RVA = "0x241D5D0", Offset = "0x241D5D0", VA = "0x241D5D0")]
	private void method_26()
	{
	}

	// Token: 0x06002008 RID: 8200 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002008")]
	[Address(RVA = "0x241D5D4", Offset = "0x241D5D4", VA = "0x241D5D4")]
	private void method_27()
	{
	}

	// Token: 0x06002009 RID: 8201 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5D8", Offset = "0x241D5D8", VA = "0x241D5D8")]
	[Token(Token = "0x6002009")]
	private void method_28()
	{
	}

	// Token: 0x0600200A RID: 8202 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5DC", Offset = "0x241D5DC", VA = "0x241D5DC")]
	[Token(Token = "0x600200A")]
	private void method_29()
	{
	}

	// Token: 0x0600200B RID: 8203 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600200B")]
	[Address(RVA = "0x241D5E0", Offset = "0x241D5E0", VA = "0x241D5E0")]
	private void method_30()
	{
	}

	// Token: 0x0600200C RID: 8204 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600200C")]
	[Address(RVA = "0x241D5E4", Offset = "0x241D5E4", VA = "0x241D5E4")]
	private void method_31()
	{
	}

	// Token: 0x0600200D RID: 8205 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5E8", Offset = "0x241D5E8", VA = "0x241D5E8")]
	[Token(Token = "0x600200D")]
	private void method_32()
	{
	}

	// Token: 0x0600200E RID: 8206 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600200E")]
	[Address(RVA = "0x241D5EC", Offset = "0x241D5EC", VA = "0x241D5EC")]
	private void method_33()
	{
	}

	// Token: 0x0600200F RID: 8207 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600200F")]
	[Address(RVA = "0x241D5F0", Offset = "0x241D5F0", VA = "0x241D5F0")]
	private void method_34()
	{
	}

	// Token: 0x06002010 RID: 8208 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5F4", Offset = "0x241D5F4", VA = "0x241D5F4")]
	[Token(Token = "0x6002010")]
	private void method_35()
	{
	}

	// Token: 0x06002011 RID: 8209 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002011")]
	[Address(RVA = "0x241D5F8", Offset = "0x241D5F8", VA = "0x241D5F8")]
	private void method_36()
	{
	}

	// Token: 0x06002012 RID: 8210 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D5FC", Offset = "0x241D5FC", VA = "0x241D5FC")]
	[Token(Token = "0x6002012")]
	private void method_37()
	{
	}

	// Token: 0x06002013 RID: 8211 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002013")]
	[Address(RVA = "0x241D600", Offset = "0x241D600", VA = "0x241D600")]
	private void method_38()
	{
	}

	// Token: 0x06002014 RID: 8212 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002014")]
	[Address(RVA = "0x241D604", Offset = "0x241D604", VA = "0x241D604")]
	private void method_39()
	{
	}

	// Token: 0x06002015 RID: 8213 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D608", Offset = "0x241D608", VA = "0x241D608")]
	[Token(Token = "0x6002015")]
	private void method_40()
	{
	}

	// Token: 0x06002016 RID: 8214 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002016")]
	[Address(RVA = "0x241D60C", Offset = "0x241D60C", VA = "0x241D60C")]
	private void method_41()
	{
	}

	// Token: 0x06002017 RID: 8215 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D610", Offset = "0x241D610", VA = "0x241D610")]
	[Token(Token = "0x6002017")]
	private void method_42()
	{
	}

	// Token: 0x06002018 RID: 8216 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002018")]
	[Address(RVA = "0x241D614", Offset = "0x241D614", VA = "0x241D614")]
	private void method_43()
	{
	}

	// Token: 0x06002019 RID: 8217 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002019")]
	[Address(RVA = "0x241D618", Offset = "0x241D618", VA = "0x241D618")]
	private void method_44()
	{
	}

	// Token: 0x0600201A RID: 8218 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600201A")]
	[Address(RVA = "0x241D61C", Offset = "0x241D61C", VA = "0x241D61C")]
	private void method_45()
	{
	}

	// Token: 0x0600201B RID: 8219 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D620", Offset = "0x241D620", VA = "0x241D620")]
	[Token(Token = "0x600201B")]
	private void method_46()
	{
	}

	// Token: 0x0600201C RID: 8220 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600201C")]
	[Address(RVA = "0x241D624", Offset = "0x241D624", VA = "0x241D624")]
	private void method_47()
	{
	}

	// Token: 0x0600201D RID: 8221 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600201D")]
	[Address(RVA = "0x241D628", Offset = "0x241D628", VA = "0x241D628")]
	private void method_48()
	{
	}

	// Token: 0x0600201E RID: 8222 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600201E")]
	[Address(RVA = "0x241D62C", Offset = "0x241D62C", VA = "0x241D62C")]
	private void method_49()
	{
	}

	// Token: 0x0600201F RID: 8223 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x600201F")]
	[Address(RVA = "0x241D630", Offset = "0x241D630", VA = "0x241D630")]
	private void method_50()
	{
	}

	// Token: 0x06002020 RID: 8224 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002020")]
	[Address(RVA = "0x241D634", Offset = "0x241D634", VA = "0x241D634")]
	private void method_51()
	{
	}

	// Token: 0x06002021 RID: 8225 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002021")]
	[Address(RVA = "0x241D638", Offset = "0x241D638", VA = "0x241D638")]
	private void method_52()
	{
	}

	// Token: 0x06002022 RID: 8226 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D63C", Offset = "0x241D63C", VA = "0x241D63C")]
	[Token(Token = "0x6002022")]
	private void method_53()
	{
	}

	// Token: 0x06002023 RID: 8227 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002023")]
	[Address(RVA = "0x241D640", Offset = "0x241D640", VA = "0x241D640")]
	private void method_54()
	{
	}

	// Token: 0x06002024 RID: 8228 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D644", Offset = "0x241D644", VA = "0x241D644")]
	[Token(Token = "0x6002024")]
	private void method_55()
	{
	}

	// Token: 0x06002025 RID: 8229 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D648", Offset = "0x241D648", VA = "0x241D648")]
	[Token(Token = "0x6002025")]
	private void method_56()
	{
	}

	// Token: 0x06002026 RID: 8230 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6002026")]
	[Address(RVA = "0x241D64C", Offset = "0x241D64C", VA = "0x241D64C")]
	private void method_57()
	{
	}

	// Token: 0x06002027 RID: 8231 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D650", Offset = "0x241D650", VA = "0x241D650")]
	[Token(Token = "0x6002027")]
	private void method_58()
	{
	}

	// Token: 0x06002028 RID: 8232 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D654", Offset = "0x241D654", VA = "0x241D654")]
	[Token(Token = "0x6002028")]
	private void method_59()
	{
	}

	// Token: 0x06002029 RID: 8233 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D658", Offset = "0x241D658", VA = "0x241D658")]
	[Token(Token = "0x6002029")]
	private void method_60()
	{
	}

	// Token: 0x0600202A RID: 8234 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D65C", Offset = "0x241D65C", VA = "0x241D65C")]
	[Token(Token = "0x600202A")]
	private void Start()
	{
	}

	// Token: 0x0600202B RID: 8235 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D660", Offset = "0x241D660", VA = "0x241D660")]
	[Token(Token = "0x600202B")]
	private void method_61()
	{
	}

	// Token: 0x0600202C RID: 8236 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D664", Offset = "0x241D664", VA = "0x241D664")]
	[Token(Token = "0x600202C")]
	private void method_62()
	{
	}

	// Token: 0x0600202D RID: 8237 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D668", Offset = "0x241D668", VA = "0x241D668")]
	[Token(Token = "0x600202D")]
	private void method_63()
	{
	}

	// Token: 0x0600202E RID: 8238 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D66C", Offset = "0x241D66C", VA = "0x241D66C")]
	[Token(Token = "0x600202E")]
	private void method_64()
	{
	}

	// Token: 0x0600202F RID: 8239 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D670", Offset = "0x241D670", VA = "0x241D670")]
	[Token(Token = "0x600202F")]
	private void method_65()
	{
	}

	// Token: 0x06002030 RID: 8240 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D674", Offset = "0x241D674", VA = "0x241D674")]
	[Token(Token = "0x6002030")]
	private void method_66()
	{
	}

	// Token: 0x06002031 RID: 8241 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D678", Offset = "0x241D678", VA = "0x241D678")]
	[Token(Token = "0x6002031")]
	private void method_67()
	{
	}

	// Token: 0x06002032 RID: 8242 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D67C", Offset = "0x241D67C", VA = "0x241D67C")]
	[Token(Token = "0x6002032")]
	private void method_68()
	{
	}

	// Token: 0x06002033 RID: 8243 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D680", Offset = "0x241D680", VA = "0x241D680")]
	[Token(Token = "0x6002033")]
	private void method_69()
	{
	}

	// Token: 0x06002034 RID: 8244 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D684", Offset = "0x241D684", VA = "0x241D684")]
	[Token(Token = "0x6002034")]
	private void method_70()
	{
	}

	// Token: 0x06002035 RID: 8245 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D688", Offset = "0x241D688", VA = "0x241D688")]
	[Token(Token = "0x6002035")]
	private void method_71()
	{
	}

	// Token: 0x06002036 RID: 8246 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D68C", Offset = "0x241D68C", VA = "0x241D68C")]
	[Token(Token = "0x6002036")]
	private void method_72()
	{
	}

	// Token: 0x06002037 RID: 8247 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D690", Offset = "0x241D690", VA = "0x241D690")]
	[Token(Token = "0x6002037")]
	private void method_73()
	{
	}

	// Token: 0x06002038 RID: 8248 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D694", Offset = "0x241D694", VA = "0x241D694")]
	[Token(Token = "0x6002038")]
	private void method_74()
	{
	}

	// Token: 0x06002039 RID: 8249 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D698", Offset = "0x241D698", VA = "0x241D698")]
	[Token(Token = "0x6002039")]
	private void method_75()
	{
	}

	// Token: 0x0600203A RID: 8250 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D69C", Offset = "0x241D69C", VA = "0x241D69C")]
	[Token(Token = "0x600203A")]
	private void method_76()
	{
	}

	// Token: 0x0600203B RID: 8251 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D6A0", Offset = "0x241D6A0", VA = "0x241D6A0")]
	[Token(Token = "0x600203B")]
	private void method_77()
	{
	}

	// Token: 0x0600203C RID: 8252 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D6A4", Offset = "0x241D6A4", VA = "0x241D6A4")]
	[Token(Token = "0x600203C")]
	private void method_78()
	{
	}

	// Token: 0x0600203D RID: 8253 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D6A8", Offset = "0x241D6A8", VA = "0x241D6A8")]
	[Token(Token = "0x600203D")]
	private void method_79()
	{
	}

	// Token: 0x0600203E RID: 8254 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D6AC", Offset = "0x241D6AC", VA = "0x241D6AC")]
	[Token(Token = "0x600203E")]
	private void method_80()
	{
	}

	// Token: 0x0600203F RID: 8255 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x241D6B0", Offset = "0x241D6B0", VA = "0x241D6B0")]
	[Token(Token = "0x600203F")]
	private void method_81()
	{
	}
}
