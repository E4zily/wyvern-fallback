﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x02000046 RID: 70
[Token(Token = "0x2000046")]
public class SwitchColorSelector : MonoBehaviour
{
	// Token: 0x06000930 RID: 2352 RVA: 0x000138B4 File Offset: 0x00011AB4
	[Address(RVA = "0x3088460", Offset = "0x3088460", VA = "0x3088460")]
	[Token(Token = "0x6000930")]
	public void method_0(Collider collider_0)
	{
		collider_0.gameObject.tag == "friend";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x000139A0 File Offset: 0x00011BA0
	[Address(RVA = "0x30885B8", Offset = "0x30885B8", VA = "0x30885B8")]
	[Token(Token = "0x6000931")]
	public void method_1(Collider collider_0)
	{
		collider_0.gameObject.tag == "Horizontal";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x00013A8C File Offset: 0x00011C8C
	[Address(RVA = "0x3088710", Offset = "0x3088710", VA = "0x3088710")]
	[Token(Token = "0x6000932")]
	public void method_2(Collider collider_0)
	{
		collider_0.gameObject.tag == "HandL";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x00013B78 File Offset: 0x00011D78
	[Token(Token = "0x6000933")]
	[Address(RVA = "0x3088868", Offset = "0x3088868", VA = "0x3088868")]
	public void method_3(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.gameObject_2.SetActive(active2 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x00013C5C File Offset: 0x00011E5C
	[Address(RVA = "0x30889C0", Offset = "0x30889C0", VA = "0x30889C0")]
	[Token(Token = "0x6000934")]
	public void method_4(Collider collider_0)
	{
		collider_0.gameObject.tag == "Open";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x00013D48 File Offset: 0x00011F48
	[Address(RVA = "0x3088B18", Offset = "0x3088B18", VA = "0x3088B18")]
	[Token(Token = "0x6000935")]
	public void method_5(Collider collider_0)
	{
		collider_0.gameObject.tag == "Regular";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000936 RID: 2358 RVA: 0x00013E34 File Offset: 0x00012034
	[Address(RVA = "0x3088C70", Offset = "0x3088C70", VA = "0x3088C70")]
	[Token(Token = "0x6000936")]
	public void method_6(Collider collider_0)
	{
		collider_0.gameObject.tag == "true";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			this.gameObject_2.SetActive(active2 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			this.gameObject_2.SetActive(active7 != 0L);
			return;
		}
	}

	// Token: 0x06000937 RID: 2359 RVA: 0x00013F10 File Offset: 0x00012110
	[Address(RVA = "0x3088DC8", Offset = "0x3088DC8", VA = "0x3088DC8")]
	[Token(Token = "0x6000937")]
	public void method_7(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x00013FFC File Offset: 0x000121FC
	[Token(Token = "0x6000938")]
	[Address(RVA = "0x3088F20", Offset = "0x3088F20", VA = "0x3088F20")]
	public void method_8(Collider collider_0)
	{
		collider_0.gameObject.tag == "SaveHeight";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			this.gameObject_2.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			this.gameObject_1.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_2;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			return;
		}
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x000140D8 File Offset: 0x000122D8
	[Token(Token = "0x6000939")]
	[Address(RVA = "0x3089078", Offset = "0x3089078", VA = "0x3089078")]
	public void method_9(Collider collider_0)
	{
		collider_0.gameObject.tag == "Name Changing Error. Error: ";
		long active2;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_1;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_2;
			active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_1)
		{
			this.gameObject_0.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_1;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
			GameObject gameObject4 = this.gameObject_2;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject5 = this.gameObject_0;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_1;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_2;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			return;
		}
	}

	// Token: 0x0600093A RID: 2362 RVA: 0x000141AC File Offset: 0x000123AC
	[Address(RVA = "0x30891D0", Offset = "0x30891D0", VA = "0x30891D0")]
	[Token(Token = "0x600093A")]
	public void method_10(Collider collider_0)
	{
		collider_0.gameObject.tag == "betaAgree";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			this.gameObject_1.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x0600093B RID: 2363 RVA: 0x00014290 File Offset: 0x00012490
	[Address(RVA = "0x3089328", Offset = "0x3089328", VA = "0x3089328")]
	[Token(Token = "0x600093B")]
	public void method_11(Collider collider_0)
	{
		collider_0.gameObject.tag == "tp 2";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600093C RID: 2364 RVA: 0x0001437C File Offset: 0x0001257C
	[Address(RVA = "0x3089480", Offset = "0x3089480", VA = "0x3089480")]
	[Token(Token = "0x600093C")]
	public void method_12(Collider collider_0)
	{
		collider_0.gameObject.tag == "\tExpires: ";
		bool flag;
		if (flag = this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (flag)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600093D RID: 2365 RVA: 0x00014468 File Offset: 0x00012668
	[Token(Token = "0x600093D")]
	[Address(RVA = "0x30895D8", Offset = "0x30895D8", VA = "0x30895D8")]
	public void method_13(Collider collider_0)
	{
		collider_0.gameObject.tag == "Photon token acquired!";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		bool flag;
		long active6;
		if (flag = this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (flag)
		{
			this.gameObject_0.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x0600093E RID: 2366 RVA: 0x0001454C File Offset: 0x0001274C
	[Address(RVA = "0x3089730", Offset = "0x3089730", VA = "0x3089730")]
	[Token(Token = "0x600093E")]
	public void method_14(Collider collider_0)
	{
		string tag = collider_0.gameObject.tag;
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600093F RID: 2367 RVA: 0x00014630 File Offset: 0x00012830
	[Address(RVA = "0x3089888", Offset = "0x3089888", VA = "0x3089888")]
	[Token(Token = "0x600093F")]
	public void method_15(Collider collider_0)
	{
		collider_0.gameObject.tag == "_Color";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000940 RID: 2368 RVA: 0x0001471C File Offset: 0x0001291C
	[Address(RVA = "0x30899E0", Offset = "0x30899E0", VA = "0x30899E0")]
	[Token(Token = "0x6000940")]
	public void method_16(Collider collider_0)
	{
		collider_0.gameObject.tag == "EnableCosmetic";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000941 RID: 2369 RVA: 0x00014808 File Offset: 0x00012A08
	[Token(Token = "0x6000941")]
	[Address(RVA = "0x3089B38", Offset = "0x3089B38", VA = "0x3089B38")]
	public void method_17(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000942 RID: 2370 RVA: 0x000148F4 File Offset: 0x00012AF4
	[Address(RVA = "0x3089C90", Offset = "0x3089C90", VA = "0x3089C90")]
	[Token(Token = "0x6000942")]
	public void method_18(Collider collider_0)
	{
		collider_0.gameObject.tag == "NetworkGunShoot";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000943 RID: 2371 RVA: 0x000149E0 File Offset: 0x00012BE0
	[Address(RVA = "0x3089DE8", Offset = "0x3089DE8", VA = "0x3089DE8")]
	[Token(Token = "0x6000943")]
	public void method_19(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vector1_d371bd24217449349bd747533d51af6b";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000944 RID: 2372 RVA: 0x00014ACC File Offset: 0x00012CCC
	[Address(RVA = "0x3089F40", Offset = "0x3089F40", VA = "0x3089F40")]
	[Token(Token = "0x6000944")]
	public void method_20(Collider collider_0)
	{
		collider_0.gameObject.tag == "windowsmr";
	}

	// Token: 0x06000945 RID: 2373 RVA: 0x00014AF0 File Offset: 0x00012CF0
	[Address(RVA = "0x308A098", Offset = "0x308A098", VA = "0x308A098")]
	[Token(Token = "0x6000945")]
	public void method_21(Collider collider_0)
	{
		collider_0.gameObject.tag == "Key";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000946 RID: 2374 RVA: 0x00014BDC File Offset: 0x00012DDC
	[Token(Token = "0x6000946")]
	[Address(RVA = "0x308A1F0", Offset = "0x308A1F0", VA = "0x308A1F0")]
	public void method_22(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000947 RID: 2375 RVA: 0x00014CC8 File Offset: 0x00012EC8
	[Address(RVA = "0x308A348", Offset = "0x308A348", VA = "0x308A348")]
	[Token(Token = "0x6000947")]
	public void method_23(Collider collider_0)
	{
		collider_0.gameObject.tag == "Right Hand";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			this.gameObject_2.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x06000948 RID: 2376 RVA: 0x00014DAC File Offset: 0x00012FAC
	[Token(Token = "0x6000948")]
	[Address(RVA = "0x308A4A0", Offset = "0x308A4A0", VA = "0x308A4A0")]
	public void method_24(Collider collider_0)
	{
		collider_0.gameObject.tag == "Agreed";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000949 RID: 2377 RVA: 0x00014E98 File Offset: 0x00013098
	[Token(Token = "0x6000949")]
	[Address(RVA = "0x308A5F8", Offset = "0x308A5F8", VA = "0x308A5F8")]
	public void method_25(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		GameObject gameObject6;
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			long active7 = 0L;
			gameObject6.SetActive(active7 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active8 = 0L;
			gameObject7.SetActive(active8 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active9 = 1L;
			gameObject8.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600094A RID: 2378 RVA: 0x00014F7C File Offset: 0x0001317C
	[Token(Token = "0x600094A")]
	[Address(RVA = "0x308A750", Offset = "0x308A750", VA = "0x308A750")]
	public void method_26(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Already Own This Item";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600094B RID: 2379 RVA: 0x00015068 File Offset: 0x00013268
	[Token(Token = "0x600094B")]
	[Address(RVA = "0x308A8A8", Offset = "0x308A8A8", VA = "0x308A8A8")]
	public void method_27(Collider collider_0)
	{
		collider_0.gameObject.tag == "hand 2";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			this.gameObject_2.SetActive(active2 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x0600094C RID: 2380 RVA: 0x0001514C File Offset: 0x0001334C
	[Address(RVA = "0x308AA00", Offset = "0x308AA00", VA = "0x308AA00")]
	[Token(Token = "0x600094C")]
	public void method_28(Collider collider_0)
	{
		collider_0.gameObject.tag == "{0}/{1:f0}";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600094D RID: 2381 RVA: 0x00015238 File Offset: 0x00013438
	[Token(Token = "0x600094D")]
	[Address(RVA = "0x308AB58", Offset = "0x308AB58", VA = "0x308AB58")]
	public void method_29(Collider collider_0)
	{
		collider_0.gameObject.tag == "Player";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600094E RID: 2382 RVA: 0x00015324 File Offset: 0x00013524
	[Token(Token = "0x600094E")]
	[Address(RVA = "0x308ACB0", Offset = "0x308ACB0", VA = "0x308ACB0")]
	public void method_30(Collider collider_0)
	{
		collider_0.gameObject.tag == " and the correct version is ";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600094F RID: 2383 RVA: 0x00015410 File Offset: 0x00013610
	[Address(RVA = "0x308AE08", Offset = "0x308AE08", VA = "0x308AE08")]
	[Token(Token = "0x600094F")]
	public void method_31(Collider collider_0)
	{
		collider_0.gameObject.tag == "You have been banned for ";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			this.gameObject_1.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x06000950 RID: 2384 RVA: 0x000154F4 File Offset: 0x000136F4
	[Address(RVA = "0x308AF60", Offset = "0x308AF60", VA = "0x308AF60")]
	[Token(Token = "0x6000950")]
	public void method_32(Collider collider_0)
	{
		collider_0.gameObject.tag == "closeToObject";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000951 RID: 2385 RVA: 0x000155E0 File Offset: 0x000137E0
	[Address(RVA = "0x308B0B8", Offset = "0x308B0B8", VA = "0x308B0B8")]
	[Token(Token = "0x6000951")]
	public void method_33(Collider collider_0)
	{
		collider_0.gameObject.tag == ". Please update you game to the latest version";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x000156CC File Offset: 0x000138CC
	[Address(RVA = "0x308B210", Offset = "0x308B210", VA = "0x308B210")]
	[Token(Token = "0x6000952")]
	public void method_34(Collider collider_0)
	{
		collider_0.gameObject.tag == "CapuchinRemade";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000953 RID: 2387 RVA: 0x000157B8 File Offset: 0x000139B8
	[Token(Token = "0x6000953")]
	[Address(RVA = "0x308B368", Offset = "0x308B368", VA = "0x308B368")]
	public void method_35(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000954 RID: 2388 RVA: 0x000158A4 File Offset: 0x00013AA4
	[Token(Token = "0x6000954")]
	[Address(RVA = "0x308B4C0", Offset = "0x308B4C0", VA = "0x308B4C0")]
	public void method_36(Collider collider_0)
	{
		collider_0.gameObject.tag == "Connected to Server.";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000955 RID: 2389 RVA: 0x00015990 File Offset: 0x00013B90
	[Address(RVA = "0x308B618", Offset = "0x308B618", VA = "0x308B618")]
	[Token(Token = "0x6000955")]
	public void method_37(Collider collider_0)
	{
		collider_0.gameObject.tag == "";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000956 RID: 2390 RVA: 0x00015A7C File Offset: 0x00013C7C
	[Token(Token = "0x6000956")]
	[Address(RVA = "0x308B770", Offset = "0x308B770", VA = "0x308B770")]
	public void OnTriggerEnter(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000957 RID: 2391 RVA: 0x00015B68 File Offset: 0x00013D68
	[Address(RVA = "0x308B8C8", Offset = "0x308B8C8", VA = "0x308B8C8")]
	[Token(Token = "0x6000957")]
	public void method_38(Collider collider_0)
	{
		collider_0.gameObject.tag == "User is on an outdated version of Capuchin. Your version is ";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000958 RID: 2392 RVA: 0x00015C54 File Offset: 0x00013E54
	[Token(Token = "0x6000958")]
	[Address(RVA = "0x308BA20", Offset = "0x308BA20", VA = "0x308BA20")]
	public void method_39(Collider collider_0)
	{
		collider_0.gameObject.tag == "Vertical";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000959 RID: 2393 RVA: 0x00015D40 File Offset: 0x00013F40
	[Address(RVA = "0x308BB78", Offset = "0x308BB78", VA = "0x308BB78")]
	[Token(Token = "0x6000959")]
	public void method_40(Collider collider_0)
	{
		collider_0.gameObject.tag == "openvr";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			long active2 = 1L;
			gameObject.SetActive(active2 != 0L);
			GameObject gameObject2 = this.gameObject_2;
			long active3 = 1L;
			gameObject2.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active4 = 1L;
			gameObject3.SetActive(active4 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active5 = 1L;
			gameObject4.SetActive(active5 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active6 = 0L;
			gameObject5.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active7 = 1L;
			gameObject6.SetActive(active7 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active8 = 0L;
			gameObject7.SetActive(active8 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active9 = 1L;
			gameObject8.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600095A RID: 2394 RVA: 0x00015E24 File Offset: 0x00014024
	[Address(RVA = "0x308BCD0", Offset = "0x308BCD0", VA = "0x308BCD0")]
	[Token(Token = "0x600095A")]
	public void method_41(Collider collider_0)
	{
		collider_0.gameObject.tag == "Game Started";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600095B RID: 2395 RVA: 0x00015F10 File Offset: 0x00014110
	[Address(RVA = "0x308BE28", Offset = "0x308BE28", VA = "0x308BE28")]
	[Token(Token = "0x600095B")]
	public void method_42(Collider collider_0)
	{
		collider_0.gameObject.tag == "_BumpMap";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600095C RID: 2396 RVA: 0x00015FFC File Offset: 0x000141FC
	[Token(Token = "0x600095C")]
	[Address(RVA = "0x308BF80", Offset = "0x308BF80", VA = "0x308BF80")]
	public void method_43(Collider collider_0)
	{
		collider_0.gameObject.tag == "FingerTip";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600095D RID: 2397 RVA: 0x000160E8 File Offset: 0x000142E8
	[Token(Token = "0x600095D")]
	[Address(RVA = "0x308C0D8", Offset = "0x308C0D8", VA = "0x308C0D8")]
	public void method_44(Collider collider_0)
	{
		collider_0.gameObject.tag == "ChangeToTagged";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x0600095E RID: 2398 RVA: 0x000161D4 File Offset: 0x000143D4
	[Token(Token = "0x600095E")]
	[Address(RVA = "0x308C230", Offset = "0x308C230", VA = "0x308C230")]
	public void method_45(Collider collider_0)
	{
		collider_0.gameObject.tag == "1BN";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			this.gameObject_1.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_2;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			return;
		}
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x000162B8 File Offset: 0x000144B8
	[Address(RVA = "0x308C388", Offset = "0x308C388", VA = "0x308C388")]
	[Token(Token = "0x600095F")]
	public void method_46(Collider collider_0)
	{
		collider_0.gameObject.tag == "You Already Own This Item";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		bool flag;
		if (flag = this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 0L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (flag)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x00002060 File Offset: 0x00000260
	[Token(Token = "0x6000960")]
	[Address(RVA = "0x308C4E0", Offset = "0x308C4E0", VA = "0x308C4E0")]
	public SwitchColorSelector()
	{
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x000163A4 File Offset: 0x000145A4
	[Address(RVA = "0x308C4E8", Offset = "0x308C4E8", VA = "0x308C4E8")]
	[Token(Token = "0x6000961")]
	public void method_47(Collider collider_0)
	{
		collider_0.gameObject.tag == "PlayerDeath";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000962 RID: 2402 RVA: 0x00016490 File Offset: 0x00014690
	[Address(RVA = "0x308C640", Offset = "0x308C640", VA = "0x308C640")]
	[Token(Token = "0x6000962")]
	public void method_48(Collider collider_0)
	{
		collider_0.gameObject.tag == "Downloading image";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 1L;
			gameObject2.SetActive(active2 != 0L);
			long active3 = 1L;
			gameObject2.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject3 = this.gameObject_0;
			long active4 = 0L;
			gameObject3.SetActive(active4 != 0L);
			GameObject gameObject4 = this.gameObject_1;
			long active5 = 0L;
			gameObject4.SetActive(active5 != 0L);
			GameObject gameObject5 = this.gameObject_2;
			long active6 = 1L;
			gameObject5.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject6 = this.gameObject_0;
			long active7 = 0L;
			gameObject6.SetActive(active7 != 0L);
			GameObject gameObject7 = this.gameObject_1;
			long active8 = 0L;
			gameObject7.SetActive(active8 != 0L);
			GameObject gameObject8 = this.gameObject_2;
			long active9 = 0L;
			gameObject8.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000963 RID: 2403 RVA: 0x00016574 File Offset: 0x00014774
	[Address(RVA = "0x308C798", Offset = "0x308C798", VA = "0x308C798")]
	[Token(Token = "0x6000963")]
	public void method_49(Collider collider_0)
	{
		collider_0.gameObject.tag == "oculus";
	}

	// Token: 0x06000964 RID: 2404 RVA: 0x00016598 File Offset: 0x00014798
	[Address(RVA = "0x308C8F0", Offset = "0x308C8F0", VA = "0x308C8F0")]
	[Token(Token = "0x6000964")]
	public void method_50(Collider collider_0)
	{
		collider_0.gameObject.tag == "Start Gamemode";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 1L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 1L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 1L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 0L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 1L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 0L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 0L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x06000965 RID: 2405 RVA: 0x00016684 File Offset: 0x00014884
	[Token(Token = "0x6000965")]
	[Address(RVA = "0x308CA48", Offset = "0x308CA48", VA = "0x308CA48")]
	public void method_51(Collider collider_0)
	{
		collider_0.gameObject.tag == "Try Connect To Server...";
		if (this.bool_0)
		{
			GameObject gameObject = this.gameObject_0;
			long active = 0L;
			gameObject.SetActive(active != 0L);
			GameObject gameObject2 = this.gameObject_1;
			long active2 = 0L;
			gameObject2.SetActive(active2 != 0L);
			GameObject gameObject3 = this.gameObject_2;
			long active3 = 0L;
			gameObject3.SetActive(active3 != 0L);
		}
		if (this.bool_1)
		{
			GameObject gameObject4 = this.gameObject_0;
			long active4 = 0L;
			gameObject4.SetActive(active4 != 0L);
			GameObject gameObject5 = this.gameObject_1;
			long active5 = 1L;
			gameObject5.SetActive(active5 != 0L);
			GameObject gameObject6 = this.gameObject_2;
			long active6 = 1L;
			gameObject6.SetActive(active6 != 0L);
		}
		if (this.bool_2)
		{
			GameObject gameObject7 = this.gameObject_0;
			long active7 = 0L;
			gameObject7.SetActive(active7 != 0L);
			GameObject gameObject8 = this.gameObject_1;
			long active8 = 1L;
			gameObject8.SetActive(active8 != 0L);
			GameObject gameObject9 = this.gameObject_2;
			long active9 = 1L;
			gameObject9.SetActive(active9 != 0L);
			return;
		}
	}

	// Token: 0x04000167 RID: 359
	[Token(Token = "0x4000167")]
	[FieldOffset(Offset = "0x18")]
	public bool bool_0;

	// Token: 0x04000168 RID: 360
	[Token(Token = "0x4000168")]
	[FieldOffset(Offset = "0x19")]
	public bool bool_1;

	// Token: 0x04000169 RID: 361
	[Token(Token = "0x4000169")]
	[FieldOffset(Offset = "0x1A")]
	public bool bool_2;

	// Token: 0x0400016A RID: 362
	[Token(Token = "0x400016A")]
	[FieldOffset(Offset = "0x20")]
	public GameObject gameObject_0;

	// Token: 0x0400016B RID: 363
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400016B")]
	public GameObject gameObject_1;

	// Token: 0x0400016C RID: 364
	[Token(Token = "0x400016C")]
	[FieldOffset(Offset = "0x30")]
	public GameObject gameObject_2;
}
