﻿using System;
using Cpp2IlInjected;
using UnityEngine;

// Token: 0x0200004C RID: 76
[Token(Token = "0x200004C")]
public class Charger : MonoBehaviour
{
	// Token: 0x06000A35 RID: 2613 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A35")]
	[Address(RVA = "0x2AF01AC", Offset = "0x2AF01AC", VA = "0x2AF01AC")]
	private void method_0()
	{
	}

	// Token: 0x06000A36 RID: 2614 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01B0", Offset = "0x2AF01B0", VA = "0x2AF01B0")]
	[Token(Token = "0x6000A36")]
	private void method_1()
	{
	}

	// Token: 0x06000A37 RID: 2615 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01B4", Offset = "0x2AF01B4", VA = "0x2AF01B4")]
	[Token(Token = "0x6000A37")]
	private void method_2()
	{
	}

	// Token: 0x06000A38 RID: 2616 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A38")]
	[Address(RVA = "0x2AF01B8", Offset = "0x2AF01B8", VA = "0x2AF01B8")]
	private void method_3()
	{
	}

	// Token: 0x06000A39 RID: 2617 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01BC", Offset = "0x2AF01BC", VA = "0x2AF01BC")]
	[Token(Token = "0x6000A39")]
	private void method_4()
	{
	}

	// Token: 0x06000A3A RID: 2618 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01C0", Offset = "0x2AF01C0", VA = "0x2AF01C0")]
	[Token(Token = "0x6000A3A")]
	private void method_5()
	{
	}

	// Token: 0x06000A3B RID: 2619 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01C4", Offset = "0x2AF01C4", VA = "0x2AF01C4")]
	[Token(Token = "0x6000A3B")]
	private void method_6()
	{
	}

	// Token: 0x06000A3C RID: 2620 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01C8", Offset = "0x2AF01C8", VA = "0x2AF01C8")]
	[Token(Token = "0x6000A3C")]
	private void method_7()
	{
	}

	// Token: 0x06000A3D RID: 2621 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A3D")]
	[Address(RVA = "0x2AF01CC", Offset = "0x2AF01CC", VA = "0x2AF01CC")]
	private void method_8()
	{
	}

	// Token: 0x06000A3E RID: 2622 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A3E")]
	[Address(RVA = "0x2AF01D0", Offset = "0x2AF01D0", VA = "0x2AF01D0")]
	private void method_9()
	{
	}

	// Token: 0x06000A3F RID: 2623 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A3F")]
	[Address(RVA = "0x2AF01D4", Offset = "0x2AF01D4", VA = "0x2AF01D4")]
	private void method_10()
	{
	}

	// Token: 0x06000A40 RID: 2624 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A40")]
	[Address(RVA = "0x2AF01D8", Offset = "0x2AF01D8", VA = "0x2AF01D8")]
	private void method_11()
	{
	}

	// Token: 0x06000A41 RID: 2625 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A41")]
	[Address(RVA = "0x2AF01DC", Offset = "0x2AF01DC", VA = "0x2AF01DC")]
	private void method_12()
	{
	}

	// Token: 0x06000A42 RID: 2626 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A42")]
	[Address(RVA = "0x2AF01E0", Offset = "0x2AF01E0", VA = "0x2AF01E0")]
	private void method_13()
	{
	}

	// Token: 0x06000A43 RID: 2627 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A43")]
	[Address(RVA = "0x2AF01E4", Offset = "0x2AF01E4", VA = "0x2AF01E4")]
	private void method_14()
	{
	}

	// Token: 0x06000A44 RID: 2628 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A44")]
	[Address(RVA = "0x2AF01E8", Offset = "0x2AF01E8", VA = "0x2AF01E8")]
	private void method_15()
	{
	}

	// Token: 0x06000A45 RID: 2629 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01EC", Offset = "0x2AF01EC", VA = "0x2AF01EC")]
	[Token(Token = "0x6000A45")]
	private void method_16()
	{
	}

	// Token: 0x06000A46 RID: 2630 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01F0", Offset = "0x2AF01F0", VA = "0x2AF01F0")]
	[Token(Token = "0x6000A46")]
	private void method_17()
	{
	}

	// Token: 0x06000A47 RID: 2631 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A47")]
	[Address(RVA = "0x2AF01F4", Offset = "0x2AF01F4", VA = "0x2AF01F4")]
	private void method_18()
	{
	}

	// Token: 0x06000A48 RID: 2632 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01F8", Offset = "0x2AF01F8", VA = "0x2AF01F8")]
	[Token(Token = "0x6000A48")]
	private void method_19()
	{
	}

	// Token: 0x06000A49 RID: 2633 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF01FC", Offset = "0x2AF01FC", VA = "0x2AF01FC")]
	[Token(Token = "0x6000A49")]
	private void method_20()
	{
	}

	// Token: 0x06000A4A RID: 2634 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A4A")]
	[Address(RVA = "0x2AF0200", Offset = "0x2AF0200", VA = "0x2AF0200")]
	private void method_21()
	{
	}

	// Token: 0x06000A4B RID: 2635 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A4B")]
	[Address(RVA = "0x2AF0204", Offset = "0x2AF0204", VA = "0x2AF0204")]
	private void method_22()
	{
	}

	// Token: 0x06000A4C RID: 2636 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0208", Offset = "0x2AF0208", VA = "0x2AF0208")]
	[Token(Token = "0x6000A4C")]
	private void method_23()
	{
	}

	// Token: 0x06000A4D RID: 2637 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A4D")]
	[Address(RVA = "0x2AF020C", Offset = "0x2AF020C", VA = "0x2AF020C")]
	private void method_24()
	{
	}

	// Token: 0x06000A4E RID: 2638 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0210", Offset = "0x2AF0210", VA = "0x2AF0210")]
	[Token(Token = "0x6000A4E")]
	private void method_25()
	{
	}

	// Token: 0x06000A4F RID: 2639 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A4F")]
	[Address(RVA = "0x2AF0214", Offset = "0x2AF0214", VA = "0x2AF0214")]
	private void method_26()
	{
	}

	// Token: 0x06000A50 RID: 2640 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A50")]
	[Address(RVA = "0x2AF0218", Offset = "0x2AF0218", VA = "0x2AF0218")]
	private void method_27()
	{
	}

	// Token: 0x06000A51 RID: 2641 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A51")]
	[Address(RVA = "0x2AF021C", Offset = "0x2AF021C", VA = "0x2AF021C")]
	private void method_28()
	{
	}

	// Token: 0x06000A52 RID: 2642 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A52")]
	[Address(RVA = "0x2AF0220", Offset = "0x2AF0220", VA = "0x2AF0220")]
	private void method_29()
	{
	}

	// Token: 0x06000A53 RID: 2643 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A53")]
	[Address(RVA = "0x2AF0224", Offset = "0x2AF0224", VA = "0x2AF0224")]
	private void method_30()
	{
	}

	// Token: 0x06000A54 RID: 2644 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A54")]
	[Address(RVA = "0x2AF0228", Offset = "0x2AF0228", VA = "0x2AF0228")]
	private void method_31()
	{
	}

	// Token: 0x06000A55 RID: 2645 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A55")]
	[Address(RVA = "0x2AF022C", Offset = "0x2AF022C", VA = "0x2AF022C")]
	private void method_32()
	{
	}

	// Token: 0x06000A56 RID: 2646 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A56")]
	[Address(RVA = "0x2AF0230", Offset = "0x2AF0230", VA = "0x2AF0230")]
	private void method_33()
	{
	}

	// Token: 0x06000A57 RID: 2647 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A57")]
	[Address(RVA = "0x2AF0234", Offset = "0x2AF0234", VA = "0x2AF0234")]
	private void method_34()
	{
	}

	// Token: 0x06000A58 RID: 2648 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A58")]
	[Address(RVA = "0x2AF0238", Offset = "0x2AF0238", VA = "0x2AF0238")]
	private void method_35()
	{
	}

	// Token: 0x06000A59 RID: 2649 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A59")]
	[Address(RVA = "0x2AF023C", Offset = "0x2AF023C", VA = "0x2AF023C")]
	private void method_36()
	{
	}

	// Token: 0x06000A5A RID: 2650 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A5A")]
	[Address(RVA = "0x2AF0240", Offset = "0x2AF0240", VA = "0x2AF0240")]
	private void method_37()
	{
	}

	// Token: 0x06000A5B RID: 2651 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A5B")]
	[Address(RVA = "0x2AF0244", Offset = "0x2AF0244", VA = "0x2AF0244")]
	private void method_38()
	{
	}

	// Token: 0x06000A5C RID: 2652 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0248", Offset = "0x2AF0248", VA = "0x2AF0248")]
	[Token(Token = "0x6000A5C")]
	private void method_39()
	{
	}

	// Token: 0x06000A5D RID: 2653 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A5D")]
	[Address(RVA = "0x2AF024C", Offset = "0x2AF024C", VA = "0x2AF024C")]
	private void method_40()
	{
	}

	// Token: 0x06000A5E RID: 2654 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0250", Offset = "0x2AF0250", VA = "0x2AF0250")]
	[Token(Token = "0x6000A5E")]
	private void method_41()
	{
	}

	// Token: 0x06000A5F RID: 2655 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0254", Offset = "0x2AF0254", VA = "0x2AF0254")]
	[Token(Token = "0x6000A5F")]
	private void Update()
	{
	}

	// Token: 0x06000A60 RID: 2656 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A60")]
	[Address(RVA = "0x2AF0258", Offset = "0x2AF0258", VA = "0x2AF0258")]
	private void method_42()
	{
	}

	// Token: 0x06000A61 RID: 2657 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A61")]
	[Address(RVA = "0x2AF025C", Offset = "0x2AF025C", VA = "0x2AF025C")]
	private void method_43()
	{
	}

	// Token: 0x06000A62 RID: 2658 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0260", Offset = "0x2AF0260", VA = "0x2AF0260")]
	[Token(Token = "0x6000A62")]
	private void method_44()
	{
	}

	// Token: 0x06000A63 RID: 2659 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0264", Offset = "0x2AF0264", VA = "0x2AF0264")]
	[Token(Token = "0x6000A63")]
	private void method_45()
	{
	}

	// Token: 0x06000A64 RID: 2660 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A64")]
	[Address(RVA = "0x2AF0268", Offset = "0x2AF0268", VA = "0x2AF0268")]
	private void method_46()
	{
	}

	// Token: 0x06000A65 RID: 2661 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF026C", Offset = "0x2AF026C", VA = "0x2AF026C")]
	[Token(Token = "0x6000A65")]
	private void method_47()
	{
	}

	// Token: 0x06000A66 RID: 2662 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A66")]
	[Address(RVA = "0x2AF0270", Offset = "0x2AF0270", VA = "0x2AF0270")]
	private void method_48()
	{
	}

	// Token: 0x06000A67 RID: 2663 RVA: 0x00002060 File Offset: 0x00000260
	[Address(RVA = "0x2AF0274", Offset = "0x2AF0274", VA = "0x2AF0274")]
	[Token(Token = "0x6000A67")]
	public Charger()
	{
	}

	// Token: 0x06000A68 RID: 2664 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF027C", Offset = "0x2AF027C", VA = "0x2AF027C")]
	[Token(Token = "0x6000A68")]
	private void method_49()
	{
	}

	// Token: 0x06000A69 RID: 2665 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A69")]
	[Address(RVA = "0x2AF0280", Offset = "0x2AF0280", VA = "0x2AF0280")]
	private void method_50()
	{
	}

	// Token: 0x06000A6A RID: 2666 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0284", Offset = "0x2AF0284", VA = "0x2AF0284")]
	[Token(Token = "0x6000A6A")]
	private void method_51()
	{
	}

	// Token: 0x06000A6B RID: 2667 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0288", Offset = "0x2AF0288", VA = "0x2AF0288")]
	[Token(Token = "0x6000A6B")]
	private void method_52()
	{
	}

	// Token: 0x06000A6C RID: 2668 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF028C", Offset = "0x2AF028C", VA = "0x2AF028C")]
	[Token(Token = "0x6000A6C")]
	private void Start()
	{
	}

	// Token: 0x06000A6D RID: 2669 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A6D")]
	[Address(RVA = "0x2AF0290", Offset = "0x2AF0290", VA = "0x2AF0290")]
	private void method_53()
	{
	}

	// Token: 0x06000A6E RID: 2670 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0294", Offset = "0x2AF0294", VA = "0x2AF0294")]
	[Token(Token = "0x6000A6E")]
	private void method_54()
	{
	}

	// Token: 0x06000A6F RID: 2671 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A6F")]
	[Address(RVA = "0x2AF0298", Offset = "0x2AF0298", VA = "0x2AF0298")]
	private void method_55()
	{
	}

	// Token: 0x06000A70 RID: 2672 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF029C", Offset = "0x2AF029C", VA = "0x2AF029C")]
	[Token(Token = "0x6000A70")]
	private void method_56()
	{
	}

	// Token: 0x06000A71 RID: 2673 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A71")]
	[Address(RVA = "0x2AF02A0", Offset = "0x2AF02A0", VA = "0x2AF02A0")]
	private void method_57()
	{
	}

	// Token: 0x06000A72 RID: 2674 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A72")]
	[Address(RVA = "0x2AF02A4", Offset = "0x2AF02A4", VA = "0x2AF02A4")]
	private void method_58()
	{
	}

	// Token: 0x06000A73 RID: 2675 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A73")]
	[Address(RVA = "0x2AF02A8", Offset = "0x2AF02A8", VA = "0x2AF02A8")]
	private void method_59()
	{
	}

	// Token: 0x06000A74 RID: 2676 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A74")]
	[Address(RVA = "0x2AF02AC", Offset = "0x2AF02AC", VA = "0x2AF02AC")]
	private void method_60()
	{
	}

	// Token: 0x06000A75 RID: 2677 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A75")]
	[Address(RVA = "0x2AF02B0", Offset = "0x2AF02B0", VA = "0x2AF02B0")]
	private void method_61()
	{
	}

	// Token: 0x06000A76 RID: 2678 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A76")]
	[Address(RVA = "0x2AF02B4", Offset = "0x2AF02B4", VA = "0x2AF02B4")]
	private void method_62()
	{
	}

	// Token: 0x06000A77 RID: 2679 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A77")]
	[Address(RVA = "0x2AF02B8", Offset = "0x2AF02B8", VA = "0x2AF02B8")]
	private void method_63()
	{
	}

	// Token: 0x06000A78 RID: 2680 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02BC", Offset = "0x2AF02BC", VA = "0x2AF02BC")]
	[Token(Token = "0x6000A78")]
	private void method_64()
	{
	}

	// Token: 0x06000A79 RID: 2681 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A79")]
	[Address(RVA = "0x2AF02C0", Offset = "0x2AF02C0", VA = "0x2AF02C0")]
	private void method_65()
	{
	}

	// Token: 0x06000A7A RID: 2682 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A7A")]
	[Address(RVA = "0x2AF02C4", Offset = "0x2AF02C4", VA = "0x2AF02C4")]
	private void method_66()
	{
	}

	// Token: 0x06000A7B RID: 2683 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A7B")]
	[Address(RVA = "0x2AF02C8", Offset = "0x2AF02C8", VA = "0x2AF02C8")]
	private void method_67()
	{
	}

	// Token: 0x06000A7C RID: 2684 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A7C")]
	[Address(RVA = "0x2AF02CC", Offset = "0x2AF02CC", VA = "0x2AF02CC")]
	private void method_68()
	{
	}

	// Token: 0x06000A7D RID: 2685 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A7D")]
	[Address(RVA = "0x2AF02D0", Offset = "0x2AF02D0", VA = "0x2AF02D0")]
	private void method_69()
	{
	}

	// Token: 0x06000A7E RID: 2686 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A7E")]
	[Address(RVA = "0x2AF02D4", Offset = "0x2AF02D4", VA = "0x2AF02D4")]
	private void method_70()
	{
	}

	// Token: 0x06000A7F RID: 2687 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A7F")]
	[Address(RVA = "0x2AF02D8", Offset = "0x2AF02D8", VA = "0x2AF02D8")]
	private void method_71()
	{
	}

	// Token: 0x06000A80 RID: 2688 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A80")]
	[Address(RVA = "0x2AF02DC", Offset = "0x2AF02DC", VA = "0x2AF02DC")]
	private void method_72()
	{
	}

	// Token: 0x06000A81 RID: 2689 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02E0", Offset = "0x2AF02E0", VA = "0x2AF02E0")]
	[Token(Token = "0x6000A81")]
	private void method_73()
	{
	}

	// Token: 0x06000A82 RID: 2690 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02E4", Offset = "0x2AF02E4", VA = "0x2AF02E4")]
	[Token(Token = "0x6000A82")]
	private void method_74()
	{
	}

	// Token: 0x06000A83 RID: 2691 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02E8", Offset = "0x2AF02E8", VA = "0x2AF02E8")]
	[Token(Token = "0x6000A83")]
	private void method_75()
	{
	}

	// Token: 0x06000A84 RID: 2692 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02EC", Offset = "0x2AF02EC", VA = "0x2AF02EC")]
	[Token(Token = "0x6000A84")]
	private void method_76()
	{
	}

	// Token: 0x06000A85 RID: 2693 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A85")]
	[Address(RVA = "0x2AF02F0", Offset = "0x2AF02F0", VA = "0x2AF02F0")]
	private void method_77()
	{
	}

	// Token: 0x06000A86 RID: 2694 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02F4", Offset = "0x2AF02F4", VA = "0x2AF02F4")]
	[Token(Token = "0x6000A86")]
	private void method_78()
	{
	}

	// Token: 0x06000A87 RID: 2695 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02F8", Offset = "0x2AF02F8", VA = "0x2AF02F8")]
	[Token(Token = "0x6000A87")]
	private void method_79()
	{
	}

	// Token: 0x06000A88 RID: 2696 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF02FC", Offset = "0x2AF02FC", VA = "0x2AF02FC")]
	[Token(Token = "0x6000A88")]
	private void method_80()
	{
	}

	// Token: 0x06000A89 RID: 2697 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A89")]
	[Address(RVA = "0x2AF0300", Offset = "0x2AF0300", VA = "0x2AF0300")]
	private void method_81()
	{
	}

	// Token: 0x06000A8A RID: 2698 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A8A")]
	[Address(RVA = "0x2AF0304", Offset = "0x2AF0304", VA = "0x2AF0304")]
	private void method_82()
	{
	}

	// Token: 0x06000A8B RID: 2699 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A8B")]
	[Address(RVA = "0x2AF0308", Offset = "0x2AF0308", VA = "0x2AF0308")]
	private void method_83()
	{
	}

	// Token: 0x06000A8C RID: 2700 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A8C")]
	[Address(RVA = "0x2AF030C", Offset = "0x2AF030C", VA = "0x2AF030C")]
	private void method_84()
	{
	}

	// Token: 0x06000A8D RID: 2701 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A8D")]
	[Address(RVA = "0x2AF0310", Offset = "0x2AF0310", VA = "0x2AF0310")]
	private void method_85()
	{
	}

	// Token: 0x06000A8E RID: 2702 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A8E")]
	[Address(RVA = "0x2AF0314", Offset = "0x2AF0314", VA = "0x2AF0314")]
	private void method_86()
	{
	}

	// Token: 0x06000A8F RID: 2703 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF0318", Offset = "0x2AF0318", VA = "0x2AF0318")]
	[Token(Token = "0x6000A8F")]
	private void method_87()
	{
	}

	// Token: 0x06000A90 RID: 2704 RVA: 0x00002083 File Offset: 0x00000283
	[Address(RVA = "0x2AF031C", Offset = "0x2AF031C", VA = "0x2AF031C")]
	[Token(Token = "0x6000A90")]
	private void method_88()
	{
	}

	// Token: 0x06000A91 RID: 2705 RVA: 0x00002083 File Offset: 0x00000283
	[Token(Token = "0x6000A91")]
	[Address(RVA = "0x2AF0320", Offset = "0x2AF0320", VA = "0x2AF0320")]
	private void method_89()
	{
	}
}
